package com.ombudsman.service.serviceImpl;

import java.io.IOException;
import java.net.URLDecoder;
import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.text.StringEscapeUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ombudsman.service.common.Constantsconfig;
import com.ombudsman.service.common.PhoenixHelper;
import com.ombudsman.service.model.ContactData;
import com.ombudsman.service.model.EmailData;
import com.ombudsman.service.model.LetterData;
import com.ombudsman.service.model.PhoneData;
import com.ombudsman.service.model.PortalData;
import com.ombudsman.service.model.TaskData;
import com.ombudsman.service.repo.ContactRepository;
import com.ombudsman.service.repo.IncreLoadAuditRepository;
import com.ombudsman.service.repo.IncreLoadErrorRepository;
import com.ombudsman.service.response.ContactRes;
import com.ombudsman.service.response.EmailRes;
import com.ombudsman.service.response.LetterRes;
import com.ombudsman.service.response.PhoneRes;
import com.ombudsman.service.response.PortalRes;
import com.ombudsman.service.response.TaskRes;

import okhttp3.HttpUrl;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

@Service
public class ContactPhxHelper {

	@Autowired
	PhoenixHelper phoenixHelper;

	@Autowired
	IncreLoadAuditRepository increLoadAuditRep;

	@Autowired
	IncreLoadErrorRepository increLoadErrorRep;

	@Autowired
	ContactRepository contactRep;

	@Autowired
	ContactSqlHelper contactsqlhelper;

	@Autowired
	Constantsconfig constant;

	Logger LOG = LogManager.getRootLogger();

	public String contactphxhelper(String startWebJob_formatted, ContactRes contactRes,
			ArrayList<ContactData> arrayListcontact, int Fetchxml_Record, String lastupdatedDate, String entityname,
			Set<String> map, String Fetch_IncrementalDataLoadAuditId, boolean moreRecords, String pagingCookie,
			int page) throws InterruptedException, IOException {

		Instant startpnx = Instant.now();
		LOG.info(String.format("Code started for %s  at : %s:", constant.Entity_Contact, startpnx));
		String fetchXml = "";

		LOG.info(String.format("Latest Modified Date for %s  is : %s ", constant.Entity_Contact, lastupdatedDate));

		OkHttpClient client = new OkHttpClient.Builder().connectTimeout(5, TimeUnit.MINUTES)
				.writeTimeout(120, TimeUnit.SECONDS).readTimeout(5, TimeUnit.MINUTES).build();

		fetchXml = this.getFetchXML(startWebJob_formatted, lastupdatedDate, Fetchxml_Record, entityname, pagingCookie,
				page,constant.ContactPk);

		String httpUrl = new HttpUrl.Builder().scheme("https").host(constant.APIM_HOST).addPathSegment("phoniex")
				.addPathSegment("contacts").addQueryParameter("fetchXml", fetchXml).build().toString();
		Request request = phoenixHelper.getPhoenixRequestBuild(httpUrl);

		Response response = client.newCall(request).execute();
		String dataReturned = response.body().string();

		LOG.info(String.format("fetchxml for %s  is   : %s", constant.Entity_Contact, fetchXml));

		ObjectMapper mapper = new ObjectMapper();
		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		JSONObject jsonObject = new JSONObject(dataReturned);
		JSONArray jsonArray = jsonObject.getJSONArray("value");

		if (jsonArray != null) {
			try {
				for (int i = 0; i < jsonArray.length(); i++) {

					contactValueSet(arrayListcontact, mapper, jsonArray, i);

				}
			} catch (Exception e) {

				LOG.warn(String.format("CAUGHT EXCEPTION while setting values in arrayList for %s  : %s",
						constant.Entity_Contact, e));
			}
		}
		contactRes.setContactData(arrayListcontact);
		LOG.info(String.format("Total recs extracted for %s  from Phoenix call are : %s", constant.Entity_Contact,
				arrayListcontact.size()));
		Instant endpnx = Instant.now();
		LOG.info(String.format("Phoenix call for %s  completed at : %s", constant.Entity_Contact, endpnx));
		long timeElapsedphnx = Duration.between(startpnx, endpnx).toMillis();
		LOG.info(String.format("***************Total time taken for %s  by Phoenix call(in millisecond) : %s",
				constant.Entity_Contact, timeElapsedphnx));

		for (ContactData condata : arrayListcontact) {
			map.add(condata.getContactid());
		}

		contactsqlhelper.insertForContact(arrayListcontact, Fetch_IncrementalDataLoadAuditId);
		// Extract paging cookie

		String responseXml = dataReturned;

		String pagingcookie = jsonObject.isNull("@Microsoft.Dynamics.CRM.fetchxmlpagingcookie") ? null
				: jsonObject.optString("@Microsoft.Dynamics.CRM.fetchxmlpagingcookie");
		String finalcookie = null;
		if (pagingcookie != null) {
			pagingCookie = extractPagingCookie(pagingcookie).replace("\"", "");
			String decodedpagingCookie1 = URLDecoder.decode(pagingCookie, "UTF-8");
			String decodedpagingCookie2 = URLDecoder.decode(decodedpagingCookie1, "UTF-8");
			finalcookie = StringEscapeUtils.escapeXml11(decodedpagingCookie2);

			moreRecords = responseXml.contains("\"@Microsoft.Dynamics.CRM.morerecords\":true");
		}
		LOG.info(String.format("Recs extracted for %s  from Phoenix call are : %s", constant.Entity_Contact,
				arrayListcontact.size()));
		LOG.info(String.format("More records are there for %s : %s", constant.Entity_Contact, moreRecords));
		return finalcookie;

	}

	private String extractPagingCookie(String pagingcookie) {

		Pattern pattern = Pattern.compile("pagingcookie=([^\\s>]+)");
		Matcher matcher = pattern.matcher(pagingcookie);
		return matcher.find() ? matcher.group(1) : null;
	}

	public String contactphxhelper_recon(String startWebJob_formatted, ContactRes contactRes,
			ArrayList<ContactData> arrayListcontact, int Fetchxml_Record, String lastupdatedDate, String entityname,
			String Fetch_IncrementalDataLoadAuditId, boolean moreRecords, String pagingCookie, int page)
			throws InterruptedException, IOException {

		Instant startpnx = Instant.now();
		LOG.info(String.format("Code started for %s  at : %s:", constant.Entity_Contact, startpnx));
		String fetchXml = "";
		
		LOG.info(String.format("Latest Modified Date for %s  is : %s ", constant.Entity_Contact, lastupdatedDate));

		OkHttpClient client = new OkHttpClient.Builder().connectTimeout(5, TimeUnit.MINUTES)
				.writeTimeout(120, TimeUnit.SECONDS).readTimeout(5, TimeUnit.MINUTES).build();

		fetchXml = this.getFetchXML(startWebJob_formatted, lastupdatedDate, Fetchxml_Record, entityname, pagingCookie,
				page,constant.ContactPk);

		String httpUrl = new HttpUrl.Builder().scheme("https").host(constant.APIM_HOST).addPathSegment("phoniex")
				.addPathSegment("contacts").addQueryParameter("fetchXml", fetchXml).build().toString();
		Request request = phoenixHelper.getPhoenixRequestBuild(httpUrl);

		Response response = client.newCall(request).execute();
		String dataReturned = response.body().string();

		LOG.info(String.format("fetchxml for %s  is   : %s", constant.Entity_Contact, fetchXml));

		ObjectMapper mapper = new ObjectMapper();
		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		JSONObject jsonObject = new JSONObject(dataReturned);
		JSONArray jsonArray = jsonObject.getJSONArray("value");

		if (jsonArray != null) {
			try {
				for (int i = 0; i < jsonArray.length(); i++) {

					contactValueSet(arrayListcontact, mapper, jsonArray, i);

				}
			} catch (Exception e) {

				LOG.warn(String.format("CAUGHT EXCEPTION while setting values in arrayList for %s  : %s",
						constant.Entity_Contact, e));
			}
		}
		contactRes.setContactData(arrayListcontact);
		LOG.info(String.format("Total recs extracted for %s  from Phoenix call are : %s", constant.Entity_Contact,
				arrayListcontact.size()));
		Instant endpnx = Instant.now();
		LOG.info(String.format("Phoenix call for %s  completed at : %s", constant.Entity_Contact, endpnx));
		long timeElapsedphnx = Duration.between(startpnx, endpnx).toMillis();
		LOG.info(String.format("***************Total time taken for %s  by Phoenix call(in millisecond) : %s",
				constant.Entity_Contact, timeElapsedphnx));
		contactsqlhelper.insertForContact(arrayListcontact, Fetch_IncrementalDataLoadAuditId);
		// Extract paging cookie

		String responseXml = dataReturned;

		String pagingcookie = jsonObject.isNull("@Microsoft.Dynamics.CRM.fetchxmlpagingcookie") ? null
				: jsonObject.optString("@Microsoft.Dynamics.CRM.fetchxmlpagingcookie");
		String finalcookie = null;
		if (pagingcookie != null) {
			pagingCookie = extractPagingCookie(pagingcookie).replace("\"", "");
			String decodedpagingCookie1 = URLDecoder.decode(pagingCookie, "UTF-8");
			String decodedpagingCookie2 = URLDecoder.decode(decodedpagingCookie1, "UTF-8");
			finalcookie = StringEscapeUtils.escapeXml11(decodedpagingCookie2);

			moreRecords = responseXml.contains("\"@Microsoft.Dynamics.CRM.morerecords\":true");
		}
		LOG.info(String.format("Recs extracted for %s  from Phoenix call are : %s", constant.Entity_Contact,
				arrayListcontact.size()));
		LOG.info(String.format("More records are there for %s : %s", constant.Entity_Contact, moreRecords));
		return finalcookie;

	}

	public String getFetchXML(String curtime, String lastupdatedDate, int Fetchxml_Record, String entityname,
			String pagingCookie, int page,String PK) {

		String fetchXML = "<fetch version='1.0' mapping='logical'  count='" + Fetchxml_Record + "' page='" + page + "'>"
				+ "<entity name='" + entityname + "'>" + "<filter>"
				+ "<condition attribute='modifiedon' operator='between' value=''>" + "<value>" + lastupdatedDate
				+ "</value>" + "<value>" + curtime + "</value>" + "</condition>" + "</filter>"
				+ "<order attribute='" + PK + "' /> " + "</entity>" + "</fetch>";
		if (pagingCookie != null) {
			fetchXML = fetchXML.replace("fetch ", "fetch paging-cookie='" + pagingCookie + "' ");
		}
		return fetchXML;

	}

	public String getFetchXMLEmail(String curtime, String lastupdatedDate, int Fetchxml_Record, String entityname,
			String pagingCookie, int page,String PK) {

		String fetchXML = "<fetch version='1.0' mapping='logical'  count='" + Fetchxml_Record + "' page='" + page + "'>"
				+ "<entity name='" + entityname + "'>" + "<attribute name='activityid' />" + "<attribute name='cc' />"
				+ "<attribute name='from' />" + "<attribute name='to' />" + "<attribute name='activitytypecode' />"
				+ "<attribute name='attachmentcount' />" + "<attribute name='directioncode' />"
				+ "<attribute name='emailsender' />" + "<attribute name='fos_isresponserequested' />"
				+ "<attribute name='fos_offeroutcomeid' />" + "<attribute name='fos_originator' />"
				+ "<attribute name='fos_recipientrole' />" + "<attribute name='fos_responsetobereceivedby' />"
				+ "<attribute name='regardingobjectid' />" + "<attribute name='senton' />"
				+ "<attribute name='statecode' />" + "<attribute name='subject' />"
				+ "<attribute name='torecipients' />" + "<attribute name='versionnumber' />"
				+ "<attribute name='createdby' />" + "<attribute name='createdon' />"
				+ "<attribute name='modifiedby' />" + "<attribute name='sender' />" + "<attribute name='modifiedon' />"
				+ "<filter>" + "<condition attribute='modifiedon' operator='between' value=''>" + "<value>"
				+ lastupdatedDate + "</value>" + "<value>" + curtime + "</value>" + "</condition>" + "</filter>"
				+ "<order attribute='" + PK + "' /> " + "</entity>" + "</fetch>";
		if (pagingCookie != null) {
			fetchXML = fetchXML.replace("fetch ", "fetch paging-cookie='" + pagingCookie + "' ");
		}
		return fetchXML;

	}

	public void contactValueSet(ArrayList<ContactData> arrayListcontact, ObjectMapper mapper, JSONArray jsonArray,
			int i) throws JsonProcessingException, JsonMappingException {
		ContactData caseObjcontact = null;

		caseObjcontact = mapper.readValue(jsonArray.get(i).toString(), ContactData.class);

		JSONObject childJsonObject = new JSONObject(jsonArray.get(i).toString());

		caseObjcontact.setStatecode(childJsonObject.isNull("statecode") ? null : childJsonObject.optLong("statecode"));

		caseObjcontact
				.setContactid(childJsonObject.isNull("contactid") ? null : childJsonObject.optString("contactid"));

		caseObjcontact.setFos_contactdescriptionoption(childJsonObject.isNull("fos_contactdescriptionoption") ? null
				: childJsonObject.optLong("fos_contactdescriptionoption"));

		caseObjcontact.setFos_digitalportalinvitestatus(childJsonObject.isNull("fos_digitalportalinvitestatus") ? null
				: childJsonObject.optLong("fos_digitalportalinvitestatus"));

		caseObjcontact.setFos_isdigitalportaladmin(childJsonObject.isNull("fos_isdigitalportaladmin") ? null
				: childJsonObject.optLong("fos_isdigitalportaladmin"));

		caseObjcontact.setFos_parentorganisationcapacity(childJsonObject.isNull("fos_parentorganisationcapacity") ? null
				: childJsonObject.optLong("fos_parentorganisationcapacity"));

		caseObjcontact.setFos_phonerecordingconsent(childJsonObject.isNull("fos_phonerecordingconsent") ? null
				: childJsonObject.optLong("fos_phonerecordingconsent"));

		caseObjcontact.setFos_preferredmethodofcorrespondencecode(
				childJsonObject.isNull("fos_preferredmethodofcorrespondencecode") ? null
						: childJsonObject.optLong("fos_preferredmethodofcorrespondencecode"));

		caseObjcontact.setFos_surveyconsentcode(childJsonObject.isNull("fos_surveyconsentcode") ? null
				: childJsonObject.optLong("fos_surveyconsentcode"));

		caseObjcontact
				.setGendercode(childJsonObject.isNull("gendercode") ? null : childJsonObject.optLong("gendercode"));

		caseObjcontact.setPreferredcontactmethodcode(childJsonObject.isNull("preferredcontactmethodcode") ? null
				: childJsonObject.optLong("preferredcontactmethodcode"));

		caseObjcontact
				.setDonotemail(childJsonObject.isNull("donotemail") ? null : childJsonObject.optBoolean("donotemail"));

		caseObjcontact
				.setDonotphone(childJsonObject.isNull("donotphone") ? null : childJsonObject.optBoolean("donotphone"));

		caseObjcontact.setDonotpostalmail(
				childJsonObject.isNull("donotpostalmail") ? null : childJsonObject.optBoolean("donotpostalmail"));

		caseObjcontact.setParentcustomerid(childJsonObject.isNull("_parentcustomerid_value") ? null
				: childJsonObject.optString("_parentcustomerid_value"));

		caseObjcontact.setParentcontactid(childJsonObject.isNull("_parentcontactid_value") ? null
				: childJsonObject.optString("_parentcontactid_value"));

		caseObjcontact.setAddress1_city(
				childJsonObject.isNull("address1_city") ? null : childJsonObject.optString("address1_city"));

		caseObjcontact.setAddress1_composite(
				childJsonObject.isNull("address1_composite") ? null : childJsonObject.optString("address1_composite"));

		caseObjcontact.setAddress1_country(
				childJsonObject.isNull("address1_country") ? null : childJsonObject.optString("address1_country"));
		caseObjcontact.setAddress1_county(
				childJsonObject.isNull("address1_county") ? null : childJsonObject.optString("address1_county"));

		caseObjcontact.setAddress1_line1(
				childJsonObject.isNull("address1_line1") ? null : childJsonObject.optString("address1_line1"));

		caseObjcontact.setAddress1_line2(
				childJsonObject.isNull("address1_line2") ? null : childJsonObject.optString("address1_line2"));

		caseObjcontact.setAddress1_line3(
				childJsonObject.isNull("address1_line3") ? null : childJsonObject.optString("address1_line3"));

		caseObjcontact.setAddress1_name(
				childJsonObject.isNull("address1_name") ? null : childJsonObject.optString("address1_name"));

		caseObjcontact.setAddress1_postalcode(childJsonObject.isNull("address1_postalcode") ? null
				: childJsonObject.optString("address1_postalcode"));

		caseObjcontact
				.setBirthdate(childJsonObject.isNull("birthdate") ? null : childJsonObject.optString("birthdate"));

		caseObjcontact.setDescription(
				childJsonObject.isNull("description") ? null : childJsonObject.optString("description"));

		caseObjcontact.setEmailaddress1(
				childJsonObject.isNull("emailaddress1") ? null : childJsonObject.optString("emailaddress1"));

		caseObjcontact
				.setFirstname(childJsonObject.isNull("firstname") ? null : childJsonObject.optString("firstname"));

		caseObjcontact.setFos_addressid(
				childJsonObject.isNull("fos_addressid") ? null : childJsonObject.optString("fos_addressid"));

		caseObjcontact
				.setFos_fcaid(childJsonObject.isNull("fos_fcaid") ? null : childJsonObject.optString("fos_fcaid"));

		caseObjcontact.setFos_needstring(
				childJsonObject.isNull("fos_needstring") ? null : childJsonObject.optString("fos_needstring"));

		caseObjcontact.setFos_othertitle(
				childJsonObject.isNull("fos_othertitle") ? null : childJsonObject.optString("fos_othertitle"));

		caseObjcontact.setFullname(childJsonObject.isNull("fullname") ? null : childJsonObject.optString("fullname"));

		caseObjcontact.setJobtitle(childJsonObject.isNull("jobtitle") ? null : childJsonObject.optString("jobtitle"));

		caseObjcontact.setLastname(childJsonObject.isNull("lastname") ? null : childJsonObject.optString("lastname"));

		caseObjcontact
				.setMiddlename(childJsonObject.isNull("middlename") ? null : childJsonObject.optString("middlename"));

		caseObjcontact.setMsa_managingpartneridname(
				childJsonObject.isNull("_msa_managingpartnerid_value@OData.Community.Display.V1.FormattedValue") ? null
						: childJsonObject
								.optString("_msa_managingpartnerid_value@OData.Community.Display.V1.FormattedValue"));

		caseObjcontact
				.setSalutation(childJsonObject.isNull("salutation") ? null : childJsonObject.optString("salutation"));

		caseObjcontact.setSuffix(childJsonObject.isNull("suffix") ? null : childJsonObject.optString("suffix"));

		caseObjcontact
				.setTelephone1(childJsonObject.isNull("telephone1") ? null : childJsonObject.optString("telephone1"));

		caseObjcontact
				.setTelephone2(childJsonObject.isNull("telephone2") ? null : childJsonObject.optString("telephone2"));

		caseObjcontact.setVersionnumber(
				childJsonObject.isNull("versionnumber") ? null : childJsonObject.optLong("versionnumber"));

		caseObjcontact
				.setCreatedon(childJsonObject.isNull("createdon") ? null : childJsonObject.optString("createdon"));

		caseObjcontact
				.setModifiedon(childJsonObject.isNull("modifiedon") ? null : childJsonObject.optString("modifiedon"));

		caseObjcontact.setCreatedby(
				childJsonObject.isNull("_createdby_value") ? null : childJsonObject.optString("_createdby_value"));

		caseObjcontact.setModifiedby(
				childJsonObject.isNull("_modifiedby_value") ? null : childJsonObject.optString("_modifiedby_value"));

		arrayListcontact.add(caseObjcontact);
	}

	public void taskValueSet(ArrayList<TaskData> arrayListTaskData, ObjectMapper mapper, JSONArray jsonArray, int i)
			throws JsonProcessingException, JsonMappingException {
		TaskData taskObj = null;

		taskObj = mapper.readValue(jsonArray.get(i).toString(), TaskData.class);

		JSONObject childJsonObject = new JSONObject(jsonArray.get(i).toString());

		taskObj.setActivityid(childJsonObject.isNull("activityid") ? null : childJsonObject.optString("activityid"));

		taskObj.setStatecode(childJsonObject.isNull("statecode") ? null : childJsonObject.optLong("statecode"));

		taskObj.setFos_emailid(
				childJsonObject.isNull("_fos_emailid_value") ? null : childJsonObject.optString("_fos_emailid_value"));

		taskObj.setFos_letterid(childJsonObject.isNull("_fos_letterid_value") ? null
				: childJsonObject.optString("_fos_letterid_value"));

		taskObj.setFos_phonecallid(childJsonObject.isNull("_fos_phonecallid_value") ? null
				: childJsonObject.optString("_fos_phonecallid_value"));

		taskObj.setRegardingobjectid(childJsonObject.isNull("_regardingobjectid_value") ? null
				: childJsonObject.optString("_regardingobjectid_value"));

		taskObj.setFos_completedondate(childJsonObject.isNull("fos_completedondate") ? null
				: childJsonObject.optString("fos_completedondate"));

		taskObj.setModifiedon(childJsonObject.isNull("modifiedon") ? null : childJsonObject.optString("modifiedon"));

		taskObj.setVersionnumber(
				childJsonObject.isNull("versionnumber") ? null : childJsonObject.optLong("versionnumber"));

		taskObj.setCreatedon(childJsonObject.isNull("createdon") ? null : childJsonObject.optString("createdon"));

		taskObj.setCreatedby(
				childJsonObject.isNull("_createdby_value") ? null : childJsonObject.optString("_createdby_value"));

		taskObj.setModifiedby(
				childJsonObject.isNull("_modifiedby_value") ? null : childJsonObject.optString("_modifiedby_value"));

		taskObj.setScheduledend(
				childJsonObject.isNull("scheduledend") ? null : childJsonObject.optString("scheduledend"));

		taskObj.setFos_categorycode(
				childJsonObject.isNull("fos_categorycode") ? null : childJsonObject.optLong("fos_categorycode"));

		arrayListTaskData.add(taskObj);
	}

	public void portalValueSet(ArrayList<PortalData> arrayListPortalData, ObjectMapper mapper, JSONArray jsonArray,
			int i) throws JsonProcessingException, JsonMappingException {
		PortalData portalObj = null;

		portalObj = mapper.readValue(jsonArray.get(i).toString(), PortalData.class);

		JSONObject childJsonObject = new JSONObject(jsonArray.get(i).toString());

		portalObj.setActivityid(childJsonObject.isNull("activityid") ? null : childJsonObject.optString("activityid"));

		portalObj.setCreatedbyname(
				childJsonObject.isNull("_createdby_value@OData.Community.Display.V1.FormattedValue") ? null
						: childJsonObject.optString("_createdby_value@OData.Community.Display.V1.FormattedValue"));

		portalObj.setFos_businessresponse(childJsonObject.isNull("fos_businessresponse") ? null
				: childJsonObject.optString("fos_businessresponse"));

		portalObj.setFos_capacity(
				childJsonObject.isNull("fos_capacity") ? null : childJsonObject.optString("fos_capacity"));

		portalObj.setFos_capacityname(
				childJsonObject.isNull("fos_capacity@OData.Community.Display.V1.FormattedValue") ? null
						: childJsonObject.optString("fos_capacity@OData.Community.Display.V1.FormattedValue"));

		portalObj.setFos_category(
				childJsonObject.isNull("fos_category") ? null : childJsonObject.optString("fos_category"));

		portalObj.setFos_dpuseremailaddress(childJsonObject.isNull("fos_dpuseremailaddress") ? null
				: childJsonObject.optString("fos_dpuseremailaddress"));

		portalObj.setFos_dpuserfullname(
				childJsonObject.isNull("fos_dpuserfullname") ? null : childJsonObject.optString("fos_dpuserfullname"));

		portalObj.setFos_otherreason(
				childJsonObject.isNull("fos_otherreason") ? null : childJsonObject.optString("fos_otherreason"));

		portalObj.setFos_otherreasonforchange(childJsonObject.isNull("fos_otherreasonforchange") ? null
				: childJsonObject.optString("fos_otherreasonforchange"));

		portalObj.setFos_reasonforchange(childJsonObject.isNull("fos_reasonforchange") ? null
				: childJsonObject.optString("fos_reasonforchange"));

		portalObj.setFos_reasonforchangename(
				childJsonObject.isNull("fos_reasonforchange@OData.Community.Display.V1.FormattedValue") ? null
						: childJsonObject.optString("fos_reasonforchange@OData.Community.Display.V1.FormattedValue"));

		portalObj.setModifiedbyname(
				childJsonObject.isNull("_modifiedby_value@OData.Community.Display.V1.FormattedValue") ? null
						: childJsonObject.optString("_modifiedby_value@OData.Community.Display.V1.FormattedValue"));

		portalObj.setRegardingobjectid(childJsonObject.isNull("_regardingobjectid_value") ? null
				: childJsonObject.optString("_regardingobjectid_value"));

		portalObj.setRegardingobjectidname(
				childJsonObject.isNull("_regardingobjectid_value@OData.Community.Display.V1.FormattedValue") ? null
						: childJsonObject
								.optString("_regardingobjectid_value@OData.Community.Display.V1.FormattedValue"));

		portalObj.setSubject(childJsonObject.isNull("subject") ? null : childJsonObject.optString("subject"));

		portalObj.setVersionnumber(
				childJsonObject.isNull("versionnumber") ? null : childJsonObject.optLong("versionnumber"));

		portalObj.setCreatedby(
				childJsonObject.isNull("_createdby_value") ? null : childJsonObject.optString("_createdby_value"));

		portalObj.setCreatedon(childJsonObject.isNull("createdon") ? null : childJsonObject.optString("createdon"));

		portalObj.setModifiedby(
				childJsonObject.isNull("_modifiedby_value") ? null : childJsonObject.optString("_modifiedby_value"));

		portalObj.setModifiedon(childJsonObject.isNull("modifiedon") ? null : childJsonObject.optString("modifiedon"));
		portalObj.setTo(childJsonObject.isNull("to") ? null : childJsonObject.optString("to"));
		portalObj.setFrom(childJsonObject.isNull("from") ? null : childJsonObject.optString("from"));

		arrayListPortalData.add(portalObj);
	}

	public void phoneValueSet(ArrayList<PhoneData> arrayListPhoneData, ObjectMapper mapper, JSONArray jsonArray, int i)
			throws JsonProcessingException, JsonMappingException {
		PhoneData phoneObj = null;

		phoneObj = mapper.readValue(jsonArray.get(i).toString(), PhoneData.class);

		JSONObject childJsonObject = new JSONObject(jsonArray.get(i).toString());

		phoneObj.setActivityid(childJsonObject.isNull("activityid") ? null : childJsonObject.optString("activityid"));

		phoneObj.setDescription(
				childJsonObject.isNull("description") ? null : childJsonObject.optString("description"));

		phoneObj.setDirectioncode(
				childJsonObject.isNull("directioncode") ? null : childJsonObject.optBoolean("directioncode"));

		phoneObj.setFos_isresponserequested(childJsonObject.isNull("fos_isresponserequested") ? null
				: childJsonObject.optBoolean("fos_isresponserequested"));

		phoneObj.setFos_direction(
				childJsonObject.isNull("fos_direction") ? null : childJsonObject.optString("fos_direction"));

		phoneObj.setFos_offeroutcomeid(childJsonObject.isNull("_fos_offeroutcomeid_value") ? null
				: childJsonObject.optString("_fos_offeroutcomeid_value"));

		phoneObj.setFos_originator(
				childJsonObject.isNull("fos_originator") ? null : childJsonObject.optLong("fos_originator"));

		phoneObj.setFos_recipientrole(
				childJsonObject.isNull("fos_recipientrole") ? null : childJsonObject.optString("fos_recipientrole"));

		phoneObj.setFos_responsetobereceivedby(childJsonObject.isNull("fos_responsetobereceivedby") ? null
				: childJsonObject.optString("fos_responsetobereceivedby"));

		phoneObj.setFos_visibleinportal(
				childJsonObject.isNull("fos_visibleinportal") ? null : childJsonObject.optLong("fos_visibleinportal"));

		phoneObj.setRegardingobjectid(childJsonObject.isNull("_regardingobjectid_value") ? null
				: childJsonObject.optString("_regardingobjectid_value"));

		phoneObj.setStatecode(childJsonObject.isNull("statecode") ? null : childJsonObject.optLong("statecode"));

		phoneObj.setVersionnumber(
				childJsonObject.isNull("versionnumber") ? null : childJsonObject.optLong("versionnumber"));

		phoneObj.setCreatedby(
				childJsonObject.isNull("_createdby_value") ? null : childJsonObject.optString("_createdby_value"));

		phoneObj.setCreatedon(childJsonObject.isNull("createdon") ? null : childJsonObject.optString("createdon"));

		phoneObj.setModifiedby(
				childJsonObject.isNull("_modifiedby_value") ? null : childJsonObject.optString("_modifiedby_value"));

		phoneObj.setModifiedon(childJsonObject.isNull("modifiedon") ? null : childJsonObject.optString("modifiedon"));

		arrayListPhoneData.add(phoneObj);
	}

	public void letterValueSet(ArrayList<LetterData> arrayListLetterData, ObjectMapper mapper, JSONArray jsonArray,
			int i) throws JsonProcessingException, JsonMappingException {
		LetterData letterObj = null;

		letterObj = mapper.readValue(jsonArray.get(i).toString(), LetterData.class);

		JSONObject childJsonObject = new JSONObject(jsonArray.get(i).toString());

		letterObj.setActivityid(childJsonObject.isNull("activityid") ? null : childJsonObject.optString("activityid"));

		letterObj.setDirectioncode(
				childJsonObject.isNull("directioncode") ? null : childJsonObject.optBoolean("directioncode"));

		letterObj.setFos_dispatcheddate(
				childJsonObject.isNull("fos_dispatcheddate") ? null : childJsonObject.optString("fos_dispatcheddate"));

		letterObj.setFos_isresponserequested(childJsonObject.isNull("fos_isresponserequested") ? null
				: childJsonObject.optBoolean("fos_isresponserequested"));

		letterObj.setFos_mailclasscode(
				childJsonObject.isNull("fos_mailclasscode") ? null : childJsonObject.optLong("fos_mailclasscode"));

		letterObj.setFos_offeroutcomeid(childJsonObject.isNull("_fos_offeroutcomeid_value") ? null
				: childJsonObject.optString("_fos_offeroutcomeid_value"));

		letterObj.setFos_originator(
				childJsonObject.isNull("fos_originator") ? null : childJsonObject.optLong("fos_originator"));

		letterObj.setFos_recipientrole(
				childJsonObject.isNull("fos_recipientrole") ? null : childJsonObject.optString("fos_recipientrole"));

		letterObj.setFos_responsetobereceivedby(childJsonObject.isNull("fos_responsetobereceivedby") ? null
				: childJsonObject.optString("fos_responsetobereceivedby"));

		letterObj.setFos_visibleinportal(
				childJsonObject.isNull("fos_visibleinportal") ? null : childJsonObject.optLong("fos_visibleinportal"));

		letterObj.setRegardingobjectid(childJsonObject.isNull("_regardingobjectid_value") ? null
				: childJsonObject.optString("_regardingobjectid_value"));

		letterObj.setStatecode(childJsonObject.isNull("statecode") ? null : childJsonObject.optLong("statecode"));

		letterObj.setVersionnumber(
				childJsonObject.isNull("versionnumber") ? null : childJsonObject.optLong("versionnumber"));

		letterObj.setCreatedby(
				childJsonObject.isNull("_createdby_value") ? null : childJsonObject.optString("_createdby_value"));

		letterObj.setCreatedon(childJsonObject.isNull("createdon") ? null : childJsonObject.optString("createdon"));

		letterObj.setModifiedby(
				childJsonObject.isNull("_modifiedby_value") ? null : childJsonObject.optString("_modifiedby_value"));

		letterObj.setFos_completedondate(childJsonObject.isNull("fos_completedondate") ? null
				: childJsonObject.optString("fos_completedondate"));

		letterObj.setModifiedon(childJsonObject.isNull("modifiedon") ? null : childJsonObject.optString("modifiedon"));

		arrayListLetterData.add(letterObj);
	}

	public void emailValueSet(ArrayList<EmailData> arrayListEmailData, ObjectMapper mapper, JSONArray jsonArray, int i)
			throws JsonProcessingException, JsonMappingException {
		EmailData emailObjEmail = null;

		emailObjEmail = mapper.readValue(jsonArray.get(i).toString(), EmailData.class);

		JSONObject childJsonObject = new JSONObject(jsonArray.get(i).toString());

		emailObjEmail
				.setActivityid(childJsonObject.isNull("activityid") ? null : childJsonObject.optString("activityid"));

		emailObjEmail.setStatecode(childJsonObject.isNull("statecode") ? null : childJsonObject.optLong("statecode"));

		emailObjEmail.setActivitytypecode(
				childJsonObject.isNull("activitytypecode") ? null : childJsonObject.optString("activitytypecode"));

		emailObjEmail.setAttachmentcount(
				childJsonObject.isNull("attachmentcount") ? null : childJsonObject.optLong("attachmentcount"));

		emailObjEmail.setDirectioncode(
				childJsonObject.isNull("directioncode") ? null : childJsonObject.optBoolean("directioncode"));

		emailObjEmail.setFos_isresponserequested(childJsonObject.isNull("fos_isresponserequested") ? null
				: childJsonObject.optBoolean("fos_isresponserequested"));

		emailObjEmail.setEmailsendername(
				childJsonObject.isNull("_emailsender_value@OData.Community.Display.V1.FormattedValue") ? null
						: childJsonObject.optString("_emailsender_value@OData.Community.Display.V1.FormattedValue"));

		emailObjEmail.setFos_offeroutcomeid(childJsonObject.isNull("_fos_offeroutcomeid_value") ? null
				: childJsonObject.optString("_fos_offeroutcomeid_value"));

		emailObjEmail.setFos_originator(
				childJsonObject.isNull("fos_originator") ? null : childJsonObject.optLong("fos_originator"));

		emailObjEmail.setFos_recipientrole(
				childJsonObject.isNull("fos_recipientrole") ? null : childJsonObject.optString("fos_recipientrole"));

		emailObjEmail.setFos_responsetobereceivedby(childJsonObject.isNull("fos_responsetobereceivedby") ? null
				: childJsonObject.optString("fos_responsetobereceivedby"));

		emailObjEmail.setFrom(childJsonObject.isNull("activityid") ? null : childJsonObject.optString("activityid"));

		emailObjEmail.setRegardingobjectid(childJsonObject.isNull("_regardingobjectid_value") ? null
				: childJsonObject.optString("_regardingobjectid_value"));

		emailObjEmail.setSenton(childJsonObject.isNull("senton") ? null : childJsonObject.optString("senton"));

		emailObjEmail.setSubject(childJsonObject.isNull("subject") ? null : childJsonObject.optString("subject"));

		emailObjEmail.setTorecipients(
				childJsonObject.isNull("torecipients") ? null : childJsonObject.optString("torecipients"));

		emailObjEmail.setVersionnumber(
				childJsonObject.isNull("versionnumber") ? null : childJsonObject.optLong("versionnumber"));

		emailObjEmail.setCreatedby(
				childJsonObject.isNull("_createdby_value") ? null : childJsonObject.optString("_createdby_value"));

		emailObjEmail.setCreatedon(childJsonObject.isNull("createdon") ? null : childJsonObject.optString("createdon"));

		emailObjEmail.setModifiedby(
				childJsonObject.isNull("_modifiedby_value") ? null : childJsonObject.optString("_modifiedby_value"));

		emailObjEmail
				.setModifiedon(childJsonObject.isNull("modifiedon") ? null : childJsonObject.optString("modifiedon"));
		emailObjEmail.setCc(childJsonObject.isNull("cc") ? null : childJsonObject.optString("cc"));
		emailObjEmail.setTo(childJsonObject.isNull("to") ? null : childJsonObject.optString("to"));

		arrayListEmailData.add(emailObjEmail);
	}

	public void phxContact(String Fetch_IncrementalDataLoadAuditId, ContactRes contactRes,
			ArrayList<ContactData> arrayListcontact, Set<String> map, String startWebJob_formatted,
			String lastupdatedDate, int batchsize) throws InterruptedException, IOException {
		Instant startpnx = Instant.now();
		String pagingCookie = null;
		int page = 1;
		boolean moreRecords = false;
		LOG.info(String.format("Code started for %s  at : %s ", constant.Entity_Contact, startpnx));

		do {
			arrayListcontact.clear();

			pagingCookie = contactphxhelper(startWebJob_formatted, contactRes, arrayListcontact, batchsize,
					lastupdatedDate, constant.Contact, map, Fetch_IncrementalDataLoadAuditId, moreRecords, pagingCookie,
					page);
			LOG.info(String.format("Paging cookie for %s  is : %s", constant.Entity_Contact, pagingCookie));
			page++;

		} while (pagingCookie != null);
		Instant endpnx = Instant.now();
		LOG.info(String.format("Code ended for %s  at : %s", constant.Entity_Contact, endpnx));
		long timeElapsedphnx = Duration.between(startpnx, endpnx).toMillis();
		LOG.info(String.format("***************Total time taken for %s  by all operations : %s milliseconds",
				constant.Entity_Contact, timeElapsedphnx));

		arrayListcontact.clear();

	}

	public Long phxContact_recon(String Fetch_IncrementalDataLoadAuditId, ContactRes contactRes,
			ArrayList<ContactData> arrayListcontact, String startWebJob_formatted, String lastupdatedDate,
			int batchsize, Long totalRecord) throws InterruptedException, IOException {
		Instant startpnx = Instant.now();
		String pagingCookie = null;
		int page = 1;
		boolean moreRecords = false;
		LOG.info(String.format("Code started for %s  at : %s ", constant.Entity_Contact, startpnx));

		do {
			arrayListcontact.clear();

			pagingCookie = contactphxhelper_recon(startWebJob_formatted, contactRes, arrayListcontact, batchsize,
					lastupdatedDate, constant.Contact, Fetch_IncrementalDataLoadAuditId, moreRecords, pagingCookie,
					page);

			totalRecord += arrayListcontact.size();

			LOG.info(String.format("Paging cookie for %s  is : %s", constant.Entity_Contact, pagingCookie));

			page++;
		} while (pagingCookie != null);
		Instant endpnx = Instant.now();
		LOG.info(String.format("Code ended for %s  at : %s", constant.Entity_Contact, endpnx));
		long timeElapsedphnx = Duration.between(startpnx, endpnx).toMillis();
		LOG.info(String.format("***************Total time taken for %s  by all operations : %s milliseconds",
				constant.Entity_Contact, timeElapsedphnx));

		arrayListcontact.clear();
		return totalRecord;

	}

	public String emailphxhelper(String startWebJob_formatted, ArrayList<EmailData> arrayListEmailData,
			EmailRes emailRes, int batchsize, String startdateValue, String entityname, Set<String> map,
			ArrayList<EmailData> finalarrayListEmailData, String fetch_IncrementalDataLoadAuditId, boolean moreRecords,
			String pagingCookie, int page) throws InterruptedException, IOException {

		String fetchXml = "";
		fetchXml = this.getFetchXMLEmail(startWebJob_formatted, startdateValue, batchsize, entityname, pagingCookie,
				page,constant.EmailPk);
		String httpUrl = new HttpUrl.Builder().scheme("https").host(constant.APIM_HOST).addPathSegment("phoniex")
				.addPathSegment("emails").addQueryParameter("fetchXml", fetchXml).build().toString();
		Request request = phoenixHelper.getPhoenixRequestBuild(httpUrl);

//		String accessToken = phoenixHelper.getConnectionWithD365();
//
//		HttpUrl httpUrl = new HttpUrl.Builder().scheme("https").host(phoenixHelper.PHOENIX_HOST).addPathSegment("api")
//				.addPathSegment("data").addPathSegment("v9.2").addPathSegment("emails")
//				.addQueryParameter("fetchXml", fetchXml).build();
//
//		Request request = phoenixHelper.getPhoenixRequestBuild(accessToken, httpUrl);
		OkHttpClient client = new OkHttpClient.Builder().connectTimeout(5, TimeUnit.MINUTES)
				.writeTimeout(120, TimeUnit.SECONDS).readTimeout(5, TimeUnit.MINUTES).build();
		Response response = client.newCall(request).execute();
		String dataReturned = response.body().string();

		LOG.info(String.format("fetchxml for %s  is   : %s", constant.Email, fetchXml));
		Instant datamappingpnx = Instant.now();
		ObjectMapper mapper = new ObjectMapper();
		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		JSONObject jsonObject = new JSONObject(dataReturned);
		JSONArray jsonArray = jsonObject.getJSONArray("value");

		if (jsonArray != null) {

			for (int i = 0; i < jsonArray.length(); i++) {

				emailValueSet(arrayListEmailData, mapper, jsonArray, i);

			}

		}

		emailRes.setEmailData(arrayListEmailData);

		Instant datamappingendpnx = Instant.now();
		long timeElapsedFinalMapping = Duration.between(datamappingpnx, datamappingendpnx).toMillis();
		LOG.info(String.format("Total time taken for Phoenix mapping for %s  is : %s", constant.Email,
				timeElapsedFinalMapping));

		Instant startfinallist = Instant.now();

		for (EmailData emaildata : arrayListEmailData) {
			if (map.contains(emaildata.getRegardingobjectid())) {
				finalarrayListEmailData.add(emaildata);
			}
		}
		Instant endfinallist = Instant.now();
		long timeElapsed = Duration.between(startfinallist, endfinallist).toMillis();
		LOG.info(String.format(
				"***************Total time taken for %s   by caseconsideration to give final list  is : %s ms ",
				constant.Email, timeElapsed));
		LOG.info(String.format("Total recs extracted for %s  from Phoenix call after matching with INC are : %s",
				constant.Email, finalarrayListEmailData.size()));
		contactsqlhelper.insertForEmail(finalarrayListEmailData, fetch_IncrementalDataLoadAuditId);
		

		// Extract paging cookie

		String responseXml = dataReturned;

		String pagingcookie = jsonObject.isNull("@Microsoft.Dynamics.CRM.fetchxmlpagingcookie") ? null
				: jsonObject.optString("@Microsoft.Dynamics.CRM.fetchxmlpagingcookie");
		String finalcookie = null;
		if (pagingcookie != null) {
			pagingCookie = extractPagingCookie(pagingcookie).replace("\"", "");
			String decodedpagingCookie1 = URLDecoder.decode(pagingCookie, "UTF-8");
			String decodedpagingCookie2 = URLDecoder.decode(decodedpagingCookie1, "UTF-8");
			finalcookie = StringEscapeUtils.escapeXml11(decodedpagingCookie2);

			moreRecords = responseXml.contains("\"@Microsoft.Dynamics.CRM.morerecords\":true");
		}
		LOG.info(String.format("Recs extracted for %s  from Phoenix call are : %s", constant.Email,
				finalarrayListEmailData.size()));
		LOG.info(String.format("More records are there for %s : %s", constant.Email, moreRecords));
		finalarrayListEmailData.clear();
		return finalcookie;

	}

	public void phxEmail(String Fetch_IncrementalDataLoadAuditId, EmailRes emailRes,
			ArrayList<EmailData> arrayListEmailData, Set<String> map, String startWebJob_formatted,
			String lastupdatedDate, int batchsize, ArrayList<EmailData> FinalarrayListEmailData)
			throws JsonMappingException, JsonProcessingException, InterruptedException, IOException {

		Instant startpnx = Instant.now();
		String pagingCookie = null;
		int page = 1;
		boolean moreRecords = false;

		LOG.info(String.format("Code started for %s  at : %s ", constant.Email, startpnx));

		do {
			arrayListEmailData.clear();

			pagingCookie = emailphxhelper(startWebJob_formatted, arrayListEmailData, emailRes, batchsize,
					lastupdatedDate, constant.Email, map, FinalarrayListEmailData, Fetch_IncrementalDataLoadAuditId,
					moreRecords, pagingCookie, page);

			LOG.info(String.format("Paging cookie for %s  is : %s", constant.Email, pagingCookie));
			page++;

		} while (pagingCookie != null);
		Instant endpnx = Instant.now();
		LOG.info(String.format("Code ended for %s  completed at : %s", constant.Email, endpnx));
		long timeElapsedphnx = Duration.between(startpnx, endpnx).toMillis();
		LOG.info(String.format("***************Total time taken for %s  by all operations : %s milliseconds",
				constant.Email, timeElapsedphnx));
		arrayListEmailData.clear();
		FinalarrayListEmailData.clear();

	}

	public void phxLetter(String fetch_IncrementalDataLoadAuditId, LetterRes letterRes,
			ArrayList<LetterData> arrayListLetterData, Set<String> map, String startWebJob_formatted,
			String lastupdatedDate, int batchsize, ArrayList<LetterData> finalarrayListLetterData)
			throws JsonMappingException, JsonProcessingException, InterruptedException, IOException {

		Instant startpnx = Instant.now();
		String pagingCookie = null;
		int page = 1;
		boolean moreRecords = false;

		LOG.info(String.format("Code started for %s  at : %s ", constant.Letter, startpnx));

		do {
			arrayListLetterData.clear();

			pagingCookie = letterphxhelper(startWebJob_formatted, arrayListLetterData, letterRes, batchsize,
					lastupdatedDate, constant.Letter, map, finalarrayListLetterData, fetch_IncrementalDataLoadAuditId,
					moreRecords, pagingCookie, page);

			LOG.info(String.format("Paging cookie for %s  is : %s", constant.Letter, pagingCookie));
			page++;

		} while (pagingCookie != null);

		Instant endpnx = Instant.now();
		LOG.info(String.format("Code ended for %s  completed at : %s", constant.Letter, endpnx));
		long timeElapsedphnx = Duration.between(startpnx, endpnx).toMillis();
		LOG.info(String.format("***************Total time taken for %s  by all operations : %s milliseconds",
				constant.Letter, timeElapsedphnx));
		arrayListLetterData.clear();

	}

	private String letterphxhelper(String startWebJob_formatted, ArrayList<LetterData> arrayListLetterData,
			LetterRes letterRes, int batchsize, String startdateValue, String entityname, Set<String> map,
			ArrayList<LetterData> finalarrayListLetterData, String fetch_IncrementalDataLoadAuditId,
			boolean moreRecords, String pagingCookie, int page) throws IOException, InterruptedException {

		String fetchXml = "";
		fetchXml = this.getFetchXML(startWebJob_formatted, startdateValue, batchsize, entityname, pagingCookie, page,constant.LetterPk);
		String httpUrl = new HttpUrl.Builder().scheme("https").host(constant.APIM_HOST).addPathSegment("phoniex")
				.addPathSegment("letters").addQueryParameter("fetchXml", fetchXml).build().toString();
		Request request = phoenixHelper.getPhoenixRequestBuild(httpUrl);

		OkHttpClient client = new OkHttpClient.Builder().connectTimeout(5, TimeUnit.MINUTES)
				.writeTimeout(120, TimeUnit.SECONDS).readTimeout(5, TimeUnit.MINUTES).build();

//		String accessToken = phoenixHelper.getConnectionWithD365();
//
//		HttpUrl httpUrl = new HttpUrl.Builder().scheme("https").host(phoenixHelper.PHOENIX_HOST).addPathSegment("api")
//				.addPathSegment("data").addPathSegment("v9.2").addPathSegment("letters")
//				.addQueryParameter("fetchXml", fetchXml).build();
//
//		Request request = phoenixHelper.getPhoenixRequestBuild(accessToken, httpUrl);
		Response response = client.newCall(request).execute();
		String dataReturned = response.body().string();

		LOG.info(String.format("fetchxml for %s  is   : %s", constant.Letter, fetchXml));
		Instant datamappingpnx = Instant.now();
		ObjectMapper mapper = new ObjectMapper();
		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		JSONObject jsonObject = new JSONObject(dataReturned);
		JSONArray jsonArray = jsonObject.getJSONArray("value");

		if (jsonArray != null) {

			for (int i = 0; i < jsonArray.length(); i++) {

				letterValueSet(arrayListLetterData, mapper, jsonArray, i);

			}

		}

		letterRes.setLetterData(arrayListLetterData);

		Instant datamappingendpnx = Instant.now();
		long timeElapsedFinalMapping = Duration.between(datamappingpnx, datamappingendpnx).toMillis();
		LOG.info(String.format("Total time taken for Phoenix mapping for %s  is : %s", constant.Letter,
				timeElapsedFinalMapping));
		Instant startfinallist = Instant.now();

		for (LetterData letterdata : arrayListLetterData) {
			if (map.contains(letterdata.getRegardingobjectid())) {
				finalarrayListLetterData.add(letterdata);
			}
		}
		Instant endfinallist = Instant.now();
		long timeElapsed = Duration.between(startfinallist, endfinallist).toMillis();
		LOG.info(String.format(
				"***************Total time taken for %s   by caseconsideration to give final list  is : %s ms ",
				constant.Letter, timeElapsed));
		LOG.info(String.format("Total recs extracted for %s  from Phoenix call after matching with INC are : %s",
				constant.Letter, finalarrayListLetterData.size()));
		contactsqlhelper.insertForLetter(finalarrayListLetterData, fetch_IncrementalDataLoadAuditId);

		// Extract paging cookie

		String responseXml = dataReturned;

		String pagingcookie = jsonObject.isNull("@Microsoft.Dynamics.CRM.fetchxmlpagingcookie") ? null
				: jsonObject.optString("@Microsoft.Dynamics.CRM.fetchxmlpagingcookie");
		String finalcookie = null;
		if (pagingcookie != null) {
			pagingCookie = extractPagingCookie(pagingcookie).replace("\"", "");
			String decodedpagingCookie1 = URLDecoder.decode(pagingCookie, "UTF-8");
			String decodedpagingCookie2 = URLDecoder.decode(decodedpagingCookie1, "UTF-8");
			finalcookie = StringEscapeUtils.escapeXml11(decodedpagingCookie2);

			moreRecords = responseXml.contains("\"@Microsoft.Dynamics.CRM.morerecords\":true");
		}
		LOG.info(String.format("Recs extracted for %s  from Phoenix call are : %s", constant.Letter,
				finalarrayListLetterData.size()));
		LOG.info(String.format("More records are there for %s : %s", constant.Letter, moreRecords));
		finalarrayListLetterData.clear();

		return finalcookie;

	}

	public void phxTask(String Fetch_IncrementalDataLoadAuditId, TaskRes taskRes, ArrayList<TaskData> arrayListTaskData,
			Set<String> map, String startWebJob_formatted, String lastupdatedDate, int batchsize,
			ArrayList<TaskData> FinalarrayListTaskData)
			throws JsonMappingException, JsonProcessingException, InterruptedException, IOException {

		Instant startpnx = Instant.now();
		String pagingCookie = null;
		int page = 1;
		boolean moreRecords = false;

		LOG.info(String.format("Code started for %s  at : %s ", constant.Task, startpnx));

		do {
			arrayListTaskData.clear();

			pagingCookie = taskphxhelper(startWebJob_formatted, arrayListTaskData, taskRes, batchsize, lastupdatedDate,
					constant.Task, map, FinalarrayListTaskData, Fetch_IncrementalDataLoadAuditId, moreRecords,
					pagingCookie, page);

			LOG.info(String.format("Paging cookie for %s  is : %s", constant.Task, pagingCookie));
			page++;

		} while (pagingCookie != null);

		Instant endpnx = Instant.now();
		LOG.info(String.format("Code ended for %s  completed at : %s", constant.Task, endpnx));
		long timeElapsedphnx = Duration.between(startpnx, endpnx).toMillis();
		LOG.info(String.format("***************Total time taken for %s  by all operations : %s milliseconds",
				constant.Task, timeElapsedphnx));
		arrayListTaskData.clear();
		FinalarrayListTaskData.clear();

	}

	public String taskphxhelper(String startWebJob_formatted, ArrayList<TaskData> arrayListTaskData, TaskRes taskRes,
			int batchsize, String startdateValue, String entityname, Set<String> map,
			ArrayList<TaskData> finalarrayListTaskData, String fetch_IncrementalDataLoadAuditId, boolean moreRecords,
			String pagingCookie, int page) throws InterruptedException, IOException {

		String fetchXml = "";

		fetchXml = this.getFetchXML(startWebJob_formatted, startdateValue, batchsize, entityname, pagingCookie, page,constant.TaskPk);
		String httpUrl = new HttpUrl.Builder().scheme("https").host(constant.APIM_HOST).addPathSegment("phoniex")
				.addPathSegment("tasks").addQueryParameter("fetchXml", fetchXml).build().toString();
		Request request = phoenixHelper.getPhoenixRequestBuild(httpUrl);
		OkHttpClient client = new OkHttpClient.Builder().connectTimeout(5, TimeUnit.MINUTES)
				.writeTimeout(120, TimeUnit.SECONDS).readTimeout(5, TimeUnit.MINUTES).build();

		Response response = client.newCall(request).execute();
		String dataReturned = response.body().string();

		LOG.info(String.format("fetchxml for %s  is   : %s", constant.Task, fetchXml));
		Instant datamappingpnx = Instant.now();
		ObjectMapper mapper = new ObjectMapper();
		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		JSONObject jsonObject = new JSONObject(dataReturned);
		JSONArray jsonArray = jsonObject.getJSONArray("value");

		if (jsonArray != null) {

			for (int i = 0; i < jsonArray.length(); i++) {

				taskValueSet(arrayListTaskData, mapper, jsonArray, i);

			}

		}

		taskRes.setTaskData(arrayListTaskData);

		Instant datamappingendpnx = Instant.now();
		long timeElapsedFinalMapping = Duration.between(datamappingpnx, datamappingendpnx).toMillis();
		LOG.info(String.format("Total time taken for Phoenix mapping for %s  is : %s", constant.Task,
				timeElapsedFinalMapping));

		Instant startfinallist = Instant.now();

		for (TaskData taskdata : arrayListTaskData) {
			if (map.contains(taskdata.getRegardingobjectid())) {
				finalarrayListTaskData.add(taskdata);
			}
		}
		Instant endfinallist = Instant.now();
		long timeElapsed = Duration.between(startfinallist, endfinallist).toMillis();
		LOG.info(String.format(
				"***************Total time taken by %s  to give final list after comparing with Contact is : %s ms ",
				constant.Task, timeElapsed));
		LOG.info(String.format("Total recs extracted for %s  from Phoenix call after matching with INC are : %s",
				constant.Task, finalarrayListTaskData.size()));
		contactsqlhelper.insertForTask(finalarrayListTaskData, fetch_IncrementalDataLoadAuditId);

		// Extract paging cookie

		String responseXml = dataReturned;

		String pagingcookie = jsonObject.isNull("@Microsoft.Dynamics.CRM.fetchxmlpagingcookie") ? null
				: jsonObject.optString("@Microsoft.Dynamics.CRM.fetchxmlpagingcookie");
		String finalcookie = null;
		if (pagingcookie != null) {
			pagingCookie = extractPagingCookie(pagingcookie).replace("\"", "");
			String decodedpagingCookie1 = URLDecoder.decode(pagingCookie, "UTF-8");
			String decodedpagingCookie2 = URLDecoder.decode(decodedpagingCookie1, "UTF-8");
			finalcookie = StringEscapeUtils.escapeXml11(decodedpagingCookie2);

			moreRecords = responseXml.contains("\"@Microsoft.Dynamics.CRM.morerecords\":true");
		}
		LOG.info(String.format("Recs extracted for %s  from Phoenix call are : %s", constant.Task,
				finalarrayListTaskData.size()));
		LOG.info(String.format("More records are there for %s : %s", constant.Task, moreRecords));
		finalarrayListTaskData.clear();

		return finalcookie;

	}

	public void phxPhone(String Fetch_IncrementalDataLoadAuditId, PhoneRes phoneRes,
			ArrayList<PhoneData> arrayListPhoneData, Set<String> map, String startWebJob_formatted,
			String lastupdatedDate, int batchsize, ArrayList<PhoneData> FinalarrayListPhoneData)
			throws JsonMappingException, JsonProcessingException, InterruptedException, IOException {

		Instant startpnx = Instant.now();
		String pagingCookie = null;
		int page = 1;
		boolean moreRecords = false;
		LOG.info(String.format("Code started for %s  at : %s ", constant.Phone, startpnx));

		do {
			arrayListPhoneData.clear();

			pagingCookie = phonephxhelper(startWebJob_formatted, arrayListPhoneData, phoneRes, batchsize,
					lastupdatedDate, constant.Phone, map, FinalarrayListPhoneData, Fetch_IncrementalDataLoadAuditId,
					moreRecords, pagingCookie, page);

			LOG.info(String.format("Paging cookie for %s  is : %s", constant.Phone, pagingCookie));
			page++;

		} while (pagingCookie != null);

		Instant endpnx = Instant.now();
		LOG.info(String.format("Code ended for %s  completed at : %s", constant.Phone, endpnx));
		long timeElapsedphnx = Duration.between(startpnx, endpnx).toMillis();
		LOG.info(String.format("***************Total time taken for %s  by all operations : %s milliseconds",
				constant.Phone, timeElapsedphnx));
		arrayListPhoneData.clear();
		FinalarrayListPhoneData.clear();

	}

	public String phonephxhelper(String startWebJob_formatted, ArrayList<PhoneData> arrayListPhoneData,
			PhoneRes phoneRes, int batchsize, String startdateValue, String entityname, Set<String> map,
			ArrayList<PhoneData> FinalarrayListPhoneData, String fetch_IncrementalDataLoadAuditId, boolean moreRecords,
			String pagingCookie, int page) throws IOException, InterruptedException {

		String fetchXml = "";

		fetchXml = this.getFetchXML(startWebJob_formatted, startdateValue, batchsize, entityname, pagingCookie, page,constant.PhonePk);
		String httpUrl = new HttpUrl.Builder().scheme("https").host(constant.APIM_HOST).addPathSegment("phoniex")
				.addPathSegment("phonecalls").addQueryParameter("fetchXml", fetchXml).build().toString();
		Request request = phoenixHelper.getPhoenixRequestBuild(httpUrl);

		OkHttpClient client = new OkHttpClient.Builder().connectTimeout(5, TimeUnit.MINUTES)
				.writeTimeout(120, TimeUnit.SECONDS).readTimeout(5, TimeUnit.MINUTES).build();
		Response response = client.newCall(request).execute();
		String dataReturned = response.body().string();

		LOG.info(String.format("fetchxml for %s  is   : %s", constant.Phone, fetchXml));
		Instant datamappingpnx = Instant.now();
		ObjectMapper mapper = new ObjectMapper();
		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		JSONObject jsonObject = new JSONObject(dataReturned);
		JSONArray jsonArray = jsonObject.getJSONArray("value");
		if (jsonArray != null) {

			for (int i = 0; i < jsonArray.length(); i++) {

				phoneValueSet(arrayListPhoneData, mapper, jsonArray, i);

			}

		}

		phoneRes.setPhoneData(arrayListPhoneData);

		Instant datamappingendpnx = Instant.now();
		long timeElapsedFinalMapping = Duration.between(datamappingpnx, datamappingendpnx).toMillis();
		LOG.info(String.format("Total time taken for Phoenix mapping for %s  is : %s", constant.Phone,
				timeElapsedFinalMapping));

		Instant startfinallist = Instant.now();

		for (PhoneData phonedata : arrayListPhoneData) {
			if (map.contains(phonedata.getRegardingobjectid())) {
				FinalarrayListPhoneData.add(phonedata);
			}
		}
		Instant endfinallist = Instant.now();
		long timeElapsed = Duration.between(startfinallist, endfinallist).toMillis();
		LOG.info(String.format(
				"***************Total time taken for %s   by caseconsideration to give final list  is : %s ms ",
				constant.Phone, timeElapsed));
		LOG.info(String.format("Total recs extracted for %s  from Phoenix call after matching with INC are : %s",
				constant.Phone, FinalarrayListPhoneData.size()));
		contactsqlhelper.insertForPhone(FinalarrayListPhoneData, fetch_IncrementalDataLoadAuditId);

		// Extract paging cookie

		String responseXml = dataReturned;

		String pagingcookie = jsonObject.isNull("@Microsoft.Dynamics.CRM.fetchxmlpagingcookie") ? null
				: jsonObject.optString("@Microsoft.Dynamics.CRM.fetchxmlpagingcookie");
		String finalcookie = null;
		if (pagingcookie != null) {
			pagingCookie = extractPagingCookie(pagingcookie).replace("\"", "");
			String decodedpagingCookie1 = URLDecoder.decode(pagingCookie, "UTF-8");
			String decodedpagingCookie2 = URLDecoder.decode(decodedpagingCookie1, "UTF-8");
			finalcookie = StringEscapeUtils.escapeXml11(decodedpagingCookie2);

			moreRecords = responseXml.contains("\"@Microsoft.Dynamics.CRM.morerecords\":true");
		}
		LOG.info(String.format("Recs extracted for %s  from Phoenix call are : %s", constant.Phone,
				FinalarrayListPhoneData.size()));
		LOG.info(String.format("More records are there for %s : %s", constant.Phone, moreRecords));
		FinalarrayListPhoneData.clear();
		return finalcookie;

	}

	public void phxPortal(String Fetch_IncrementalDataLoadAuditId, PortalRes portalRes,
			ArrayList<PortalData> arrayListPortalData, Set<String> map, String startWebJob_formatted,
			String lastupdatedDate, int batchsize, ArrayList<PortalData> FinalarrayListPortalData)
			throws JsonMappingException, JsonProcessingException, InterruptedException, IOException {

		Instant startpnx = Instant.now();
		String pagingCookie = null;
		int page = 1;
		boolean moreRecords = false;
		LOG.info(String.format("Code started for %s  at : %s ", constant.Portal, startpnx));

		do {
			arrayListPortalData.clear();

			pagingCookie = portalphxhelper(startWebJob_formatted, arrayListPortalData, portalRes, batchsize,
					lastupdatedDate, constant.Portal, map, FinalarrayListPortalData, Fetch_IncrementalDataLoadAuditId,
					moreRecords, pagingCookie, page);

			LOG.info(String.format("Paging cookie for %s  is : %s", constant.Portal, pagingCookie));
			page++;

		} while (pagingCookie != null);

		Instant endpnx = Instant.now();
		LOG.info(String.format("Code ended for %s  completed at : %s", constant.Portal, endpnx));
		long timeElapsedphnx = Duration.between(startpnx, endpnx).toMillis();
		LOG.info(String.format("***************Total time taken for %s  by all operations : %s milliseconds",
				constant.Portal, timeElapsedphnx));
		arrayListPortalData.clear();
		FinalarrayListPortalData.clear();

	}

	public String portalphxhelper(String startWebJob_formatted, ArrayList<PortalData> arrayListPortalData,
			PortalRes portalRes, int batchsize, String startdateValue, String entityname, Set<String> map,
			ArrayList<PortalData> FinalarrayListPortalData, String Fetch_IncrementalDataLoadAuditId,
			boolean moreRecords, String pagingCookie, int page) throws InterruptedException, IOException {

		String fetchXml = "";

		fetchXml = this.getFetchXML(startWebJob_formatted, startdateValue, batchsize, entityname, pagingCookie, page,constant.PortalPk);
		String httpUrl = new HttpUrl.Builder().scheme("https").host(constant.APIM_HOST).addPathSegment("phoniex")
				.addPathSegment("fos_portals").addQueryParameter("fetchXml", fetchXml).build().toString();
		Request request = phoenixHelper.getPhoenixRequestBuild(httpUrl);

		OkHttpClient client = new OkHttpClient.Builder().connectTimeout(5, TimeUnit.MINUTES)
				.writeTimeout(120, TimeUnit.SECONDS).readTimeout(5, TimeUnit.MINUTES).build();
		Response response = client.newCall(request).execute();
		String dataReturned = response.body().string();

		LOG.info(String.format("fetchxml for %s  is   : %s", constant.Portal, fetchXml));
		Instant datamappingpnx = Instant.now();
		ObjectMapper mapper = new ObjectMapper();
		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		JSONObject jsonObject = new JSONObject(dataReturned);
		JSONArray jsonArray = jsonObject.getJSONArray("value");

		if (jsonArray != null) {

			for (int i = 0; i < jsonArray.length(); i++) {

				portalValueSet(arrayListPortalData, mapper, jsonArray, i);

			}

		}

		portalRes.setPortalData(arrayListPortalData);

		Instant datamappingendpnx = Instant.now();
		long timeElapsedFinalMapping = Duration.between(datamappingpnx, datamappingendpnx).toMillis();
		LOG.info(String.format("Total time taken for Phoenix mapping for %s  is : %s", constant.Portal,
				timeElapsedFinalMapping));

		Instant startfinallist = Instant.now();

		for (PortalData portaldata : arrayListPortalData) {
			if (map.contains(portaldata.getRegardingobjectid())) {
				FinalarrayListPortalData.add(portaldata);
			}
		}
		Instant endfinallist = Instant.now();
		long timeElapsed = Duration.between(startfinallist, endfinallist).toMillis();
		LOG.info(String.format(
				"***************Total time taken by %s  to give final list after comparing with Contact is : %s ms ",
				constant.Portal, timeElapsed));
		LOG.info(String.format("Total recs extracted for %s  from Phoenix call after matching with INC are : %s",
				constant.Portal, FinalarrayListPortalData.size()));
		contactsqlhelper.insertForPortal(FinalarrayListPortalData, Fetch_IncrementalDataLoadAuditId);

		// Extract paging cookie

		String responseXml = dataReturned;

		String pagingcookie = jsonObject.isNull("@Microsoft.Dynamics.CRM.fetchxmlpagingcookie") ? null
				: jsonObject.optString("@Microsoft.Dynamics.CRM.fetchxmlpagingcookie");
		String finalcookie = null;
		if (pagingcookie != null) {
			pagingCookie = extractPagingCookie(pagingcookie).replace("\"", "");
			String decodedpagingCookie1 = URLDecoder.decode(pagingCookie, "UTF-8");
			String decodedpagingCookie2 = URLDecoder.decode(decodedpagingCookie1, "UTF-8");
			finalcookie = StringEscapeUtils.escapeXml11(decodedpagingCookie2);

			moreRecords = responseXml.contains("\"@Microsoft.Dynamics.CRM.morerecords\":true");
		}
		LOG.info(String.format("Recs extracted for %s  from Phoenix call are : %s", constant.Portal,
				FinalarrayListPortalData.size()));
		LOG.info(String.format("More records are there for %s : %s", constant.Portal, moreRecords));
		FinalarrayListPortalData.clear();
		return finalcookie;
	}

}
