package com.ombudsman.service.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.ombudsman.service.model.PortalData;

public interface PortalRepository extends JpaRepository<PortalData, String> {

	@Modifying
	@Transactional
	@Query(value = "INSERT INTO stg_portal(activityid,createdbyname,fos_businessresponse,fos_capacity,fos_capacityname,fos_category,fos_dpuseremailaddress,fos_dpuserfullname,fos_otherreason,fos_otherreasonforchange,fos_reasonforchange,fos_reasonforchangename,modifiedbyname,regardingobjectid,regardingobjectidname,subject,versionnumber,createdon,modifiedon,createdby,modifiedby,[to],[from],incrementaldataloadjobauditid) VALUES (CONVERT(uniqueidentifier,:activityid),:createdbyname,:fos_businessresponse,:fos_capacity,:fos_capacityname,:fos_category,:fos_dpuseremailaddress,:fos_dpuserfullname,:fos_otherreason,:fos_otherreasonforchange,:fos_reasonforchange,:fos_reasonforchangename,:modifiedbyname,CONVERT(uniqueidentifier,:regardingobjectid),:regardingobjectidname,:subject,:versionnumber, :createdon, :modifiedon, CONVERT(uniqueidentifier,:createdby), CONVERT(uniqueidentifier,:modifiedby),CONVERT(uniqueidentifier,:to),CONVERT(uniqueidentifier,:from),CONVERT(uniqueidentifier,:incrementaldataloadjobauditid))", nativeQuery = true)
	int InsertQuery(@Param("activityid") String activityid, @Param("createdbyname") String createdbyname,
			@Param("fos_businessresponse") String fos_businessresponse, @Param("fos_capacity") String fos_capacity,
			@Param("fos_capacityname") String fos_capacityname, @Param("fos_category") String fos_category,
			@Param("fos_dpuseremailaddress") String fos_dpuseremailaddress,
			@Param("fos_dpuserfullname") String fos_dpuserfullname, @Param("fos_otherreason") String fos_otherreason,
			@Param("fos_otherreasonforchange") String fos_otherreasonforchange,
			@Param("fos_reasonforchange") String fos_reasonforchange,
			@Param("fos_reasonforchangename") String fos_reasonforchangename,
			@Param("modifiedbyname") String modifiedbyname, @Param("regardingobjectid") String regardingobjectid,
			@Param("regardingobjectidname") String regardingobjectidname, @Param("subject") String subject,
			@Param("versionnumber") Long versionnumber, @Param("createdon") String createdon,
			@Param("modifiedon") String modifiedon, @Param("createdby") String createdby,
			@Param("modifiedby") String modifiedby,@Param("to") String to,@Param("from") String from,@Param("incrementaldataloadjobauditid") String incrementaldataloadjobauditid);
}
