package com.ombudsman.service.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.ombudsman.service.model.ContactData;

public interface TaskRepository extends JpaRepository<ContactData, String> {

	@Modifying
	@Transactional
	@Query(value = "INSERT INTO stg_task(activityid,fos_categorycode,fos_completedondate,fos_emailid,fos_letterid,fos_phonecallid,regardingobjectid,statecode,versionnumber,createdon,modifiedon,createdby,modifiedby,scheduledend,incrementaldataloadjobauditid) VALUES (CONVERT(uniqueidentifier,:activityid),:fos_categorycode, :fos_completedondate,CONVERT(uniqueidentifier,:fos_emailid),CONVERT(uniqueidentifier,:fos_letterid),CONVERT(uniqueidentifier,:fos_phonecallid),CONVERT(uniqueidentifier,:regardingobjectid),:statecode,:versionnumber,:createdon,:modifiedon,CONVERT(uniqueidentifier,:createdby),CONVERT(uniqueidentifier,:modifiedby),:scheduledend,CONVERT(uniqueidentifier,:incrementaldataloadjobauditid))", nativeQuery = true)
	int InsertQuery(@Param("activityid") String activityid, @Param("fos_categorycode") Long fos_categorycode,
			@Param("fos_completedondate") String fos_completedondate, @Param("fos_emailid") String fos_emailid,
			@Param("fos_letterid") String fos_letterid, @Param("fos_phonecallid") String fos_phonecallid,
			@Param("regardingobjectid") String regardingobjectid, @Param("statecode") Long statecode,
			@Param("versionnumber") Long versionnumber, @Param("createdon") String createdon,
			@Param("modifiedon") String modifiedon, @Param("createdby") String createdby,
			@Param("modifiedby") String modifiedby,@Param("scheduledend") String scheduledend,			
			@Param("incrementaldataloadjobauditid") String incrementaldataloadjobauditid);

}
