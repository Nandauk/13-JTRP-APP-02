package com.ombudsman.service.response;

public enum CurrentJobStatus {
	Pending(1, "Pending"), In_Progress(2, "In_Progress"), Completed(3, "Completed"),
	Partially_Completed(4, "Partially_Completed"), Failed(5, "Failed"), Terminated(6, "Terminated");

	private final int value;
	private final String status;

	CurrentJobStatus(int value, String status) {
		this.value = value;
		this.status = status;
	}

	public String getStatus() {
		return status;
	}

	public int getValue() {
		return value;
	}
	

}
