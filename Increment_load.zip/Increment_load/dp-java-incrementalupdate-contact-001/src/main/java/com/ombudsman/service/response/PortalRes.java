package com.ombudsman.service.response;

import java.util.List;

import com.ombudsman.service.model.PortalData;

public class PortalRes {
	private List<PortalData> portalData;

	public List<PortalData> getPortalData() {
		return portalData;
	}

	public void setPortalData(List<PortalData> portalData) {
		this.portalData = portalData;
	}

}
