package com.ombudsman.service.response;

import java.util.List;

import com.ombudsman.service.model.EmailData;

public class EmailRes {
	private List<EmailData> emailData;

	public List<EmailData> getEmailData() {
		return emailData;
	}

	public void setEmailData(List<EmailData> emailData) {
		this.emailData = emailData;
	}

}
