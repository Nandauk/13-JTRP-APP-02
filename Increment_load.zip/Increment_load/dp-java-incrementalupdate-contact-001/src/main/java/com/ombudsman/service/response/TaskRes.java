package com.ombudsman.service.response;

import java.util.List;

import com.ombudsman.service.model.TaskData;

public class TaskRes {
	private List<TaskData> taskData;

	public List<TaskData> getTaskData() {
		return taskData;
	}

	public void setTaskData(List<TaskData> taskData) {
		this.taskData = taskData;
	}

}
