package com.ombudsman.service.serviceImpl;

import java.io.IOException;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;
import java.time.*;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ombudsman.service.common.Constantsconfig;
import com.ombudsman.service.common.PhoenixHelper;
import com.ombudsman.service.model.ContactData;
import com.ombudsman.service.model.EmailData;
import com.ombudsman.service.model.LetterData;
import com.ombudsman.service.model.PhoneData;
import com.ombudsman.service.model.PortalData;
import com.ombudsman.service.model.TaskData;
import com.ombudsman.service.repo.ContactRepository;
import com.ombudsman.service.repo.IncreLoadAuditRepository;
import com.ombudsman.service.repo.IncreLoadErrorRepository;
import com.ombudsman.service.response.ContactRes;
import com.ombudsman.service.response.EmailRes;
import com.ombudsman.service.response.LetterRes;
import com.ombudsman.service.response.PhoneRes;
import com.ombudsman.service.response.PortalRes;
import com.ombudsman.service.response.TaskRes;
import com.ombudsman.service.services.ContactPhxToSqlService;

@Service
public class ContactPhxToSqlImpl implements ContactPhxToSqlService {

	@Autowired
	PhoenixHelper phoenixHelper;

	@Autowired
	IncreLoadAuditRepository increLoadAuditRep;

	@Autowired
	IncreLoadErrorRepository increLoadErrorRep;

	@Autowired
	ContactRepository contactRep;

	@Autowired
	ContactPhxHelper contactphxhelper;

	@Autowired
	ContactSqlHelper contactsqlhelper;

	@Autowired
	Constantsconfig constant;

	@Autowired
	EmailHelper emailhelper;

	Logger LOG = LogManager.getRootLogger();

	@Override
	public void contactUpdatePnxtoSql() throws IOException, InterruptedException {

		String Fetch_IncrementalDataLoadAuditId = null;

		var contactRes = new ContactRes();
		var emailRes = new EmailRes();
		var letterRes = new LetterRes();
		var portalRes = new PortalRes();
		var phoneRes = new PhoneRes();
		var taskRes = new TaskRes();

		ArrayList<TaskData> arrayListTaskData = new ArrayList<>();
		ArrayList<EmailData> arrayListEmailData = new ArrayList<>();
		ArrayList<PhoneData> arrayListPhoneData = new ArrayList<>();
		ArrayList<PortalData> arrayListPortalData = new ArrayList<>();
		ArrayList<LetterData> arrayListLetterData = new ArrayList<>();
		ArrayList<TaskData> FinalarrayListTaskData = new ArrayList<>();
		ArrayList<EmailData> FinalarrayListEmailData = new ArrayList<>();
		ArrayList<PhoneData> FinalarrayListPhoneData = new ArrayList<>();
		ArrayList<PortalData> FinalarrayListPortalData = new ArrayList<>();
		ArrayList<LetterData> FinalarrayListLetterData = new ArrayList<>();
		ArrayList<ContactData> arrayListcontact = new ArrayList<>();
		Set<String> map = new HashSet<>();
		Integer failedCount = 0;
		Long totalSuccessCount = (long) 0;
		int current_status_id_inprogress, current_status_id_readytoprocess, current_status_id_failed_azurfunc;
		int current_status_id_failed, current_status_id_failed_deleterecon;
		Long totalRecord = (long) 0;

		Instant startWebJob = Instant.now();
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS").withZone(ZoneId.of("UTC"));
		String startWebJob_formatted = formatter.format(startWebJob);
		String startWebJob_UTC = Instant.now().toString();

		try {

			LOG.info(String.format("WebJob started for  %s  at : %s ", constant.Entity_Contact, startWebJob));

			current_status_id_failed = increLoadAuditRep.getCurrentStatusFId(constant.DataSourceName, constant.Failed);
			current_status_id_failed_azurfunc = increLoadAuditRep.getCurrentStatusFId(constant.DataSourceName_AZUNCFUNC,
					constant.Failed);
			current_status_id_failed_deleterecon = increLoadAuditRep
					.getCurrentStatusFId(constant.DataSourceName_DEL_RECON, constant.Failed);

			String last7DaysTimeStamp = java.time.LocalDateTime.now().minusDays(7)
					.format(java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss:SSS"));
			int failedCountLast7days = increLoadAuditRep.getFailedEntries(current_status_id_failed,
					current_status_id_failed_azurfunc, current_status_id_failed_deleterecon, last7DaysTimeStamp);

			if (failedCountLast7days > 0) {
				LOG.info(String.format("Due to some failed entries in audit table, webJob is exiting for %s at :%s.",
						constant.Entity_Contact, startWebJob));
				// Send email to support team
				emailhelper.NotificationWebclient(constant.Entity_Contact, "NA", constant.DataSourceName,
						"Due to some failed entries in audit table,webJob is exiting", Instant.now().toString());
				//
				return;
			}

			int JobId = increLoadAuditRep.getJobID(constant.Entity_Contact);
			current_status_id_inprogress = increLoadAuditRep.getCurrentStatusIPId(constant.DataSourceName,
					constant.In_Progress);

			current_status_id_readytoprocess = increLoadAuditRep.getCurrentStatusRTPId(constant.DataSourceName,
					constant.Ready_To_Process);

			increLoadAuditRep.InsertQuery(JobId, startWebJob_formatted, arrayListcontact.size(), totalSuccessCount,
					failedCount, current_status_id_inprogress, null, constant.DataSourceName, constant.Entity_Contact,
					constant.Entity_Contact);

			Fetch_IncrementalDataLoadAuditId = increLoadAuditRep.getIncrementalDataLoadAuditId(startWebJob_formatted,
					current_status_id_inprogress, constant.DataSourceName, constant.Entity_Contact);

			String lastupdatedDate_temp = increLoadAuditRep.findLatestDatefromphx(constant.Entity_Contact);
			String lastupdatedDate =LocalDateTime.parse(lastupdatedDate_temp,DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.S")).atZone(ZoneOffset.UTC).format(DateTimeFormatter.ISO_INSTANT);
			int batchsize = constant.Fetchxml_Record;

			// Code for Contact
			contactphxhelper.phxContact(Fetch_IncrementalDataLoadAuditId, contactRes, arrayListcontact,
					map, startWebJob_UTC, lastupdatedDate, batchsize);
			totalRecord += map.size();
			LOG.info(String.format("Total records of %s are : %s", constant.Entity_Contact, totalRecord));

			if (totalRecord != 0) {

				// Code for Email

				contactphxhelper.phxEmail(Fetch_IncrementalDataLoadAuditId, emailRes, arrayListEmailData, map,
						startWebJob_UTC, lastupdatedDate, batchsize, FinalarrayListEmailData);

				// Code for Letter

				contactphxhelper.phxLetter(Fetch_IncrementalDataLoadAuditId, letterRes, arrayListLetterData, map,
						startWebJob_UTC, lastupdatedDate, batchsize, FinalarrayListLetterData);

				// Code for Task

				contactphxhelper.phxTask(Fetch_IncrementalDataLoadAuditId, taskRes, arrayListTaskData, map,
						startWebJob_UTC, lastupdatedDate, batchsize, FinalarrayListTaskData);

				// Code for Phone

				contactphxhelper.phxPhone(Fetch_IncrementalDataLoadAuditId, phoneRes, arrayListPhoneData, map,
						startWebJob_UTC, lastupdatedDate, batchsize, FinalarrayListPhoneData);

				// Code for portal

				contactphxhelper.phxPortal(Fetch_IncrementalDataLoadAuditId, portalRes, arrayListPortalData, map,
						startWebJob_UTC, lastupdatedDate, batchsize, FinalarrayListPortalData);
			}
			map.clear();
			increLoadAuditRep.UpdateQuery(totalRecord, totalSuccessCount, failedCount, current_status_id_readytoprocess,
					null, Fetch_IncrementalDataLoadAuditId, constant.Entity_Contact);

		} catch (Exception e) {

			LOG.error(String.format("ERROR IN getting data from phoenix for %s .Error logs: %s:",
					constant.Entity_Contact, e.getMessage()));

			Instant finishWebJobCatchIU = Instant.now();
			String emailTime = finishWebJobCatchIU.toString();
			LOG.info(String.format("Web job went to Catch block for %s ", constant.Entity_Contact));
			long timeElapsedWebJobcatchIU = Duration.between(startWebJob, finishWebJobCatchIU).toMillis();
			LOG.info(String.format(
					"****************Total time taken by Webjob for %s till completion from catch block : %s(in milliseconds)*************** :",
					constant.Entity_Contact, timeElapsedWebJobcatchIU));

			String DataPayload = "Not applicable,Failed at phoenix stage level";
			current_status_id_failed = increLoadAuditRep.getCurrentStatusFId(constant.DataSourceName, constant.Failed);
			// Entry in Error Table
			increLoadErrorRep.InsertQuery(Fetch_IncrementalDataLoadAuditId, DataPayload, current_status_id_failed,
					constant.Error_log, e.getMessage(), constant.Entity_Contact, constant.Entity_Contact);

			// Entry in Audit table
			increLoadAuditRep.UpdateQuery(totalRecord, totalSuccessCount, failedCount, current_status_id_failed,
					Instant.now().toString(), Fetch_IncrementalDataLoadAuditId, constant.Entity_Contact);
			// Send email to support team
			emailhelper.NotificationWebclient(constant.Entity_Contact, Fetch_IncrementalDataLoadAuditId,
					constant.DataSourceName, e.getMessage(), emailTime);
			//
			Thread.currentThread().interrupt();
			throw new RuntimeException(
					String.format("Job failed for %s  with Error : %s", constant.Entity_Contact, ExceptionUtils.getStackTrace(e)));

		}

		Instant Finalfinish = Instant.now();
		long timeElapsedcompleteJob = Duration.between(startWebJob, Finalfinish).toMillis();
		LOG.info(String.format("***************Total time taken for %s  for Complete Job  is : %s ms ",
				constant.Entity_Contact, timeElapsedcompleteJob));

	}

	@Override
	public void contactUpdatePnxtoSql_recon(String Start_time, String End_time)
			throws IOException, InterruptedException {
		String Fetch_IncrementalDataLoadAuditId = null;

		var contactRes = new ContactRes();

		ArrayList<ContactData> arrayListcontact = new ArrayList<>();

		Integer failedCount = 0;
		Long totalSuccessCount = (long) 0;
		int current_status_id_inprogress, current_status_id_completed, current_status_id_readytoprocess;
		int current_status_id_failed, current_status_id_failed_azurfunc, current_status_id_failed_deleterecon;
		Long totalRecord = (long) 0;
		Instant startWebJob = Instant.now();
		
		String startWebJob_formatted = End_time.equals("NA") ? ZonedDateTime.of(LocalDate.now(ZoneOffset.UTC), LocalTime.of(22, 59,0), ZoneOffset.UTC).format(DateTimeFormatter.ISO_INSTANT)
				: End_time;

		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS").withZone(ZoneId.of("UTC"));
		String startWebJob_recon = formatter.format(startWebJob);
		try {

			LOG.info(String.format("WebJob started for  %s  at : %s ", constant.Entity_Contact, startWebJob));
			current_status_id_failed = increLoadAuditRep.getCurrentStatusFId(constant.DataSourceName, constant.Failed);
			current_status_id_failed_azurfunc = increLoadAuditRep.getCurrentStatusFId(constant.DataSourceName_AZUNCFUNC,
					constant.Failed);
			current_status_id_failed_deleterecon = increLoadAuditRep
					.getCurrentStatusFId(constant.DataSourceName_DEL_RECON, constant.Failed);

			String last7DaysTimeStamp = java.time.LocalDateTime.now().minusDays(7)
					.format(java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss:SSS"));
			int failedCountLast7days = increLoadAuditRep.getFailedEntries(current_status_id_failed,
					current_status_id_failed_azurfunc, current_status_id_failed_deleterecon, last7DaysTimeStamp);

			if (failedCountLast7days > 0) {
				LOG.info(String.format("Due to some failed entries in audit table, webJob is exiting for %s at :%s.",
						constant.Entity_Contact, startWebJob));
				// Send email to support team
				emailhelper.NotificationWebclient(constant.Entity_Contact, "NA", constant.DataSourceName,
						"Due to some failed entries in audit table,webJob is exiting", Instant.now().toString());
				//
				return;
			}
			int JobId = increLoadAuditRep.getJobID(constant.Entity_Contact);
			current_status_id_inprogress = increLoadAuditRep.getCurrentStatusIPId(constant.DataSourceName,
					constant.In_Progress);

			current_status_id_readytoprocess = increLoadAuditRep.getCurrentStatusRTPId(constant.DataSourceName,
					constant.Ready_To_Process);
			increLoadAuditRep.InsertQuery(JobId, startWebJob_recon, arrayListcontact.size(), totalSuccessCount,
					failedCount, current_status_id_inprogress, null, constant.DataSourceName, constant.Entity_Contact,
					constant.Entity_Contact);

			Fetch_IncrementalDataLoadAuditId = increLoadAuditRep.getIncrementalDataLoadAuditId(startWebJob_recon,
					current_status_id_inprogress, constant.DataSourceName, constant.Entity_Contact);

			String lastupdatedDate = Start_time.equals("NA")
					? ZonedDateTime.of(LocalDate.now(ZoneOffset.UTC).minusDays(1), LocalTime.of(23, 0, 00), ZoneOffset.UTC).format(DateTimeFormatter.ISO_INSTANT)
					: Start_time;
			int batchsize = constant.Fetchxml_Record;

			// Code for Contact
			totalRecord = contactphxhelper.phxContact_recon(Fetch_IncrementalDataLoadAuditId, contactRes,
					arrayListcontact, startWebJob_formatted, lastupdatedDate, batchsize, totalRecord);
			

			increLoadAuditRep.UpdateQuery(totalRecord, totalSuccessCount, failedCount, current_status_id_readytoprocess,
					null, Fetch_IncrementalDataLoadAuditId, constant.Entity_Contact);

		} catch (Exception e) {

			LOG.error(String.format("ERROR IN getting data from phoenix for %s .Error logs: %s:",
					constant.Entity_Contact, e.getMessage()));

			Instant finishWebJobCatchIU = Instant.now();
			String emailTime = finishWebJobCatchIU.toString();
			LOG.info(String.format("Web job went to Catch block for %s ", constant.Entity_Contact));
			long timeElapsedWebJobcatchIU = Duration.between(startWebJob, finishWebJobCatchIU).toMillis();
			LOG.info(String.format(
					"****************Total time taken by Webjob for %s till completion from catch block : %s(in milliseconds)*************** :",
					constant.Entity_Contact, timeElapsedWebJobcatchIU));

			String DataPayload = "Not applicable,Failed at phoenix stage level";
			current_status_id_failed = increLoadAuditRep.getCurrentStatusFId(constant.DataSourceName, constant.Failed);
			// Entry in Error Table
			increLoadErrorRep.InsertQuery(Fetch_IncrementalDataLoadAuditId, DataPayload, current_status_id_failed,
					constant.Error_log, e.getMessage(), constant.Entity_Contact,
					constant.Entity_Contact);

			// Entry in Audit table
			increLoadAuditRep.UpdateQuery(totalRecord, totalSuccessCount, failedCount, current_status_id_failed,
					Instant.now().toString(), Fetch_IncrementalDataLoadAuditId, constant.Entity_Contact);
			// Send email to support team
			emailhelper.NotificationWebclient(constant.Entity_Contact, Fetch_IncrementalDataLoadAuditId,
					constant.DataSourceName, e.getMessage(), emailTime);
			//
			Thread.currentThread().interrupt();
			throw new RuntimeException(String.format("Job failed for %s  with Error : %s", constant.Entity_Contact,
					ExceptionUtils.getStackTrace(e)));

		}

		Instant Finalfinish = Instant.now();

		long timeElapsedcompleteJob = Duration.between(startWebJob, Finalfinish).toMillis();
		LOG.info(String.format("***************Total time taken for %s  for Complete Job  is : %s ms ",
				constant.Entity_Contact, timeElapsedcompleteJob));
	}

}
