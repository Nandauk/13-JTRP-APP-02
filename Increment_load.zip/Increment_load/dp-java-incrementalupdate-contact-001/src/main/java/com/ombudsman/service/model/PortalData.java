package com.ombudsman.service.model;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "stg_portal")
public class PortalData {

	@Id
	private String activityid;
	private String createdbyname;
	private String fos_businessresponse;
	private String fos_capacity;
	private String fos_capacityname;
	private String fos_category;
	private String fos_dpuseremailaddress;
	private String fos_dpuserfullname;
	private String fos_otherreason;
	private String fos_otherreasonforchange;
	private String fos_reasonforchange;
	private String fos_reasonforchangename;
	private String from;
	private String modifiedbyname;
	private String regardingobjectid;
	private String regardingobjectidname;
	private String subject;
	private String to;
	public String getFrom() {
		return from;
	}

	public void setFrom(String from) {
		this.from = from;
	}

	public String getTo() {
		return to;
	}

	public void setTo(String to) {
		this.to = to;
	}

	private Long versionnumber;
	private String createdon;
	private String modifiedon;
	private String createdby;
	private String modifiedby;
	private String incrementaldataloadjobauditid;

	public String getIncrementaldataloadjobauditid() {
		return incrementaldataloadjobauditid;
	}

	public void setIncrementaldataloadjobauditid(String incrementaldataloadjobauditid) {
		this.incrementaldataloadjobauditid = incrementaldataloadjobauditid;
	}

	public String getActivityid() {
		return activityid;
	}

	public void setActivityid(String activityid) {
		this.activityid = activityid;
	}

	public String getCreatedbyname() {
		return createdbyname;
	}

	public void setCreatedbyname(String createdbyname) {
		this.createdbyname = createdbyname;
	}

	public String getFos_businessresponse() {
		return fos_businessresponse;
	}

	public void setFos_businessresponse(String fos_businessresponse) {
		this.fos_businessresponse = fos_businessresponse;
	}

	public String getFos_capacity() {
		return fos_capacity;
	}

	public void setFos_capacity(String fos_capacity) {
		this.fos_capacity = fos_capacity;
	}

	public String getFos_capacityname() {
		return fos_capacityname;
	}

	public void setFos_capacityname(String fos_capacityname) {
		this.fos_capacityname = fos_capacityname;
	}

	public String getFos_category() {
		return fos_category;
	}

	public void setFos_category(String fos_category) {
		this.fos_category = fos_category;
	}

	public String getFos_dpuseremailaddress() {
		return fos_dpuseremailaddress;
	}

	public void setFos_dpuseremailaddress(String fos_dpuseremailaddress) {
		this.fos_dpuseremailaddress = fos_dpuseremailaddress;
	}

	public String getFos_dpuserfullname() {
		return fos_dpuserfullname;
	}

	public void setFos_dpuserfullname(String fos_dpuserfullname) {
		this.fos_dpuserfullname = fos_dpuserfullname;
	}

	public String getFos_otherreason() {
		return fos_otherreason;
	}

	public void setFos_otherreason(String fos_otherreason) {
		this.fos_otherreason = fos_otherreason;
	}

	public String getFos_otherreasonforchange() {
		return fos_otherreasonforchange;
	}

	public void setFos_otherreasonforchange(String fos_otherreasonforchange) {
		this.fos_otherreasonforchange = fos_otherreasonforchange;
	}

	public String getFos_reasonforchange() {
		return fos_reasonforchange;
	}

	public void setFos_reasonforchange(String fos_reasonforchange) {
		this.fos_reasonforchange = fos_reasonforchange;
	}

	public String getFos_reasonforchangename() {
		return fos_reasonforchangename;
	}

	public void setFos_reasonforchangename(String fos_reasonforchangename) {
		this.fos_reasonforchangename = fos_reasonforchangename;
	}

	public String getModifiedbyname() {
		return modifiedbyname;
	}

	public void setModifiedbyname(String modifiedbyname) {
		this.modifiedbyname = modifiedbyname;
	}

	public String getRegardingobjectid() {
		return regardingobjectid;
	}

	public void setRegardingobjectid(String regardingobjectid) {
		this.regardingobjectid = regardingobjectid;
	}

	public String getRegardingobjectidname() {
		return regardingobjectidname;
	}

	public void setRegardingobjectidname(String regardingobjectidname) {
		this.regardingobjectidname = regardingobjectidname;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public Long getVersionnumber() {
		return versionnumber;
	}

	public void setVersionnumber(Long versionnumber) {
		this.versionnumber = versionnumber;
	}

	public String getCreatedon() {
		return createdon;
	}

	public void setCreatedon(String createdon) {
		this.createdon = createdon;
	}

	public String getModifiedon() {
		return modifiedon;
	}

	public void setModifiedon(String modifiedon) {
		this.modifiedon = modifiedon;
	}

	public String getCreatedby() {
		return createdby;
	}

	public void setCreatedby(String createdby) {
		this.createdby = createdby;
	}

	public String getModifiedby() {
		return modifiedby;
	}

	public void setModifiedby(String modifiedby) {
		this.modifiedby = modifiedby;
	}

	public LocalDateTime getModifiedonSorting() {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss'Z'");
		return LocalDateTime.parse(modifiedon, formatter);
	}

}
