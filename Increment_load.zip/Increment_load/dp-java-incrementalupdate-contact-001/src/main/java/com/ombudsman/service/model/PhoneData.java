package com.ombudsman.service.model;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "stg_phone")
public class PhoneData {

	@Id
	private String activityid;
	private String description;
	private Boolean directioncode;
	private String fos_direction;
	private Boolean fos_isresponserequested;
	private String fos_offeroutcomeid;
	private Long fos_originator;
	private String fos_recipientrole;
	private String fos_responsetobereceivedby;
	private Long fos_visibleinportal;
	private String regardingobjectid;
	private Long statecode;
	private Long versionnumber;
	private String createdon;
	private String modifiedon;
	private String createdby;
	private String modifiedby;
	private String incrementaldataloadjobauditid;


	public String getIncrementaldataloadjobauditid() {
		return incrementaldataloadjobauditid;
	}


	public void setIncrementaldataloadjobauditid(String incrementaldataloadjobauditid) {
		this.incrementaldataloadjobauditid = incrementaldataloadjobauditid;
	}


	public String getActivityid() {
		return activityid;
	}


	public void setActivityid(String activityid) {
		this.activityid = activityid;
	}


	public String getDescription() {
		return description;
	}


	public void setDescription(String description) {
		this.description = description;
	}


	public Boolean getDirectioncode() {
		return directioncode;
	}


	public void setDirectioncode(Boolean directioncode) {
		this.directioncode = directioncode;
	}


	public String getFos_direction() {
		return fos_direction;
	}


	public void setFos_direction(String fos_direction) {
		this.fos_direction = fos_direction;
	}


	public Boolean getFos_isresponserequested() {
		return fos_isresponserequested;
	}


	public void setFos_isresponserequested(Boolean fos_isresponserequested) {
		this.fos_isresponserequested = fos_isresponserequested;
	}


	public String getFos_offeroutcomeid() {
		return fos_offeroutcomeid;
	}


	public void setFos_offeroutcomeid(String fos_offeroutcomeid) {
		this.fos_offeroutcomeid = fos_offeroutcomeid;
	}


	public Long getFos_originator() {
		return fos_originator;
	}


	public void setFos_originator(Long fos_originator) {
		this.fos_originator = fos_originator;
	}


	public String getFos_recipientrole() {
		return fos_recipientrole;
	}


	public void setFos_recipientrole(String fos_recipientrole) {
		this.fos_recipientrole = fos_recipientrole;
	}


	public String getFos_responsetobereceivedby() {
		return fos_responsetobereceivedby;
	}


	public void setFos_responsetobereceivedby(String fos_responsetobereceivedby) {
		this.fos_responsetobereceivedby = fos_responsetobereceivedby;
	}


	public Long getFos_visibleinportal() {
		return fos_visibleinportal;
	}


	public void setFos_visibleinportal(Long fos_visibleinportal) {
		this.fos_visibleinportal = fos_visibleinportal;
	}


	public String getRegardingobjectid() {
		return regardingobjectid;
	}


	public void setRegardingobjectid(String regardingobjectid) {
		this.regardingobjectid = regardingobjectid;
	}


	public Long getStatecode() {
		return statecode;
	}


	public void setStatecode(Long statecode) {
		this.statecode = statecode;
	}


	public Long getVersionnumber() {
		return versionnumber;
	}


	public void setVersionnumber(Long versionnumber) {
		this.versionnumber = versionnumber;
	}


	public String getCreatedon() {
		return createdon;
	}


	public void setCreatedon(String createdon) {
		this.createdon = createdon;
	}


	public String getModifiedon() {
		return modifiedon;
	}


	public void setModifiedon(String modifiedon) {
		this.modifiedon = modifiedon;
	}


	public String getCreatedby() {
		return createdby;
	}


	public void setCreatedby(String createdby) {
		this.createdby = createdby;
	}


	public String getModifiedby() {
		return modifiedby;
	}


	public void setModifiedby(String modifiedby) {
		this.modifiedby = modifiedby;
	}


	public LocalDateTime getModifiedonSorting() {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss'Z'");
		return LocalDateTime.parse(modifiedon, formatter);
	}

}
