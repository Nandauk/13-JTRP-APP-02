package com.ombudsman.service.serviceImpl;

import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ombudsman.service.common.Constantsconfig;
import com.ombudsman.service.model.ContactData;
import com.ombudsman.service.model.EmailData;
import com.ombudsman.service.model.LetterData;
import com.ombudsman.service.model.PhoneData;
import com.ombudsman.service.model.PortalData;
import com.ombudsman.service.model.TaskData;
import com.ombudsman.service.repo.ContactRepository;
import com.ombudsman.service.repo.EmailRepository;
import com.ombudsman.service.repo.LetterRepository;
import com.ombudsman.service.repo.PhoneRepository;
import com.ombudsman.service.repo.PortalRepository;
import com.ombudsman.service.repo.TaskRepository;

@Service
public class ContactSqlHelper {

	@Autowired
	EmailRepository emailRep;

	@Autowired
	TaskRepository taskRep;

	@Autowired
	PhoneRepository phoneRep;

	@Autowired
	PortalRepository portalRep;

	@Autowired
	LetterRepository letterRep;

	@Autowired
	Constantsconfig constant;

	@Autowired
	ContactRepository contactRep;

	Logger LOG = LogManager.getRootLogger();

	public void insertHelperemail(EmailData emaild, String Fetch_IncrementalDataLoadAuditId) {

		emailRep.InsertQuery(emaild.getActivityid(), emaild.getStatecode(), emaild.getActivitytypecode(),
				emaild.getAttachmentcount(), emaild.getDescription(), emaild.getDirectioncode(),
				emaild.getFos_isresponserequested(), emaild.getEmailsendername(), emaild.getFos_offeroutcomeid(),
				emaild.getFos_originator(), emaild.getFos_recipientrole(), emaild.getFos_responsetobereceivedby(),
				emaild.getFrom(), emaild.getCc(), emaild.getTo(), emaild.getSenton(), emaild.getSubject(),
				emaild.getTorecipients(), emaild.getRegardingobjectid(), emaild.getVersionnumber(),
				emaild.getCreatedon(), emaild.getModifiedon(), emaild.getCreatedby(), emaild.getModifiedby(),
				Fetch_IncrementalDataLoadAuditId);

	}

	public void insertHelpertask(TaskData taskd, String Fetch_IncrementalDataLoadAuditId) {
		taskRep.InsertQuery(taskd.getActivityid(), taskd.getFos_categorycode(), taskd.getFos_completedondate(),
				taskd.getFos_emailid(), taskd.getFos_letterid(), taskd.getFos_phonecallid(),
				taskd.getRegardingobjectid(), taskd.getStatecode(), taskd.getVersionnumber(), taskd.getCreatedon(),
				taskd.getModifiedon(), taskd.getCreatedby(), taskd.getModifiedby(),taskd.getScheduledend(),
				Fetch_IncrementalDataLoadAuditId);

	}

	public void insertHelperportal(PortalData portald, String Fetch_IncrementalDataLoadAuditId) {

		portalRep.InsertQuery(portald.getActivityid(), portald.getCreatedbyname(), portald.getFos_businessresponse(),
				portald.getFos_capacity(), portald.getFos_capacityname(), portald.getFos_category(),
				portald.getFos_dpuseremailaddress(), portald.getFos_dpuserfullname(), portald.getFos_otherreason(),
				portald.getFos_otherreasonforchange(), portald.getFos_reasonforchange(),
				portald.getFos_reasonforchangename(), portald.getModifiedbyname(), portald.getRegardingobjectid(),
				portald.getRegardingobjectidname(), portald.getSubject(), portald.getVersionnumber(),
				portald.getCreatedon(), portald.getModifiedon(), portald.getCreatedby(), portald.getModifiedby(),
				portald.getTo(), portald.getFrom(), Fetch_IncrementalDataLoadAuditId);

	}

	public void insertHelperphone(PhoneData phoned, String Fetch_IncrementalDataLoadAuditId) {

		phoneRep.InsertQuery(phoned.getActivityid(), phoned.getDescription(), phoned.getDirectioncode(),
				phoned.getFos_direction(), phoned.getFos_isresponserequested(), phoned.getFos_offeroutcomeid(),
				phoned.getFos_originator(), phoned.getFos_recipientrole(), phoned.getFos_responsetobereceivedby(),
				phoned.getFos_visibleinportal(), phoned.getRegardingobjectid(), phoned.getStatecode(),
				phoned.getVersionnumber(), phoned.getCreatedon(), phoned.getModifiedon(), phoned.getCreatedby(),
				phoned.getModifiedby(), Fetch_IncrementalDataLoadAuditId);

	}

	public void insertHelperletter(LetterData letterd, String Fetch_IncrementalDataLoadAuditId) {
		letterRep.InsertQuery(letterd.getActivityid(), letterd.getDirectioncode(), letterd.getFos_dispatcheddate(),
				letterd.getFos_isresponserequested(), letterd.getFos_mailclasscode(), letterd.getFos_offeroutcomeid(),
				letterd.getFos_originator(), letterd.getFos_recipientrole(), letterd.getFos_responsetobereceivedby(),
				letterd.getFos_visibleinportal(), letterd.getRegardingobjectid(), letterd.getStatecode(),
				letterd.getVersionnumber(), letterd.getCreatedon(), letterd.getModifiedon(), letterd.getCreatedby(),
				letterd.getModifiedby(),letterd.getFos_completedondate(),
				Fetch_IncrementalDataLoadAuditId);

	}

	private void insertcontact(ContactData contactd, String Fetch_IncrementalDataLoadAuditId) {

		contactRep.InsertQuery(contactd.getContactid(), contactd.getStatecode(), contactd.getFos_capacity(),
				contactd.getFos_contactdescriptionoption(), contactd.getFos_digitalportalinvitestatus(),
				contactd.getFos_isdigitalportaladmin(), contactd.getFos_parentorganisationcapacity(),
				contactd.getFos_phonerecordingconsent(), contactd.getFos_preferredmethodofcorrespondencecode(),
				contactd.getFos_surveyconsentcode(), contactd.getGendercode(), contactd.getPreferredcontactmethodcode(),
				contactd.getDonotemail(), contactd.getDonotphone(), contactd.getDonotpostalmail(),
				contactd.getParentcontactid(), contactd.getParentcustomerid(), contactd.getAddress1_city(),
				contactd.getAddress1_composite(), contactd.getAddress1_country(), contactd.getAddress1_county(),
				contactd.getAddress1_line1(), contactd.getAddress1_line2(), contactd.getAddress1_line3(),
				contactd.getAddress1_name(), contactd.getAddress1_postalcode(), contactd.getBirthdate(),
				contactd.getDescription(), contactd.getEmailaddress1(), contactd.getFirstname(),
				contactd.getFos_addressid(), contactd.getFos_fcaid(), contactd.getFos_needstring(),
				contactd.getFos_othertitle(), contactd.getFullname(), contactd.getJobtitle(), contactd.getLastname(),
				contactd.getMiddlename(), contactd.getMsa_managingpartneridname(), contactd.getSalutation(),
				contactd.getSuffix(), contactd.getTelephone1(), contactd.getTelephone2(), contactd.getVersionnumber(),
				contactd.getCreatedon(), contactd.getModifiedon(), contactd.getCreatedby(), contactd.getModifiedby(),
				Fetch_IncrementalDataLoadAuditId);

	}

	@Transactional
	public void insertForContact(ArrayList<ContactData> arrayListcontact, String Fetch_IncrementalDataLoadAuditId) {

		LOG.info(String.format("Total records for CONTACT entity for  Insertion are : %s ", arrayListcontact.size()));
		Instant startInsert = Instant.now();

		for (ContactData contactd : arrayListcontact) {

			if (contactd.getContactid() != null) {

				insertcontact(contactd, Fetch_IncrementalDataLoadAuditId);

			}

		}
		Instant finishInsert = Instant.now();

		long timeElapsedInsert = Duration.between(startInsert, finishInsert).toMillis();
		LOG.info(String.format("Time taken for %s for insert queries is : %s ms", constant.Entity_Contact,
				timeElapsedInsert));
	}

	@Transactional

	public void insertForTask(ArrayList<TaskData> FinalarrayListTaskData, String Fetch_IncrementalDataLoadAuditId) {

		LOG.info(String.format("Total records for %s entity for  Insertion are : %s ", constant.Task,
				FinalarrayListTaskData.size()));
		Instant startInsert = Instant.now();

		for (TaskData taskd : FinalarrayListTaskData) {

			if (taskd.getRegardingobjectid() != null) {

				insertHelpertask(taskd, Fetch_IncrementalDataLoadAuditId);

			}

		}
		Instant finishInsert = Instant.now();

		long timeElapsedInsert = Duration.between(startInsert, finishInsert).toMillis();
		LOG.info(String.format("Time taken for %s for insert queries is : %s ms", constant.Task, timeElapsedInsert));
	}

	@Transactional
	public void insertForPortal(ArrayList<PortalData> FinalarrayListPortalData,
			String Fetch_IncrementalDataLoadAuditId) {

		LOG.info(String.format("Total records for %s entity for  Insertion are : %s ", constant.Portal,
				FinalarrayListPortalData.size()));
		Instant startInsert = Instant.now();

		for (PortalData portald : FinalarrayListPortalData) {

			if (portald.getRegardingobjectid() != null) {

				insertHelperportal(portald, Fetch_IncrementalDataLoadAuditId);

			}

		}
		Instant finishInsert = Instant.now();

		long timeElapsedInsert = Duration.between(startInsert, finishInsert).toMillis();
		LOG.info(String.format("Time taken for %s for insert queries is : %s ms", constant.Portal, timeElapsedInsert));
	}

	@Transactional
	public void insertForEmail(ArrayList<EmailData> FinalarrayListEmailData, String Fetch_IncrementalDataLoadAuditId) {

		LOG.info(String.format("Total records for %s entity for  Insertion are : %s ", constant.Email,
				FinalarrayListEmailData.size()));
		Instant startInsert = Instant.now();

		for (EmailData emaild : FinalarrayListEmailData) {

			if (emaild.getRegardingobjectid() != null) {

				insertHelperemail(emaild, Fetch_IncrementalDataLoadAuditId);

			}

		}
		Instant finishInsert = Instant.now();

		long timeElapsedInsert = Duration.between(startInsert, finishInsert).toMillis();
		LOG.info(String.format("Time taken for %s for insert queries is : %s ms", constant.Email, timeElapsedInsert));
	}

	@Transactional

	public void insertForPhone(ArrayList<PhoneData> FinalarrayListPhoneData, String Fetch_IncrementalDataLoadAuditId) {

		LOG.info(String.format("Total records for %s entity for  Insertion are : %s ", constant.Phone,
				FinalarrayListPhoneData.size()));
		Instant startInsert = Instant.now();

		for (PhoneData phoned : FinalarrayListPhoneData) {

			if (phoned.getRegardingobjectid() != null) {

				insertHelperphone(phoned, Fetch_IncrementalDataLoadAuditId);

			}

		}
		Instant finishInsert = Instant.now();

		long timeElapsedInsert = Duration.between(startInsert, finishInsert).toMillis();
		LOG.info(String.format("Time taken for %s for insert queries is : %s ms", constant.Phone, timeElapsedInsert));
	}

	@Transactional
	public void insertForLetter(ArrayList<LetterData> finalarrayListLetterData,
			String fetch_IncrementalDataLoadAuditId) {

		LOG.info(String.format("Total records for %s entity for  Insertion are : %s ", constant.Letter,
				finalarrayListLetterData.size()));
		Instant startInsert = Instant.now();

		for (LetterData letterd : finalarrayListLetterData) {

			if (letterd.getRegardingobjectid() != null) {

				insertHelperletter(letterd, fetch_IncrementalDataLoadAuditId);

			}

		}
		Instant finishInsert = Instant.now();

		long timeElapsedInsert = Duration.between(startInsert, finishInsert).toMillis();
		LOG.info(String.format("Time taken for %s for insert queries is : %s ms", constant.Letter, timeElapsedInsert));

	}
}
