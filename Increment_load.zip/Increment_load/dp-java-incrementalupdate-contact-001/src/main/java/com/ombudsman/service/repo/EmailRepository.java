package com.ombudsman.service.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.ombudsman.service.model.EmailData;

	public interface EmailRepository extends JpaRepository<EmailData, String> {


		@Modifying
		@Transactional
		@Query(value = "INSERT INTO stg_email(activityid,statecode,activitytypecode,attachmentcount,description,directioncode,fos_isresponserequested,emailsendername,fos_offeroutcomeid,fos_originator,fos_recipientrole,fos_responsetobereceivedby,[from],cc,[to],"
				+ "senton,subject, torecipients, regardingobjectid,versionnumber,createdon,modifiedon,createdby,modifiedby,incrementaldataloadjobauditid) VALUES (CONVERT(uniqueidentifier,:activityid), :statecode, :activitytypecode, :attachmentcount, :description, :directioncode, :fos_isresponserequested, :emailsendername, CONVERT(uniqueidentifier,:fos_offeroutcomeid), :fos_originator,:fos_recipientrole,:fos_responsetobereceivedby,"
				+ "CONVERT(uniqueidentifier,:from),CONVERT(uniqueidentifier,:cc),CONVERT(uniqueidentifier,:to),"
				+ ":senton, :subject, :torecipients, CONVERT(uniqueidentifier,:regardingobjectid), :versionnumber, :createdon, :modifiedon, CONVERT(uniqueidentifier,:createdby), CONVERT(uniqueidentifier,:modifiedby),CONVERT(uniqueidentifier,:incrementaldataloadjobauditid))", nativeQuery = true)
		int InsertQuery(@Param("activityid") String activityid, @Param("statecode") Long statecode,
				@Param("activitytypecode") String activitytypecode, @Param("attachmentcount") Long attachmentcount,
				@Param("description") String description, @Param("directioncode") Boolean directioncode,
				@Param("fos_isresponserequested") Boolean fos_isresponserequested,
				@Param("emailsendername") String emailsendername, @Param("fos_offeroutcomeid") String fos_offeroutcomeid,
				@Param("fos_originator") Long fos_originator, @Param("fos_recipientrole") String fos_recipientrole,
				@Param("fos_responsetobereceivedby") String fos_responsetobereceivedby,
				@Param("from") String from,@Param("cc") String cc,@Param("to") String to,
				@Param("senton") String senton, @Param("subject") String subject,
				@Param("torecipients") String torecipients, @Param("regardingobjectid") String regardingobjectid,
				@Param("versionnumber") Long versionnumber, @Param("createdon") String createdon,
				@Param("modifiedon") String modifiedon, @Param("createdby") String createdby,
				@Param("modifiedby") String modifiedby,
				@Param("incrementaldataloadjobauditid") String incrementaldataloadjobauditid);


	}

