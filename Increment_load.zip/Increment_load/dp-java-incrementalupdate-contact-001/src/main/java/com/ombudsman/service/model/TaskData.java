package com.ombudsman.service.model;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "stg_task")
public class TaskData {

	@Id

	private String activityid; // unique identifier
	private Long fos_categorycode;
	private String fos_completedondate;
	private String fos_emailid;
	private String fos_letterid;
	private String fos_phonecallid;
	private String regardingobjectid;
	private Long statecode;
	private Long versionnumber;
	private String createdon;
	private String modifiedon;
	private String createdby;
	private String modifiedby;
	private String scheduledend;
	public String getScheduledend() {
		return scheduledend;
	}

	public void setScheduledend(String scheduledend) {
		this.scheduledend = scheduledend;
	}

	private String incrementaldataloadjobauditid;

	public String getIncrementaldataloadjobauditid() {
		return incrementaldataloadjobauditid;
	}

	public void setIncrementaldataloadjobauditid(String incrementaldataloadjobauditid) {
		this.incrementaldataloadjobauditid = incrementaldataloadjobauditid;
	}

	public String getActivityid() {
		return activityid;
	}

	public void setActivityid(String activityid) {
		this.activityid = activityid;
	}

	public Long getFos_categorycode() {
		return fos_categorycode;
	}

	public void setFos_categorycode(Long fos_categorycode) {
		this.fos_categorycode = fos_categorycode;
	}

	public String getFos_completedondate() {
		return fos_completedondate;
	}

	public void setFos_completedondate(String fos_completedondate) {
		this.fos_completedondate = fos_completedondate;
	}

	public String getFos_emailid() {
		return fos_emailid;
	}

	public void setFos_emailid(String fos_emailid) {
		this.fos_emailid = fos_emailid;
	}

	public String getFos_letterid() {
		return fos_letterid;
	}

	public void setFos_letterid(String fos_letterid) {
		this.fos_letterid = fos_letterid;
	}

	public String getFos_phonecallid() {
		return fos_phonecallid;
	}

	public void setFos_phonecallid(String fos_phonecallid) {
		this.fos_phonecallid = fos_phonecallid;
	}

	public String getRegardingobjectid() {
		return regardingobjectid;
	}

	public void setRegardingobjectid(String regardingobjectid) {
		this.regardingobjectid = regardingobjectid;
	}

	public Long getStatecode() {
		return statecode;
	}

	public void setStatecode(Long statecode) {
		this.statecode = statecode;
	}

	public Long getVersionnumber() {
		return versionnumber;
	}

	public void setVersionnumber(Long versionnumber) {
		this.versionnumber = versionnumber;
	}

	public String getCreatedon() {
		return createdon;
	}

	public void setCreatedon(String createdon) {
		this.createdon = createdon;
	}

	public String getModifiedon() {
		return modifiedon;
	}

	public void setModifiedon(String modifiedon) {
		this.modifiedon = modifiedon;
	}

	public String getCreatedby() {
		return createdby;
	}

	public void setCreatedby(String createdby) {
		this.createdby = createdby;
	}

	public String getModifiedby() {
		return modifiedby;
	}

	public void setModifiedby(String modifiedby) {
		this.modifiedby = modifiedby;
	}

	public LocalDateTime getModifiedonSorting() {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss'Z'");
		return LocalDateTime.parse(modifiedon, formatter);
	}
}
