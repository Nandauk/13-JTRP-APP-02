package com.ombudsman.service.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.ombudsman.service.model.LetterData;

public interface LetterRepository extends JpaRepository<LetterData, String> {


	@Modifying
	@Transactional
	@Query(value = "INSERT INTO stg_letter(activityid,directioncode,fos_dispatcheddate,fos_isresponserequested,fos_mailclasscode,fos_offeroutcomeid,fos_originator,fos_recipientrole,fos_responsetobereceivedby,fos_visibleinportal,regardingobjectid,statecode,versionnumber,createdon,modifiedon,createdby,modifiedby,fos_completedondate,incrementaldataloadjobauditid) VALUES (CONVERT(uniqueidentifier,:activityid),:directioncode, :fos_dispatcheddate, :fos_isresponserequested, :fos_mailclasscode, CONVERT(uniqueidentifier,:fos_offeroutcomeid), :fos_originator,:fos_recipientrole,:fos_responsetobereceivedby,:fos_visibleinportal,CONVERT(uniqueidentifier,:regardingobjectid),:statecode,:versionnumber, :createdon, :modifiedon, CONVERT(uniqueidentifier,:createdby), CONVERT(uniqueidentifier,:modifiedby),:fos_completedondate,CONVERT(uniqueidentifier,:incrementaldataloadjobauditid))", nativeQuery = true)
	int InsertQuery(@Param("activityid") String activityid, @Param("directioncode") Boolean directioncode,
			@Param("fos_dispatcheddate") String fos_dispatcheddate,
			@Param("fos_isresponserequested") Boolean fos_isresponserequested,
			@Param("fos_mailclasscode") Long fos_mailclasscode, @Param("fos_offeroutcomeid") String fos_offeroutcomeid,
			@Param("fos_originator") Long fos_originator, @Param("fos_recipientrole") String fos_recipientrole,
			@Param("fos_responsetobereceivedby") String fos_responsetobereceivedby,
			@Param("fos_visibleinportal") Long fos_visibleinportal,
			@Param("regardingobjectid") String regardingobjectid, @Param("statecode") Long statecode,
			@Param("versionnumber") Long versionnumber, @Param("createdon") String createdon,
			@Param("modifiedon") String modifiedon, @Param("createdby") String createdby,
			@Param("modifiedby") String modifiedby,@Param("fos_completedondate") String fos_completedondate,
			@Param("incrementaldataloadjobauditid") String incrementaldataloadjobauditid);


}
