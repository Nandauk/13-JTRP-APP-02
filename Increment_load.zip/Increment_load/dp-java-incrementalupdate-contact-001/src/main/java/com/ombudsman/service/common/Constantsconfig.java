package com.ombudsman.service.common;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public class Constantsconfig {
	
	@Value("${Entity_Contact}")
	public String Entity_Contact;
	
	@Value("${apim.host}")
	public String APIM_HOST;
	
	public String In_Progress = "In_Progress";
	public String Pending = "Pending";
	public String Completed = "Completed";
	public String Ready_To_Process = "Ready_To_Process";
	public String Terminated = "Terminated";
	public String Failed = "Failed";
	public String Error_log = "PHOENIX_001";
	public String Error_log_phx_sql = "PHOENIX_OR_SQL_001";
	public String DataSourceName = "SCH";
	public String DataSourceName_AZUNCFUNC = "DELETE_SUBMISSION";
	public String DataSourceName_DEL_RECON = "RCON_DELETE_JOB";
	
	public String Contact = "contact";
	public String Email = "email";
	public String Task = "task";
	public String Letter = "letter";
	public String Phone = "phonecall";
	public String Portal = "fos_portal";
	
	public String EmailPk = "activityid";
	public String TaskPk = "activityid";
	public String LetterPk = "activityid";
	public String PhonePk = "activityid";
	public String PortalPk = "activityid";
	public String ContactPk = "contactid";
	
	@Value("${Fetchxml_Record}")
	public int Fetchxml_Record;


}
