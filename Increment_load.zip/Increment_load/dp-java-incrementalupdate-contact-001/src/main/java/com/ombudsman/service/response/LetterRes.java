package com.ombudsman.service.response;

import java.util.List;

import com.ombudsman.service.model.LetterData;

public class LetterRes {
	private List<LetterData> letterData;

	public List<LetterData> getLetterData() {
		return letterData;
	}

	public void setLetterData(List<LetterData> letterData) {
		this.letterData = letterData;
	}

}
