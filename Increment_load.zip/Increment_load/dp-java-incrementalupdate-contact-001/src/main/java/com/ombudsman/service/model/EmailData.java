package com.ombudsman.service.model;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "stg_email")
public class EmailData {

	@Id
	private String activityid;
	private Long statecode;
	private String activitytypecode;
	private Long attachmentcount;
	private String cc;
	private String description;
	private Boolean directioncode;
	private Boolean fos_isresponserequested;
	private String emailsendername;
	private String fos_offeroutcomeid;
	private Long fos_originator;
	private String fos_recipientrole;
	private String fos_responsetobereceivedby;
	private String from;
	private String regardingobjectid;
	private String senton;
	public String getCc() {
		return cc;
	}

	public void setCc(String cc) {
		this.cc = cc;
	}

	public String getTo() {
		return to;
	}

	public void setTo(String to) {
		this.to = to;
	}

	private String subject;

	private String to;
	private String torecipients;
	private Long versionnumber;
	private String createdon;
	private String modifiedon;
	private String createdby;
	private String modifiedby;
	private String incrementaldataloadjobauditid;

	public String getIncrementaldataloadjobauditid() {
		return incrementaldataloadjobauditid;
	}

	public void setIncrementaldataloadjobauditid(String incrementaldataloadjobauditid) {
		this.incrementaldataloadjobauditid = incrementaldataloadjobauditid;
	}

	public String getActivityid() {
		return activityid;
	}

	public void setActivityid(String activityid) {
		this.activityid = activityid;
	}

	public Long getStatecode() {
		return statecode;
	}

	public void setStatecode(Long statecode) {
		this.statecode = statecode;
	}

	public String getActivitytypecode() {
		return activitytypecode;
	}

	public void setActivitytypecode(String activitytypecode) {
		this.activitytypecode = activitytypecode;
	}

	public Long getAttachmentcount() {
		return attachmentcount;
	}

	public void setAttachmentcount(Long attachmentcount) {
		this.attachmentcount = attachmentcount;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Boolean getDirectioncode() {
		return directioncode;
	}

	public void setDirectioncode(Boolean directioncode) {
		this.directioncode = directioncode;
	}

	public Boolean getFos_isresponserequested() {
		return fos_isresponserequested;
	}

	public void setFos_isresponserequested(Boolean fos_isresponserequested) {
		this.fos_isresponserequested = fos_isresponserequested;
	}

	public String getEmailsendername() {
		return emailsendername;
	}

	public void setEmailsendername(String emailsendername) {
		this.emailsendername = emailsendername;
	}

	public String getFos_offeroutcomeid() {
		return fos_offeroutcomeid;
	}

	public void setFos_offeroutcomeid(String fos_offeroutcomeid) {
		this.fos_offeroutcomeid = fos_offeroutcomeid;
	}

	public Long getFos_originator() {
		return fos_originator;
	}

	public void setFos_originator(Long fos_originator) {
		this.fos_originator = fos_originator;
	}

	public String getFos_recipientrole() {
		return fos_recipientrole;
	}

	public void setFos_recipientrole(String fos_recipientrole) {
		this.fos_recipientrole = fos_recipientrole;
	}

	public String getFos_responsetobereceivedby() {
		return fos_responsetobereceivedby;
	}

	public void setFos_responsetobereceivedby(String fos_responsetobereceivedby) {
		this.fos_responsetobereceivedby = fos_responsetobereceivedby;
	}

	public String getFrom() {
		return from;
	}

	public void setFrom(String from) {
		this.from = from;
	}

	public String getRegardingobjectid() {
		return regardingobjectid;
	}

	public void setRegardingobjectid(String regardingobjectid) {
		this.regardingobjectid = regardingobjectid;
	}

	public String getSenton() {
		return senton;
	}

	public void setSenton(String senton) {
		this.senton = senton;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getTorecipients() {
		return torecipients;
	}

	public void setTorecipients(String torecipients) {
		this.torecipients = torecipients;
	}

	public Long getVersionnumber() {
		return versionnumber;
	}

	public void setVersionnumber(Long versionnumber) {
		this.versionnumber = versionnumber;
	}

	public String getCreatedon() {
		return createdon;
	}

	public void setCreatedon(String createdon) {
		this.createdon = createdon;
	}

	public String getModifiedon() {
		return modifiedon;
	}

	public void setModifiedon(String modifiedon) {
		this.modifiedon = modifiedon;
	}

	public String getCreatedby() {
		return createdby;
	}

	public void setCreatedby(String createdby) {
		this.createdby = createdby;
	}

	public String getModifiedby() {
		return modifiedby;
	}

	public void setModifiedby(String modifiedby) {
		this.modifiedby = modifiedby;
	}

	public LocalDateTime getModifiedonSorting() {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss'Z'");
		return LocalDateTime.parse(modifiedon, formatter);
	}

}
