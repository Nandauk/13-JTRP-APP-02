package com.ombudsman.service.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.ombudsman.service.model.PhoneData;

public interface PhoneRepository extends JpaRepository<PhoneData, String> {

	@Modifying
	@Transactional
	@Query(value = "INSERT INTO stg_phone(activityid,description,directioncode,fos_direction,fos_isresponserequested,fos_offeroutcomeid,fos_originator,fos_recipientrole,fos_responsetobereceivedby,fos_visibleinportal,regardingobjectid,statecode,versionnumber,createdon,modifiedon,createdby,modifiedby,incrementaldataloadjobauditid) VALUES (CONVERT(uniqueidentifier,:activityid), :description,:directioncode, :fos_direction,:fos_isresponserequested, CONVERT(uniqueidentifier,:fos_offeroutcomeid), :fos_originator,:fos_recipientrole,:fos_responsetobereceivedby,:fos_visibleinportal,CONVERT(uniqueidentifier,:regardingobjectid),:statecode,:versionnumber, :createdon, :modifiedon, CONVERT(uniqueidentifier,:createdby), CONVERT(uniqueidentifier,:modifiedby),CONVERT(uniqueidentifier,:incrementaldataloadjobauditid))", nativeQuery = true)
	int InsertQuery(@Param("activityid") String activityid, @Param("description") String description,
			@Param("directioncode") Boolean directioncode, @Param("fos_direction") String fos_direction,
			@Param("fos_isresponserequested") Boolean fos_isresponserequested,
			@Param("fos_offeroutcomeid") String fos_offeroutcomeid, @Param("fos_originator") Long fos_originator,
			@Param("fos_recipientrole") String fos_recipientrole,
			@Param("fos_responsetobereceivedby") String fos_responsetobereceivedby,
			@Param("fos_visibleinportal") Long fos_visibleinportal,
			@Param("regardingobjectid") String regardingobjectid, @Param("statecode") Long statecode,
			@Param("versionnumber") Long versionnumber, @Param("createdon") String createdon,
			@Param("modifiedon") String modifiedon, @Param("createdby") String createdby,
			@Param("modifiedby") String modifiedby,@Param("incrementaldataloadjobauditid") String incrementaldataloadjobauditid);

}
