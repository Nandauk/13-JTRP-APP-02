package com.ombudsman.service.response;

import java.util.List;

import com.ombudsman.service.model.PhoneData;

public class PhoneRes {
	private List<PhoneData> phoneData;

	public List<PhoneData> getPhoneData() {
		return phoneData;
	}

	public void setPhoneData(List<PhoneData> phoneData) {
		this.phoneData = phoneData;
	}

}
