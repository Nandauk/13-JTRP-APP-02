package com.ombudsman.service.repo;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class PortalRepositoryTest {

    @Mock
    private PortalRepository repository;

    @Test
    public void testInsertQuery() {
        String activityId = "activity123";
        String createdByname = "John Doe";
        String fosBusinessResponse = "businessResponse";
        String fosCapacity = "capacity";
        String fosCapacityName = "capacityName";
        String fosCategory = "category";
        String fosDpUserEmailAddress = "user@example.com";
        String fosDpUserFullName = "User Fullname";
        String fosOtherReason = "otherReason";
        String fosOtherReasonForChange = "otherReasonForChange";
        String fosReasonForChange = "reasonForChange";
        String fosReasonForChangeName = "reasonForChangeName";
        String modifiedByName = "Jane Smith";
        String regardingObjectId = "regardingObjectId";
        String regardingObjectIdName = "regardingObjectIdName";
        String subject = "subject";
        Long versionNumber = 1L;
        String createdOn = "2025-01-24T10:58:00";
        String modifiedOn = "2025-01-24T10:58:00";
        String createdBy = "creator";
        String modifiedBy = "modifier";
        String to = "to@example.com";
        String from = "from@example.com";
        String incrementalDataLoadJobAuditId = "auditId123";

        // Mock the InsertQuery method
        when(repository.InsertQuery(activityId, createdByname, fosBusinessResponse, fosCapacity, fosCapacityName,
                fosCategory, fosDpUserEmailAddress, fosDpUserFullName, fosOtherReason, fosOtherReasonForChange,
                fosReasonForChange, fosReasonForChangeName, modifiedByName, regardingObjectId, regardingObjectIdName,
                subject, versionNumber, createdOn, modifiedOn, createdBy, modifiedBy, to, from,
                incrementalDataLoadJobAuditId)).thenReturn(1);

        // Call the method on the mock
        int result = repository.InsertQuery(activityId, createdByname, fosBusinessResponse, fosCapacity, fosCapacityName,
                fosCategory, fosDpUserEmailAddress, fosDpUserFullName, fosOtherReason, fosOtherReasonForChange,
                fosReasonForChange, fosReasonForChangeName, modifiedByName, regardingObjectId, regardingObjectIdName,
                subject, versionNumber, createdOn, modifiedOn, createdBy, modifiedBy, to, from,
                incrementalDataLoadJobAuditId);

        // Assert the result
        assertThat(result).isEqualTo(1);
    }
}