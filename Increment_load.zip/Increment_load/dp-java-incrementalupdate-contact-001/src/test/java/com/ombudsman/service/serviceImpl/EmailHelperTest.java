//package com.ombudsman.service.serviceImpl;
// 
//import static org.mockito.Mockito.*;
//import static org.junit.jupiter.api.Assertions.*;
// 
//import java.time.Instant;
//import java.time.ZoneId;
//import java.time.format.DateTimeFormatter;
//import java.util.ArrayList;
//import java.util.List;
// 
//import org.json.JSONException;
//import org.junit.jupiter.api.BeforeEach;
//import org.junit.jupiter.api.Test;
//import org.mockito.InjectMocks;
//import org.mockito.Mock;
//import org.mockito.MockitoAnnotations;
//import org.springframework.web.reactive.function.BodyInserters;
//import org.springframework.web.reactive.function.client.WebClient;
// 
//import com.google.gson.Gson;
//import com.ombudsman.service.common.Constantsconfig;
//import com.ombudsman.service.model.From;
//import com.ombudsman.service.model.MailjetResponseBody;
//import com.ombudsman.service.model.MailjetVariables;
//import com.ombudsman.service.model.Messages;
//import com.ombudsman.service.model.SendMailReq;
//import com.ombudsman.service.model.To;
// 
//import okhttp3.MediaType;
//import reactor.core.publisher.Mono;
// 
//public class EmailHelperTest {
// 
//    @Mock
//    private To to1;
// 
//    @Mock
//    private Constantsconfig constant;
// 
//    @InjectMocks
//    private EmailHelper emailHelper;
// 
//    @BeforeEach
//    public void setUp() {
//        MockitoAnnotations.openMocks(this);
//        emailHelper.TO_EMAIL = "test@example.com"; // replace with your test email
//        emailHelper.TEMPLATE_ID = 123; // replace with your test template ID
//    }
// 
//    @Test
//    public void testNotificationWebclient() throws JSONException {
//        // Given
//        String entity_Account = "entity_account";
//        String fetch_IncrementalDataLoadAuditId = "audit_id";
//        String dataSourceName = "data_source";
//        String error = "error_message";
//        String emailTime = "email_time";
// 
//        doNothing().when(to1).setEmail(anyString());
// 
//        // When
//        emailHelper.NotificationWebclient(entity_Account, fetch_IncrementalDataLoadAuditId,
//                dataSourceName, error, emailTime);
// 
//        // Then
//        verify(to1, times(1)).setEmail(anyString());
//        // Add more verification here if necessary to check other methods being called
//    }
// 
//    @Test
//    public void testSend() throws JSONException {
//        // Given
//        SendMailReq sendMailReq = new SendMailReq();
//        String jsonResponse = "{\"Messages\":[{\"Status\":\"success\"}]}";
// 
//        // Mock the WebClient and its response
//        WebClient webClientMock = mock(WebClient.class);
//        WebClient.RequestBodyUriSpec requestBodyUriSpecMock = mock(WebClient.RequestBodyUriSpec.class);
//        WebClient.RequestBodySpec requestBodySpecMock = mock(WebClient.RequestBodySpec.class);
//        WebClient.RequestHeadersSpec requestHeadersSpecMock = mock(WebClient.RequestHeadersSpec.class);
//        WebClient.ResponseSpec responseSpecMock = mock(WebClient.ResponseSpec.class);
// 
//        //when(WebClient.create()).thenReturn(webClientMock);
//        when(webClientMock.post()).thenReturn(requestBodyUriSpecMock);
//        when(requestBodyUriSpecMock.uri(anyString())).thenReturn(requestBodySpecMock);
//        when(requestBodySpecMock.body(any(BodyInserters.FormInserter.class))).thenReturn(requestHeadersSpecMock);
//        //when(requestHeadersSpecMock.accept(MediaType.APPLICATION_JSON)).thenReturn(requestHeadersSpecMock);
//        when(requestHeadersSpecMock.retrieve()).thenReturn(responseSpecMock);
//        when(responseSpecMock.bodyToMono(MailjetResponseBody.class)).thenReturn(Mono.just(new Gson().fromJson(jsonResponse, MailjetResponseBody.class)));
// 
//        // When
//        //String status = emailHelper.send(sendMailReq);
// 
//        // Then
//        //assertEquals("success", status);
//    }
//}