package com.ombudsman.service.exception;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PhoenixServiceExceptionTest {

    @Test
    public void testPhoenixServiceException() {
        String message = "Test message";
        String exceptionMessage = "PHOENIX_ERROR";

        PhoenixServiceException exception = new PhoenixServiceException(message, exceptionMessage);

        assertNotNull(exception);
        assertEquals(message, exception.getMessage());
        assertEquals(exceptionMessage, exception.getCode());
    }
}
