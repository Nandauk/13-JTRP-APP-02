package com.ombudsman.service.model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

public class PhoneDataTest {

    @Test
    public void testSelectedGetters() {
        PhoneData phoneData = new PhoneData();

        // Set values using setters
        phoneData.setActivityid("activity123");
        phoneData.setDescription("Call Description");
        phoneData.setDirectioncode(true);
        phoneData.setFos_direction("Outbound");
        phoneData.setFos_isresponserequested(false);
        phoneData.setFos_offeroutcomeid("offer123");
        phoneData.setFos_originator(1L);
        phoneData.setFos_recipientrole("Role");
        phoneData.setFos_responsetobereceivedby("2023-09-21");
        phoneData.setFos_visibleinportal(2L);
        phoneData.setRegardingobjectid("regarding123");
        phoneData.setStatecode(3L);
        phoneData.setVersionnumber(4L);
        phoneData.setCreatedon("2023-08-21T14:30:00Z");
        phoneData.setModifiedon("2023-08-21T15:00:00Z");
        phoneData.setCreatedby("John Doe");
        phoneData.setModifiedby("Jane Doe");
        phoneData.setIncrementaldataloadjobauditid("audit-12345");

        // Test getters
        assertEquals("activity123", phoneData.getActivityid());
        assertEquals("Call Description", phoneData.getDescription());
        assertEquals(true, phoneData.getDirectioncode());
        assertEquals("Outbound", phoneData.getFos_direction());
        assertEquals(false, phoneData.getFos_isresponserequested());
        assertEquals("offer123", phoneData.getFos_offeroutcomeid());
        assertEquals(1L, phoneData.getFos_originator());
        assertEquals("Role", phoneData.getFos_recipientrole());
        assertEquals("2023-09-21", phoneData.getFos_responsetobereceivedby());
        assertEquals(2L, phoneData.getFos_visibleinportal());
        assertEquals("regarding123", phoneData.getRegardingobjectid());
        assertEquals(3L, phoneData.getStatecode());
        assertEquals(4L, phoneData.getVersionnumber());
        assertEquals("2023-08-21T14:30:00Z", phoneData.getCreatedon());
        assertEquals("2023-08-21T15:00:00Z", phoneData.getModifiedon());
        assertEquals("John Doe", phoneData.getCreatedby());
        assertEquals("Jane Doe", phoneData.getModifiedby());
        assertEquals("audit-12345", phoneData.getIncrementaldataloadjobauditid());
    }
}
