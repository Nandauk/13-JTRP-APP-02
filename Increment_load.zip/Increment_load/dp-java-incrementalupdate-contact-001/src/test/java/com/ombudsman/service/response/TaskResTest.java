package com.ombudsman.service.response;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import com.ombudsman.service.model.TaskData;
import java.util.ArrayList;
import java.util.List;

public class TaskResTest {

    private TaskRes taskRes;

    @BeforeEach
    public void setUp() {
        taskRes = new TaskRes();
    }

    @Test
    public void testSetAndGetTaskData() {
        List<TaskData> taskDataList = new ArrayList<>();
        TaskData taskData = new TaskData();
        taskDataList.add(taskData);

        taskRes.setTaskData(taskDataList);
        
        assertNotNull(taskRes.getTaskData());
        assertEquals(taskDataList, taskRes.getTaskData());
    }
}
