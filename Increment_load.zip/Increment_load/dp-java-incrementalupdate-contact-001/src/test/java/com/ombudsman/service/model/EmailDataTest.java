package com.ombudsman.service.model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

public class EmailDataTest {

    @Test
    public void testSelectedGetters() {
        EmailData emailData = new EmailData();

        // Set values using setters
        emailData.setActivityid("activity123");
        emailData.setStatecode(1L);
        emailData.setActivitytypecode("email");
        emailData.setAttachmentcount(2L);
        emailData.setCc("cc@example.com");
        emailData.setDescription("Description of email");
        emailData.setDirectioncode(true);
        emailData.setFos_isresponserequested(false);
        emailData.setEmailsendername("Sender Name");
        emailData.setFos_offeroutcomeid("offer123");
        emailData.setFos_originator(3L);
        emailData.setFos_recipientrole("Role");
        emailData.setFos_responsetobereceivedby("2023-08-21");
        emailData.setFrom("from@example.com");
        emailData.setRegardingobjectid("regarding123");
        emailData.setSenton("2023-08-21T14:30:00Z");
        emailData.setSubject("Subject of email");
        emailData.setTo("to@example.com");
        emailData.setTorecipients("recipient@example.com");
        emailData.setVersionnumber(1L);
        emailData.setCreatedon("2023-08-21T14:30:00Z");
        emailData.setModifiedon("2023-08-21T15:00:00Z");
        emailData.setCreatedby("John Doe");
        emailData.setModifiedby("Jane Doe");
        emailData.setIncrementaldataloadjobauditid("audit-12345");

        // Test getters
        assertEquals("activity123", emailData.getActivityid());
        assertEquals(1L, emailData.getStatecode());
        assertEquals("email", emailData.getActivitytypecode());
        assertEquals(2L, emailData.getAttachmentcount());
        assertEquals("cc@example.com", emailData.getCc());
        assertEquals("Description of email", emailData.getDescription());
        assertEquals(true, emailData.getDirectioncode());
        assertEquals(false, emailData.getFos_isresponserequested());
        assertEquals("Sender Name", emailData.getEmailsendername());
        assertEquals("offer123", emailData.getFos_offeroutcomeid());
        assertEquals(3L, emailData.getFos_originator());
        assertEquals("Role", emailData.getFos_recipientrole());
        assertEquals("2023-08-21", emailData.getFos_responsetobereceivedby());
        assertEquals("from@example.com", emailData.getFrom());
        assertEquals("regarding123", emailData.getRegardingobjectid());
        assertEquals("2023-08-21T14:30:00Z", emailData.getSenton());
        assertEquals("Subject of email", emailData.getSubject());
        assertEquals("to@example.com", emailData.getTo());
        assertEquals("recipient@example.com", emailData.getTorecipients());
        assertEquals(1L, emailData.getVersionnumber());
        assertEquals("2023-08-21T14:30:00Z", emailData.getCreatedon());
        assertEquals("2023-08-21T15:00:00Z", emailData.getModifiedon());
        assertEquals("John Doe", emailData.getCreatedby());
        assertEquals("Jane Doe", emailData.getModifiedby());
        assertEquals("audit-12345", emailData.getIncrementaldataloadjobauditid());
    }
}
