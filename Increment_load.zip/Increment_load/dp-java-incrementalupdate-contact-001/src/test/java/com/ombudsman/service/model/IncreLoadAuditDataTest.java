package com.ombudsman.service.model;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class IncreLoadAuditDataTest {

    @Test
    public void testIncreLoadAuditData() {
        // Create a new instance of IncreLoadAuditData
        IncreLoadAuditData data = new IncreLoadAuditData();

        // Set values using setters
        data.setIncremental_data_load_audit_id("ID123");
        data.setJob_id(1);
        data.setJob_start_dateTime("2024-10-02T12:00:00");
        data.setTotal_number_of_records(100);
        data.setNumber_of_processed_record(90);
        data.setNumber_of_failed_record(10);
        data.setCurrent_job_status_id(1);
        data.setJob_close_datetime("2024-10-02T13:00:00");
        data.setNext_job_run_datetime("2024-10-03T12:00:00");
        data.setSource("source");
        data.setCreated_on("2024-10-01T12:00:00");
        data.setModified_on("2024-10-02T12:30:00");
        data.setCreated_by("creator");
        data.setModified_by("modifier");

        // Assert values using getters
        assertEquals("ID123", data.getIncremental_data_load_audit_id());
        assertEquals(1, data.getJob_id());
        assertEquals("2024-10-02T12:00:00", data.getJob_start_dateTime());
        assertEquals(100, data.getTotal_number_of_records());
        assertEquals(90, data.getNumber_of_processed_record());
        assertEquals(10, data.getNumber_of_failed_record());
        assertEquals(1, data.getCurrent_job_status_id());
        assertEquals("2024-10-02T13:00:00", data.getJob_close_datetime());
        assertEquals("2024-10-03T12:00:00", data.getNext_job_run_datetime());
        assertEquals("source", data.getSource());
        assertEquals("2024-10-01T12:00:00", data.getCreated_on());
        assertEquals("2024-10-02T12:30:00", data.getModified_on());
        assertEquals("creator", data.getCreated_by());
        assertEquals("modifier", data.getModified_by());
    }
}
