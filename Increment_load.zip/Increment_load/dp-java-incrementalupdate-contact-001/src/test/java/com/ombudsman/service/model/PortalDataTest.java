package com.ombudsman.service.model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

public class PortalDataTest {

    @Test
    public void testSelectedGetters() {
        PortalData portalData = new PortalData();

        // Set values using setters
        portalData.setActivityid("activity123");
        portalData.setCreatedbyname("John Doe");
        portalData.setFos_businessresponse("Response Text");
        portalData.setFos_capacity("Capacity123");
        portalData.setFos_capacityname("Capacity Name");
        portalData.setFos_category("Category123");
        portalData.setFos_dpuseremailaddress("user@example.com");
        portalData.setFos_dpuserfullname("User Fullname");
        portalData.setFos_otherreason("Other Reason");
        portalData.setFos_otherreasonforchange("Other Reason for Change");
        portalData.setFos_reasonforchange("Reason123");
        portalData.setFos_reasonforchangename("Reason Name");
        portalData.setFrom("from@example.com");
        portalData.setModifiedbyname("Jane Doe");
        portalData.setRegardingobjectid("regarding123");
        portalData.setRegardingobjectidname("Regarding Name");
        portalData.setSubject("Subject Text");
        portalData.setTo("to@example.com");

        // Test getters
        assertEquals("activity123", portalData.getActivityid());
        assertEquals("John Doe", portalData.getCreatedbyname());
        assertEquals("Response Text", portalData.getFos_businessresponse());
        assertEquals("Capacity123", portalData.getFos_capacity());
        assertEquals("Capacity Name", portalData.getFos_capacityname());
        assertEquals("Category123", portalData.getFos_category());
        assertEquals("user@example.com", portalData.getFos_dpuseremailaddress());
        assertEquals("User Fullname", portalData.getFos_dpuserfullname());
        assertEquals("Other Reason", portalData.getFos_otherreason());
        assertEquals("Other Reason for Change", portalData.getFos_otherreasonforchange());
        assertEquals("Reason123", portalData.getFos_reasonforchange());
        assertEquals("Reason Name", portalData.getFos_reasonforchangename());
        assertEquals("from@example.com", portalData.getFrom());
        assertEquals("Jane Doe", portalData.getModifiedbyname());
        assertEquals("regarding123", portalData.getRegardingobjectid());
        assertEquals("Regarding Name", portalData.getRegardingobjectidname());
        assertEquals("Subject Text", portalData.getSubject());
        assertEquals("to@example.com", portalData.getTo());
    }
}
