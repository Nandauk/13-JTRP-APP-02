package com.ombudsman.service.response;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import com.ombudsman.service.model.PhoneData;
import java.util.ArrayList;
import java.util.List;

public class PhoneResTest {

    private PhoneRes phoneRes;

    @BeforeEach
    public void setUp() {
        phoneRes = new PhoneRes();
    }

    @Test
    public void testSetAndGetPhoneData() {
        List<PhoneData> phoneDataList = new ArrayList<>();
        PhoneData phoneData = new PhoneData();
        phoneDataList.add(phoneData);

        phoneRes.setPhoneData(phoneDataList);
        
        assertNotNull(phoneRes.getPhoneData());
        assertEquals(phoneDataList, phoneRes.getPhoneData());
    }
}
