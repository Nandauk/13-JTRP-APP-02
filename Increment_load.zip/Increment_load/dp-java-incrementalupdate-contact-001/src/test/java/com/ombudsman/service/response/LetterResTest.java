package com.ombudsman.service.response;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import com.ombudsman.service.model.LetterData;
import java.util.ArrayList;
import java.util.List;

public class LetterResTest {

    private LetterRes letterRes;

    @BeforeEach
    public void setUp() {
        letterRes = new LetterRes();
    }

    @Test
    public void testSetAndGetLetterData() {
        List<LetterData> letterDataList = new ArrayList<>();
        LetterData letterData = new LetterData();
        letterDataList.add(letterData);

        letterRes.setLetterData(letterDataList);
        
        assertNotNull(letterRes.getLetterData());
        assertEquals(letterDataList, letterRes.getLetterData());
    }
}
