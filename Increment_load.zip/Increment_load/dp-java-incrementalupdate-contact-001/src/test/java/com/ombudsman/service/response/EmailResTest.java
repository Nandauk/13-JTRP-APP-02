package com.ombudsman.service.response;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import com.ombudsman.service.model.EmailData;
import java.util.ArrayList;
import java.util.List;

public class EmailResTest {

    private EmailRes emailRes;

    @BeforeEach
    public void setUp() {
        emailRes = new EmailRes();
    }

    @Test
    public void testSetAndGetEmailData() {
        List<EmailData> emailDataList = new ArrayList<>();
        EmailData emailData = new EmailData();
        emailDataList.add(emailData);

        emailRes.setEmailData(emailDataList);
        
        assertNotNull(emailRes.getEmailData());
        assertEquals(emailDataList, emailRes.getEmailData());
    }
}
