package com.ombudsman.service.model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

public class TaskDataTest {

    @Test
    public void testSelectedGetters() {
        TaskData taskData = new TaskData();

        // Set values using setters
        taskData.setActivityid("activity123");
        taskData.setFos_categorycode(1L);
        taskData.setFos_completedondate("2023-08-21T14:30:00Z");
        taskData.setFos_emailid("email123");
        taskData.setFos_letterid("letter123");
        taskData.setFos_phonecallid("phonecall123");
        taskData.setRegardingobjectid("regarding123");
        taskData.setStatecode(2L);
        taskData.setVersionnumber(3L);
        taskData.setCreatedon("2023-08-21T15:00:00Z");
        taskData.setModifiedon("2023-08-21T15:30:00Z");
        taskData.setCreatedby("John Doe");
        taskData.setModifiedby("Jane Doe");
        taskData.setIncrementaldataloadjobauditid("audit-12345");

        // Test getters
        assertEquals("activity123", taskData.getActivityid());
        assertEquals(1L, taskData.getFos_categorycode());
        assertEquals("2023-08-21T14:30:00Z", taskData.getFos_completedondate());
        assertEquals("email123", taskData.getFos_emailid());
        assertEquals("letter123", taskData.getFos_letterid());
        assertEquals("phonecall123", taskData.getFos_phonecallid());
        assertEquals("regarding123", taskData.getRegardingobjectid());
        assertEquals(2L, taskData.getStatecode());
        assertEquals(3L, taskData.getVersionnumber());
        assertEquals("2023-08-21T15:00:00Z", taskData.getCreatedon());
        assertEquals("2023-08-21T15:30:00Z", taskData.getModifiedon());
        assertEquals("John Doe", taskData.getCreatedby());
        assertEquals("Jane Doe", taskData.getModifiedby());
        assertEquals("audit-12345", taskData.getIncrementaldataloadjobauditid());
    }
}
