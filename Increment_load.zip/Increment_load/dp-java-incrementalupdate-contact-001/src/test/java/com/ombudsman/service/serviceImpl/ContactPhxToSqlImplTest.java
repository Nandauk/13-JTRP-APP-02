// package com.ombudsman.service.serviceImpl;

// import static org.junit.Assert.assertEquals;
// import static org.junit.jupiter.api.Assertions.assertThrows;
// import static org.mockito.ArgumentMatchers.any;
// import static org.mockito.ArgumentMatchers.anyInt;
// import static org.mockito.ArgumentMatchers.anyLong;
// import static org.mockito.ArgumentMatchers.anyString;
// import static org.mockito.Mockito.*;

// import java.io.IOException;
// import java.time.Instant;
// import java.util.ArrayList;
// import java.util.HashSet;
// import java.util.Set;

// import org.junit.jupiter.api.BeforeEach;
// import org.junit.jupiter.api.Test;
// import org.junit.jupiter.api.extension.ExtendWith;
// import org.mockito.ArgumentCaptor;
// import org.mockito.InjectMocks;
// import org.mockito.Mock;
// import org.mockito.Mockito;
// import org.mockito.MockitoAnnotations;
// import org.springframework.test.context.junit.jupiter.SpringExtension;
// import org.springframework.test.util.ReflectionTestUtils;

// import com.ombudsman.service.common.Constantsconfig;
// import com.ombudsman.service.common.PhoenixHelper;
// import com.ombudsman.service.model.ContactData;
// import com.ombudsman.service.repo.ContactRepository;
// import com.ombudsman.service.repo.IncreLoadAuditRepository;
// import com.ombudsman.service.repo.IncreLoadErrorRepository;
// import com.ombudsman.service.response.ContactRes;
// import com.ombudsman.service.response.EmailRes;

// @ExtendWith(SpringExtension.class)
// public class ContactPhxToSqlImplTest {

// 	@InjectMocks
// 	private ContactPhxToSqlImpl contactPhxToSqlImpl;

// 	@Mock
// 	private IncreLoadAuditRepository increLoadAuditRep;

// 	@Mock
// 	private IncreLoadErrorRepository increLoadErrorRep;

// 	@Mock
// 	private ContactRepository contactRep;

// 	@Mock
// 	private Constantsconfig constant;

// 	@Mock
// 	private PhoenixHelper phoenixHelper;

// 	@Mock
// 	private EmailHelper emailHelper;

// 	@Mock
// 	private ContactPhxHelper contactPhxHelper;

// 	@Mock
// 	private ContactSqlHelper contactSqlHelper;

// 	@BeforeEach
// 	public void setUp() throws Exception {
// 		MockitoAnnotations.openMocks(this);
// 		ReflectionTestUtils.setField(constant, "Entity_Contact", "Contact");
// 		ReflectionTestUtils.setField(constant, "DataSourceName", "DataSource");
// 		ReflectionTestUtils.setField(constant, "In_Progress", "In_Progress");
// 		ReflectionTestUtils.setField(constant, "Completed", "Completed");
// 		ReflectionTestUtils.setField(constant, "Ready_To_Process", "Ready_To_Process");
// 		ReflectionTestUtils.setField(constant, "Fetchxml_Record", 10);
// 	}

// 	@Test
// 	public void test_contactUpdatePnxtoSql_successfulExecution() throws IOException, InterruptedException {
// 		// Arrange
// 		when(increLoadAuditRep.getJobID(anyString())).thenReturn(1);
// 		when(increLoadAuditRep.getCurrentStatusIPId(anyString(), anyString())).thenReturn(2);

// 		when(increLoadAuditRep.getIncrementalDataLoadAuditId(anyString(), anyInt(), anyString(), anyString()))
// 				.thenReturn("incrementalAuditId");
// 		when(increLoadAuditRep.findLatestDatefromphx(anyString())).thenReturn("lastUpdatedDate");

// 		// Act
// 		contactPhxToSqlImpl.contactUpdatePnxtoSql();

// 		// Assert
// 		verify(increLoadAuditRep, times(1)).getJobID(anyString());
// 		verify(contactPhxHelper, times(1)).phxContact(anyString(), any(ContactRes.class), any(ArrayList.class),
// 				any(HashSet.class), anyString(), anyString(), anyInt());
// 	}

// 	@Test
// 	public void test_contactUpdatePnxtoSql_phxContactException() throws IOException, InterruptedException {
// 		// Arrange
// 		when(increLoadAuditRep.getJobID(anyString())).thenReturn(1);
// 		when(increLoadAuditRep.getCurrentStatusIPId(anyString(), anyString())).thenReturn(2);
// 		when(increLoadAuditRep.getIncrementalDataLoadAuditId(anyString(), anyInt(), anyString(), anyString()))
// 				.thenReturn("incrementalAuditId");
// 		when(increLoadAuditRep.findLatestDatefromphx(anyString())).thenReturn("lastUpdatedDate");
// 		when(contactPhxHelper.phxContact(anyString(), any(ContactRes.class), any(ArrayList.class), any(HashSet.class),
// 				anyString(), anyString(), anyInt())).thenThrow(new RuntimeException("Test Exception"));

// 		// Act & Assert
// 		assertThrows(RuntimeException.class, () -> contactPhxToSqlImpl.contactUpdatePnxtoSql());

// 		verify(increLoadAuditRep, times(1)).getJobID(anyString());
// 		verify(contactPhxHelper, times(1)).phxContact(anyString(), any(ContactRes.class), any(ArrayList.class),
// 				any(HashSet.class), anyString(), anyString(), anyInt());
// 	}

// 	@Test
// 	public void test_contactUpdatePnxtoSql_sqlInsertException() {
// 		// Arrange
// 		doThrow(new RuntimeException("Test Exception")).when(increLoadAuditRep).UpdateQuery(anyLong(), anyLong(),
// 				anyInt(), anyInt(), anyString(), anyString(), anyString());

// 		// Act & Assert
// 		RuntimeException thrown = assertThrows(RuntimeException.class, () -> {
// 			increLoadAuditRep.UpdateQuery(1L, 2L, 3, 4, "param1", "param2", "param3");
// 		});

// 		// Verify exception message
// 		assertEquals("Test Exception", thrown.getMessage());
// 	}

// 	@Test
// 	public void contactUpdatePnxtoSql_recon_successfulExecution() throws IOException, InterruptedException {
// 		// Arrange
// 		when(increLoadAuditRep.getJobID(Mockito.anyString())).thenReturn(1);
// 		when(increLoadAuditRep.getCurrentStatusIPId(Mockito.anyString(), Mockito.anyString())).thenReturn(2);
// 		when(increLoadAuditRep.getIncrementalDataLoadAuditId(Mockito.anyString(), Mockito.anyInt(), Mockito.anyString(),
// 				Mockito.anyString())).thenReturn("incrementalAuditId");
// 		when(increLoadAuditRep.findLatestDatefromphx(constant.Entity_Contact)).thenReturn("lastUpdatedDate");
// 		when(contactPhxHelper.phxContact("incrementalAuditId", new ContactRes(), new ArrayList<>(), new HashSet<>(),
// 				"startWebJob_formatted", "lastUpdatedDate", constant.Fetchxml_Record)).thenReturn("maxModifiedOn");

// 		// Act
// 		contactPhxToSqlImpl.contactUpdatePnxtoSql_recon("StartTime", "EndTime");

// 		// Assert
// 		verify(increLoadAuditRep).getJobID(constant.Entity_Contact);
// 		// Add more verifications based on your logic
// 	}

// 	@Test
// 	public void test_contactUpdatePnxtoSql_recon_phxContactException() throws IOException, InterruptedException {
// 		// Arrange
// 		when(increLoadAuditRep.getJobID(anyString())).thenReturn(1);
// 		when(increLoadAuditRep.getCurrentStatusIPId(anyString(), anyString())).thenReturn(2);
// 		when(increLoadAuditRep.getIncrementalDataLoadAuditId(anyString(), anyInt(), anyString(), anyString()))
// 				.thenReturn("incrementalAuditId");
// 		when(increLoadAuditRep.findLatestDatefromphx(anyString())).thenReturn("2023-10-01T00:00:00Z");

// 		// Create ContactData List
// 		ArrayList<ContactData> contactDataList = new ArrayList<>();

// 		// Mocking phxContact_recon to throw RuntimeException
// 		doThrow(new RuntimeException("Test Exception")).when(contactPhxHelper).phxContact_recon(anyString(),
// 				any(ContactRes.class), any(ArrayList.class), anyString(), anyString(), anyInt(), anyLong());

// 		// Act & Assert
// 		assertThrows(RuntimeException.class,
// 				() -> contactPhxToSqlImpl.contactUpdatePnxtoSql_recon("startTime", "endTime"));

// 		// Verify
// 		verify(increLoadAuditRep, times(1)).getJobID(anyString());
// 		verify(contactPhxHelper, times(1)).phxContact_recon(anyString(), any(ContactRes.class), any(ArrayList.class),
// 				anyString(), anyString(), anyInt(), anyLong());
// 	}

// 	@Test
// 	public void test_contactUpdatePnxtoSql_recon_sqlInsertException() throws IOException, InterruptedException {
// 		// Arrange
// 		when(increLoadAuditRep.getJobID(anyString())).thenReturn(1);
// 		when(increLoadAuditRep.getCurrentStatusIPId(anyString(), anyString())).thenReturn(2);
// 		when(increLoadAuditRep.getIncrementalDataLoadAuditId(anyString(), anyInt(), anyString(), anyString()))
// 				.thenReturn("incrementalAuditId");

// 		// Mocking phxContact_recon to ensure totalRecord is non-zero
// 		doAnswer(invocation -> {
// 			Set<String> map = new HashSet<>();
// 			map.add("dummy_record");
// 			return "maxModifiedOn";
// 		}).when(contactPhxHelper).phxContact_recon(anyString(), any(ContactRes.class), any(ArrayList.class),
// 				anyString(), anyString(), anyInt(), anyLong());

// 		// Simulate exception on method call that would update the database
// 		doThrow(new RuntimeException("Test Exception")).when(increLoadAuditRep).UpdateQuery(anyLong(), anyLong(),
// 				anyInt(), anyInt(), anyString(), anyString(), anyString());

// 		// Act & Assert
// 		assertThrows(RuntimeException.class,
// 				() -> contactPhxToSqlImpl.contactUpdatePnxtoSql_recon("startTime", "endTime"));

// 		// Verify
// 		verify(increLoadAuditRep, times(1)).getJobID(anyString());
// 		verify(contactPhxHelper, times(1)).phxContact_recon(anyString(), any(ContactRes.class), any(ArrayList.class),
// 				anyString(), anyString(), anyInt(), anyLong());
// 		verify(increLoadAuditRep, times(1)).UpdateQuery(anyLong(), anyLong(), anyInt(), anyInt(), anyString(),
// 				anyString(), anyString());
// 	}

// }