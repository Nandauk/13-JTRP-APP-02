package com.ombudsman.service.response;

import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.Test;

public class CurrentJobStatusTest {

    @Test
    public void testGetStatus() {
        assertEquals("Pending", CurrentJobStatus.Pending.getStatus());
        assertEquals("In_Progress", CurrentJobStatus.In_Progress.getStatus());
        assertEquals("Completed", CurrentJobStatus.Completed.getStatus());
        assertEquals("Partially_Completed", CurrentJobStatus.Partially_Completed.getStatus());
        assertEquals("Failed", CurrentJobStatus.Failed.getStatus());
        assertEquals("Terminated", CurrentJobStatus.Terminated.getStatus());
    }

    @Test
    public void testGetValue() {
        assertEquals(1, CurrentJobStatus.Pending.getValue());
        assertEquals(2, CurrentJobStatus.In_Progress.getValue());
        assertEquals(3, CurrentJobStatus.Completed.getValue());
        assertEquals(4, CurrentJobStatus.Partially_Completed.getValue());
        assertEquals(5, CurrentJobStatus.Failed.getValue());
        assertEquals(6, CurrentJobStatus.Terminated.getValue());
    }
}
