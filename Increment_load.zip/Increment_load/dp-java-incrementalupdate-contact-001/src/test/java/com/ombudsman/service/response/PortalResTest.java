package com.ombudsman.service.response;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import com.ombudsman.service.model.PortalData;
import java.util.ArrayList;
import java.util.List;

public class PortalResTest {

    private PortalRes portalRes;

    @BeforeEach
    public void setUp() {
        portalRes = new PortalRes();
    }

    @Test
    public void testSetAndGetPortalData() {
        List<PortalData> portalDataList = new ArrayList<>();
        PortalData portalData = new PortalData();
        portalDataList.add(portalData);

        portalRes.setPortalData(portalDataList);
        
        assertNotNull(portalRes.getPortalData());
        assertEquals(portalDataList, portalRes.getPortalData());
    }
}
