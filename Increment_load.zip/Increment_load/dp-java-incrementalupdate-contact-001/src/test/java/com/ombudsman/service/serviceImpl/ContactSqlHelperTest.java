package com.ombudsman.service.serviceImpl;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.slf4j.Logger;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.ombudsman.service.common.Constantsconfig;
import com.ombudsman.service.model.ContactData;
import com.ombudsman.service.model.EmailData;
import com.ombudsman.service.model.LetterData;
import com.ombudsman.service.model.PhoneData;
import com.ombudsman.service.model.PortalData;
import com.ombudsman.service.model.TaskData;
import com.ombudsman.service.repo.ContactRepository;
import com.ombudsman.service.repo.EmailRepository;
import com.ombudsman.service.repo.LetterRepository;
import com.ombudsman.service.repo.PhoneRepository;
import com.ombudsman.service.repo.PortalRepository;
import com.ombudsman.service.repo.TaskRepository;

@ExtendWith(SpringExtension.class)
public class ContactSqlHelperTest {

	@InjectMocks
	ContactSqlHelper contactSqlHelper;
	
	@Mock
	EmailRepository emailRep;

	@Mock
	TaskRepository taskRep;

	@Mock
	PhoneRepository phoneRep;

	@Mock
	PortalRepository portalRep;

	@Mock
	LetterRepository letterRep;

	@Mock
	Constantsconfig constant;

	@Mock
	ContactRepository contactRep;
	
	@Mock
    private Logger LOG;
	
	
    @Test
    public void testInsertHelperEmail() {
        EmailData emailData = mock(EmailData.class);
        String auditId = "testAuditId";
        contactSqlHelper.insertHelperemail(emailData, auditId);
        verify(emailRep, times(1)).InsertQuery(
            emailData.getActivityid(),
            emailData.getStatecode(),
            emailData.getActivitytypecode(),
            emailData.getAttachmentcount(),
            emailData.getDescription(),
            emailData.getDirectioncode(),
            emailData.getFos_isresponserequested(),
            emailData.getEmailsendername(),
            emailData.getFos_offeroutcomeid(),
            emailData.getFos_originator(),
            emailData.getFos_recipientrole(),
            emailData.getFos_responsetobereceivedby(),
            emailData.getFrom(),
            emailData.getCc(),
            emailData.getTo(),
            emailData.getSenton(),
            emailData.getSubject(),
            emailData.getTorecipients(),
            emailData.getRegardingobjectid(),
            emailData.getVersionnumber(),
            emailData.getCreatedon(),
            emailData.getModifiedon(),
            emailData.getCreatedby(),
            emailData.getModifiedby(),
            auditId
        );
    }

    @Test
    public void testInsertHelperTask() {
        TaskData taskData = mock(TaskData.class);
        String auditId = "testAuditId";
        contactSqlHelper.insertHelpertask(taskData, auditId);
        verify(taskRep, times(1)).InsertQuery(
            taskData.getActivityid(),
            taskData.getFos_categorycode(),
            taskData.getFos_completedondate(),
            taskData.getFos_emailid(),
            taskData.getFos_letterid(),
            taskData.getFos_phonecallid(),
            taskData.getRegardingobjectid(),
            taskData.getStatecode(),
            taskData.getVersionnumber(),
            taskData.getCreatedon(),
            taskData.getModifiedon(),
            taskData.getCreatedby(),
            taskData.getModifiedby(),
            taskData.getScheduledend(),
            auditId
        );
    }

    @Test
    public void testInsertHelperPortal() {
        PortalData portalData = mock(PortalData.class);
        String auditId = "testAuditId";
        contactSqlHelper.insertHelperportal(portalData, auditId);
        verify(portalRep, times(1)).InsertQuery(
            portalData.getActivityid(),
            portalData.getCreatedbyname(),
            portalData.getFos_businessresponse(),
            portalData.getFos_capacity(),
            portalData.getFos_capacityname(),
            portalData.getFos_category(),
            portalData.getFos_dpuseremailaddress(),
            portalData.getFos_dpuserfullname(),
            portalData.getFos_otherreason(),
            portalData.getFos_otherreasonforchange(),
            portalData.getFos_reasonforchange(),
            portalData.getFos_reasonforchangename(),
            portalData.getModifiedbyname(),
            portalData.getRegardingobjectid(),
            portalData.getRegardingobjectidname(),
            portalData.getSubject(),
            portalData.getVersionnumber(),
            portalData.getCreatedon(),
            portalData.getModifiedon(),
            portalData.getCreatedby(),
            portalData.getModifiedby(),
            portalData.getTo(),
            portalData.getFrom(),
            auditId
        );
    }

    @Test
    public void testInsertHelperPhone() {
        PhoneData phoneData = mock(PhoneData.class);
        String auditId = "testAuditId";
        contactSqlHelper.insertHelperphone(phoneData, auditId);
        verify(phoneRep, times(1)).InsertQuery(
            phoneData.getActivityid(),
            phoneData.getDescription(),
            phoneData.getDirectioncode(),
            phoneData.getFos_direction(),
            phoneData.getFos_isresponserequested(),
            phoneData.getFos_offeroutcomeid(),
            phoneData.getFos_originator(),
            phoneData.getFos_recipientrole(),
            phoneData.getFos_responsetobereceivedby(),
            phoneData.getFos_visibleinportal(),
            phoneData.getRegardingobjectid(),
            phoneData.getStatecode(),
            phoneData.getVersionnumber(),
            phoneData.getCreatedon(),
            phoneData.getModifiedon(),
            phoneData.getCreatedby(),
            phoneData.getModifiedby(),
            auditId
        );
    }

    @Test
    public void testInsertHelperLetter() {
        LetterData letterData = mock(LetterData.class);
        String auditId = "testAuditId";
        contactSqlHelper.insertHelperletter(letterData, auditId);
        verify(letterRep, times(1)).InsertQuery(
            letterData.getActivityid(),
            letterData.getDirectioncode(),
            letterData.getFos_dispatcheddate(),
            letterData.getFos_isresponserequested(),
            letterData.getFos_mailclasscode(),
            letterData.getFos_offeroutcomeid(),
            letterData.getFos_originator(),
            letterData.getFos_recipientrole(),
            letterData.getFos_responsetobereceivedby(),
            letterData.getFos_visibleinportal(),
            letterData.getRegardingobjectid(),
            letterData.getStatecode(),
            letterData.getVersionnumber(),
            letterData.getCreatedon(),
            letterData.getModifiedon(),
            letterData.getCreatedby(),
            letterData.getModifiedby(),
            letterData.getFos_completedondate(),
            auditId
        );
    }

    @Test
    public void testInsertContact() throws IllegalAccessException, IllegalArgumentException, InvocationTargetException, NoSuchMethodException, SecurityException {
        ContactData contactData = mock(ContactData.class);
        String auditId = "testAuditId";
        // Call private method using reflection
        Method method = ContactSqlHelper.class.getDeclaredMethod("insertcontact", ContactData.class, String.class);
        method.setAccessible(true);
        method.invoke(contactSqlHelper, contactData, auditId);
        verify(contactRep, times(1)).InsertQuery(
            contactData.getContactid(),
            contactData.getStatecode(),
            contactData.getFos_capacity(),
            contactData.getFos_contactdescriptionoption(),
            contactData.getFos_digitalportalinvitestatus(),
            contactData.getFos_isdigitalportaladmin(),
            contactData.getFos_parentorganisationcapacity(),
            contactData.getFos_phonerecordingconsent(),
            contactData.getFos_preferredmethodofcorrespondencecode(),
            contactData.getFos_surveyconsentcode(),
            contactData.getGendercode(),
            contactData.getPreferredcontactmethodcode(),
            contactData.getDonotemail(),
            contactData.getDonotphone(),
            contactData.getDonotpostalmail(),
            contactData.getParentcontactid(),
            contactData.getParentcustomerid(),
            contactData.getAddress1_city(),
            contactData.getAddress1_composite(),
            contactData.getAddress1_country(),
            contactData.getAddress1_county(),
            contactData.getAddress1_line1(),
            contactData.getAddress1_line2(),
            contactData.getAddress1_line3(),
            contactData.getAddress1_name(),
            contactData.getAddress1_postalcode(),
            contactData.getBirthdate(),
            contactData.getDescription(),
            contactData.getEmailaddress1(),
            contactData.getFirstname(),
            contactData.getFos_addressid(),
            contactData.getFos_fcaid(),
            contactData.getFos_needstring(),
            contactData.getFos_othertitle(),
            contactData.getFullname(),
            contactData.getJobtitle(),
            contactData.getLastname(),
            contactData.getMiddlename(),
            contactData.getMsa_managingpartneridname(),
            contactData.getSalutation(),
            contactData.getSuffix(),
            contactData.getTelephone1(),
            contactData.getTelephone1(),
            contactData.getVersionnumber(),
            contactData.getCreatedon(),
            contactData.getModifiedon(),
            contactData.getCreatedby(),
            contactData.getModifiedby(),
            auditId
        );
    }
    
    @Test
    public void insertForContact_Test() {

    	ContactData data = new ContactData();
    	data.setCreatedby("mock");
    	ArrayList<ContactData> arrayListcontact = new ArrayList<>() ;
    	arrayListcontact.add(data);
    	String Fetch_IncrementalDataLoadAuditId = "AuditID";

    	contactSqlHelper.insertForContact(arrayListcontact,Fetch_IncrementalDataLoadAuditId);
    	
    	assertEquals(1, arrayListcontact.size());
    			
	}
    
    @Test
    public void insertForTask_Test() {

    	 ArrayList<TaskData> finalarrayListTaskData = new ArrayList<>();
         TaskData taskData = new TaskData();
         taskData.setRegardingobjectid("123");
         finalarrayListTaskData.add(taskData);

         String fetch_IncrementalDataLoadAuditId = "456";

         contactSqlHelper.insertForTask(finalarrayListTaskData, fetch_IncrementalDataLoadAuditId);

         assertEquals(1, finalarrayListTaskData.size());

	}
    
    @Test
    public void insertForPortal_Test() {

    	 ArrayList<PortalData> FinalarrayListPortalData = new ArrayList<>();
    	 PortalData portalData = new PortalData();
    	 portalData.setRegardingobjectid("123");
    	 FinalarrayListPortalData.add(portalData);

         String fetch_IncrementalDataLoadAuditId = "456";

         contactSqlHelper.insertForPortal(FinalarrayListPortalData, fetch_IncrementalDataLoadAuditId);

         assertEquals(1, FinalarrayListPortalData.size());

	}
    
    @Test
    public void insertForEmail_Test() {

    	 ArrayList<EmailData> FinalarrayListEmailData = new ArrayList<>();
    	 EmailData taskData = new EmailData();
         taskData.setRegardingobjectid("123");
         FinalarrayListEmailData.add(taskData);

         String fetch_IncrementalDataLoadAuditId = "456";

         contactSqlHelper.insertForEmail(FinalarrayListEmailData, fetch_IncrementalDataLoadAuditId);

         assertEquals(1, FinalarrayListEmailData.size());

	}
    
    @Test
    public void insertForPhone_Test() {

    	 ArrayList<PhoneData> FinalarrayListPhoneData = new ArrayList<>();
    	 PhoneData taskData = new PhoneData();
         taskData.setRegardingobjectid("123");
         FinalarrayListPhoneData.add(taskData);

         String fetch_IncrementalDataLoadAuditId = "456";

         contactSqlHelper.insertForPhone(FinalarrayListPhoneData, fetch_IncrementalDataLoadAuditId);

         assertEquals(1, FinalarrayListPhoneData.size());

	}
    
    @Test
    public void insertForLetter_Test() {

    	 ArrayList<LetterData> finalarrayListLetterData = new ArrayList<>();
    	 LetterData taskData = new LetterData();
         taskData.setRegardingobjectid("123");
         finalarrayListLetterData.add(taskData);

         String fetch_IncrementalDataLoadAuditId = "456";

         contactSqlHelper.insertForLetter(finalarrayListLetterData, fetch_IncrementalDataLoadAuditId);

         assertEquals(1, finalarrayListLetterData.size());

	}

    
}
