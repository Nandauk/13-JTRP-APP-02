package com.ombudsman.service.services;

import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.doThrow;

import java.io.IOException;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

public class ContactPhxToSqlServiceTest {

    @Mock
    private ContactPhxToSqlService contactPhxToSqlService;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testContactUpdatePnxtoSql() throws IOException, InterruptedException {
        contactPhxToSqlService.contactUpdatePnxtoSql();
        verify(contactPhxToSqlService, times(1)).contactUpdatePnxtoSql();
    }

    @Test
    public void testContactUpdatePnxtoSql_recon() throws IOException, InterruptedException {
        String startTime = "2021-01-01T00:00:00";
        String endTime = "2021-01-01T23:59:59";
        contactPhxToSqlService.contactUpdatePnxtoSql_recon(startTime, endTime);
        verify(contactPhxToSqlService, times(1)).contactUpdatePnxtoSql_recon(startTime, endTime);
    }

    @Test
    public void testContactUpdatePnxtoSql_throwsIOException() throws IOException, InterruptedException {
        doThrow(new IOException()).when(contactPhxToSqlService).contactUpdatePnxtoSql();
        try {
            contactPhxToSqlService.contactUpdatePnxtoSql();
        } catch (IOException e) {
            // expected exception
        }
        verify(contactPhxToSqlService, times(1)).contactUpdatePnxtoSql();
    }

    @Test
    public void testContactUpdatePnxtoSql_recon_throwsIOException() throws IOException, InterruptedException {
        String startTime = "2021-01-01T00:00:00";
        String endTime = "2021-01-01T23:59:59";
        doThrow(new IOException()).when(contactPhxToSqlService).contactUpdatePnxtoSql_recon(startTime, endTime);
        try {
            contactPhxToSqlService.contactUpdatePnxtoSql_recon(startTime, endTime);
        } catch (IOException e) {
            // expected exception
        }
        verify(contactPhxToSqlService, times(1)).contactUpdatePnxtoSql_recon(startTime, endTime);
    }

    @Test
    public void testContactUpdatePnxtoSql_throwsInterruptedException() throws IOException, InterruptedException {
        doThrow(new InterruptedException()).when(contactPhxToSqlService).contactUpdatePnxtoSql();
        try {
            contactPhxToSqlService.contactUpdatePnxtoSql();
        } catch (InterruptedException e) {
            // expected exception
        }
        verify(contactPhxToSqlService, times(1)).contactUpdatePnxtoSql();
    }

    @Test
    public void testContactUpdatePnxtoSql_recon_throwsInterruptedException() throws IOException, InterruptedException {
        String startTime = "2021-01-01T00:00:00";
        String endTime = "2021-01-01T23:59:59";
        doThrow(new InterruptedException()).when(contactPhxToSqlService).contactUpdatePnxtoSql_recon(startTime, endTime);
        try {
            contactPhxToSqlService.contactUpdatePnxtoSql_recon(startTime, endTime);
        } catch (InterruptedException e) {
            // expected exception
        }
        verify(contactPhxToSqlService, times(1)).contactUpdatePnxtoSql_recon(startTime, endTime);
    }
}
