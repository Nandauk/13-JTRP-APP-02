package com.ombudsman.service.exception;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ServiceExceptionsTest {

    @Test
    public void testServiceExceptions() {
        String message = "Test message";
        String code = "TEST_CODE";

        ServiceExceptions exception = new ServiceExceptions(message, code);

        assertNotNull(exception);
        assertEquals(message, exception.getMessage());
        assertEquals(code, exception.getCode());
    }
}
