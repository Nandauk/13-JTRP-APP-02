package com.ombudsman.service.response;

import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class GenericResponseTest {

    private GenericResponse genericResponse;

    @BeforeEach
    public void setUp() {
        genericResponse = new GenericResponse();
    }

    @Test
    public void testSetAndGetStatus() {
        String status = "Success";
        genericResponse.setStatus(status);
        assertEquals(status, genericResponse.getStatus());
    }

    @Test
    public void testSetAndGetMessage() {
        String message = "Operation completed successfully";
        genericResponse.setMessage(message);
        assertEquals(message, genericResponse.getMessage());
    }
}
