package com.ombudsman.service.model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

public class LetterDataTest {

    @Test
    public void testSelectedGetters() {
        LetterData letterData = new LetterData();

        // Set values using setters
        letterData.setActivityid("activity123");
        letterData.setDirectioncode(true);
        letterData.setFos_dispatcheddate("2023-08-21");
        letterData.setFos_isresponserequested(false);
        letterData.setFos_mailclasscode(1L);
        letterData.setFos_offeroutcomeid("offer123");
        letterData.setFos_originator(2L);
        letterData.setFos_recipientrole("recipientRole");
        letterData.setFos_responsetobereceivedby("2023-09-21");
        letterData.setFos_visibleinportal(1L);
        letterData.setRegardingobjectid("regarding456");
        letterData.setStatecode(1L);
        letterData.setVersionnumber(1L);
        letterData.setCreatedon("2023-08-21T14:30:00Z");
        letterData.setModifiedon("2023-08-21T15:00:00Z");
        letterData.setCreatedby("John Doe");
        letterData.setModifiedby("Jane Doe");
        letterData.setIncrementaldataloadjobauditid("audit-12345");

        // Test getters
        assertEquals("activity123", letterData.getActivityid());
        assertEquals(true, letterData.getDirectioncode());
        assertEquals("2023-08-21", letterData.getFos_dispatcheddate());
        assertEquals(false, letterData.getFos_isresponserequested());
        assertEquals(1L, letterData.getFos_mailclasscode());
        assertEquals("offer123", letterData.getFos_offeroutcomeid());
        assertEquals(2L, letterData.getFos_originator());
        assertEquals("recipientRole", letterData.getFos_recipientrole());
        assertEquals("2023-09-21", letterData.getFos_responsetobereceivedby());
        assertEquals(1L, letterData.getFos_visibleinportal());
        assertEquals("regarding456", letterData.getRegardingobjectid());
        assertEquals(1L, letterData.getStatecode());
        assertEquals(1L, letterData.getVersionnumber());
        assertEquals("2023-08-21T14:30:00Z", letterData.getCreatedon());
        assertEquals("2023-08-21T15:00:00Z", letterData.getModifiedon());
        assertEquals("John Doe", letterData.getCreatedby());
        assertEquals("Jane Doe", letterData.getModifiedby());
        assertEquals("audit-12345", letterData.getIncrementaldataloadjobauditid());
    }
}
