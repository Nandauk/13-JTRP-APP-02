package com.ombudsman.service.response;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import com.ombudsman.service.model.ContactData;
import java.util.ArrayList;
import java.util.List;

public class ContactResTest {

    private ContactRes contactRes;

    @BeforeEach
    public void setUp() {
        contactRes = new ContactRes();
    }

    @Test
    public void testSetAndGetContactData() {
        List<ContactData> contactDataList = new ArrayList<>();
        ContactData contactData = new ContactData();
        contactDataList.add(contactData);

        contactRes.setContactData(contactDataList);
        
        assertNotNull(contactRes.getContactData());
        assertEquals(contactDataList, contactRes.getContactData());
    }
}
