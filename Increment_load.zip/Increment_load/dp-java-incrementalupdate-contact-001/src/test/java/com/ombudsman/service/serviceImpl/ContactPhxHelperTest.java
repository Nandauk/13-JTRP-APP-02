//package com.ombudsman.service.serviceImpl;
//
//import static org.junit.Assert.assertFalse;
//import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;
//import static org.junit.jupiter.api.Assertions.assertEquals;
//import static org.junit.jupiter.api.Assertions.assertNotNull;
//import static org.junit.jupiter.api.Assertions.assertTrue;
//import static org.mockito.ArgumentMatchers.anyString;
//import static org.mockito.ArgumentMatchers.eq;
//import static org.mockito.Mockito.times;
//import static org.mockito.Mockito.verify;
//import static org.mockito.Mockito.when;
//
//import java.lang.reflect.Method;
//import java.time.OffsetDateTime;
//import java.util.ArrayList;
//import java.util.HashSet;
//import java.util.Set;
//
//import org.json.JSONArray;
//import org.json.JSONObject;
//import org.junit.jupiter.api.BeforeEach;
//import org.junit.jupiter.api.DisplayName;
//import org.junit.jupiter.api.Test;
//import org.junit.jupiter.api.extension.ExtendWith;
//import org.mockito.InjectMocks;
//import org.mockito.Mock;
//import org.mockito.Mockito;
//import org.mockito.MockitoAnnotations;
//import org.mockito.Spy;
//import org.springframework.test.context.junit.jupiter.SpringExtension;
//import org.springframework.test.util.ReflectionTestUtils;
//
//import com.fasterxml.jackson.core.JsonProcessingException;
//import com.fasterxml.jackson.databind.ObjectMapper;
//import com.ombudsman.service.common.Constantsconfig;
//import com.ombudsman.service.common.PhoenixHelper;
//import com.ombudsman.service.model.ContactData;
//import com.ombudsman.service.model.EmailData;
//import com.ombudsman.service.model.LetterData;
//import com.ombudsman.service.model.PhoneData;
//import com.ombudsman.service.model.PortalData;
//import com.ombudsman.service.model.TaskData;
//import com.ombudsman.service.repo.ContactRepository;
//import com.ombudsman.service.repo.IncreLoadAuditRepository;
//import com.ombudsman.service.repo.IncreLoadErrorRepository;
//import com.ombudsman.service.response.ContactRes;
//import com.ombudsman.service.response.EmailRes;
//import com.ombudsman.service.response.LetterRes;
//import com.ombudsman.service.response.PhoneRes;
//import com.ombudsman.service.response.PortalRes;
//import com.ombudsman.service.response.TaskRes;
//
//import okhttp3.Call;
//import okhttp3.HttpUrl;
//import okhttp3.OkHttpClient;
//import okhttp3.mockwebserver.MockResponse;
//import okhttp3.mockwebserver.MockWebServer;
//
//@ExtendWith(SpringExtension.class)
//public class ContactPhxHelperTest {
//
//	@Spy
//	@InjectMocks
//	ContactPhxHelper contactService;
//
//	@Mock
//	ContactRepository contactRep;
//
//	@Mock
//	Call remoteCall;
//
//	@Mock
//	OkHttpClient okHttpClient;
//
//	@Mock
//	PhoenixHelper phoenixHelper;
//
//	@Mock
//	IncreLoadAuditRepository increLoadAuditRep;
//
//	@Mock
//	IncreLoadErrorRepository increLoadErrorRep;
//
//	@Mock
//	ContactSqlHelper contactsqlhelper;
//
//	@Mock
//	Constantsconfig constant;
//
//	@Mock
//	private ObjectMapper mapper;
//
//	@Mock
//	private JSONArray jsonArray;
//
//	private MockWebServer mockWebServer;
//
//	@BeforeEach
//	public void setUp() throws Exception {
//
//		MockitoAnnotations.openMocks(this);
//		mockWebServer = new MockWebServer();
//		mockWebServer.start();
//		mapper = new ObjectMapper();
//		jsonArray = new JSONArray();
//
//		// Set the mock APIM_HOST constant
//		ReflectionTestUtils.setField(constant, "APIM_HOST", mockWebServer.url("/").host());
//		ReflectionTestUtils.setField(constant, "Entity_Contact", "Contact");
//	}
//
//	@DisplayName("phxEmail_Test")
//	@Test
//	public void phxEmail_Test() throws Exception {
//		MockResponse mockResponse = new MockResponse()
//				.setBody("{\"value\": [{\"accountId\": \"123\", \"modifiedon\": \"2024-10-02\"}]}")
//				.addHeader("Content-Type", "application/json");
//		mockWebServer.enqueue(mockResponse);
//
//		// Prepare mock inputs
//		String Fetch_IncrementalDataLoadAuditId = "mockID";
//		EmailRes emailRes = new EmailRes();
//		ArrayList<EmailData> arrayListEmailData = new ArrayList<>();
//		Set<String> map = new HashSet<>();
//		String startWebJob_formatted = "2024-10-02";
//		String lastupdatedDate = "1994-02-01";
//		int batchsize = 3;
//		ArrayList<EmailData> FinalarrayListEmailData = new ArrayList<>();
//
//		// Mock Phoenix request build method
//		HttpUrl mockHttpUrl = mockWebServer.url("/phoniex/emails?fetchXml=test");
//		when(phoenixHelper.getPhoenixRequestBuild(anyString()))
//				.thenReturn(new okhttp3.Request.Builder().url(mockHttpUrl).build());
//
//		// Call the method
//		assertDoesNotThrow(() -> {
//			contactService.phxEmail(Fetch_IncrementalDataLoadAuditId, emailRes, arrayListEmailData, map,
//					startWebJob_formatted, lastupdatedDate, batchsize, FinalarrayListEmailData);
//		});
//
//		// Assertions
//		assertNotNull(arrayListEmailData);
//		assertTrue(arrayListEmailData.isEmpty());
//		assertNotNull(FinalarrayListEmailData);
//		assertTrue(FinalarrayListEmailData.isEmpty());
//		assertFalse(map.contains("123"));
//	}
//
//	@DisplayName("phxLetter_Test")
//	@Test
//	public void phxLetter_Test() throws Exception {
//		MockResponse mockResponse = new MockResponse()
//				.setBody("{\"value\": [{\"accountId\": \"123\", \"modifiedon\": \"2024-10-02\"}]}")
//				.addHeader("Content-Type", "application/json");
//		mockWebServer.enqueue(mockResponse);
//
//		// Prepare mock inputs
//		String fetch_IncrementalDataLoadAuditId = "mockID";
//		LetterRes letterRes = new LetterRes();
//		ArrayList<LetterData> arrayListLetterData = new ArrayList<>();
//		Set<String> map = new HashSet<>();
//		String startWebJob_formatted = "2024-10-02";
//		String lastupdatedDate = "1994-02-01";
//		int batchsize = 3;
//		ArrayList<LetterData> finalarrayListLetterData = new ArrayList<>();
//
//		// Mock Phoenix request build method
//		HttpUrl mockHttpUrl = mockWebServer.url("/phoniex/letters?fetchXml=test");
//		when(phoenixHelper.getPhoenixRequestBuild(anyString()))
//				.thenReturn(new okhttp3.Request.Builder().url(mockHttpUrl).build());
//
//		// Call the method
//		assertDoesNotThrow(() -> {
//			contactService.phxLetter(fetch_IncrementalDataLoadAuditId, letterRes, arrayListLetterData, map,
//					startWebJob_formatted, lastupdatedDate, batchsize, finalarrayListLetterData);
//		});
//
//		// Assertions
//		assertNotNull(arrayListLetterData);
//		assertTrue(arrayListLetterData.isEmpty());
//		assertNotNull(finalarrayListLetterData);
//		assertTrue(finalarrayListLetterData.isEmpty());
//		assertFalse(map.contains("123"));
//	}
//
//	@DisplayName("phxTask_Test")
//	@Test
//	public void phxTask_Test() throws Exception {
//		MockResponse mockResponse = new MockResponse()
//				.setBody("{\"value\": [{\"accountId\": \"123\", \"modifiedon\": \"2024-10-02\"}]}")
//				.addHeader("Content-Type", "application/json");
//		mockWebServer.enqueue(mockResponse);
//
//		// Prepare mock inputs
//		String Fetch_IncrementalDataLoadAuditId = "mockID";
//		TaskRes taskRes = new TaskRes();
//		ArrayList<TaskData> arrayListTaskData = new ArrayList<>();
//		Set<String> map = new HashSet<>();
//		String startWebJob_formatted = "2024-10-02";
//		String lastupdatedDate = "1994-02-01";
//		int batchsize = 3;
//		ArrayList<TaskData> FinalarrayListTaskData = new ArrayList<>();
//
//		// Mock Phoenix request build method
//		HttpUrl mockHttpUrl = mockWebServer.url("/phoniex/tasks?fetchXml=test");
//		when(phoenixHelper.getPhoenixRequestBuild(anyString()))
//				.thenReturn(new okhttp3.Request.Builder().url(mockHttpUrl).build());
//
//		// Call the method
//		assertDoesNotThrow(() -> {
//			contactService.phxTask(Fetch_IncrementalDataLoadAuditId, taskRes, arrayListTaskData, map,
//					startWebJob_formatted, lastupdatedDate, batchsize, FinalarrayListTaskData);
//		});
//
//		// Assertions
//		assertNotNull(arrayListTaskData);
//		assertTrue(arrayListTaskData.isEmpty());
//		assertNotNull(FinalarrayListTaskData);
//		assertTrue(FinalarrayListTaskData.isEmpty());
//		assertFalse(map.contains("123"));
//	}
//
//	@DisplayName("phxPhone_Test")
//	@Test
//	public void phxPhone_Test() throws Exception {
//		MockResponse mockResponse = new MockResponse()
//				.setBody("{\"value\": [{\"accountId\": \"123\", \"modifiedon\": \"2024-10-02\"}]}")
//				.addHeader("Content-Type", "application/json");
//		mockWebServer.enqueue(mockResponse);
//
//		// Prepare mock inputs
//		String Fetch_IncrementalDataLoadAuditId = "mockID";
//		PhoneRes phoneRes = new PhoneRes();
//		ArrayList<PhoneData> arrayListPhoneData = new ArrayList<>();
//		Set<String> map = new HashSet<>();
//		String startWebJob_formatted = "2024-10-02";
//		String lastupdatedDate = "1994-02-01";
//		int batchsize = 3;
//		ArrayList<PhoneData> FinalarrayListPhoneData = new ArrayList<>();
//
//		// Mock Phoenix request build method
//		HttpUrl mockHttpUrl = mockWebServer.url("/phoniex/phones?fetchXml=test");
//		when(phoenixHelper.getPhoenixRequestBuild(anyString()))
//				.thenReturn(new okhttp3.Request.Builder().url(mockHttpUrl).build());
//
//		// Call the method
//		assertDoesNotThrow(() -> {
//			contactService.phxPhone(Fetch_IncrementalDataLoadAuditId, phoneRes, arrayListPhoneData, map,
//					startWebJob_formatted, lastupdatedDate, batchsize, FinalarrayListPhoneData);
//		});
//
//		// Assertions
//		assertNotNull(arrayListPhoneData);
//		assertTrue(arrayListPhoneData.isEmpty());
//		assertNotNull(FinalarrayListPhoneData);
//		assertTrue(FinalarrayListPhoneData.isEmpty());
//		assertFalse(map.contains("123"));
//	}
//
//	@DisplayName("phxPortal_Test")
//	@Test
//	public void phxPortal_Test() throws Exception {
//		MockResponse mockResponse = new MockResponse()
//				.setBody("{\"value\": [{\"accountId\": \"123\", \"modifiedon\": \"2024-10-02\"}]}")
//				.addHeader("Content-Type", "application/json");
//		mockWebServer.enqueue(mockResponse);
//
//		// Prepare mock inputs
//		String Fetch_IncrementalDataLoadAuditId = "mockID";
//		PortalRes portalRes = new PortalRes();
//		ArrayList<PortalData> arrayListPortalData = new ArrayList<>();
//		Set<String> map = new HashSet<>();
//		String startWebJob_formatted = "2024-10-02";
//		String lastupdatedDate = "1994-02-01";
//		int batchsize = 3;
//		ArrayList<PortalData> FinalarrayListPortalData = new ArrayList<>();
//
//		// Mock Phoenix request build method
//		HttpUrl mockHttpUrl = mockWebServer.url("/phoniex/portals?fetchXml=test");
//		when(phoenixHelper.getPhoenixRequestBuild(anyString()))
//				.thenReturn(new okhttp3.Request.Builder().url(mockHttpUrl).build());
//
//		// Call the method
//		assertDoesNotThrow(() -> {
//			contactService.phxPortal(Fetch_IncrementalDataLoadAuditId, portalRes, arrayListPortalData, map,
//					startWebJob_formatted, lastupdatedDate, batchsize, FinalarrayListPortalData);
//		});
//
//		// Assertions
//		assertNotNull(arrayListPortalData);
//		assertTrue(arrayListPortalData.isEmpty());
//		assertNotNull(FinalarrayListPortalData);
//		assertTrue(FinalarrayListPortalData.isEmpty());
//		assertFalse(map.contains("123"));
//	}
//
//	@DisplayName("phxContact_Test")
//	@Test
//	public void phxContact_Test() throws Exception {
//		MockResponse mockResponse = new MockResponse()
//				.setBody("{\"value\": [{\"accountId\": \"123\", \"modifiedon\": \"2024-10-02\"}]}")
//				.addHeader("Content-Type", "application/json");
//		mockWebServer.enqueue(mockResponse);
//
//		// Prepare mock inputs
//		String Fetch_IncrementalDataLoadAuditId = "mockID";
//		ContactRes contactRes = new ContactRes();
//		ArrayList<ContactData> arrayListcontact = new ArrayList<>();
//		Set<String> map = new HashSet<>();
//		String startWebJob_formatted = "2024-10-02";
//		String lastupdatedDate = "1994-02-01";
//		int batchsize = 3;
//
//		// Mock Phoenix request build method
//		HttpUrl mockHttpUrl = mockWebServer.url("/phoniex/contacts?fetchXml=test");
//		when(phoenixHelper.getPhoenixRequestBuild(anyString()))
//				.thenReturn(new okhttp3.Request.Builder().url(mockHttpUrl).build());
//
//		// Call the method
//		String result = assertDoesNotThrow(() -> {
//			return contactService.phxContact(Fetch_IncrementalDataLoadAuditId, contactRes, arrayListcontact, map,
//					startWebJob_formatted, lastupdatedDate, batchsize);
//		});
//
//		// Assertions
//		assertNotNull(result);
//		assertEquals(startWebJob_formatted, result);
//		assertNotNull(arrayListcontact);
//		assertTrue(arrayListcontact.isEmpty());
//		assertFalse(map.contains("123"));
//	}
//
//	@DisplayName("phxContact_recon_Test")
//	@Test
//	public void phxContact_recon_Test() throws Exception {
//		MockResponse mockResponse = new MockResponse()
//				.setBody("{\"value\": [{\"accountId\": \"123\", \"modifiedon\": \"2024-10-02\"}]}")
//				.addHeader("Content-Type", "application/json");
//		mockWebServer.enqueue(mockResponse);
//
//		// Prepare mock inputs
//		String Fetch_IncrementalDataLoadAuditId = "mockID";
//		ContactRes contactRes = new ContactRes();
//		ArrayList<ContactData> arrayListcontact = new ArrayList<>();
//		String startWebJob_formatted = "2024-10-02";
//		String lastupdatedDate = "1994-02-01";
//		int batchsize = 3;
//		Long totalRecord = 0L;
//
//		// Mock Phoenix request build method
//		HttpUrl mockHttpUrl = mockWebServer.url("/phoniex/contacts?fetchXml=test");
//		when(phoenixHelper.getPhoenixRequestBuild(anyString()))
//				.thenReturn(new okhttp3.Request.Builder().url(mockHttpUrl).build());
//
//		// Call the method
//		Long result = assertDoesNotThrow(() -> {
//			return contactService.phxContact_recon(Fetch_IncrementalDataLoadAuditId, contactRes, arrayListcontact,
//					startWebJob_formatted, lastupdatedDate, batchsize, totalRecord);
//		});
//
//		// Assertions
//		assertNotNull(result);
//		assertTrue(result >= 0);
//		assertNotNull(arrayListcontact);
//		assertTrue(arrayListcontact.isEmpty());
//	}
//
//	@DisplayName("contactphxhelper")
//	@Test
//	public void contactphxhelperTest() throws Exception {
//		MockResponse mockResponse = new MockResponse()
//				.setBody("{\"value\": [{\"accountId\": \"123\", \"modifiedon\": \"2024-10-10\"}]}")
//				.addHeader("Content-Type", "application/json");
//		mockWebServer.enqueue(mockResponse);
//
//		// Prepare mock inputs
//		String startWebJobFormatted = "2024-10-01";
//		ContactRes contactRes = new ContactRes();
//		ContactData data = new ContactData();
//		ArrayList<ContactData> arrayListContactData = new ArrayList<>();
//		int fetchXmlRecord = 10;
//		String lastUpdatedDate = "2024-09-30";
//		String entityName = "Account";
//		Set<String> map = new HashSet<>();
//		String fetchIncrementalDataLoadAuditId = "1";
//
//		// Mock Phoenix request build method
//		HttpUrl mockHttpUrl = mockWebServer.url("/phoniex/contacts?fetchXml=test");
//		when(phoenixHelper.getPhoenixRequestBuild(anyString()))
//				.thenReturn(new okhttp3.Request.Builder().url(mockHttpUrl).build());
//
//		// Call the method
//		String result = contactService.contactphxhelper(startWebJobFormatted, contactRes, arrayListContactData,
//				fetchXmlRecord, lastUpdatedDate, entityName, map, fetchIncrementalDataLoadAuditId);
//
//		assertNotNull(result);
//		assertEquals("2024-10-10", result);
//		verify(contactsqlhelper, times(1)).insertForContact(eq(arrayListContactData),
//				eq(fetchIncrementalDataLoadAuditId));
//		assertFalse(map.contains("123"));
//
//	}
//
//	@DisplayName("contactphxhelper_recon_Test")
//	@Test
//	public void contactphxhelper_recon_Test() throws Exception {
//		MockResponse mockResponse = new MockResponse()
//				.setBody("{\"value\": [{\"accountId\": \"123\", \"modifiedon\": \"2024-10-10\"}]}")
//				.addHeader("Content-Type", "application/json");
//		mockWebServer.enqueue(mockResponse);
//
//		// Prepare mock inputs
//		String startWebJobFormatted = "2024-10-01";
//		ContactRes contactRes = new ContactRes();
//		ContactData data = new ContactData();
//		ArrayList<ContactData> arrayListContactData = new ArrayList<>();
//		int fetchXmlRecord = 10;
//		String lastUpdatedDate = "2024-09-30";
//		String entityName = "Account";
//		Set<String> map = new HashSet<>();
//		String fetchIncrementalDataLoadAuditId = "1";
//
//		// Mock Phoenix request build method
//		HttpUrl mockHttpUrl = mockWebServer.url("/phoniex/contacts?fetchXml=test");
//		when(phoenixHelper.getPhoenixRequestBuild(anyString()))
//				.thenReturn(new okhttp3.Request.Builder().url(mockHttpUrl).build());
//
//		// Call the method
//		String result = contactService.contactphxhelper_recon(startWebJobFormatted, contactRes, arrayListContactData,
//				fetchXmlRecord, lastUpdatedDate, entityName, fetchIncrementalDataLoadAuditId);
//
//		assertNotNull(result);
//		assertEquals("2024-10-10", result);
//		verify(contactsqlhelper, times(1)).insertForContact(eq(arrayListContactData),
//				eq(fetchIncrementalDataLoadAuditId));
//		assertFalse(map.contains("123"));
//
//	}
//
//	@Test
//	public void testGetFetchXML() {
//		// Arrange
//		String curtime = "2023-01-02 00:00:00";
//		String lastupdatedDate = "2023-01-01 00:00:00";
//		int Fetchxml_Record = 100;
//		String entityname = "entityName";
//
//		// Act
//		String fetchXml = contactService.getFetchXML(curtime, lastupdatedDate, Fetchxml_Record, entityname);
//
//		// Assert
//		assertNotNull(fetchXml);
//		assertTrue(fetchXml.contains(curtime));
//		assertTrue(fetchXml.contains(lastupdatedDate));
//		assertTrue(fetchXml.contains(entityname));
//	}
//
//	@Test
//	void testContactValueSet() throws JsonProcessingException {
//		// Add sample JSON data to the jsonArray
//		String jsonStr = "{ \"contactid\": \"123\", \"fos_contactdescriptionoption\": 456, \"birthdate\": \"01-01-1999\" }";
//		jsonArray.put(new JSONObject(jsonStr));
//
//		ContactData data = new ContactData();
//		data.setContactid("Contactid1");
//		data.setFos_contactdescriptionoption(98L);
//		data.setBirthdate("01-01-1999");
//
//		ArrayList<ContactData> arrayListAccountData = new ArrayList<>();
//		arrayListAccountData.add(data);
//
//		// Call the method under test
//		contactService.contactValueSet(arrayListAccountData, mapper, jsonArray, 0);
//
//		assertEquals(2, arrayListAccountData.size());
//		ContactData result = arrayListAccountData.get(0);
//
//		// Verify the expected values
//		assertEquals("Contactid1", result.getContactid());
//		assertEquals(98L, result.getFos_contactdescriptionoption());
//		assertEquals("01-01-1999", result.getBirthdate());
//	}
//
//	@Test
//	void testTaskValueSet() throws JsonProcessingException {
//		// Add sample JSON data to the jsonArray
//		String jsonStr = "{ \"activityid\": \"123\", \"createdby\": \"MockUser\", \"statecode\": 8}";
//		jsonArray.put(new JSONObject(jsonStr));
//
//		TaskData data = new TaskData();
//		data.setActivityid("ID1");
//		data.setCreatedby("MockUser");
//		data.setStatecode(8l);
//
//		ArrayList<TaskData> arrayTaskDataData = new ArrayList<>();
//		arrayTaskDataData.add(data);
//
//		// Call the method under test
//		contactService.taskValueSet(arrayTaskDataData, mapper, jsonArray, 0);
//
//		assertEquals(2, arrayTaskDataData.size());
//		TaskData result = arrayTaskDataData.get(0);
//
//		// Verify the expected values
//		assertEquals("ID1", result.getActivityid());
//		assertEquals("MockUser", result.getCreatedby());
//		assertEquals(8l, result.getStatecode());
//	}
//
//	@Test
//	void testPhoneValueSet() throws JsonProcessingException {
//		// Add sample JSON data to the jsonArray
//		String jsonStr = "{ \"activityid\": \"123\", \"createdby\": \"MockUser\", \"statecode\": 8}";
//		jsonArray.put(new JSONObject(jsonStr));
//
//		PhoneData data = new PhoneData();
//		data.setActivityid("ID1");
//		data.setCreatedby("MockUser");
//		data.setStatecode(8l);
//
//		ArrayList<PhoneData> arrayPhoneData = new ArrayList<>();
//		arrayPhoneData.add(data);
//
//		// Call the method under test
//		contactService.phoneValueSet(arrayPhoneData, mapper, jsonArray, 0);
//
//		assertEquals(2, arrayPhoneData.size());
//		PhoneData result = arrayPhoneData.get(0);
//
//		// Verify the expected values
//		assertEquals("ID1", result.getActivityid());
//		assertEquals("MockUser", result.getCreatedby());
//		assertEquals(8l, result.getStatecode());
//	}
//
//	@Test
//	void testLetterValueSet() throws JsonProcessingException {
//		// Add sample JSON data to the jsonArray
//		String jsonStr = "{ \"activityid\": \"123\", \"createdby\": \"MockUser\", \"statecode\": 8}";
//		jsonArray.put(new JSONObject(jsonStr));
//
//		LetterData data = new LetterData();
//		data.setActivityid("ID1");
//		data.setCreatedby("MockUser");
//		data.setStatecode(8l);
//
//		ArrayList<LetterData> arrayLetterData = new ArrayList<>();
//		arrayLetterData.add(data);
//
//		// Call the method under test
//		contactService.letterValueSet(arrayLetterData, mapper, jsonArray, 0);
//
//		assertEquals(2, arrayLetterData.size());
//		LetterData result = arrayLetterData.get(0);
//
//		// Verify the expected values
//		assertEquals("ID1", result.getActivityid());
//		assertEquals("MockUser", result.getCreatedby());
//		assertEquals(8l, result.getStatecode());
//	}
//
//	@Test
//	void testEmailValueSet() throws JsonProcessingException {
//		// Add sample JSON data to the jsonArray
//		String jsonStr = "{ \"activityid\": \"123\", \"createdby\": \"MockUser\", \"statecode\": 8}";
//		jsonArray.put(new JSONObject(jsonStr));
//
//		EmailData data = new EmailData();
//		data.setActivityid("ID1");
//		data.setCreatedby("MockUser");
//		data.setStatecode(8l);
//
//		ArrayList<EmailData> arrayEmailData = new ArrayList<>();
//		arrayEmailData.add(data);
//
//		// Call the method under test
//		contactService.emailValueSet(arrayEmailData, mapper, jsonArray, 0);
//
//		assertEquals(2, arrayEmailData.size());
//		EmailData result = arrayEmailData.get(0);
//
//		// Verify the expected values
//		assertEquals("ID1", result.getActivityid());
//		assertEquals("MockUser", result.getCreatedby());
//		assertEquals(8l, result.getStatecode());
//	}
//
//	@Test
//	void testPortalDataSet() throws JsonProcessingException {
//		// Add sample JSON data to the jsonArray
//		String jsonStr = "{ \"activityid\": \"123\", \"createdby\": \"MockUser\", \"fos_otherreason\": \"mock\"}";
//		jsonArray.put(new JSONObject(jsonStr));
//
//		PortalData data = new PortalData();
//		data.setActivityid("ID1");
//		data.setCreatedby("MockUser");
//		data.setFos_otherreason("mock");
//		;
//
//		ArrayList<PortalData> arrayPortalData = new ArrayList<>();
//		arrayPortalData.add(data);
//
//		// Call the method under test
//		contactService.portalValueSet(arrayPortalData, mapper, jsonArray, 0);
//
//		assertEquals(2, arrayPortalData.size());
//		PortalData result = arrayPortalData.get(0);
//
//		// Verify the expected values
//		assertEquals("ID1", result.getActivityid());
//		assertEquals("MockUser", result.getCreatedby());
//		assertEquals("mock", result.getFos_otherreason());
//	}
//
//	@Test
//	public void emailphxhelper_Test() throws Exception {
//		MockResponse mockResponse = new MockResponse()
//				.setBody("{\"value\": [{\"accountId\": \"123\", \"modifiedon\": \"2024-10-10\"}]}")
//				.addHeader("Content-Type", "application/json");
//		mockWebServer.enqueue(mockResponse);
//
//		// Prepare mock inputs
//		String startWebJob_Formatted = "2024-10-01";
//		ArrayList<EmailData> arrayListEmailData = new ArrayList<>();
//		EmailRes emailRes = new EmailRes();
//		int batchsize = 3;
//		String startdateValue = "01-02-1994";
//		String entityname = "MockName";
//		Set<String> map = new HashSet<>();
//		ArrayList<EmailData> finalarrayListEmailData = new ArrayList<>();
//		String fetch_IncrementalDataLoadAuditId = "mockID";
//
//		// Mock Phoenix request build method
//		HttpUrl mockHttpUrl = mockWebServer.url("/phoniex/contacts?fetchXml=test");
//		when(phoenixHelper.getPhoenixRequestBuild(anyString()))
//				.thenReturn(new okhttp3.Request.Builder().url(mockHttpUrl).build());
//
//		// Call the method
//		String result = contactService.emailphxhelper(startWebJob_Formatted, arrayListEmailData, emailRes, batchsize,
//				startdateValue, entityname, map, finalarrayListEmailData, fetch_IncrementalDataLoadAuditId
//
//		);
//
//		assertNotNull(result);
//		assertEquals("2024-10-10", result);
//		assertFalse(map.contains("123"));
//	}
//
//	@Test
//	public void letterphxhelper_Test() throws Exception {
//		MockResponse mockResponse = new MockResponse()
//				.setBody("{\"value\": [{\"accountId\": \"123\", \"modifiedon\": \"2024-10-10\"}]}")
//				.addHeader("Content-Type", "application/json");
//		mockWebServer.enqueue(mockResponse);
//
//		// Prepare mock inputs
//		String startWebJob_Formatted = "2024-10-01";
//		ArrayList<LetterData> arrayLetterData = new ArrayList<>();
//		LetterRes letterRes = new LetterRes();
//		int batchsize = 3;
//		String startdateValue = "01-02-1994";
//		String entityname = "MockName";
//		Set<String> map = new HashSet<>();
//		ArrayList<LetterData> finalarrayLetterData = new ArrayList<>();
//		String fetch_IncrementalDataLoadAuditId = "mockID";
//
//		// Use reflection to mock the private method
//		Method method = ContactPhxHelper.class.getDeclaredMethod("letterphxhelper", String.class, ArrayList.class,
//				LetterRes.class, int.class, String.class, String.class, Set.class, ArrayList.class, String.class);
//		method.setAccessible(true);
//
//		// Mock Phoenix request build method
//		HttpUrl mockHttpUrl = mockWebServer.url("/phoniex/contacts?fetchXml=test");
//		when(phoenixHelper.getPhoenixRequestBuild(anyString()))
//				.thenReturn(new okhttp3.Request.Builder().url(mockHttpUrl).build());
//
//		// Call the method
//
//		String result = (String) method.invoke(contactService, startWebJob_Formatted, arrayLetterData, letterRes,
//				batchsize, startdateValue, entityname, map, finalarrayLetterData, fetch_IncrementalDataLoadAuditId
//
//		);
//
//		assertNotNull(result);
//		assertEquals("2024-10-01", result);
//
//	}
//
//	@Test
//	public void taskphxhelper_Test() throws Exception {
//		MockResponse mockResponse = new MockResponse()
//				.setBody("{\"value\": [{\"accountId\": \"123\", \"modifiedon\": \"2024-10-10\"}]}")
//				.addHeader("Content-Type", "application/json");
//		mockWebServer.enqueue(mockResponse);
//
//		// Prepare mock inputs
//		String startWebJob_Formatted = "2024-10-01";
//		ArrayList<TaskData> arrayTaskData = new ArrayList<>();
//		TaskRes taskRes = new TaskRes();
//		int batchsize = 3;
//		String startdateValue = "01-02-1994";
//		String entityname = "MockName";
//		Set<String> map = new HashSet<>();
//		ArrayList<TaskData> finalarrayListEmailData = new ArrayList<>();
//		String fetch_IncrementalDataLoadAuditId = "mockID";
//
//		// Mock Phoenix request build method
//		HttpUrl mockHttpUrl = mockWebServer.url("/phoniex/contacts?fetchXml=test");
//		when(phoenixHelper.getPhoenixRequestBuild(anyString()))
//				.thenReturn(new okhttp3.Request.Builder().url(mockHttpUrl).build());
//
//		// Call the method
//		String result = contactService.taskphxhelper(startWebJob_Formatted, arrayTaskData, taskRes, batchsize,
//				startdateValue, entityname, map, finalarrayListEmailData, fetch_IncrementalDataLoadAuditId
//
//		);
//
//		assertNotNull(result);
//		assertEquals("2024-10-10", result);
//		assertFalse(map.contains("123"));
//	}
//
//	@Test
//	public void phonephxhelper_Test() throws Exception {
//		MockResponse mockResponse = new MockResponse()
//				.setBody("{\"value\": [{\"accountId\": \"123\", \"modifiedon\": \"2024-10-10\"}]}")
//				.addHeader("Content-Type", "application/json");
//		mockWebServer.enqueue(mockResponse);
//
//		// Prepare mock inputs
//		String startWebJob_Formatted = "2024-10-01";
//		ArrayList<PhoneData> arrayEmailData = new ArrayList<>();
//		PhoneRes phoneRes = new PhoneRes();
//		int batchsize = 3;
//		String startdateValue = "01-02-1994";
//		String entityname = "MockName";
//		Set<String> map = new HashSet<>();
//		ArrayList<PhoneData> FinalarrayListPhoneData = new ArrayList<>();
//		String fetch_IncrementalDataLoadAuditId = "mockID";
//
//		// Mock Phoenix request build method
//		HttpUrl mockHttpUrl = mockWebServer.url("/phoniex/contacts?fetchXml=test");
//		when(phoenixHelper.getPhoenixRequestBuild(anyString()))
//				.thenReturn(new okhttp3.Request.Builder().url(mockHttpUrl).build());
//
//		// Call the method
//		String result = contactService.phonephxhelper(startWebJob_Formatted, arrayEmailData, phoneRes, batchsize,
//				startdateValue, entityname, map, FinalarrayListPhoneData, fetch_IncrementalDataLoadAuditId
//
//		);
//
//		assertNotNull(result);
//		assertEquals("2024-10-10", result);
//		assertFalse(map.contains("123"));
//	}
//
//	@Test
//	public void portalphxhelper_Test() throws Exception {
//		MockResponse mockResponse = new MockResponse()
//				.setBody("{\"value\": [{\"accountId\": \"123\", \"modifiedon\": \"2024-10-10\"}]}")
//				.addHeader("Content-Type", "application/json");
//		mockWebServer.enqueue(mockResponse);
//
//		// Prepare mock inputs
//		String startWebJob_Formatted = "2024-10-01";
//		ArrayList<PortalData> arrayPortalData = new ArrayList<>();
//		PortalRes portalRes = new PortalRes();
//		int batchsize = 3;
//		String startdateValue = "01-02-1994";
//		String entityname = "MockName";
//		Set<String> map = new HashSet<>();
//		ArrayList<PortalData> FinalarrayListPortalData = new ArrayList<>();
//		String fetch_IncrementalDataLoadAuditId = "mockID";
//
//		// Mock Phoenix request build method
//		HttpUrl mockHttpUrl = mockWebServer.url("/phoniex/contacts?fetchXml=test");
//		when(phoenixHelper.getPhoenixRequestBuild(anyString()))
//				.thenReturn(new okhttp3.Request.Builder().url(mockHttpUrl).build());
//
//		// Call the method
//		String result = contactService.portalphxhelper(startWebJob_Formatted, arrayPortalData, portalRes,
//
//				batchsize, startdateValue, entityname, map, FinalarrayListPortalData, fetch_IncrementalDataLoadAuditId
//
//		);
//
//		assertNotNull(result);
//		assertEquals("2024-10-10", result);
//		assertFalse(map.contains("123"));
//	}
//
//}
