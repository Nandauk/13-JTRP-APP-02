package com.ombudsman.service.repo;

import com.ombudsman.service.repo.EmailRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class EmailRepositoryTest {

    @Mock
    private EmailRepository emailRepository;

    @BeforeEach
    void setUp() {
        // Setup mocks before each test if necessary
    }

    @Test
    public void testInsertQuery() {
        // Arrange
        String activityId = "activity123";
        Long stateCode = 1L;
        String activityTypeCode = "email";
        Long attachmentCount = 2L;
        String description = "Test description";
        Boolean directionCode = true;
        Boolean isResponseRequested = true;
        String emailSenderName = "sender@example.com";
        String offerOutcomeId = "outcome123";
        Long originator = 1L;
        String recipientRole = "recipientRole";
        String responseToBeReceivedBy = "2025-02-24";
        String from = "from@example.com";
        String cc = "cc@example.com";
        String to = "to@example.com";
        String sentOn = "2025-01-24T10:58:00";
        String subject = "Test Subject";
        String toRecipients = "toRecipients";
        String regardingObjectId = "regardingObject123";
        Long versionNumber = 1L;
        String createdOn = "2025-01-24T10:58:00";
        String modifiedOn = "2025-01-24T10:58:00";
        String createdBy = "creator";
        String modifiedBy = "modifier";
        String incrementalDataLoadJobAuditId = "auditId123";

        // Mock the expected behavior of the method
        when(emailRepository.InsertQuery(
                eq(activityId), eq(stateCode), eq(activityTypeCode), eq(attachmentCount),
                eq(description), eq(directionCode), eq(isResponseRequested), eq(emailSenderName),
                eq(offerOutcomeId), eq(originator), eq(recipientRole), eq(responseToBeReceivedBy),
                eq(from), eq(cc), eq(to), eq(sentOn), eq(subject), eq(toRecipients),
                eq(regardingObjectId), eq(versionNumber), eq(createdOn), eq(modifiedOn),
                eq(createdBy), eq(modifiedBy), eq(incrementalDataLoadJobAuditId))
        ).thenReturn(1); // simulating a successful insert

        // Act
        int result = emailRepository.InsertQuery(activityId, stateCode, activityTypeCode, attachmentCount, description,
                directionCode, isResponseRequested, emailSenderName, offerOutcomeId, originator, recipientRole,
                responseToBeReceivedBy, from, cc, to, sentOn, subject, toRecipients, regardingObjectId, versionNumber,
                createdOn, modifiedOn, createdBy, modifiedBy, incrementalDataLoadJobAuditId);

        // Assert
        assertEquals(1, result);
        verify(emailRepository, times(1)).InsertQuery(eq(activityId), eq(stateCode), eq(activityTypeCode), eq(attachmentCount),
                eq(description), eq(directionCode), eq(isResponseRequested), eq(emailSenderName),
                eq(offerOutcomeId), eq(originator), eq(recipientRole), eq(responseToBeReceivedBy),
                eq(from), eq(cc), eq(to), eq(sentOn), eq(subject), eq(toRecipients),
                eq(regardingObjectId), eq(versionNumber), eq(createdOn), eq(modifiedOn),
                eq(createdBy), eq(modifiedBy), eq(incrementalDataLoadJobAuditId));
    }
}