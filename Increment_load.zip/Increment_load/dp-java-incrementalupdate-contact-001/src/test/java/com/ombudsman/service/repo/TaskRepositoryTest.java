package com.ombudsman.service.repo;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class TaskRepositoryTest {

    @Mock
    private TaskRepository repository;

    @Test
    public void testInsertQuery() {
        String activityId = "activity123";
        Long fosCategoryCode = 1L;
        String fosCompletedOnDate = "2025-01-24";
        String fosEmailId = "email123";
        String fosLetterId = "letter123";
        String fosPhoneCallId = "phoneCall123";
        String regardingObjectId = "regardingObject123";
        Long stateCode = 1L;
        Long versionNumber = 1L;
        String createdOn = "2025-01-24T10:58:00";
        String scheduledend = "2025-01-24T10:58:00";
        String modifiedOn = "2025-01-24T10:58:00";
        String createdBy = "creator";
        String modifiedBy = "modifier";
        String incrementalDataLoadJobAuditId = "auditId123";

        // Mock the InsertQuery method
        when(repository.InsertQuery(activityId, fosCategoryCode, fosCompletedOnDate, fosEmailId, fosLetterId,
                fosPhoneCallId, regardingObjectId, stateCode, versionNumber, createdOn, modifiedOn, createdBy, modifiedBy,
                scheduledend,incrementalDataLoadJobAuditId)).thenReturn(1);

        // Call the method on the mock
        int result = repository.InsertQuery(activityId, fosCategoryCode, fosCompletedOnDate, fosEmailId, fosLetterId,
                fosPhoneCallId, regardingObjectId, stateCode, versionNumber, createdOn, modifiedOn, createdBy, modifiedBy,
                scheduledend,incrementalDataLoadJobAuditId);

        // Assert the result
        assertThat(result).isEqualTo(1);
    }
}