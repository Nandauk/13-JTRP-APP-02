package com.ombudsman.service.repo;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class LetterRepositoryTest {

    @Mock
    private LetterRepository repository;

    @Test
    public void testInsertQuery() {
        String activityId = "activity123";
        Boolean directionCode = true;
        String dispatchDate = "2025-01-24";
        Boolean isResponseRequested = true;
        Long mailClassCode = 1L;
        String offerOutcomeId = "outcome123";
        Long originator = 1L;
        String recipientRole = "recipientRole";
        String responseToBeReceivedBy = "2025-02-24";
        Long visibleInPortal = 1L;
        String regardingObjectId = "regardingObject123";
        Long stateCode = 1L;
        Long versionNumber = 1L;
        String fos_completedondate = "2025-01-24T10:58:00";
        String createdOn = "2025-01-24T10:58:00";
        String modifiedOn = "2025-01-24T10:58:00";
        String createdBy = "creator";
        String modifiedBy = "modifier";
        String incrementalDataLoadJobAuditId = "auditId123";

        // Mock the InsertQuery method
        when(repository.InsertQuery(activityId, directionCode, dispatchDate, isResponseRequested, mailClassCode,
                offerOutcomeId, originator, recipientRole, responseToBeReceivedBy, visibleInPortal,
                regardingObjectId, stateCode, versionNumber, createdOn, modifiedOn, createdBy, modifiedBy,fos_completedondate,
                incrementalDataLoadJobAuditId)).thenReturn(1);

        int result = repository.InsertQuery(activityId, directionCode, dispatchDate, isResponseRequested, mailClassCode,
                offerOutcomeId, originator, recipientRole, responseToBeReceivedBy, visibleInPortal,
                regardingObjectId, stateCode, versionNumber, createdOn, modifiedOn, createdBy, modifiedBy,fos_completedondate,
                incrementalDataLoadJobAuditId);
        assertThat(result).isEqualTo(1);
    }
}