#! /bin/bash
az account set --subscription "b70424dd-d53a-40a3-98a4-0cf1f27c11f0"
cat <<EOF > dp-java-incrementalupdate-contact-dv2-configmap.yaml
apiVersion: v1
kind: ConfigMap
metadata:
  name: dp-java-incrementalupdate-contact-nonprod-configmap
  namespace: var_namespace_respondent
data:
EOF

ENVIRONMENT=dv2
ENVIRON=dev2

cat <<EOF>> dp-java-incrementalupdate-contact-${ENVIRONMENT}-configmap.yaml
   SERVER_PORT: '8443'
   ENV: DV2
   SQL_DRIVER: com.microsoft.sqlserver.jdbc.SQLServerDriver
   CRON_TIME_JOB: 0 */15 * * * *
   CRON_TIME_JOB_RECON: 0 0 23 * * *
   SQL_CONNECT_TIMEOUT: '10000'
   SQL_READ_TIMEOUT: '5000'
   RUN_FLAG: 'ON'
   ENTITY_CONTACT: CONTACT_ENTITY
   APIM_HOST: apim-{ENVIRON}.financial-ombudsman.org.uk
   START_TIME: NA
   END_TIME: NA
   FETCHXML_RECORD_COUNT: '1000'
   TEMPLATE_ID: '6646610'
   TO_EMAIL: swati.amlani@financial-ombudsman.org.uk
   MAILJET_URL: https://apim-{ENVIRON}.financial-ombudsman.org.uk/mailjet/send   
EOF

cat dp-java-incrementalupdate-contact-${ENVIRONMENT}-configmap.yaml