#! /bin/bash
if [ -z "$1" ]; then
  echo "Usage: $0 [dv2|prf]"
  exit 1
fi

stage="$1"
#ENVIRONMENT="$stage"

#Set subscription ID based on environment
if [ "$stage" = "dv2" ]; then 
  echo "deploying to dv2 environment"
  SUBSCRIPTION_ID="b70424dd-d53a-40a3-98a4-0cf1f27c11f0"
  ENVIRON=dev2
  ENVIRONMENT=dv2
elif [ "$stage" = "prf" ]; then
  echo "deploying to prf environment"
  SUBSCRIPTION_ID="07285016-701b-4617-9557-1cedc46548fb"
  ENVIRON=prf
  ENVIRONMENT=prf
elif [ "$stage" = "prf-dr" ]; then
  echo "deploying to prf-dr environment"
  SUBSCRIPTION_ID="07285016-701b-4617-9557-1cedc46548fb"
  ENVIRON=prf 
  ENVIRONMENT=prf 
else
   echo "Invalid environment. Use 'dv2' or 'prf'."
   exit 1
fi     

# Convert ENVIRONMENT to uppercase
ENVIRONMENT_UPPER=$(echo "$ENVIRONMENT" | tr '[:lower:]' '[:upper:]')

#Set the subscription
az account set --subscription "$SUBSCRIPTION_ID"

# Generate ConfigMap YAML
cat <<EOF > dp-java-incrementalupdate-contact-${stage}-configmap.yaml
apiVersion: v1
kind: ConfigMap
metadata:
  name: dp-java-incrementalupdate-contact-nonprod-configmap
  namespace: var_namespace_respondent
data:
  SERVER_PORT: '8443'
  ENV: ${ENVIRONMENT_UPPER}
  SQL_DRIVER: com.microsoft.sqlserver.jdbc.SQLServerDriver
  CRON_TIME_JOB: 0 */15 * * * *
  CRON_TIME_JOB_RECON: 0 0 23 * * *
  SQL_CONNECT_TIMEOUT: '10000'
  SQL_READ_TIMEOUT: '5000'
  RUN_FLAG: 'ON'
  ENTITY_CONTACT: CONTACT_ENTITY
  APIM_HOST: apim-${ENVIRON}.financial-ombudsman.org.uk
  START_TIME: NA
  END_TIME: NA
  FETCHXML_RECORD_COUNT: '1000'
  TEMPLATE_ID: '6646610'
  TO_EMAIL: swati.amlani@financial-ombudsman.org.uk
  MAILJET_URL: https://apim-${ENVIRON}.financial-ombudsman.org.uk/mailjet/send   
EOF

echo "ConfigMap YAML generated: dp-java-incrementalupdate-contact-${stage}-configmap.yaml