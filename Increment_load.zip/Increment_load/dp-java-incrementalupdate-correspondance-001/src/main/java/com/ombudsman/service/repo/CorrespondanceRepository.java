package com.ombudsman.service.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.ombudsman.service.model.CorrespondanceData;

public interface CorrespondanceRepository extends JpaRepository<CorrespondanceData, String> {

	@Modifying
	@Transactional
	@Query(value = "INSERT INTO stg_correspondence(fos_correspondenceid,fos_requestresponseby,versionnumber,createdon,modifiedon,createdby,modifiedby,incrementaldataloadjobauditid) VALUES (CONVERT(uniqueidentifier,:fos_correspondenceid),:fos_requestresponseby,:versionnumber,:createdon,:modifiedon,CONVERT(uniqueidentifier,:createdby),CONVERT(uniqueidentifier,:modifiedby),CONVERT(uniqueidentifier,:incrementaldataloadjobauditid))", nativeQuery = true)
	int InsertQuery(@Param("fos_correspondenceid") String fos_correspondenceid,
			@Param("fos_requestresponseby") String fos_requestresponseby, @Param("versionnumber") Long versionnumber,
			@Param("createdon") String createdon, @Param("modifiedon") String modifiedon,
			@Param("createdby") String createdby, @Param("modifiedby") String modifiedby,
			@Param("incrementaldataloadjobauditid") String incrementaldataloadjobauditid);

}
