package com.ombudsman.service.services;

import java.io.IOException;

public interface CorrespondancePhxToSqlService {
	
	void correspondancePhxToSql() throws IOException,  InterruptedException;

	void correspondancePhxToSql_recon(String Start_time, String End_time) throws  IOException,  InterruptedException;

}
