package com.ombudsman.service.model;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "stg_correnspondence")
public class CorrespondanceData {

	@Id
	private String fos_correspondenceid;
	private String fos_requestresponseby;
	private Long versionnumber;
	private String createdon;
	private String modifiedon;
	private String createdby;
	private String modifiedby;
	private String incrementaldataloadjobauditid;

	public String getIncrementaldataloadjobauditid() {
		return incrementaldataloadjobauditid;
	}

	public void setIncrementaldataloadjobauditid(String incrementaldataloadjobauditid) {
		this.incrementaldataloadjobauditid = incrementaldataloadjobauditid;
	}

	public String getFos_correspondenceid() {
		return fos_correspondenceid;
	}

	public void setFos_correspondenceid(String fos_correspondenceid) {
		this.fos_correspondenceid = fos_correspondenceid;
	}

	public String getModifiedon() {
		return modifiedon;
	}

	public void setModifiedon(String modifiedon) {
		this.modifiedon = modifiedon;
	}

	public LocalDateTime getModifiedonSorting() {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss'Z'");
		return LocalDateTime.parse(modifiedon, formatter);
	}

	public Long getVersionnumber() {
		return versionnumber;
	}

	public void setVersionnumber(Long versionnumber) {
		this.versionnumber = versionnumber;
	}

	public String getCreatedon() {
		return createdon;
	}

	public void setCreatedon(String createdon) {
		this.createdon = createdon;
	}

	public String getCreatedby() {
		return createdby;
	}

	public void setCreatedby(String createdby) {
		this.createdby = createdby;
	}

	public String getModifiedby() {
		return modifiedby;
	}

	public void setModifiedby(String modifiedby) {
		this.modifiedby = modifiedby;
	}

	public String getFos_requestresponseby() {
		return fos_requestresponseby;
	}

	public void setFos_requestresponseby(String fos_requestresponseby) {
		this.fos_requestresponseby = fos_requestresponseby;
	}

}
