package com.ombudsman.service.serviceImpl;

import java.util.ArrayList;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ombudsman.service.common.Constantsconfig;
import com.ombudsman.service.model.CorrespondanceData;
import com.ombudsman.service.repo.CorrespondanceRepository;

@Service
public class CorrespondanceSqlHelper {

	@Autowired
	CorrespondanceRepository correspondanceRepository;

	@Autowired
	Constantsconfig constant;

	Logger LOG = LogManager.getRootLogger();

	public void insertForALL(ArrayList<CorrespondanceData> arrayListcorrespondance,
			String Fetch_IncrementalDataLoadAuditId) {
		
		LOG.info(String.format("Total records for %s for  Insertion are : %s ", constant.Entity_Correspondance,
				arrayListcorrespondance.size()));

		for (CorrespondanceData cpd : arrayListcorrespondance) {

			if (cpd.getFos_correspondenceid() != null) {
				insertcorrespondance(Fetch_IncrementalDataLoadAuditId, cpd);

			}
		}

	}

	public void insertcorrespondance(String Fetch_IncrementalDataLoadAuditId, CorrespondanceData cpd) {
		correspondanceRepository.InsertQuery(cpd.getFos_correspondenceid(), cpd.getFos_requestresponseby(),
				cpd.getVersionnumber(), cpd.getCreatedon(), cpd.getModifiedon(), cpd.getCreatedby(),
				cpd.getModifiedby(), Fetch_IncrementalDataLoadAuditId);
	}


}
