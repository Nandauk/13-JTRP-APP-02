package com.ombudsman.service.response;

import java.util.List;

import com.ombudsman.service.model.CorrespondanceData;



public class CorrespondanceRes {

	private List<CorrespondanceData> correspondanceData;

	public List<CorrespondanceData> getCorrespondanceData() {
		return correspondanceData;
	}

	public void setCorrespondanceData(List<CorrespondanceData> correspondanceData) {
		this.correspondanceData = correspondanceData;
	}

}
