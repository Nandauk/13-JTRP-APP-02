//package com.ombudsman.service.serviceImpl;
// 
//import static org.junit.jupiter.api.Assertions.assertEquals;
//import static org.junit.jupiter.api.Assertions.assertFalse;
//import static org.junit.jupiter.api.Assertions.assertNotNull;
// 
//import java.io.IOException;
//import java.util.ArrayList;
// 
//import org.junit.jupiter.api.BeforeAll;
//import org.junit.jupiter.api.BeforeEach;
//import org.junit.jupiter.api.Test;
//import org.junit.jupiter.api.extension.ExtendWith;
//import org.mockito.InjectMocks;
//import org.mockito.Mock;
//import org.mockito.MockitoAnnotations;
//import org.mockito.junit.jupiter.MockitoExtension;
//import org.springframework.boot.web.server.WebServer;
//import org.springframework.test.util.ReflectionTestUtils;
//import static org.mockito.ArgumentMatchers.anyString;
//import static org.mockito.ArgumentMatchers.anyInt;
// 
//import static org.mockito.ArgumentMatchers.eq;
//import static org.mockito.Mockito.times;
//import static org.mockito.Mockito.verify;
//import static org.mockito.Mockito.when;
// 
//import com.ombudsman.service.common.Constantsconfig;
//import com.ombudsman.service.common.PhoenixHelper;
//import com.ombudsman.service.model.CorrespondanceData;
//import com.ombudsman.service.repo.CorrespondanceRepository;
//import com.ombudsman.service.repo.IncreLoadAuditRepository;
//import com.ombudsman.service.repo.IncreLoadErrorRepository;
//import com.ombudsman.service.response.CorrespondanceRes;
// 
//import okhttp3.Call;
//import okhttp3.HttpUrl;
//import okhttp3.OkHttpClient;
//import okhttp3.mockwebserver.MockResponse;
//import okhttp3.mockwebserver.MockWebServer;
// 
//@ExtendWith(MockitoExtension.class)
//public class CorrespondancePhxHelperTest {
//	@InjectMocks
//	CorrespondancePhxHelper correspondancePhxHelper;
//	@Mock
//	PhoenixHelper phoenixHelper;
// 
//	@Mock
//	IncreLoadAuditRepository increLoadAuditRep;
// 
//	@Mock
//	IncreLoadErrorRepository increLoadErrorRep;
// 
//	@Mock
//	CorrespondanceRepository correspondanceRepository;
// 
//	@Mock
//	CorrespondanceSqlHelper correspondancesqlhelper;
//	@Mock
//	Constantsconfig constant;
//	@Mock
//	Call remoteCall;
//	@Mock
//	OkHttpClient okHttpClient;
//	public static MockWebServer mockWebServer;
// 
//	 @BeforeEach
//	    public void setUp() throws Exception {
//	        MockitoAnnotations.openMocks(this);
//	        mockWebServer = new MockWebServer();
//	        mockWebServer.start();
// 
//	        // Set the mock APIM_HOST constant
//	        ReflectionTestUtils.setField(constant, "APIM_HOST", mockWebServer.url("/").host());
//	        ReflectionTestUtils.setField(constant, "Entity_Correspondance", "Correspondance");
//	    }
// 
//	 @Test
//	 public void testPhxhelper_success() throws Exception {
//	     // Mock the response from Phoenix API
//	     MockResponse mockResponse = new MockResponse()
//	             .setBody("{\"value\": [{\"fos_correspondenceid\": \"123\", \"modifiedon\": \"2024-10-10\"}]}")
//	             .addHeader("Content-Type", "application/json");
//	     mockWebServer.enqueue(mockResponse);
// 
//	     // Prepare mock inputs
//	     String startWebJob_formatted = "2024-10-01";
//	     CorrespondanceRes correspondanceRes = new CorrespondanceRes();
//	     ArrayList<CorrespondanceData> arrayListcorrespondance = new ArrayList<>();
//	     int batchsize = 10;
//	     String startdateValue = "2024-09-30";
//	     String entityname = "Correspondance";
//	     String fetch_IncrementalDataLoadAuditId = "audit123";
// 
//	     // Mock Phoenix request build method
//	     HttpUrl mockHttpUrl = mockWebServer.url("/phoniex/fos_correspondences?fetchXml=test");
//	     when(phoenixHelper.getPhoenixRequestBuild(anyString())).thenReturn(new okhttp3.Request.Builder().url(mockHttpUrl).build());
// 
//	     // Call the method
//	     String result = correspondancePhxHelper.phxhelper(
//	             startWebJob_formatted,
//	             correspondanceRes,
//	             arrayListcorrespondance,
//	             batchsize,
//	             startdateValue,
//	             entityname,
//	             fetch_IncrementalDataLoadAuditId
//	     );
// 
//	     assertNotNull(result);
//	     assertEquals("2024-10-10", result);  // Adjusted expected value
//	     verify(correspondancesqlhelper, times(1)).insertForALL(eq(arrayListcorrespondance), eq(fetch_IncrementalDataLoadAuditId));
//	     assertFalse(arrayListcorrespondance.isEmpty());
//	 }
// 
//    @Test
//    void testGetFetchXML() {
//        // Arrange
//        String curtime = "2023-01-01T00:00:00Z";
//        String lastupdatedDate = "2022-12-31T00:00:00Z";
//        int Fetchxml_Record = 10;
//        String entityname = "correspondance";
// 
//        // Act
//        String fetchXml = correspondancePhxHelper.getFetchXML(curtime, lastupdatedDate, Fetchxml_Record, entityname);
// 
//        // Assert
//        String expectedFetchXml = "<fetch top='10' version='1.0' mapping='logical'><entity name='correspondance'><filter><condition attribute='modifiedon' operator='between' value=''><value>2022-12-31T00:00:00Z</value><value>2023-01-01T00:00:00Z</value></condition></filter><order attribute='modifiedon' /> </entity></fetch>";
//        assertEquals(expectedFetchXml, fetchXml);
//    }
// 
// 
//}