package com.ombudsman.service.exception;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.test.context.junit.jupiter.SpringExtension;

@ExtendWith(SpringExtension.class)
public class GeneralServiceExceptionsTest {

    private GeneralServiceExceptions exception;
    private String message = "Test message";
    private String code = "400";
    private String exceptionMessage = "Test exception message";
    private StackTraceElement[] stackTraceElements = new StackTraceElement[0];

    @BeforeEach
    public void setUp() {
        exception = new GeneralServiceExceptions(message, code, exceptionMessage);
    }

    @Test
    public void testGetMessage() {
        assertEquals(message, exception.getMessage(), "The message should be equal to the initialized value");
    }

    @Test
    public void testGetCode() {
        assertEquals(code, exception.getCode(), "The code should be equal to the initialized value");
    }

    @Test
    public void testGetExceptionMessage() {
        assertEquals(exceptionMessage, exception.getExceptionMessage(), "The exception message should be equal to the initialized value");
    }

    
}
