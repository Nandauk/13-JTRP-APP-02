package com.ombudsman.service.model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;

class MessagesTest {

    @Test
    void testGetters() {
        Messages messages = new Messages();

        // Create `From` object and set value 
        From from = new From();
        from.setEmail("from@example.com");
        from.setName("Sender Name");
        messages.setFrom(from);

        // Create `To` object list and set values
        To to1 = new To();
        to1.setEmail("to1@example.com");
        to1.setName("Recipient One");

        To to2 = new To();
        to2.setEmail("to2@example.com");
        to2.setName("Recipient Two");

        List<To> toList = new ArrayList<>();
        toList.add(to1);
        toList.add(to2);
        messages.setTo(toList);

        // Create `MailjetVariables` object and set value
        MailjetVariables var = new MailjetVariables();
        var.setEntityName("Entity Name");
        var.setSource("Source");
        var.setAuditId("Audit123");
        var.setErrorLog("Error Log");
        var.setTimeStamp("2023-08-21T14:30:00Z");

        messages.setVar(var);
        messages.setTemplateID(1);
        messages.setTemplateLanguage(true);

        // Test getters
        assertEquals("from@example.com", messages.getFrom().getEmail());
        assertEquals("Sender Name", messages.getFrom().getName());
        assertEquals(2, messages.getTo().size());
        assertEquals("to1@example.com", messages.getTo().get(0).getEmail());
        assertEquals("Recipient One", messages.getTo().get(0).getName());
        assertEquals("to2@example.com", messages.getTo().get(1).getEmail());
        assertEquals("Recipient Two", messages.getTo().get(1).getName());
        assertEquals("Entity Name", messages.getVar().getEntityName());
        assertEquals("Source", messages.getVar().getSource());
        assertEquals("Audit123", messages.getVar().getAuditId());
        assertEquals("Error Log", messages.getVar().getErrorLog());
        assertEquals("2023-08-21T14:30:00Z", messages.getVar().getTimeStamp());
        assertEquals(1, messages.getTemplateID());
        assertEquals(true, messages.getTemplateLanguage());
    }
}
