package com.ombudsman.service.model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

class CorrespondanceDataTest {
	@Test
    void testSelectedGetters() {
    CorrespondanceData correspondanceData = new CorrespondanceData();

    // Set values using setters
    correspondanceData.setFos_correspondenceid("testCorrespondanceId");
    correspondanceData.setFos_requestresponseby("testRequest");
    correspondanceData.setVersionnumber(1L);
    correspondanceData.setCreatedon("2023-08-21T14:30:00Z");
    correspondanceData.setModifiedon("2023-08-21T15:00:00Z");
    correspondanceData.setCreatedby("John Doe");
    correspondanceData.setModifiedby("Jane Doe");
    correspondanceData.setIncrementaldataloadjobauditid("audit-12345");

    // Test getters
    assertEquals("testCorrespondanceId", correspondanceData.getFos_correspondenceid());
    assertEquals("testRequest", correspondanceData.getFos_requestresponseby());
    assertEquals(1L, correspondanceData.getVersionnumber());
    assertEquals("2023-08-21T14:30:00Z", correspondanceData.getCreatedon());
    assertEquals("2023-08-21T15:00:00Z", correspondanceData.getModifiedon());
    assertEquals("John Doe", correspondanceData.getCreatedby());
    assertEquals("Jane Doe", correspondanceData.getModifiedby());
    assertEquals("audit-12345", correspondanceData.getIncrementaldataloadjobauditid());
}}
