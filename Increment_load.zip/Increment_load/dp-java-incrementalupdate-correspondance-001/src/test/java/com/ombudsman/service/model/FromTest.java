package com.ombudsman.service.model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

class FromTest {

    @Test
    void testSelectedGetters() {
        From from = new From();

        // Set values using setters
        from.setEmail("test@example.com");
        from.setName("Test Name");

        // Test getters
        assertEquals("test@example.com", from.getEmail());
        assertEquals("Test Name", from.getName());
    }


}
