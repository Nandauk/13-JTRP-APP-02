package com.ombudsman.service.repo;

import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
public class IncreLoadAuditRepositoryTest {

	@Mock
	private IncreLoadAuditRepository increLoadAuditRepository;

	@BeforeEach
	public void setUp() {
		MockitoAnnotations.openMocks(this);
	}

	@Test
	void testInsertQuery() {
		// Given
		Integer jobId = 1;
		String jobStartDateTime = "2025-01-01T10:00:00Z";
		Integer totalNumberOfRecords = 100;
		Long numberOfProcessedRecord = 90L;
		Integer numberOfFailedRecord = 100;
		Integer currentJobStatusId = 2;
		String jobCloseDatetime = "2025-01-01T12:00:00Z";
		String source = "source";
		String createdBy = "creator";
		String modifiedBy = "modifier";

		// When
		when(increLoadAuditRepository.InsertQuery(jobId, jobStartDateTime, totalNumberOfRecords,
				numberOfProcessedRecord, numberOfFailedRecord, currentJobStatusId, jobCloseDatetime, source, createdBy,
				modifiedBy)).thenReturn(1);

		// Call the method with the correct arguments
		int result = increLoadAuditRepository.InsertQuery(jobId, jobStartDateTime, totalNumberOfRecords,
				numberOfProcessedRecord, numberOfFailedRecord, currentJobStatusId, jobCloseDatetime, source, createdBy,
				modifiedBy);

		// Then
		verify(increLoadAuditRepository, times(1)).InsertQuery(jobId, jobStartDateTime, totalNumberOfRecords,
				numberOfProcessedRecord, numberOfFailedRecord, currentJobStatusId, jobCloseDatetime, source, createdBy,
				modifiedBy);
	}

	@Test
	void testGetCurrentStatusIPId() {
		// Given
		String dataSourceName = "source";
		String inProgress = "In_Progress";

		// When
		when(increLoadAuditRepository.getCurrentStatusIPId(dataSourceName, inProgress)).thenReturn(1);

		// Call the method with the correct arguments
		int result = increLoadAuditRepository.getCurrentStatusIPId(dataSourceName, inProgress);

		// Then
		verify(increLoadAuditRepository, times(1)).getCurrentStatusIPId(dataSourceName, inProgress);
	}

	@Test
	void testGetCurrentStatusFId() {
		// Given
		String dataSourceName = "source";
		String failed = "Failed";

		// When
		when(increLoadAuditRepository.getCurrentStatusFId(dataSourceName, failed)).thenReturn(1);

		// Call the method with the correct arguments
		int result = increLoadAuditRepository.getCurrentStatusFId(dataSourceName, failed);

		// Then
		verify(increLoadAuditRepository, times(1)).getCurrentStatusFId(dataSourceName, failed);
	}

	@Test
	void testGetIncrementalDataLoadAuditId() {
		// Given
		String formattedTime = "2025-01-01T10:00:00Z";
		Integer currentJobStatusId = 2;
		String dataSourceName = "source";
		String createdBy = "creator";

		// When
		when(increLoadAuditRepository.getIncrementalDataLoadAuditId(formattedTime, currentJobStatusId, dataSourceName,
				createdBy)).thenReturn("auditId123");

		// Call the method with the correct arguments
		String result = increLoadAuditRepository.getIncrementalDataLoadAuditId(formattedTime, currentJobStatusId,
				dataSourceName, createdBy);

		// Then
		verify(increLoadAuditRepository, times(1)).getIncrementalDataLoadAuditId(formattedTime, currentJobStatusId,
				dataSourceName, createdBy);
	}

	@Test
	void testGetJobID() {
		// Given
		String createdBy = "creator";

		// When
		when(increLoadAuditRepository.getJobID(createdBy)).thenReturn(1);

		// Call the method with the correct arguments
		int result = increLoadAuditRepository.getJobID(createdBy);

		// Then
		verify(increLoadAuditRepository, times(1)).getJobID(createdBy);
	}

	@Test
	void testGetDataSourceName() {
		// Given
		String createdBy = "creator";

		// When
		when(increLoadAuditRepository.getDataSourceName(createdBy)).thenReturn("sourceName");

		// Call the method with the correct arguments
		String result = increLoadAuditRepository.getDataSourceName(createdBy);

		// Then
		verify(increLoadAuditRepository, times(1)).getDataSourceName(createdBy);
	}

	@Test
	void testUpdateQuery() {
		// Given
		Long totalNumberOfRecords = 100L;
		Long numberOfProcessedRecord = 90L;
		Integer numberOfFailedRecord = 100;
		Integer currentJobStatusId = 2;
		String jobCloseDatetime = "2025-01-01T12:00:00Z";
		String incrementalDataLoadAuditId = "auditId123";
		String modifiedBy = "modifier";

		// When
		doNothing().when(increLoadAuditRepository).UpdateQuery(totalNumberOfRecords, numberOfProcessedRecord,
				numberOfFailedRecord, currentJobStatusId, jobCloseDatetime, incrementalDataLoadAuditId, modifiedBy);

		// Call the method with the correct arguments
		increLoadAuditRepository.UpdateQuery(totalNumberOfRecords, numberOfProcessedRecord, numberOfFailedRecord,
				currentJobStatusId, jobCloseDatetime, incrementalDataLoadAuditId, modifiedBy);

		// Then
		verify(increLoadAuditRepository, times(1)).UpdateQuery(totalNumberOfRecords, numberOfProcessedRecord,
				numberOfFailedRecord, currentJobStatusId, jobCloseDatetime, incrementalDataLoadAuditId, modifiedBy);
	}

	@Test
	void testFindLatestDatefromphx() {
		// Given
		String processName = "process";

		// When
		when(increLoadAuditRepository.findLatestDatefromphx(processName)).thenReturn("2025-01-01T12:00:00Z");

		// Call the method with the correct arguments
		String result = increLoadAuditRepository.findLatestDatefromphx(processName);

		// Then
		verify(increLoadAuditRepository, times(1)).findLatestDatefromphx(processName);
	}

	@Test
	void testUpdateLatestDateCtlTbl() {
		// Given
		String latestModifiedOnDatePhx = "2025-01-01T12:00:00Z";
		String processName = "process";

		// When
		doNothing().when(increLoadAuditRepository).UpdateLatestDateCtlTbl(latestModifiedOnDatePhx, processName);

		// Call the method with the correct arguments
		increLoadAuditRepository.UpdateLatestDateCtlTbl(latestModifiedOnDatePhx, processName);

		// Then
		verify(increLoadAuditRepository, times(1)).UpdateLatestDateCtlTbl(latestModifiedOnDatePhx, processName);
	}
}
