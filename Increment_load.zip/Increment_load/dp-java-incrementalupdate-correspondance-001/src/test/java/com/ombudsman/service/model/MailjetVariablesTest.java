package com.ombudsman.service.model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

class MailjetVariablesTest {

    @Test
    void testGettersAndSetters() {
        MailjetVariables variables = new MailjetVariables();

        // Set values using setters
        variables.setEntityName("Entity Name");
        variables.setSource("Source");
        variables.setAuditId("Audit123");
        variables.setErrorLog("Error Log");
        variables.setTimeStamp("2023-08-21T14:30:00Z");

        // Test getters
        assertEquals("Entity Name", variables.getEntityName());
        assertEquals("Source", variables.getSource());
        assertEquals("Audit123", variables.getAuditId());
        assertEquals("Error Log", variables.getErrorLog());
        assertEquals("2023-08-21T14:30:00Z", variables.getTimeStamp());
    }
}
