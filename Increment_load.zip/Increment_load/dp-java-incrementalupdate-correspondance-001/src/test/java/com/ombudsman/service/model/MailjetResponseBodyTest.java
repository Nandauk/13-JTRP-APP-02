package com.ombudsman.service.model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;

class MailjetResponseBodyTest {

    @Test
    void testMailjetResponseBodyGetters() {
        MailjetResponseBody mailjetResponseBody = new MailjetResponseBody();

        // Create recipients
        MailjetResponseBody.Recipient recipient1 = new MailjetResponseBody.Recipient();
        recipient1.setEmail("recipient1@example.com");

        MailjetResponseBody.Recipient recipient2 = new MailjetResponseBody.Recipient();
        recipient2.setEmail("recipient2@example.com");

        List<MailjetResponseBody.Recipient> recipients = new ArrayList<>();
        recipients.add(recipient1);
        recipients.add(recipient2);

        // Create message
        MailjetResponseBody.Message message = new MailjetResponseBody.Message();
        message.setStatus("success");
        message.setTo(recipients);

        List<MailjetResponseBody.Message> messages = new ArrayList<>();
        messages.add(message);

        // Set values using setters
        mailjetResponseBody.setMessages(messages);

        // Test getters
        assertEquals(1, mailjetResponseBody.getMessages().size());
        assertEquals("success", mailjetResponseBody.getMessages().get(0).getStatus());
        assertEquals(2, mailjetResponseBody.getMessages().get(0).getTo().size());
        assertEquals("recipient1@example.com", mailjetResponseBody.getMessages().get(0).getTo().get(0).getEmail());
        assertEquals("recipient2@example.com", mailjetResponseBody.getMessages().get(0).getTo().get(1).getEmail());
    }
}
