package com.ombudsman.service.response;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;

import com.ombudsman.service.model.CorrespondanceData;

public class CorrespondanceResTest {

    private CorrespondanceRes correspondanceRes;
    private List<CorrespondanceData> correspondanceDataList;

    @BeforeEach
    public void setUp() {
        correspondanceRes = new CorrespondanceRes();
        correspondanceDataList = new ArrayList<>();
        correspondanceDataList.add(new CorrespondanceData());
    }

    @Test
    public void testGetCorrespondanceData() {
        correspondanceRes.setCorrespondanceData(correspondanceDataList);
        List<CorrespondanceData> result = correspondanceRes.getCorrespondanceData();
        assertNotNull(result);
        assertEquals(1, result.size());
        assertEquals(correspondanceDataList, result);
    }

    @Test
    public void testSetCorrespondanceData() {
        correspondanceRes.setCorrespondanceData(correspondanceDataList);
        assertEquals(correspondanceDataList, correspondanceRes.getCorrespondanceData());
    }
}
