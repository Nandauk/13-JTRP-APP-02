/*package com.ombudsman.service.serviceImpl;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.isNull;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;

import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.ombudsman.service.common.Constantsconfig;
import com.ombudsman.service.common.PhoenixHelper;
import com.ombudsman.service.model.CorrespondanceData;
import com.ombudsman.service.repo.CorrespondanceRepository;
import com.ombudsman.service.repo.IncreLoadAuditRepository;
import com.ombudsman.service.repo.IncreLoadErrorRepository;
import com.ombudsman.service.response.CorrespondanceRes;

import okhttp3.Call;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Protocol;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.ResponseBody;

@ExtendWith(SpringExtension.class)
public class CorrespondancePhxToSqlImplTest {

	@InjectMocks
	private CorrespondancePhxToSqlImpl correspondancePhxToSqlImpl;

	@Mock
	private PhoenixHelper phoenixHelper;

	@Mock
	private IncreLoadAuditRepository increLoadAuditRep;

	@Mock
	private IncreLoadErrorRepository increLoadErrorRep;

	@Mock
	private CorrespondanceRepository correspondanceRepository;

	@Mock
	private CorrespondancePhxHelper correspondancephxhelper;

	@Mock
	private CorrespondanceSqlHelper correspondancesqlhelper;

	@Mock
	private Constantsconfig constant;

	@Mock
	private EmailHelper emailhelper;

	private static final Logger LOG = LoggerFactory.getLogger(CorrespondancePhxToSqlImplTest.class);

	@BeforeEach
	public void setUp() {
		// Initialize constants
		constant.DataSourceName = "dataSourceName";
		constant.In_Progress = "inProgress";
		constant.Completed = "completed";
		constant.Ready_To_Process = "readyToProcess";
		constant.Entity_Correspondance = "correspondance";
	}

	@DisplayName("correspondancePhxToSqlTest")
	@Test
	public void correspondancePhxToSqlTest() throws Exception { // Arrange
		constant.DataSourceName = "dataSourceName";
		constant.In_Progress = "inProgress";
		constant.Completed = "completed";
		constant.Ready_To_Process = "readyToProcess";
		constant.Entity_Correspondance = "correspondance";

		when(increLoadAuditRep.getJobID(anyString())).thenReturn(1);
		when(increLoadAuditRep.getCurrentStatusIPId(anyString(), anyString())).thenReturn(1);

		when(increLoadAuditRep.getCurrentStatusRTPId(anyString(), anyString())).thenReturn(3);
		when(increLoadAuditRep.getIncrementalDataLoadAuditId(anyString(), anyInt(), anyString(), anyString()))
				.thenReturn("id");
		when(increLoadAuditRep.findLatestDatefromphx(anyString())).thenReturn("2023-01-01");

		// Act
		correspondancePhxToSqlImpl.correspondancePhxToSql();

		// Assert
		verify(increLoadAuditRep, times(1)).getJobID(anyString());
		verify(increLoadAuditRep, times(1)).getCurrentStatusIPId(anyString(), anyString());

		verify(increLoadAuditRep, times(1)).getCurrentStatusRTPId(anyString(), anyString());
		verify(increLoadAuditRep, times(1)).InsertQuery(anyInt(), anyString(), anyInt(), anyLong(), anyInt(), anyInt(),
				isNull(), anyString(), anyString(), anyString());
	}

	@Test
	public void testCorrespondancePhxToSql_recon() throws IOException, InterruptedException {
		// Arrange
		when(increLoadAuditRep.getJobID(anyString())).thenReturn(1);
		when(increLoadAuditRep.getCurrentStatusIPId(anyString(), anyString())).thenReturn(1);
		when(increLoadAuditRep.getCurrentStatusRTPId(anyString(), anyString())).thenReturn(3);

		when(increLoadAuditRep.getIncrementalDataLoadAuditId(anyString(), anyInt(), anyString(), anyString()))
				.thenReturn("id");
		// Remove unnecessary stubbings
		// when(increLoadAuditRep.findLatestDatefromphx(anyString())).thenReturn("2023-01-01");

		// Act
		correspondancePhxToSqlImpl.correspondancePhxToSql_recon("2023-01-01 00:00:00", "2023-01-02 00:00:00");

		// Assert
		verify(increLoadAuditRep, times(1)).getJobID(anyString());
		verify(increLoadAuditRep, times(1)).getCurrentStatusIPId(anyString(), anyString());
		verify(increLoadAuditRep, times(1)).getCurrentStatusRTPId(anyString(), anyString());

		verify(increLoadAuditRep, times(1)).InsertQuery(anyInt(), anyString(), anyInt(), anyLong(), anyInt(), anyInt(),
				isNull(), anyString(), anyString(), anyString());
	}

	@Test
	public void testIncidentUpdatePnxtoSql_Exception() throws IOException {
		// Arrange
		constant.Entity_Correspondance = "correspondance";
		doThrow(new RuntimeException("Database Error")).when(increLoadAuditRep).getJobID(anyString());

		// Mark unnecessary stubbings as lenient
		lenient().when(increLoadAuditRep.getCurrentStatusIPId(anyString(), anyString())).thenReturn(1);

		lenient().when(increLoadAuditRep.getCurrentStatusRTPId(anyString(), anyString())).thenReturn(3);
		lenient().when(increLoadAuditRep.getIncrementalDataLoadAuditId(anyString(), anyInt(), anyString(), anyString()))
				.thenReturn("id");
		lenient().when(increLoadAuditRep.findLatestDatefromphx(anyString())).thenReturn("2023-01-01");

		// Act and Assert
		RuntimeException exception = assertThrows(RuntimeException.class, () -> {
			correspondancePhxToSqlImpl.correspondancePhxToSql();
		});

		String expectedMessage = "Job failed for correspondance  with Error : java.lang.RuntimeException: Database Error";
		String actualMessage = exception.getMessage().split("\n")[0].trim();

		// Print the actual message for debugging purposes
		System.out.println("Actual exception message: '" + actualMessage + "'");

		assertEquals(expectedMessage, actualMessage, "The exception message did not match the expected value.");
	}

}*/
