package com.ombudsman.service.model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

class ToTest {

    @Test
    void testSelectedGetters() {
        To to = new To();

        // Set values using setters
        to.setEmail("test@example.com");
        to.setName("Test Name");

        // Test getters
        assertEquals("test@example.com", to.getEmail());
        assertEquals("Test Name", to.getName());
    }


}
