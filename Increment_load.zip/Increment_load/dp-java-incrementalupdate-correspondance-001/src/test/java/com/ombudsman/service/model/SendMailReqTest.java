package com.ombudsman.service.model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;

public class SendMailReqTest {

	@Test
	void testSendMailReqTestGetters() 
	{
		SendMailReq sendMailReq = new SendMailReq();
		
		List<Messages> messages = new ArrayList<>();
		Messages message = new Messages();
		message.setTemplateID(123);
		messages.add(message);
		
		sendMailReq.setMessages(messages);
		
		 // Test getters
        assertEquals(1, sendMailReq.getMessages().size());
		
	}
	
}
