package com.ombudsman.service.repo;

import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
public class CorrespondanceRepositoryTest {

	@Mock
    private CorrespondanceRepository correspondanceRepository;
	
    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }
    
    @Test
    void testInsertQuery() {
        // Given
    	String fos_correspondenceid = "testCorrespondanceId";
    	String fos_requestresponseby ="testRequestResponseBy";
    	Long versionnumber = 123L;
        String createdOn = "2025-01-01T10:00:00Z";
        String modifiedOn = "2025-01-01T10:00:00Z";
        String createdBy = "creator";
        String modifiedBy = "modifier";
        String incrementalDataLoadJobAuditId = "audit123";
        
        // When
        when(correspondanceRepository.InsertQuery(fos_correspondenceid, fos_requestresponseby, versionnumber, createdOn, modifiedOn, createdBy,
                modifiedBy, incrementalDataLoadJobAuditId)).thenReturn(1);

        // Call the method with the correct arguments
        int result = correspondanceRepository.InsertQuery(fos_correspondenceid, fos_requestresponseby, versionnumber, createdOn, modifiedOn, createdBy,
                modifiedBy, incrementalDataLoadJobAuditId);

        // Then
        verify(correspondanceRepository, times(1)).InsertQuery(fos_correspondenceid, fos_requestresponseby, versionnumber, createdOn, modifiedOn, createdBy,
                modifiedBy, incrementalDataLoadJobAuditId);
    }
}
