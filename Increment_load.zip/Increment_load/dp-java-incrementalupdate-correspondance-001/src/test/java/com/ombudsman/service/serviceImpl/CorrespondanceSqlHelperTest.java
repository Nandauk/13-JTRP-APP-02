package com.ombudsman.service.serviceImpl;

import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;

import com.ombudsman.service.common.Constantsconfig;
import com.ombudsman.service.model.CorrespondanceData;
import com.ombudsman.service.repo.CorrespondanceRepository;

@ExtendWith(MockitoExtension.class)
public class CorrespondanceSqlHelperTest {

	@InjectMocks
	CorrespondanceSqlHelper mMockCorrespondanceSqlHelper;
	
	@Mock
	private CorrespondanceRepository correspondanceRepository;

	private CorrespondanceData correspondanceData;
	@Mock
	private Constantsconfig constant;
	
	@BeforeEach
	public void setUp() {
		correspondanceData = new CorrespondanceData();
		constant.Correspondance = "Correspondance";
		
		correspondanceData.setFos_correspondenceid("correspondanceId");
		correspondanceData.setFos_requestresponseby("requestResponseBy");
		correspondanceData.setVersionnumber(1L);
		correspondanceData.setModifiedon("2023-01-01");
		correspondanceData.setCreatedby("createdby");
		correspondanceData.setModifiedby("modifiedby");
		correspondanceData.setCreatedon("2023-01-01");		
	}
	
	@Test
	void testInsertForALL() {
		// Arrange
		String fetchIncrementalDataLoadAuditId = "audit_id";	

		// Act
		mMockCorrespondanceSqlHelper.insertcorrespondance(fetchIncrementalDataLoadAuditId,correspondanceData);

		// Assert
		verify(correspondanceRepository, times(1)).InsertQuery(
				correspondanceData.getFos_correspondenceid(),
				correspondanceData.getFos_requestresponseby(),
				correspondanceData.getVersionnumber(),
				correspondanceData.getCreatedon(),
				correspondanceData.getModifiedon(),
				correspondanceData.getCreatedby(),
				correspondanceData.getModifiedby(),
				fetchIncrementalDataLoadAuditId);
	}
}
