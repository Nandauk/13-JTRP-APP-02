package com.ombudsman.service.serviceImpl;

import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

import java.time.Instant;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.test.util.ReflectionTestUtils;

import com.ombudsman.service.common.Constantsconfig;
import com.ombudsman.service.model.AccountData;
import com.ombudsman.service.model.ContactData;
import com.ombudsman.service.repo.AccountRepository;
import com.ombudsman.service.repo.ContactRepository;


@ExtendWith(MockitoExtension.class)
public class AccountSqlHelperTest {

    @Mock
    private AccountRepository accountRepo;
    
    @Mock
    private ContactRepository contactRepo;
    
    @InjectMocks
    private AccountSqlHelper accountSqlHelper;
    
    private Constantsconfig constants;
    
    @BeforeEach
    void setUp() {
        // Create real instance with reflection
        constants = new Constantsconfig();
        
        // Set field values using Spring's ReflectionTestUtils
        ReflectionTestUtils.setField(constants, "Contact", "contact");
        ReflectionTestUtils.setField(constants, "Entity_Account", "account");
        ReflectionTestUtils.setField(constants, "DataSourceName", "SCH");
        ReflectionTestUtils.setField(constants, "Fetchxml_Record", 1000);
        
        // Inject the configured constants into helper
        //accountSqlHelper = new AccountSqlHelper(constants, accountRepo, contactRepo, null, null);
    }

  
        @Test
        public void testInsertHelper() {
            // Given
            AccountData accountd = new AccountData();
            // Set values for accountd

            String fetchIncrementalDataLoadAuditId = "someId";

            // When
            accountSqlHelper.insertHelper(accountd, fetchIncrementalDataLoadAuditId);

            // Then
            verify(accountRepo, times(1)).InsertQuery(accountd.getAccountid(), accountd.getAccountcategorycode(),
                    accountd.getBusinesstypecode(), accountd.getFos_approvalstatus(), accountd.getFos_hierarchylevel(),
                    accountd.getFos_legalstatus(), accountd.getFos_nametype(), accountd.getPreferredcontactmethodcode(),
                    accountd.getDonotemail(), accountd.getDonotphone(), accountd.getDonotpostalmail(),
                    accountd.getParentaccountid(), accountd.getAccountnumber(), accountd.getAddress1_city(),
                    accountd.getAddress1_composite(), accountd.getAddress1_country(), accountd.getAddress1_county(),
                    accountd.getAddress1_line1(), accountd.getAddress1_line2(), accountd.getAddress1_line3(),
                    accountd.getAddress1_name(), accountd.getAddress1_postalcode(), accountd.getAddress1_stateorprovince(),
                    accountd.getAddress2_city(), accountd.getAddress2_composite(), accountd.getAddress2_country(),
                    accountd.getAddress2_county(), accountd.getAddress2_line1(), accountd.getAddress2_line2(),
                    accountd.getAddress2_line3(), accountd.getAddress2_name(), accountd.getAddress2_postalcode(),
                    accountd.getAddress2_stateorprovince(), accountd.getEmailaddress1(), accountd.getFos_fcareference(),
                    accountd.getFos_shortname(), accountd.getFos_legalstatusname(), accountd.getName(),
                    accountd.getWebsiteurl(), accountd.getVersionnumber(), accountd.getCreatedon(),
                    accountd.getModifiedon(), accountd.getCreatedby(), accountd.getModifiedby(),
                    accountd.getFos_businesstypecode_txt(), accountd.getParentaccountidname(),
                    accountd.getFos_hierarchylevelname(), fetchIncrementalDataLoadAuditId,accountd.getFos_organisationcapacity(),
                    accountd.getStatecode());
       }
    

            @Test
            public void testInsertHelpercontact() {
                // Given
                ContactData contactd = new ContactData();
                // Set values for contactd

                String fetchIncrementalDataLoadAuditId = "someId";

                // When
                accountSqlHelper.insertHelpercontact(contactd, fetchIncrementalDataLoadAuditId);

                // Then
                verify(contactRepo, times(1)).InsertQuery(contactd.getContactid(), contactd.getStatecode(),
                        contactd.getFos_capacity(), contactd.getFos_contactdescriptionoption(),
                        contactd.getFos_digitalportalinvitestatus(), contactd.getFos_isdigitalportaladmin(),
                        contactd.getFos_parentorganisationcapacity(), contactd.getFos_phonerecordingconsent(),
                        contactd.getFos_preferredmethodofcorrespondencecode(), contactd.getFos_surveyconsentcode(),
                        contactd.getGendercode(), contactd.getPreferredcontactmethodcode(), contactd.getDonotemail(),
                        contactd.getDonotphone(), contactd.getDonotpostalmail(), contactd.getParentcontactid(),
                        contactd.getParentcustomerid(), contactd.getAddress1_city(), contactd.getAddress1_composite(),
                        contactd.getAddress1_country(), contactd.getAddress1_county(), contactd.getAddress1_line1(),
                        contactd.getAddress1_line2(), contactd.getAddress1_line3(), contactd.getAddress1_name(),
                        contactd.getAddress1_postalcode(), contactd.getBirthdate(), contactd.getDescription(),
                        contactd.getEmailaddress1(), contactd.getFirstname(), contactd.getFos_addressid(),
                        contactd.getFos_fcaid(), contactd.getFos_needstring(), contactd.getFos_othertitle(),
                        contactd.getFullname(), contactd.getJobtitle(), contactd.getLastname(), contactd.getMiddlename(),
                        contactd.getMsa_managingpartneridname(), contactd.getSalutation(), contactd.getSuffix(),
                        contactd.getTelephone1(), contactd.getTelephone2(), contactd.getVersionnumber(), contactd.getCreatedon(),
                        contactd.getModifiedon(), contactd.getCreatedby(), contactd.getModifiedby(),contactd.getFos_customeraddressid(),
                        fetchIncrementalDataLoadAuditId);
            }
        

   
}