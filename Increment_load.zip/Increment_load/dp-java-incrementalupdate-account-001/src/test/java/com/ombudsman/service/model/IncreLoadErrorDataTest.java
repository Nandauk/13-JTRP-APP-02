package com.ombudsman.service.model;

import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.time.LocalDateTime;
import java.util.UUID;

public class IncreLoadErrorDataTest {

    private IncreLoadErrorData increLoadErrorData;

    @BeforeEach
    public void setUp() {
        increLoadErrorData = new IncreLoadErrorData();
    }

    @Test
    public void testGettersAndSetters() {
        UUID errorId = UUID.randomUUID();
        UUID auditId = UUID.randomUUID();
        increLoadErrorData.setIncremental_data_load_error_id(errorId);
        increLoadErrorData.setIncremental_data_load_audit_id(auditId);
        increLoadErrorData.setData_pay_load("Data Payload");
        LocalDateTime now = LocalDateTime.now();
        
        increLoadErrorData.setCurrent_error_status_id(1);
        increLoadErrorData.setError_code("Error Code");
        increLoadErrorData.setError_log("Error Log");
        increLoadErrorData.setCreated_on(now);
        increLoadErrorData.setModified_on("2023-01-01T12:00:00Z");
        increLoadErrorData.setCreated_by("CreatedBy");
        increLoadErrorData.setModified_by("ModifiedBy");

        assertEquals(errorId, increLoadErrorData.getIncremental_data_load_error_id());
        assertEquals(auditId, increLoadErrorData.getIncremental_data_load_audit_id());
        assertEquals("Data Payload", increLoadErrorData.getData_pay_load());
       
        assertEquals(1, increLoadErrorData.getCurrent_error_status_id());
        assertEquals("Error Code", increLoadErrorData.getError_code());
        assertEquals("Error Log", increLoadErrorData.getError_log());
        assertEquals(now, increLoadErrorData.getCreated_on());
        assertEquals("2023-01-01T12:00:00Z", increLoadErrorData.getModified_on());
        assertEquals("CreatedBy", increLoadErrorData.getCreated_by());
        assertEquals("ModifiedBy", increLoadErrorData.getModified_by());
    }
}
