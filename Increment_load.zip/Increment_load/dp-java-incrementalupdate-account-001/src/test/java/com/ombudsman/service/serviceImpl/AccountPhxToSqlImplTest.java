package com.ombudsman.service.serviceImpl;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.ArgumentMatchers.isNull;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import com.ombudsman.service.common.Constantsconfig;
import com.ombudsman.service.model.AccountData;
import com.ombudsman.service.repo.AccountRepository;
import com.ombudsman.service.repo.ContactRepository;
import com.ombudsman.service.repo.IncreLoadAuditRepository;
import com.ombudsman.service.repo.IncreLoadErrorRepository;
import com.ombudsman.service.response.AccountRes;

@ExtendWith(MockitoExtension.class)
public class AccountPhxToSqlImplTest {

	@Mock
	private IncreLoadAuditRepository increLoadAuditRep;
	@Mock
	private AccountPhxHelper accphxhelper;
	@Mock
	private IncreLoadErrorRepository increLoadErrorRep;
	@Mock
	private Constantsconfig constantsConfig;
	@Mock
	private EmailHelper emailhelper;

	@InjectMocks
	private AccountPhxToSqlImpl accountPhxToSqlService;

	private final String ENTITY_ACCOUNT = "Account";
	private final String DATA_SOURCE = "AccountDataSource";
	private final String IN_PROGRESS = "InProgress";
	private final String COMPLETED = "Completed";
	private final String FAILED = "Failed";

	@BeforeEach
	void setup() {
		ReflectionTestUtils.setField(constantsConfig, "Entity_Account", ENTITY_ACCOUNT);
		ReflectionTestUtils.setField(constantsConfig, "DataSourceName", DATA_SOURCE);
		ReflectionTestUtils.setField(constantsConfig, "In_Progress", IN_PROGRESS);
		ReflectionTestUtils.setField(constantsConfig, "Completed", COMPLETED);
		ReflectionTestUtils.setField(constantsConfig, "Failed", FAILED);
		ReflectionTestUtils.setField(constantsConfig, "Fetchxml_Record", 1000);
		ReflectionTestUtils.setField(constantsConfig, "Error_log", "ERROR_LOG");
	}

	@Test
	void testAccountUpdatePnxtoSql_Success() throws Exception {
		// Mock setup
		when(increLoadAuditRep.getJobID(ENTITY_ACCOUNT)).thenReturn(1);
		when(increLoadAuditRep.getCurrentStatusIPId(DATA_SOURCE, IN_PROGRESS)).thenReturn(101);

		when(increLoadAuditRep.getIncrementalDataLoadAuditId(anyString(), anyInt(), eq(DATA_SOURCE),
				eq(ENTITY_ACCOUNT))).thenReturn("AUDIT123");
		when(increLoadAuditRep.findLatestDatefromphx(ENTITY_ACCOUNT)).thenReturn("2023-01-01T00:00:00Z");
		when(accphxhelper.phxAccount(anyString(), any(AccountRes.class), any(), any(), anyString(), anyString(),
				anyInt())).thenReturn("2023-01-02T00:00:00Z");

		// Execute
		accountPhxToSqlService.accountUpdatePnxtoSql();

		// Verify
		verify(increLoadAuditRep).InsertQuery(anyInt(), anyString(), anyInt(), anyLong(), anyInt(), anyInt(), eq(null),
				eq(DATA_SOURCE), eq(ENTITY_ACCOUNT), eq(ENTITY_ACCOUNT));
		// verify(increLoadAuditRep).UpdateLatestDateCtlTbl(ENTITY_ACCOUNT,
		// "2023-01-02T00:00:00Z");
	}

	@Test
	void testAccountUpdatePnxtoSql_ExceptionDuringPhoenixProcessing() throws Exception {
		// Mock setup
		when(increLoadAuditRep.getJobID(ENTITY_ACCOUNT)).thenReturn(1);
		when(increLoadAuditRep.getCurrentStatusIPId(DATA_SOURCE, IN_PROGRESS)).thenReturn(101);
		when(increLoadAuditRep.getIncrementalDataLoadAuditId(anyString(), anyInt(), eq(DATA_SOURCE),
				eq(ENTITY_ACCOUNT))).thenReturn("AUDIT123");
		when(increLoadAuditRep.findLatestDatefromphx(ENTITY_ACCOUNT)).thenReturn("2023-01-01T00:00:00Z");
		when(accphxhelper.phxAccount(anyString(), any(AccountRes.class), any(), any(), anyString(), anyString(),
				anyInt())).thenThrow(new RuntimeException("Phoenix connection failed"));

		// Execute & Verify
		assertThrows(RuntimeException.class, () -> accountPhxToSqlService.accountUpdatePnxtoSql());

		verify(increLoadErrorRep).InsertQuery(eq("AUDIT123"), anyString(), anyInt(), eq("ERROR_LOG"), anyString(),
				eq(ENTITY_ACCOUNT), eq(ENTITY_ACCOUNT));
		verify(emailhelper).NotificationWebclient(eq(ENTITY_ACCOUNT), eq("AUDIT123"), eq(DATA_SOURCE), anyString(),
				anyString());
	}

//    @Test
//    void testAccountUpdatePnxtoSql_NoRecords() throws Exception {
//        // Mock setup
//        when(increLoadAuditRep.getJobID(ENTITY_ACCOUNT)).thenReturn(1);
//        when(increLoadAuditRep.getCurrentStatusIPId(DATA_SOURCE, IN_PROGRESS)).thenReturn(101);
//        when(increLoadAuditRep.getCurrentStatusCId(DATA_SOURCE, COMPLETED)).thenReturn(102);
//        when(increLoadAuditRep.getIncrementalDataLoadAuditId(anyString(), anyInt(), eq(DATA_SOURCE), eq(ENTITY_ACCOUNT)))
//            .thenReturn("AUDIT123");
//        when(increLoadAuditRep.findLatestDatefromphx(ENTITY_ACCOUNT)).thenReturn("2023-01-01T00:00:00Z");
//        when(accphxhelper.phxAccount(anyString(), any(AccountRes.class), any(), any(), anyString(), anyString(), anyInt()))
//            .thenReturn("2023-01-01T00:00:00Z");
//
//        // Execute
//        accountPhxToSqlService.accountUpdatePnxtoSql();
//
//        // Verify
//        verify(increLoadAuditRep).UpdateQuery(eq(0L), eq(0L), eq(0), eq(102), eq(null), eq("AUDIT123"), eq(ENTITY_ACCOUNT));
//    }

	@Test
	void testAccountUpdatePnxtoSqlRecon_Success() throws Exception {
		// Mock setup
		when(increLoadAuditRep.getJobID(ENTITY_ACCOUNT)).thenReturn(1);
		when(increLoadAuditRep.getCurrentStatusIPId(DATA_SOURCE, IN_PROGRESS)).thenReturn(101);

		when(increLoadAuditRep.getIncrementalDataLoadAuditId(anyString(), anyInt(), eq(DATA_SOURCE),
				eq(ENTITY_ACCOUNT))).thenReturn("AUDIT123");
		when(accphxhelper.phxAccount_recon(anyString(), any(AccountRes.class), any(), anyLong(), anyString(),
				anyString(), anyInt())).thenReturn(100L);

		// Execute
		accountPhxToSqlService.accountUpdatePnxtoSql_recon("2023-01-01T00:00:00Z", "2023-01-02T00:00:00Z");

		// Verify
		// verify(increLoadAuditRep).UpdateLatestDateCtlTbl(ENTITY_ACCOUNT,
		// "2023-01-02T00:00:00Z");
	}

	@Test
	void testAccountUpdatePnxtoSqlRecon_Exception() throws Exception {
		// Mock setup
		when(increLoadAuditRep.getJobID(ENTITY_ACCOUNT)).thenReturn(1);
		when(increLoadAuditRep.getCurrentStatusIPId(DATA_SOURCE, IN_PROGRESS)).thenReturn(101);
		when(increLoadAuditRep.getIncrementalDataLoadAuditId(anyString(), anyInt(), eq(DATA_SOURCE),
				eq(ENTITY_ACCOUNT))).thenReturn("AUDIT123");
		when(accphxhelper.phxAccount_recon(anyString(), any(AccountRes.class), any(), anyLong(), anyString(),
				anyString(), anyInt())).thenThrow(new RuntimeException("Reconciliation error"));

		// Execute & Verify
		assertThrows(RuntimeException.class,
				() -> accountPhxToSqlService.accountUpdatePnxtoSql_recon("2023-01-01", "2023-01-02"));

		verify(increLoadErrorRep).InsertQuery(eq("AUDIT123"), anyString(), anyInt(), eq("ERROR_LOG"), anyString(),
				eq(ENTITY_ACCOUNT), eq(ENTITY_ACCOUNT));
	}

//    @Test
//    void testAccountUpdatePnxtoSqlRecon_NoRecords() throws Exception {
//        // Mock setup
//        when(increLoadAuditRep.getJobID(ENTITY_ACCOUNT)).thenReturn(1);
//        when(increLoadAuditRep.getCurrentStatusIPId(DATA_SOURCE, IN_PROGRESS)).thenReturn(101);
//        when(increLoadAuditRep.getCurrentStatusCId(DATA_SOURCE, COMPLETED)).thenReturn(102);
//        when(increLoadAuditRep.getIncrementalDataLoadAuditId(anyString(), anyInt(), eq(DATA_SOURCE), eq(ENTITY_ACCOUNT)))
//            .thenReturn("AUDIT123");
//        when(accphxhelper.phxAccount_recon(anyString(), any(AccountRes.class), any(), anyLong(), anyString(), anyString(), anyInt()))
//            .thenReturn(0L);
//
//        // Execute
//        accountPhxToSqlService.accountUpdatePnxtoSql_recon("2023-01-01T00:00:00Z", "2023-01-02T00:00:00Z");
//
//        // Verify
//        verify(increLoadAuditRep).UpdateQuery(eq(0L), eq(0L), eq(0), eq(102), eq(null), eq("AUDIT123"), eq(ENTITY_ACCOUNT));
//    }
}