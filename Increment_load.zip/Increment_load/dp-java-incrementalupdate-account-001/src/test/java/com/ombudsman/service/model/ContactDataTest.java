package com.ombudsman.service.model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;


public class ContactDataTest {

    private ContactData contactData;

    @BeforeEach
    public void setUp() {
        contactData = new ContactData();
    }

    @Test
    public void testSetAndGetContactid() {
        contactData.setContactid("contact123");
        assertEquals("contact123", contactData.getContactid());
    }

    @Test
    public void testSetAndGetStatecode() {
        contactData.setStatecode(1L);
        assertEquals(1L, contactData.getStatecode());
    }

    @Test
    public void testSetAndGetFos_capacity() {
        contactData.setFos_capacity(10L);
        assertEquals(10L, contactData.getFos_capacity());
    }

    @Test
    public void testSetAndGetFos_contactdescriptionoption() {
        contactData.setFos_contactdescriptionoption(20L);
        assertEquals(20L, contactData.getFos_contactdescriptionoption());
    }

    @Test
    public void testSetAndGetFos_digitalportalinvitestatus() {
        contactData.setFos_digitalportalinvitestatus(30L);
        assertEquals(30L, contactData.getFos_digitalportalinvitestatus());
    }

    @Test
    public void testSetAndGetFos_isdigitalportaladmin() {
        contactData.setFos_isdigitalportaladmin(40L);
        assertEquals(40L, contactData.getFos_isdigitalportaladmin());
    }

    @Test
    public void testSetAndGetFos_parentorganisationcapacity() {
        contactData.setFos_parentorganisationcapacity(50L);
        assertEquals(50L, contactData.getFos_parentorganisationcapacity());
    }

    @Test
    public void testSetAndGetFos_phonerecordingconsent() {
        contactData.setFos_phonerecordingconsent(60L);
        assertEquals(60L, contactData.getFos_phonerecordingconsent());
    }

    @Test
    public void testSetAndGetFos_preferredmethodofcorrespondencecode() {
        contactData.setFos_preferredmethodofcorrespondencecode(70L);
        assertEquals(70L, contactData.getFos_preferredmethodofcorrespondencecode());
    }

    @Test
    public void testSetAndGetFos_surveyconsentcode() {
        contactData.setFos_surveyconsentcode(80L);
        assertEquals(80L, contactData.getFos_surveyconsentcode());
    }

    @Test
    public void testSetAndGetGendercode() {
        contactData.setGendercode(90L);
        assertEquals(90L, contactData.getGendercode());
    }

    @Test
    public void testSetAndGetPreferredcontactmethodcode() {
        contactData.setPreferredcontactmethodcode(100L);
        assertEquals(100L, contactData.getPreferredcontactmethodcode());
    }

    @Test
    public void testSetAndGetDonotemail() {
        contactData.setDonotemail(true);
        assertEquals(true, contactData.getDonotemail());
    }

    @Test
    public void testSetAndGetDonotphone() {
        contactData.setDonotphone(false);
        assertEquals(false, contactData.getDonotphone());
    }

    @Test
    public void testSetAndGetDonotpostalmail() {
        contactData.setDonotpostalmail(true);
        assertEquals(true, contactData.getDonotpostalmail());
    }

    @Test
    public void testSetAndGetParentcustomerid() {
        contactData.setParentcustomerid("parent123");
        assertEquals("parent123", contactData.getParentcustomerid());
    }

    @Test
    public void testSetAndGetParentcontactid() {
        contactData.setParentcontactid("parentcontact123");
        assertEquals("parentcontact123", contactData.getParentcontactid());
    }

    @Test
    public void testSetAndGetAddress1City() {
        contactData.setAddress1_city("City");
        assertEquals("City", contactData.getAddress1_city());
    }

    @Test
    public void testSetAndGetAddress1Composite() {
        contactData.setAddress1_composite("Composite Address");
        assertEquals("Composite Address", contactData.getAddress1_composite());
    }

    @Test
    public void testSetAndGetAddress1Country() {
        contactData.setAddress1_country("Country");
        assertEquals("Country", contactData.getAddress1_country());
    }

    @Test
    public void testSetAndGetAddress1County() {
        contactData.setAddress1_county("County");
        assertEquals("County", contactData.getAddress1_county());
    }

    @Test
    public void testSetAndGetAddress1Line1() {
        contactData.setAddress1_line1("Line 1");
        assertEquals("Line 1", contactData.getAddress1_line1());
    }

    @Test
    public void testSetAndGetAddress1Line2() {
        contactData.setAddress1_line2("Line 2");
        assertEquals("Line 2", contactData.getAddress1_line2());
    }

    @Test
    public void testSetAndGetAddress1Line3() {
        contactData.setAddress1_line3("Line 3");
        assertEquals("Line 3", contactData.getAddress1_line3());
    }

    @Test
    public void testSetAndGetAddress1Name() {
        contactData.setAddress1_name("Name");
        assertEquals("Name", contactData.getAddress1_name());
    }

    @Test
    public void testSetAndGetAddress1Postalcode() {
        contactData.setAddress1_postalcode("Postal Code");
        assertEquals("Postal Code", contactData.getAddress1_postalcode());
    }

    @Test
    public void testSetAndGetBirthdate() {
        contactData.setBirthdate("2000-01-01");
        assertEquals("2000-01-01", contactData.getBirthdate());
    }

    @Test
    public void testSetAndGetDescription() {
        contactData.setDescription("Description");
        assertEquals("Description", contactData.getDescription());
    }

    @Test
    public void testSetAndGetEmailaddress1() {
        contactData.setEmailaddress1("email@example.com");
        assertEquals("email@example.com", contactData.getEmailaddress1());
    }

    @Test
    public void testSetAndGetFirstname() {
        contactData.setFirstname("First Name");
        assertEquals("First Name", contactData.getFirstname());
    }

    @Test
    public void testSetAndGetFos_addressid() {
        contactData.setFos_addressid("Address ID");
        assertEquals("Address ID", contactData.getFos_addressid());
    }

    @Test
    public void testSetAndGetFos_fcaid() {
        contactData.setFos_fcaid("FCA ID");
        assertEquals("FCA ID", contactData.getFos_fcaid());
    }

    @Test
    public void testSetAndGetFos_needstring() {
        contactData.setFos_needstring("Need String");
        assertEquals("Need String", contactData.getFos_needstring());
    }

    @Test
    public void testSetAndGetFos_othertitle() {
        contactData.setFos_othertitle("Other Title");
        assertEquals("Other Title", contactData.getFos_othertitle());
    }

    @Test
    public void testSetAndGetFullname() {
        contactData.setFullname("Full Name");
        assertEquals("Full Name", contactData.getFullname());
    }

    @Test
    public void testSetAndGetJobtitle() {
        contactData.setJobtitle("Job Title");
        assertEquals("Job Title", contactData.getJobtitle());
    }

    @Test
    public void testSetAndGetLastname() {
        contactData.setLastname("Last Name");
        assertEquals("Last Name", contactData.getLastname());
    }

    @Test
    public void testSetAndGetMiddlename() {
        contactData.setMiddlename("Middle Name");
        assertEquals("Middle Name", contactData.getMiddlename());
    }

    @Test
    public void testSetAndGetMsa_managingpartneridname() {
        contactData.setMsa_managingpartneridname("Partner Name");
        assertEquals("Partner Name", contactData.getMsa_managingpartneridname());
    }

    @Test
    public void testSetAndGetSalutation() {
        contactData.setSalutation("Salutation");
        assertEquals("Salutation", contactData.getSalutation());
    }

    @Test
    public void testSetAndGetSuffix() {
        contactData.setSuffix("Suffix");
        assertEquals("Suffix", contactData.getSuffix());
    }

    @Test
    public void testSetAndGetTelephone1() {
        contactData.setTelephone1("1234567890");
        assertEquals("1234567890", contactData.getTelephone1());
    }
    
    
    @Test
    public void testSetAndGetTelephone2() {
        contactData.setTelephone2("1234567890");
        assertEquals("1234567890", contactData.getTelephone2());
    }
    
    
    
    @Test
    public void testSetAndGetVersionnumber() {
        contactData.setVersionnumber(80L);
        assertEquals(80L, contactData.getVersionnumber());
    }
    
    

   
    
    @Test
    public void testSetAndGetCreate() {
        contactData.setCreatedon("1234567890");
        assertEquals("1234567890", contactData.getCreatedon());
    }
    
    
    @Test
    public void testSetAndGetModifiedon() {
        contactData.setModifiedon("1234567890");
        assertEquals("1234567890", contactData.getModifiedon());
    }
    
    
    @Test
    public void testSetAndGetCreatedBy() {
        contactData.setCreatedby("1234567890");
        assertEquals("1234567890", contactData.getCreatedby());
    }
    
    
    @Test
    public void testSetAndGetModifiedby() {
        contactData.setModifiedby("1234567890");
        assertEquals("1234567890", contactData.getModifiedby());
    }
    
    @Test
    public void testGetModifiedonSorting() {
        contactData.setModifiedon("2023-01-01T10:15:30Z");
        LocalDateTime expectedDateTime = LocalDateTime.of(2023, 1, 1, 10, 15, 30);
        assertEquals(expectedDateTime, contactData.getModifiedonSorting());
    }
    

    
    @Test
    public void testSetAndGetIncrementalloadjobaudit() {
        contactData.setIncrementaldataloadjobauditid("1234567890");
        assertEquals("1234567890", contactData.getIncrementaldataloadjobauditid());
    }

	

	

}