package com.ombudsman.service.model;

import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class AccountDataTest {

    private AccountData accountData;

    @BeforeEach
    void setUp() {
        accountData = new AccountData();
    }

    @Test
    void testGetterAndSetterMethods() {
        accountData.setAccountid("12345");
        assertEquals("12345", accountData.getAccountid());

        accountData.setAccountcategorycode(10L);
        assertEquals(10L, accountData.getAccountcategorycode());

        accountData.setDonotemail(true);
        assertTrue(accountData.getDonotemail());

        accountData.setDonotphone(false);
        assertFalse(accountData.getDonotphone());

        accountData.setDonotpostalmail(true);
        assertTrue(accountData.getDonotpostalmail());

        accountData.setName("Test Account");
        assertEquals("Test Account", accountData.getName());

        accountData.setModifiedon("2025-01-01T12:00:00Z");
        assertEquals("2025-01-01T12:00:00Z", accountData.getModifiedon());

        accountData.setAddress1_city("New York");
        assertEquals("New York", accountData.getAddress1_city());

        accountData.setAddress1_postalcode("10001");
        assertEquals("10001", accountData.getAddress1_postalcode());

        accountData.setAddress1_line1("123 Test Street");
        assertEquals("123 Test Street", accountData.getAddress1_line1());

        accountData.setParentaccountid("parent123");
        assertEquals("parent123", accountData.getParentaccountid());
    }

    @Test
    void testGetModifiedonSorting() {
        String modifiedon = "2025-01-01T12:00:00Z";
        accountData.setModifiedon(modifiedon);

        LocalDateTime expectedDateTime = LocalDateTime.parse(modifiedon, DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss'Z'"));
        assertEquals(expectedDateTime, accountData.getModifiedonSorting());
    }

    @Test
    void testSetAndGetBooleanFields() {
        accountData.setDonotemail(true);
        accountData.setDonotphone(false);
        accountData.setDonotpostalmail(true);

        assertTrue(accountData.getDonotemail());
        assertFalse(accountData.getDonotphone());
        assertTrue(accountData.getDonotpostalmail());
    }

    @Test
    void testSetAndGetAddressFields() {
        accountData.setAddress1_city("New York");
        accountData.setAddress1_postalcode("10001");
        accountData.setAddress1_line1("123 Test Street");

        assertEquals("New York", accountData.getAddress1_city());
        assertEquals("10001", accountData.getAddress1_postalcode());
        assertEquals("123 Test Street", accountData.getAddress1_line1());
    }

    @Test
    void testSetAndGetParentAccountId() {
        accountData.setParentaccountid("parent123");
        assertEquals("parent123", accountData.getParentaccountid());
    }

    @Test
    void testEdgeCases() {
        accountData.setName(null);
        assertNull(accountData.getName());

        accountData.setAddress1_city("");
        assertEquals("", accountData.getAddress1_city());

        accountData.setModifiedon("");
        assertEquals("", accountData.getModifiedon());
    }

    @Test
    void testAllFields() {
        accountData.setAccountid("123");
        accountData.setName("Sample Name");
        accountData.setDonotemail(true);
        accountData.setDonotphone(false);
        accountData.setDonotpostalmail(true);
        accountData.setParentaccountid("ParentID");
        accountData.setAddress1_city("Sample City");
        accountData.setAddress1_postalcode("00000");
        accountData.setAddress1_line1("123 Test Street");
        accountData.setModifiedon("2025-12-31T23:59:59Z");
        
        
       

        assertEquals("123", accountData.getAccountid());
        assertEquals("Sample Name", accountData.getName());
        assertTrue(accountData.getDonotemail());
        assertFalse(accountData.getDonotphone());
        assertTrue(accountData.getDonotpostalmail());
        assertEquals("ParentID", accountData.getParentaccountid());
        assertEquals("Sample City", accountData.getAddress1_city());
        assertEquals("00000", accountData.getAddress1_postalcode());
        assertEquals("123 Test Street", accountData.getAddress1_line1());
        assertEquals("2025-12-31T23:59:59Z", accountData.getModifiedon());
        
        
        
        
        
        
        accountData.setParentaccountidname("parent");
        accountData.setFos_hierarchylevelname("hier");
        accountData.setFos_businesstypecode_txt("Buiss");
        
        
        assertEquals("parent", accountData.getParentaccountidname());
        assertEquals("hier", accountData.getFos_hierarchylevelname());
        assertEquals("Buiss", accountData.getFos_businesstypecode_txt());
        
        
        
        accountData.setBusinesstypecode(25L);
        accountData.setFos_approvalstatus(25L);
        accountData.setFos_hierarchylevel(25L);
        
        
        assertEquals(25L, accountData.getBusinesstypecode());
        assertEquals(25L, accountData.getFos_approvalstatus());
        assertEquals(25L, accountData.getFos_hierarchylevel());
        
        
        
        
        
        accountData.setFos_legalstatus(25L);
        accountData.setFos_nametype(25L);
        accountData.setPreferredcontactmethodcode(25L);
        
        
        assertEquals(25L, accountData.getFos_legalstatus());
        assertEquals(25L, accountData.getFos_nametype());
        assertEquals(25L, accountData.getPreferredcontactmethodcode());
        
        


    	
    }
        @Test
        public void testSetAndGetAccountnumber() {
            accountData.setAccountnumber("123456");
            assertEquals("123456", accountData.getAccountnumber());
        }

        @Test
        public void testSetAndGetAddress1Composite() {
            accountData.setAddress1_composite("Address 1 Composite");
            assertEquals("Address 1 Composite", accountData.getAddress1_composite());
        }

        @Test
        public void testSetAndGetAddress1Country() {
            accountData.setAddress1_country("Country");
            assertEquals("Country", accountData.getAddress1_country());
        }

        @Test
        public void testSetAndGetAddress1County() {
            accountData.setAddress1_county("County");
            assertEquals("County", accountData.getAddress1_county());
        }

        @Test
        public void testSetAndGetAddress1Line2() {
            accountData.setAddress1_line2("Address Line 2");
            assertEquals("Address Line 2", accountData.getAddress1_line2());
        }

        @Test
        public void testSetAndGetAddress1Line3() {
            accountData.setAddress1_line3("Address Line 3");
            assertEquals("Address Line 3", accountData.getAddress1_line3());
        }

        @Test
        public void testSetAndGetAddress1Name() {
            accountData.setAddress1_name("Address 1 Name");
            assertEquals("Address 1 Name", accountData.getAddress1_name());
        }

        @Test
        public void testSetAndGetAddress1StateOrProvince() {
            accountData.setAddress1_stateorprovince("State Or Province");
            assertEquals("State Or Province", accountData.getAddress1_stateorprovince());
        }

        @Test
        public void testSetAndGetAddress2City() {
            accountData.setAddress2_city("City");
            assertEquals("City", accountData.getAddress2_city());
        }

        @Test
        public void testSetAndGetAddress2Composite() {
            accountData.setAddress2_composite("Address 2 Composite");
            assertEquals("Address 2 Composite", accountData.getAddress2_composite());
        }

        @Test
        public void testSetAndGetAddress2Country() {
            accountData.setAddress2_country("Country");
            assertEquals("Country", accountData.getAddress2_country());
        }

        @Test
        public void testSetAndGetAddress2County() {
            accountData.setAddress2_county("County");
            assertEquals("County", accountData.getAddress2_county());
        }

        @Test
        public void testSetAndGetAddress2Line1() {
            accountData.setAddress2_line1("Address Line 1");
            assertEquals("Address Line 1", accountData.getAddress2_line1());
        }

        @Test
        public void testSetAndGetAddress2Line2() {
            accountData.setAddress2_line2("Address Line 2");
            assertEquals("Address Line 2", accountData.getAddress2_line2());
        }

        @Test
        public void testSetAndGetAddress2Line3() {
            accountData.setAddress2_line3("Address Line 3");
            assertEquals("Address Line 3", accountData.getAddress2_line3());
        }

        @Test
        public void testSetAndGetAddress2Name() {
            accountData.setAddress2_name("Address 2 Name");
            assertEquals("Address 2 Name", accountData.getAddress2_name());
        }

        @Test
        public void testSetAndGetAddress2Postalcode() {
            accountData.setAddress2_postalcode("Postal Code");
            assertEquals("Postal Code", accountData.getAddress2_postalcode());
        }

        @Test
        public void testSetAndGetAddress2StateOrProvince() {
            accountData.setAddress2_stateorprovince("State Or Province");
            assertEquals("State Or Province", accountData.getAddress2_stateorprovince());
        }

        @Test
        public void testSetAndGetEmailaddress1() {
            accountData.setEmailaddress1("email@example.com");
            assertEquals("email@example.com", accountData.getEmailaddress1());
        }

        @Test
        public void testSetAndGetFosFcareference() {
            accountData.setFos_fcareference("FCA Reference");
            assertEquals("FCA Reference", accountData.getFos_fcareference());
        }

        @Test
        public void testSetAndGetFosShortname() {
            accountData.setFos_shortname("Short Name");
            assertEquals("Short Name", accountData.getFos_shortname());
        }

        @Test
        public void testSetAndGetFosLegalstatusname() {
            accountData.setFos_legalstatusname("Legal Status Name");
            assertEquals("Legal Status Name", accountData.getFos_legalstatusname());
        }

        @Test
        public void testSetAndGetName() {
            accountData.setName("Name");
            assertEquals("Name", accountData.getName());
        }

        @Test
        public void testSetAndGetWebsiteurl() {
            accountData.setWebsiteurl("http://example.com");
            assertEquals("http://example.com", accountData.getWebsiteurl());
        }

        @Test
        public void testSetAndGetVersionnumber() {
            accountData.setVersionnumber(1L);
            assertEquals(1L, accountData.getVersionnumber());
        }

        @Test
        public void testSetAndGetCreatedon() {
            accountData.setCreatedon("2023-01-01");
            assertEquals("2023-01-01", accountData.getCreatedon());
        }

        @Test
        public void testSetAndGetCreatedby() {
            accountData.setCreatedby("Created By");
            assertEquals("Created By", accountData.getCreatedby());
        }

        @Test
        public void testSetAndGetModifiedby() {
            accountData.setModifiedby("Modified By");
            assertEquals("Modified By", accountData.getModifiedby());
        }

        @Test
        public void testSetAndGetIncrementaldataloadjobauditid() {
            accountData.setIncrementaldataloadjobauditid("Job Audit ID");
            assertEquals("Job Audit ID", accountData.getIncrementaldataloadjobauditid());
        }

}
