package com.ombudsman.service.model;

import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.time.LocalDateTime;
import java.util.UUID;

public class IncreLoadAuditDataTest {

    private IncreLoadAuditData increLoadAuditData;

    @BeforeEach
    public void setUp() {
        increLoadAuditData = new IncreLoadAuditData();
    }

    @Test
    public void testGettersAndSetters() {
        UUID id = UUID.randomUUID();
        increLoadAuditData.setIncremental_data_load_audit_id(id);
        increLoadAuditData.setJob_id(1);
        increLoadAuditData.setTotal_number_of_records(100);
        increLoadAuditData.setNumber_of_processed_record(90);
        increLoadAuditData.setNumber_of_failed_record(10);
        increLoadAuditData.setCurrent_job_status_id(2);
        increLoadAuditData.setJob_close_datetime("2023-01-01T10:15:30Z");
        increLoadAuditData.setNext_job_run_datetime("2023-01-02T10:15:30Z");
        increLoadAuditData.setSource("Source");
        LocalDateTime now = LocalDateTime.now();
        increLoadAuditData.setCreated_on(now);
        increLoadAuditData.setJobStartDateTime(now.minusDays(1));
        increLoadAuditData.setModified_on("2023-01-01T12:00:00Z");
        increLoadAuditData.setCreated_by("CreatedBy");
        increLoadAuditData.setModified_by("ModifiedBy");
       

        assertEquals(id, increLoadAuditData.getIncremental_data_load_audit_id());
        assertEquals(1, increLoadAuditData.getJob_id());
        assertEquals(100, increLoadAuditData.getTotal_number_of_records());
        assertEquals(90, increLoadAuditData.getNumber_of_processed_record());
        assertEquals(10, increLoadAuditData.getNumber_of_failed_record());
        assertEquals(2, increLoadAuditData.getCurrent_job_status_id());
        assertEquals("2023-01-01T10:15:30Z", increLoadAuditData.getJob_close_datetime());
        assertEquals("2023-01-02T10:15:30Z", increLoadAuditData.getNext_job_run_datetime());
        assertEquals("Source", increLoadAuditData.getSource());
        assertEquals(now, increLoadAuditData.getCreated_on());
        assertEquals(now.minusDays(1), increLoadAuditData.getJobStartDateTime());
        assertEquals("2023-01-01T12:00:00Z", increLoadAuditData.getModified_on());
        assertEquals("CreatedBy", increLoadAuditData.getCreated_by());
        assertEquals("ModifiedBy", increLoadAuditData.getModified_by());
       
    }
}
