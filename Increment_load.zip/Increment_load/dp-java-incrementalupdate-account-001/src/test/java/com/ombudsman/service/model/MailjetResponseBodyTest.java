package com.ombudsman.service.model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.Arrays;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.ombudsman.service.model.MailjetResponseBody;
import com.ombudsman.service.model.MailjetResponseBody.Message;
import com.ombudsman.service.model.MailjetResponseBody.Recipient;

public class MailjetResponseBodyTest {

    private MailjetResponseBody mailjetResponseBody;

    @BeforeEach
    public void setUp() {
        mailjetResponseBody = new MailjetResponseBody();
    }

    @Test
    public void testMessages() {
        // Given
        Message message = new Message();
        message.setStatus("success");
        Recipient recipient = new Recipient();
        recipient.setEmail("test@example.com");
        message.setTo(Arrays.asList(recipient));
        
        // When
        mailjetResponseBody.setMessages(Arrays.asList(message));
        
        // Then
        assertEquals(1, mailjetResponseBody.getMessages().size());
        assertEquals("success", mailjetResponseBody.getMessages().get(0).getStatus());
        assertEquals("test@example.com", mailjetResponseBody.getMessages().get(0).getTo().get(0).getEmail());
    }
}
