package com.ombudsman.service.model;



import java.util.List;

import com.google.gson.annotations.SerializedName;

   
public class SendMailReq {

   @SerializedName("Messages")
   List<Messages> Messages;


    public void setMessages(List<Messages> Messages) {
        this.Messages = Messages;
    }
    public List<Messages> getMessages() {
        return Messages;
    }
    
}
