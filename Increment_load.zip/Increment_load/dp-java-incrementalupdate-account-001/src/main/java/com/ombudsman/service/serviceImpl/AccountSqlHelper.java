package com.ombudsman.service.serviceImpl;

import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ombudsman.service.common.Constantsconfig;
import com.ombudsman.service.model.AccountData;
import com.ombudsman.service.model.ContactData;
import com.ombudsman.service.repo.AccountRepository;
import com.ombudsman.service.repo.ContactRepository;
import com.ombudsman.service.repo.IncreLoadAuditRepository;
import com.ombudsman.service.repo.IncreLoadErrorRepository;

/**
 * 
 * @author swatiamlani This class will be used for inserting data into STG
 *         tables and Stored procedure call
 *
 */

@Service
public class AccountSqlHelper {

	@Autowired
	Constantsconfig constant;

	@Autowired
	AccountRepository accountRep;

	@Autowired
	IncreLoadAuditRepository increLoadAuditRep;

	@Autowired
	IncreLoadErrorRepository increLoadErrorRep;

	@Autowired
	ContactRepository contactRep;

	Logger LOG = LogManager.getRootLogger();

	public void insertHelpercontact(ContactData contactd, String Fetch_IncrementalDataLoadAuditId) {

		contactRep.InsertQuery(contactd.getContactid(), contactd.getStatecode(), contactd.getFos_capacity(),
				contactd.getFos_contactdescriptionoption(), contactd.getFos_digitalportalinvitestatus(),
				contactd.getFos_isdigitalportaladmin(), contactd.getFos_parentorganisationcapacity(),
				contactd.getFos_phonerecordingconsent(), contactd.getFos_preferredmethodofcorrespondencecode(),
				contactd.getFos_surveyconsentcode(), contactd.getGendercode(), contactd.getPreferredcontactmethodcode(),
				contactd.getDonotemail(), contactd.getDonotphone(), contactd.getDonotpostalmail(),
				contactd.getParentcontactid(), contactd.getParentcustomerid(), contactd.getAddress1_city(),
				contactd.getAddress1_composite(), contactd.getAddress1_country(), contactd.getAddress1_county(),
				contactd.getAddress1_line1(), contactd.getAddress1_line2(), contactd.getAddress1_line3(),
				contactd.getAddress1_name(), contactd.getAddress1_postalcode(), contactd.getBirthdate(),
				contactd.getDescription(), contactd.getEmailaddress1(), contactd.getFirstname(),
				contactd.getFos_addressid(), contactd.getFos_fcaid(), contactd.getFos_needstring(),
				contactd.getFos_othertitle(), contactd.getFullname(), contactd.getJobtitle(), contactd.getLastname(),
				contactd.getMiddlename(), contactd.getMsa_managingpartneridname(), contactd.getSalutation(),
				contactd.getSuffix(), contactd.getTelephone1(), contactd.getTelephone2(), contactd.getVersionnumber(),
				contactd.getCreatedon(), contactd.getModifiedon(), contactd.getCreatedby(), contactd.getModifiedby(),
				contactd.getFos_customeraddressid(),
				Fetch_IncrementalDataLoadAuditId);

	}

	public void insertHelper(AccountData accountd, String Fetch_IncrementalDataLoadAuditId) {

		accountRep.InsertQuery(accountd.getAccountid(), accountd.getAccountcategorycode(),
				accountd.getBusinesstypecode(), accountd.getFos_approvalstatus(), accountd.getFos_hierarchylevel(),
				accountd.getFos_legalstatus(), accountd.getFos_nametype(), accountd.getPreferredcontactmethodcode(),
				accountd.getDonotemail(), accountd.getDonotphone(), accountd.getDonotpostalmail(),
				accountd.getParentaccountid(), accountd.getAccountnumber(), accountd.getAddress1_city(),
				accountd.getAddress1_composite(), accountd.getAddress1_country(), accountd.getAddress1_county(),
				accountd.getAddress1_line1(), accountd.getAddress1_line2(), accountd.getAddress1_line3(),
				accountd.getAddress1_name(), accountd.getAddress1_postalcode(), accountd.getAddress1_stateorprovince(),
				accountd.getAddress2_city(), accountd.getAddress2_composite(), accountd.getAddress2_country(),
				accountd.getAddress2_county(), accountd.getAddress2_line1(), accountd.getAddress2_line2(),
				accountd.getAddress2_line3(), accountd.getAddress2_name(), accountd.getAddress2_postalcode(),
				accountd.getAddress2_stateorprovince(), accountd.getEmailaddress1(), accountd.getFos_fcareference(),
				accountd.getFos_shortname(), accountd.getFos_legalstatusname(), accountd.getName(),
				accountd.getWebsiteurl(), accountd.getVersionnumber(), accountd.getCreatedon(),
				accountd.getModifiedon(), accountd.getCreatedby(), accountd.getModifiedby(),
				accountd.getFos_businesstypecode_txt(), accountd.getParentaccountidname(),
				accountd.getFos_hierarchylevelname(), Fetch_IncrementalDataLoadAuditId,
				accountd.getFos_organisationcapacity(), accountd.getStatecode());

	}

	@Transactional
	public void insertContact(ArrayList<ContactData> arrayListContactData, String Fetch_IncrementalDataLoadAuditId) {

		LOG.info(String.format("Total records for %s for  Insertion are : %s ", constant.Contact,
				arrayListContactData.size()));

		for (ContactData contactd : arrayListContactData) {

			if (contactd.getParentcustomerid() != null) {
				insertHelpercontact(contactd, Fetch_IncrementalDataLoadAuditId);

			}

		}

		LOG.info(String.format("Total records for %s for  Insertquery are : %s ", constant.Entity_Account,
				arrayListContactData.size()));

	}

	@Transactional
	public void insertAccount(ArrayList<AccountData> arrayListAccountData, String Fetch_IncrementalDataLoadAuditId) {
		Instant startInsert = Instant.now();
		for (AccountData accountd : arrayListAccountData) {

			if (accountd.getAccountid() != null) {
				insertHelper(accountd, Fetch_IncrementalDataLoadAuditId);

			}

		}
		Instant finishInsert = Instant.now();

		long timeElapsedInsert = Duration.between(startInsert, finishInsert).toMillis();
		LOG.info(String.format("Time taken for %s for insert queries is : %s ms", constant.Entity_Account,
				timeElapsedInsert));
	}

}
