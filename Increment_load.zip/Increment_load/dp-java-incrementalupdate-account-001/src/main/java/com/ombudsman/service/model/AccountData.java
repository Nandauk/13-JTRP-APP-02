package com.ombudsman.service.model;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonFormat.Shape;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "stg_account")
public class AccountData {

	@Id
	private String accountid;
	private Long accountcategorycode;
	private Long businesstypecode;
	private Long fos_approvalstatus;
	private Long fos_hierarchylevel;
	private Long fos_legalstatus;
	private Long fos_nametype;
	private Long preferredcontactmethodcode;
	@JsonFormat(shape = Shape.NUMBER)
	private Boolean donotemail;
	@JsonFormat(shape = Shape.NUMBER)
	private Boolean donotphone;
	@JsonFormat(shape = Shape.NUMBER)
	private Boolean donotpostalmail;
	private String parentaccountid;
	private String accountnumber;
	private String address1_city;
	private String address1_composite;
	private String address1_country;
	private String address1_county;
	private String address1_line1;
	private String address1_line2;
	private String address1_line3;
	private String address1_name;
	private String address1_postalcode;
	private String address1_stateorprovince;
	private String address2_city;
	private String address2_composite;
	private String address2_country;
	private String address2_county;
	private String address2_line1;
	private String address2_line2;
	private String address2_line3;
	private String address2_name;
	private String address2_postalcode;
	private String address2_stateorprovince;
	private String emailaddress1;
	private String fos_fcareference;
	private String fos_shortname;
	private String fos_legalstatusname;
	private String name;
	private String fos_businesstypecode_txt;
	private String parentaccountidname;
	private String fos_hierarchylevelname;
	private String websiteurl;
	private Long versionnumber;

	private String createdon;
	private String modifiedon;
	private String createdby;
	private String modifiedby;
	private String incrementaldataloadjobauditid;
	private Long fos_organisationcapacity;
	private Long statecode;

	public Long getFos_organisationcapacity() {
		return fos_organisationcapacity;
	}

	public void setFos_organisationcapacity(Long fos_organisationcapacity) {
		this.fos_organisationcapacity = fos_organisationcapacity;
	}

	public String getParentaccountidname() {
		return parentaccountidname;
	}

	public void setParentaccountidname(String parentaccountidname) {
		this.parentaccountidname = parentaccountidname;
	}

	public String getFos_hierarchylevelname() {
		return fos_hierarchylevelname;
	}

	public void setFos_hierarchylevelname(String fos_hierarchylevelname) {
		this.fos_hierarchylevelname = fos_hierarchylevelname;
	}

	public String getFos_businesstypecode_txt() {
		return fos_businesstypecode_txt;
	}

	public void setFos_businesstypecode_txt(String fos_businesstypecode_txt) {
		this.fos_businesstypecode_txt = fos_businesstypecode_txt;
	}

	public Long getStatecode() {
		return statecode;
	}

	public void setStatecode(Long statecode) {
		this.statecode = statecode;
	}

	public Long getAccountcategorycode() {
		return accountcategorycode;
	}

	public void setAccountcategorycode(Long accountcategorycode) {
		this.accountcategorycode = accountcategorycode;
	}

	public Long getBusinesstypecode() {
		return businesstypecode;
	}

	public void setBusinesstypecode(Long businesstypecode) {
		this.businesstypecode = businesstypecode;
	}

	public Long getFos_approvalstatus() {
		return fos_approvalstatus;
	}

	public void setFos_approvalstatus(Long fos_approvalstatus) {
		this.fos_approvalstatus = fos_approvalstatus;
	}

	public Long getFos_hierarchylevel() {
		return fos_hierarchylevel;
	}

	public void setFos_hierarchylevel(Long fos_hierarchylevel) {
		this.fos_hierarchylevel = fos_hierarchylevel;
	}

	public Long getFos_legalstatus() {
		return fos_legalstatus;
	}

	public void setFos_legalstatus(Long fos_legalstatus) {
		this.fos_legalstatus = fos_legalstatus;
	}

	public Long getFos_nametype() {
		return fos_nametype;
	}

	public void setFos_nametype(Long fos_nametype) {
		this.fos_nametype = fos_nametype;
	}

	public Long getPreferredcontactmethodcode() {
		return preferredcontactmethodcode;
	}

	public void setPreferredcontactmethodcode(Long preferredcontactmethodcode) {
		this.preferredcontactmethodcode = preferredcontactmethodcode;
	}

	public Boolean getDonotemail() {
		return donotemail;
	}

	public void setDonotemail(Boolean donotemail) {
		this.donotemail = donotemail;
	}

	public Boolean getDonotphone() {
		return donotphone;
	}

	public void setDonotphone(Boolean donotphone) {
		this.donotphone = donotphone;
	}

	public Boolean getDonotpostalmail() {
		return donotpostalmail;
	}

	public void setDonotpostalmail(Boolean donotpostalmail) {
		this.donotpostalmail = donotpostalmail;
	}

	public String getAccountnumber() {
		return accountnumber;
	}

	public void setAccountnumber(String accountnumber) {
		this.accountnumber = accountnumber;
	}

	public String getAddress1_city() {
		return address1_city;
	}

	public void setAddress1_city(String address1_city) {
		this.address1_city = address1_city;
	}

	public String getAddress1_composite() {
		return address1_composite;
	}

	public void setAddress1_composite(String address1_composite) {
		this.address1_composite = address1_composite;
	}

	public String getAddress1_country() {
		return address1_country;
	}

	public void setAddress1_country(String address1_country) {
		this.address1_country = address1_country;
	}

	public String getAddress1_county() {
		return address1_county;
	}

	public void setAddress1_county(String address1_county) {
		this.address1_county = address1_county;
	}

	public String getAddress1_line1() {
		return address1_line1;
	}

	public void setAddress1_line1(String address1_line1) {
		this.address1_line1 = address1_line1;
	}

	public String getAddress1_line2() {
		return address1_line2;
	}

	public void setAddress1_line2(String address1_line2) {
		this.address1_line2 = address1_line2;
	}

	public String getAddress1_line3() {
		return address1_line3;
	}

	public void setAddress1_line3(String address1_line3) {
		this.address1_line3 = address1_line3;
	}

	public String getAddress1_name() {
		return address1_name;
	}

	public void setAddress1_name(String address1_name) {
		this.address1_name = address1_name;
	}

	public String getAddress1_postalcode() {
		return address1_postalcode;
	}

	public void setAddress1_postalcode(String address1_postalcode) {
		this.address1_postalcode = address1_postalcode;
	}

	public String getAddress1_stateorprovince() {
		return address1_stateorprovince;
	}

	public void setAddress1_stateorprovince(String address1_stateorprovince) {
		this.address1_stateorprovince = address1_stateorprovince;
	}

	public String getAddress2_city() {
		return address2_city;
	}

	public void setAddress2_city(String address2_city) {
		this.address2_city = address2_city;
	}

	public String getAddress2_composite() {
		return address2_composite;
	}

	public void setAddress2_composite(String address2_composite) {
		this.address2_composite = address2_composite;
	}

	public String getAddress2_country() {
		return address2_country;
	}

	public void setAddress2_country(String address2_country) {
		this.address2_country = address2_country;
	}

	public String getAddress2_county() {
		return address2_county;
	}

	public void setAddress2_county(String address2_county) {
		this.address2_county = address2_county;
	}

	public String getAddress2_line1() {
		return address2_line1;
	}

	public void setAddress2_line1(String address2_line1) {
		this.address2_line1 = address2_line1;
	}

	public String getAddress2_line2() {
		return address2_line2;
	}

	public void setAddress2_line2(String address2_line2) {
		this.address2_line2 = address2_line2;
	}

	public String getAddress2_line3() {
		return address2_line3;
	}

	public void setAddress2_line3(String address2_line3) {
		this.address2_line3 = address2_line3;
	}

	public String getAddress2_name() {
		return address2_name;
	}

	public void setAddress2_name(String address2_name) {
		this.address2_name = address2_name;
	}

	public String getAddress2_postalcode() {
		return address2_postalcode;
	}

	public void setAddress2_postalcode(String address2_postalcode) {
		this.address2_postalcode = address2_postalcode;
	}

	public String getAddress2_stateorprovince() {
		return address2_stateorprovince;
	}

	public void setAddress2_stateorprovince(String address2_stateorprovince) {
		this.address2_stateorprovince = address2_stateorprovince;
	}

	public String getEmailaddress1() {
		return emailaddress1;
	}

	public void setEmailaddress1(String emailaddress1) {
		this.emailaddress1 = emailaddress1;
	}

	public String getFos_fcareference() {
		return fos_fcareference;
	}

	public void setFos_fcareference(String fos_fcareference) {
		this.fos_fcareference = fos_fcareference;
	}

	public String getFos_shortname() {
		return fos_shortname;
	}

	public void setFos_shortname(String fos_shortname) {
		this.fos_shortname = fos_shortname;
	}

	public String getFos_legalstatusname() {
		return fos_legalstatusname;
	}

	public void setFos_legalstatusname(String fos_legalstatusname) {
		this.fos_legalstatusname = fos_legalstatusname;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getWebsiteurl() {
		return websiteurl;
	}

	public void setWebsiteurl(String websiteurl) {
		this.websiteurl = websiteurl;
	}

	public Long getVersionnumber() {
		return versionnumber;
	}

	public void setVersionnumber(Long versionnumber) {
		this.versionnumber = versionnumber;
	}

	public String getAccountid() {
		return accountid;
	}

	public void setAccountid(String accountid) {
		this.accountid = accountid;
	}

	public String getParentaccountid() {
		return parentaccountid;
	}

	public void setParentaccountid(String parentaccountid) {
		this.parentaccountid = parentaccountid;
	}

	public String getCreatedon() {
		return createdon;
	}

	public void setCreatedon(String createdon) {
		this.createdon = createdon;
	}

	public String getModifiedon() {
		return modifiedon;
	}

	public void setModifiedon(String modifiedon) {
		this.modifiedon = modifiedon;
	}

	public String getCreatedby() {
		return createdby;
	}

	public void setCreatedby(String createdby) {
		this.createdby = createdby;
	}

	public String getModifiedby() {
		return modifiedby;
	}

	public void setModifiedby(String modifiedby) {
		this.modifiedby = modifiedby;
	}

	public String getIncrementaldataloadjobauditid() {
		return incrementaldataloadjobauditid;
	}

	public void setIncrementaldataloadjobauditid(String incrementaldataloadjobauditid) {
		this.incrementaldataloadjobauditid = incrementaldataloadjobauditid;
	}

	public LocalDateTime getModifiedonSorting() {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss'Z'");
		return LocalDateTime.parse(modifiedon, formatter);
	}

}
