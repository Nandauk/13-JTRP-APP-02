package com.ombudsman.service.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.ombudsman.service.model.ContactData;

public interface ContactRepository extends JpaRepository<ContactData, String> {

	@Modifying
	@Transactional
	@Query(value = "INSERT INTO stg_contact(contactid,statecode,fos_capacity,fos_contactdescriptionoption,fos_digitalportalinvitestatus,fos_isdigitalportaladmin,fos_parentorganisationcapacity,fos_phonerecordingconsent,fos_preferredmethodofcorrespondencecode,fos_surveyconsentcode,gendercode,preferredcontactmethodcode,donotemail,donotphone,donotpostalmail,parentcontactid,parentcustomerid,address1_city,address1_composite,address1_country,address1_county,address1_line1,address1_line2,address1_line3,address1_name,address1_postalcode,birthdate,description,emailaddress1,firstname,fos_addressid,fos_fcaid,fos_needstring,fos_othertitle,fullname,jobtitle,lastname,middlename,msa_managingpartneridname,salutation,suffix,telephone1,telephone2,versionnumber,createdby,modifiedby,modifiedon,createdon,fos_customeraddressid,incrementaldataloadjobauditid) VALUES (CONVERT(uniqueidentifier,:contactid),:statecode, :fos_capacity,:fos_contactdescriptionoption,:fos_digitalportalinvitestatus,:fos_isdigitalportaladmin,:fos_parentorganisationcapacity,:fos_phonerecordingconsent,:fos_preferredmethodofcorrespondencecode,:fos_surveyconsentcode,:gendercode,:preferredcontactmethodcode,:donotemail,:donotphone,:donotpostalmail,:parentcontactid,:parentcustomerid,:address1_city,:address1_composite,:address1_country,:address1_county,:address1_line1,:address1_line2,:address1_line3,:address1_name,:address1_postalcode,:birthdate,:description,:emailaddress1,:firstname,:fos_addressid,:fos_fcaid,:fos_needstring,:fos_othertitle,:fullname,:jobtitle,:lastname,:middlename,:msa_managingpartneridname,:salutation,:suffix,:telephone1,:telephone2,:versionnumber,CONVERT(uniqueidentifier,:createdby),CONVERT(uniqueidentifier,:modifiedby),:modifiedon,:createdon,:fos_customeraddressid,CONVERT(uniqueidentifier,:incrementaldataloadjobauditid))", nativeQuery = true)
	int InsertQuery(@Param("contactid") String contactid, @Param("statecode") Long statecode,
			@Param("fos_capacity") Long fos_capacity,
			@Param("fos_contactdescriptionoption") Long fos_contactdescriptionoption,
			@Param("fos_digitalportalinvitestatus") Long fos_digitalportalinvitestatus,
			@Param("fos_isdigitalportaladmin") Long fos_isdigitalportaladmin,
			@Param("fos_parentorganisationcapacity") Long fos_parentorganisationcapacity,
			@Param("fos_phonerecordingconsent") Long fos_phonerecordingconsent,
			@Param("fos_preferredmethodofcorrespondencecode") Long fos_preferredmethodofcorrespondencecode,
			@Param("fos_surveyconsentcode") Long fos_surveyconsentcode, @Param("gendercode") Long gendercode,
			@Param("preferredcontactmethodcode") Long preferredcontactmethodcode,
			@Param("donotemail") Boolean donotemail, @Param("donotphone") Boolean donotphone,
			@Param("donotpostalmail") Boolean donotpostalmail, @Param("parentcontactid") String parentcontactid,
			@Param("parentcustomerid") String parentcustomerid, @Param("address1_city") String address1_city,
			@Param("address1_composite") String address1_composite, @Param("address1_country") String address1_country,
			@Param("address1_county") String address1_county, @Param("address1_line1") String address1_line1,
			@Param("address1_line2") String address1_line2, @Param("address1_line3") String address1_line3,
			@Param("address1_name") String address1_name, @Param("address1_postalcode") String address1_postalcode,
			@Param("birthdate") String birthdate, @Param("description") String description,
			@Param("emailaddress1") String emailaddress1, @Param("firstname") String firstname,
			@Param("fos_addressid") String fos_addressid, @Param("fos_fcaid") String fos_fcaid,
			@Param("fos_needstring") String fos_needstring, @Param("fos_othertitle") String fos_othertitle,
			@Param("fullname") String fullname, @Param("jobtitle") String jobtitle, @Param("lastname") String lastname,
			@Param("middlename") String middlename,
			@Param("msa_managingpartneridname") String msa_managingpartneridname,
			@Param("salutation") String salutation, @Param("suffix") String suffix,
			@Param("telephone1") String telephone1, @Param("telephone2") String telephone2,
			@Param("versionnumber") Long versionnumber, @Param("createdon") String createdon,
			@Param("modifiedon") String modifiedon, @Param("createdby") String createdby,
			@Param("modifiedby") String modifiedby,@Param("fos_customeraddressid") String fos_customeraddressid,
			@Param("incrementaldataloadjobauditid") String incrementaldataloadjobauditid);
}
