package com.ombudsman.service.response;

import java.util.List;

import com.ombudsman.service.model.AccountData;

public class AccountRes {

	private List<AccountData> accountData;

	public List<AccountData> getAccountData() {
		return accountData;
	}

	public void setAccountData(List<AccountData> accountData) {
		this.accountData = accountData;
	}

}