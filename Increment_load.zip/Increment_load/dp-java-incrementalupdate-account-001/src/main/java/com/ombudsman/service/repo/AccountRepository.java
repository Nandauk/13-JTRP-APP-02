package com.ombudsman.service.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.ombudsman.service.model.AccountData;

public interface AccountRepository extends JpaRepository<AccountData, String> {

	@Query(value = "select top (1) modifiedon from account order by modifiedon DESC", nativeQuery = true)
	String findLatestDate();

	@Modifying
	@Transactional
	@Query(value = "INSERT INTO stg_account(accountid,accountcategorycode,businesstypecode,fos_approvalstatus,fos_hierarchylevel,fos_legalstatus,fos_nametype,preferredcontactmethodcode,donotemail,donotphone,donotpostalmail,parentaccountid,accountnumber,address1_city,address1_composite,address1_country,address1_county,address1_line1,address1_line2,address1_line3,address1_name,address1_postalcode,address1_stateorprovince,address2_city,address2_composite,address2_country,address2_county,address2_line1,address2_line2,address2_line3,address2_name,address2_postalcode,address2_stateorprovince,emailaddress1,fos_fcareference,fos_shortname,fos_legalstatusname,name,websiteurl,versionnumber,createdby,modifiedby,modifiedon,createdon,fos_businesstypecode_txt,parentaccountidname,fos_hierarchylevelname,incrementaldataloadjobauditid,fos_organisationcapacity,statecode) VALUES (CONVERT(uniqueidentifier,:accountid),:accountcategorycode, :businesstypecode,:fos_approvalstatus,:fos_hierarchylevel,:fos_legalstatus,:fos_nametype,:preferredcontactmethodcode,:donotemail,:donotphone,:donotpostalmail,CONVERT(uniqueidentifier,:parentaccountid),:accountnumber,:address1_city,:address1_composite,:address1_country,:address1_county,:address1_line1,:address1_line2,:address1_line3,:address1_name,:address1_postalcode,:address1_stateorprovince,:address2_city,:address2_composite,:address2_country,:address2_county,:address2_line1,:address2_line2,:address2_line3,:address2_name,:address2_postalcode,:address2_stateorprovince,:emailaddress1,:fos_fcareference,:fos_shortname,:fos_legalstatusname,:name,:websiteurl,:versionnumber,CONVERT(uniqueidentifier,:createdby),CONVERT(uniqueidentifier,:modifiedby),:modifiedon,:createdon,:fos_businesstypecode_txt,:parentaccountidname,:fos_hierarchylevelname,CONVERT(uniqueidentifier,:incrementaldataloadjobauditid),:fos_organisationcapacity,:statecode)", nativeQuery = true)
	int InsertQuery(@Param("accountid") String accountid, @Param("accountcategorycode") Long accountcategorycode,
			@Param("businesstypecode") Long businesstypecode, @Param("fos_approvalstatus") Long fos_approvalstatus,
			@Param("fos_hierarchylevel") Long fos_hierarchylevel, @Param("fos_legalstatus") Long fos_legalstatus,
			@Param("fos_nametype") Long fos_nametype,
			@Param("preferredcontactmethodcode") Long preferredcontactmethodcode,
			@Param("donotemail") Boolean donotemail, @Param("donotphone") Boolean donotphone,
			@Param("donotpostalmail") Boolean donotpostalmail, @Param("parentaccountid") String parentaccountid,
			@Param("accountnumber") String accountnumber, @Param("address1_city") String address1_city,
			@Param("address1_composite") String address1_composite, @Param("address1_country") String address1_country,
			@Param("address1_county") String address1_county, @Param("address1_line1") String address1_line1,
			@Param("address1_line2") String address1_line2, @Param("address1_line3") String address1_line3,
			@Param("address1_name") String address1_name, @Param("address1_postalcode") String address1_postalcode,
			@Param("address1_stateorprovince") String address1_stateorprovince,
			@Param("address2_city") String address2_city, @Param("address2_composite") String address2_composite,
			@Param("address2_country") String address2_country, @Param("address2_county") String address2_county,
			@Param("address2_line1") String address2_line1, @Param("address2_line2") String address2_line2,
			@Param("address2_line3") String address2_line3, @Param("address2_name") String address2_name,
			@Param("address2_postalcode") String address2_postalcode,
			@Param("address2_stateorprovince") String address2_stateorprovince,
			@Param("emailaddress1") String emailaddress1, @Param("fos_fcareference") String fos_fcareference,
			@Param("fos_shortname") String fos_shortname, @Param("fos_legalstatusname") String fos_legalstatusname,
			@Param("name") String name, @Param("websiteurl") String websiteurl,
			@Param("versionnumber") Long versionnumber, @Param("createdon") String createdon,
			@Param("modifiedon") String modifiedon, @Param("createdby") String createdby,
			@Param("modifiedby") String modifiedby, @Param("fos_businesstypecode_txt") String fos_businesstypecode_txt,
			@Param("parentaccountidname") String parentaccountidname,
			@Param("fos_hierarchylevelname") String fos_hierarchylevelname,
			@Param("incrementaldataloadjobauditid") String incrementaldataloadjobauditid,
			@Param("fos_organisationcapacity") Long fos_organisationcapacity, @Param("statecode") Long statecode);

}
