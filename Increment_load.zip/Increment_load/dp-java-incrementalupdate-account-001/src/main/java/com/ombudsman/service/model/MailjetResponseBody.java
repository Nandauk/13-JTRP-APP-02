package com.ombudsman.service.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.List;

public class MailjetResponseBody {

	private List<Message> messages;

	@JsonProperty("Messages")
	public List<Message> getMessages() {
		return messages;
	}

	public void setMessages(List<Message> messages) {
		this.messages = messages;
	}

	public static class Message {

		private String status;
		private List<Recipient> to;

		@JsonProperty("Status")
		public String getStatus() {
			return status;
		}

		public void setStatus(String status) {
			this.status = status;
		}

		@JsonProperty("To")
		public List<Recipient> getTo() {
			return to;
		}

		public void setTo(List<Recipient> to) {
			this.to = to;
		}

	}

	public static class Recipient {
		private String email;

		@JsonProperty("Email")
		public String getEmail() {
			return email;
		}

		public void setEmail(String email) {
			this.email = email;
		}

	}
}
