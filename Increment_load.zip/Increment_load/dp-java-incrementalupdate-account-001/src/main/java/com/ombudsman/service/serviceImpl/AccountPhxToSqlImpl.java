package com.ombudsman.service.serviceImpl;

import java.io.IOException;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.ombudsman.service.common.Constantsconfig;
import com.ombudsman.service.model.AccountData;
import com.ombudsman.service.model.ContactData;
import com.ombudsman.service.repo.AccountRepository;
import com.ombudsman.service.repo.ContactRepository;
import com.ombudsman.service.repo.IncreLoadAuditRepository;
import com.ombudsman.service.repo.IncreLoadErrorRepository;
import com.ombudsman.service.response.AccountRes;
import com.ombudsman.service.response.ContactRes;
import com.ombudsman.service.services.AccountPhxToSqlService;

/**
 * 
 * @author swatiamlani
 * 
 *         This Service impl class is used to fetch data from phoenix for a
 *         duration of 15 mins and insert it into STG tables.
 *
 */

@Service
public class AccountPhxToSqlImpl implements AccountPhxToSqlService {

	@Autowired
	EmailHelper emailhelper;

	@Autowired
	Constantsconfig constant;

	@Autowired
	AccountRepository accountRep;

	@Autowired
	IncreLoadAuditRepository increLoadAuditRep;

	@Autowired
	IncreLoadErrorRepository increLoadErrorRep;

	@Autowired
	ContactRepository contactRep;

	@Autowired
	AccountSqlHelper accsqlhelper;

	@Autowired
	AccountPhxHelper accphxhelper;

	Logger LOG = LogManager.getRootLogger();

	@Override
	public void accountUpdatePnxtoSql() throws JsonMappingException, JsonProcessingException, IOException {

		String Fetch_IncrementalDataLoadAuditId = null;

		var accountRes = new AccountRes();
		var contactRes = new ContactRes();
		ArrayList<AccountData> arrayListAccountData = new ArrayList<>();
		ArrayList<ContactData> arrayListContactData = new ArrayList<>();
		ArrayList<ContactData> finalarrayListContactData = new ArrayList<>();

		Integer failedCount = 0;
		Long totalSuccessCount = (long) 0;
		int current_status_id_inprogress, current_status_id_readytoprocess;
		int current_status_id_failed, current_status_id_failed_azurfunc, current_status_id_failed_deleterecon;
		Instant startWebJob = Instant.now();
		Set<String> map = new HashSet<>();
		String maxModifedOn = null;
		Long totalRecord = (long) 0;
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS").withZone(ZoneId.of("UTC"));
		String startWebJob_formatted = formatter.format(startWebJob);

		try {
			LOG.info(String.format("WebJob started for  %s  at : %s ", constant.Entity_Account, startWebJob));

			// Check if any job is in failed state in last 7 days.Then exit without doing
			// entry in audit table
			current_status_id_failed = increLoadAuditRep.getCurrentStatusFId(constant.DataSourceName, constant.Failed);
			current_status_id_failed_azurfunc = increLoadAuditRep.getCurrentStatusFId(constant.DataSourceName_AZUNCFUNC,
					constant.Failed);
			current_status_id_failed_deleterecon = increLoadAuditRep
					.getCurrentStatusFId(constant.DataSourceName_DEL_RECON, constant.Failed);

			String last7DaysTimeStamp = java.time.LocalDateTime.now().minusDays(7)
					.format(java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss:SSS"));
			int failedCountLast7days = increLoadAuditRep.getFailedEntries(current_status_id_failed,
					current_status_id_failed_azurfunc, current_status_id_failed_deleterecon, last7DaysTimeStamp);

			if (failedCountLast7days > 0) {
				LOG.info(String.format("Due to some failed entries in audit table, webJob is exiting for %s at :%s.",
						constant.Entity_Account, startWebJob));
				// Send email to support team
				emailhelper.NotificationWebclient(constant.Entity_Account, "NA", constant.DataSourceName,
						"Due to some failed entries in audit table,webJob is exiting", Instant.now().toString());
				//
				return;
			}

			int JobId = increLoadAuditRep.getJobID(constant.Entity_Account);

			current_status_id_inprogress = increLoadAuditRep.getCurrentStatusIPId(constant.DataSourceName,
					constant.In_Progress);

			current_status_id_readytoprocess = increLoadAuditRep.getCurrentStatusRTPId(constant.DataSourceName,
					constant.Ready_To_Process);

			increLoadAuditRep.InsertQuery(JobId, startWebJob_formatted, arrayListAccountData.size(), totalSuccessCount,
					failedCount, current_status_id_inprogress, null, constant.DataSourceName, constant.Entity_Account,
					constant.Entity_Account);

			Fetch_IncrementalDataLoadAuditId = increLoadAuditRep.getIncrementalDataLoadAuditId(startWebJob_formatted,
					current_status_id_inprogress, constant.DataSourceName, constant.Entity_Account);

			String lastupdatedDate = increLoadAuditRep.findLatestDatefromphx(constant.Entity_Account);
			int batchsize = constant.Fetchxml_Record;

			maxModifedOn = accphxhelper.phxAccount(Fetch_IncrementalDataLoadAuditId, accountRes, arrayListAccountData,
					map, startWebJob_formatted, lastupdatedDate, batchsize);
			totalRecord += map.size();

			if (totalRecord != 0) {
				accphxhelper.phxContact(Fetch_IncrementalDataLoadAuditId, contactRes, arrayListContactData, map,
						startWebJob_formatted, lastupdatedDate, batchsize, finalarrayListContactData);
			}

			increLoadAuditRep.UpdateQuery(totalRecord, totalSuccessCount, failedCount, current_status_id_readytoprocess,
					null, Fetch_IncrementalDataLoadAuditId, constant.Entity_Account);

		} catch (Exception e) {
			Instant finishWebJobCatch = Instant.now();
			String emailTime = finishWebJobCatch.toString();
			LOG.error(String.format("ERROR in getting data from phoenix for %s .Error logs : %s:",
					constant.Entity_Account, e.getMessage()));
			LOG.info(String.format("Web job finished for %s  from Catch block at : %s ", constant.Entity_Account,
					finishWebJobCatch));
			long timeElapsedWebJobcatch = Duration.between(startWebJob, finishWebJobCatch).toMillis();
			LOG.info(String.format(
					"****************Total time taken by Webjob for %s  till completion from catch block is :  %s millisec*************** :",
					constant.Entity_Account, timeElapsedWebJobcatch));

			String DataPayload = "Not applicable,Failed at phoenix stage level";
			current_status_id_failed = increLoadAuditRep.getCurrentStatusFId(constant.DataSourceName, constant.Failed);
			// Entry in Error Table
			increLoadErrorRep.InsertQuery(Fetch_IncrementalDataLoadAuditId, DataPayload, current_status_id_failed,
					constant.Error_log, e.getMessage(), constant.Entity_Account, constant.Entity_Account);

			// Entry in Audit table
			increLoadAuditRep.UpdateQuery(totalRecord, totalSuccessCount, failedCount, current_status_id_failed,
					Instant.now().toString(), Fetch_IncrementalDataLoadAuditId, constant.Entity_Account);
			// Send email to support team
			emailhelper.NotificationWebclient(constant.Entity_Account, Fetch_IncrementalDataLoadAuditId,
					constant.DataSourceName, e.getMessage(), emailTime);
			//

			Thread.currentThread().interrupt();
			throw new RuntimeException(
					String.format("Job failed for %s  with Error : %s", constant.Entity_Account, ExceptionUtils.getStackTrace(e)));

		}

		Instant Finalfinish = Instant.now();

		long timeElapsedcompleteJob = Duration.between(startWebJob, Finalfinish).toMillis();
		LOG.info(String.format("***************Total time taken for %s entity for Complete Job  is : %s ms ",
				constant.Entity_Account, timeElapsedcompleteJob));

	}

	@Override
	public void accountUpdatePnxtoSql_recon(String Start_time, String End_time)
			throws JsonMappingException, JsonProcessingException, IOException, InterruptedException {

		String Fetch_IncrementalDataLoadAuditId = null;

		var accountRes = new AccountRes();

		ArrayList<AccountData> arrayListAccountData = new ArrayList<>();

		Integer failedCount = 0;
		Long totalSuccessCount = (long) 0;
		int current_status_id_inprogress, current_status_id_readytoprocess;
		int current_status_id_failed,current_status_id_failed_azurfunc,current_status_id_failed_deleterecon;
		Instant startWebJob = Instant.now();

		String maxModifedOn = null;
		Long totalRecord = (long) 0;
		String startWebJob_formatted = End_time.equals("NA") ? LocalDateTime
				.of(LocalDate.now(), LocalTime.of(22, 59, 0)).format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))
				: End_time;

		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS").withZone(ZoneId.of("UTC"));
		String startWebJob_recon = formatter.format(startWebJob);

		try {
			LOG.info(String.format("WebJob started for  %s  at : %s ", constant.Entity_Account, startWebJob));

			// Check if any job is in failed state in last 7 days.Then exit without doing
			// entry in audit table
			current_status_id_failed = increLoadAuditRep.getCurrentStatusFId(constant.DataSourceName, constant.Failed);
			current_status_id_failed_azurfunc = increLoadAuditRep.getCurrentStatusFId(constant.DataSourceName_AZUNCFUNC,
					constant.Failed);
			current_status_id_failed_deleterecon = increLoadAuditRep
					.getCurrentStatusFId(constant.DataSourceName_DEL_RECON, constant.Failed);

			String last7DaysTimeStamp = java.time.LocalDateTime.now().minusDays(7)
					.format(java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss:SSS"));
			int failedCountLast7days = increLoadAuditRep.getFailedEntries(current_status_id_failed,
					current_status_id_failed_azurfunc, current_status_id_failed_deleterecon, last7DaysTimeStamp);

			if (failedCountLast7days > 0) {
				LOG.info(String.format("Due to some failed entries in audit table, webJob is exiting for %s at :%s.",
						constant.Entity_Account, startWebJob));
				// Send email to support team
				emailhelper.NotificationWebclient(constant.Entity_Account, "NA", constant.DataSourceName,
						"Due to some failed entries in audit table,webJob is exiting", Instant.now().toString());
				//
				return;
			}

			int JobId = increLoadAuditRep.getJobID(constant.Entity_Account);

			current_status_id_inprogress = increLoadAuditRep.getCurrentStatusIPId(constant.DataSourceName,
					constant.In_Progress);

			current_status_id_readytoprocess = increLoadAuditRep.getCurrentStatusRTPId(constant.DataSourceName,
					constant.Ready_To_Process);
			increLoadAuditRep.InsertQuery(JobId, startWebJob_recon, arrayListAccountData.size(), totalSuccessCount,
					failedCount, current_status_id_inprogress, null, constant.DataSourceName, constant.Entity_Account,
					constant.Entity_Account);

			Fetch_IncrementalDataLoadAuditId = increLoadAuditRep.getIncrementalDataLoadAuditId(startWebJob_recon,
					current_status_id_inprogress, constant.DataSourceName, constant.Entity_Account);

			String lastupdatedDate = Start_time.equals("NA")
					? LocalDateTime.of(LocalDate.now().minusDays(1), LocalTime.of(23, 0, 00)).format(
							DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))
					: Start_time;
			int batchsize = constant.Fetchxml_Record;

			totalRecord = accphxhelper.phxAccount_recon(Fetch_IncrementalDataLoadAuditId, accountRes,
					arrayListAccountData, totalRecord, startWebJob_formatted, lastupdatedDate, batchsize);

			maxModifedOn = startWebJob_formatted;

			increLoadAuditRep.UpdateQuery(totalRecord, totalSuccessCount, failedCount, current_status_id_readytoprocess,
					null, Fetch_IncrementalDataLoadAuditId, constant.Entity_Account);

		} catch (Exception e) {
			Instant finishWebJobCatch = Instant.now();

			LOG.error(String.format("ERROR IN getting data from phoenix for %s .Error logs : %s:",
					constant.Entity_Account, e.getMessage()));
			LOG.info(String.format("Web job finished for %s  from Catch block at : %s ", constant.Entity_Account,
					finishWebJobCatch));
			long timeElapsedWebJobcatch = Duration.between(startWebJob, finishWebJobCatch).toMillis();
			LOG.info(String.format(
					"****************Total time taken by Webjob for %s  till completion from catch block is :  %s millisec*************** :",
					constant.Entity_Account, timeElapsedWebJobcatch));

			String DataPayload = "Not applicable,Failed at phoenix stage level";
			current_status_id_failed = increLoadAuditRep.getCurrentStatusFId(constant.DataSourceName, constant.Failed);
			// Entry in Error Table
			increLoadErrorRep.InsertQuery(Fetch_IncrementalDataLoadAuditId, DataPayload, current_status_id_failed,
					constant.Error_log, e.getMessage(), constant.Entity_Account, constant.Entity_Account);

			// Entry in Audit table
			increLoadAuditRep.UpdateQuery(totalRecord, totalSuccessCount, failedCount, current_status_id_failed,
					Instant.now().toString(), Fetch_IncrementalDataLoadAuditId, constant.Entity_Account);

			Thread.currentThread().interrupt();
			throw new RuntimeException(
					String.format("Job failed for %s  with Error : %s", constant.Entity_Account, ExceptionUtils.getStackTrace(e)));

		}

		Instant Finalfinish = Instant.now();

		long timeElapsedcompleteJob = Duration.between(startWebJob, Finalfinish).toMillis();
		LOG.info(String.format("***************Total time taken for %s entity for Complete Job  is : %s ms ",
				constant.Entity_Account, timeElapsedcompleteJob));

	}

}
