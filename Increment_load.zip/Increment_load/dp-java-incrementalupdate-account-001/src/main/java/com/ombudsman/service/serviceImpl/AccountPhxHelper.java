package com.ombudsman.service.serviceImpl;

import java.io.IOException;
import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.ombudsman.service.common.Constantsconfig;
import com.ombudsman.service.common.PhoenixHelper;
import com.ombudsman.service.model.AccountData;
import com.ombudsman.service.model.ContactData;
import com.ombudsman.service.repo.AccountRepository;
import com.ombudsman.service.repo.IncreLoadAuditRepository;
import com.ombudsman.service.response.AccountRes;
import com.ombudsman.service.response.ContactRes;

import okhttp3.HttpUrl;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

/**
 * 
 * @author swatiamlani
 * 
 *         This phxhelper classes contains all phx calls
 *
 */

@Service
public class AccountPhxHelper {

	@Autowired
	Constantsconfig constant;

	@Autowired
	AccountRepository accountRep;

	@Autowired
	PhoenixHelper phoenixHelper;

	@Autowired
	AccountSqlHelper accsqlhelper;

	@Autowired
	IncreLoadAuditRepository increLoadAuditRep;

	Logger LOG = LogManager.getRootLogger();

	public String accountphxhelper(String startWebJob_formatted, AccountRes accountRes,
			ArrayList<AccountData> arrayListAccountData, int Fetchxml_Record, String lastupdatedDate, String entityname,
			Set<String> map, String fetch_IncrementalDataLoadAuditId)
			throws InterruptedException, IOException, JsonProcessingException, JsonMappingException {

		Instant startpnx = Instant.now();
		LOG.info(String.format("Phoenix call started for %s  at : %s ", constant.Entity_Account, startpnx));

		String fetchXml = "";
		String startdate = null;
		LOG.info(String.format("Latest Modified Date for %s  is : %s ", constant.Entity_Account, lastupdatedDate));

		OkHttpClient client = new OkHttpClient.Builder().connectTimeout(60, TimeUnit.SECONDS)
				.writeTimeout(120, TimeUnit.SECONDS).readTimeout(60, TimeUnit.SECONDS).build();
		fetchXml = this.getFetchXML(startWebJob_formatted, lastupdatedDate, Fetchxml_Record, entityname);

		String httpUrl = new HttpUrl.Builder().scheme("https").host(constant.APIM_HOST).addPathSegment("phoniex")
				.addPathSegment("accounts").addQueryParameter("fetchXml", fetchXml).build().toString();

		Request request = phoenixHelper.getPhoenixRequestBuild(httpUrl);
		Response response = client.newCall(request).execute();
		String dataReturned = response.body().string();

		ObjectMapper mapper = new ObjectMapper().registerModule(new JavaTimeModule());

		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		JSONObject jsonObject = new JSONObject(dataReturned);
		JSONArray jsonArray = jsonObject.getJSONArray("value");

		if (jsonArray != null) {
			try {
				for (int i = 0; i < jsonArray.length(); i++) {

					accountValueSet(arrayListAccountData, mapper, jsonArray, i);

				}
			} catch (Exception e) {

				LOG.warn(String.format("CAUGHT EXCEPTION while setting values in arrayList for %s is : %s",
						constant.Entity_Account, e));
			}
		}
		accountRes.setAccountData(arrayListAccountData);
		LOG.info(String.format("Total recs extracted for %s  from Phoenix call are :  %s", constant.Entity_Account,
				arrayListAccountData.size()));
		Instant endpnx = Instant.now();
		long timeElapsedphnx = Duration.between(startpnx, endpnx).toMillis();
		LOG.info(String.format("***************Total time taken for %s entity by Phoenix call is : %s milliseconds ",
				constant.Entity_Account, timeElapsedphnx));

		if (CollectionUtils.isNotEmpty(arrayListAccountData)) {
			arrayListAccountData.sort(Comparator.comparing(AccountData::getModifiedonSorting));
			AccountData maxModifiedonData = arrayListAccountData.get(arrayListAccountData.size() - 1);
			startdate = maxModifiedonData.getModifiedon();
		} else {
			startdate = startWebJob_formatted;
		}
		for (AccountData accdata : arrayListAccountData) {
			map.add(accdata.getAccountid());
		}

		accsqlhelper.insertAccount(arrayListAccountData, fetch_IncrementalDataLoadAuditId);

		return startdate;

	}

	public String accountphxhelper_recon(String startWebJob_formatted, AccountRes accountRes,
			ArrayList<AccountData> arrayListAccountData, int Fetchxml_Record, String lastupdatedDate, String entityname,
			String fetch_IncrementalDataLoadAuditId)
			throws InterruptedException, IOException, JsonProcessingException, JsonMappingException {

		Instant startpnx = Instant.now();
		LOG.info(String.format("Phoenix call started for %s  at : %s ", constant.Entity_Account, startpnx));

		String fetchXml = "";
		String startdate = null;
		LOG.info(String.format("Latest Modified Date for %s  is : %s ", constant.Entity_Account, lastupdatedDate));

		OkHttpClient client = new OkHttpClient.Builder().connectTimeout(60, TimeUnit.SECONDS)
				.writeTimeout(120, TimeUnit.SECONDS).readTimeout(60, TimeUnit.SECONDS).build();
		fetchXml = this.getFetchXML(startWebJob_formatted, lastupdatedDate, Fetchxml_Record, entityname);
		String httpUrl = new HttpUrl.Builder().scheme("https").host(constant.APIM_HOST).addPathSegment("phoniex")
				.addPathSegment("accounts").addQueryParameter("fetchXml", fetchXml).build().toString();

		Request request = phoenixHelper.getPhoenixRequestBuild(httpUrl);

		Response response = client.newCall(request).execute();
		String dataReturned = response.body().string();

		ObjectMapper mapper = new ObjectMapper().registerModule(new JavaTimeModule());

		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		JSONObject jsonObject = new JSONObject(dataReturned);
		JSONArray jsonArray = jsonObject.getJSONArray("value");

		if (jsonArray != null) {
			try {
				for (int i = 0; i < jsonArray.length(); i++) {

					accountValueSet(arrayListAccountData, mapper, jsonArray, i);

				}
			} catch (Exception e) {

				LOG.warn(String.format("CAUGHT EXCEPTION while setting values in arrayList for %s is : %s",
						constant.Entity_Account, e));
			}
		}
		accountRes.setAccountData(arrayListAccountData);
		LOG.info(String.format("Total recs extracted for %s  from Phoenix call are :  %s", constant.Entity_Account,
				arrayListAccountData.size()));
		Instant endpnx = Instant.now();
		long timeElapsedphnx = Duration.between(startpnx, endpnx).toMillis();
		LOG.info(String.format("***************Total time taken for %s entity by Phoenix call is : %s milliseconds ",
				constant.Entity_Account, timeElapsedphnx));

		if (CollectionUtils.isNotEmpty(arrayListAccountData)) {
			arrayListAccountData.sort(Comparator.comparing(AccountData::getModifiedonSorting));
			AccountData maxModifiedonData = arrayListAccountData.get(arrayListAccountData.size() - 1);
			startdate = maxModifiedonData.getModifiedon();
		} else {
			startdate = startWebJob_formatted;
		}

		accsqlhelper.insertAccount(arrayListAccountData, fetch_IncrementalDataLoadAuditId);

		return startdate;

	}

	public void accountValueSet(ArrayList<AccountData> arrayListAccountData, ObjectMapper mapper, JSONArray jsonArray,
			int i) throws JsonProcessingException, JsonMappingException {
		AccountData caseObjaccount = null;

		caseObjaccount = mapper.readValue(jsonArray.get(i).toString(), AccountData.class);

		JSONObject childJsonObject = new JSONObject(jsonArray.get(i).toString());

		caseObjaccount
				.setAccountid(childJsonObject.isNull("accountid") ? null : childJsonObject.optString("accountid"));

		caseObjaccount.setAccountcategorycode(
				childJsonObject.isNull("accountcategorycode") ? null : childJsonObject.optLong("accountcategorycode"));

		caseObjaccount.setBusinesstypecode(
				childJsonObject.isNull("businesstypecode") ? null : childJsonObject.optLong("businesstypecode"));

		caseObjaccount.setFos_approvalstatus(
				childJsonObject.isNull("fos_approvalstatus") ? null : childJsonObject.optLong("fos_approvalstatus"));

		caseObjaccount.setFos_hierarchylevel(
				childJsonObject.isNull("fos_hierarchylevel") ? null : childJsonObject.optLong("fos_hierarchylevel"));

		caseObjaccount.setFos_legalstatus(
				childJsonObject.isNull("fos_legalstatus") ? null : childJsonObject.optLong("fos_legalstatus"));

		caseObjaccount.setFos_nametype(
				childJsonObject.isNull("fos_nametype") ? null : childJsonObject.optLong("fos_nametype"));

		caseObjaccount.setPreferredcontactmethodcode(childJsonObject.isNull("preferredcontactmethodcode") ? null
				: childJsonObject.optLong("preferredcontactmethodcode"));

		caseObjaccount.setParentaccountid(childJsonObject.isNull("_parentaccountid_value") ? null
				: childJsonObject.optString("_parentaccountid_value"));

		caseObjaccount.setAccountnumber(
				childJsonObject.isNull("accountnumber") ? null : childJsonObject.optString("accountnumber"));

		caseObjaccount
				.setDonotemail(childJsonObject.isNull("donotemail") ? null : childJsonObject.optBoolean("donotemail"));

		caseObjaccount
				.setDonotphone(childJsonObject.isNull("donotphone") ? null : childJsonObject.optBoolean("donotphone"));

		caseObjaccount.setDonotpostalmail(
				childJsonObject.isNull("donotpostalmail") ? null : childJsonObject.optBoolean("donotpostalmail"));

		caseObjaccount.setAddress1_city(
				childJsonObject.isNull("address1_city") ? null : childJsonObject.optString("address1_city"));

		caseObjaccount.setAddress1_composite(
				childJsonObject.isNull("address1_composite") ? null : childJsonObject.optString("address1_composite"));

		caseObjaccount.setAddress1_country(
				childJsonObject.isNull("address1_country") ? null : childJsonObject.optString("address1_country"));
		caseObjaccount.setAddress1_county(
				childJsonObject.isNull("address1_county") ? null : childJsonObject.optString("address1_county"));

		caseObjaccount.setAddress1_line1(
				childJsonObject.isNull("address1_line1") ? null : childJsonObject.optString("address1_line1"));

		caseObjaccount.setAddress1_line2(
				childJsonObject.isNull("address1_line2") ? null : childJsonObject.optString("address1_line2"));

		caseObjaccount.setAddress1_line3(
				childJsonObject.isNull("address1_line3") ? null : childJsonObject.optString("address1_line3"));

		caseObjaccount.setAddress1_name(
				childJsonObject.isNull("address1_name") ? null : childJsonObject.optString("address1_name"));

		caseObjaccount.setAddress1_postalcode(childJsonObject.isNull("address1_postalcode") ? null
				: childJsonObject.optString("address1_postalcode"));

		caseObjaccount.setAddress1_stateorprovince(childJsonObject.isNull("address1_stateorprovince") ? null
				: childJsonObject.optString("address1_stateorprovince"));

		caseObjaccount.setFos_fcareference(
				childJsonObject.isNull("fos_fcareference") ? null : childJsonObject.optString("fos_fcareference"));

		caseObjaccount.setEmailaddress1(
				childJsonObject.isNull("emailaddress1") ? null : childJsonObject.optString("emailaddress1"));

		caseObjaccount.setFos_shortname(
				childJsonObject.isNull("fos_shortname") ? null : childJsonObject.optString("fos_shortname"));

		caseObjaccount.setFos_legalstatusname(
				childJsonObject.isNull("fos_legalstatusname@OData.Community.Display.V1.FormattedValue") ? null
						: childJsonObject.optString("fos_legalstatusname@OData.Community.Display.V1.FormattedValue"));

		caseObjaccount.setName(childJsonObject.isNull("name") ? null : childJsonObject.optString("name"));

		caseObjaccount
				.setWebsiteurl(childJsonObject.isNull("websiteurl") ? null : childJsonObject.optString("websiteurl"));

		caseObjaccount.setAddress2_city(
				childJsonObject.isNull("address2_city") ? null : childJsonObject.optString("address2_city"));

		caseObjaccount.setAddress2_composite(
				childJsonObject.isNull("address2_composite") ? null : childJsonObject.optString("address2_composite"));

		caseObjaccount.setAddress2_country(
				childJsonObject.isNull("address2_country") ? null : childJsonObject.optString("address2_country"));

		caseObjaccount.setAddress2_county(
				childJsonObject.isNull("address2_county") ? null : childJsonObject.optString("address2_county"));

		caseObjaccount.setAddress2_line1(
				childJsonObject.isNull("address2_line1") ? null : childJsonObject.optString("address2_line1"));

		caseObjaccount.setAddress2_line2(
				childJsonObject.isNull("address2_line2") ? null : childJsonObject.optString("address2_line2"));

		caseObjaccount.setAddress2_line3(
				childJsonObject.isNull("address2_line3") ? null : childJsonObject.optString("address2_line3"));

		caseObjaccount.setAddress2_name(
				childJsonObject.isNull("address2_name") ? null : childJsonObject.optString("address2_name"));

		caseObjaccount.setAddress2_postalcode(childJsonObject.isNull("address2_postalcode") ? null
				: childJsonObject.optString("address2_postalcode"));

		caseObjaccount.setAddress2_stateorprovince(childJsonObject.isNull("address2_stateorprovince") ? null
				: childJsonObject.optString("address2_stateorprovince"));

		String versionnumbers = childJsonObject.optString("@odata.etag");
		Long versionno = StringUtils.isEmpty(versionnumbers) ? null : Long.parseLong(versionnumbers.split("\"")[1]);
		caseObjaccount.setVersionnumber(versionno);
		versionnumbers = null;

		caseObjaccount
				.setCreatedon(childJsonObject.isNull("createdon") ? null : childJsonObject.optString("createdon"));

		caseObjaccount
				.setModifiedon(childJsonObject.isNull("modifiedon") ? null : childJsonObject.optString("modifiedon"));

		caseObjaccount.setCreatedby(
				childJsonObject.isNull("_createdby_value") ? null : childJsonObject.optString("_createdby_value"));

		caseObjaccount.setModifiedby(
				childJsonObject.isNull("_modifiedby_value") ? null : childJsonObject.optString("_modifiedby_value"));

		caseObjaccount.setFos_businesstypecode_txt(
				childJsonObject.isNull("businesstypecode@OData.Community.Display.V1.FormattedValue") ? null
						: childJsonObject.optString("businesstypecode@OData.Community.Display.V1.FormattedValue"));

		caseObjaccount.setParentaccountidname(
				childJsonObject.isNull("_parentaccountid_value@OData.Community.Display.V1.FormattedValue") ? null
						: childJsonObject
								.optString("_parentaccountid_value@OData.Community.Display.V1.FormattedValue"));

		caseObjaccount.setFos_hierarchylevelname(
				childJsonObject.isNull("fos_hierarchylevel@OData.Community.Display.V1.FormattedValue") ? null
						: childJsonObject.optString("fos_hierarchylevel@OData.Community.Display.V1.FormattedValue"));
		caseObjaccount.setStatecode(childJsonObject.isNull("statecode") ? null : childJsonObject.optLong("statecode"));

		caseObjaccount.setFos_organisationcapacity(childJsonObject.isNull("fos_organisationcapacity") ? null
				: childJsonObject.optLong("fos_organisationcapacity"));

		arrayListAccountData.add(caseObjaccount);
	}

	public void phxhelper_recon(String startWebJob_formatted, Integer totalSuccessCount, Integer failedCount,
			AccountRes accountRes, ArrayList<AccountData> arrayListAccountData, String fetch_IncrementalDataLoadAuditId,
			int current_status_id_inprogress, String Start_time, String End_time)
			throws InterruptedException, IOException, JsonProcessingException, JsonMappingException {
	}

	public void contactValueSet(ArrayList<ContactData> arrayListContactData, ObjectMapper mapper, JSONArray jsonArray,
			int i) throws JsonProcessingException, JsonMappingException {
		ContactData caseObjcontact = null;

		caseObjcontact = mapper.readValue(jsonArray.get(i).toString(), ContactData.class);

		JSONObject childJsonObject = new JSONObject(jsonArray.get(i).toString());

		caseObjcontact.setStatecode(childJsonObject.isNull("statecode") ? null : childJsonObject.optLong("statecode"));

		caseObjcontact
				.setContactid(childJsonObject.isNull("contactid") ? null : childJsonObject.optString("contactid"));

		caseObjcontact.setFos_contactdescriptionoption(childJsonObject.isNull("fos_contactdescriptionoption") ? null
				: childJsonObject.optLong("fos_contactdescriptionoption"));

		caseObjcontact.setFos_digitalportalinvitestatus(childJsonObject.isNull("fos_digitalportalinvitestatus") ? null
				: childJsonObject.optLong("fos_digitalportalinvitestatus"));

		caseObjcontact.setFos_isdigitalportaladmin(childJsonObject.isNull("fos_isdigitalportaladmin") ? null
				: childJsonObject.optLong("fos_isdigitalportaladmin"));

		caseObjcontact.setFos_parentorganisationcapacity(childJsonObject.isNull("fos_parentorganisationcapacity") ? null
				: childJsonObject.optLong("fos_parentorganisationcapacity"));

		caseObjcontact.setFos_phonerecordingconsent(childJsonObject.isNull("fos_phonerecordingconsent") ? null
				: childJsonObject.optLong("fos_phonerecordingconsent"));

		caseObjcontact.setFos_preferredmethodofcorrespondencecode(
				childJsonObject.isNull("fos_preferredmethodofcorrespondencecode") ? null
						: childJsonObject.optLong("fos_preferredmethodofcorrespondencecode"));

		caseObjcontact.setFos_surveyconsentcode(childJsonObject.isNull("fos_surveyconsentcode") ? null
				: childJsonObject.optLong("fos_surveyconsentcode"));

		caseObjcontact
				.setGendercode(childJsonObject.isNull("gendercode") ? null : childJsonObject.optLong("gendercode"));

		caseObjcontact.setPreferredcontactmethodcode(childJsonObject.isNull("preferredcontactmethodcode") ? null
				: childJsonObject.optLong("preferredcontactmethodcode"));

		caseObjcontact
				.setDonotemail(childJsonObject.isNull("donotemail") ? null : childJsonObject.optBoolean("donotemail"));

		caseObjcontact
				.setDonotphone(childJsonObject.isNull("donotphone") ? null : childJsonObject.optBoolean("donotphone"));

		caseObjcontact.setDonotpostalmail(
				childJsonObject.isNull("donotpostalmail") ? null : childJsonObject.optBoolean("donotpostalmail"));

		caseObjcontact.setParentcustomerid(childJsonObject.isNull("_parentcustomerid_value") ? null
				: childJsonObject.optString("_parentcustomerid_value"));

		caseObjcontact.setParentcontactid(
				childJsonObject.isNull("_parentcontactid_value") ? null : childJsonObject.optString("_parentcontactid_value"));

		caseObjcontact.setAddress1_city(
				childJsonObject.isNull("address1_city") ? null : childJsonObject.optString("address1_city"));

		caseObjcontact.setAddress1_composite(
				childJsonObject.isNull("address1_composite") ? null : childJsonObject.optString("address1_composite"));

		caseObjcontact.setAddress1_country(
				childJsonObject.isNull("address1_country") ? null : childJsonObject.optString("address1_country"));

		caseObjcontact.setAddress1_county(
				childJsonObject.isNull("address1_county") ? null : childJsonObject.optString("address1_county"));

		caseObjcontact.setAddress1_line1(
				childJsonObject.isNull("address1_line1") ? null : childJsonObject.optString("address1_line1"));

		caseObjcontact.setAddress1_line2(
				childJsonObject.isNull("address1_line2") ? null : childJsonObject.optString("address1_line2"));

		caseObjcontact.setAddress1_line3(
				childJsonObject.isNull("address1_line3") ? null : childJsonObject.optString("address1_line3"));

		caseObjcontact.setAddress1_name(
				childJsonObject.isNull("address1_name") ? null : childJsonObject.optString("address1_name"));

		caseObjcontact.setAddress1_postalcode(childJsonObject.isNull("address1_postalcode") ? null
				: childJsonObject.optString("address1_postalcode"));

		caseObjcontact
				.setBirthdate(childJsonObject.isNull("birthdate") ? null : childJsonObject.optString("birthdate"));

		caseObjcontact.setDescription(
				childJsonObject.isNull("description") ? null : childJsonObject.optString("description"));

		caseObjcontact.setEmailaddress1(
				childJsonObject.isNull("emailaddress1") ? null : childJsonObject.optString("emailaddress1"));

		caseObjcontact
				.setFirstname(childJsonObject.isNull("firstname") ? null : childJsonObject.optString("firstname"));

		caseObjcontact.setFos_addressid(
				childJsonObject.isNull("fos_addressid") ? null : childJsonObject.optString("fos_addressid"));

		caseObjcontact
				.setFos_fcaid(childJsonObject.isNull("fos_fcaid") ? null : childJsonObject.optString("fos_fcaid"));

		caseObjcontact.setFos_needstring(
				childJsonObject.isNull("fos_needstring") ? null : childJsonObject.optString("fos_needstring"));

		caseObjcontact.setFos_othertitle(
				childJsonObject.isNull("fos_othertitle") ? null : childJsonObject.optString("fos_othertitle"));

		caseObjcontact.setFullname(childJsonObject.isNull("fullname") ? null : childJsonObject.optString("fullname"));

		caseObjcontact.setJobtitle(childJsonObject.isNull("jobtitle") ? null : childJsonObject.optString("jobtitle"));

		caseObjcontact.setLastname(childJsonObject.isNull("lastname") ? null : childJsonObject.optString("lastname"));

		caseObjcontact
				.setMiddlename(childJsonObject.isNull("middlename") ? null : childJsonObject.optString("middlename"));

		caseObjcontact.setMsa_managingpartneridname(
				childJsonObject.isNull("_msa_managingpartnerid_value@OData.Community.Display.V1.FormattedValue") ? null
						: childJsonObject
								.optString("_msa_managingpartnerid_value@OData.Community.Display.V1.FormattedValue"));

		caseObjcontact
				.setSalutation(childJsonObject.isNull("salutation") ? null : childJsonObject.optString("salutation"));

		caseObjcontact.setSuffix(childJsonObject.isNull("suffix") ? null : childJsonObject.optString("suffix"));

		caseObjcontact
				.setTelephone1(childJsonObject.isNull("telephone1") ? null : childJsonObject.optString("telephone1"));

		caseObjcontact
				.setTelephone2(childJsonObject.isNull("telephone2") ? null : childJsonObject.optString("telephone2"));

		String versionnumbers = childJsonObject.optString("@odata.etag");
		Long versionno = StringUtils.isEmpty(versionnumbers) ? null : Long.parseLong(versionnumbers.split("\"")[1]);
		caseObjcontact.setVersionnumber(versionno);
		versionnumbers = null;
		caseObjcontact
				.setCreatedon(childJsonObject.isNull("createdon") ? null : childJsonObject.optString("createdon"));

		caseObjcontact
				.setModifiedon(childJsonObject.isNull("modifiedon") ? null : childJsonObject.optString("modifiedon"));

		caseObjcontact.setCreatedby(
				childJsonObject.isNull("_createdby_value") ? null : childJsonObject.optString("_createdby_value"));

		caseObjcontact.setModifiedby(
				childJsonObject.isNull("_modifiedby_value") ? null : childJsonObject.optString("_modifiedby_value"));
		
		caseObjcontact.setFos_customeraddressid(childJsonObject.isNull("fos_customeraddressid") ? null : childJsonObject.optString("fos_customeraddressid"));

		arrayListContactData.add(caseObjcontact);
	}

	public String getFetchXML(String curtime, String lastupdatedDate, int Fetchxml_Record, String entityname) {

		return "<fetch top='" + Fetchxml_Record + "' version='1.0' mapping='logical'>" + "<entity name='" + entityname
				+ "'>" + "<filter>" + "<condition attribute='modifiedon' operator='between' value=''>" + "<value>"
				+ lastupdatedDate + "</value>" + "<value>" + curtime + "</value>" + "</condition>" + "</filter>"
				+ "<order attribute='modifiedon' /> " + "</entity>" + "</fetch>";

	}

	public String phxAccount(String Fetch_IncrementalDataLoadAuditId, AccountRes accountRes,
			ArrayList<AccountData> arrayListAccountData, Set<String> map, String startWebJob_formatted,
			String lastupdatedDate, int batchsize)
			throws JsonMappingException, JsonProcessingException, InterruptedException, IOException {

		Instant startpnx = Instant.now();
		String startdate = null;
		String startdateValue = null;
		LOG.info(String.format("Code started for %s  at : %s ", constant.Entity_Account, startpnx));

		do {
			arrayListAccountData.clear();
			startdateValue = (startdate == null || startdate.isEmpty()) ? lastupdatedDate : startdate;
			startdate = accountphxhelper(startWebJob_formatted, accountRes, arrayListAccountData, batchsize,
					startdateValue, constant.Account, map, Fetch_IncrementalDataLoadAuditId);
		} while (arrayListAccountData.size() >= batchsize);
		Instant endpnx = Instant.now();
		LOG.info(String.format("Code ended for %s  at : %s", constant.Entity_Account, endpnx));
		long timeElapsedphnx = Duration.between(startpnx, endpnx).toMillis();
		LOG.info(String.format("***************Total time taken for %s  by all operations : %s milliseconds",
				constant.Entity_Account, timeElapsedphnx));
		startdate = startWebJob_formatted;
		arrayListAccountData.clear();
		return startdate;
	}

	public Long phxAccount_recon(String Fetch_IncrementalDataLoadAuditId, AccountRes accountRes,
			ArrayList<AccountData> arrayListAccountData, Long totalRecord, String startWebJob_formatted,
			String lastupdatedDate, int batchsize)
			throws JsonMappingException, JsonProcessingException, InterruptedException, IOException {

		Instant startpnx = Instant.now();
		String startdate = null;
		String startdateValue = null;
		LOG.info(String.format("Code started for %s  at : %s ", constant.Entity_Account, startpnx));

		do {
			arrayListAccountData.clear();
			startdateValue = (startdate == null || startdate.isEmpty()) ? lastupdatedDate : startdate;
			startdate = accountphxhelper_recon(startWebJob_formatted, accountRes, arrayListAccountData, batchsize,
					startdateValue, constant.Account, Fetch_IncrementalDataLoadAuditId);

			totalRecord += arrayListAccountData.size();
		} while (arrayListAccountData.size() >= batchsize);
		Instant endpnx = Instant.now();
		LOG.info(String.format("Code ended for %s  at : %s", constant.Entity_Account, endpnx));
		long timeElapsedphnx = Duration.between(startpnx, endpnx).toMillis();
		LOG.info(String.format("***************Total time taken for %s  by all operations : %s milliseconds",
				constant.Entity_Account, timeElapsedphnx));
		startdate = startWebJob_formatted;
		arrayListAccountData.clear();
		return totalRecord;
	}

	public void phxContact(String Fetch_IncrementalDataLoadAuditId, ContactRes contactRes,
			ArrayList<ContactData> arrayListContactData, Set<String> map, String startWebJob_formatted,
			String lastupdatedDate, int batchsize, ArrayList<ContactData> finalarrayListContactData)
			throws IOException, InterruptedException {
		Instant startpnx = Instant.now();
		String startdate = null;
		String startdateValue = null;
		LOG.info(String.format("Code started for %s  at : %s ", constant.Contact, startpnx));

		do {
			arrayListContactData.clear();
			startdateValue = (startdate == null || startdate.isEmpty()) ? lastupdatedDate : startdate;
			startdate = contactphxhelper(startWebJob_formatted, contactRes, arrayListContactData, batchsize,
					startdateValue, constant.Contact, map, Fetch_IncrementalDataLoadAuditId, finalarrayListContactData);

		} while (arrayListContactData.size() >= batchsize);
		Instant endpnx = Instant.now();
		LOG.info(String.format("Code ended for %s  at : %s", constant.Contact, endpnx));
		long timeElapsedphnx = Duration.between(startpnx, endpnx).toMillis();
		LOG.info(String.format("***************Total time taken for %s  by all operations : %s milliseconds",
				constant.Contact, timeElapsedphnx));
		startdate = startWebJob_formatted;
		arrayListContactData.clear();
	}

	public String contactphxhelper(String startWebJob_formatted, ContactRes contactRes,
			ArrayList<ContactData> arrayListContactData, int batchsize, String startdateValue, String entityname,
			Set<String> map, String fetch_IncrementalDataLoadAuditId, ArrayList<ContactData> finalarrayListContactData)
			throws IOException, InterruptedException {
		Instant startpnx = Instant.now();
		LOG.info(String.format("Code started for %s  at : %s:", constant.Contact, startpnx));
		String fetchXml = "";
		String startdate = null;

		LOG.info(String.format("Latest Modified Date for %s  is : %s ", constant.Contact, startdateValue));

		OkHttpClient client = new OkHttpClient.Builder().connectTimeout(60, TimeUnit.SECONDS)
				.writeTimeout(120, TimeUnit.SECONDS).readTimeout(60, TimeUnit.SECONDS).build();

		fetchXml = this.getFetchXML(startWebJob_formatted, startdateValue, batchsize, entityname);

		String httpUrl = new HttpUrl.Builder().scheme("https").host(constant.APIM_HOST).addPathSegment("phoniex")
				.addPathSegment("contacts").addQueryParameter("fetchXml", fetchXml).build().toString();
		Request request = phoenixHelper.getPhoenixRequestBuild(httpUrl);

		Response response = client.newCall(request).execute();
		String dataReturned = response.body().string();

		LOG.info(String.format("fetchxml for %s  is   : %s", constant.Contact, fetchXml));

		ObjectMapper mapper = new ObjectMapper();
		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		JSONObject jsonObject = new JSONObject(dataReturned);
		JSONArray jsonArray = jsonObject.getJSONArray("value");

		if (jsonArray != null) {
			try {
				for (int i = 0; i < jsonArray.length(); i++) {

					contactValueSet(arrayListContactData, mapper, jsonArray, i);

				}
			} catch (Exception e) {

				LOG.warn(String.format("CAUGHT EXCEPTION while setting values in arrayList for %s  : %s",
						constant.Contact, e));
			}
		}
		contactRes.setContactData(arrayListContactData);
		LOG.info(String.format("Total recs extracted for %s  from Phoenix call are : %s", constant.Contact,
				arrayListContactData.size()));
		Instant endpnx = Instant.now();
		LOG.info(String.format("Phoenix call for %s  completed at : %s", constant.Contact, endpnx));
		long timeElapsedphnx = Duration.between(startpnx, endpnx).toMillis();
		LOG.info(String.format("***************Total time taken for %s  by Phoenix call(in millisecond) : %s",
				constant.Contact, timeElapsedphnx));

		if (CollectionUtils.isNotEmpty(arrayListContactData)) {
			arrayListContactData.sort(Comparator.comparing(ContactData::getModifiedonSorting));
			ContactData maxModifiedonData = arrayListContactData.get(arrayListContactData.size() - 1);
			startdate = maxModifiedonData.getModifiedon();
		} else {
			startdate = startWebJob_formatted;
		}

		Instant startfinallist = Instant.now();

		for (ContactData condata : arrayListContactData) {
			if (map.contains(condata.getParentcustomerid())) {
				finalarrayListContactData.add(condata);
			}
		}
		Instant endfinallist = Instant.now();
		long timeElapsed = Duration.between(startfinallist, endfinallist).toMillis();
		LOG.info(String.format(
				"***************Total time taken by %s  to give final list after comparing with Account is : %s ms ",
				constant.Contact, timeElapsed));
		LOG.info(String.format("Total recs extracted for %s  from Phoenix call after matching with Account are : %s",
				constant.Contact, finalarrayListContactData.size()));
		accsqlhelper.insertContact(finalarrayListContactData, fetch_IncrementalDataLoadAuditId);
		finalarrayListContactData.clear();

		return startdate;
	}
}
