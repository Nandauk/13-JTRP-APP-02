package com.ombudsman.service.model;

import com.google.gson.annotations.SerializedName;

public class MailjetVariables {

	@SerializedName("entityName")
	String entityName;

	@SerializedName("source")
	String source;

	@SerializedName("auditId")
	String auditId;

	@SerializedName("errorLog")
	String errorLog;

	@SerializedName("timeStamp")
	String timeStamp;

	public String getEntityName() {
		return entityName;
	}

	public void setEntityName(String entityName) {
		this.entityName = entityName;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getAuditId() {
		return auditId;
	}

	public void setAuditId(String auditId) {
		this.auditId = auditId;
	}

	public String getErrorLog() {
		return errorLog;
	}

	public void setErrorLog(String errorLog) {
		this.errorLog = errorLog;
	}

	public String getTimeStamp() {
		return timeStamp;
	}

	public void setTimeStamp(String timeStamp) {
		this.timeStamp = timeStamp;
	}


	
}
