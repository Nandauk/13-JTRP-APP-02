package com.ombudsman.service.services;

import java.io.IOException;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;

public interface AccountPhxToSqlService {

	void accountUpdatePnxtoSql() throws  IOException, InterruptedException;
	void accountUpdatePnxtoSql_recon(String Start_time, String End_time) throws  IOException, InterruptedException;
}
