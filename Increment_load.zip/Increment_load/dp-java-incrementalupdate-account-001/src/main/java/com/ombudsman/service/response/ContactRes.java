package com.ombudsman.service.response;

import java.util.List;

import com.ombudsman.service.model.ContactData;

public class ContactRes {

	private List<ContactData> contactData;

	public List<ContactData> getContactData() {
		return contactData;
	}

	public void setContactData(List<ContactData> contactData) {
		this.contactData = contactData;
	}

	
}