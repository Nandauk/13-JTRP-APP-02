package com.ombudsman.service.repo;

import com.ombudsman.service.model.IncreLoadErrorData;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.junit.jupiter.api.extension.ExtendWith;

import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class IncreLoadErrorRepositoryTest {

    @Mock
    private IncreLoadErrorRepository increLoadErrorRepository;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testInsertQuery() {
        // Given
        String incrementalDataLoadAuditId = "auditId123";
        String dataPayLoad = "dataPayLoad";
        Integer currentErrorStatusId = 1;
        String errorCode = "error123";
        String errorLog = "errorLog";
        String createdBy = "creator";
        String modifiedBy = "modifier";

        // When
        when(increLoadErrorRepository.InsertQuery(incrementalDataLoadAuditId, dataPayLoad, currentErrorStatusId, errorCode,
                errorLog, createdBy, modifiedBy)).thenReturn(1);

        // Call the method with the correct arguments
        int result = increLoadErrorRepository.InsertQuery(incrementalDataLoadAuditId, dataPayLoad, currentErrorStatusId, errorCode,
                errorLog, createdBy, modifiedBy);

        // Then
        verify(increLoadErrorRepository, times(1)).InsertQuery(incrementalDataLoadAuditId, dataPayLoad, currentErrorStatusId, errorCode,
                errorLog, createdBy, modifiedBy);
    }

    @Test
    void testGetIncrementalDataLoadErrorId() {
        // Given
        String fetchIncrementalDataLoadAuditId = "auditId123";

        // When
        when(increLoadErrorRepository.getIncrementalDataLoadErrorId(fetchIncrementalDataLoadAuditId)).thenReturn("errorId123");

        // Call the method with the correct arguments
        String result = increLoadErrorRepository.getIncrementalDataLoadErrorId(fetchIncrementalDataLoadAuditId);

        // Then
        verify(increLoadErrorRepository, times(1)).getIncrementalDataLoadErrorId(fetchIncrementalDataLoadAuditId);
    }
}
