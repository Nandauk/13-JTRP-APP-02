/*
 * package com.ombudsman.service.serviceImpl;
 * 
 * import static org.junit.jupiter.api.Assertions.assertEquals; import static
 * org.junit.jupiter.api.Assertions.assertFalse; import static
 * org.junit.jupiter.api.Assertions.assertNotNull; import static
 * org.junit.jupiter.api.Assertions.assertThrows; import static
 * org.mockito.ArgumentMatchers.anyString; import static
 * org.mockito.ArgumentMatchers.eq; import static org.mockito.Mockito.times;
 * import static org.mockito.Mockito.verify; import static
 * org.mockito.Mockito.when;
 * 
 * import java.util.ArrayList; import java.util.HashSet; import java.util.Set;
 * 
 * import org.junit.jupiter.api.BeforeEach; import org.junit.jupiter.api.Test;
 * import org.junit.jupiter.api.extension.ExtendWith; import
 * org.mockito.InjectMocks; import org.mockito.Mock; import
 * org.mockito.MockitoAnnotations; import
 * org.mockito.junit.jupiter.MockitoExtension; import
 * org.springframework.test.util.ReflectionTestUtils;
 * 
 * import com.ombudsman.service.common.Constantsconfig; import
 * com.ombudsman.service.common.PhoenixHelper; import
 * com.ombudsman.service.model.CaselinkData; import
 * com.ombudsman.service.model.ContactData; import
 * com.ombudsman.service.response.CaselinkRes; import
 * com.ombudsman.service.response.ContactRes;
 * 
 * import okhttp3.HttpUrl; import okhttp3.mockwebserver.MockResponse; import
 * okhttp3.mockwebserver.MockWebServer;
 * 
 * @ExtendWith(MockitoExtension.class) public class CaseLinkPhxHelperTest {
 * 
 * @Mock private Constantsconfig constantsConfig;
 * 
 * @Mock private PhoenixHelper phoenixHelper;
 * 
 * @Mock private CaselinkSqlHelper casesqlhelper;
 * 
 * @InjectMocks private CaseLinkPhxHelper caseLinkPhxHelper;
 * 
 * private MockWebServer mockWebServer;
 * 
 * @BeforeEach public void setUp() throws Exception {
 * MockitoAnnotations.openMocks(this); mockWebServer = new MockWebServer();
 * mockWebServer.start();
 * 
 * // Set the mock APIM_HOST constant
 * ReflectionTestUtils.setField(constantsConfig, "APIM_HOST",
 * mockWebServer.url("/").host()); ReflectionTestUtils.setField(constantsConfig,
 * "Entity_Caselink", "Caselink"); }
 * 
 * @Test public void testPhxCaselink_success() throws Exception { // Mock the
 * response from Phoenix API MockResponse mockResponse = new MockResponse()
 * .setBody("{\"value\": [{\"fos_individualid\": \"123\", \"fos_caselinkid\": \"456\", \"modifiedon\": \"2024-10-10\"}]}"
 * ) .addHeader("Content-Type", "application/json");
 * mockWebServer.enqueue(mockResponse);
 * 
 * // Prepare mock inputs String Fetch_IncrementalDataLoadAuditId = "audit123";
 * CaselinkRes caselinkRes = new CaselinkRes(); ArrayList<CaselinkData>
 * arrayListCaselink = new ArrayList<>(); Set<String> map = new HashSet<>();
 * String startWebJob_formatted = "2024-10-01"; String lastupdatedDate =
 * "2024-09-30"; int batchsize = 10; Set<String> mapTotal = new HashSet<>();
 * 
 * // Mock Phoenix request build method HttpUrl mockHttpUrl =
 * mockWebServer.url("/phoniex/fos_caselinks?fetchXml=test");
 * when(phoenixHelper.getPhoenixRequestBuild(anyString())).thenReturn(new
 * okhttp3.Request.Builder().url(mockHttpUrl).build());
 * 
 * // Call the method String result = caseLinkPhxHelper.phxCaselink(
 * Fetch_IncrementalDataLoadAuditId, caselinkRes, arrayListCaselink, map,
 * startWebJob_formatted, lastupdatedDate, batchsize, mapTotal );
 * 
 * assertNotNull(result); assertEquals("2024-10-01", result);
 * verify(casesqlhelper, times(1)).insertCaselink(eq(arrayListCaselink),
 * eq(Fetch_IncrementalDataLoadAuditId)); assertFalse(map.isEmpty());
 * assertFalse(mapTotal.isEmpty()); }
 * 
 * @Test public void testPhxCaselink_recon_success() throws Exception { // Mock
 * the response from Phoenix API MockResponse mockResponse = new MockResponse()
 * .setBody("{\"value\": [{\"fos_individualid\": \"123\", \"fos_caselinkid\": \"456\", \"modifiedon\": \"2024-10-10\"}]}"
 * ) .addHeader("Content-Type", "application/json");
 * mockWebServer.enqueue(mockResponse);
 * 
 * // Prepare mock inputs String Fetch_IncrementalDataLoadAuditId = "audit123";
 * CaselinkRes caselinkRes = new CaselinkRes(); ArrayList<CaselinkData>
 * arrayListCaselink = new ArrayList<>(); String startWebJob_formatted =
 * "2024-10-01"; String lastupdatedDate = "2024-09-30"; int batchsize = 10; Long
 * totalRecord = 0L;
 * 
 * // Mock Phoenix request build method HttpUrl mockHttpUrl =
 * mockWebServer.url("/phoniex/fos_caselinks?fetchXml=test");
 * when(phoenixHelper.getPhoenixRequestBuild(anyString())).thenReturn(new
 * okhttp3.Request.Builder().url(mockHttpUrl).build());
 * 
 * // Call the method Long result = caseLinkPhxHelper.phxCaselink_recon(
 * Fetch_IncrementalDataLoadAuditId, caselinkRes, arrayListCaselink,
 * startWebJob_formatted, lastupdatedDate, batchsize, totalRecord );
 * 
 * assertNotNull(result); assertEquals(1L, result); }
 * 
 * @Test public void testPhxCaselink_Exception() throws Exception { // Mock to
 * throw exception in the Phoenix processing part
 * when(phoenixHelper.getPhoenixRequestBuild(anyString())).thenThrow(new
 * RuntimeException("Test Exception"));
 * 
 * assertThrows(RuntimeException.class, () -> { caseLinkPhxHelper.phxCaselink(
 * "audit123", new CaselinkRes(), new ArrayList<>(), new HashSet<>(),
 * "2024-10-01", "2024-09-30", 10, new HashSet<>() ); });
 * 
 * // Verify the interactions within the catch block verify(phoenixHelper,
 * times(1)).getPhoenixRequestBuild(anyString()); }
 * 
 * @Test public void testPhxCaselink_recon_Exception() throws Exception { //
 * Mock to throw exception in the Phoenix processing part
 * when(phoenixHelper.getPhoenixRequestBuild(anyString())).thenThrow(new
 * RuntimeException("Test Exception"));
 * 
 * assertThrows(RuntimeException.class, () -> {
 * caseLinkPhxHelper.phxCaselink_recon( "audit123", new CaselinkRes(), new
 * ArrayList<>(), "2024-10-01", "2024-09-30", 10, 0L ); });
 * 
 * // Verify the interactions within the catch block verify(phoenixHelper,
 * times(1)).getPhoenixRequestBuild(anyString()); }
 * 
 * @Test public void testPhxContact_success() throws Exception { // Mock the
 * response from Phoenix API MockResponse mockResponse = new MockResponse()
 * .setBody("{\"value\": [{\"contactid\": \"123\", \"modifiedon\": \"2024-10-10\"}]}"
 * ) .addHeader("Content-Type", "application/json");
 * mockWebServer.enqueue(mockResponse);
 * 
 * // Prepare mock inputs String Fetch_IncrementalDataLoadAuditId = "audit123";
 * ContactRes contactRes = new ContactRes(); ArrayList<ContactData>
 * arrayListContactData = new ArrayList<>(); Set<String> map = new HashSet<>();
 * String startWebJob_formatted = "2024-10-01"; String lastupdatedDate =
 * "2024-09-30"; int batchsize = 10; ArrayList<ContactData>
 * finalarrayListContactData = new ArrayList<>();
 * 
 * // Mock Phoenix request build method HttpUrl mockHttpUrl =
 * mockWebServer.url("/phoniex/contacts?fetchXml=test");
 * when(phoenixHelper.getPhoenixRequestBuild(anyString())).thenReturn(new
 * okhttp3.Request.Builder().url(mockHttpUrl).build());
 * 
 * // Call the method caseLinkPhxHelper.phxContact(
 * Fetch_IncrementalDataLoadAuditId, contactRes, arrayListContactData, map,
 * startWebJob_formatted, lastupdatedDate, batchsize, finalarrayListContactData
 * );
 * 
 * assertNotNull(arrayListContactData);
 * assertNotNull(finalarrayListContactData); verify(casesqlhelper,
 * times(1)).insertContact(eq(finalarrayListContactData),
 * eq(Fetch_IncrementalDataLoadAuditId)); }
 * 
 * 
 * 
 * @Test public void testPhxContact_Exception() throws Exception { // Mock to
 * throw exception in the Phoenix processing part
 * when(phoenixHelper.getPhoenixRequestBuild(anyString())).thenThrow(new
 * RuntimeException("Test Exception"));
 * 
 * assertThrows(RuntimeException.class, () -> { caseLinkPhxHelper.phxContact(
 * "audit123", new ContactRes(), new ArrayList<>(), new HashSet<>(),
 * "2024-10-01", "2024-09-30", 10, new ArrayList<>() ); });
 * 
 * // Verify the interactions within the catch block verify(phoenixHelper,
 * times(1)).getPhoenixRequestBuild(anyString()); }
 * 
 * @Test public void testContactPhxHelper_Exception() throws Exception { // Mock
 * to throw exception in the Phoenix processing part
 * when(phoenixHelper.getPhoenixRequestBuild(anyString())).thenThrow(new
 * RuntimeException("Test Exception"));
 * 
 * assertThrows(RuntimeException.class, () -> {
 * caseLinkPhxHelper.contactphxhelper( "2024-10-01", new ContactRes(), new
 * ArrayList<>(), 10, "2024-09-30", "Contact", new HashSet<>(), "audit123", new
 * ArrayList<>() ); });
 * 
 * // Verify the interactions within the catch block verify(phoenixHelper,
 * times(1)).getPhoenixRequestBuild(anyString()); } }
 */