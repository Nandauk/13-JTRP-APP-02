package com.ombudsman.service.serviceImpl;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

import java.util.ArrayList;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;

import com.ombudsman.service.common.Constantsconfig;
import com.ombudsman.service.model.CaselinkData;
import com.ombudsman.service.model.ContactData;
import com.ombudsman.service.repo.CaselinkRepository;
import com.ombudsman.service.repo.ContactRepository;
import com.ombudsman.service.response.ContactRes;

@ExtendWith(MockitoExtension.class)
public class CaselinkSqlHelperTest {

	@Mock
	private Constantsconfig constant;
	@Mock
	private ContactRepository contactRep;
	@Mock
	private CaselinkRepository caselinkRepository;

	@InjectMocks
	private CaselinkSqlHelper caselinkSqlHelper;

	private CaselinkData caselinkData;
	private ContactData contactData;
	private ContactRes contactRes;
	@BeforeEach
	public void setUp() {
		caselinkData = new CaselinkData();

		// Setting up dummy data using setter methods
		caselinkData.setStatecode(1L);
		caselinkData.setStatuscode(2L);
		caselinkData.setFos_caselinkid("caselink_id");
		caselinkData.setFos_businesstypecode(3L);

		caselinkData.setFos_aretheyotherwisecoveredunderthetemporaryp(false);
		caselinkData.setFos_howisthefirminourjurisdiction(4L);
		caselinkData.setFos_preferredmethodofcontact(5L);
		caselinkData.setFos_preferredmethodofcorrespondence(6L);

		caselinkData.setFos_islinkedorpartnered(true);
		caselinkData.setFos_ismicroenterprise(false);
		caselinkData.setFos_issmallmediumenterprise(true);
		caselinkData.setFos_receivecorrespondence(true);
		caselinkData.setFos_appointedrepresentativeid("appointed_representative_id");
		caselinkData.setFos_case("case");
		caselinkData.setFos_representativecaselinkid("representative_caselink_id");
		caselinkData.setFos_individualid("individual_id");
		caselinkData.setFos_organisationid("organisation_id");
		caselinkData.setFos_preferredemailaddress("email@example.com");
		caselinkData.setFos_preferredphonenumber("123456789");
		caselinkData.setFos_tradingname("trading_name");

		caselinkData.setFos_caseid("case_id");
		caselinkData.setFos_declarationdate("2023-01-01");
		caselinkData.setFos_extendedreference("extended_reference");
		caselinkData.setFos_numberofemployees(50L);
		caselinkData.setFos_numberofpartners(10L);
		caselinkData.setFos_reference("reference");
		caselinkData.setVersionnumber(1L);
		caselinkData.setCreatedby("created_by");
		caselinkData.setModifiedby("modified_by");
		caselinkData.setModifiedon("2023-01-02");
		caselinkData.setCreatedon("2023-01-01");
		caselinkData.setFos_preferredemailaddressname("preferred_email_name");
		caselinkData.setFos_tradingnamename("trading_name_name");
contactData = new ContactData();
        
        // Setting up dummy data using setter methods
        contactData.setContactid("contact_id");
        contactData.setStatecode(1L);
        contactData.setFos_capacity(2L);
        contactData.setFos_contactdescriptionoption(3L);
        contactData.setFos_digitalportalinvitestatus(4L);
        contactData.setFos_isdigitalportaladmin(5L);
        contactData.setFos_parentorganisationcapacity(6L);
        contactData.setFos_phonerecordingconsent(7L);
        contactData.setFos_preferredmethodofcorrespondencecode(8L);
        contactData.setFos_surveyconsentcode(9L);
        contactData.setGendercode(10L);
        contactData.setPreferredcontactmethodcode(11L);
        contactData.setDonotemail(true);
        contactData.setDonotphone(false);
        contactData.setDonotpostalmail(true);
        contactData.setParentcontactid("parent_contact_id");
        contactData.setParentcustomerid("parent_customer_id");
        contactData.setAddress1_city("city");
        contactData.setAddress1_composite("composite");
        contactData.setAddress1_country("country");
        contactData.setAddress1_county("county");
        contactData.setAddress1_line1("line1");
        contactData.setAddress1_line2("line2");
        contactData.setAddress1_line3("line3");
        contactData.setAddress1_name("name");
        contactData.setAddress1_postalcode("postal_code");
        contactData.setBirthdate("2000-01-01");
        contactData.setDescription("description");
        contactData.setEmailaddress1("email@example.com");
        contactData.setFirstname("John");
        contactData.setFos_addressid("address_id");
        contactData.setFos_fcaid("fca_id");
        contactData.setFos_needstring("need_string");
        contactData.setFos_othertitle("other_title");
        contactData.setFullname("John Doe");
        contactData.setJobtitle("job_title");
        contactData.setLastname("Doe");
        contactData.setMiddlename("Middle");
        contactData.setMsa_managingpartneridname("managing_partner_name");
        contactData.setSalutation("Mr.");
        contactData.setSuffix("Jr.");
        contactData.setTelephone1("123456789");
        contactData.setTelephone2("987654321");
        contactData.setVersionnumber(1L);
        contactData.setCreatedon("2023-01-01");
        contactData.setModifiedon("2023-01-02");
        contactData.setCreatedby("created_by");
        contactData.setModifiedby("modified_by");
	}

	@Test
	public void testInsertHelpercaseLink() {
		String fetchIncrementalDataLoadAuditId = "audit123";

		caselinkSqlHelper.insertHelpercaseLink(caselinkData, fetchIncrementalDataLoadAuditId);

		verify(caselinkRepository, times(1)).InsertQuery(
				caselinkData.getStatecode(), caselinkData.getStatuscode(), caselinkData.getFos_caselinkid(),
				caselinkData.getFos_businesstypecode(), caselinkData.getFos_declarationaccepted(),
				caselinkData.getFos_aretheyotherwisecoveredunderthetemporaryp(), caselinkData.getFos_howisthefirminourjurisdiction(),
				caselinkData.getFos_preferredmethodofcontact(), caselinkData.getFos_preferredmethodofcorrespondence(),
				caselinkData.getFos_role(), caselinkData.getFos_islinkedorpartnered(), caselinkData.getFos_ismicroenterprise(),
				caselinkData.getFos_issmallmediumenterprise(), caselinkData.getFos_receivecorrespondence(),
				caselinkData.getFos_appointedrepresentativeid(), caselinkData.getFos_case(), caselinkData.getFos_representativecaselinkid(),
				caselinkData.getFos_individualid(), caselinkData.getFos_organisationid(), caselinkData.getFos_preferredemailaddress(),
				caselinkData.getFos_preferredphonenumber(), caselinkData.getFos_tradingname(), caselinkData.getFos_annualincome(),
				caselinkData.getFos_annualturnover(), caselinkData.getFos_balancesheet(), caselinkData.getFos_netassets(),
				caselinkData.getFos_caseid(), caselinkData.getFos_declarationdate(), caselinkData.getFos_extendedreference(),
				caselinkData.getFos_numberofemployees(), caselinkData.getFos_numberofpartners(), caselinkData.getFos_reference(),
				caselinkData.getVersionnumber(), caselinkData.getCreatedby(), caselinkData.getModifiedby(),
				caselinkData.getModifiedon(), caselinkData.getCreatedon(), caselinkData.getFos_preferredemailaddressname(),
				caselinkData.getFos_tradingnamename(), fetchIncrementalDataLoadAuditId
				);
	}

  

	@Test
	public void testInsertHelpercontact() {
		String fetchIncrementalDataLoadAuditId = "audit123";

		caselinkSqlHelper.insertHelpercontact(contactData, fetchIncrementalDataLoadAuditId);

		verify(contactRep, times(1)).InsertQuery(
				contactData.getContactid(), contactData.getStatecode(), contactData.getFos_capacity(),
				contactData.getFos_contactdescriptionoption(), contactData.getFos_digitalportalinvitestatus(),
				contactData.getFos_isdigitalportaladmin(), contactData.getFos_parentorganisationcapacity(),
				contactData.getFos_phonerecordingconsent(), contactData.getFos_preferredmethodofcorrespondencecode(),
				contactData.getFos_surveyconsentcode(), contactData.getGendercode(), contactData.getPreferredcontactmethodcode(),
				contactData.getDonotemail(), contactData.getDonotphone(), contactData.getDonotpostalmail(),
				contactData.getParentcontactid(), contactData.getParentcustomerid(), contactData.getAddress1_city(),
				contactData.getAddress1_composite(), contactData.getAddress1_country(), contactData.getAddress1_county(),
				contactData.getAddress1_line1(), contactData.getAddress1_line2(), contactData.getAddress1_line3(),
				contactData.getAddress1_name(), contactData.getAddress1_postalcode(), contactData.getBirthdate(),
				contactData.getDescription(), contactData.getEmailaddress1(), contactData.getFirstname(),
				contactData.getFos_addressid(), contactData.getFos_fcaid(), contactData.getFos_needstring(),
				contactData.getFos_othertitle(), contactData.getFullname(), contactData.getJobtitle(), contactData.getLastname(),
				contactData.getMiddlename(), contactData.getMsa_managingpartneridname(), contactData.getSalutation(),
				contactData.getSuffix(), contactData.getTelephone1(), contactData.getTelephone2(), contactData.getVersionnumber(),
				contactData.getCreatedon(), contactData.getModifiedon(), contactData.getCreatedby(), contactData.getModifiedby(),
				fetchIncrementalDataLoadAuditId
				);
	}

}
