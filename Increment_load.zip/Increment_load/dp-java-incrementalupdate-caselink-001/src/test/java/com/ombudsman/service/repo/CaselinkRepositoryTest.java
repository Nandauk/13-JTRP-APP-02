package com.ombudsman.service.repo;

import com.ombudsman.service.model.CaselinkData;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.junit.jupiter.api.extension.ExtendWith;

import java.math.BigDecimal;

import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class CaselinkRepositoryTest {

	@Mock
	private CaselinkRepository caselinkRepository;

	@BeforeEach
	public void setUp() {
		MockitoAnnotations.openMocks(this);
	}

	@Test
	void testInsertQuery() {
		// Given
		Long statecode = 1L;
		Long statuscode = 2L;
		String fos_caselinkid = "caseLink123";
		Long fos_businesstypecode = 3L;
		Long fos_declarationaccepted = 4L;
		Boolean fos_aretheyotherwisecoveredunderthetemporaryp = true;
		Long fos_howisthefirminourjurisdiction = 5L;
		Long fos_preferredmethodofcontact = 6L;
		Long fos_preferredmethodofcorrespondence = 7L;
		Long fos_role = 8L;
		Boolean fos_islinkedorpartnered = false;
		Boolean fos_ismicroenterprise = true;
		Boolean fos_issmallmediumenterprise = false;
		Boolean fos_receivecorrespondence = true;
		String fos_appointedrepresentativeid = "rep123";
		String fos_case = "case123";
		String fos_representativecaselinkid = "repCaseLink123";
		String fos_individualid = "ind123";
		String fos_organisationid = "org123";
		String fos_preferredemailaddress = "email@example.com";
		String fos_preferredphonenumber = "1234567890";
		String fos_tradingname = "Trading Name";
		BigDecimal fos_annualincome = new BigDecimal("100000.00");
		BigDecimal fos_annualturnover = new BigDecimal("200000.00");
		BigDecimal fos_balancesheet = new BigDecimal("300000.00");
		BigDecimal fos_netassets = new BigDecimal("400000.00");
		String fos_caseid = "caseId123";
		String fos_declarationdate = "2025-01-01";
		String fos_extendedreference = "extRef123";
		Long fos_numberofemployees = 50L;
		Long fos_numberofpartners = 5L;
		String fos_reference = "ref123";
		Long versionnumber = 1L;
		String createdby = "creator";
		String modifiedby = "modifier";
		String modifiedon = "2025-01-01";
		String createdon = "2025-01-01";
		String fos_preferredemailaddressname = "Preferred Email Name";
		String fos_tradingnamename = "Trading Name Name";
		String incrementaldataloadjobauditid = "audit123";

		// When
		when(caselinkRepository.InsertQuery(statecode, statuscode, fos_caselinkid, fos_businesstypecode,
				fos_declarationaccepted, fos_aretheyotherwisecoveredunderthetemporaryp,
				fos_howisthefirminourjurisdiction, fos_preferredmethodofcontact, fos_preferredmethodofcorrespondence,
				fos_role, fos_islinkedorpartnered, fos_ismicroenterprise, fos_issmallmediumenterprise,
				fos_receivecorrespondence, fos_appointedrepresentativeid, fos_case, fos_representativecaselinkid,
				fos_individualid, fos_organisationid, fos_preferredemailaddress, fos_preferredphonenumber,
				fos_tradingname, fos_annualincome, fos_annualturnover, fos_balancesheet, fos_netassets, fos_caseid,
				fos_declarationdate, fos_extendedreference, fos_numberofemployees, fos_numberofpartners, fos_reference,
				versionnumber, createdby, modifiedby, modifiedon, createdon, fos_preferredemailaddressname,
				fos_tradingnamename, incrementaldataloadjobauditid)).thenReturn(1);

		// Call the method with the correct arguments
		int result = caselinkRepository.InsertQuery(statecode, statuscode, fos_caselinkid, fos_businesstypecode,
				fos_declarationaccepted, fos_aretheyotherwisecoveredunderthetemporaryp,
				fos_howisthefirminourjurisdiction, fos_preferredmethodofcontact, fos_preferredmethodofcorrespondence,
				fos_role, fos_islinkedorpartnered, fos_ismicroenterprise, fos_issmallmediumenterprise,
				fos_receivecorrespondence, fos_appointedrepresentativeid, fos_case, fos_representativecaselinkid,
				fos_individualid, fos_organisationid, fos_preferredemailaddress, fos_preferredphonenumber,
				fos_tradingname, fos_annualincome, fos_annualturnover, fos_balancesheet, fos_netassets, fos_caseid,
				fos_declarationdate, fos_extendedreference, fos_numberofemployees, fos_numberofpartners, fos_reference,
				versionnumber, createdby, modifiedby, modifiedon, createdon, fos_preferredemailaddressname,
				fos_tradingnamename, incrementaldataloadjobauditid);

		verify(caselinkRepository, times(1)).InsertQuery(statecode, statuscode, fos_caselinkid, fos_businesstypecode,
				fos_declarationaccepted, fos_aretheyotherwisecoveredunderthetemporaryp,
				fos_howisthefirminourjurisdiction, fos_preferredmethodofcontact, fos_preferredmethodofcorrespondence,
				fos_role, fos_islinkedorpartnered, fos_ismicroenterprise, fos_issmallmediumenterprise,
				fos_receivecorrespondence, fos_appointedrepresentativeid, fos_case, fos_representativecaselinkid,
				fos_individualid, fos_organisationid, fos_preferredemailaddress, fos_preferredphonenumber,
				fos_tradingname, fos_annualincome, fos_annualturnover, fos_balancesheet, fos_netassets, fos_caseid,
				fos_declarationdate, fos_extendedreference, fos_numberofemployees, fos_numberofpartners, fos_reference,
				versionnumber, createdby, modifiedby, modifiedon, createdon, fos_preferredemailaddressname,
				fos_tradingnamename, incrementaldataloadjobauditid);
	}

}
