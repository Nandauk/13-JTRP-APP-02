package com.ombudsman.service.repo;

import com.ombudsman.service.model.ContactData;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.junit.jupiter.api.extension.ExtendWith;

import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class ContactRepositoryTest {

    @Mock
    private ContactRepository contactRepository;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testInsertQuery() {
        // Given
        String contactid = "12345";
        Long statecode = 1L;
        Long fos_capacity = 2L;
        Long fos_contactdescriptionoption = 3L;
        Long fos_digitalportalinvitestatus = 4L;
        Long fos_isdigitalportaladmin = 5L;
        Long fos_parentorganisationcapacity = 6L;
        Long fos_phonerecordingconsent = 7L;
        Long fos_preferredmethodofcorrespondencecode = 8L;
        Long fos_surveyconsentcode = 9L;
        Long gendercode = 10L;
        Long preferredcontactmethodcode = 11L;
        Boolean donotemail = true;
        Boolean donotphone = false;
        Boolean donotpostalmail = true;
        String parentcontactid = "parent123";
        String parentcustomerid = "customer123";
        String address1_city = "City";
        String address1_composite = "Composite";
        String address1_country = "Country";
        String address1_county = "County";
        String address1_line1 = "Line1";
        String address1_line2 = "Line2";
        String address1_line3 = "Line3";
        String address1_name = "Name";
        String address1_postalcode = "PostalCode";
        String birthdate = "2000-01-01";
        String description = "Description";
        String emailaddress1 = "email@example.com";
        String firstname = "First";
        String fos_addressid = "address123";
        String fos_fcaid = "fca123";
        String fos_needstring = "needString";
        String fos_othertitle = "otherTitle";
        String fullname = "Full Name";
        String jobtitle = "Job Title";
        String lastname = "Last";
        String middlename = "Middle";
        String msa_managingpartneridname = "partnerName";
        String salutation = "Mr.";
        String suffix = "Jr.";
        String telephone1 = "123-456-7890";
        String telephone2 = "098-765-4321";
        Long versionnumber = 1L;
        String createdon = "2025-01-01";
        String modifiedon = "2025-01-01";
        String createdby = "creator";
        String modifiedby = "modifier";
        String incrementaldataloadjobauditid = "audit123";

        // When
        when(contactRepository.InsertQuery(contactid, statecode, fos_capacity, fos_contactdescriptionoption,
                fos_digitalportalinvitestatus, fos_isdigitalportaladmin, fos_parentorganisationcapacity,
                fos_phonerecordingconsent, fos_preferredmethodofcorrespondencecode, fos_surveyconsentcode,
                gendercode, preferredcontactmethodcode, donotemail, donotphone, donotpostalmail, parentcontactid,
                parentcustomerid, address1_city, address1_composite, address1_country, address1_county,
                address1_line1, address1_line2, address1_line3, address1_name, address1_postalcode, birthdate,
                description, emailaddress1, firstname, fos_addressid, fos_fcaid, fos_needstring, fos_othertitle,
                fullname, jobtitle, lastname, middlename, msa_managingpartneridname, salutation, suffix, telephone1,
                telephone2, versionnumber, createdby, modifiedby, modifiedon, createdon, incrementaldataloadjobauditid))
            .thenReturn(1);

        // Call the method with the correct arguments
        int result = contactRepository.InsertQuery(contactid, statecode, fos_capacity, fos_contactdescriptionoption,
                fos_digitalportalinvitestatus, fos_isdigitalportaladmin, fos_parentorganisationcapacity,
                fos_phonerecordingconsent, fos_preferredmethodofcorrespondencecode, fos_surveyconsentcode,
                gendercode, preferredcontactmethodcode, donotemail, donotphone, donotpostalmail, parentcontactid,
                parentcustomerid, address1_city, address1_composite, address1_country, address1_county,
                address1_line1, address1_line2, address1_line3, address1_name, address1_postalcode, birthdate,
                description, emailaddress1, firstname, fos_addressid, fos_fcaid, fos_needstring, fos_othertitle,
                fullname, jobtitle, lastname, middlename, msa_managingpartneridname, salutation, suffix, telephone1,
                telephone2, versionnumber, createdby, modifiedby, modifiedon, createdon, incrementaldataloadjobauditid);

        verify(contactRepository, times(1)).InsertQuery(contactid, statecode, fos_capacity, fos_contactdescriptionoption,
                fos_digitalportalinvitestatus, fos_isdigitalportaladmin, fos_parentorganisationcapacity,
                fos_phonerecordingconsent, fos_preferredmethodofcorrespondencecode, fos_surveyconsentcode,
                gendercode, preferredcontactmethodcode, donotemail, donotphone, donotpostalmail, parentcontactid,
                parentcustomerid, address1_city, address1_composite, address1_country, address1_county,
                address1_line1, address1_line2, address1_line3, address1_name, address1_postalcode, birthdate,
                description, emailaddress1, firstname, fos_addressid, fos_fcaid, fos_needstring, fos_othertitle,
                fullname, jobtitle, lastname, middlename, msa_managingpartneridname, salutation, suffix, telephone1,
                telephone2, versionnumber, createdby, modifiedby, modifiedon, createdon, incrementaldataloadjobauditid);
    }
}
