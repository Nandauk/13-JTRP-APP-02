package com.ombudsman.service.common;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

public class ConstantsconfigTest {

	@Test
	public void testConstantsConfigValues() {
		Constantsconfig constantsconfig = new Constantsconfig();

		// Set values directly
		constantsconfig.Entity_Caselink = "TestCaselink";
		constantsconfig.APIM_HOST = "TestHost";
		constantsconfig.Fetchxml_Record = 10;

		constantsconfig.In_Progress = "In_Progress";
		constantsconfig.Pending = "Pending";
		constantsconfig.Completed = "Completed";
		constantsconfig.Ready_To_Process = "Ready_To_Process";
		constantsconfig.Terminated = "Terminated";
		constantsconfig.Failed = "Failed";
		constantsconfig.Error_log = "PHOENIX_001";
		constantsconfig.Error_log_phx_sql = "PHOENIX_OR_SQL_001";
		constantsconfig.DataSourceName = "SCH";

		constantsconfig.Caselink = "fos_caselink";
		constantsconfig.Contact = "contact";

		// Test values
		assertEquals("TestCaselink", constantsconfig.Entity_Caselink);
		assertEquals("TestHost", constantsconfig.APIM_HOST);
		assertEquals(10, constantsconfig.Fetchxml_Record);

		assertEquals("In_Progress", constantsconfig.In_Progress);
		assertEquals("Pending", constantsconfig.Pending);
		assertEquals("Completed", constantsconfig.Completed);
		assertEquals("Ready_To_Process", constantsconfig.Ready_To_Process);
		assertEquals("Terminated", constantsconfig.Terminated);
		assertEquals("Failed", constantsconfig.Failed);
		assertEquals("PHOENIX_001", constantsconfig.Error_log);
		assertEquals("PHOENIX_OR_SQL_001", constantsconfig.Error_log_phx_sql);
		assertEquals("SCH", constantsconfig.DataSourceName);

		assertEquals("fos_caselink", constantsconfig.Caselink);
		assertEquals("contact", constantsconfig.Contact);
	}
}
