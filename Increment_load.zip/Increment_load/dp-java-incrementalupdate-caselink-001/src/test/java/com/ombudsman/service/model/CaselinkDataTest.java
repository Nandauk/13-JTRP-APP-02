package com.ombudsman.service.model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.math.BigDecimal;

import org.junit.jupiter.api.Test;

public class CaselinkDataTest {

	@Test
	public void testGettersAndSetters() {
		CaselinkData caselinkData = new CaselinkData();

		// Set values using setters
		caselinkData.setStatecode(1L);
		caselinkData.setStatuscode(2L);
		caselinkData.setFos_caselinkid("link123");
		caselinkData.setFos_businesstypecode(123L);
		caselinkData.setFos_declarationaccepted(321L);
		caselinkData.setFos_aretheyotherwisecoveredunderthetemporaryp(true);
		caselinkData.setFos_islinkedorpartnered(true);
		caselinkData.setFos_ismicroenterprise(false);
		caselinkData.setFos_issmallmediumenterprise(true);
		caselinkData.setFos_receivecorrespondence(false);
		caselinkData.setFos_howisthefirminourjurisdiction(111L);
		caselinkData.setFos_preferredmethodofcontact(222L);
		caselinkData.setFos_preferredmethodofcorrespondence(333L);
		caselinkData.setFos_role(444L);
		caselinkData.setFos_appointedrepresentativeid("rep123");
		caselinkData.setFos_individualid("ind123");
		caselinkData.setFos_organisationid("org123");
		caselinkData.setFos_preferredemailaddress("email@example.com");
		caselinkData.setFos_preferredphonenumber("123-456-7890");
		caselinkData.setFos_representativecaselinkid("repLink123");
		caselinkData.setFos_tradingname("TradeName");
		caselinkData.setFos_annualincome(BigDecimal.valueOf(100000.00));
		caselinkData.setFos_annualturnover(BigDecimal.valueOf(200000.00));
		caselinkData.setFos_balancesheet(BigDecimal.valueOf(300000.00));
		caselinkData.setFos_netassets(BigDecimal.valueOf(400000.00));
		caselinkData.setFos_caseid("case123");
		caselinkData.setFos_declarationdate("2024-01-01T00:00:00Z");
		caselinkData.setFos_extendedreference("extRef123");
		caselinkData.setFos_numberofemployees(50L);
		caselinkData.setFos_numberofpartners(10L);
		caselinkData.setFos_reference("ref123");
		caselinkData.setVersionnumber(1L);
		caselinkData.setCreatedon("2023-09-21T14:30:00Z");
		caselinkData.setModifiedon("2023-09-21T15:00:00Z");
		caselinkData.setCreatedby("John Doe");
		caselinkData.setModifiedby("Jane Doe");
		caselinkData.setFos_case("caseData");
		caselinkData.setIncrementaldataloadjobauditid("audit123");
		caselinkData.setFos_preferredemailaddressname("PreferredEmail");
		caselinkData.setFos_tradingnamename("TradingName");

		// Test getters
		assertEquals(1L, caselinkData.getStatecode());
		assertEquals(2L, caselinkData.getStatuscode());
		assertEquals("link123", caselinkData.getFos_caselinkid());
		assertEquals(123L, caselinkData.getFos_businesstypecode());
		assertEquals(321L, caselinkData.getFos_declarationaccepted());
		assertEquals(true, caselinkData.getFos_aretheyotherwisecoveredunderthetemporaryp());
		assertEquals(true, caselinkData.getFos_islinkedorpartnered());
		assertEquals(false, caselinkData.getFos_ismicroenterprise());
		assertEquals(true, caselinkData.getFos_issmallmediumenterprise());
		assertEquals(false, caselinkData.getFos_receivecorrespondence());
		assertEquals(111L, caselinkData.getFos_howisthefirminourjurisdiction());
		assertEquals(222L, caselinkData.getFos_preferredmethodofcontact());
		assertEquals(333L, caselinkData.getFos_preferredmethodofcorrespondence());
		assertEquals(444L, caselinkData.getFos_role());
		assertEquals("rep123", caselinkData.getFos_appointedrepresentativeid());
		assertEquals("ind123", caselinkData.getFos_individualid());
		assertEquals("org123", caselinkData.getFos_organisationid());
		assertEquals("email@example.com", caselinkData.getFos_preferredemailaddress());
		assertEquals("123-456-7890", caselinkData.getFos_preferredphonenumber());
		assertEquals("repLink123", caselinkData.getFos_representativecaselinkid());
		assertEquals("TradeName", caselinkData.getFos_tradingname());
		assertEquals(BigDecimal.valueOf(100000.00), caselinkData.getFos_annualincome());
		assertEquals(BigDecimal.valueOf(200000.00), caselinkData.getFos_annualturnover());
		assertEquals(BigDecimal.valueOf(300000.00), caselinkData.getFos_balancesheet());
		assertEquals(BigDecimal.valueOf(400000.00), caselinkData.getFos_netassets());
		assertEquals("case123", caselinkData.getFos_caseid());
		assertEquals("2024-01-01T00:00:00Z", caselinkData.getFos_declarationdate());
		assertEquals("extRef123", caselinkData.getFos_extendedreference());
		assertEquals(50L, caselinkData.getFos_numberofemployees());
		assertEquals(10L, caselinkData.getFos_numberofpartners());
		assertEquals("ref123", caselinkData.getFos_reference());
		assertEquals(1L, caselinkData.getVersionnumber());
		assertEquals("2023-09-21T14:30:00Z", caselinkData.getCreatedon());
		assertEquals("2023-09-21T15:00:00Z", caselinkData.getModifiedon());
		assertEquals("John Doe", caselinkData.getCreatedby());
		assertEquals("Jane Doe", caselinkData.getModifiedby());
		assertEquals("caseData", caselinkData.getFos_case());
		assertEquals("audit123", caselinkData.getIncrementaldataloadjobauditid());
		assertEquals("PreferredEmail", caselinkData.getFos_preferredemailaddressname());
		assertEquals("TradingName", caselinkData.getFos_tradingnamename());
	}}