package com.ombudsman.service.model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

public class ContactDataTest {

	@Test
	public void testGetters() {
		ContactData contactData = new ContactData();

		// Set values using setters
		contactData.setContactid("contact123");
		contactData.setStatecode(1L);
		contactData.setFos_capacity(2L);
		contactData.setFos_contactdescriptionoption(3L);
		contactData.setFos_digitalportalinvitestatus(4L);
		contactData.setFos_isdigitalportaladmin(5L);
		contactData.setFos_parentorganisationcapacity(6L);
		contactData.setFos_phonerecordingconsent(7L);
		contactData.setFos_preferredmethodofcorrespondencecode(8L);
		contactData.setFos_surveyconsentcode(9L);
		contactData.setGendercode(10L);
		contactData.setPreferredcontactmethodcode(11L);
		contactData.setDonotemail(true);
		contactData.setDonotphone(false);
		contactData.setDonotpostalmail(true);
		contactData.setParentcustomerid("parentCustomer123");
		contactData.setParentcontactid("parentContact123");
		contactData.setAddress1_city("City One");
		contactData.setAddress1_composite("Composite One");
		contactData.setAddress1_country("Country One");
		contactData.setAddress1_county("County One");
		contactData.setAddress1_line1("Line1 One");
		contactData.setAddress1_line2("Line2 One");
		contactData.setAddress1_line3("Line3 One");
		contactData.setAddress1_name("Name One");
		contactData.setAddress1_postalcode("Postal Code One");
		contactData.setBirthdate("2000-01-01");
		contactData.setDescription("Description One");
		contactData.setEmailaddress1("email@one.com");
		contactData.setFirstname("First Name");
		contactData.setFos_addressid("address123");
		contactData.setFos_fcaid("fcaid123");
		contactData.setFos_needstring("needString123");
		contactData.setFos_othertitle("Other Title");
		contactData.setFullname("Full Name");
		contactData.setJobtitle("Job Title");
		contactData.setLastname("Last Name");
		contactData.setMiddlename("Middle Name");
		contactData.setMsa_managingpartneridname("Managing Partner");
		contactData.setSalutation("Mr.");
		contactData.setSuffix("Jr.");
		contactData.setTelephone1("123-456-7890");
		contactData.setTelephone2("098-765-4321");
		contactData.setVersionnumber(1L);
		contactData.setCreatedon("2023-08-21T14:30:00Z");
		contactData.setModifiedon("2023-08-21T15:00:00Z");
		contactData.setCreatedby("John Doe");
		contactData.setModifiedby("Jane Doe");
		contactData.setIncrementaldataloadjobauditid("audit-12345");

		// Test getters
		assertEquals("contact123", contactData.getContactid());
		assertEquals(1L, contactData.getStatecode());
		assertEquals(2L, contactData.getFos_capacity());
		assertEquals(3L, contactData.getFos_contactdescriptionoption());
		assertEquals(4L, contactData.getFos_digitalportalinvitestatus());
		assertEquals(5L, contactData.getFos_isdigitalportaladmin());
		assertEquals(6L, contactData.getFos_parentorganisationcapacity());
		assertEquals(7L, contactData.getFos_phonerecordingconsent());
		assertEquals(8L, contactData.getFos_preferredmethodofcorrespondencecode());
		assertEquals(9L, contactData.getFos_surveyconsentcode());
		assertEquals(10L, contactData.getGendercode());
		assertEquals(11L, contactData.getPreferredcontactmethodcode());
		assertEquals(true, contactData.getDonotemail());
		assertEquals(false, contactData.getDonotphone());
		assertEquals(true, contactData.getDonotpostalmail());
		assertEquals("parentCustomer123", contactData.getParentcustomerid());
		assertEquals("parentContact123", contactData.getParentcontactid());
		assertEquals("City One", contactData.getAddress1_city());
		assertEquals("Composite One", contactData.getAddress1_composite());
		assertEquals("Country One", contactData.getAddress1_country());
		assertEquals("County One", contactData.getAddress1_county());
		assertEquals("Line1 One", contactData.getAddress1_line1());
		assertEquals("Line2 One", contactData.getAddress1_line2());
		assertEquals("Line3 One", contactData.getAddress1_line3());
		assertEquals("Name One", contactData.getAddress1_name());
		assertEquals("Postal Code One", contactData.getAddress1_postalcode());
		assertEquals("2000-01-01", contactData.getBirthdate());
		assertEquals("Description One", contactData.getDescription());
		assertEquals("email@one.com", contactData.getEmailaddress1());
		assertEquals("First Name", contactData.getFirstname());
		assertEquals("address123", contactData.getFos_addressid());
		assertEquals("fcaid123", contactData.getFos_fcaid());
		assertEquals("needString123", contactData.getFos_needstring());
		assertEquals("Other Title", contactData.getFos_othertitle());
		assertEquals("Full Name", contactData.getFullname());
		assertEquals("Job Title", contactData.getJobtitle());
		assertEquals("Last Name", contactData.getLastname());
		assertEquals("Middle Name", contactData.getMiddlename());
		assertEquals("Managing Partner", contactData.getMsa_managingpartneridname());
		assertEquals("Mr.", contactData.getSalutation());
		assertEquals("Jr.", contactData.getSuffix());
		assertEquals("123-456-7890", contactData.getTelephone1());
		assertEquals("098-765-4321", contactData.getTelephone2());
		assertEquals(1L, contactData.getVersionnumber());
		assertEquals("2023-08-21T14:30:00Z", contactData.getCreatedon());
		assertEquals("2023-08-21T15:00:00Z", contactData.getModifiedon());
		assertEquals("John Doe", contactData.getCreatedby());
		assertEquals("Jane Doe", contactData.getModifiedby());
		assertEquals("audit-12345", contactData.getIncrementaldataloadjobauditid());
	}}
