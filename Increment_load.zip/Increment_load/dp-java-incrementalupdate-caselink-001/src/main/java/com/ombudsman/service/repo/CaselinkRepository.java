package com.ombudsman.service.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;
import java.math.BigDecimal;
import com.ombudsman.service.model.CaselinkData;

public interface CaselinkRepository extends JpaRepository<CaselinkData, String> {

	@Modifying
	@Transactional
	@Query(value = "INSERT INTO stg_caselink(statecode,statuscode,fos_caselinkid,fos_businesstypecode,fos_declarationaccepted,fos_aretheyotherwisecoveredunderthetemporaryp,fos_howisthefirminourjurisdiction,fos_preferredmethodofcontact,fos_preferredmethodofcorrespondence,fos_role,fos_islinkedorpartnered,fos_ismicroenterprise,fos_issmallmediumenterprise,fos_receivecorrespondence,fos_appointedrepresentativeid,fos_case,fos_representativecaselinkid,fos_individualid,fos_organisationid,fos_preferredemailaddress,fos_preferredphonenumber,fos_tradingname,fos_annualincome,fos_annualturnover,fos_balancesheet,fos_netassets,fos_caseid,fos_declarationdate,fos_extendedreference,fos_numberofemployees,fos_numberofpartners,fos_reference,versionnumber,createdby,modifiedby,modifiedon,createdon,fos_preferredemailaddressname,fos_tradingnamename,incrementaldataloadjobauditid) VALUES (:statecode, :statuscode,CONVERT(uniqueidentifier,:fos_caselinkid),:fos_businesstypecode,:fos_declarationaccepted,:fos_aretheyotherwisecoveredunderthetemporaryp,:fos_howisthefirminourjurisdiction,:fos_preferredmethodofcontact,:fos_preferredmethodofcorrespondence,:fos_role,:fos_islinkedorpartnered,:fos_ismicroenterprise,:fos_issmallmediumenterprise,:fos_receivecorrespondence,CONVERT(uniqueidentifier,:fos_appointedrepresentativeid),CONVERT(uniqueidentifier,:fos_case),CONVERT(uniqueidentifier,:fos_representativecaselinkid),CONVERT(uniqueidentifier,:fos_individualid),CONVERT(uniqueidentifier,:fos_organisationid),CONVERT(uniqueidentifier,:fos_preferredemailaddress),CONVERT(uniqueidentifier,:fos_preferredphonenumber),CONVERT(uniqueidentifier,:fos_tradingname),:fos_annualincome,:fos_annualturnover,:fos_balancesheet,:fos_netassets,:fos_caseid,:fos_declarationdate,:fos_extendedreference,:fos_numberofemployees,:fos_numberofpartners,:fos_reference,:versionnumber,CONVERT(uniqueidentifier,:createdby),CONVERT(uniqueidentifier,:modifiedby),:modifiedon,:createdon,:fos_preferredemailaddressname,:fos_tradingnamename,CONVERT(uniqueidentifier,:incrementaldataloadjobauditid))", nativeQuery = true)
	int InsertQuery(@Param("statecode") Long statecode, @Param("statuscode") Long statuscode,
			@Param("fos_caselinkid") String fos_caselinkid, @Param("fos_businesstypecode") Long fos_businesstypecode,
			@Param("fos_declarationaccepted") Long fos_declarationaccepted,
			@Param("fos_aretheyotherwisecoveredunderthetemporaryp") Boolean fos_aretheyotherwisecoveredunderthetemporaryp,
			@Param("fos_howisthefirminourjurisdiction") Long fos_howisthefirminourjurisdiction,
			@Param("fos_preferredmethodofcontact") Long fos_preferredmethodofcontact,
			@Param("fos_preferredmethodofcorrespondence") Long fos_preferredmethodofcorrespondence,
			@Param("fos_role") Long fos_role, @Param("fos_islinkedorpartnered") Boolean fos_islinkedorpartnered,
			@Param("fos_ismicroenterprise") Boolean fos_ismicroenterprise,
			@Param("fos_issmallmediumenterprise") Boolean fos_issmallmediumenterprise,
			@Param("fos_receivecorrespondence") Boolean fos_receivecorrespondence,
			@Param("fos_appointedrepresentativeid") String fos_appointedrepresentativeid,
			@Param("fos_case") String fos_case,
			@Param("fos_representativecaselinkid") String fos_representativecaselinkid,
			@Param("fos_individualid") String fos_individualid, @Param("fos_organisationid") String fos_organisationid,
			@Param("fos_preferredemailaddress") String fos_preferredemailaddress,
			@Param("fos_preferredphonenumber") String fos_preferredphonenumber,
			@Param("fos_tradingname") String fos_tradingname, @Param("fos_annualincome") BigDecimal fos_annualincome,
			@Param("fos_annualturnover") BigDecimal fos_annualturnover,
			@Param("fos_balancesheet") BigDecimal fos_balancesheet, @Param("fos_netassets") BigDecimal fos_netassets,
			@Param("fos_caseid") String fos_caseid, @Param("fos_declarationdate") String fos_declarationdate,
			@Param("fos_extendedreference") String fos_extendedreference,
			@Param("fos_numberofemployees") Long fos_numberofemployees,
			@Param("fos_numberofpartners") Long fos_numberofpartners, @Param("fos_reference") String fos_reference,
			@Param("versionnumber") Long versionnumber, @Param("createdby") String createdby,
			@Param("modifiedby") String modifiedby, @Param("modifiedon") String modifiedon,
			@Param("createdon") String createdon,
			@Param("fos_preferredemailaddressname") String fos_preferredemailaddressname,
			@Param("fos_tradingnamename") String fos_tradingnamename,
			@Param("incrementaldataloadjobauditid") String incrementaldataloadjobauditid);

}
