package com.ombudsman.service.model;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonFormat.Shape;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "stg_contact")
public class ContactData {

	@Id
	private String contactid;
	private Long statecode;
	private Long fos_capacity;
	private Long fos_contactdescriptionoption;
	private Long fos_digitalportalinvitestatus;
	private Long fos_isdigitalportaladmin;
	private Long fos_parentorganisationcapacity;
	private Long fos_phonerecordingconsent;
	private Long fos_preferredmethodofcorrespondencecode;
	private Long fos_surveyconsentcode;
	private Long gendercode;
	private Long preferredcontactmethodcode;
	@JsonFormat(shape = Shape.NUMBER)
	private Boolean donotemail;
	@JsonFormat(shape = Shape.NUMBER)
	private Boolean donotphone;
	@JsonFormat(shape = Shape.NUMBER)
	private Boolean donotpostalmail;
	private String parentcustomerid;
	private String parentcontactid;
	private String address1_city;
	private String address1_composite;
	private String address1_country;
	private String address1_county;
	private String address1_line1;
	private String address1_line2;
	private String address1_line3;
	private String address1_name;
	private String address1_postalcode;
	private String birthdate;
	private String description;
	private String emailaddress1;
	private String firstname;
	private String fos_addressid;
	private String fos_fcaid;
	private String fos_needstring;
	private String fos_othertitle;
	private String fullname;
	private String jobtitle;
	private String lastname;
	private String middlename;
	private String msa_managingpartneridname;
	private String salutation;
	private String suffix;
	private String telephone1;
	private String telephone2;
	private Long versionnumber;
	private String createdon;
	private String modifiedon;
	private String createdby;
	private String modifiedby;
	private String incrementaldataloadjobauditid;
	
	

	public String getIncrementaldataloadjobauditid() {
		return incrementaldataloadjobauditid;
	}

	public void setIncrementaldataloadjobauditid(String incrementaldataloadjobauditid) {
		this.incrementaldataloadjobauditid = incrementaldataloadjobauditid;
	}

	public String getContactid() {
		return contactid;
	}

	public void setContactid(String contactid) {
		this.contactid = contactid;
	}

	public Long getStatecode() {
		return statecode;
	}

	public void setStatecode(Long statecode) {
		this.statecode = statecode;
	}

	public Long getFos_capacity() {
		return fos_capacity;
	}

	public void setFos_capacity(Long fos_capacity) {
		this.fos_capacity = fos_capacity;
	}

	public Long getFos_contactdescriptionoption() {
		return fos_contactdescriptionoption;
	}

	public void setFos_contactdescriptionoption(Long fos_contactdescriptionoption) {
		this.fos_contactdescriptionoption = fos_contactdescriptionoption;
	}

	public Long getFos_digitalportalinvitestatus() {
		return fos_digitalportalinvitestatus;
	}

	public void setFos_digitalportalinvitestatus(Long fos_digitalportalinvitestatus) {
		this.fos_digitalportalinvitestatus = fos_digitalportalinvitestatus;
	}

	public Long getFos_isdigitalportaladmin() {
		return fos_isdigitalportaladmin;
	}

	public void setFos_isdigitalportaladmin(Long fos_isdigitalportaladmin) {
		this.fos_isdigitalportaladmin = fos_isdigitalportaladmin;
	}

	public Long getFos_parentorganisationcapacity() {
		return fos_parentorganisationcapacity;
	}

	public void setFos_parentorganisationcapacity(Long fos_parentorganisationcapacity) {
		this.fos_parentorganisationcapacity = fos_parentorganisationcapacity;
	}

	public Long getFos_phonerecordingconsent() {
		return fos_phonerecordingconsent;
	}

	public void setFos_phonerecordingconsent(Long fos_phonerecordingconsent) {
		this.fos_phonerecordingconsent = fos_phonerecordingconsent;
	}

	public Long getFos_preferredmethodofcorrespondencecode() {
		return fos_preferredmethodofcorrespondencecode;
	}

	public void setFos_preferredmethodofcorrespondencecode(Long fos_preferredmethodofcorrespondencecode) {
		this.fos_preferredmethodofcorrespondencecode = fos_preferredmethodofcorrespondencecode;
	}

	public Long getFos_surveyconsentcode() {
		return fos_surveyconsentcode;
	}

	public void setFos_surveyconsentcode(Long fos_surveyconsentcode) {
		this.fos_surveyconsentcode = fos_surveyconsentcode;
	}

	public Long getGendercode() {
		return gendercode;
	}

	public void setGendercode(Long gendercode) {
		this.gendercode = gendercode;
	}

	public Long getPreferredcontactmethodcode() {
		return preferredcontactmethodcode;
	}

	public void setPreferredcontactmethodcode(Long preferredcontactmethodcode) {
		this.preferredcontactmethodcode = preferredcontactmethodcode;
	}

	public Boolean getDonotemail() {
		return donotemail;
	}

	public void setDonotemail(Boolean donotemail) {
		this.donotemail = donotemail;
	}

	public Boolean getDonotphone() {
		return donotphone;
	}

	public void setDonotphone(Boolean donotphone) {
		this.donotphone = donotphone;
	}

	public Boolean getDonotpostalmail() {
		return donotpostalmail;
	}

	public void setDonotpostalmail(Boolean donotpostalmail) {
		this.donotpostalmail = donotpostalmail;
	}

	public String getParentcustomerid() {
		return parentcustomerid;
	}

	public void setParentcustomerid(String parentcustomerid) {
		this.parentcustomerid = parentcustomerid;
	}

	public String getParentcontactid() {
		return parentcontactid;
	}

	public void setParentcontactid(String parentcontactid) {
		this.parentcontactid = parentcontactid;
	}

	public String getAddress1_city() {
		return address1_city;
	}

	public void setAddress1_city(String address1_city) {
		this.address1_city = address1_city;
	}

	public String getAddress1_composite() {
		return address1_composite;
	}

	public void setAddress1_composite(String address1_composite) {
		this.address1_composite = address1_composite;
	}

	public String getAddress1_country() {
		return address1_country;
	}

	public void setAddress1_country(String address1_country) {
		this.address1_country = address1_country;
	}

	public String getAddress1_county() {
		return address1_county;
	}

	public void setAddress1_county(String address1_county) {
		this.address1_county = address1_county;
	}

	public String getAddress1_line1() {
		return address1_line1;
	}

	public void setAddress1_line1(String address1_line1) {
		this.address1_line1 = address1_line1;
	}

	public String getAddress1_line2() {
		return address1_line2;
	}

	public void setAddress1_line2(String address1_line2) {
		this.address1_line2 = address1_line2;
	}

	public String getAddress1_line3() {
		return address1_line3;
	}

	public void setAddress1_line3(String address1_line3) {
		this.address1_line3 = address1_line3;
	}

	public String getAddress1_name() {
		return address1_name;
	}

	public void setAddress1_name(String address1_name) {
		this.address1_name = address1_name;
	}

	public String getAddress1_postalcode() {
		return address1_postalcode;
	}

	public void setAddress1_postalcode(String address1_postalcode) {
		this.address1_postalcode = address1_postalcode;
	}

	public String getBirthdate() {
		return birthdate;
	}

	public void setBirthdate(String birthdate) {
		this.birthdate = birthdate;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getEmailaddress1() {
		return emailaddress1;
	}

	public void setEmailaddress1(String emailaddress1) {
		this.emailaddress1 = emailaddress1;
	}

	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getFos_addressid() {
		return fos_addressid;
	}

	public void setFos_addressid(String fos_addressid) {
		this.fos_addressid = fos_addressid;
	}

	public String getFos_fcaid() {
		return fos_fcaid;
	}

	public void setFos_fcaid(String fos_fcaid) {
		this.fos_fcaid = fos_fcaid;
	}

	public String getFos_needstring() {
		return fos_needstring;
	}

	public void setFos_needstring(String fos_needstring) {
		this.fos_needstring = fos_needstring;
	}

	public String getFos_othertitle() {
		return fos_othertitle;
	}

	public void setFos_othertitle(String fos_othertitle) {
		this.fos_othertitle = fos_othertitle;
	}

	public String getFullname() {
		return fullname;
	}

	public void setFullname(String fullname) {
		this.fullname = fullname;
	}

	public String getJobtitle() {
		return jobtitle;
	}

	public void setJobtitle(String jobtitle) {
		this.jobtitle = jobtitle;
	}

	public String getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public String getMiddlename() {
		return middlename;
	}

	public void setMiddlename(String middlename) {
		this.middlename = middlename;
	}

	public String getMsa_managingpartneridname() {
		return msa_managingpartneridname;
	}

	public void setMsa_managingpartneridname(String msa_managingpartneridname) {
		this.msa_managingpartneridname = msa_managingpartneridname;
	}

	public String getSalutation() {
		return salutation;
	}

	public void setSalutation(String salutation) {
		this.salutation = salutation;
	}

	public String getSuffix() {
		return suffix;
	}

	public void setSuffix(String suffix) {
		this.suffix = suffix;
	}

	public String getTelephone1() {
		return telephone1;
	}

	public void setTelephone1(String telephone1) {
		this.telephone1 = telephone1;
	}

	public String getTelephone2() {
		return telephone2;
	}

	public void setTelephone2(String telephone2) {
		this.telephone2 = telephone2;
	}

	public Long getVersionnumber() {
		return versionnumber;
	}

	public void setVersionnumber(Long versionnumber) {
		this.versionnumber = versionnumber;
	}

	public String getCreatedon() {
		return createdon;
	}

	public void setCreatedon(String createdon) {
		this.createdon = createdon;
	}

	public String getModifiedon() {
		return modifiedon;
	}

	public void setModifiedon(String modifiedon) {
		this.modifiedon = modifiedon;
	}

	public String getCreatedby() {
		return createdby;
	}

	public void setCreatedby(String createdby) {
		this.createdby = createdby;
	}

	public String getModifiedby() {
		return modifiedby;
	}

	public void setModifiedby(String modifiedby) {
		this.modifiedby = modifiedby;
	}

	public LocalDateTime getModifiedonSorting() {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss'Z'");
		return LocalDateTime.parse(modifiedon, formatter);
	}

}
