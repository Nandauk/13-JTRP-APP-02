package com.ombudsman.service.services;

import java.io.IOException;

public interface CaselinkPhxToSqlService {

	void caselinkUpdatePnxtoSql() throws  IOException,  InterruptedException;

	void caselinkUpdatePnxtoSql_recon(String Start_time, String End_time) throws  IOException,  InterruptedException;
}
