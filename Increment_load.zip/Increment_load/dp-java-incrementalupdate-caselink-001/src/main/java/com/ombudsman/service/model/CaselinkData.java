package com.ombudsman.service.model;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.math.BigDecimal;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonFormat.Shape;

@Entity
@Table(name = "stg_caselink")
public class CaselinkData {

	private Long statecode;
	private Long statuscode;
	@Id
	private String fos_caselinkid;
	private Long fos_businesstypecode;
	private Long fos_declarationaccepted;
	@JsonFormat(shape = Shape.NUMBER)
	private Boolean fos_aretheyotherwisecoveredunderthetemporaryp;
	@JsonFormat(shape = Shape.NUMBER)
	private Boolean fos_islinkedorpartnered;
	@JsonFormat(shape = Shape.NUMBER)
	private Boolean fos_ismicroenterprise;
	@JsonFormat(shape = Shape.NUMBER)
	private Boolean fos_issmallmediumenterprise;
	@JsonFormat(shape = Shape.NUMBER)
	private Boolean fos_receivecorrespondence;
	private Long fos_howisthefirminourjurisdiction;
	private Long fos_preferredmethodofcontact;
	private Long fos_preferredmethodofcorrespondence;
	private Long fos_role;
	private String fos_appointedrepresentativeid;
	private String fos_individualid;
	private String fos_organisationid;
	private String fos_preferredemailaddress;
	private String fos_preferredphonenumber;
	private String fos_representativecaselinkid;
	private String fos_tradingname;
	private BigDecimal fos_annualincome;
	private BigDecimal fos_annualturnover;
	private BigDecimal fos_balancesheet;
	private BigDecimal fos_netassets;
	private String fos_caseid;
	private String fos_declarationdate;
	private String fos_extendedreference;
	private Long fos_numberofemployees;
	private Long fos_numberofpartners;
	private String fos_reference;
	private Long versionnumber;
	private String createdon;
	private String modifiedon;
	private String createdby;
	private String modifiedby;
	@Column(nullable = false)
	private String fos_case;
	private String incrementaldataloadjobauditid;
	private String fos_preferredemailaddressname;
	private String fos_tradingnamename;

	public String getFos_preferredemailaddressname() {
		return fos_preferredemailaddressname;
	}

	public void setFos_preferredemailaddressname(String fos_preferredemailaddressname) {
		this.fos_preferredemailaddressname = fos_preferredemailaddressname;
	}

	public String getFos_tradingnamename() {
		return fos_tradingnamename;
	}

	public void setFos_tradingnamename(String fos_tradingnamename) {
		this.fos_tradingnamename = fos_tradingnamename;
	}

	public String getIncrementaldataloadjobauditid() {
		return incrementaldataloadjobauditid;
	}

	public void setIncrementaldataloadjobauditid(String incrementaldataloadjobauditid) {
		this.incrementaldataloadjobauditid = incrementaldataloadjobauditid;
	}

	public String getModifiedon() {
		return modifiedon;
	}

	public void setModifiedon(String modifiedon) {
		this.modifiedon = modifiedon;
	}

	public Long getStatecode() {
		return statecode;
	}

	public void setStatecode(Long statecode) {
		this.statecode = statecode;
	}

	public Long getStatuscode() {
		return statuscode;
	}

	public void setStatuscode(Long statuscode) {
		this.statuscode = statuscode;
	}

	public String getFos_caselinkid() {
		return fos_caselinkid;
	}

	public void setFos_caselinkid(String fos_caselinkid) {
		this.fos_caselinkid = fos_caselinkid;
	}

	public Long getFos_businesstypecode() {
		return fos_businesstypecode;
	}

	public void setFos_businesstypecode(Long fos_businesstypecode) {
		this.fos_businesstypecode = fos_businesstypecode;
	}

	public Long getFos_declarationaccepted() {
		return fos_declarationaccepted;
	}

	public void setFos_declarationaccepted(Long fos_declarationaccepted) {
		this.fos_declarationaccepted = fos_declarationaccepted;
	}

	public Boolean getFos_aretheyotherwisecoveredunderthetemporaryp() {
		return fos_aretheyotherwisecoveredunderthetemporaryp;
	}

	public void setFos_aretheyotherwisecoveredunderthetemporaryp(
			Boolean fos_aretheyotherwisecoveredunderthetemporaryp) {
		this.fos_aretheyotherwisecoveredunderthetemporaryp = fos_aretheyotherwisecoveredunderthetemporaryp;
	}

	public Long getFos_howisthefirminourjurisdiction() {
		return fos_howisthefirminourjurisdiction;
	}

	public void setFos_howisthefirminourjurisdiction(Long fos_howisthefirminourjurisdiction) {
		this.fos_howisthefirminourjurisdiction = fos_howisthefirminourjurisdiction;
	}

	public Long getFos_preferredmethodofcontact() {
		return fos_preferredmethodofcontact;
	}

	public void setFos_preferredmethodofcontact(Long fos_preferredmethodofcontact) {
		this.fos_preferredmethodofcontact = fos_preferredmethodofcontact;
	}

	public Long getFos_preferredmethodofcorrespondence() {
		return fos_preferredmethodofcorrespondence;
	}

	public void setFos_preferredmethodofcorrespondence(Long fos_preferredmethodofcorrespondence) {
		this.fos_preferredmethodofcorrespondence = fos_preferredmethodofcorrespondence;
	}

	public Long getFos_role() {
		return fos_role;
	}

	public void setFos_role(Long fos_role) {
		this.fos_role = fos_role;
	}

	public Boolean getFos_islinkedorpartnered() {
		return fos_islinkedorpartnered;
	}

	public void setFos_islinkedorpartnered(Boolean fos_islinkedorpartnered) {
		this.fos_islinkedorpartnered = fos_islinkedorpartnered;
	}

	public Boolean getFos_ismicroenterprise() {
		return fos_ismicroenterprise;
	}

	public void setFos_ismicroenterprise(Boolean fos_ismicroenterprise) {
		this.fos_ismicroenterprise = fos_ismicroenterprise;
	}

	public Boolean getFos_issmallmediumenterprise() {
		return fos_issmallmediumenterprise;
	}

	public void setFos_issmallmediumenterprise(Boolean fos_issmallmediumenterprise) {
		this.fos_issmallmediumenterprise = fos_issmallmediumenterprise;
	}

	public Boolean getFos_receivecorrespondence() {
		return fos_receivecorrespondence;
	}

	public void setFos_receivecorrespondence(Boolean fos_receivecorrespondence) {
		this.fos_receivecorrespondence = fos_receivecorrespondence;
	}

	public String getFos_appointedrepresentativeid() {
		return fos_appointedrepresentativeid;
	}

	public void setFos_appointedrepresentativeid(String fos_appointedrepresentativeid) {
		this.fos_appointedrepresentativeid = fos_appointedrepresentativeid;
	}

	public String getFos_case() {
		return fos_case;
	}

	public void setFos_case(String fos_case) {
		this.fos_case = fos_case;
	}

	public String getFos_individualid() {
		return fos_individualid;
	}

	public void setFos_individualid(String fos_individualid) {
		this.fos_individualid = fos_individualid;
	}

	public String getFos_organisationid() {
		return fos_organisationid;
	}

	public void setFos_organisationid(String fos_organisationid) {
		this.fos_organisationid = fos_organisationid;
	}

	public String getFos_preferredemailaddress() {
		return fos_preferredemailaddress;
	}

	public void setFos_preferredemailaddress(String fos_preferredemailaddress) {
		this.fos_preferredemailaddress = fos_preferredemailaddress;
	}

	public String getFos_preferredphonenumber() {
		return fos_preferredphonenumber;
	}

	public void setFos_preferredphonenumber(String fos_preferredphonenumber) {
		this.fos_preferredphonenumber = fos_preferredphonenumber;
	}

	public String getFos_representativecaselinkid() {
		return fos_representativecaselinkid;
	}

	public void setFos_representativecaselinkid(String fos_representativecaselinkid) {
		this.fos_representativecaselinkid = fos_representativecaselinkid;
	}

	public String getFos_tradingname() {
		return fos_tradingname;
	}

	public void setFos_tradingname(String fos_tradingname) {
		this.fos_tradingname = fos_tradingname;
	}

	public BigDecimal getFos_annualincome() {
		return fos_annualincome;
	}

	public void setFos_annualincome(BigDecimal fos_annualincome) {
		this.fos_annualincome = fos_annualincome;
	}

	public BigDecimal getFos_annualturnover() {
		return fos_annualturnover;
	}

	public void setFos_annualturnover(BigDecimal fos_annualturnover) {
		this.fos_annualturnover = fos_annualturnover;
	}

	public BigDecimal getFos_balancesheet() {
		return fos_balancesheet;
	}

	public void setFos_balancesheet(BigDecimal fos_balancesheet) {
		this.fos_balancesheet = fos_balancesheet;
	}

	public BigDecimal getFos_netassets() {
		return fos_netassets;
	}

	public void setFos_netassets(BigDecimal fos_netassets) {
		this.fos_netassets = fos_netassets;
	}

	public String getFos_caseid() {
		return fos_caseid;
	}

	public void setFos_caseid(String fos_caseid) {
		this.fos_caseid = fos_caseid;
	}

	

	public String getFos_extendedreference() {
		return fos_extendedreference;
	}

	public void setFos_extendedreference(String fos_extendedreference) {
		this.fos_extendedreference = fos_extendedreference;
	}

	public Long getFos_numberofemployees() {
		return fos_numberofemployees;
	}

	public void setFos_numberofemployees(Long fos_numberofemployees) {
		this.fos_numberofemployees = fos_numberofemployees;
	}

	public Long getFos_numberofpartners() {
		return fos_numberofpartners;
	}

	public void setFos_numberofpartners(Long fos_numberofpartners) {
		this.fos_numberofpartners = fos_numberofpartners;
	}

	public String getFos_reference() {
		return fos_reference;
	}

	public void setFos_reference(String fos_reference) {
		this.fos_reference = fos_reference;
	}

	public Long getVersionnumber() {
		return versionnumber;
	}

	public void setVersionnumber(Long versionnumber) {
		this.versionnumber = versionnumber;
	}

	public String getCreatedon() {
		return createdon;
	}

	public void setCreatedon(String createdon) {
		this.createdon = createdon;
	}

	public String getCreatedby() {
		return createdby;
	}

	public void setCreatedby(String createdby) {
		this.createdby = createdby;
	}

	public String getModifiedby() {
		return modifiedby;
	}

	public void setModifiedby(String modifiedby) {
		this.modifiedby = modifiedby;
	}
	
	public LocalDateTime getModifiedonSorting() {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss'Z'");
		return LocalDateTime.parse(modifiedon,formatter);
	}

	public String getFos_declarationdate() {
		return fos_declarationdate;
	}

	public void setFos_declarationdate(String fos_declarationdate) {
		this.fos_declarationdate = fos_declarationdate;
	}

}


