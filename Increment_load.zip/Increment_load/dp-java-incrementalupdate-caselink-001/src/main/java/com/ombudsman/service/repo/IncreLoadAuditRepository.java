package com.ombudsman.service.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.ombudsman.service.model.IncreLoadAuditData;

public interface IncreLoadAuditRepository extends JpaRepository<IncreLoadAuditData, String> {

	@Modifying
	@Transactional
	@Query(value = "INSERT INTO dp_incremental_data_load_job_audit (job_id,job_start_date_time,total_number_of_records,number_of_processed_record,number_of_failed_record,current_job_status_id,job_close_datetime,"
			+ "source,created_by,modified_by) VALUES (:JobId,:job_start_date_time,:total_number_of_records,:number_of_processed_record,:number_of_failed_record,:current_job_status_id,:job_close_datetime,:source,:created_by,:modified_by)", nativeQuery = true)
	int InsertQuery(@Param("JobId") Integer job_id, @Param("job_start_date_time") String startWebJob_formatted,
			@Param("total_number_of_records") Integer total_number_of_records,
			@Param("number_of_processed_record") Long number_of_processed_record,
			@Param("number_of_failed_record") Integer number_of_failed_record,
			@Param("current_job_status_id") Integer current_job_status_id,
			@Param("job_close_datetime") String job_close_datetime, @Param("source") String source,
			@Param("created_by") String created_by, @Param("modified_by") String modified_by);

	@Query(value = "select id from dp_key_pair_master_data where data_source_name=:DataSourceName and item_value=:In_Progress", nativeQuery = true)
	int getCurrentStatusIPId(@Param("DataSourceName") String DataSourceName, @Param("In_Progress") String In_Progress);

	@Query(value = "select id from dp_key_pair_master_data where data_source_name=:DataSourceName and item_value=:Ready_To_Process", nativeQuery = true)
	int getCurrentStatusRTPId(@Param("DataSourceName") String DataSourceName,
			@Param("Ready_To_Process") String Ready_To_Process);

	@Query(value = "select id from dp_key_pair_master_data where data_source_name=:DataSourceName and item_value=:Failed", nativeQuery = true)
	int getCurrentStatusFId(@Param("DataSourceName") String DataSourceName, @Param("Failed") String Failed);

	@Query(value = "select incremental_data_load_audit_id from dp_incremental_data_load_job_audit where current_job_status_id=:current_job_status_id and source=:data_source_name and job_start_date_time=:startWebJob and created_by=:created_by", nativeQuery = true)
	String getIncrementalDataLoadAuditId(@Param("startWebJob") String formattedtime,
			@Param("current_job_status_id") Integer current_job_status_id,
			@Param("data_source_name") String data_source_name, @Param("created_by") String created_by);

	@Query(value = "select job_id from dp_job_master where created_by=:created_by", nativeQuery = true)
	int getJobID(@Param("created_by") String created_by);

	@Query(value = "select distinct(data_source_name) from dp_key_pair_master_data where created_by=:created_by", nativeQuery = true)
	String getDataSourceName(@Param("created_by") String created_by);

	

	@Modifying
	@Transactional
	@Query(value = "Update dp_incremental_data_load_job_audit set total_number_of_records=:total_number_of_records,number_of_processed_record=:number_of_processed_record,number_of_failed_record=:number_of_failed_record,current_job_status_id=:current_job_status_id,job_close_datetime=:job_close_datetime,modified_by=:modified_by where incremental_data_load_audit_id=:incremental_data_load_audit_id", nativeQuery = true)
	void UpdateQuery(@Param("total_number_of_records") Long total_number_of_records,
			@Param("number_of_processed_record") Long number_of_processed_record,
			@Param("number_of_failed_record") Integer number_of_failed_record,
			@Param("current_job_status_id") Integer current_job_status_id,
			@Param("job_close_datetime") String job_close_datetime,
			@Param("incremental_data_load_audit_id") String incremental_data_load_audit_id,
			@Param("modified_by") String modified_by);

	@Query(value = "select cast(last_processed_datetime as DATETIME2(0)) as lpd from dp_incremental_last_processed_datetime where process_name=:process_name", nativeQuery = true)
	String findLatestDatefromphx(@Param("process_name") String process_name);

	@Modifying
	@Transactional
	@Query(value = "Update dp_incremental_last_processed_datetime set last_processed_datetime=:latestModifiedOnDatePhx where process_name=:process_name", nativeQuery = true)
	void UpdateLatestDateCtlTbl(@Param("latestModifiedOnDatePhx") String latestModifiedOnDatePhx,
			@Param("process_name") String process_name);
	
	@Query(value = "select count(*) from dp_incremental_data_load_job_audit where current_job_status_id IN (:current_status_id_failed,:current_status_id_failed_azurfunc,:current_status_id_failed_deleterecon) and job_start_date_time >= :last7DaysTimeStamp", nativeQuery = true)
	int getFailedEntries(@Param("current_status_id_failed") int current_status_id_failed,
			@Param("current_status_id_failed_azurfunc") int current_status_id_failed_azurfunc,
			@Param("current_status_id_failed_deleterecon") int current_status_id_failed_deleterecon,
			@Param("last7DaysTimeStamp") String last7DaysTimeStamp);


}