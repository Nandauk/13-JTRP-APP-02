package com.ombudsman.service.response;

import java.util.List;

import com.ombudsman.service.model.CaselinkData;

public class CaselinkRes {

	private List<CaselinkData> caselinkData;

	public List<CaselinkData> getCaselinkData() {
		return caselinkData;
	}

	public void setCaselinkData(List<CaselinkData> caselinkData) {
		this.caselinkData = caselinkData;
	}

}
