package com.ombudsman.service;

import java.io.IOException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.web.bind.annotation.ResponseBody;
import com.microsoft.applicationinsights.attach.ApplicationInsights;
import com.microsoft.applicationinsights.connectionstring.ConnectionString;
import com.ombudsman.service.common.KeyVaultUtil;
import com.ombudsman.service.services.CaselinkPhxToSqlService;

@SpringBootApplication
@EnableScheduling

public class WebjobApplication {

	@Value("${RUN_FLAG}")
	public String flag;

	@Autowired
	CaselinkPhxToSqlService getDataFromPhxcaselink;

	@Value("${Entity_Caselink}")
	public String Entity_Caselink;
	
	@Value("${Start_time}")
	public String Start_time;
	
	@Value("${End_time}")
	public String End_time;

	static String connectionString=null;
	Logger LOG = LogManager.getRootLogger();

	public static void main(String[] args) {
		 ApplicationInsights.attach();
	     String KEYVAULT_URL=System.getenv("KEYVAULT_URL");
	     String APPLICATIONINSIGHTS_CONNECTION_STRING_S="secret-dp-logging-appidpincrfunc-connectionstring";
	     connectionString=KeyVaultUtil.getSecret(KEYVAULT_URL, APPLICATIONINSIGHTS_CONNECTION_STRING_S);
		 ConnectionString.configure(connectionString);
		SpringApplication.run(WebjobApplication.class, args);

	}

	@Scheduled(cron = "${cron_time_caselink}")

	public @ResponseBody void caselink() throws IOException, InterruptedException {

		if ("OFF".equals(flag)) {
			LOG.debug(String.format("Exiting as the flagvalue for %s  is: %s", Entity_Caselink, flag));
			System.exit(0);
		}

		LOG.debug(String.format("Running  as flagvalue for %s  is : %s", Entity_Caselink, flag));
		getDataFromPhxcaselink.caselinkUpdatePnxtoSql();

	}

	@Scheduled(cron = "${cron_time_caselink_recon}")

	public @ResponseBody void caselink_recon() throws IOException, InterruptedException {

		if ("OFF".equals(flag)) {
			LOG.debug(String.format("Recon Job : Exiting as  flagvalue for %s  is: %s", Entity_Caselink, flag));
			System.exit(0);
		}

		LOG.debug(String.format("Recon Job : Running  as flagvalue for %s  is : %s", Entity_Caselink, flag));
		getDataFromPhxcaselink.caselinkUpdatePnxtoSql_recon(Start_time,End_time);

	}

}
