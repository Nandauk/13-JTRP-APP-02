package com.ombudsman.service.serviceImpl;

import java.util.ArrayList;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ombudsman.service.common.Constantsconfig;
import com.ombudsman.service.model.CaselinkData;
import com.ombudsman.service.model.ContactData;
import com.ombudsman.service.repo.CaselinkRepository;
import com.ombudsman.service.repo.ContactRepository;

/**
 * 
 * @author swatiamlani This class will be used for inserting data into STG
 *         tables and Stored procedure call
 *
 */

@Service
public class CaselinkSqlHelper {

	Logger LOG = LogManager.getRootLogger();

	@Autowired
	Constantsconfig constant;

	@Autowired
	ContactRepository contactRep;

	@Autowired
	CaselinkRepository caselinkRepository;

	@Transactional

	public void insertContact(ArrayList<ContactData> arrayListContact, String Fetch_IncrementalDataLoadAuditId) {

		LOG.info(String.format("Total records for CONTACT child  entity for  Insertion are : %s ",
				arrayListContact.size()));

		for (ContactData contactd : arrayListContact) {

			if (contactd.getContactid() != null) {
				insertHelpercontact(contactd, Fetch_IncrementalDataLoadAuditId);

			}

		}

	}

	public void insertHelpercaseLink(CaselinkData caselinkd, String Fetch_IncrementalDataLoadAuditId) {

		caselinkRepository.InsertQuery(caselinkd.getStatecode(), caselinkd.getStatuscode(),
				caselinkd.getFos_caselinkid(), caselinkd.getFos_businesstypecode(),
				caselinkd.getFos_declarationaccepted(), caselinkd.getFos_aretheyotherwisecoveredunderthetemporaryp(),
				caselinkd.getFos_howisthefirminourjurisdiction(), caselinkd.getFos_preferredmethodofcontact(),
				caselinkd.getFos_preferredmethodofcorrespondence(), caselinkd.getFos_role(),
				caselinkd.getFos_islinkedorpartnered(), caselinkd.getFos_ismicroenterprise(),
				caselinkd.getFos_issmallmediumenterprise(), caselinkd.getFos_receivecorrespondence(),
				caselinkd.getFos_appointedrepresentativeid(), caselinkd.getFos_case(),
				caselinkd.getFos_representativecaselinkid(), caselinkd.getFos_individualid(),
				caselinkd.getFos_organisationid(), caselinkd.getFos_preferredemailaddress(),
				caselinkd.getFos_preferredphonenumber(), caselinkd.getFos_tradingname(),
				caselinkd.getFos_annualincome(), caselinkd.getFos_annualturnover(), caselinkd.getFos_balancesheet(),
				caselinkd.getFos_netassets(), caselinkd.getFos_caseid(), caselinkd.getFos_declarationdate(),
				caselinkd.getFos_extendedreference(), caselinkd.getFos_numberofemployees(),
				caselinkd.getFos_numberofpartners(), caselinkd.getFos_reference(), caselinkd.getVersionnumber(),
				caselinkd.getCreatedby(), caselinkd.getModifiedby(), caselinkd.getModifiedon(),
				caselinkd.getCreatedon(), caselinkd.getFos_preferredemailaddressname(),
				caselinkd.getFos_tradingnamename(), Fetch_IncrementalDataLoadAuditId);

	}

	public void insertHelpercontact(ContactData contactd, String Fetch_IncrementalDataLoadAuditId) {
		contactRep.InsertQuery(contactd.getContactid(), contactd.getStatecode(), contactd.getFos_capacity(),
				contactd.getFos_contactdescriptionoption(), contactd.getFos_digitalportalinvitestatus(),
				contactd.getFos_isdigitalportaladmin(), contactd.getFos_parentorganisationcapacity(),
				contactd.getFos_phonerecordingconsent(), contactd.getFos_preferredmethodofcorrespondencecode(),
				contactd.getFos_surveyconsentcode(), contactd.getGendercode(), contactd.getPreferredcontactmethodcode(),
				contactd.getDonotemail(), contactd.getDonotphone(), contactd.getDonotpostalmail(),
				contactd.getParentcontactid(), contactd.getParentcustomerid(), contactd.getAddress1_city(),
				contactd.getAddress1_composite(), contactd.getAddress1_country(), contactd.getAddress1_county(),
				contactd.getAddress1_line1(), contactd.getAddress1_line2(), contactd.getAddress1_line3(),
				contactd.getAddress1_name(), contactd.getAddress1_postalcode(), contactd.getBirthdate(),
				contactd.getDescription(), contactd.getEmailaddress1(), contactd.getFirstname(),
				contactd.getFos_addressid(), contactd.getFos_fcaid(), contactd.getFos_needstring(),
				contactd.getFos_othertitle(), contactd.getFullname(), contactd.getJobtitle(), contactd.getLastname(),
				contactd.getMiddlename(), contactd.getMsa_managingpartneridname(), contactd.getSalutation(),
				contactd.getSuffix(), contactd.getTelephone1(), contactd.getTelephone2(), contactd.getVersionnumber(),
				contactd.getCreatedon(), contactd.getModifiedon(), contactd.getCreatedby(), contactd.getModifiedby(),
				Fetch_IncrementalDataLoadAuditId);

	}

	@Transactional
	public void insertCaselink(ArrayList<CaselinkData> arrayListCaselink, String fetch_IncrementalDataLoadAuditId) {

		LOG.info(
				String.format("Total records for CASELINK  entity for  Insertion are : %s ", arrayListCaselink.size()));
		LOG.info("Starting Insertquery for CASELINK  ");
		for (CaselinkData caselinkd : arrayListCaselink) {

			if (caselinkd.getFos_caselinkid() != null) {
				insertHelpercaseLink(caselinkd, fetch_IncrementalDataLoadAuditId);

			}

		}
		LOG.info("Ending Insertquery for CASELINK  ");

	}

}
