//package com.ombudsman.service.serviceImpl;
//
//import java.util.ArrayList;
//
//import org.assertj.core.api.Assertions;
//import org.junit.jupiter.api.DisplayName;
//import org.junit.jupiter.api.Test;
//import org.junit.jupiter.api.extension.ExtendWith;
//import org.mockito.ArgumentMatchers;
//import org.mockito.InjectMocks;
//import org.mockito.Mock;
//import org.mockito.Mockito;
//import org.springframework.test.context.junit.jupiter.SpringExtension;
//
//import com.ombudsman.service.model.CorrespondanceSourceData;
//import com.ombudsman.service.repo.CorrespondanceSourceRepository;
//import com.ombudsman.service.response.CorrespondanceSourceRes;
//
//import okhttp3.Call;
//import okhttp3.MediaType;
//import okhttp3.OkHttpClient;
//import okhttp3.Protocol;
//import okhttp3.Request;
//import okhttp3.Response;
//import okhttp3.ResponseBody;
//
//@ExtendWith(SpringExtension.class)
//public class CorrespondanceSourcePhxToSqlImplTest {
//
//	@InjectMocks
//	CorrespondanceSourcePhxToSqlImpl correspondanceSourcePhxToSqlImpl;
//	
//	@Mock
//	CorrespondanceSourceRepository correspondanceSourceRepository;
//	
//	@Mock
//	Call remoteCall;
//	
//	@Mock
//	OkHttpClient okHttpClient;
//	
//	@DisplayName("phxhelper")
//	@Test
//	public void phxhelperTest() throws Exception
//	{
//		CorrespondanceSourceRes correspondanceSourceRes = new CorrespondanceSourceRes();
//		ArrayList<CorrespondanceSourceData> arrayListcorrespondancesource = new ArrayList<>();
//		Integer failedCount=0,totalSuccessCount=0;
//		String fetch_IncrementalDataLoadAuditId = "fetch_IncrementalDataLoadAuditIdTest";
//		int current_status_id_inprogress=1;
//		String lastupdatedDate = "2024-05-30 13:43:17.0";
//		Mockito.when(correspondanceSourceRepository.findLatestDate()).thenReturn(lastupdatedDate);
//		
//		Request mockRequest = new Request.Builder().url("https://www.sample.com").build();
//		
//		@SuppressWarnings("deprecation")
//		Response mockResponse = new Response.Builder().request(mockRequest).protocol(Protocol.HTTP_1_1).code(200)
//				.message("")
//				// .body(ResponseBody.
//				.body(ResponseBody.create(MediaType.parse("application/json"), "\"value\":[{"
//						+ "sampleResponse\"}]"))
//				.build();
//		
//		Mockito.when(okHttpClient.newCall(ArgumentMatchers.any())).thenReturn(remoteCall);
//
//		Mockito.when(remoteCall.execute()).thenReturn(mockResponse);
//		
//		Throwable exception = Assertions.catchThrowable(() ->correspondanceSourcePhxToSqlImpl.phxhelper(correspondanceSourceRes, 
//				arrayListcorrespondancesource, failedCount, totalSuccessCount, fetch_IncrementalDataLoadAuditId,current_status_id_inprogress));
//		
//		Assertions.assertThat(exception).isNotNull();
//
//	}
//}
