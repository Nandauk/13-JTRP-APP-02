package com.ombudsman.service.serviceImpl;

import java.io.IOException;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.time.*;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ombudsman.service.common.Constantsconfig;
import com.ombudsman.service.common.PhoenixHelper;
import com.ombudsman.service.model.CorrespondanceSourceData;
import com.ombudsman.service.repo.CorrespondanceSourceRepository;
import com.ombudsman.service.repo.IncreLoadAuditRepository;
import com.ombudsman.service.repo.IncreLoadErrorRepository;
import com.ombudsman.service.response.CorrespondanceSourceRes;
import com.ombudsman.service.services.CorrespondanceSourcePhxToSqlService;

@Service
public class CorrespondanceSourcePhxToSqlImpl implements CorrespondanceSourcePhxToSqlService {

	@Autowired
	Constantsconfig constant;

	@Autowired
	PhoenixHelper phoenixHelper;

	@Autowired
	EmailHelper emailhelper;

	@Autowired
	CorrespondanceSourceRepository correspondanceSourceRepository;

	@Autowired
	CorrespondanceSourceSqlHelper correspondancesqlhelper;

	@Autowired
	CorrespondanceSourcePhxHelper correspondancesourcephxHelper;

	@Autowired
	IncreLoadAuditRepository increLoadAuditRep;

	@Autowired
	IncreLoadErrorRepository increLoadErrorRep;

	Logger LOG = LogManager.getRootLogger();

	@Override
	public void correspondancesourcePhxToSql() throws IOException, InterruptedException {

		String Fetch_IncrementalDataLoadAuditId = null;

		var correspondanceSourceRes = new CorrespondanceSourceRes();
		ArrayList<CorrespondanceSourceData> arrayListcorrespondancesource = new ArrayList<>();
		Integer failedCount = 0;
		int current_status_id_inprogress, current_status_id_failed_deleterecon, current_status_id_readytoprocess;
		int current_status_id_failed, current_status_id_failed_azurfunc;

		Instant startWebJob = Instant.now();

		Long total = (long) 0;
		Long totalSuccessCount = (long) 0;
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS").withZone(ZoneId.of("UTC"));
		String startWebJob_formatted = formatter.format(startWebJob);
		String startWebJob_UTC = Instant.now().toString();

		try {
			LOG.info(String.format("WebJob started for  %s  at : %s ", constant.Entity_CorrespondanceSource,
					startWebJob));
			// Check if any job is in failed state in last 7 days.Then exit without doing
			// entry in audit table
			current_status_id_failed = increLoadAuditRep.getCurrentStatusFId(constant.DataSourceName, constant.Failed);
			current_status_id_failed_azurfunc = increLoadAuditRep.getCurrentStatusFId(constant.DataSourceName_AZUNCFUNC,
					constant.Failed);
			current_status_id_failed_deleterecon = increLoadAuditRep
					.getCurrentStatusFId(constant.DataSourceName_DEL_RECON, constant.Failed);

			String last7DaysTimeStamp = java.time.LocalDateTime.now().minusDays(7)
					.format(java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss:SSS"));
			int failedCountLast7days = increLoadAuditRep.getFailedEntries(current_status_id_failed,
					current_status_id_failed_azurfunc, current_status_id_failed_deleterecon, last7DaysTimeStamp);

			if (failedCountLast7days > 0) {
				LOG.info(String.format("Due to some failed entries in audit table, webJob is exiting for %s at :%s.",
						constant.Entity_CorrespondanceSource, startWebJob));
				// Send email to support team
				emailhelper.NotificationWebclient(constant.Entity_CorrespondanceSource, "NA", constant.DataSourceName,
						"Due to some failed entries in audit table,webJob is exiting", Instant.now().toString());
				//
				return;
			}

			int JobId = increLoadAuditRep.getJobID(constant.Entity_CorrespondanceSource);
			current_status_id_inprogress = increLoadAuditRep.getCurrentStatusIPId(constant.DataSourceName,
					constant.In_Progress);

			current_status_id_readytoprocess = increLoadAuditRep.getCurrentStatusRTPId(constant.DataSourceName,
					constant.Ready_To_Process);
			increLoadAuditRep.InsertQuery(JobId, startWebJob_formatted, arrayListcorrespondancesource.size(),
					totalSuccessCount, failedCount, current_status_id_inprogress, null, constant.DataSourceName,
					constant.Entity_CorrespondanceSource, constant.Entity_CorrespondanceSource);

			Fetch_IncrementalDataLoadAuditId = increLoadAuditRep.getIncrementalDataLoadAuditId(
					startWebJob_formatted.toString(), current_status_id_inprogress, constant.DataSourceName,
					constant.Entity_CorrespondanceSource);

//			New Code Changes	
			String lastupdatedDate_temp = increLoadAuditRep.findLatestDatefromphx(constant.Entity_CorrespondanceSource);
			String lastupdatedDate =LocalDateTime.parse(lastupdatedDate_temp,DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.S")).atZone(ZoneOffset.UTC).format(DateTimeFormatter.ISO_INSTANT);
			int batchsize = constant.Fetchxml_Record;
			total = correspondancesourcephxHelper.phxCorrespondanceSource(startWebJob_UTC,
					correspondanceSourceRes, arrayListcorrespondancesource, Fetch_IncrementalDataLoadAuditId,
					lastupdatedDate, batchsize, total);

			
			increLoadAuditRep.UpdateQuery(total, totalSuccessCount, failedCount, current_status_id_readytoprocess, null,
					Fetch_IncrementalDataLoadAuditId, constant.Entity_CorrespondanceSource);

		} catch (Exception e) {

			LOG.error(String.format("ERROR IN getting data from phoenix for %s .Error logs: %s:",
					constant.Entity_CorrespondanceSource, e.getMessage()));

			Instant finishWebJobCatchIU = Instant.now();
			String emailTime = finishWebJobCatchIU.toString();
			LOG.info(String.format("Web job went to Catch block for %s ", constant.Entity_CorrespondanceSource));
			long timeElapsedWebJobcatchIU = Duration.between(startWebJob, finishWebJobCatchIU).toMillis();
			LOG.info(String.format(
					"****************Total time taken by Webjob for %s till completion from catch block : %s(in milliseconds)*************** :",
					constant.Entity_CorrespondanceSource, timeElapsedWebJobcatchIU));

			String DataPayload = "Not applicable,Failed at phoenix stage level";
			current_status_id_failed = increLoadAuditRep.getCurrentStatusFId(constant.DataSourceName, constant.Failed);
			// Entry in Error Table
			increLoadErrorRep.InsertQuery(Fetch_IncrementalDataLoadAuditId, DataPayload, current_status_id_failed,
					constant.Error_log, e.getMessage(), constant.Entity_CorrespondanceSource,
					constant.Entity_CorrespondanceSource);

			// Entry in Audit table
			increLoadAuditRep.UpdateQuery(total, totalSuccessCount, failedCount, current_status_id_failed,
					Instant.now().toString(), Fetch_IncrementalDataLoadAuditId, constant.Entity_CorrespondanceSource);

			// Send email to support team
			emailhelper.NotificationWebclient(constant.Entity_CorrespondanceSource, Fetch_IncrementalDataLoadAuditId,
					constant.DataSourceName, e.getMessage(), emailTime);
			//
			Thread.currentThread().interrupt();
			throw new RuntimeException(String.format("Job failed for %s  with Error : %s",
					constant.Entity_CorrespondanceSource, ExceptionUtils.getStackTrace(e)));
		}

		Instant Finalfinish = Instant.now();

		long timeElapsedcompleteJob = Duration.between(startWebJob, Finalfinish).toMillis();
		LOG.info(String.format("***************Total time taken for %s entity for Complete Job  is : %s ms ",
				constant.Entity_CorrespondanceSource, timeElapsedcompleteJob));

	}

	@Override
	public void correspondancesourcePhxToSql_recon(String Start_time, String End_time)
			throws IOException, InterruptedException {

		String Fetch_IncrementalDataLoadAuditId = null;

		var correspondanceSourceRes = new CorrespondanceSourceRes();
		ArrayList<CorrespondanceSourceData> arrayListcorrespondancesource = new ArrayList<>();
		Integer failedCount = 0;
		int current_status_id_inprogress, current_status_id_failed_azurfunc, current_status_id_readytoprocess;
		int current_status_id_failed, current_status_id_failed_deleterecon;

		Instant startWebJob = Instant.now();
		Long total = (long) 0;
		Long totalSuccessCount = (long) 0;
		String startWebJob_formatted = End_time.equals("NA") ? ZonedDateTime.of(LocalDate.now(ZoneOffset.UTC), LocalTime.of(22, 59,0), ZoneOffset.UTC).format(DateTimeFormatter.ISO_INSTANT)
				: End_time;
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS").withZone(ZoneId.of("UTC"));
		String startWebJob_recon = formatter.format(startWebJob);

		try {
			LOG.info(String.format("WebJob started for  %s  at : %s ", constant.Entity_CorrespondanceSource,
					startWebJob));

			// Check if any job is in failed state in last 7 days.Then exit without doing
			// entry in audit table
			current_status_id_failed = increLoadAuditRep.getCurrentStatusFId(constant.DataSourceName, constant.Failed);
			current_status_id_failed_azurfunc = increLoadAuditRep.getCurrentStatusFId(constant.DataSourceName_AZUNCFUNC,
					constant.Failed);
			current_status_id_failed_deleterecon = increLoadAuditRep
					.getCurrentStatusFId(constant.DataSourceName_DEL_RECON, constant.Failed);

			String last7DaysTimeStamp = java.time.LocalDateTime.now().minusDays(7)
					.format(java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss:SSS"));
			int failedCountLast7days = increLoadAuditRep.getFailedEntries(current_status_id_failed,
					current_status_id_failed_azurfunc, current_status_id_failed_deleterecon, last7DaysTimeStamp);

			if (failedCountLast7days > 0) {
				LOG.info(String.format("Due to some failed entries in audit table, webJob is exiting for %s at :%s.",
						constant.Entity_CorrespondanceSource, startWebJob));
				// Send email to support team
				emailhelper.NotificationWebclient(constant.Entity_CorrespondanceSource, "NA", constant.DataSourceName,
						"Due to some failed entries in audit table,webJob is exiting", Instant.now().toString());
				//
				return;
			}

			int JobId = increLoadAuditRep.getJobID(constant.Entity_CorrespondanceSource);
			current_status_id_inprogress = increLoadAuditRep.getCurrentStatusIPId(constant.DataSourceName,
					constant.In_Progress);

			current_status_id_readytoprocess = increLoadAuditRep.getCurrentStatusRTPId(constant.DataSourceName,
					constant.Ready_To_Process);
			increLoadAuditRep.InsertQuery(JobId, startWebJob_recon, arrayListcorrespondancesource.size(),
					totalSuccessCount, failedCount, current_status_id_inprogress, null, constant.DataSourceName,
					constant.Entity_CorrespondanceSource, constant.Entity_CorrespondanceSource);

			Fetch_IncrementalDataLoadAuditId = increLoadAuditRep.getIncrementalDataLoadAuditId(startWebJob_recon,
					current_status_id_inprogress, constant.DataSourceName, constant.Entity_CorrespondanceSource);

//			New Code Changes	
			String lastupdatedDate = Start_time.equals("NA")
					? ZonedDateTime.of(LocalDate.now(ZoneOffset.UTC).minusDays(1), LocalTime.of(23, 0, 00), ZoneOffset.UTC).format(DateTimeFormatter.ISO_INSTANT)
					: Start_time;
			int batchsize = constant.Fetchxml_Record;
			total = correspondancesourcephxHelper.phxCorrespondanceSource(startWebJob_formatted,
					correspondanceSourceRes, arrayListcorrespondancesource, Fetch_IncrementalDataLoadAuditId,
					lastupdatedDate, batchsize, total);
			

			increLoadAuditRep.UpdateQuery(total, totalSuccessCount, failedCount, current_status_id_readytoprocess, null,
					Fetch_IncrementalDataLoadAuditId, constant.Entity_CorrespondanceSource);

		} catch (Exception e) {

			LOG.error(String.format("ERROR IN getting data from phoenix for %s .Error logs: %s:",
					constant.Entity_CorrespondanceSource, e.getMessage()));

			Instant finishWebJobCatchIU = Instant.now();
			String emailTime = finishWebJobCatchIU.toString();
			LOG.info(String.format("Web job went to Catch block for %s ", constant.Entity_CorrespondanceSource));
			long timeElapsedWebJobcatchIU = Duration.between(startWebJob, finishWebJobCatchIU).toMillis();
			LOG.info(String.format(
					"****************Total time taken by Webjob for %s till completion from catch block : %s(in milliseconds)*************** :",
					constant.Entity_CorrespondanceSource, timeElapsedWebJobcatchIU));

			String DataPayload = "Not applicable,Failed at phoenix stage level";
			current_status_id_failed = increLoadAuditRep.getCurrentStatusFId(constant.DataSourceName, constant.Failed);
			// Entry in Error Table
			increLoadErrorRep.InsertQuery(Fetch_IncrementalDataLoadAuditId, DataPayload, current_status_id_failed,
					constant.Error_log, e.getMessage(), constant.Entity_CorrespondanceSource,
					constant.Entity_CorrespondanceSource);

			// Entry in Audit table
			increLoadAuditRep.UpdateQuery(total, totalSuccessCount, failedCount, current_status_id_failed,
					Instant.now().toString(), Fetch_IncrementalDataLoadAuditId, constant.Entity_CorrespondanceSource);
			// Send email to support team
			emailhelper.NotificationWebclient(constant.Entity_CorrespondanceSource, Fetch_IncrementalDataLoadAuditId,
					constant.DataSourceName, e.getMessage(), emailTime);
			//

			Thread.currentThread().interrupt();
			throw new RuntimeException(String.format("Job failed for %s  with Error : %s",
					constant.Entity_CorrespondanceSource, ExceptionUtils.getStackTrace(e)));
		}

		Instant Finalfinish = Instant.now();

		long timeElapsedcompleteJob = Duration.between(startWebJob, Finalfinish).toMillis();
		LOG.info(String.format("***************Total time taken for %s entity for Complete Job  is : %s ms ",
				constant.Entity_CorrespondanceSource, timeElapsedcompleteJob));

	}

}
