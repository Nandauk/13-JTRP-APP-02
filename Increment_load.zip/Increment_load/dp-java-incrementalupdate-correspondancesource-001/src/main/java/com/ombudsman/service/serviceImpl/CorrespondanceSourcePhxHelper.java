package com.ombudsman.service.serviceImpl;

import java.io.IOException;
import java.net.URLDecoder;
import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.text.StringEscapeUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ombudsman.service.common.Constantsconfig;
import com.ombudsman.service.common.PhoenixHelper;
import com.ombudsman.service.model.CorrespondanceSourceData;
import com.ombudsman.service.repo.CorrespondanceSourceRepository;
import com.ombudsman.service.repo.IncreLoadAuditRepository;
import com.ombudsman.service.repo.IncreLoadErrorRepository;
import com.ombudsman.service.response.CorrespondanceSourceRes;

import okhttp3.HttpUrl;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

@Service
public class CorrespondanceSourcePhxHelper {

	@Autowired
	Constantsconfig constant;

	@Autowired
	PhoenixHelper phoenixHelper;

	@Autowired
	CorrespondanceSourceRepository correspondanceSourceRepository;

	@Autowired
	CorrespondanceSourceSqlHelper correspondancesqlhelper;

	@Autowired
	IncreLoadAuditRepository increLoadAuditRep;

	@Autowired
	IncreLoadErrorRepository increLoadErrorRep;

	Logger LOG = LogManager.getRootLogger();

	public String phxhelper(String startWebJob_formatted, CorrespondanceSourceRes correspondanceSourceRes,
			ArrayList<CorrespondanceSourceData> arrayListcorrespondancesource, int batchsize, String startdateValue,
			String entityname, String fetch_IncrementalDataLoadAuditId, boolean moreRecords, String pagingCookie,
			int page) throws InterruptedException, IOException {

		String fetchXml = "";

		Instant startpnx = Instant.now();
		LOG.info(String.format("Phoenix call started for %s  at : %s", constant.Entity_CorrespondanceSource, startpnx));

		LOG.info(String.format("Latest Modified Date for %s  is : %s", constant.Entity_CorrespondanceSource,
				startdateValue));

		OkHttpClient client = new OkHttpClient.Builder().connectTimeout(5, TimeUnit.MINUTES)
				.writeTimeout(120, TimeUnit.SECONDS).readTimeout(5, TimeUnit.MINUTES).build();
		fetchXml = this.getFetchXML(startWebJob_formatted, startdateValue, batchsize, entityname, pagingCookie, page,constant.CorrespondanceSourcePk);
		String httpUrl = new HttpUrl.Builder().scheme("https").host(constant.APIM_HOST).addPathSegment("phoniex")
				.addPathSegment("fos_correspondencesources").addQueryParameter("fetchXml", fetchXml).build().toString();
		Request request = phoenixHelper.getPhoenixRequestBuild(httpUrl);

		Response response = client.newCall(request).execute();
		String dataReturned = response.body().string();

		ObjectMapper mapper = new ObjectMapper();
		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		JSONObject jsonObject = new JSONObject(dataReturned);
		JSONArray jsonArray = jsonObject.getJSONArray("value");

		if (jsonArray != null) {
			try {
				for (int i = 0; i < jsonArray.length(); i++) {

					CorrespondanceSourceData caseObj = null;

					caseObj = mapper.readValue(jsonArray.get(i).toString(), CorrespondanceSourceData.class);

					JSONObject childJsonObject = new JSONObject(jsonArray.get(i).toString());

					caseObj.setFos_correspondencesourceid(childJsonObject.isNull("fos_correspondencesourceid") ? null
							: childJsonObject.optString("fos_correspondencesourceid"));

					caseObj.setFos_outcomeid(childJsonObject.isNull("_fos_outcomeid_value") ? null
							: childJsonObject.optString("_fos_outcomeid_value"));

					caseObj.setModifiedon(
							childJsonObject.isNull("modifiedon") ? null : childJsonObject.optString("modifiedon"));

					String versionnumbers = childJsonObject.optString("@odata.etag");
					Long versionno = StringUtils.isEmpty(versionnumbers) ? null
							: Long.parseLong(versionnumbers.split("\"")[1]);
					caseObj.setVersionnumber(versionno);
					versionnumbers = null;

					caseObj.setCreatedon(
							childJsonObject.isNull("createdon") ? null : childJsonObject.optString("createdon"));

					caseObj.setCreatedby(childJsonObject.isNull("_createdby_value") ? null
							: childJsonObject.optString("_createdby_value"));

					caseObj.setModifiedby(childJsonObject.isNull("_modifiedby_value") ? null
							: childJsonObject.optString("_modifiedby_value"));

					arrayListcorrespondancesource.add(caseObj);

				}
			} catch (Exception e) {

				LOG.warn(String.format("CAUGHT EXCEPTION for %s  while setting values in arrayList,Error logs: %s",
						constant.Entity_CorrespondanceSource, e.getMessage()));
			}
		}
		correspondanceSourceRes.setCorrespondanceSourceData(arrayListcorrespondancesource);

		LOG.info(String.format("Total recs extracted from Phoenix call for %s are :%s",
				constant.Entity_CorrespondanceSource, arrayListcorrespondancesource.size()));
		Instant endpnx = Instant.now();
		LOG.info(String.format("Phoenix call  completed for %s at : %s", constant.Entity_CorrespondanceSource, endpnx));
		long timeElapsedphnx = Duration.between(startpnx, endpnx).toMillis();
		LOG.info(String.format("***************Total time taken for %s  by Phoenix call(in millisecond) are  :%s",
				constant.Entity_CorrespondanceSource, timeElapsedphnx));

		correspondancesqlhelper.insertForALL(arrayListcorrespondancesource, fetch_IncrementalDataLoadAuditId);

		// Extract paging cookie

		String responseXml = dataReturned;

		String pagingcookie = jsonObject.isNull("@Microsoft.Dynamics.CRM.fetchxmlpagingcookie") ? null
				: jsonObject.optString("@Microsoft.Dynamics.CRM.fetchxmlpagingcookie");
		String finalcookie = null;
		if (pagingcookie != null) {
			pagingCookie = extractPagingCookie(pagingcookie).replace("\"", "");
			String decodedpagingCookie1 = URLDecoder.decode(pagingCookie, "UTF-8");
			String decodedpagingCookie2 = URLDecoder.decode(decodedpagingCookie1, "UTF-8");
			finalcookie = StringEscapeUtils.escapeXml11(decodedpagingCookie2);

			moreRecords = responseXml.contains("\"@Microsoft.Dynamics.CRM.morerecords\":true");
		}
		LOG.info(String.format("Recs extracted for %s  from Phoenix call are : %s",
				constant.Entity_CorrespondanceSource, arrayListcorrespondancesource.size()));
		LOG.info(
				String.format("More records are there for %s : %s", constant.Entity_CorrespondanceSource, moreRecords));
		return finalcookie;
	}

	private String extractPagingCookie(String pagingcookie) {

		Pattern pattern = Pattern.compile("pagingcookie=([^\\s>]+)");
		Matcher matcher = pattern.matcher(pagingcookie);
		return matcher.find() ? matcher.group(1) : null;
	}

	public String getFetchXML(String curtime, String lastupdatedDate, int Fetchxml_Record, String entityname,
			String pagingCookie, int page,String PK) {

		String fetchXML = "<fetch version='1.0' mapping='logical'  count='" + Fetchxml_Record + "' page='" + page + "'>"
				+ "<entity name='" + entityname + "'>" + "<filter>"
				+ "<condition attribute='modifiedon' operator='between' value=''>" + "<value>" + lastupdatedDate
				+ "</value>" + "<value>" + curtime + "</value>" + "</condition>" + "</filter>"
				+ "<order attribute='" + PK + "' /> " + "</entity>" + "</fetch>";
		if (pagingCookie != null) {
			fetchXML = fetchXML.replace("fetch ", "fetch paging-cookie='" + pagingCookie + "' ");
		}
		return fetchXML;

	}

	public Long phxCorrespondanceSource(String startWebJob_formatted, CorrespondanceSourceRes correspondanceSourceRes,
			ArrayList<CorrespondanceSourceData> arrayListcorrespondanceSource, String fetch_IncrementalDataLoadAuditId,
			String lastupdatedDate, int batchsize, Long total) throws InterruptedException, IOException {
		Instant startpnx = Instant.now();
		String pagingCookie = null;
		int page = 1;
		boolean moreRecords = false;
		LOG.info(String.format("Code started for %s  at : %s ", constant.Entity_CorrespondanceSource, startpnx));

		do {
			arrayListcorrespondanceSource.clear();

			pagingCookie = phxhelper(startWebJob_formatted, correspondanceSourceRes, arrayListcorrespondanceSource,
					batchsize, lastupdatedDate, constant.CorrespondanceSource, fetch_IncrementalDataLoadAuditId,
					moreRecords, pagingCookie, page);

			total += arrayListcorrespondanceSource.size();

			LOG.info(
					String.format("Paging cookie for %s  is : %s", constant.Entity_CorrespondanceSource, pagingCookie));
			page++;
		} while (pagingCookie != null);

		Instant endpnx = Instant.now();
		LOG.info(String.format("Code ended for %s  at : %s", constant.Entity_CorrespondanceSource, endpnx));
		long timeElapsedphnx = Duration.between(startpnx, endpnx).toMillis();
		LOG.info(String.format("***************Total time taken for %s  by all operations : %s milliseconds",
				constant.Entity_CorrespondanceSource, timeElapsedphnx));

		arrayListcorrespondanceSource.clear();
		return total;

	}

}
