package com.ombudsman.service.response;

import java.util.List;

import com.ombudsman.service.model.CorrespondanceSourceData;

public class CorrespondanceSourceRes {

	private List<CorrespondanceSourceData> correspondanceSourceData;

	public List<CorrespondanceSourceData> getCorrespondanceSourceData() {
		return correspondanceSourceData;
	}

	public void setCorrespondanceSourceData(List<CorrespondanceSourceData> correspondanceSourceData) {
		this.correspondanceSourceData = correspondanceSourceData;
	}

}
