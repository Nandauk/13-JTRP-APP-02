package com.ombudsman.service.services;

import java.io.IOException;

public interface CorrespondanceSourcePhxToSqlService {
	
	void correspondancesourcePhxToSql() throws IOException, InterruptedException;

	void correspondancesourcePhxToSql_recon(String Start_time, String End_time) throws IOException, InterruptedException;

}
