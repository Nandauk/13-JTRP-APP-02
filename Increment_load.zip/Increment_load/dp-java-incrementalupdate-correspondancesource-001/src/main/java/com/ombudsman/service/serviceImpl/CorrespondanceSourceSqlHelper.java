package com.ombudsman.service.serviceImpl;

import java.util.ArrayList;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ombudsman.service.common.Constantsconfig;
import com.ombudsman.service.model.CorrespondanceSourceData;
import com.ombudsman.service.repo.CorrespondanceSourceRepository;

@Service
public class CorrespondanceSourceSqlHelper {

	@Autowired
	Constantsconfig constant;

	@Autowired
	CorrespondanceSourceRepository correspondanceSourceRepository;

	Logger LOG = LogManager.getRootLogger();

	public void insertForALL(ArrayList<CorrespondanceSourceData> arrayListcorrespondancesource,
			String Fetch_IncrementalDataLoadAuditId) {

		LOG.info(String.format("Total records for %s for  Insertion are : %s ", constant.Entity_CorrespondanceSource,
				arrayListcorrespondancesource.size()));

		for (CorrespondanceSourceData userd : arrayListcorrespondancesource) {

			if (userd.getFos_correspondencesourceid() != null) {
				insertCorrespondancesource(Fetch_IncrementalDataLoadAuditId, userd);

			}
		}

	}

	public void insertCorrespondancesource(String Fetch_IncrementalDataLoadAuditId, CorrespondanceSourceData userd) {
		correspondanceSourceRepository.InsertQuery(userd.getFos_correspondencesourceid(), userd.getFos_outcomeid(),
				userd.getVersionnumber(), userd.getCreatedon(), userd.getModifiedon(), userd.getCreatedby(),
				userd.getModifiedby(), Fetch_IncrementalDataLoadAuditId);
	}

}
