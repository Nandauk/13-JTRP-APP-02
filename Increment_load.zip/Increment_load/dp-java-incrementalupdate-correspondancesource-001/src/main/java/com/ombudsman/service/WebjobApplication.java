package com.ombudsman.service;

import java.io.IOException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.web.bind.annotation.ResponseBody;
import com.microsoft.applicationinsights.attach.ApplicationInsights;
import com.microsoft.applicationinsights.connectionstring.ConnectionString;
import com.ombudsman.service.common.KeyVaultUtil;
import com.ombudsman.service.services.CorrespondanceSourcePhxToSqlService;

@SpringBootApplication
@EnableScheduling
public class WebjobApplication {

	@Value("${RUN_FLAG}")
	public String flag;


	@Value("${Entity_CorrespondanceSource}")
	public String Entity_CorrespondanceSource;
	
	@Value("${Start_time}")
	public String Start_time;
	
	@Value("${End_time}")
	public String End_time;
	
	@Autowired
	CorrespondanceSourcePhxToSqlService getDataFromPhxcorrespondancesource;

	static String connectionString=null;
	Logger LOG = LogManager.getRootLogger();
	
	public static void main(String[] args) {
	     ApplicationInsights.attach();
	     String KEYVAULT_URL=System.getenv("KEYVAULT_URL");
	     String APPLICATIONINSIGHTS_CONNECTION_STRING_S="secret-dp-logging-appidpincrfunc-connectionstring";
	     connectionString=KeyVaultUtil.getSecret(KEYVAULT_URL, APPLICATIONINSIGHTS_CONNECTION_STRING_S);
		 ConnectionString.configure(connectionString);		
		SpringApplication.run(WebjobApplication.class, args);

	}

	@Scheduled(cron = "${cron_time_correspondancesource}")
	public @ResponseBody void CorrespondanceSource() throws IOException, InterruptedException {

		if ("OFF".equals(flag)) {
			LOG.debug(String.format("Exiting as  flagvalue for %s  is: %s", Entity_CorrespondanceSource, flag));
			System.exit(0);
		}

		LOG.debug(String.format("Running  as flagvalue for %s  is: %s", Entity_CorrespondanceSource, flag));
		getDataFromPhxcorrespondancesource.correspondancesourcePhxToSql();

	}
	
	@Scheduled(cron = "${cron_time_correspondancesource_recon}")
	public @ResponseBody void CorrespondanceSource_recon() throws IOException, InterruptedException {

		if ("OFF".equals(flag)) {
			LOG.debug(String.format("Recon Job : Exiting as  flagvalue for %s  is: %s", Entity_CorrespondanceSource, flag));
			System.exit(0);
		}

		LOG.debug(String.format("Recon Job : Running  as flagvalue for %s  is: %s", Entity_CorrespondanceSource, flag));
		getDataFromPhxcorrespondancesource.correspondancesourcePhxToSql_recon(Start_time,End_time);

	}

}
