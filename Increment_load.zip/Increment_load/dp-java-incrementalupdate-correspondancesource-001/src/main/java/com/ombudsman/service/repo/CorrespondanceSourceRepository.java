package com.ombudsman.service.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.ombudsman.service.model.CorrespondanceSourceData;

public interface CorrespondanceSourceRepository extends JpaRepository<CorrespondanceSourceData, String> {

	@Modifying
	@Transactional
	@Query(value = "INSERT INTO stg_correspondencesource(fos_correspondencesourceid,fos_outcomeid,versionnumber,createdon,modifiedon,createdby,modifiedby,incrementaldataloadjobauditid) VALUES (CONVERT(uniqueidentifier,:fos_correspondencesourceid),CONVERT(uniqueidentifier,:fos_outcomeid),:versionnumber,:createdon,:modifiedon,CONVERT(uniqueidentifier,:createdby),CONVERT(uniqueidentifier,:modifiedby),CONVERT(uniqueidentifier,:incrementaldataloadjobauditid))", nativeQuery = true)
	int InsertQuery(@Param("fos_correspondencesourceid") String fos_correspondencesourceid,
			@Param("fos_outcomeid") String fos_outcomeid, @Param("versionnumber") Long versionnumber,
			@Param("createdon") String createdon, @Param("modifiedon") String modifiedon,
			@Param("createdby") String createdby, @Param("modifiedby") String modifiedby,@Param("incrementaldataloadjobauditid") String incrementaldataloadjobauditid);

}
