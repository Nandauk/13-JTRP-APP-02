package com.ombudsman.service.model;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "stg_correspondancesource")
public class CorrespondanceSourceData {

	@Id
	private String fos_correspondencesourceid;
	private String fos_outcomeid;
	private Long versionnumber;
	private String createdon;
	private String modifiedon;
	private String createdby;
	private String modifiedby;
	private String incrementaldataloadjobauditid;
	
	
	public String getIncrementaldataloadjobauditid() {
		return incrementaldataloadjobauditid;
	}

	public void setIncrementaldataloadjobauditid(String incrementaldataloadjobauditid) {
		this.incrementaldataloadjobauditid = incrementaldataloadjobauditid;
	}

	public String getModifiedon() {
		return modifiedon;
	}

	public void setModifiedon(String modifiedon) {
		this.modifiedon = modifiedon;
	}

	public String getFos_correspondencesourceid() {
		return fos_correspondencesourceid;
	}

	public void setFos_correspondencesourceid(String fos_correspondencesourceid) {
		this.fos_correspondencesourceid = fos_correspondencesourceid;
	}

	public LocalDateTime getModifiedonSorting() {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss'Z'");
		return LocalDateTime.parse(modifiedon, formatter);
	}

	public Long getVersionnumber() {
		return versionnumber;
	}

	public void setVersionnumber(Long versionnumber) {
		this.versionnumber = versionnumber;
	}

	public String getCreatedon() {
		return createdon;
	}

	public void setCreatedon(String createdon) {
		this.createdon = createdon;
	}

	public String getCreatedby() {
		return createdby;
	}

	public void setCreatedby(String createdby) {
		this.createdby = createdby;
	}

	public String getModifiedby() {
		return modifiedby;
	}

	public void setModifiedby(String modifiedby) {
		this.modifiedby = modifiedby;
	}

	public String getFos_outcomeid() {
		return fos_outcomeid;
	}

	public void setFos_outcomeid(String fos_outcomeid) {
		this.fos_outcomeid = fos_outcomeid;
	}

}
