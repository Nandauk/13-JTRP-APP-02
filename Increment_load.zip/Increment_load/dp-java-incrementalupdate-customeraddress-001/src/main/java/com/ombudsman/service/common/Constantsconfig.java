package com.ombudsman.service.common;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public class Constantsconfig {
	
	@Value("${Entity_CustomerAddress}")
	public String Entity_CustomerAddress;

	@Value("${apim.host}")
	public String APIM_HOST;

	public String In_Progress = "In_Progress";
	public String Pending = "Pending";
	public String Completed = "Completed";
	public String Ready_To_Process = "Ready_To_Process";
	public String Terminated = "Terminated";
	public String Failed = "Failed";
	public String Error_log = "PHOENIX_001";
	public String Error_log_phx_sql = "PHOENIX_OR_SQL_001";
	public String DataSourceName = "SCH";
	public String DataSourceName_AZUNCFUNC = "DELETE_SUBMISSION";
	public String DataSourceName_DEL_RECON = "RCON_DELETE_JOB";
	

	@Value("${Fetchxml_Record}")
	public int Fetchxml_Record;
	
	public String CustomerAddress = "customeraddress";
	public String CustomerAddressPK = "customeraddressid";

}
