package com.ombudsman.service.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "dp_incremental_data_load_job_audit")
public class IncreLoadAuditData {

	@Id
	private String incremental_data_load_audit_id;
	private Integer job_id;
	private String job_start_dateTime;
	private Integer total_number_of_records;
	private Integer number_of_processed_record;
	private Integer number_of_failed_record;
	private Integer current_job_status_id;
	private String job_close_datetime;
	private String next_job_run_datetime;
	private String source;
	private String created_on;
	private String modified_on;
	private String created_by;
	private String modified_by;
	public String getIncremental_data_load_audit_id() {
		return incremental_data_load_audit_id;
	}
	public void setIncremental_data_load_audit_id(String incremental_data_load_audit_id) {
		this.incremental_data_load_audit_id = incremental_data_load_audit_id;
	}
	public Integer getJob_id() {
		return job_id;
	}
	public void setJob_id(Integer job_id) {
		this.job_id = job_id;
	}
	public String getJob_start_dateTime() {
		return job_start_dateTime;
	}
	public void setJob_start_dateTime(String job_start_dateTime) {
		this.job_start_dateTime = job_start_dateTime;
	}
	public Integer getTotal_number_of_records() {
		return total_number_of_records;
	}
	public void setTotal_number_of_records(Integer total_number_of_records) {
		this.total_number_of_records = total_number_of_records;
	}
	public Integer getNumber_of_processed_record() {
		return number_of_processed_record;
	}
	public void setNumber_of_processed_record(Integer number_of_processed_record) {
		this.number_of_processed_record = number_of_processed_record;
	}
	public Integer getNumber_of_failed_record() {
		return number_of_failed_record;
	}
	public void setNumber_of_failed_record(Integer number_of_failed_record) {
		this.number_of_failed_record = number_of_failed_record;
	}
	public Integer getCurrent_job_status_id() {
		return current_job_status_id;
	}
	public void setCurrent_job_status_id(Integer current_job_status_id) {
		this.current_job_status_id = current_job_status_id;
	}
	public String getJob_close_datetime() {
		return job_close_datetime;
	}
	public void setJob_close_datetime(String job_close_datetime) {
		this.job_close_datetime = job_close_datetime;
	}
	public String getNext_job_run_datetime() {
		return next_job_run_datetime;
	}
	public void setNext_job_run_datetime(String next_job_run_datetime) {
		this.next_job_run_datetime = next_job_run_datetime;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getCreated_on() {
		return created_on;
	}
	public void setCreated_on(String created_on) {
		this.created_on = created_on;
	}
	public String getModified_on() {
		return modified_on;
	}
	public void setModified_on(String modified_on) {
		this.modified_on = modified_on;
	}
	public String getCreated_by() {
		return created_by;
	}
	public void setCreated_by(String created_by) {
		this.created_by = created_by;
	}
	public String getModified_by() {
		return modified_by;
	}
	public void setModified_by(String modified_by) {
		this.modified_by = modified_by;
	}

	
}
