package com.ombudsman.service.common;

import java.net.MalformedURLException;
import java.util.Locale;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Configuration;

import com.microsoft.aad.adal4j.AuthenticationContext;
import com.microsoft.aad.adal4j.AuthenticationResult;
import com.microsoft.aad.adal4j.ClientCredential;
import com.ombudsman.service.exception.PhoenixServiceException;

import okhttp3.HttpUrl;
import okhttp3.Request;

@Configuration
public class PhoenixHelper {

	@SuppressWarnings("unused")
	private static final String API_ERROR_PHOENIXCONNECTIVITY = "api.error.phoenixconnectivity";

//	@Autowired
//	private KeyVaultConfiguration keyValutProps;
	
	//@Value("${app.phoneix_host}")
	@Value("${apim.host}")
	public String PHOENIX_HOST;

	@Autowired
	private MessageSource messageSource;

	//public Request getPhoenixRequestBuild(String accessToken, HttpUrl httpUrl) {
	public Request getPhoenixRequestBuild(String httpUrl) {
		return new Request.Builder().url(httpUrl).get().addHeader("OData-MaxVersion", "4.0")
				.addHeader("OData-Version", "4.0").addHeader("Accept", "application/json")
				.addHeader("Content-Type", "application/json; charset=utf-8")
				.addHeader("Prefer", "odata.include-annotations=\"*\"")
			//	.addHeader("Authorization", "Bearer " + accessToken)
				.addHeader("cache-control", "no-cache").build();
	}

//	public String getConnectionWithD365() throws InterruptedException {
//		String accessToken = null;
//		ExecutorService service = Executors.newFixedThreadPool(1);
//		AuthenticationResult result;
//
//		try {
//
//			AuthenticationContext context = new AuthenticationContext(
//					this.keyValutProps.d365Authority + this.keyValutProps.d365tenantID, true, service);
//			Future<AuthenticationResult> future = context.acquireToken(this.keyValutProps.phoenixHost,
//					new ClientCredential(this.keyValutProps.d365ClientId, this.keyValutProps.d365Secrect), null);
//
//			result = future.get();
//			accessToken = result.getAccessToken();
//
//		} catch (MalformedURLException | ExecutionException e) {
//
//			throw new PhoenixServiceException(
//					messageSource.getMessage("api.error.phoenixconnectivity", null, Locale.ENGLISH), e.getMessage());
//		}
//		return accessToken;
//	}

}

