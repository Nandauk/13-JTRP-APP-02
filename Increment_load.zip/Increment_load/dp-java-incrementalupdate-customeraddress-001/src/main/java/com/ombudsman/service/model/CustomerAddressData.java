package com.ombudsman.service.model;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "stg_customeraddress")
public class CustomerAddressData {

	@Id
	private String customeraddressid;
	private String city;
	private String country;
	private String county;
	private String createdonbehalfby;
	private String fos_parentorganisationaddressid;
	private String line1;
	private String line2;
	private String line3;
	private String name;
	private String parentid;
	private String postalcode;
	private String primarycontactname;
	private String stateorprovince;
	private Long addressnumber;
	private Long addresstypecode;
	private String createdon;
	private String modifiedon;
	private String createdby;
	private String modifiedby;
	private String incrementaldataloadjobauditid;

	public String getIncrementaldataloadjobauditid() {
		return incrementaldataloadjobauditid;
	}

	public void setIncrementaldataloadjobauditid(String incrementaldataloadjobauditid) {
		this.incrementaldataloadjobauditid = incrementaldataloadjobauditid;
	}

	public String getCustomeraddressid() {
		return customeraddressid;
	}

	public void setCustomeraddressid(String customeraddressid) {
		this.customeraddressid = customeraddressid;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getCounty() {
		return county;
	}

	public void setCounty(String county) {
		this.county = county;
	}

	public String getCreatedonbehalfby() {
		return createdonbehalfby;
	}

	public void setCreatedonbehalfby(String createdonbehalfby) {
		this.createdonbehalfby = createdonbehalfby;
	}

	public String getFos_parentorganisationaddressid() {
		return fos_parentorganisationaddressid;
	}

	public void setFos_parentorganisationaddressid(String fos_parentorganisationaddressid) {
		this.fos_parentorganisationaddressid = fos_parentorganisationaddressid;
	}

	public String getLine1() {
		return line1;
	}

	public void setLine1(String line1) {
		this.line1 = line1;
	}

	public String getLine2() {
		return line2;
	}

	public void setLine2(String line2) {
		this.line2 = line2;
	}

	public String getLine3() {
		return line3;
	}

	public void setLine3(String line3) {
		this.line3 = line3;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getParentid() {
		return parentid;
	}

	public void setParentid(String parentid) {
		this.parentid = parentid;
	}

	public String getPostalcode() {
		return postalcode;
	}

	public void setPostalcode(String postalcode) {
		this.postalcode = postalcode;
	}

	public String getPrimarycontactname() {
		return primarycontactname;
	}

	public void setPrimarycontactname(String primarycontactname) {
		this.primarycontactname = primarycontactname;
	}

	public String getStateorprovince() {
		return stateorprovince;
	}

	public void setStateorprovince(String stateorprovince) {
		this.stateorprovince = stateorprovince;
	}

	public Long getAddressnumber() {
		return addressnumber;
	}

	public void setAddressnumber(Long addressnumber) {
		this.addressnumber = addressnumber;
	}

	public Long getAddresstypecode() {
		return addresstypecode;
	}

	public void setAddresstypecode(Long addresstypecode) {
		this.addresstypecode = addresstypecode;
	}

	public String getCreatedon() {
		return createdon;
	}

	public void setCreatedon(String createdon) {
		this.createdon = createdon;
	}

	public String getModifiedon() {
		return modifiedon;
	}

	public void setModifiedon(String modifiedon) {
		this.modifiedon = modifiedon;
	}

	public String getCreatedby() {
		return createdby;
	}

	public void setCreatedby(String createdby) {
		this.createdby = createdby;
	}

	public String getModifiedby() {
		return modifiedby;
	}

	public void setModifiedby(String modifiedby) {
		this.modifiedby = modifiedby;
	}

	public LocalDateTime getModifiedonSorting() {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss'Z'");
		return LocalDateTime.parse(modifiedon, formatter);
	}

}
