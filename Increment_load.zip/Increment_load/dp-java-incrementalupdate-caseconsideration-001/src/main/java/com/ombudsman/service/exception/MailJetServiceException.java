package com.ombudsman.service.exception;

public class MailJetServiceException extends GeneralServiceExceptions {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	

	public MailJetServiceException(String message,String exceptionMessage) {
		super(message, "RESPONDENT_AZURE_1000",exceptionMessage);
	}
	
}
