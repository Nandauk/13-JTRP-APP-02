package com.ombudsman.service.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.ombudsman.service.model.IncreLoadErrorData;

public interface IncreLoadErrorRepository extends JpaRepository<IncreLoadErrorData, String> {

	@Modifying
	@Transactional
	@Query(value = "INSERT INTO dp_incremental_load_error (incremental_data_load_audit_id,data_pay_load,current_error_status_id,error_code,error_log,"
			+ "created_by,modified_by) VALUES (:incremental_data_load_audit_id,:data_pay_load,:current_error_status_id,:error_code,:error_log,:created_by,:modified_by) ", nativeQuery = true)
	int InsertQuery(@Param("incremental_data_load_audit_id") String incremental_data_load_audit_id,
			@Param("data_pay_load") String data_pay_load,
			@Param("current_error_status_id") Integer current_error_status_id,@Param("error_code") String error_code, @Param("error_log") String error_log,
			@Param("created_by") String created_by, @Param("modified_by") String modified_by);

	@Query(value = "select incremental_data_load_error_id from Incremental_load_error where incremental_data_load_audit_id=:Fetch_IncrementalDataLoadAuditId", nativeQuery = true)
	String getIncrementalDataLoadErrorId(
			@Param("Fetch_IncrementalDataLoadAuditId") String Fetch_IncrementalDataLoadAuditId);

}
