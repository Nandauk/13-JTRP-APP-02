package com.ombudsman.service.model;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonFormat.Shape;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "stg_case_consideration")
public class CaseconsiderationData {

	@Id
	private String fos_caseconsiderationid;
	private Long statecode;
	private Long fos_consideration;
	private Boolean fos_committed;
	@JsonFormat(shape = Shape.NUMBER)

	private String fos_caseid;
	private String fos_individual;

	private String fos_referencenumber;
	private Long versionnumber;
	private String createdon;
	private String modifiedon;
	
	private String createdby;
	private String modifiedby;
	private String incrementaldataloadjobauditid;
	
	
	public String getIncrementaldataloadjobauditid() {
		return incrementaldataloadjobauditid;
	}

	public void setIncrementaldataloadjobauditid(String incrementaldataloadjobauditid) {
		this.incrementaldataloadjobauditid = incrementaldataloadjobauditid;
	}

	

	public String getModifiedon() {
		return modifiedon;
	}

	public void setModifiedon(String modifiedon) {
		this.modifiedon = modifiedon;
	}

	public Long getStatecode() {
		return statecode;
	}

	public void setStatecode(Long statecode) {
		this.statecode = statecode;
	}

	public String getFos_caseid() {
		return fos_caseid;
	}

	public void setFos_caseid(String fos_caseid) {
		this.fos_caseid = fos_caseid;
	}

	
	public String getFos_caseconsiderationid() {
		return fos_caseconsiderationid;
	}

	public void setFos_caseconsiderationid(String fos_caseconsiderationid) {
		this.fos_caseconsiderationid = fos_caseconsiderationid;
	}

	public Long getFos_consideration() {
		return fos_consideration;
	}

	public void setFos_consideration(Long fos_consideration) {
		this.fos_consideration = fos_consideration;
	}

	public Boolean getFos_committed() {
		return fos_committed;
	}

	public void setFos_committed(Boolean fos_committed) {
		this.fos_committed = fos_committed;
	}

	public String getFos_individual() {
		return fos_individual;
	}

	public void setFos_individual(String fos_individual) {
		this.fos_individual = fos_individual;
	}

	
	public LocalDateTime getModifiedonSorting() {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss'Z'");
		return LocalDateTime.parse(modifiedon,formatter);
	}

	public Long getVersionnumber() {
		return versionnumber;
	}

	public void setVersionnumber(Long versionnumber) {
		this.versionnumber = versionnumber;
	}

	public String getCreatedon() {
		return createdon;
	}

	public void setCreatedon(String createdon) {
		this.createdon = createdon;
	}

	public String getCreatedby() {
		return createdby;
	}

	public void setCreatedby(String createdby) {
		this.createdby = createdby;
	}

	public String getModifiedby() {
		return modifiedby;
	}

	public void setModifiedby(String modifiedby) {
		this.modifiedby = modifiedby;
	}

	public String getFos_referencenumber() {
		return fos_referencenumber;
	}

	public void setFos_referencenumber(String fos_referencenumber) {
		this.fos_referencenumber = fos_referencenumber;
	}

}
