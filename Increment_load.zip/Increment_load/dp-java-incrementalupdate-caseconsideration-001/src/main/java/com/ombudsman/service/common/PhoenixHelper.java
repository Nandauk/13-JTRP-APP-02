package com.ombudsman.service.common;

import org.springframework.context.annotation.Configuration;

import okhttp3.Request;

@Configuration
public class PhoenixHelper {


	//public Request getPhoenixRequestBuild(String accessToken, HttpUrl httpUrl) {
	public Request getPhoenixRequestBuild(String httpUrl) {
		return new Request.Builder().url(httpUrl).get().addHeader("OData-MaxVersion", "4.0")
				.addHeader("OData-Version", "4.0").addHeader("Accept", "application/json")
				.addHeader("Content-Type", "application/json; charset=utf-8")
				.addHeader("Prefer", "odata.include-annotations=\"*\"")
				//.addHeader("Authorization", "Bearer " + accessToken)
				.addHeader("cache-control", "no-cache").build();
	}

	

}
