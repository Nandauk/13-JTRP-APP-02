package com.ombudsman.service.serviceImpl;

import java.util.ArrayList;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ombudsman.service.common.Constantsconfig;
import com.ombudsman.service.model.CaseconsiderationData;
import com.ombudsman.service.repo.CaseconsiderationRepository;

@Service
public class CaseconsiderationSqlHelper {

	@Autowired
	Constantsconfig constant;

	@Autowired
	CaseconsiderationRepository caseconsiderationRepository;

	Logger LOG = LogManager.getRootLogger();

	public void insertForALL(ArrayList<CaseconsiderationData> arrayListcaseconsideration,
			String Fetch_IncrementalDataLoadAuditId) {

		LOG.info(String.format("Total records for %s for  Insertion are : %s ", constant.Entity_Caseconsideration,
				arrayListcaseconsideration.size()));

		for (CaseconsiderationData ccd : arrayListcaseconsideration) {

			if (ccd.getFos_caseconsiderationid() != null) {

				insertcaseconsideration(Fetch_IncrementalDataLoadAuditId, ccd);

			}

		}

	}

	public void insertcaseconsideration(String Fetch_IncrementalDataLoadAuditId, CaseconsiderationData ccd) {
		caseconsiderationRepository.InsertQuery(ccd.getFos_caseconsiderationid(), ccd.getStatecode(),
				ccd.getFos_consideration(), ccd.getFos_committed(), ccd.getFos_caseid(), ccd.getFos_individual(),
				ccd.getFos_referencenumber(), ccd.getVersionnumber(), ccd.getCreatedon(), ccd.getModifiedon(),
				ccd.getCreatedby(), ccd.getModifiedby(), Fetch_IncrementalDataLoadAuditId);
	}

}
