package com.ombudsman.service.response;

import java.util.List;

import com.ombudsman.service.model.CaseconsiderationData;

public class CaseconsiderationRes {

	private List<CaseconsiderationData> caseconsiderationData;

	public List<CaseconsiderationData> getCaseconsiderationData() {
		return caseconsiderationData;
	}

	public void setCaseconsiderationData(List<CaseconsiderationData> caseconsiderationData) {
		this.caseconsiderationData = caseconsiderationData;
	}

}
