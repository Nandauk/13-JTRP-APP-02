package com.ombudsman.service.services;

import java.io.IOException;

public interface CaseconsiderationPhxToSqlService {

	void caseconsiderationPhxToSql() throws IOException,  InterruptedException;

	void caseconsiderationPhxToSql_recon(String Start_time, String End_time) throws  IOException,  InterruptedException;
}