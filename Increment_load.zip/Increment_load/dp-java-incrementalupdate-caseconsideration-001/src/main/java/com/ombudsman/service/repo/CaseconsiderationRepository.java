package com.ombudsman.service.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.ombudsman.service.model.CaseconsiderationData;

public interface CaseconsiderationRepository extends JpaRepository<CaseconsiderationData, String> {

	@Modifying
	@Transactional
	@Query(value = "INSERT INTO stg_case_consideration(fos_caseconsiderationid,statecode,fos_consideration,fos_committed,fos_caseid,fos_individual,fos_referencenumber,versionnumber,createdon,modifiedon,createdby,modifiedby,incrementaldataloadjobauditid) VALUES (CONVERT(uniqueidentifier,:fos_caseconsiderationid),:statecode,:fos_consideration,:fos_committed,CONVERT(uniqueidentifier,:fos_caseid),CONVERT(uniqueidentifier,:fos_individual),:fos_referencenumber,:versionnumber,:createdon,:modifiedon,CONVERT(uniqueidentifier,:createdby),CONVERT(uniqueidentifier,:modifiedby),CONVERT(uniqueidentifier,:incrementaldataloadjobauditid))", nativeQuery = true)
	int InsertQuery(@Param("fos_caseconsiderationid") String fos_caseconsiderationid,
			@Param("statecode") Long statecode, @Param("fos_consideration") Long fos_consideration,
			@Param("fos_committed") Boolean fos_committed, @Param("fos_caseid") String fos_caseid,
			@Param("fos_individual") String fos_individual, @Param("fos_referencenumber") String fos_referencenumber,
			@Param("versionnumber") Long versionnumber, @Param("createdon") String createdon,
			@Param("modifiedon") String modifiedon, @Param("createdby") String createdby,
			@Param("modifiedby") String modifiedby,
			@Param("incrementaldataloadjobauditid") String incrementaldataloadjobauditid);

}
