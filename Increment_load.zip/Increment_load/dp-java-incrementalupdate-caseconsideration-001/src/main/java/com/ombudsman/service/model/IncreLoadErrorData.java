package com.ombudsman.service.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "dp_incremental_load_error")
public class IncreLoadErrorData {

	@Id
	private String incremental_data_load_error_id;
	private String incremental_data_load_audit_id;
	private String data_pay_load;
	private String error_created_datetime;
	private Long current_error_status_id;
	
	private String error_code;
	private String error_log;

	private String created_on;
	private String modified_on;
	private String created_by;
	private String modified_by;
	public String getIncremental_data_load_error_id() {
		return incremental_data_load_error_id;
	}
	public void setIncremental_data_load_error_id(String incremental_data_load_error_id) {
		this.incremental_data_load_error_id = incremental_data_load_error_id;
	}
	public String getIncremental_data_load_audit_id() {
		return incremental_data_load_audit_id;
	}
	public void setIncremental_data_load_audit_id(String incremental_data_load_audit_id) {
		this.incremental_data_load_audit_id = incremental_data_load_audit_id;
	}
	public String getData_pay_load() {
		return data_pay_load;
	}
	public void setData_pay_load(String data_pay_load) {
		this.data_pay_load = data_pay_load;
	}
	public String getError_created_datetime() {
		return error_created_datetime;
	}
	public void setError_created_datetime(String error_created_datetime) {
		this.error_created_datetime = error_created_datetime;
	}
	public Long getCurrent_error_status_id() {
		return current_error_status_id;
	}
	public void setCurrent_error_status_id(Long current_error_status_id) {
		this.current_error_status_id = current_error_status_id;
	}
	public String getError_code() {
		return error_code;
	}
	public void setError_code(String error_code) {
		this.error_code = error_code;
	}
	public String getError_log() {
		return error_log;
	}
	public void setError_log(String error_log) {
		this.error_log = error_log;
	}
	public String getCreated_on() {
		return created_on;
	}
	public void setCreated_on(String created_on) {
		this.created_on = created_on;
	}
	public String getModified_on() {
		return modified_on;
	}
	public void setModified_on(String modified_on) {
		this.modified_on = modified_on;
	}
	public String getCreated_by() {
		return created_by;
	}
	public void setCreated_by(String created_by) {
		this.created_by = created_by;
	}
	public String getModified_by() {
		return modified_by;
	}
	public void setModified_by(String modified_by) {
		this.modified_by = modified_by;
	}

	

}
