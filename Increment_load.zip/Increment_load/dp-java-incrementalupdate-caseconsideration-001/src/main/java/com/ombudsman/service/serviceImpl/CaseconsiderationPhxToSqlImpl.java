package com.ombudsman.service.serviceImpl;

import java.io.IOException;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.time.*;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ombudsman.service.common.Constantsconfig;
import com.ombudsman.service.common.PhoenixHelper;
import com.ombudsman.service.model.CaseconsiderationData;
import com.ombudsman.service.repo.CaseconsiderationRepository;
import com.ombudsman.service.repo.IncreLoadAuditRepository;
import com.ombudsman.service.repo.IncreLoadErrorRepository;
import com.ombudsman.service.response.CaseconsiderationRes;
import com.ombudsman.service.services.CaseconsiderationPhxToSqlService;

@Service
public class CaseconsiderationPhxToSqlImpl implements CaseconsiderationPhxToSqlService {

	@Autowired
	Constantsconfig constant;

	@Autowired
	PhoenixHelper phoenixHelper;

	@Autowired
	CaseconsiderationRepository caseconsiderationRepository;

	@Autowired
	CaseconsiderationSqlHelper caseconsiderationsqlhelper;

	@Autowired
	IncreLoadAuditRepository increLoadAuditRep;

	@Autowired
	IncreLoadErrorRepository increLoadErrorRep;

	@Autowired
	CaseconsiderationPhxHelper caseconsiderationphxhelper;

	@Autowired
	EmailHelper emailhelper;

	Logger LOG = LogManager.getRootLogger();

	@Override
	public void caseconsiderationPhxToSql() throws IOException, InterruptedException {

		String Fetch_IncrementalDataLoadAuditId = null;

		var caseconsiderationRes = new CaseconsiderationRes();
		ArrayList<CaseconsiderationData> arrayListcaseconsideration = new ArrayList<>();
		int current_status_id_inprogress, current_status_id_failed_azurfunc, current_status_id_readytoprocess;
		int current_status_id_failed,current_status_id_failed_deleterecon;
		Long totalRecord = (long) 0;
		Integer failedCount = 0;
		Long totalSuccessCount = (long) 0;
		
		Instant startWebJob = Instant.now();
		String startWebJob_UTC = Instant.now().toString();

		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS").withZone(ZoneId.of("UTC"));
		String startWebJob_formatted = formatter.format(startWebJob);

		try {

			LOG.info(String.format("WebJob started for  %s  at : %s ", constant.Entity_Caseconsideration, startWebJob));

			current_status_id_failed = increLoadAuditRep.getCurrentStatusFId(constant.DataSourceName, constant.Failed);
			current_status_id_failed_azurfunc = increLoadAuditRep.getCurrentStatusFId(constant.DataSourceName_AZUNCFUNC,
					constant.Failed);
			current_status_id_failed_deleterecon = increLoadAuditRep
					.getCurrentStatusFId(constant.DataSourceName_DEL_RECON, constant.Failed);

			String last7DaysTimeStamp = java.time.LocalDateTime.now().minusDays(7)
					.format(java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss:SSS"));
			int failedCountLast7days = increLoadAuditRep.getFailedEntries(current_status_id_failed,
					current_status_id_failed_azurfunc, current_status_id_failed_deleterecon, last7DaysTimeStamp);

			if (failedCountLast7days > 0) {
				LOG.info(String.format("Due to some failed entries in audit table, webJob is exiting for %s at :%s.",
						constant.Entity_Caseconsideration, startWebJob));
				// Send email to support team
				emailhelper.NotificationWebclient(constant.Entity_Caseconsideration, "NA", constant.DataSourceName,
						"Due to some failed entries in audit table,webJob is exiting", Instant.now().toString());
				//
				return;
			}
			
			int JobId = increLoadAuditRep.getJobID(constant.Entity_Caseconsideration);
			current_status_id_inprogress = increLoadAuditRep.getCurrentStatusIPId(constant.DataSourceName,
					constant.In_Progress);
			
			current_status_id_readytoprocess = increLoadAuditRep.getCurrentStatusRTPId(constant.DataSourceName,
					constant.Ready_To_Process);
			increLoadAuditRep.InsertQuery(JobId, startWebJob_formatted, arrayListcaseconsideration.size(),
					totalSuccessCount, failedCount, current_status_id_inprogress, null, constant.DataSourceName,
					constant.Entity_Caseconsideration, constant.Entity_Caseconsideration);

			Fetch_IncrementalDataLoadAuditId = increLoadAuditRep.getIncrementalDataLoadAuditId(startWebJob_formatted,
					current_status_id_inprogress, constant.DataSourceName, constant.Entity_Caseconsideration);

			String lastupdatedDate_temp = increLoadAuditRep.findLatestDatefromphx(constant.Entity_Caseconsideration);
			String lastupdatedDate =LocalDateTime.parse(lastupdatedDate_temp,DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.S")).atZone(ZoneOffset.UTC).format(DateTimeFormatter.ISO_INSTANT);
			int batchsize = constant.Fetchxml_Record;

			totalRecord = caseconsiderationphxhelper.phxCaseconsideration(Fetch_IncrementalDataLoadAuditId,
					caseconsiderationRes, arrayListcaseconsideration, startWebJob_UTC, lastupdatedDate, batchsize,
					totalRecord);

			increLoadAuditRep.UpdateQuery(totalRecord, totalSuccessCount, failedCount, current_status_id_readytoprocess,
					null, Fetch_IncrementalDataLoadAuditId, constant.Entity_Caseconsideration);

		} catch (Exception e) {

			LOG.error(String.format("ERROR in getting data from phoenix for %s .Error logs: %s:",
					constant.Entity_Caseconsideration, e.getMessage()));

			Instant finishWebJobCatchIU = Instant.now();
			String emailTime = finishWebJobCatchIU.toString();
			LOG.info(String.format("Web job went to Catch block for %s ", constant.Entity_Caseconsideration));
			long timeElapsedWebJobcatchIU = Duration.between(startWebJob, finishWebJobCatchIU).toMillis();
			LOG.info(String.format(
					"****************Total time taken by Webjob for %s till completion from catch block : %s(in milliseconds)*************** :",
					constant.Entity_Caseconsideration, timeElapsedWebJobcatchIU));

			String DataPayload = "Not applicable,Failed at phoenix stage level";
			current_status_id_failed = increLoadAuditRep.getCurrentStatusFId(constant.DataSourceName, constant.Failed);
			// Entry in Error Table
			increLoadErrorRep.InsertQuery(Fetch_IncrementalDataLoadAuditId, DataPayload, current_status_id_failed,
					constant.Error_log, e.getMessage(), constant.Entity_Caseconsideration,
					constant.Entity_Caseconsideration);

			// Entry in Audit table
			increLoadAuditRep.UpdateQuery(totalRecord, totalSuccessCount, failedCount, current_status_id_failed,
					Instant.now().toString(), Fetch_IncrementalDataLoadAuditId, constant.Entity_Caseconsideration);

			// Send email to support team
			emailhelper.NotificationWebclient(constant.Entity_Caseconsideration, Fetch_IncrementalDataLoadAuditId,
					constant.DataSourceName, e.getMessage(), emailTime);
			//
			Thread.currentThread().interrupt();
			throw new RuntimeException(String.format("Job failed for %s entity with Error : %s",
					constant.Entity_Caseconsideration, ExceptionUtils.getStackTrace(e)));
		}

		Instant Finalfinish = Instant.now();

		long timeElapsedcompleteJob = Duration.between(startWebJob, Finalfinish).toMillis();
		LOG.info(String.format("***************Total time taken for %s entity for Complete Job  is : %s ms ",
				constant.Entity_Caseconsideration, timeElapsedcompleteJob));

	}

	@Override
	public void caseconsiderationPhxToSql_recon(String Start_time, String End_time)
			throws IOException, InterruptedException {

		String Fetch_IncrementalDataLoadAuditId = null;

		var caseconsiderationRes = new CaseconsiderationRes();
		ArrayList<CaseconsiderationData> arrayListcaseconsideration = new ArrayList<>();
		int current_status_id_inprogress, current_status_id_failed_azurfunc, current_status_id_readytoprocess;
		int current_status_id_failed,current_status_id_failed_deleterecon;
		Long totalRecord = (long) 0;
		Integer failedCount = 0;
		
		Long totalSuccessCount = (long) 0;
		Instant startWebJob = Instant.now();

		String startWebJob_formatted = End_time.equals("NA") ? ZonedDateTime.of(LocalDate.now(ZoneOffset.UTC), LocalTime.of(22, 59,0), ZoneOffset.UTC).format(DateTimeFormatter.ISO_INSTANT)
				: End_time;
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS").withZone(ZoneId.of("UTC"));
		String startWebJob_recon = formatter.format(startWebJob);
		try {

			LOG.info(String.format("WebJob started for  %s  at : %s ", constant.Entity_Caseconsideration, startWebJob));

			current_status_id_failed = increLoadAuditRep.getCurrentStatusFId(constant.DataSourceName, constant.Failed);
			current_status_id_failed_azurfunc = increLoadAuditRep.getCurrentStatusFId(constant.DataSourceName_AZUNCFUNC,
					constant.Failed);
			current_status_id_failed_deleterecon = increLoadAuditRep
					.getCurrentStatusFId(constant.DataSourceName_DEL_RECON, constant.Failed);

			String last7DaysTimeStamp = java.time.LocalDateTime.now().minusDays(7)
					.format(java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss:SSS"));
			int failedCountLast7days = increLoadAuditRep.getFailedEntries(current_status_id_failed,
					current_status_id_failed_azurfunc, current_status_id_failed_deleterecon, last7DaysTimeStamp);

			if (failedCountLast7days > 0) {
				LOG.info(String.format("Due to some failed entries in audit table, webJob is exiting for %s at :%s.",
						constant.Entity_Caseconsideration, startWebJob));
				// Send email to support team
				emailhelper.NotificationWebclient(constant.Entity_Caseconsideration, "NA", constant.DataSourceName,
						"Due to some failed entries in audit table,webJob is exiting", Instant.now().toString());
				//
				return;
			}
			
			int JobId = increLoadAuditRep.getJobID(constant.Entity_Caseconsideration);
			current_status_id_inprogress = increLoadAuditRep.getCurrentStatusIPId(constant.DataSourceName,
					constant.In_Progress);
			
			current_status_id_readytoprocess = increLoadAuditRep.getCurrentStatusRTPId(constant.DataSourceName,
					constant.Ready_To_Process);
			increLoadAuditRep.InsertQuery(JobId, startWebJob_recon, arrayListcaseconsideration.size(),
					totalSuccessCount, failedCount, current_status_id_inprogress, null, constant.DataSourceName,
					constant.Entity_Caseconsideration, constant.Entity_Caseconsideration);

			Fetch_IncrementalDataLoadAuditId = increLoadAuditRep.getIncrementalDataLoadAuditId(startWebJob_recon,
					current_status_id_inprogress, constant.DataSourceName, constant.Entity_Caseconsideration);

			String lastupdatedDate = Start_time.equals("NA")
					? ZonedDateTime.of(LocalDate.now(ZoneOffset.UTC).minusDays(1), LocalTime.of(23, 0, 00), ZoneOffset.UTC).format(DateTimeFormatter.ISO_INSTANT)
					: Start_time;
			int batchsize = constant.Fetchxml_Record;
			totalRecord = caseconsiderationphxhelper.phxCaseconsideration(Fetch_IncrementalDataLoadAuditId,
					caseconsiderationRes, arrayListcaseconsideration, startWebJob_formatted, lastupdatedDate, batchsize,
					totalRecord);
			

			increLoadAuditRep.UpdateQuery(totalRecord, totalSuccessCount, failedCount, current_status_id_readytoprocess,
					null, Fetch_IncrementalDataLoadAuditId, constant.Entity_Caseconsideration);

		} catch (Exception e) {

			LOG.error(String.format("ERROR in getting data from phoenix for %s .Error logs: %s:",
					constant.Entity_Caseconsideration, e.getMessage()));

			Instant finishWebJobCatchIU = Instant.now();
			String emailTime = finishWebJobCatchIU.toString();
			LOG.info(String.format("Web job went to Catch block for %s ", constant.Entity_Caseconsideration));
			long timeElapsedWebJobcatchIU = Duration.between(startWebJob, finishWebJobCatchIU).toMillis();
			LOG.info(String.format(
					"****************Total time taken by Webjob for %s till completion from catch block : %s(in milliseconds)*************** :",
					constant.Entity_Caseconsideration, timeElapsedWebJobcatchIU));

			String DataPayload = "Not applicable,Failed at phoenix stage level";
			current_status_id_failed = increLoadAuditRep.getCurrentStatusFId(constant.DataSourceName, constant.Failed);
			// Entry in Error Table
			increLoadErrorRep.InsertQuery(Fetch_IncrementalDataLoadAuditId, DataPayload, current_status_id_failed,
					constant.Error_log, e.getMessage(), constant.Entity_Caseconsideration,
					constant.Entity_Caseconsideration);

			// Entry in Audit table
			increLoadAuditRep.UpdateQuery(totalRecord, totalSuccessCount, failedCount, current_status_id_failed,
					Instant.now().toString(), Fetch_IncrementalDataLoadAuditId, constant.Entity_Caseconsideration);

			// Send email to support team
			emailhelper.NotificationWebclient(constant.Entity_Caseconsideration, Fetch_IncrementalDataLoadAuditId,
					constant.DataSourceName, e.getMessage(), emailTime);
			//
			Thread.currentThread().interrupt();
			throw new RuntimeException(String.format("Job failed for %s entity with Error : %s",
					constant.Entity_Caseconsideration, ExceptionUtils.getStackTrace(e)));
		}

		Instant Finalfinish = Instant.now();

		long timeElapsedcompleteJob = Duration.between(startWebJob, Finalfinish).toMillis();
		LOG.info(String.format("***************Total time taken for %s entity for Complete Job  is : %s ms ",
				constant.Entity_Caseconsideration, timeElapsedcompleteJob));

	}

}
