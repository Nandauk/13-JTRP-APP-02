/*
 * package com.ombudsman.service.serviceImpl;
 * 
 * import static org.mockito.Mockito.*;
 * 
 * import java.util.ArrayList;
 * 
 * import org.junit.jupiter.api.BeforeEach; import org.junit.jupiter.api.Test;
 * import org.junit.jupiter.api.extension.ExtendWith; import
 * org.mockito.InjectMocks; import org.mockito.Mock; import
 * org.mockito.junit.jupiter.MockitoExtension; import
 * org.springframework.test.util.ReflectionTestUtils;
 * 
 * import com.ombudsman.service.common.Constantsconfig; import
 * com.ombudsman.service.model.CaseconsiderationData; import
 * com.ombudsman.service.repo.CaseconsiderationRepository;
 * 
 * @ExtendWith(MockitoExtension.class) public class
 * CaseconsiderationSqlHelperTest {
 * 
 * @Mock private Constantsconfig constant;
 * 
 * @Mock private CaseconsiderationRepository caseconsiderationRepository;
 * 
 * @InjectMocks private CaseconsiderationSqlHelper caseconsiderationSqlHelper;
 * 
 * @BeforeEach public void setUp() { ReflectionTestUtils.setField(constant,
 * "Entity_Caseconsideration", "Caseconsideration"); }
 * 
 * @Test public void testInsertForALL() { // Prepare test data
 * ArrayList<CaseconsiderationData> arrayListcaseconsideration = new
 * ArrayList<>(); CaseconsiderationData data1 = new CaseconsiderationData();
 * data1.setFos_caseconsiderationid("123"); data1.setStatecode(1L);
 * data1.setFos_consideration(2L); data1.setFos_committed(true);
 * data1.setFos_caseid("case123"); data1.setFos_individual("indiv123");
 * data1.setFos_referencenumber("ref123"); data1.setVersionnumber(1L);
 * data1.setCreatedon("2024-01-01"); data1.setModifiedon("2024-01-02");
 * data1.setCreatedby("creator123"); data1.setModifiedby("modifier123");
 * 
 * arrayListcaseconsideration.add(data1);
 * 
 * CaseconsiderationData data2 = new CaseconsiderationData();
 * data2.setFos_caseconsiderationid(null);
 * arrayListcaseconsideration.add(data2);
 * 
 * String Fetch_IncrementalDataLoadAuditId = "audit123";
 * 
 * // Call the method
 * caseconsiderationSqlHelper.insertForALL(arrayListcaseconsideration,
 * Fetch_IncrementalDataLoadAuditId);
 * 
 * // Verify interactions verify(caseconsiderationRepository,
 * times(1)).InsertQuery( eq("123"), eq(1L), eq(2L), eq(true), eq("case123"),
 * eq("indiv123"), eq("ref123"), eq(1L), eq("2024-01-01"), eq("2024-01-02"),
 * eq("creator123"), eq("modifier123"), eq(Fetch_IncrementalDataLoadAuditId) );
 * 
 * verify(caseconsiderationRepository, never()).InsertQuery( isNull(),
 * anyLong(), anyLong(), anyBoolean(), anyString(), anyString(), anyString(),
 * anyLong(), anyString(), anyString(), anyString(), anyString(),
 * eq(Fetch_IncrementalDataLoadAuditId) ); }
 * 
 * @Test public void testInsertcaseconsideration() { // Prepare test data String
 * Fetch_IncrementalDataLoadAuditId = "audit123"; CaseconsiderationData data =
 * new CaseconsiderationData(); data.setFos_caseconsiderationid("123");
 * data.setStatecode(1L); data.setFos_consideration(2L);
 * data.setFos_committed(true); data.setFos_caseid("case123");
 * data.setFos_individual("indiv123"); data.setFos_referencenumber("ref123");
 * data.setVersionnumber(1L); data.setCreatedon("2024-01-01");
 * data.setModifiedon("2024-01-02"); data.setCreatedby("creator123");
 * data.setModifiedby("modifier123");
 * 
 * // Call the method caseconsiderationSqlHelper.insertcaseconsideration(
 * Fetch_IncrementalDataLoadAuditId, data);
 * 
 * // Verify interactions verify(caseconsiderationRepository,
 * times(1)).InsertQuery( eq("123"), eq(1L), eq(2L), eq(true), eq("case123"),
 * eq("indiv123"), eq("ref123"), eq(1L), eq("2024-01-01"), eq("2024-01-02"),
 * eq("creator123"), eq("modifier123"), eq(Fetch_IncrementalDataLoadAuditId) );
 * } }
 */