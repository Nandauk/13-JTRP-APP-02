package com.ombudsman.service.services;

import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.times;
import static org.junit.Assert.assertThat;
import static org.mockito.Mockito.doThrow;

import java.io.IOException;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

public class CaseconsiderationPhxToSqlServiceTest {

    @Mock
    private CaseconsiderationPhxToSqlService caseconsiderationPhxToSqlService;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testCaseconsiderationPhxToSql() throws IOException, InterruptedException {
        caseconsiderationPhxToSqlService.caseconsiderationPhxToSql();
        verify(caseconsiderationPhxToSqlService, times(1)).caseconsiderationPhxToSql();
    }

    @Test
    public void testCaseconsiderationPhxToSql_recon() throws IOException, InterruptedException {
        String startTime = "2025-01-01T00:00:00";
        String endTime = "2025-01-01T23:59:59";
        caseconsiderationPhxToSqlService.caseconsiderationPhxToSql_recon(startTime, endTime);
        verify(caseconsiderationPhxToSqlService, times(1)).caseconsiderationPhxToSql_recon(startTime, endTime);
    }

  
}
