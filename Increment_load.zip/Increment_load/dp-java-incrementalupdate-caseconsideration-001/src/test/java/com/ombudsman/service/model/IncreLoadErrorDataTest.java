package com.ombudsman.service.model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

public class IncreLoadErrorDataTest {

    @Test
    public void testSelectedGetters() {
        IncreLoadErrorData increLoadErrorData = new IncreLoadErrorData();

        // Set values using setters
        increLoadErrorData.setIncremental_data_load_error_id("error123");
        increLoadErrorData.setIncremental_data_load_audit_id("audit456");
        increLoadErrorData.setData_pay_load("Sample payload");
        increLoadErrorData.setError_created_datetime("2023-08-21T14:30:00Z");
        increLoadErrorData.setCurrent_error_status_id(1L);
        increLoadErrorData.setError_code("ERR001");
        increLoadErrorData.setError_log("Error log details");
        increLoadErrorData.setCreated_on("2023-08-21T14:00:00Z");
        increLoadErrorData.setModified_on("2023-08-21T15:30:00Z");
        increLoadErrorData.setCreated_by("John Doe");
        increLoadErrorData.setModified_by("Jane Doe");

        // Test getters
        assertEquals("error123", increLoadErrorData.getIncremental_data_load_error_id());
        assertEquals("audit456", increLoadErrorData.getIncremental_data_load_audit_id());
        assertEquals("Sample payload", increLoadErrorData.getData_pay_load());
        assertEquals("2023-08-21T14:30:00Z", increLoadErrorData.getError_created_datetime());
        assertEquals(1L, increLoadErrorData.getCurrent_error_status_id());
        assertEquals("ERR001", increLoadErrorData.getError_code());
        assertEquals("Error log details", increLoadErrorData.getError_log());
        assertEquals("2023-08-21T14:00:00Z", increLoadErrorData.getCreated_on());
        assertEquals("2023-08-21T15:30:00Z", increLoadErrorData.getModified_on());
        assertEquals("John Doe", increLoadErrorData.getCreated_by());
        assertEquals("Jane Doe", increLoadErrorData.getModified_by());
    }
}
