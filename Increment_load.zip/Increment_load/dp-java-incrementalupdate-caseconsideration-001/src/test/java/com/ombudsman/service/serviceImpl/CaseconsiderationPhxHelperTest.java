/*
 * package com.ombudsman.service.serviceImpl;
 * 
 * import static org.mockito.Mockito.*; import static
 * org.junit.jupiter.api.Assertions.*;
 * 
 * import java.io.IOException; import java.lang.reflect.Method; import
 * java.time.Instant; import java.time.ZoneId; import
 * java.time.format.DateTimeFormatter; import java.util.ArrayList; import
 * java.util.concurrent.TimeUnit;
 * 
 * import org.junit.jupiter.api.BeforeEach; import org.junit.jupiter.api.Test;
 * import org.junit.jupiter.api.extension.ExtendWith; import
 * org.mockito.InjectMocks; import org.mockito.Mock; import
 * org.mockito.junit.jupiter.MockitoExtension; import
 * org.springframework.test.util.ReflectionTestUtils;
 * 
 * import com.ombudsman.service.common.Constantsconfig; import
 * com.ombudsman.service.common.PhoenixHelper; import
 * com.ombudsman.service.repo.CaseconsiderationRepository; import
 * com.ombudsman.service.repo.IncreLoadAuditRepository; import
 * com.ombudsman.service.repo.IncreLoadErrorRepository; import
 * com.ombudsman.service.model.CaseconsiderationData; import
 * com.ombudsman.service.response.CaseconsiderationRes;
 * 
 * import okhttp3.mockwebserver.MockResponse; import
 * okhttp3.mockwebserver.MockWebServer; import okhttp3.HttpUrl; import
 * okhttp3.OkHttpClient; import okhttp3.Request; import okhttp3.Response;
 * 
 * @ExtendWith(MockitoExtension.class) public class
 * CaseconsiderationPhxHelperTest {
 * 
 * @Mock private Constantsconfig constant;
 * 
 * @Mock private PhoenixHelper phoenixHelper;
 * 
 * @Mock private CaseconsiderationRepository caseconsiderationRepository;
 * 
 * @Mock private CaseconsiderationSqlHelper caseconsiderationsqlhelper;
 * 
 * @Mock private IncreLoadAuditRepository increLoadAuditRep;
 * 
 * @Mock private IncreLoadErrorRepository increLoadErrorRep;
 * 
 * @InjectMocks private CaseconsiderationPhxHelper caseconsiderationPhxHelper;
 * 
 * private MockWebServer mockWebServer;
 * 
 * @BeforeEach public void setUp() throws Exception { mockWebServer = new
 * MockWebServer(); mockWebServer.start();
 * 
 * // Set the mock APIM_HOST constant ReflectionTestUtils.setField(constant,
 * "APIM_HOST", mockWebServer.url("/").host());
 * ReflectionTestUtils.setField(constant, "Entity_Caseconsideration",
 * "Caseconsideration"); }
 * 
 * @Test public void testCaseConsidrationphxhelper_success() throws Exception {
 * // Mock the response from Phoenix API MockResponse mockResponse = new
 * MockResponse()
 * .setBody("{\"value\": [{\"fos_individualid\": \"123\", \"fos_caseconsiderationid\": \"456\", \"modifiedon\": \"2024-10-10\"}]}"
 * ) .addHeader("Content-Type", "application/json");
 * mockWebServer.enqueue(mockResponse);
 * 
 * // Prepare mock inputs String Fetch_IncrementalDataLoadAuditId = "audit123";
 * CaseconsiderationRes caseconsiderationRes = new CaseconsiderationRes();
 * ArrayList<CaseconsiderationData> arrayListCaseconsideration = new
 * ArrayList<>(); int batchsize = 10; String startWebJob_formatted =
 * "2024-10-01"; String lastupdatedDate = "2024-09-30"; String entityname =
 * "Caseconsideration";
 * 
 * // Mock Phoenix request build method HttpUrl mockHttpUrl =
 * mockWebServer.url("/phoniex/fos_caseconsiderations?fetchXml=test");
 * when(phoenixHelper.getPhoenixRequestBuild(anyString())).thenReturn(new
 * okhttp3.Request.Builder().url(mockHttpUrl).build());
 * 
 * // Use reflection to make the private method accessible Method method =
 * CaseconsiderationPhxHelper.class.getDeclaredMethod(
 * "caseConsidrationphxhelper", String.class, CaseconsiderationRes.class,
 * ArrayList.class, int.class, String.class, String.class, String.class );
 * method.setAccessible(true);
 * 
 * // Call the method String result = (String)
 * method.invoke(caseconsiderationPhxHelper, startWebJob_formatted,
 * caseconsiderationRes, arrayListCaseconsideration, batchsize, lastupdatedDate,
 * entityname, Fetch_IncrementalDataLoadAuditId );
 * 
 * assertNotNull(result); assertEquals("2024-10-10", result);
 * verify(caseconsiderationsqlhelper,
 * times(1)).insertForALL(eq(arrayListCaseconsideration),
 * eq(Fetch_IncrementalDataLoadAuditId));
 * assertFalse(arrayListCaseconsideration.isEmpty()); }
 * 
 * @Test public void testPhxCaseconsideration_success() throws Exception { //
 * Mock the response from Phoenix API MockResponse mockResponse = new
 * MockResponse()
 * .setBody("{\"value\": [{\"fos_individualid\": \"123\", \"fos_caseconsiderationid\": \"456\", \"modifiedon\": \"2024-10-10\"}]}"
 * ) .addHeader("Content-Type", "application/json");
 * mockWebServer.enqueue(mockResponse);
 * 
 * // Prepare mock inputs String fetch_IncrementalDataLoadAuditId = "audit123";
 * CaseconsiderationRes caseconsiderationRes = new CaseconsiderationRes();
 * ArrayList<CaseconsiderationData> arrayListcaseconsideration = new
 * ArrayList<>(); String startWebJob_formatted = "2024-10-01"; String
 * lastupdatedDate = "2024-09-30"; int batchsize = 10; Long totalRecord = 0L;
 * 
 * // Mock Phoenix request build method HttpUrl mockHttpUrl =
 * mockWebServer.url("/phoniex/fos_caseconsiderations?fetchXml=test");
 * when(phoenixHelper.getPhoenixRequestBuild(anyString())).thenReturn(new
 * okhttp3.Request.Builder().url(mockHttpUrl).build());
 * 
 * // Use reflection to make the private method accessible Method
 * caseConsidrationphxhelperMethod =
 * CaseconsiderationPhxHelper.class.getDeclaredMethod(
 * "caseConsidrationphxhelper", String.class, CaseconsiderationRes.class,
 * ArrayList.class, int.class, String.class, String.class, String.class );
 * caseConsidrationphxhelperMethod.setAccessible(true);
 * 
 * // Stub the void method
 * doNothing().when(caseconsiderationsqlhelper).insertForALL(any(ArrayList.class
 * ), anyString());
 * 
 * // Call the method Long result =
 * caseconsiderationPhxHelper.phxCaseconsideration(
 * fetch_IncrementalDataLoadAuditId, caseconsiderationRes,
 * arrayListcaseconsideration, startWebJob_formatted, lastupdatedDate,
 * batchsize, totalRecord );
 * 
 * assertNotNull(result); assertTrue(result > 0);
 * assertFalse(arrayListcaseconsideration.isEmpty()); } }
 */