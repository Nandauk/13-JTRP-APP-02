package com.ombudsman.service.model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

public class IncreLoadAuditDataTest {

	@Test
	public void testSelectedGetters() {
		IncreLoadAuditData increLoadAuditData = new IncreLoadAuditData();

		// Set values using setters
		increLoadAuditData.setIncremental_data_load_audit_id("audit-12345");
		increLoadAuditData.setJob_id(1);

		increLoadAuditData.setTotal_number_of_records(100);
		increLoadAuditData.setNumber_of_processed_record(90);
		increLoadAuditData.setNumber_of_failed_record(10);
		increLoadAuditData.setCurrent_job_status_id(2);
		increLoadAuditData.setJob_close_datetime("2023-08-21T16:00:00Z");
		increLoadAuditData.setNext_job_run_datetime("2023-08-22T14:30:00Z");
		increLoadAuditData.setSource("System");
		increLoadAuditData.setCreated_on("2023-08-21T14:00:00Z");
		increLoadAuditData.setModified_on("2023-08-21T15:30:00Z");
		increLoadAuditData.setCreated_by("John Doe");
		increLoadAuditData.setModified_by("Jane Doe");

		// Test getters
		assertEquals("audit-12345", increLoadAuditData.getIncremental_data_load_audit_id());
		assertEquals(1, increLoadAuditData.getJob_id());

		assertEquals(100, increLoadAuditData.getTotal_number_of_records());
		assertEquals(90, increLoadAuditData.getNumber_of_processed_record());
		assertEquals(10, increLoadAuditData.getNumber_of_failed_record());
		assertEquals(2, increLoadAuditData.getCurrent_job_status_id());
		assertEquals("2023-08-21T16:00:00Z", increLoadAuditData.getJob_close_datetime());
		assertEquals("2023-08-22T14:30:00Z", increLoadAuditData.getNext_job_run_datetime());
		assertEquals("System", increLoadAuditData.getSource());
		assertEquals("2023-08-21T14:00:00Z", increLoadAuditData.getCreated_on());
		assertEquals("2023-08-21T15:30:00Z", increLoadAuditData.getModified_on());
		assertEquals("John Doe", increLoadAuditData.getCreated_by());
		assertEquals("Jane Doe", increLoadAuditData.getModified_by());
	}
}
