package com.ombudsman.service.response;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.Arrays;
import java.util.List;

import com.ombudsman.service.model.CaseconsiderationData;
import org.junit.jupiter.api.Test;

public class CaseconsiderationResTest {

    @Test
    public void testGetAndSetCaseconsiderationData() {
        CaseconsiderationRes response = new CaseconsiderationRes();

        // Create sample data
        CaseconsiderationData data1 = new CaseconsiderationData();
        CaseconsiderationData data2 = new CaseconsiderationData();
        List<CaseconsiderationData> sampleData = Arrays.asList(data1, data2);

        // Test setter
        response.setCaseconsiderationData(sampleData);

        // Test getter
        List<CaseconsiderationData> result = response.getCaseconsiderationData();

        // Assert that the getter returns the correct data
        assertThat(result).isEqualTo(sampleData);
    }
}
