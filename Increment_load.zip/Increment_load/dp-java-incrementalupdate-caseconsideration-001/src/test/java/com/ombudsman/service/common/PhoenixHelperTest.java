package com.ombudsman.service.common;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;

import okhttp3.Request;

@RunWith(MockitoJUnitRunner.class)
public class PhoenixHelperTest {

    @InjectMocks
    private PhoenixHelper phoenixHelper;

    private String validHttpUrl;

    @BeforeEach
    public void setUp() {
        phoenixHelper = new PhoenixHelper();
        validHttpUrl = "https://example.com/api/data"; // Ensure this is a valid URL
    }

    @Test
    public void testGetPhoenixRequestBuild() {
        // Act
        Request request = phoenixHelper.getPhoenixRequestBuild(validHttpUrl);

        // Assert
        assertNotNull(request, "Request should not be null");
        assertEquals(validHttpUrl, request.url().toString(), "URL should match the provided URL");
        assertEquals("GET", request.method(), "Request method should be GET");
        assertEquals("4.0", request.header("OData-MaxVersion"), "OData-MaxVersion header should be 4.0");
        assertEquals("4.0", request.header("OData-Version"), "OData-Version header should be 4.0");
        assertEquals("application/json", request.header("Accept"), "Accept header should be application/json");
        assertEquals("application/json; charset=utf-8", request.header("Content-Type"), "Content-Type header should be application/json; charset=utf-8");
        assertEquals("odata.include-annotations=\"*\"", request.header("Prefer"), "Prefer header should be odata.include-annotations=\"*\"");
        assertEquals("no-cache", request.header("cache-control"), "cache-control header should be no-cache");
    }
}
