package com.ombudsman.service.repo;

import com.ombudsman.service.model.IncreLoadErrorData;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class IncreLoadErrorRepositoryTest {

    @Mock
    private IncreLoadErrorRepository repository;

   

    @Test
    public void testInsertQuery() {
        String auditId = "auditId123";
        String dataPayload = "dataPayload";
        int errorStatusId = 1;
        String errorCode = "errorCode123";
        String errorLog = "errorLog123";
        String createdBy = "creator";
        String modifiedBy = "modifier";

        // Mock the InsertQuery method to return 1 for a successful insert
        when(repository.InsertQuery(auditId, dataPayload, errorStatusId, errorCode, errorLog, createdBy, modifiedBy)).thenReturn(1);

        int result = repository.InsertQuery(auditId, dataPayload, errorStatusId, errorCode, errorLog, createdBy, modifiedBy);
        assertThat(result).isEqualTo(1);
    }

    @Test
    public void testGetIncrementalDataLoadErrorId() {
        String auditId = "auditId123";
        String errorId = "errorId123";

        // Mock the getIncrementalDataLoadErrorId method to return the expected error id
        when(repository.getIncrementalDataLoadErrorId(auditId)).thenReturn(errorId);

        String retrievedErrorId = repository.getIncrementalDataLoadErrorId(auditId);
        assertThat(retrievedErrorId).isEqualTo("errorId123");
    }
}