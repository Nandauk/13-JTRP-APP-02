package com.ombudsman.service.exception;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

public class MailJetServiceExceptionTest {

	@Test
	public void testMailJetServiceException_Constructor() {
		String message = "Service unavailable";
		String exceptionMessage = "Timeout while connecting to MailJet service";

		MailJetServiceException exception = new MailJetServiceException(message, exceptionMessage);

		assertEquals("RESPONDENT_AZURE_1000", exception.getCode());
		assertEquals(message, exception.getMessage());
		assertEquals(exceptionMessage, exception.getExceptionMessage());

	}
}
