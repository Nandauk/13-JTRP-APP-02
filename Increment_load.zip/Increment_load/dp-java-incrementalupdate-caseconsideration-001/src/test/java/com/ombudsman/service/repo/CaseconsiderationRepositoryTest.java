package com.ombudsman.service.repo;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class CaseconsiderationRepositoryTest {

	@Mock
	private CaseconsiderationRepository repository;

	@Test
	public void testInsertQuery() {
		String fos_caseconsiderationid = "consideration123";
		Long statecode = 1L;
		Long fos_consideration = 2L;
		Boolean fos_committed = true;
		String fos_caseid = "case123";
		String fos_individual = "individual123";
		String fos_referencenumber = "reference123";
		Long versionnumber = 1L;
		String createdon = "2025-01-24";
		String modifiedon = "2025-01-24";
		String createdby = "creator";
		String modifiedby = "modifier";
		String incrementaldataloadjobauditid = "auditId123";

		// Mock the InsertQuery method
		when(repository.InsertQuery(fos_caseconsiderationid, statecode, fos_consideration, fos_committed, fos_caseid,
				fos_individual, fos_referencenumber, versionnumber, createdon, modifiedon, createdby, modifiedby,
				incrementaldataloadjobauditid)).thenReturn(1);

		// Call the method on the mock
		int result = repository.InsertQuery(fos_caseconsiderationid, statecode, fos_consideration, fos_committed,
				fos_caseid, fos_individual, fos_referencenumber, versionnumber, createdon, modifiedon, createdby,
				modifiedby, incrementaldataloadjobauditid);

		// Assert the result
		assertThat(result).isEqualTo(1);
	}

}
