/*package com.ombudsman.service.serviceImpl;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

import java.io.IOException;
import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.microsoft.graph.models.List;
import com.ombudsman.service.common.Constantsconfig;
import com.ombudsman.service.common.PhoenixHelper;
import com.ombudsman.service.repo.CaseconsiderationRepository;
import com.ombudsman.service.repo.IncreLoadAuditRepository;
import com.ombudsman.service.repo.IncreLoadErrorRepository;

@ExtendWith(MockitoExtension.class)
public class CaseconsiderationPhxToSqlImplTest {

	private static final Logger LOG = LoggerFactory.getLogger(CaseconsiderationPhxToSqlImplTest.class);

	@Mock
	private PhoenixHelper phoenixHelper;

	@Mock
	private CaseconsiderationRepository caseconsiderationRepository;

	@Mock
	private IncreLoadAuditRepository increLoadAuditRep;

	@Mock
	private IncreLoadErrorRepository increLoadErrorRep;

	@Mock
	private Constantsconfig constant;

	@Mock
	private CaseconsiderationSqlHelper caseconsiderationsqlhelper;

	@Mock
	private CaseconsiderationPhxHelper caseconsiderationphxhelper;

	@Mock
	private EmailHelper emailhelper;

	@InjectMocks
	private CaseconsiderationPhxToSqlImpl caseconsiderationPhxToSqlImpl;

	@BeforeEach
	public void setUp() {
		// Initialize constants
		constant.DataSourceName = "SCH";
		constant.In_Progress = "In_Progress";
		constant.Completed = "Completed";
		constant.Ready_To_Process = "Ready_To_Process";
		constant.Entity_Caseconsideration = "fos_caseconsideration";
	}

	@Test
	public void testCaseconsiderationPhxToSql() throws IOException, InterruptedException {
		// Arrange
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS").withZone(ZoneId.of("UTC"));
		String startWebJob_formatted = formatter.format(Instant.now());

		when(increLoadAuditRep.getJobID(anyString())).thenReturn(1);
		when(increLoadAuditRep.getCurrentStatusIPId(anyString(), anyString())).thenReturn(1);

		when(increLoadAuditRep.getCurrentStatusRTPId(anyString(), anyString())).thenReturn(3);
		when(increLoadAuditRep.getIncrementalDataLoadAuditId(anyString(), anyInt(), anyString(), anyString()))
				.thenReturn("id");
		when(increLoadAuditRep.findLatestDatefromphx(anyString())).thenReturn("2023-01-01");

		// Act
		caseconsiderationPhxToSqlImpl.caseconsiderationPhxToSql();

		// Assert
		verify(increLoadAuditRep, times(1)).getJobID(anyString());
		verify(increLoadAuditRep, times(1)).getCurrentStatusIPId(anyString(), anyString());

		verify(increLoadAuditRep, times(1)).getCurrentStatusRTPId(anyString(), anyString());
		verify(increLoadAuditRep, times(1)).InsertQuery(anyInt(), anyString(), anyInt(), anyLong(), anyInt(), anyInt(),
				isNull(), anyString(), anyString(), anyString());

		// Add more verifications as needed
	}

	@Test
	public void testCaseconsiderationPhxToSql_Exception() throws IOException, InterruptedException {
		// Arrange
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS").withZone(ZoneId.of("UTC"));
		String startWebJob_formatted = formatter.format(Instant.now());

		constant.DataSourceName = "SCH";
		constant.In_Progress = "In_Progress";
		constant.Completed = "Completed";
		constant.Ready_To_Process = "Ready_To_Process";
		constant.Entity_Caseconsideration = "fos_caseconsideration";

		when(increLoadAuditRep.getJobID(anyString())).thenReturn(1);
		when(increLoadAuditRep.getCurrentStatusIPId(anyString(), anyString())).thenReturn(1);

		when(increLoadAuditRep.getCurrentStatusRTPId(anyString(), anyString())).thenReturn(3);
		doThrow(new RuntimeException("Test exception")).when(caseconsiderationphxhelper).phxCaseconsideration(
				anyString(), any(), any(ArrayList.class), anyString(), anyString(), anyInt(), anyLong());

		// Act & Assert
		assertThrows(RuntimeException.class, () -> caseconsiderationPhxToSqlImpl.caseconsiderationPhxToSql());
	}

	@Test
	public void testCaseconsiderationPhxToSql_recon() throws IOException, InterruptedException {
		// Arrange
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS").withZone(ZoneId.of("UTC"));
		String startWebJob_recon = formatter.format(Instant.now());

		when(increLoadAuditRep.getJobID(anyString())).thenReturn(1);
		when(increLoadAuditRep.getCurrentStatusIPId(anyString(), anyString())).thenReturn(1);

		when(increLoadAuditRep.getCurrentStatusRTPId(anyString(), anyString())).thenReturn(3);
		when(increLoadAuditRep.getIncrementalDataLoadAuditId(anyString(), anyInt(), anyString(), anyString()))
				.thenReturn("id");

		// Act
		caseconsiderationPhxToSqlImpl.caseconsiderationPhxToSql_recon("2023-01-01 00:00:00", "2023-01-02 00:00:00");

		// Assert
		verify(increLoadAuditRep, times(1)).getJobID(anyString());
		verify(increLoadAuditRep, times(1)).getCurrentStatusIPId(anyString(), anyString());

		verify(increLoadAuditRep, times(1)).getCurrentStatusRTPId(anyString(), anyString());
		verify(increLoadAuditRep, times(1)).InsertQuery(anyInt(), anyString(), anyInt(), anyLong(), anyInt(), anyInt(),
				isNull(), anyString(), anyString(), anyString());

		// Add more verifications as needed
	}

	@Test
	public void testCaseconsiderationPhxToSql_recon_Exception() throws IOException, InterruptedException {
		// Arrange
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS").withZone(ZoneId.of("UTC"));
		String startWebJob_recon = formatter.format(Instant.now());

		constant.DataSourceName = "SCH";
		constant.In_Progress = "In_Progress";
		constant.Completed = "Completed";
		constant.Ready_To_Process = "Ready_To_Process";
		constant.Entity_Caseconsideration = "fos_caseconsideration";

		when(increLoadAuditRep.getJobID(anyString())).thenReturn(1);
		when(increLoadAuditRep.getCurrentStatusIPId(anyString(), anyString())).thenReturn(1);

		when(increLoadAuditRep.getCurrentStatusRTPId(anyString(), anyString())).thenReturn(3);
		doThrow(new RuntimeException("Test exception")).when(caseconsiderationphxhelper).phxCaseconsideration(
				anyString(), any(), any(ArrayList.class), anyString(), anyString(), anyInt(), anyLong());

		// Act & Assert
		assertThrows(RuntimeException.class, () -> caseconsiderationPhxToSqlImpl
				.caseconsiderationPhxToSql_recon("2023-01-01 00:00:00", "2023-01-02 00:00:00"));
	}
} */
