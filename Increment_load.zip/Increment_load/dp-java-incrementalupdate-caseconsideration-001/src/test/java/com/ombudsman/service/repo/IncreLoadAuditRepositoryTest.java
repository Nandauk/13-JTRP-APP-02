package com.ombudsman.service.repo;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.ombudsman.service.model.IncreLoadAuditData;

@ExtendWith(MockitoExtension.class)
public class IncreLoadAuditRepositoryTest {

    @Mock
    private IncreLoadAuditRepository increLoadAuditRepository;

    @BeforeEach
    public void setUp() {
        // Setup mock data if necessary
        // If you're using a service that depends on this repository, you can create instances here.
    }

    @Test
    public void whenFindByCreatedBy_thenReturnAuditData() {
        String createdBy = "test-user";
        IncreLoadAuditData mockData = new IncreLoadAuditData();
        mockData.setSource("unit-test");

        // Mock the getDataSourceName method to return the expected source when called with createdBy
        when(increLoadAuditRepository.getDataSourceName(createdBy)).thenReturn(mockData.getSource());

        String source = increLoadAuditRepository.getDataSourceName(createdBy);
        assertThat(source).isEqualTo("unit-test");
    }

    @Test
    public void whenInsertQuery_thenSuccess() {
        int jobId = 2;
        int totalRecords = 200;
        Long processedRecords = 190L;
        Integer failedRecords = 10;
        Integer statusId = 1;
        String closeDatetime = "2025-01-23T21:00:00Z";
        String source = "unit-test-2";
        String createdBy = "test-user-2";
        String modifiedBy = "test-user";

        // Mock the InsertQuery method to return 1 for a successful insert
        when(increLoadAuditRepository.InsertQuery(jobId, "2025-01-23T20:39:00Z", totalRecords, processedRecords,
                failedRecords, statusId, closeDatetime, source, createdBy, modifiedBy)).thenReturn(1);

        int result = increLoadAuditRepository.InsertQuery(jobId, "2025-01-23T20:39:00Z", totalRecords, processedRecords,
                failedRecords, statusId, closeDatetime, source, createdBy, modifiedBy);
        assertThat(result).isEqualTo(1);
    }
}