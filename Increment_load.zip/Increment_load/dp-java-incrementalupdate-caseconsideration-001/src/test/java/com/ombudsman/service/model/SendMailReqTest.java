package com.ombudsman.service.model;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.util.ArrayList;
import java.util.List;

public class SendMailReqTest {

    @Test
    public void testSendMailReq() {
        // Create a new instance of SendMailReq
        SendMailReq sendMailReq = new SendMailReq();

        // Create a list of Messages
        List<Messages> messagesList = new ArrayList<>();
        Messages message1 = new Messages(); // Assuming Messages has a default constructor
        Messages message2 = new Messages();
        messagesList.add(message1);
        messagesList.add(message2);

        // Set values using setter
        sendMailReq.setMessages(messagesList);

        // Assert values using getter
        List<Messages> retrievedMessages = sendMailReq.getMessages();
        assertNotNull(retrievedMessages);
        assertEquals(2, retrievedMessages.size());
        assertSame(message1, retrievedMessages.get(0));
        assertSame(message2, retrievedMessages.get(1));
    }
}
