package com.ombudsman.service.model;

import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class ToTest {

    private To to;

    @BeforeEach
    public void setUp() {
        to = new To();
    }

    @Test
    public void testSetAndGetEmail() {
        String email = "test@example.com";
        to.setEmail(email);
        assertEquals(email, to.getEmail());
    }

    @Test
    public void testSetAndGetName() {
        String name = "John Doe";
        to.setName(name);
        assertEquals(name, to.getName());
    }
}
