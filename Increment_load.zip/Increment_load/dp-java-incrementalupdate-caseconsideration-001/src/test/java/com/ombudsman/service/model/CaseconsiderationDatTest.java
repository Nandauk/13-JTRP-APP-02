package com.ombudsman.service.model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

public class CaseconsiderationDatTest {

    @Test
    public void testGetters() {
        CaseconsiderationData caseData = new CaseconsiderationData();

        // Set values using setters
        caseData.setFos_caseconsiderationid("consid123");
        caseData.setStatecode(1L);
        caseData.setFos_consideration(2L);
        caseData.setFos_committed(true);
        caseData.setFos_caseid("case123");
        caseData.setFos_individual("individual123");
        caseData.setFos_referencenumber("ref123");
        caseData.setVersionnumber(1L);
        caseData.setCreatedon("2023-08-21T14:30:00Z");
        caseData.setModifiedon("2023-08-21T15:00:00Z");
        caseData.setCreatedby("John Doe");
        caseData.setModifiedby("Jane Doe");
        caseData.setIncrementaldataloadjobauditid("audit-12345");

        // Test getters
        assertEquals("consid123", caseData.getFos_caseconsiderationid());
        assertEquals(1L, caseData.getStatecode());
        assertEquals(2L, caseData.getFos_consideration());
        assertEquals(true, caseData.getFos_committed());
        assertEquals("case123", caseData.getFos_caseid());
        assertEquals("individual123", caseData.getFos_individual());
        assertEquals("ref123", caseData.getFos_referencenumber());
        assertEquals(1L, caseData.getVersionnumber());
        assertEquals("2023-08-21T14:30:00Z", caseData.getCreatedon());
        assertEquals("2023-08-21T15:00:00Z", caseData.getModifiedon());
        assertEquals("John Doe", caseData.getCreatedby());
        assertEquals("Jane Doe", caseData.getModifiedby());
        assertEquals("audit-12345", caseData.getIncrementaldataloadjobauditid());
    }
}
