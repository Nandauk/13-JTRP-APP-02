package com.ombudsman.service.digitalmessage.Model;

public class MessageFromPhx {

	private String IncrementalobAuditID;

	public String getIncrementalobAuditID() {
		return IncrementalobAuditID;
	}

	public void setIncrementalobAuditID(String incrementalobAuditID) {
		IncrementalobAuditID = incrementalobAuditID;
	}
}
