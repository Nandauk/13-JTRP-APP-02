package com.ombudsman.service.digitalmessage.component;

import java.util.UUID;

import com.ombudsman.service.digitalmessage.Model.BaseTableDTO;
import com.ombudsman.service.digitalmessage.Model.DpSupportQueueMessage;
import com.ombudsman.service.digitalmessage.Model.PhoenixServiceBusMessage;

public class AzureFunctionHelper {

	public BaseTableDTO setValuesToBaseTable(PhoenixServiceBusMessage message)
	{

		BaseTableDTO baseSetter=new BaseTableDTO();
		baseSetter.setFosDirection("140000000");
		baseSetter.setFosDirectionName("Incoming");
		baseSetter.setFosPortalType("140000000");
		baseSetter.setFosPortalTypeName("Complainant");
		baseSetter.setTo(message.getTo());
		baseSetter.setToName("Financial Ombudsman Service");
		baseSetter.setFrom(message.getFrom());
		baseSetter.setFromName(message.getUserName());
		baseSetter.setDescription(message.getMessage());
		baseSetter.setCreatedOn(message.getCreatedOn());
		baseSetter.setCreatedBy(message.getMessageSentByDpUserAdOid());//// need to alter the SB 
		baseSetter.setOverrideCreatedOn(message.getCreatedOn());
		baseSetter.setCreatedByName(null);
		baseSetter.setModifiedOn(null);
		baseSetter.setModifiedBy(null);
		baseSetter.setModifiedByName(null);
		baseSetter.setOwningUserId(message.getOwner());
		baseSetter.setOwningUserIdName(null);
		baseSetter.setStateCode(0);
		baseSetter.setStateCodeName("Open");
		baseSetter.setStatusCode(1);
		baseSetter.setStateCodeName("Open");
		baseSetter.setFosActivityCategory(140000036);
		baseSetter.setFosActivityCategoryName("Digital Messaging");
		baseSetter.setRegardingObjectId(message.getRegardingObjectId());
		baseSetter.setRegardingObjectIdName(null);
		baseSetter.setSubject(message.getSubject());
		baseSetter.setScheduledStart(null);
		baseSetter.setScheduledEnd(null);
		baseSetter.setFosFromForeFile("Complainant Portal");
		baseSetter.setFosToForeFile("Financial Ombudsman Service");
		baseSetter.setMessageSentByDpUserAdOid(message.getMessageSentByDpUserAdOid());
		baseSetter.setMessageSentByDpUserAdName(message.getMessageSentByDpUserAdName());
		baseSetter.setUserNotificationSendStatus(false);
		return baseSetter;
	}
	

}
