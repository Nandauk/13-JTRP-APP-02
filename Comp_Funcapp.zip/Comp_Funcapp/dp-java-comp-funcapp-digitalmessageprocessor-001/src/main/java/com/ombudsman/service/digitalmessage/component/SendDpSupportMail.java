package com.ombudsman.service.digitalmessage.component;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.http.MediaType;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.WebClient;

import com.ombudsman.service.digitalmessage.Model.DpSupportQueueMessage;
import com.ombudsman.service.digitalmessage.Response.MailjetResponseBody;


public class SendDpSupportMail {
	private static final String DP_SENDEREMAIL = System.getenv("DPSENDEREMAIL");
	
	private static final String DP_RECIEVEREMAIL = System.getenv("DPRECIEVEREMAIL");
	private static final String DP_TONAME = System.getenv("DPTONAME");
	private static final String URI = "/mailjet/send";
	Logger log = LogManager.getRootLogger();
	
	
	public  void sendErrorNotification(DpSupportQueueMessage supportMessage) {
		String DP_SENDERNAME = System.getenv("DPSENDERNAME");
		String url = System.getenv("APIM_URL") + URI;
		log.info(String.format("The mailjet URL is :%s", url));
		String emailContent = "<p>Hi DPSupport Team,</p>" +
				"<p>We are facing an issue while posting a message to the service. Below are the details:</p>" +
				"<ul>" +
				"<li><strong>Temp Digital Message Processing ID:</strong> " + supportMessage.getTempDigitalMessageProcessingId() + "</li>" +
				"<li><strong>Case Reference Number Incident ID:</strong> " + supportMessage.getCaseReferenceNumberIncidentId() + "</li>" +
				"<li><strong>Failed SB Message ID:</strong> " + supportMessage.getFailedSbMessageId() + "</li>" +
				"<li><strong>Source:</strong> " + supportMessage.getFuncationAppName() + "</li>" +
				"<li><strong>Error Info:</strong> " + supportMessage.getErrorInfo() + "</li>" +
				"<li><strong>Queue Name:</strong> " + supportMessage.getQueuename() + "</li>" +
				"<li><strong>Environment:</strong> " + supportMessage.getEnvironment() + "</li>" +
				"<li><strong>Date and Time Error Occurred:</strong> " + supportMessage.getDateTimeErrorOccurred() + "</li>" +
				"<li><strong>Error Details:</strong> " + supportMessage.getErrorDetails() + "</li>" +
				"</ul>" +
				"<p>Please look into this issue at your earliest convenience.</p>" +
				"<p>Thank you,</p>" +
				"<p>Support Team</p>";

		JSONObject emailPayload = new JSONObject();
		emailPayload.put("Messages", new JSONArray()
				.put(new JSONObject()
						.put("From", new JSONObject()
								.put("Email", DP_SENDEREMAIL)
								.put("Name", DP_SENDERNAME.replaceAll("'", "")))
						.put("To", new JSONArray()
								.put(new JSONObject()
										.put("Email", DP_RECIEVEREMAIL)
										.put("Name", DP_TONAME)))
						.put("Subject", "Error Notification")
						.put("TextPart", "An error occurred in the system.")
						.put("HTMLPart", emailContent)
						.put("CustomID", "ErrorNotification")));
		log.info(String.format("The mailbody sent to DP Support team: %s", emailPayload.toString()));
		MailjetResponseBody responsebody = WebClient.create().post().uri(url).body(BodyInserters.fromValue(emailPayload.toString()))
		.accept(MediaType.APPLICATION_JSON).retrieve().bodyToMono(MailjetResponseBody.class).block();
		log.info("The Mailjet request is done for DP support team");
	}
}
