package com.ombudsman.service.digitalmessage.serviceimpl;

import java.util.Optional;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import com.ombudsman.service.digitalmessage.exception.PhoenixServiceException;
import com.ombudsman.service.digitalmessage.service.PhoenixProcessor;

import okhttp3.HttpUrl;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
public class PhoenixProcessorImpl implements PhoenixProcessor {

	//MessageSource messageSource;

	Logger LOG = LogManager.getRootLogger();

	@Override
	//public int createRecordPhnx(String accessToken, String entity, String jsonBody) {
	public int createRecordPhnx(String entity, String jsonBody) {
		Response response;
		try {

			LOG.info("Entering to createRecordPhnx method");
			LOG.info(String.format("The entity Name :%s", entity));
			OkHttpClient client = new OkHttpClient();

			MediaType mediaType = MediaType.parse("application/json; charset=utf-8");
			LOG.info(String.format("phoenixHost :%s", System.getenv("phoenixHost")));
			HttpUrl httpUrl = new HttpUrl.Builder().scheme("https")
					.host(System.getenv("phoenixHost")).addPathSegment("phoenixOdata")
					.addPathSegment(entity).build();
			LOG.info(String.format("The APIM URL for the phoenix call :%s", httpUrl.toString()));
			RequestBody body = RequestBody.create(jsonBody, mediaType);

			Request request = new Request.Builder().url(httpUrl).addHeader("Content-Type", "application/json")
					.addHeader("OData-MaxVersion", "4.0").addHeader("OData-Version", "4.0")
					//.addHeader("Authorization", "Bearer " + accessToken)
					.post(body).build();

			response = Optional.ofNullable(client.newCall(request).execute()).orElseThrow(
					() -> new PhoenixServiceException("Phoenix exception occured", "No Response from ODATA api"));

			//				if (response.code() == 429) {
			//					LOG.info("Received 429 Too Many Requests, switching to second SPN");
			//					return connectWithSecondSPN(entity, jsonBody);
			//				}

			LOG.info("Response Code: {}", response.code());
			String responseBody = response.body().string();
			LOG.info("Response Body: {}", responseBody);
			if(response.code()==204||response.code()==200)
			{
				LOG.info("createRecordPhnx Method Sucess");
			}

			return (response.code());

		} catch (Exception e) {
			LOG.info("Phoenix connection failed {}" + e.getMessage() + " " + e.getStackTrace());
			throw new PhoenixServiceException("Phoenix exception occured", e.getMessage());

		}

	}



}
