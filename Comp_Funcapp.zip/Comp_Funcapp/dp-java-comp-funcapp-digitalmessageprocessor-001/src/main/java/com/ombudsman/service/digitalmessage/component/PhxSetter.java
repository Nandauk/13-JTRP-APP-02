package com.ombudsman.service.digitalmessage.component;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ombudsman.service.digitalmessage.Model.PhoenixServiceBusMessage;
import com.ombudsman.service.digitalmessage.Model.PortalActivityRequest;
import com.ombudsman.service.digitalmessage.Model.PortalActivityRequest.FosPortalActivityParty;

public class PhxSetter {

	public PortalActivityRequest settingValues(PhoenixServiceBusMessage phxSbValues) throws JsonProcessingException
	{
		Instant utcInstant=Instant.now();
		PortalActivityRequest phxSetter=new PortalActivityRequest();
		List<FosPortalActivityParty>list=new ArrayList<>();
		FosPortalActivityParty fosfrom=new FosPortalActivityParty();
		FosPortalActivityParty fosto=new FosPortalActivityParty();
		phxSetter.setActivityId(UUID.randomUUID());
		if ("teams".equalsIgnoreCase(phxSbValues.getCaseOwnerUserType())) {
		    phxSetter.setOwnerId("/teams(" + phxSbValues.getOwner().toString() + ")");
		}
		else
		{
			phxSetter.setOwnerId("/systemusers("+phxSbValues.getOwner().toString()+")");
		}
		phxSetter.setRegardingObjectIdIncidentFosPortal("/incidents("+phxSbValues.getRegardingObjectId().toString()+")");
		phxSetter.setSubject(phxSbValues.getSubject());
		phxSetter.setFosdirection(Long.valueOf(140000000));
		phxSetter.setDescription(phxSbValues.getMessage());
		phxSetter.setFosportaltype(Long.valueOf(140000000));
		phxSetter.setStatecode(0);
		phxSetter.setStatuscode(1);
		phxSetter.setFos_toforefile(phxSbValues.getToForEfile());
		phxSetter.setFos_activitycategory(Long.valueOf(140000038));
		phxSetter.setCreatedon(phxSbValues.getCreatedOn().toString());
		phxSetter.setFos_fromforefile(phxSbValues.getUserName());
		phxSetter.setScheduledend(LocalDateTime.ofInstant(utcInstant, ZoneOffset.UTC).toString());
		///
		fosfrom.setType("Microsoft.Dynamics.CRM.activityparty");
		fosfrom.setParticipationTypeMask(1);
		fosfrom.setPartyIdContact("/contacts/"+phxSbValues.getFrom());
		fosto.setType("Microsoft.Dynamics.CRM.activityparty");
		fosto.setParticipationTypeMask(2);
		fosto.setPartyIdContact("/systemusers/"+phxSbValues.getTo());
		list.add(fosto);
		list.add(fosfrom);
		phxSetter.setFosPortalActivityParties(list);
		
		return 	phxSetter;
	}

}
