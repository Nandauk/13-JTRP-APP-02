package com.ombudsman.service.digitalmessage.exception;
public class MessageSaveException extends RuntimeException {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public MessageSaveException(String message) {
        super(message);
    }
}
