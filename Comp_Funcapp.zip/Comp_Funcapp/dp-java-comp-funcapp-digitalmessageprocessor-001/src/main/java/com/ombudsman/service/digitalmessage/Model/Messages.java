package com.ombudsman.service.digitalmessage.Model;
import java.util.List;

import com.google.gson.annotations.SerializedName;



public class Messages {

	@SerializedName("from")
	From From;

	@SerializedName("to")
	List<To> To;

	@SerializedName("templateID")
	Long TemplateID;

	@SerializedName("templateLanguage")
	boolean TemplateLanguage;

	@SerializedName("variables")
	MailjetVariables Variables;


	public MailjetVariables getVariables() {
		return Variables;
	}
	public void setVariables(MailjetVariables variables) {
		Variables = variables;
	}
	public void setFrom(From From) {
		this.From = From;
	}
	public From getFrom() {
		return From;
	}

	public void setTo(List<To> To) {
		this.To = To;
	}
	public List<To> getTo() {
		return To;
	}

	public void setTemplateID(Long TemplateID) {
		this.TemplateID = TemplateID;
	}
	public Long getTemplateID() {
		return TemplateID;
	}

	public void setTemplateLanguage(boolean TemplateLanguage) {
		this.TemplateLanguage = TemplateLanguage;
	}
	public boolean getTemplateLanguage() {
		return TemplateLanguage;
	}


}