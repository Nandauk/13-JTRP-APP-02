package com.ombudsman.service.digitalmessage.exception;

public class MailJetServiceException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	

	public MailJetServiceException(String message,String exceptionMessage,StackTraceElement[] stackTrace) {
		super(message);
	}
	
}
