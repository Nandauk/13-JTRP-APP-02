package com.ombudsman.service.digitalmessage.Model;

import java.time.LocalDateTime;
import java.util.UUID;

public class BaseTableDTO {
	private UUID activityId;
	private String fosDirection;
	private String fosDirectionName;
	private String fosPortalType;
	private String fosPortalTypeName;
	private UUID to;
	private String toName;
	private UUID from;
	private String fromName;
	private String description;
	private LocalDateTime createdOn;
	private UUID createdBy;
	private LocalDateTime overrideCreatedOn;
	private String createdByName;
	private LocalDateTime modifiedOn;
	private UUID modifiedBy;
	private String modifiedByName;
	private UUID owningUserId;
	private String owningUserIdName;
	private long stateCode;
	private String stateCodeName;
	private long statusCode;
	private String statusCodeName;
	private long fosActivityCategory;
	private String fosActivityCategoryName;
	private UUID regardingObjectId;
	private String regardingObjectIdName;
	private String subject;
	private LocalDateTime scheduledStart;
	private LocalDateTime scheduledEnd;
	private String fosFromForeFile;
	private String fosToForeFile;
	private UUID messageSentByDpUserAdOid;
	private String messageSentByDpUserAdName;
	private UUID incrementalDataLoadJobAuditId;
	private LocalDateTime dpRecordCreatedOn;
	private LocalDateTime dpRecordModifiedOn;
	private boolean userNotificationSendStatus;
	public UUID getActivityId() {
		return activityId;
	}
	public void setActivityId(UUID activityId) {
		this.activityId = activityId;
	}
	public String getFosDirection() {
		return fosDirection;
	}
	public void setFosDirection(String fosDirection) {
		this.fosDirection = fosDirection;
	}
	public String getFosDirectionName() {
		return fosDirectionName;
	}
	public void setFosDirectionName(String fosDirectionName) {
		this.fosDirectionName = fosDirectionName;
	}
	public String getFosPortalType() {
		return fosPortalType;
	}
	public void setFosPortalType(String fosPortalType) {
		this.fosPortalType = fosPortalType;
	}
	public String getFosPortalTypeName() {
		return fosPortalTypeName;
	}
	public void setFosPortalTypeName(String fosPortalTypeName) {
		this.fosPortalTypeName = fosPortalTypeName;
	}
	public UUID getTo() {
		return to;
	}
	public void setTo(UUID to) {
		this.to = to;
	}
	public String getToName() {
		return toName;
	}
	public void setToName(String toName) {
		this.toName = toName;
	}
	public UUID getFrom() {
		return from;
	}
	public void setFrom(UUID from) {
		this.from = from;
	}
	public String getFromName() {
		return fromName;
	}
	public void setFromName(String fromName) {
		this.fromName = fromName;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public LocalDateTime getCreatedOn() {
		return createdOn;
	}
	public void setCreatedOn(LocalDateTime createdOn) {
		this.createdOn = createdOn;
	}
	public UUID getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(UUID createdBy) {
		this.createdBy = createdBy;
	}
	public LocalDateTime getOverrideCreatedOn() {
		return overrideCreatedOn;
	}
	public void setOverrideCreatedOn(LocalDateTime overrideCreatedOn) {
		this.overrideCreatedOn = overrideCreatedOn;
	}
	public String getCreatedByName() {
		return createdByName;
	}
	public void setCreatedByName(String createdByName) {
		this.createdByName = createdByName;
	}
	public LocalDateTime getModifiedOn() {
		return modifiedOn;
	}
	public void setModifiedOn(LocalDateTime modifiedOn) {
		this.modifiedOn = modifiedOn;
	}
	public UUID getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(UUID modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public String getModifiedByName() {
		return modifiedByName;
	}
	public void setModifiedByName(String modifiedByName) {
		this.modifiedByName = modifiedByName;
	}
	public UUID getOwningUserId() {
		return owningUserId;
	}
	public void setOwningUserId(UUID owningUserId) {
		this.owningUserId = owningUserId;
	}
	public String getOwningUserIdName() {
		return owningUserIdName;
	}
	public void setOwningUserIdName(String owningUserIdName) {
		this.owningUserIdName = owningUserIdName;
	}
	public long getStateCode() {
		return stateCode;
	}
	public void setStateCode(long stateCode) {
		this.stateCode = stateCode;
	}
	public String getStateCodeName() {
		return stateCodeName;
	}
	public void setStateCodeName(String stateCodeName) {
		this.stateCodeName = stateCodeName;
	}
	public long getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(long statusCode) {
		this.statusCode = statusCode;
	}
	public String getStatusCodeName() {
		return statusCodeName;
	}
	public void setStatusCodeName(String statusCodeName) {
		this.statusCodeName = statusCodeName;
	}
	public long getFosActivityCategory() {
		return fosActivityCategory;
	}
	public void setFosActivityCategory(long fosActivityCategory) {
		this.fosActivityCategory = fosActivityCategory;
	}
	public String getFosActivityCategoryName() {
		return fosActivityCategoryName;
	}
	public void setFosActivityCategoryName(String fosActivityCategoryName) {
		this.fosActivityCategoryName = fosActivityCategoryName;
	}
	public UUID getRegardingObjectId() {
		return regardingObjectId;
	}
	public void setRegardingObjectId(UUID regardingObjectId) {
		this.regardingObjectId = regardingObjectId;
	}
	public String getRegardingObjectIdName() {
		return regardingObjectIdName;
	}
	public void setRegardingObjectIdName(String regardingObjectIdName) {
		this.regardingObjectIdName = regardingObjectIdName;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public LocalDateTime getScheduledStart() {
		return scheduledStart;
	}
	public void setScheduledStart(LocalDateTime scheduledStart) {
		this.scheduledStart = scheduledStart;
	}
	public LocalDateTime getScheduledEnd() {
		return scheduledEnd;
	}
	public void setScheduledEnd(LocalDateTime scheduledEnd) {
		this.scheduledEnd = scheduledEnd;
	}
	public String getFosFromForeFile() {
		return fosFromForeFile;
	}
	public void setFosFromForeFile(String fosFromForeFile) {
		this.fosFromForeFile = fosFromForeFile;
	}
	public String getFosToForeFile() {
		return fosToForeFile;
	}
	public void setFosToForeFile(String fosToForeFile) {
		this.fosToForeFile = fosToForeFile;
	}
	public UUID getMessageSentByDpUserAdOid() {
		return messageSentByDpUserAdOid;
	}
	public void setMessageSentByDpUserAdOid(UUID messageSentByDpUserAdOid) {
		this.messageSentByDpUserAdOid = messageSentByDpUserAdOid;
	}
	public String getMessageSentByDpUserAdName() {
		return messageSentByDpUserAdName;
	}
	public void setMessageSentByDpUserAdName(String messageSentByDpUserAdName) {
		this.messageSentByDpUserAdName = messageSentByDpUserAdName;
	}
	public UUID getIncrementalDataLoadJobAuditId() {
		return incrementalDataLoadJobAuditId;
	}
	public void setIncrementalDataLoadJobAuditId(UUID incrementalDataLoadJobAuditId) {
		this.incrementalDataLoadJobAuditId = incrementalDataLoadJobAuditId;
	}
	public LocalDateTime getDpRecordCreatedOn() {
		return dpRecordCreatedOn;
	}
	public void setDpRecordCreatedOn(LocalDateTime dpRecordCreatedOn) {
		this.dpRecordCreatedOn = dpRecordCreatedOn;
	}
	public LocalDateTime getDpRecordModifiedOn() {
		return dpRecordModifiedOn;
	}
	public void setDpRecordModifiedOn(LocalDateTime dpRecordModifiedOn) {
		this.dpRecordModifiedOn = dpRecordModifiedOn;
	}
	public boolean isUserNotificationSendStatus() {
		return userNotificationSendStatus;
	}
	public void setUserNotificationSendStatus(boolean userNotificationSendStatus) {
		this.userNotificationSendStatus = userNotificationSendStatus;
	}
	

}
