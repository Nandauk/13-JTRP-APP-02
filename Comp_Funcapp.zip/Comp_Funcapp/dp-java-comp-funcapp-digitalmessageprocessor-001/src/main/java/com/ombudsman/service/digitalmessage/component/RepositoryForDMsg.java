package com.ombudsman.service.digitalmessage.component;

import java.util.UUID;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.jdbc.core.JdbcTemplate;

import com.azure.messaging.servicebus.ServiceBusException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.ombudsman.service.digitalmessage.Model.BaseTableDTO;
import com.ombudsman.service.digitalmessage.Model.NotificationRequest;
import com.ombudsman.service.digitalmessage.Model.PhoenixServiceBusMessage;

public class RepositoryForDMsg {
	Logger log = LogManager.getRootLogger();

	public void sendInAppNotificationRepo(NotificationRequest notificationRequest,JdbcTemplate jdbcTemplate) throws JsonProcessingException, InterruptedException, ServiceBusException {

		String sql = "INSERT INTO dp_complainant_user_notification (request_id, user_oid, requesting_activity_name, notification_status_id, message, file_download_url, created_on,created_by, modified_on, modified_by) " +
				"VALUES (?, ?, ?, ?, ?, ?, ?, ?,?,?)";
		Object[] params = new Object[] {
				notificationRequest.getRequestId(),
				notificationRequest.getUserOid(),
				notificationRequest.getRequestingActivityName(),
				notificationRequest.getNotificationStatusId(),
				notificationRequest.getMessage(),
				notificationRequest.getFileDownloadUrl(),
				notificationRequest.getCreatedOn(),
				notificationRequest.getCreatedBy(),
				notificationRequest.getModifiedOn(),
				notificationRequest.getModifiedBy()
		};
		jdbcTemplate.update(sql, params);


	}
	public void updateDpDatabase(PhoenixServiceBusMessage message,JdbcTemplate jdbcTemplate) {
		try {
		    String updateSql = "UPDATE fosdigitalmessages SET userNotificationSendStatus = true WHERE tempDigitalMessageProcessingId = ?";
		    Object[] params = new Object[] { message.getTempDigitalMessageProcessingID() };

		    jdbcTemplate.update(updateSql, params);

		    log.info("Status updated to 'notified' for tempDigitalMessageProcessingId: " + message.getTempDigitalMessageProcessingID());
		} catch (Exception e) {
		    log.error("Error updating DP Database: " + e.getMessage());
		}
	}
	public boolean insertintoBaseTable(PhoenixServiceBusMessage message, JdbcTemplate jdbcTemplate,UUID activity_id) {
		AzureFunctionHelper helper = new AzureFunctionHelper();
		BaseTableDTO baseTableDTO = helper.setValuesToBaseTable(message);

		String sql = "INSERT INTO fosdigitalmessages (activityid, fos_direction, fos_directionname, fos_portaltype, fos_portaltypename, " +
				"\"to\", toname, \"from\", fromname, description, createdon, createdby, overridecreatedon, createdbyname, " +
				"modifiedon, modifiedby, modifiedbyname, owninguserid, owninguseridname, statecode, statecodename, " +
				"statuscode, statuscodename, fos_activitycategory, fos_activitycategoryname, regardingobjectid, regardingobjectidname, " +
				"subject, scheduledstart, scheduledend, fos_fromforefile, fos_toforefile, messagesentbydpuseradoid, " +
				"messagesentbydpuseradname, incrementaldataloadjobauditid, dprecordcreatedon, dprecordmodifiedon, usernotificationsendstatus) " +
				"VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

		Object[] params = new Object[] {
				activity_id,
				baseTableDTO.getFosDirection(),
				baseTableDTO.getFosDirectionName(),
				baseTableDTO.getFosPortalType(),
				baseTableDTO.getFosPortalTypeName(),
				baseTableDTO.getTo(),
				baseTableDTO.getToName(),
				baseTableDTO.getFrom(),
				baseTableDTO.getFromName(),
				baseTableDTO.getDescription(),
				baseTableDTO.getCreatedOn(),
				baseTableDTO.getCreatedBy(),
				baseTableDTO.getOverrideCreatedOn(),
				baseTableDTO.getCreatedByName(),
				baseTableDTO.getModifiedOn(),
				baseTableDTO.getModifiedBy(),
				baseTableDTO.getModifiedByName(),
				baseTableDTO.getOwningUserId(),
				baseTableDTO.getOwningUserIdName(),
				baseTableDTO.getStateCode(),
				baseTableDTO.getStateCodeName(),
				baseTableDTO.getStatusCode(),
				baseTableDTO.getStatusCodeName(),
				baseTableDTO.getFosActivityCategory(),
				baseTableDTO.getFosActivityCategoryName(),
				baseTableDTO.getRegardingObjectId(),
				baseTableDTO.getRegardingObjectIdName(),
				baseTableDTO.getSubject(),
				baseTableDTO.getScheduledStart(),
				baseTableDTO.getScheduledEnd(),
				baseTableDTO.getFosFromForeFile(),
				baseTableDTO.getFosToForeFile(),
				baseTableDTO.getMessageSentByDpUserAdOid(),
				baseTableDTO.getMessageSentByDpUserAdName(),
				baseTableDTO.getIncrementalDataLoadJobAuditId(),
				baseTableDTO.getDpRecordCreatedOn(),
				baseTableDTO.getDpRecordModifiedOn(),
				baseTableDTO.isUserNotificationSendStatus()
		};
		jdbcTemplate.update(sql, params);
		
		log.info("Message inserted Base table successfully.");
		return true;
	}
	public boolean markMessageAsFailed(String tempProcessingid, JdbcTemplate jdbcTemplate) {
		try {
			String sql = "UPDATE dp_phx_digitalmessagesprocessing SET processingstatus = 'Failed' ,modifiedon= current_timestamp WHERE temp_digitalmessageprocessingid = ?";
			Object[] params = new Object[] { tempProcessingid };
			jdbcTemplate.update(sql, params);
			log.info(String.format("Message marked as failed for tempProcessingid is :%s",tempProcessingid));
			return true;
		} catch (Exception e) {
			log.info("Error marking message as failed: " + e.getMessage());
		}
		return false;
	}
	public boolean deleteFromTempTable(String tempProcessingid, JdbcTemplate jdbcTemplate) {
		try {
			String sql = "DELETE FROM dp_phx_digitalmessagesprocessing WHERE temp_digitalmessageprocessingid = ?";
			Object[] params = new Object[] { tempProcessingid };
			jdbcTemplate.update(sql, params);
			log.info("Message deleted from temp table");
			return true;
		} catch (Exception e) {
			log.info("Error deleting message from temp table: " + e.getMessage());
		}
		return false;
	}
	public void updateBaseTableAsNotified(String activityId, JdbcTemplate jdbcTemplate)
	{
		String sql="UPDATE fosdigitalmessages SET  usernotificationsendstatus=1 where activityid=?";
		Object[] params = new Object[] { activityId };
		jdbcTemplate.update(sql, params);
		log.info(String.format("Notification status is updated in the Base Table for activity id  :%s",activityId));
	}
}