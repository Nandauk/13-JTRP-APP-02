package com.ombudsman.service.digitalmessage.component;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.MediaType;
import org.springframework.web.reactive.function.client.WebClient;

import com.ombudsman.service.digitalmessage.Model.SinchModel;
import com.ombudsman.service.digitalmessage.Response.SinchApiResponse;

public class SinchSmsCall {

	private static final String ENPOINT="/compcommunicationservice/compcommunicationservice/v1/communicationservice/sendsms";
	Logger LOG = LogManager.getRootLogger();
	final static String xapiKey=System.getenv("XAPIKEY");
	public SinchApiResponse sendSms(SinchModel smsRequest)
	{
		var response=new SinchApiResponse();
		final String apimURL=System.getenv("APIM_URL")+ENPOINT;
		try {
			response = WebClient.create().post().uri(apimURL).header("X-API-KEY", xapiKey)
					.contentType(MediaType.APPLICATION_JSON).bodyValue(smsRequest)
					.accept(MediaType.APPLICATION_JSON)
					.retrieve()
					.bodyToMono(SinchApiResponse.class).block();
		} catch (Exception e) {
			LOG.error("Exception occured while calling Session API: {} ", e.getMessage());
		}
		return response;

	}

}
