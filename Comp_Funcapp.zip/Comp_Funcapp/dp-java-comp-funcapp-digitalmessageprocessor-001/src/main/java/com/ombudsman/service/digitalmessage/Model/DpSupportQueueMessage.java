package com.ombudsman.service.digitalmessage.Model;

import java.time.LocalDateTime;

public class DpSupportQueueMessage {

    private String tempDigitalMessageProcessingId;
    private String caseReferenceNumberIncidentId;
    private String failedSbMessageId;
    private String source;
    private String errorInfo;
    private String errorDetails;
    private String dateTimeErrorOccurred;
    private String queuename;
    private String funcationAppName;
    private String environment;
  
	public String getQueuename() {
		return queuename;
	}
	public void setQueuename(String queuename) {
		this.queuename = queuename;
	}
	public String getFuncationAppName() {
		return funcationAppName;
	}
	public void setFuncationAppName(String funcationAppName) {
		this.funcationAppName = funcationAppName;
	}
	public String getEnvironment() {
		return environment;
	}
	public void setEnvironment(String environment) {
		this.environment = environment;
	}
	public String getTempDigitalMessageProcessingId() {
		return tempDigitalMessageProcessingId;
	}
	public void setTempDigitalMessageProcessingId(String tempDigitalMessageProcessingId) {
		this.tempDigitalMessageProcessingId = tempDigitalMessageProcessingId;
	}
	public String getCaseReferenceNumberIncidentId() {
		return caseReferenceNumberIncidentId;
	}
	public void setCaseReferenceNumberIncidentId(String caseReferenceNumberIncidentId) {
		this.caseReferenceNumberIncidentId = caseReferenceNumberIncidentId;
	}
	public String getFailedSbMessageId() {
		return failedSbMessageId;
	}
	public void setFailedSbMessageId(String failedSbMessageId) {
		this.failedSbMessageId = failedSbMessageId;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getErrorInfo() {
		return errorInfo;
	}
	public void setErrorInfo(String errorInfo) {
		this.errorInfo = errorInfo;
	}
	public String getErrorDetails() {
		return errorDetails;
	}
	public void setErrorDetails(String errorDetails) {
		this.errorDetails = errorDetails;
	}
	public String getDateTimeErrorOccurred() {
		return dateTimeErrorOccurred;
	}
	public void setDateTimeErrorOccurred(String dateTimeErrorOccurred) {
		this.dateTimeErrorOccurred = dateTimeErrorOccurred;
	}
}
