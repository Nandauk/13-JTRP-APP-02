package com.ombudsman.service.digitalmessage.Model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

public class PortalActivityRequest{

	@JsonProperty("activityid")
	private UUID activityId;
	@JsonProperty("ownerid_fos_digitalmessages@odata.bind")
	private String ownerId;
	@JsonProperty("regardingobjectid_incident_fos_digitalmessages@odata.bind")
	private String regardingObjectIdIncidentFosPortal;
	@JsonProperty("subject")
	private String subject;
	@JsonProperty("fos_direction")
	private Long fosdirection;
	@JsonProperty("description")
	private String description;
	@JsonProperty("fos_portaltype")
	private Long fosportaltype;

	@JsonProperty("statecode")
	private int statecode;
	@JsonProperty("statuscode")
	private int statuscode;

	@JsonProperty("fos_toforefile")
	private String fos_toforefile;
	@JsonProperty("fos_digitalmessages_activity_parties")
	@JsonDeserialize(contentAs = FosPortalActivityParty.class)
	private List<FosPortalActivityParty> fosPortalActivityParties;
/////
	@JsonProperty("createdon")
	private String createdon;
	@JsonProperty("fos_fromforefile")
	private String fos_fromforefile;
	@JsonProperty("fos_activitycategory")
	private Long fos_activitycategory;
	@JsonProperty("scheduledend")
	private String scheduledend;
	public String getCreatedon() {
		return createdon;
	}



	public String getScheduledend() {
		return scheduledend;
	}



	public void setScheduledend(String scheduledend) {
		this.scheduledend = scheduledend;
	}



	public void setCreatedon(String createdon) {
		this.createdon = createdon;
	}



	public String getFos_fromforefile() {
		return fos_fromforefile;
	}



	public void setFos_fromforefile(String fos_fromforefile) {
		this.fos_fromforefile = fos_fromforefile;
	}



	public Long getFos_activitycategory() {
		return fos_activitycategory;
	}



	public void setFos_activitycategory(Long fos_activitycategory) {
		this.fos_activitycategory = fos_activitycategory;
	}



	public List<FosPortalActivityParty> getFosPortalActivityParties() {
		return fosPortalActivityParties;
	}



	public void setFosPortalActivityParties(List<FosPortalActivityParty> fosPortalActivityParties) {
		this.fosPortalActivityParties = fosPortalActivityParties;
	}



	public UUID getActivityId() {
		return activityId;
	}



	public void setActivityId(UUID activityId) {
		this.activityId = activityId;
	}



	public String getOwnerId() {
		return ownerId;
	}



	public void setOwnerId(String ownerId) {
		this.ownerId = ownerId;
	}



	public String getRegardingObjectIdIncidentFosPortal() {
		return regardingObjectIdIncidentFosPortal;
	}



	public void setRegardingObjectIdIncidentFosPortal(String regardingObjectIdIncidentFosPortal) {
		this.regardingObjectIdIncidentFosPortal = regardingObjectIdIncidentFosPortal;
	}



	public String getSubject() {
		return subject;
	}



	public void setSubject(String subject) {
		this.subject = subject;
	}



	public Long getFosdirection() {
		return fosdirection;
	}



	public void setFosdirection(Long fosdirection) {
		this.fosdirection = fosdirection;
	}



	public String getDescription() {
		return description;
	}



	public void setDescription(String description) {
		this.description = description;
	}



	public Long getFosportaltype() {
		return fosportaltype;
	}



	public void setFosportaltype(Long fosportaltype) {
		this.fosportaltype = fosportaltype;
	}





	public int getStatecode() {
		return statecode;
	}



	public void setStatecode(int statecode) {
		this.statecode = statecode;
	}



	public int getStatuscode() {
		return statuscode;
	}



	public void setStatuscode(int statuscode) {
		this.statuscode = statuscode;
	}



	



	public String getFos_toforefile() {
		return fos_toforefile;
	}



	public void setFos_toforefile(String fos_toforefile) {
		this.fos_toforefile = fos_toforefile;
	}



	



	public static class FosPortalActivityParty {

		@JsonProperty("@odata.type")
		private String type;


		@JsonProperty("partyid_systemuser@odata.bind")
		@JsonInclude(com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL)
		private String partyIdSystemUser;

		@JsonInclude(com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL)
		@JsonProperty("partyid_contact@odata.bind")
		private String partyIdContact;

		@JsonProperty("participationtypemask")
		private int participationTypeMask;


		public String getPartyIdContact() {
			return partyIdContact;
		}

		public void setPartyIdContact(String partyIdContact) {
			this.partyIdContact = partyIdContact;
		}

		public String getType() {
			return type;
		}

		public void setType(String type) {
			this.type = type;
		}

		public String getPartyIdSystemUser() {
			return partyIdSystemUser;
		}

		public void setPartyIdSystemUser(String partyIdSystemUser) {
			this.partyIdSystemUser = partyIdSystemUser;
		}

		public int getParticipationTypeMask() {
			return participationTypeMask;
		}

		public void setParticipationTypeMask(int participationTypeMask) {
			this.participationTypeMask = participationTypeMask;
		}




	}
}

