package com.ombudsman.service.digitalmessage.Model;

import java.time.LocalDateTime;
import java.util.UUID;

public class PhoenixServiceBusMessage {

    private UUID tempDigitalMessageProcessingID;
    private UUID tempUILocalDigitalMessageEntryID;
    private Long direction;
    private Long portalType;
    private UUID to;
    private UUID from;
    private String message;
    private LocalDateTime createdOn;
    private String createdBy;
    private LocalDateTime modifiedOn;
    private String modifiedBy;
    private UUID owner;
    private String activityStatus;
    private String statusReason;
    private String category;
    private String regarding;
    private String activityId;
    private String subject;
    private LocalDateTime dueDate;
    private LocalDateTime overrideCreatedOn;
    private String toForEfile;
    private  String userName;
    private UUID messageSentByDpUserAdOid;
    private String messageSentByDpUserAdName; 
    private UUID regardingObjectId;
	private String caseOwnerUserType;
	public String getCaseOwnerUserType() {
		return caseOwnerUserType;
	}
	public void setCaseOwnerUserType(String caseOwnerUserType) {
		this.caseOwnerUserType = caseOwnerUserType;
	}
    public UUID getRegardingObjectId() {
		return regardingObjectId;
	}

	public void setRegardingObjectId(UUID regardingObjectId) {
		this.regardingObjectId = regardingObjectId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}
    public UUID getMessageSentByDpUserAdOid() {
		return messageSentByDpUserAdOid;
	}

	public void setMessageSentByDpUserAdOid(UUID messageSentByDpUserAdOid) {
		this.messageSentByDpUserAdOid = messageSentByDpUserAdOid;
	}

	public String getMessageSentByDpUserAdName() {
		return messageSentByDpUserAdName;
	}

	public void setMessageSentByDpUserAdName(String messageSentByDpUserAdName) {
		this.messageSentByDpUserAdName = messageSentByDpUserAdName;
	}

	public UUID getTempDigitalMessageProcessingID() {
		return tempDigitalMessageProcessingID;
	}

	public void setTempDigitalMessageProcessingID(UUID tempDigitalMessageProcessingID) {
		this.tempDigitalMessageProcessingID = tempDigitalMessageProcessingID;
	}



    public UUID getTempUILocalDigitalMessageEntryID() {
		return tempUILocalDigitalMessageEntryID;
	}

	public void setTempUILocalDigitalMessageEntryID(UUID tempUILocalDigitalMessageEntryID) {
		this.tempUILocalDigitalMessageEntryID = tempUILocalDigitalMessageEntryID;
	}

	public Long getDirection() {
        return direction;
    }

    public void setDirection(Long direction) {
        this.direction = direction;
    }

    public Long getPortalType() {
        return portalType;
    }

    public void setPortalType(Long portalType) {
        this.portalType = portalType;
    }

    public UUID getTo() {
        return to;
    }

    public void setTo(UUID to) {
        this.to = to;
    }

    public UUID getFrom() {
        return from;
    }

    public void setFrom(UUID from) {
        this.from = from;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public LocalDateTime getCreatedOn() {
        return createdOn;
    }

    public void setCreatedOn(LocalDateTime createdOn) {
        this.createdOn = createdOn;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public LocalDateTime getModifiedOn() {
        return modifiedOn;
    }

    public void setModifiedOn(LocalDateTime modifiedOn) {
        this.modifiedOn = modifiedOn;
    }

    public String getModifiedBy() {
        return modifiedBy;
    }

    public void setModifiedBy(String modifiedBy) {
        this.modifiedBy = modifiedBy;
    }

    public UUID getOwner() {
        return owner;
    }

    public void setOwner(UUID owner) {
        this.owner = owner;
    }

    public String getActivityStatus() {
        return activityStatus;
    }

    public void setActivityStatus(String activityStatus) {
        this.activityStatus = activityStatus;
    }

    public String getStatusReason() {
        return statusReason;
    }

    public void setStatusReason(String statusReason) {
        this.statusReason = statusReason;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getRegarding() {
        return regarding;
    }

    public void setRegarding(String regarding) {
        this.regarding = regarding;
    }

    public String getActivityId() {
        return activityId;
    }

    public void setActivityId(String activityId) {
        this.activityId = activityId;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public LocalDateTime getDueDate() {
        return dueDate;
    }

    public void setDueDate(LocalDateTime dueDate) {
        this.dueDate = dueDate;
    }

    public LocalDateTime getOverrideCreatedOn() {
        return overrideCreatedOn;
    }

    public void setOverrideCreatedOn(LocalDateTime overrideCreatedOn) {
        this.overrideCreatedOn = overrideCreatedOn;
    }

    public String getToForEfile() {
        return toForEfile;
    }

    public void setToForEfile(String toForEfile) {
        this.toForEfile = toForEfile;
    }
}
