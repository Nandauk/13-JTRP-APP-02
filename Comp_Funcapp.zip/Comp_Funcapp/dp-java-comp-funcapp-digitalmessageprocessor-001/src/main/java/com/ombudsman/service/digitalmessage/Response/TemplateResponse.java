package com.ombudsman.service.digitalmessage.Response;

import com.google.gson.annotations.SerializedName;

public class TemplateResponse {

 
    private String templateName;

   
    private String categories;


    private String templateId;

    // Getters and Setters
    public String getTemplateName() {
        return templateName;
    }

    public void setTemplateName(String templateName) {
        this.templateName = templateName;
    }

    public String getCategories() {
        return categories;
    }

    public void setCategories(String categories) {
        this.categories = categories;
    }

    public String getTemplateId() {
        return templateId;
    }

    public void setTemplateId(String templateId) {
        this.templateId = templateId;
    }
}
