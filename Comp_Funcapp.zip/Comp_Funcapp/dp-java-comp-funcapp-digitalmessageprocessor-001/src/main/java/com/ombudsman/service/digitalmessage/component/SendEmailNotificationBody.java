package com.ombudsman.service.digitalmessage.component;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONException;
import org.springframework.http.MediaType;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.WebClient;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.ombudsman.service.digitalmessage.Model.From;
import com.ombudsman.service.digitalmessage.Model.MailjetVariables;
import com.ombudsman.service.digitalmessage.Model.Messages;
import com.ombudsman.service.digitalmessage.Model.SendMailReq;
import com.ombudsman.service.digitalmessage.Model.To;
import com.ombudsman.service.digitalmessage.Model.UserMailjetRequest;
import com.ombudsman.service.digitalmessage.Response.GenericResponse;
import com.ombudsman.service.digitalmessage.Response.MailjetResponseBody;
import com.ombudsman.service.digitalmessage.exception.MailJetServiceException;


public class SendEmailNotificationBody {

	private static final boolean TRUE = true;
	private static final String URI = "/mailjet/send";
	private static final String SUCCESS = "success";
	private static final String SENDEREMAIL = System.getenv("SENDEREMAIL");
	
	Logger log = LogManager.getRootLogger();
	public GenericResponse  requestEmailBody(UserMailjetRequest incomingRequest, long templateId) throws JsonProcessingException {
		String SENDERNAME = System.getenv("SENDERNAME");
		GenericResponse responseMessage = new GenericResponse();
		List<To> to = new ArrayList<>();
		To toEmailAddress = new To();
		toEmailAddress.setEmail(incomingRequest.getEmailId());
		toEmailAddress.setName(incomingRequest.getConsumerName());
		to.add(toEmailAddress);

		Messages message = new Messages();
		message.setTemplateID((Long)(templateId));
		message.setTemplateLanguage(TRUE);
		message.setTo(to);

		From fromEmailAddress = new From();
		fromEmailAddress.setEmail(SENDEREMAIL);
		fromEmailAddress.setName(SENDERNAME.replaceAll("'", ""));
		message.setFrom(fromEmailAddress);

		MailjetVariables var = new MailjetVariables();
		setIfNotEmpty(incomingRequest.getConsumerName(), var::setPortal_User);
		setIfNotEmpty(incomingRequest.getSignInUrl(),  var::setSign_In);
		message.setVariables(var);
		SendMailReq sendMailReq = new SendMailReq();
		List<Messages> sendMessage = new ArrayList<>();
		sendMessage.add(message);
		sendMailReq.setMessages(sendMessage);
		String response = send(sendMailReq);
		log.info(String.format("sendMailReq response %s", response));
		if (response.equals(SUCCESS)) {
			responseMessage.setMessage(String.format("MailJet API call success : %s", response));
		} else {
			responseMessage.setMessage(String.format("MailJet API call failed : %s" + response));
		}
		log.info("SendMailReq code  ended ");
		return responseMessage;

	}

	public void setIfNotEmpty(String variableValue, Consumer<String> setter) {
		if (!StringUtils.trimToEmpty(variableValue).isEmpty()) {
			setter.accept(variableValue);
		}
	}
	public String send(SendMailReq req) throws JSONException {
		log.info("Mailjet Send request method started");
		Gson gson = new Gson();
		String json = gson.toJson(req);
		MailjetResponseBody responseBody = new MailjetResponseBody();
		String status = null;
		log.info(String.format("Request data for Send API %s", json));
		String url = System.getenv("APIM_URL") + URI;
		log.info(String.format("Send API Url : %s", url));

		try {
			responseBody = WebClient.create().post().uri(url).body(BodyInserters.fromValue(json))
					.accept(MediaType.APPLICATION_JSON).retrieve().bodyToMono(MailjetResponseBody.class).block();


		} catch (Exception ex) {
			log.error(String.format("Webclient call failed %s", ex.getMessage()));
			throw new MailJetServiceException("Mailjet Exception occured %s", ex.getMessage(), ex.getStackTrace());
		}

		log.info(String.format("Response : %s", responseBody));
		if (null != responseBody) {
			status = responseBody.getMessages().get(0).getStatus();
		}

		return status;

	}
}