package com.ombudsman.service.digitalmessage.Model;

public class UserMailjetRequest {


	private String emailId;

	private String consumerName;

	private String signInUrl;

	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getConsumerName() {
		return consumerName;
	}
	public void setConsumerName(String consumerName) {
		this.consumerName = consumerName;
	}


	public String getSignInUrl() {
		return signInUrl;
	}
	public void setSignInUrl(String signInUrl) {
		this.signInUrl = signInUrl;
	}


}
