package com.ombudsman.service.digitalmessage;

import java.beans.Transient;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.microsoft.azure.functions.ExecutionContext;
import com.microsoft.azure.functions.OutputBinding;
import com.microsoft.azure.functions.annotation.BindingName;
import com.microsoft.azure.functions.annotation.FunctionName;
import com.microsoft.azure.functions.annotation.ServiceBusQueueOutput;
import com.microsoft.azure.functions.annotation.ServiceBusQueueTrigger;
import com.ombudsman.service.digitalmessage.Model.DpSupportQueueMessage;
import com.ombudsman.service.digitalmessage.Model.NotificationRequest;
import com.ombudsman.service.digitalmessage.Model.PhoenixAuditId;
import com.ombudsman.service.digitalmessage.Model.PhoenixServiceBusMessage;
import com.ombudsman.service.digitalmessage.Model.PortalActivityRequest;
import com.ombudsman.service.digitalmessage.Model.SinchModel;
import com.ombudsman.service.digitalmessage.Model.UserMailjetRequest;
import com.ombudsman.service.digitalmessage.Response.SinchApiResponse;
import com.ombudsman.service.digitalmessage.component.PhxSetter;
import com.ombudsman.service.digitalmessage.component.RepositoryForDMsg;
import com.ombudsman.service.digitalmessage.component.RetryForFailurecases;
import com.ombudsman.service.digitalmessage.component.SendDpSupportMail;
import com.ombudsman.service.digitalmessage.component.SendEmailNotificationBody;
import com.ombudsman.service.digitalmessage.component.SinchSmsCall;
import com.ombudsman.service.digitalmessage.exception.MessageSaveException;
import com.ombudsman.service.digitalmessage.serviceimpl.PhoenixProcessorImpl;
public class DigitalMessageAzureFunction {

	private static final String SIGNIN_URL=System.getenv("SIGNIN_URL");
	private static final String TEMPLATE_ID=System.getenv("TEMPATE_ID");
	private static final int MAX_RETRIES = 3;
	private static final String REQUEST_NAME="conversationMessage";
	private static final String FOS="Financial Ombudsman Service";
	private static final String QUEUNE_NAME=System.getenv("QUEUNE_NAME");
	private static final String FUNCTIONAPP_NAME=System.getenv("FUNCTIONAPP_NAME");
	private static final String ENVIRONMENT=System.getenv("ENVIRONMENT");

	Logger log = LogManager.getRootLogger();
	final JdbcTemplate jdbcTemplate = jdbcConnection();
	RepositoryForDMsg repositoryForDMsg;
	private JdbcTemplate jdbcConnection() {
		JdbcTemplate jdbcTemplateConn;
		DriverManagerDataSource dataSource = new DriverManagerDataSource();
		dataSource.setDriverClassName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
		dataSource.setUrl(System.getenv("SQL_SERVER_URL"));
		dataSource.setUsername(System.getenv("SQL_SERVER_USERNAME"));
		dataSource.setPassword(System.getenv("SQL_SERVER_PWD"));
		jdbcTemplateConn = new JdbcTemplate(dataSource);
		return jdbcTemplateConn;
	}
	PhoenixProcessorImpl phoenixProcessorImpl = new PhoenixProcessorImpl();
	@FunctionName("OutgoingMsgFromCpToPhx")
	@Transient(true)
	public void processDigitalMessagetoPhx(
			@ServiceBusQueueTrigger(name = "message", queueName = "%SendingMessageToPhx%", connection = "AzureWebJobsServiceBus") String messageFromMs,@BindingName("MessageId") String messageId,
			@ServiceBusQueueOutput(name = "outputMessage", queueName = "%DPSupportQueue%", connection = "AzureWebJobsServiceBus") OutputBinding<String> outputMessage,
			final ExecutionContext context) throws JsonMappingException, JsonProcessingException {

		log.info(String.format("Incoming message from Digital messagaging Service :%s",messageFromMs));
		ObjectMapper mapper=new ObjectMapper();
		mapper.registerModule(new JavaTimeModule());
		PhoenixServiceBusMessage messageSB=mapper.readValue(messageFromMs, PhoenixServiceBusMessage.class);
		String temprocessingMessageid = messageSB.getTempDigitalMessageProcessingID().toString();
		PhxSetter phxSetter=new PhxSetter();
		PortalActivityRequest phxModel = phxSetter.settingValues(messageSB);
		RepositoryForDMsg repositoryForDMsg=new RepositoryForDMsg();
		String messageIdOfQueue=messageId;
		RetryForFailurecases retryCases=new RetryForFailurecases();
		try {
			int phoenixUpdateSuccess = retryCases.retryPhxcall(phxModel);
			log.info(String.format("Pnx status code  :%d",phoenixUpdateSuccess));
			if (phoenixUpdateSuccess==204|| phoenixUpdateSuccess==200) {
				log.info("Message is successfully inserted into Phoenix");
				boolean baseStatus=retryCases.retryInsertBaseTable(messageSB,jdbcTemplate,phxModel.getActivityId());
				if(baseStatus)
				{
					retryCases.retryDeleteTempTable(temprocessingMessageid,jdbcTemplate);
					log.info("Message processed successfully Inserted into Phoenix and Deleted from the Temp Table.");
				}
			}
			else	
			{
				log.info("The message is failed to reach Phoenix");
				retryCases.retryMarkAsfailed(temprocessingMessageid, jdbcTemplate);
				log.info("The message is failed to reach Phoenix and marked as failed in base table");
				DpSupportQueueMessage supportDp=new DpSupportQueueMessage();
				supportDp.setCaseReferenceNumberIncidentId(messageSB.getRegardingObjectId().toString());
				supportDp.setTempDigitalMessageProcessingId(temprocessingMessageid);
				supportDp.setDateTimeErrorOccurred(getutcTime().toString());
				supportDp.setErrorDetails("Something Wrong in Incoming data from CP input message from Complainant to Phoenix,The Message Body is :"+messageFromMs);
				supportDp.setFailedSbMessageId(messageIdOfQueue);
				supportDp.setErrorInfo("Mismatch values");
				supportDp.setFuncationAppName(FUNCTIONAPP_NAME);
				supportDp.setQueuename(QUEUNE_NAME);
				supportDp.setEnvironment(ENVIRONMENT);
				log.info(String.format("the message body to support queue is: %s", converterOfObjecttoString(supportDp)));
				outputMessage.setValue(converterOfObjecttoString(supportDp));
				log.info("The message is posted in Dp support queue");

			}

		}
		catch (Exception e) {
			repositoryForDMsg.markMessageAsFailed(temprocessingMessageid, jdbcTemplate);
			DpSupportQueueMessage supportDp=new DpSupportQueueMessage();
			supportDp.setCaseReferenceNumberIncidentId(messageSB.getRegardingObjectId().toString());
			supportDp.setTempDigitalMessageProcessingId(temprocessingMessageid);
			supportDp.setDateTimeErrorOccurred(getutcTime().toString());
			supportDp.setErrorDetails(e.getMessage());
			supportDp.setFailedSbMessageId(messageIdOfQueue);
			if(null !=e.getClass().getName())
			{
				supportDp.setErrorInfo(e.getClass().getName());
			}
			supportDp.setFuncationAppName(FUNCTIONAPP_NAME);
			supportDp.setQueuename(QUEUNE_NAME);
			supportDp.setEnvironment(ENVIRONMENT);
			outputMessage.setValue(converterOfObjecttoString(supportDp));
			log.info(String.format("The message pushed into  Dp Suppport Queue.%s",converterOfObjecttoString(supportDp)));
			throw new MessageSaveException("Failed to save message after " + MAX_RETRIES + " attempts");
		}

	}
	@FunctionName("NotifyComplainantsNewMsg")
	@Transient(true)
	public void processNotification(
			@ServiceBusQueueTrigger(name = "message", queueName = "%NotifyNewMessageQueue%", connection = "AzureWebJobsServiceBus") String message,
			final ExecutionContext context)throws InterruptedException {
		log.info("Incoming message from Phoenix:" + message);
		RepositoryForDMsg repository=new RepositoryForDMsg();
		RepositoryForDMsg repositoryForDMsg=new RepositoryForDMsg();
		Long templateId=Long.parseLong(TEMPLATE_ID);
		String smsrequestBody=System.getenv("SMSBODY");
		try {
			ObjectMapper mapper=new ObjectMapper();
			PhoenixAuditId phoenixAuditId=mapper.readValue(message, PhoenixAuditId.class);
			String auditId=phoenixAuditId.getAuditid();
			if(auditId!=null)
			{

				Map<String,Object> userDetails = querySP(auditId);
				List<Map<String,String>>listOfDetails=(List<Map<String, String>>) userDetails.get("#result-set-1");
				log.info(String.format("The values retrived for the Audit id :%s and the value are :%s", message,listOfDetails.toString()));
				if(!listOfDetails.isEmpty())
				{
					for(Map<String, String> userValues:listOfDetails)
					{
						NotificationRequest getNotification = sendInAppNotification(userValues.get("oid"), userValues.get("caseRefNumber") );
						repository.sendInAppNotificationRepo(getNotification,jdbcTemplate);
						log.info("In-App Notification is sent to the user:{} : " +userValues.get("oid"));
						boolean actionSession=Boolean.valueOf(userValues.get("userActiveSessionStatus"));
						log.info(String.format("The user active Session status for UserOid :%s and the Session Status is :%b", userValues.get("oid"),actionSession));
						if(!actionSession) {
							String modeofcommunictaion=userValues.get("comPref");
							if ("phone".equalsIgnoreCase(modeofcommunictaion)) {
								if(!StringUtils.isEmpty(userValues.get("phone")))
								{
									
									SinchModel smsBody=new SinchModel();
//									smsBody.setFrom("Ombudsman");
									smsBody.setTo(List.of(userValues.get("phone")));
									smsBody.setBody(smsrequestBody.replaceAll("\\\\n", "\n"));
									log.info(String.format("The request body for sinch: %s", converterOfObjecttoString(smsBody)));
									SinchSmsCall smsCall=new SinchSmsCall();
									SinchApiResponse response = smsCall.sendSms(smsBody);
									log.info(String.format("The response body from sinch: %s", converterOfObjecttoString(response)));
									log.info("SMS Notification is sent to the user:{} : " +userValues.get("oid"));
								}
								else
								{
									log.info(String.format("Phone is Null for the useroid: %s",userValues.get("oid")));

								}
								
							} else {
								SendEmailNotificationBody sendEmail = new SendEmailNotificationBody();
								UserMailjetRequest incomingDocumentEmailModel = new UserMailjetRequest();
								incomingDocumentEmailModel.setConsumerName(userValues.get("first_name"));
								incomingDocumentEmailModel.setEmailId(userValues.get("contactEmailAddress"));
								incomingDocumentEmailModel.setSignInUrl(SIGNIN_URL);
								log.info("The Message body passed to the send mail method:{}" +converterOfObjecttoString(incomingDocumentEmailModel));
								sendEmail.requestEmailBody(incomingDocumentEmailModel, templateId);
								log.info(String.format("The Email Notification is sent UserOid :%s",userValues.get("oid") ));

							}
						}
						repositoryForDMsg.updateBaseTableAsNotified(userValues.get("activityid"), jdbcTemplate);
					}
				}

			}

		} 
		catch (InterruptedException ie) {
			log.error("InterruptedException: ", ie);
			Thread.currentThread().interrupt();
		} catch (Exception e) {
			log.info("Error processing notification: " + e.getMessage());
			throw new RuntimeException("Failed to process notification", e);
		}

	}
	@FunctionName("notifyDpSupport")
	@Transient(true)
	public void notifyDpSupport(
			@ServiceBusQueueTrigger(name = "message", queueName = "%DPSupportQueue%", connection = "AzureWebJobsServiceBus") String message,
			final ExecutionContext context)throws InterruptedException {
		try
		{
			ObjectMapper mapper=new ObjectMapper();
			DpSupportQueueMessage dpQueue=mapper.readValue(message, DpSupportQueueMessage.class);
			SendDpSupportMail supportmai=new SendDpSupportMail();
			supportmai.sendErrorNotification(dpQueue);
		}
		catch(Exception e)
		{
			log.info("Error sending notification Dp Support team: " + e.getMessage());
			throw new RuntimeException("Error sending notification Dp Support team", e);
		}
	}
	public NotificationRequest sendInAppNotification(String userId, String caseRef) {
		NotificationRequest notification = new NotificationRequest();
		notification.setRequestId(UUID.randomUUID().toString());
		notification.setUserOid(userId);
		notification.setRequestingActivityName(REQUEST_NAME);
		notification.setNotificationStatusId(1);
		notification.setMessage(caseRef+":conversationMessage");
		notification.setFileDownloadUrl(null);
		notification.setCreatedBy(FOS);
		notification.setCreatedOn(getutcTime());
		notification.setModifiedOn(null);
		notification.setModifiedBy(null);
		return notification;
	}
	private String converterOfObjecttoString(Object objectToConvert) throws JsonProcessingException
	{
		ObjectMapper mapper=new ObjectMapper();
		mapper.registerModule(new JavaTimeModule());
		return mapper.writeValueAsString(objectToConvert);
	}
	private Map<String, Object> querySP(String incrementalJobId)
	{
		SimpleJdbcCall jdbcCall=new SimpleJdbcCall(jdbcTemplate).withProcedureName("prc_getQualifiedNotificationRecordsForDigitalMessaging");
		MapSqlParameterSource inparams=new MapSqlParameterSource()
				.addValue("jobauditid", incrementalJobId);

		return jdbcCall.execute(inparams);
	}
	private LocalDateTime getutcTime()
	{
		ZonedDateTime utcTime=ZonedDateTime.now(ZoneOffset.UTC);
		LocalDateTime createdon=utcTime.toLocalDateTime();
		return createdon;
	}

}
