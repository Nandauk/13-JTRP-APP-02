package com.ombudsman.service.digitalmessage.service;

public interface PhoenixProcessor {
	public int createRecordPhnx( String entity,String jsonBody);	
}
