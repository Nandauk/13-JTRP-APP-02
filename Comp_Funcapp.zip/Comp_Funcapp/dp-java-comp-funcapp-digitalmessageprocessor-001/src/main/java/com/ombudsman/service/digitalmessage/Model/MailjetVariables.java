package com.ombudsman.service.digitalmessage.Model;


import com.google.gson.annotations.SerializedName;


public class MailjetVariables {

	@SerializedName("portal_User")
	private String portal_User;

	@SerializedName("sign_In")
	private String sign_In;

	public String getPortal_User() {
		return portal_User;
	}

	public void setPortal_User(String portal_User) {
		this.portal_User = portal_User;
	}

	public String getSign_In() {
		return sign_In;
	}

	public void setSign_In(String sign_In) {
		this.sign_In = sign_In;
	}

	
}

