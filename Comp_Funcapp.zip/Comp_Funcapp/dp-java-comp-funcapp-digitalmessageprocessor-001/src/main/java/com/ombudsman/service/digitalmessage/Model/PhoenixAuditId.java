package com.ombudsman.service.digitalmessage.Model;

public class PhoenixAuditId {
	private String auditid;

	public String getAuditid() {
		return auditid;
	}

	public void setAuditid(String auditid) {
		this.auditid = auditid;
	}

}
