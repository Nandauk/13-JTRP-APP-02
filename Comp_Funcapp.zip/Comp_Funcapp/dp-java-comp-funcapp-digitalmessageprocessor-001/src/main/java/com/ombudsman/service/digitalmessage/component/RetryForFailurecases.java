package com.ombudsman.service.digitalmessage.component;

import java.util.UUID;
import java.util.concurrent.TimeUnit;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.jdbc.core.JdbcTemplate;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.ombudsman.service.digitalmessage.Model.PhoenixServiceBusMessage;
import com.ombudsman.service.digitalmessage.Model.PortalActivityRequest;
import com.ombudsman.service.digitalmessage.exception.MessageSaveException;
import com.ombudsman.service.digitalmessage.exception.PhoenixServiceException;
import com.ombudsman.service.digitalmessage.serviceimpl.PhoenixProcessorImpl;

public class RetryForFailurecases {

	private static final int MAX_RETRIES = 3;
	private static final int[] RETRY_INTERVALS = {1,3,3};
	private static final String ENITY_NAME=System.getenv("ENITY_NAME");
	Logger log = LogManager.getRootLogger();
	PhoenixProcessorImpl phoenixProcessorImpl = new PhoenixProcessorImpl();
	public int retryPhxcall(PortalActivityRequest phxModel)
	{
		int attempt = -1;
		while (attempt < MAX_RETRIES) {
			try
			{
				log.info(String.format("The message body sent to phx:%s", converterOfObjecttoString(phxModel)));
				int phoenixUpdateSuccess = phoenixProcessorImpl.createRecordPhnx(ENITY_NAME,converterOfObjecttoString(phxModel));				
				return phoenixUpdateSuccess;
			}
			catch(Exception e) {
				log.error("Error saving message. Attempt: {}", attempt + 1, e);
				attempt++;
				if (attempt >= MAX_RETRIES) {
					log.error("Error to connect with phoenix after maximum retry attempt failed",e.toString());
					throw new PhoenixServiceException("Error to connect with phoenix after maximum retry attempt failed",e.toString());
				}
				sleepBeforeRetry(attempt);
			}

		}
		return 0;
	}
	public boolean  retryInsertBaseTable(PhoenixServiceBusMessage messageSB,JdbcTemplate jdbcTemplate,UUID activityId)
	{
		int attempt = -1;
		RepositoryForDMsg repositoryForDMsg=new RepositoryForDMsg();
		while (attempt < MAX_RETRIES) {
			try
			{
				return repositoryForDMsg.insertintoBaseTable(messageSB,jdbcTemplate,activityId);

			}
			catch(Exception e) {
				log.error("Error saving message. Attempt: {}", attempt + 1, e);
				attempt++;
				if (attempt >= MAX_RETRIES) {
					log.error("Error to connect with DB after maximum retry attempt failed",e.toString());
					throw new MessageSaveException("Error to connect with DB after maximum retry attempt failed");
				}
				sleepBeforeRetry(attempt);
			}
			
		}
		return false;
	}
	public boolean  retryDeleteTempTable(String temprocessingMessageid,JdbcTemplate jdbcTemplate)
	{
		int attempt = -1;
		RepositoryForDMsg repositoryForDMsg=new RepositoryForDMsg();
		while (attempt < MAX_RETRIES) {
			try
			{
				return repositoryForDMsg.deleteFromTempTable(temprocessingMessageid,jdbcTemplate);

			}
			catch(Exception e) {
				log.error("Error saving message. Attempt: {}", attempt + 1, e);
				attempt++;
				if (attempt >= MAX_RETRIES) {
					log.error("Error to connect to DB after maximum retry attempt failed for Delete in Temp Table",e.toString());
					throw new MessageSaveException("Error to connect to DB after maximum retry attempt failed for Delete in Temp Table");
				}
				sleepBeforeRetry(attempt);
			}
			
		}
		return false;
	}
	public boolean  retryMarkAsfailed(String temprocessingMessageid,JdbcTemplate jdbcTemplate)
	{
		int attempt = -1;
		RepositoryForDMsg repositoryForDMsg=new RepositoryForDMsg();
		while (attempt < MAX_RETRIES) {
			try
			{
				return repositoryForDMsg.markMessageAsFailed(temprocessingMessageid,jdbcTemplate);

			}
			catch(Exception e) {
				log.error("Error saving message. Attempt: {}", attempt + 1, e);
				attempt++;
				if (attempt >= MAX_RETRIES) {
					log.error("Error to connect to DB after maximum retry attempt failed for Mark message in Temp as Failed",e.toString());
					throw new MessageSaveException("");
				}
				sleepBeforeRetry(attempt);
			}
			
		}
		return false;
	}
	private void sleepBeforeRetry(int attempt) {
		try {
			TimeUnit.MINUTES.sleep(RETRY_INTERVALS[attempt]);
		} catch (InterruptedException ie) {
			Thread.currentThread().interrupt();
			throw new RuntimeException("Thread interrupted during retry delay", ie);
		}
	}
	private String converterOfObjecttoString(Object objectToConvert) throws JsonProcessingException
	{
		ObjectMapper mapper=new ObjectMapper();
		mapper.registerModule(new JavaTimeModule());
		return mapper.writeValueAsString(objectToConvert);
	}
}
