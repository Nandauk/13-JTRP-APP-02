package com.ombudsman.service.digitalmessage.Model;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class UserMailjetRequestTest {

    private UserMailjetRequest userMailjetRequest;

    @BeforeEach
    void setUp() {
        // Initialize a new UserMailjetRequest object before each test
        userMailjetRequest = new UserMailjetRequest();
    }

    @Test
    void testSetAndGetEmailId() {
        // Arrange
        String testEmailId = "test@example.com";

        // Act
        userMailjetRequest.setEmailId(testEmailId);

        // Assert
        assertEquals(testEmailId, userMailjetRequest.getEmailId());
    }

    @Test
    void testSetAndGetEmailIdWithNull() {
        // Act
        userMailjetRequest.setEmailId(null);

        // Assert
        assertNull(userMailjetRequest.getEmailId());
    }

    @Test
    void testSetAndGetConsumerName() {
        // Arrange
        String testConsumerName = "John Doe";

        // Act
        userMailjetRequest.setConsumerName(testConsumerName);

        // Assert
        assertEquals(testConsumerName, userMailjetRequest.getConsumerName());
    }

    @Test
    void testSetAndGetConsumerNameWithNull() {
        // Act
        userMailjetRequest.setConsumerName(null);

        // Assert
        assertNull(userMailjetRequest.getConsumerName());
    }

    @Test
    void testSetAndGetSignInUrl() {
        // Arrange
        String testSignInUrl = "https://example.com/signin";

        // Act
        userMailjetRequest.setSignInUrl(testSignInUrl);

        // Assert
        assertEquals(testSignInUrl, userMailjetRequest.getSignInUrl());
    }

    @Test
    void testSetAndGetSignInUrlWithNull() {
        // Act
        userMailjetRequest.setSignInUrl(null);

        // Assert
        assertNull(userMailjetRequest.getSignInUrl());
    }

    @Test
    void testFullObjectCreation() {
        // Arrange
        String testEmailId = "test@example.com";
        String testConsumerName = "John Doe";
        String testSignInUrl = "https://example.com/signin";

        // Act
        userMailjetRequest.setEmailId(testEmailId);
        userMailjetRequest.setConsumerName(testConsumerName);
        userMailjetRequest.setSignInUrl(testSignInUrl);

        // Assert
        assertEquals(testEmailId, userMailjetRequest.getEmailId());
        assertEquals(testConsumerName, userMailjetRequest.getConsumerName());
        assertEquals(testSignInUrl, userMailjetRequest.getSignInUrl());
    }

    @Test
    void testDefaultConstructor() {
        // Arrange & Act
        UserMailjetRequest defaultRequest = new UserMailjetRequest();

        // Assert
        assertNull(defaultRequest.getEmailId());
        assertNull(defaultRequest.getConsumerName());
        assertNull(defaultRequest.getSignInUrl());
    }

    @Test
    void testSettersWithEmptyStrings() {
        // Arrange
        String emptyString = "";

        // Act
        userMailjetRequest.setEmailId(emptyString);
        userMailjetRequest.setConsumerName(emptyString);
        userMailjetRequest.setSignInUrl(emptyString);

        // Assert
        assertEquals(emptyString, userMailjetRequest.getEmailId());
        assertEquals(emptyString, userMailjetRequest.getConsumerName());
        assertEquals(emptyString, userMailjetRequest.getSignInUrl());
    }

    @Test
    void testSettersWithWhitespaceStrings() {
        // Arrange
        String whitespaceString = "   ";

        // Act
        userMailjetRequest.setEmailId(whitespaceString);
        userMailjetRequest.setConsumerName(whitespaceString);
        userMailjetRequest.setSignInUrl(whitespaceString);

        // Assert
        assertEquals(whitespaceString, userMailjetRequest.getEmailId());
        assertEquals(whitespaceString, userMailjetRequest.getConsumerName());
        assertEquals(whitespaceString, userMailjetRequest.getSignInUrl());
    }
}