package com.ombudsman.service.digitalmessage.component;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.lang.reflect.Method;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

import com.ombudsman.service.digitalmessage.Model.PhoenixServiceBusMessage;
import com.ombudsman.service.digitalmessage.Model.PortalActivityRequest;
import com.ombudsman.service.digitalmessage.serviceimpl.PhoenixProcessorImpl;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.jdbc.core.JdbcTemplate;
import org.apache.logging.log4j.Logger;

@ExtendWith(MockitoExtension.class)
class RetryForFailurecasesTest {

    @Mock
    private PhoenixProcessorImpl phoenixProcessorImpl;

    @Mock
    private RepositoryForDMsg repositoryForDMsg;

    @Mock
    private JdbcTemplate jdbcTemplate;

    @Mock
    private Logger log;

    @InjectMocks
    private RetryForFailurecases retryComponent;

    private PortalActivityRequest phxModel;
    private PhoenixServiceBusMessage messageSB;
    private UUID activityId;
    private String tempMessageId;

    @BeforeEach
    void setUp() {
        phxModel = new PortalActivityRequest();
        messageSB = new PhoenixServiceBusMessage();
        activityId = UUID.randomUUID();
        tempMessageId = "TEMP-12345";
    }

    // Test for sleepBeforeRetry method using reflection
    @Test
    void testSleepBeforeRetry() throws Exception {
        // Get the private method using reflection
        Method sleepMethod = RetryForFailurecases.class.getDeclaredMethod("sleepBeforeRetry", int.class);
        sleepMethod.setAccessible(true);
        
        // Test with first attempt (should sleep for 1 minute)
        long startTime = System.currentTimeMillis();
        sleepMethod.invoke(retryComponent, 0);
        long duration = System.currentTimeMillis() - startTime;
        
        // Verify it slept approximately 1 minute (with some tolerance)
        assertTrue(duration >= TimeUnit.MINUTES.toMillis(1) - 100 && 
                  duration <= TimeUnit.MINUTES.toMillis(1) + 100);
    }

    
}