package com.ombudsman.service.digitalmessage.Response;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

public class TemplateResponseTest {

    @Test
    void testTemplateResponseSettersAndGetters() {
        TemplateResponse response = new TemplateResponse();

        String templateName = "WelcomeTemplate";
        String categories = "Notification";
        String templateId = "12345";

        response.setTemplateName(templateName);
        response.setCategories(categories);
        response.setTemplateId(templateId);

        assertEquals(templateName, response.getTemplateName());
        assertEquals(categories, response.getCategories());
        assertEquals(templateId, response.getTemplateId());
    }
}
