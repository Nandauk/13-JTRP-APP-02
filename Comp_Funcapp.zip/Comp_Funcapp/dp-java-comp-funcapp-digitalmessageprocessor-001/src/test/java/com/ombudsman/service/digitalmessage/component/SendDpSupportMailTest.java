//package com.ombudsman.service.digitalmessage.component;
//
//import com.ombudsman.service.digitalmessage.Model.DpSupportQueueMessage;
//import com.ombudsman.service.digitalmessage.Response.MailjetResponseBody;
//import org.junit.jupiter.api.BeforeEach;
//import org.junit.jupiter.api.Test;
//import org.mockito.MockedStatic;
//import org.springframework.http.MediaType;
//import org.springframework.web.reactive.function.BodyInserter;
//import org.springframework.web.reactive.function.client.*;
//
//import reactor.core.publisher.Mono;
//
//import java.time.LocalDateTime;
//
//import static org.mockito.Mockito.*;
//
//public class SendDpSupportMailTest {
//
//    private SendDpSupportMail sendDpSupportMail;
//
//    @BeforeEach
//    public void setup() {
//        sendDpSupportMail = new SendDpSupportMail();
//    }
//
//    @Test
//    public void testSendErrorNotification_withMockedWebClient() {
//        // Arrange
//        DpSupportQueueMessage message = new DpSupportQueueMessage();
//        message.setTempDigitalMessageProcessingId("TEMP123");
//        message.setCaseReferenceNumberIncidentId("CASE456");
//        message.setFailedSbMessageId("MSG789");
//        message.setFuncationAppName("FunctionApp");
//        message.setErrorInfo("Some error info");
//        message.setQueuename("QueueName");
//        message.setEnvironment("Test");
//        message.setDateTimeErrorOccurred(LocalDateTime.now().toString());
//        message.setErrorDetails("Detailed error message");
//
//        // Mock WebClient chain
//        WebClient webClient = mock(WebClient.class);
//        WebClient.RequestBodyUriSpec uriSpec = mock(WebClient.RequestBodyUriSpec.class);
//        WebClient.RequestBodySpec bodySpec = mock(WebClient.RequestBodySpec.class);
//        WebClient.ResponseSpec responseSpec = mock(WebClient.ResponseSpec.class);
//
//        when(webClient.post()).thenReturn(uriSpec);
//        when(uriSpec.uri(anyString())).thenReturn(bodySpec);
//        when(bodySpec.body(any(BodyInserter.class))).thenReturn(bodySpec);
//        when(bodySpec.accept(any())).thenReturn(bodySpec);
//        when(bodySpec.retrieve()).thenReturn(responseSpec);
//        when(responseSpec.bodyToMono(MailjetResponseBody.class)).thenReturn(Mono.just(new MailjetResponseBody()));
//
//        // Mock WebClient.create() using static mocking
//        try (MockedStatic<WebClient> webClientStatic = mockStatic(WebClient.class)) {
//            webClientStatic.when(WebClient::create).thenReturn(webClient);
//
//            // Act
//            sendDpSupportMail.sendErrorNotification(message);
//
//            // Assert
//            verify(webClient, times(1)).post();
//            verify(uriSpec, times(1)).uri(contains("/mailjet/send"));
//            verify(bodySpec, times(1)).body(any(BodyInserter.class));
//            verify(bodySpec, times(1)).accept(MediaType.APPLICATION_JSON);
//            verify(bodySpec, times(1)).retrieve();
//            verify(responseSpec, times(1)).bodyToMono(MailjetResponseBody.class);
//        }
//    }
//}
