package com.ombudsman.service.digitalmessage.exception;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

public class ServiceExceptionsTest {

    @Test
    void testServiceExceptionsConstructorAndGetters() {
        String expectedMessage = "Test error message";
        String expectedCode = "ERROR_CODE";

        ServiceExceptions exception = new ServiceExceptions(expectedMessage, expectedCode);

        assertEquals(expectedMessage, exception.getMessage());
        assertEquals(expectedCode, exception.getCode());
    }
}
