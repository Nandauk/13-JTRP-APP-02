package com.ombudsman.service.digitalmessage.Model;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;
import static org.junit.jupiter.api.Assertions.*;
import java.time.LocalDateTime;

class NotificationRequestTest {

    private NotificationRequest notificationRequest;

    @BeforeEach
    void setUp() {
        notificationRequest = new NotificationRequest();
    }

    // Positive test cases
    @Test
    void testSetAndGetRequestId() {
        String expected = "REQ-12345";
        notificationRequest.setRequestId(expected);
        assertEquals(expected, notificationRequest.getRequestId());
    }

    @Test
    void testSetAndGetUserOid() {
        String expected = "USER-67890";
        notificationRequest.setUserOid(expected);
        assertEquals(expected, notificationRequest.getUserOid());
    }

    @Test
    void testSetAndGetRequestingActivityName() {
        String expected = "COMPLAINT_SUBMISSION";
        notificationRequest.setRequestingActivityName(expected);
        assertEquals(expected, notificationRequest.getRequestingActivityName());
    }

    @Test
    void testSetAndGetNotificationStatusId() {
        int expected = 1;
        notificationRequest.setNotificationStatusId(expected);
        assertEquals(expected, notificationRequest.getNotificationStatusId());
    }

    @Test
    void testSetAndGetMessage() {
        String expected = "Your complaint has been received";
        notificationRequest.setMessage(expected);
        assertEquals(expected, notificationRequest.getMessage());
    }

    @Test
    void testSetAndGetFileDownloadUrl() {
        String expected = "https://example.com/files/doc123.pdf";
        notificationRequest.setFileDownloadUrl(expected);
        assertEquals(expected, notificationRequest.getFileDownloadUrl());
    }

    @Test
    void testSetAndGetCreatedBy() {
        String expected = "system";
        notificationRequest.setCreatedBy(expected);
        assertEquals(expected, notificationRequest.getCreatedBy());
    }

    @Test
    void testSetAndGetCreatedOn() {
        LocalDateTime expected = LocalDateTime.now();
        notificationRequest.setCreatedOn(expected);
        assertEquals(expected, notificationRequest.getCreatedOn());
    }

    @Test
    void testSetAndGetModifiedBy() {
        String expected = "admin";
        notificationRequest.setModifiedBy(expected);
        assertEquals(expected, notificationRequest.getModifiedBy());
    }

    @Test
    void testSetAndGetModifiedOn() {
        String expected = "2023-05-15T14:30:00";
        notificationRequest.setModifiedOn(expected);
        assertEquals(expected, notificationRequest.getModifiedOn());
    }



    // Edge cases
    @Test
    void testSetMessageWithEmptyString() {
        notificationRequest.setMessage("");
        assertEquals("", notificationRequest.getMessage());
    }

    @Test
    void testSetFileDownloadUrlWithEmptyString() {
        notificationRequest.setFileDownloadUrl("");
        assertEquals("", notificationRequest.getFileDownloadUrl());
    }

    @Test
    void testSetModifiedByWithEmptyString() {
        notificationRequest.setModifiedBy("");
        assertEquals("", notificationRequest.getModifiedBy());
    }

    @Test
    void testSetModifiedOnWithEmptyString() {
        notificationRequest.setModifiedOn("");
        assertEquals("", notificationRequest.getModifiedOn());
    }

    // Test data builder for creating test instances
    public static NotificationRequest createValidNotificationRequest() {
        NotificationRequest request = new NotificationRequest();
        request.setRequestId("REQ-12345");
        request.setUserOid("USER-67890");
        request.setRequestingActivityName("COMPLAINT_SUBMISSION");
        request.setNotificationStatusId(1);
        request.setMessage("Test message");
        request.setFileDownloadUrl("https://example.com/file.pdf");
        request.setCreatedBy("system");
        request.setCreatedOn(LocalDateTime.now());
        return request;
    }
}