package com.ombudsman.service.digitalmessage.Model;

import org.junit.jupiter.api.Test;

import java.time.LocalDateTime;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;

public class PhoenixServiceBusMessageTest {

    private UUID createMockUUID() {
        return UUID.randomUUID();
    }

    private LocalDateTime createMockDateTime() {
        return LocalDateTime.now();
    }

    @Test
    public void testGettersAndSetters_withValidValues() {
        PhoenixServiceBusMessage message = new PhoenixServiceBusMessage();

        UUID uuid1 = createMockUUID();
        UUID uuid2 = createMockUUID();
        UUID uuid3 = createMockUUID();
        UUID uuid4 = createMockUUID();
        UUID uuid5 = createMockUUID();
        UUID uuid6 = createMockUUID();

        LocalDateTime now = createMockDateTime();
        LocalDateTime later = now.plusDays(1);

        // UUID fields
        message.setTempDigitalMessageProcessingID(uuid1);
        assertEquals(uuid1, message.getTempDigitalMessageProcessingID());

        message.setTempUILocalDigitalMessageEntryID(uuid2);
        assertEquals(uuid2, message.getTempUILocalDigitalMessageEntryID());

        message.setTo(uuid3);
        assertEquals(uuid3, message.getTo());

        message.setFrom(uuid4);
        assertEquals(uuid4, message.getFrom());

        message.setOwner(uuid5);
        assertEquals(uuid5, message.getOwner());

        message.setMessageSentByDpUserAdOid(uuid6);
        assertEquals(uuid6, message.getMessageSentByDpUserAdOid());

        message.setRegardingObjectId(uuid1);
        assertEquals(uuid1, message.getRegardingObjectId());

        // Long fields
        message.setDirection(10L);
        assertEquals(10L, message.getDirection());

        message.setPortalType(20L);
        assertEquals(20L, message.getPortalType());

        // String fields
        message.setMessage("Test message");
        assertEquals("Test message", message.getMessage());

        message.setCreatedBy("creatorUser");
        assertEquals("creatorUser", message.getCreatedBy());

        message.setModifiedBy("modifierUser");
        assertEquals("modifierUser", message.getModifiedBy());

        message.setActivityStatus("Active");
        assertEquals("Active", message.getActivityStatus());

        message.setStatusReason("Status Reason Example");
        assertEquals("Status Reason Example", message.getStatusReason());

        message.setCategory("Category Example");
        assertEquals("Category Example", message.getCategory());

        message.setRegarding("Regarding Example");
        assertEquals("Regarding Example", message.getRegarding());

        message.setActivityId("activity123");
        assertEquals("activity123", message.getActivityId());

        message.setSubject("Subject example");
        assertEquals("Subject example", message.getSubject());

        message.setToForEfile("to-for-efile-example");
        assertEquals("to-for-efile-example", message.getToForEfile());

        message.setUserName("userNameExample");
        assertEquals("userNameExample", message.getUserName());

        message.setMessageSentByDpUserAdName("User AD Name");
        assertEquals("User AD Name", message.getMessageSentByDpUserAdName());

        // LocalDateTime fields
        message.setCreatedOn(now);
        assertEquals(now, message.getCreatedOn());

        message.setModifiedOn(later);
        assertEquals(later, message.getModifiedOn());

        message.setDueDate(now);
        assertEquals(now, message.getDueDate());

        message.setOverrideCreatedOn(later);
        assertEquals(later, message.getOverrideCreatedOn());
    }

    @Test
    public void testSettersAcceptNullValues() {
        PhoenixServiceBusMessage message = new PhoenixServiceBusMessage();

        message.setTempDigitalMessageProcessingID(null);
        assertNull(message.getTempDigitalMessageProcessingID());

        message.setTempUILocalDigitalMessageEntryID(null);
        assertNull(message.getTempUILocalDigitalMessageEntryID());

        message.setTo(null);
        assertNull(message.getTo());

        message.setFrom(null);
        assertNull(message.getFrom());

        message.setOwner(null);
        assertNull(message.getOwner());

        message.setMessageSentByDpUserAdOid(null);
        assertNull(message.getMessageSentByDpUserAdOid());

        message.setRegardingObjectId(null);
        assertNull(message.getRegardingObjectId());

        message.setDirection(null);
        assertNull(message.getDirection());

        message.setPortalType(null);
        assertNull(message.getPortalType());

        message.setMessage(null);
        assertNull(message.getMessage());

        message.setCreatedBy(null);
        assertNull(message.getCreatedBy());

        message.setModifiedBy(null);
        assertNull(message.getModifiedBy());

        message.setActivityStatus(null);
        assertNull(message.getActivityStatus());

        message.setStatusReason(null);
        assertNull(message.getStatusReason());

        message.setCategory(null);
        assertNull(message.getCategory());

        message.setRegarding(null);
        assertNull(message.getRegarding());

        message.setActivityId(null);
        assertNull(message.getActivityId());

        message.setSubject(null);
        assertNull(message.getSubject());

        message.setToForEfile(null);
        assertNull(message.getToForEfile());

        message.setUserName(null);
        assertNull(message.getUserName());

        message.setMessageSentByDpUserAdName(null);
        assertNull(message.getMessageSentByDpUserAdName());

        message.setCreatedOn(null);
        assertNull(message.getCreatedOn());

        message.setModifiedOn(null);
        assertNull(message.getModifiedOn());

        message.setDueDate(null);
        assertNull(message.getDueDate());

        message.setOverrideCreatedOn(null);
        assertNull(message.getOverrideCreatedOn());
    }
}