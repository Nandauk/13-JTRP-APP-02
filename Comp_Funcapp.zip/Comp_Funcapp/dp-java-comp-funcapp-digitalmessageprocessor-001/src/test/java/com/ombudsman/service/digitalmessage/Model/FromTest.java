package com.ombudsman.service.digitalmessage.Model;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import java.lang.reflect.Field;

import com.google.gson.annotations.SerializedName;

class FromTest {

    private From from;

    @BeforeEach
    void setUp() {
        // Initialize a new From object before each test
        from = new From();
    }

    @Test
    void testSetAndGetEmail() {
        // Arrange
        String testEmail = "test@example.com";

        // Act
        from.setEmail(testEmail);

        // Assert
        assertEquals(testEmail, from.getEmail());
    }

    @Test
    void testSetAndGetEmailWithNull() {
        // Act
        from.setEmail(null);

        // Assert
        assertNull(from.getEmail());
    }

    @Test
    void testSetAndGetName() {
        // Arrange
        String testName = "John Doe";

        // Act
        from.setName(testName);

        // Assert
        assertEquals(testName, from.getName());
    }

    @Test
    void testSetAndGetNameWithNull() {
        // Act
        from.setName(null);

        // Assert
        assertNull(from.getName());
    }

    @Test
    void testFullObjectCreation() {
        // Arrange
        String testEmail = "test@example.com";
        String testName = "John Doe";

        // Act
        from.setEmail(testEmail);
        from.setName(testName);

        // Assert
        assertEquals(testEmail, from.getEmail());
        assertEquals(testName, from.getName());
    }

    @Test
    void testDefaultConstructor() {
        // Arrange & Act
        From defaultFrom = new From();

        // Assert
        assertNull(defaultFrom.getEmail());
        assertNull(defaultFrom.getName());
    }

    @Test
    void testSerializedNameAnnotations() throws NoSuchFieldException {
        // Test Email field annotation
        Field emailField = From.class.getDeclaredField("Email");
        SerializedName emailSerializedName = emailField.getAnnotation(SerializedName.class);
        assertNotNull(emailSerializedName);
        assertEquals("Email", emailSerializedName.value());

        // Test Name field annotation
        Field nameField = From.class.getDeclaredField("Name");
        SerializedName nameSerializedName = nameField.getAnnotation(SerializedName.class);
        assertNotNull(nameSerializedName);
        assertEquals("Name", nameSerializedName.value());
    }

    @Test
    void testSettersWithEmptyStrings() {
        // Arrange
        String emptyString = "";

        // Act
        from.setEmail(emptyString);
        from.setName(emptyString);

        // Assert
        assertEquals(emptyString, from.getEmail());
        assertEquals(emptyString, from.getName());
    }

    @Test
    void testSettersWithWhitespaceStrings() {
        // Arrange
        String whitespaceString = "   ";

        // Act
        from.setEmail(whitespaceString);
        from.setName(whitespaceString);

        // Assert
        assertEquals(whitespaceString, from.getEmail());
        assertEquals(whitespaceString, from.getName());
    }

    @Test
    void testMultipleSetOperations() {
        // Arrange
        String email1 = "first@example.com";
        String name1 = "First User";
        String email2 = "second@example.com";
        String name2 = "Second User";

        // Act
        from.setEmail(email1);
        from.setName(name1);
        from.setEmail(email2);
        from.setName(name2);

        // Assert
        assertEquals(email2, from.getEmail());
        assertEquals(name2, from.getName());
    }
}