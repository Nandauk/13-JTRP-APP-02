package com.ombudsman.service.digitalmessage.Model;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import java.lang.reflect.Field;

import com.google.gson.annotations.SerializedName;

class ToTest {

    private To to;

    @BeforeEach
    void setUp() {
        // Initialize a new To object before each test
        to = new To();
    }

    @Test
    void testSetAndGetEmail() {
        // Arrange
        String testEmail = "recipient@example.com";

        // Act
        to.setEmail(testEmail);

        // Assert
        assertEquals(testEmail, to.getEmail());
    }

    @Test
    void testSetAndGetEmailWithNull() {
        // Act
        to.setEmail(null);

        // Assert
        assertNull(to.getEmail());
    }

    @Test
    void testSetAndGetName() {
        // Arrange
        String testName = "Jane Doe";

        // Act
        to.setName(testName);

        // Assert
        assertEquals(testName, to.getName());
    }

    @Test
    void testSetAndGetNameWithNull() {
        // Act
        to.setName(null);

        // Assert
        assertNull(to.getName());
    }

    @Test
    void testFullObjectCreation() {
        // Arrange
        String testEmail = "recipient@example.com";
        String testName = "Jane Doe";

        // Act
        to.setEmail(testEmail);
        to.setName(testName);

        // Assert
        assertEquals(testEmail, to.getEmail());
        assertEquals(testName, to.getName());
    }

    @Test
    void testDefaultConstructor() {
        // Arrange & Act
        To defaultTo = new To();

        // Assert
        assertNull(defaultTo.getEmail());
        assertNull(defaultTo.getName());
    }

    @Test
    void testSerializedNameAnnotations() throws NoSuchFieldException {
        // Test Email field annotation
        Field emailField = To.class.getDeclaredField("Email");
        SerializedName emailSerializedName = emailField.getAnnotation(SerializedName.class);
        assertNotNull(emailSerializedName);
        assertEquals("Email", emailSerializedName.value());

        // Test Name field annotation
        Field nameField = To.class.getDeclaredField("Name");
        SerializedName nameSerializedName = nameField.getAnnotation(SerializedName.class);
        assertNotNull(nameSerializedName);
        assertEquals("Name", nameSerializedName.value());
    }

    @Test
    void testSettersWithEmptyStrings() {
        // Arrange
        String emptyString = "";

        // Act
        to.setEmail(emptyString);
        to.setName(emptyString);

        // Assert
        assertEquals(emptyString, to.getEmail());
        assertEquals(emptyString, to.getName());
    }

    @Test
    void testSettersWithWhitespaceStrings() {
        // Arrange
        String whitespaceString = "   ";

        // Act
        to.setEmail(whitespaceString);
        to.setName(whitespaceString);

        // Assert
        assertEquals(whitespaceString, to.getEmail());
        assertEquals(whitespaceString, to.getName());
    }

    @Test
    void testMultipleSetOperations() {
        // Arrange
        String email1 = "first@example.com";
        String name1 = "First Recipient";
        String email2 = "second@example.com";
        String name2 = "Second Recipient";

        // Act
        to.setEmail(email1);
        to.setName(name1);
        to.setEmail(email2);
        to.setName(name2);

        // Assert
        assertEquals(email2, to.getEmail());
        assertEquals(name2, to.getName());
    }

    @Test
    void testObjectEquality() {
        // Arrange
        To to1 = new To();
        To to2 = new To();
        
        // Act
        to1.setEmail("recipient@example.com");
        to1.setName("Jane Doe");
        
        to2.setEmail("recipient@example.com");
        to2.setName("Jane Doe");

        // Assert
        assertNotSame(to1, to2);
        assertEquals(to1.getEmail(), to2.getEmail());
        assertEquals(to1.getName(), to2.getName());
    }

    @Test
    void testEmailValidation() {
        // Arrange
        String validEmail = "test@example.com";
        String invalidEmail1 = "invalid-email";
        String invalidEmail2 = "test@example";

        // Act & Assert
        to.setEmail(validEmail);
        assertEquals(validEmail, to.getEmail());

        // These are just basic checks, real email validation would be more complex
        to.setEmail(invalidEmail1);
        assertEquals(invalidEmail1, to.getEmail());

        to.setEmail(invalidEmail2);
        assertEquals(invalidEmail2, to.getEmail());
    }
}