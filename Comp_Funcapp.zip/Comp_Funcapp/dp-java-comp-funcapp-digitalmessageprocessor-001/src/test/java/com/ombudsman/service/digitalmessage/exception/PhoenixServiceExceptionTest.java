package com.ombudsman.service.digitalmessage.exception;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

public class PhoenixServiceExceptionTest {

    @Test
    void testPhoenixServiceExceptionMessage() {
        String message = "Something went wrong";
        String exceptionMessage = "Detailed exception message";

        PhoenixServiceException exception = new PhoenixServiceException(message, exceptionMessage);

        assertEquals("Something went wrong", exception.getMessage());
        assertEquals("PHOENIX_ERROR", exception.getCode());
    }
}
