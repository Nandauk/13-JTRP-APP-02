package com.ombudsman.service.digitalmessage.Model;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import java.lang.reflect.Field;

import com.google.gson.annotations.SerializedName;

class MailjetVariablesTest {

    private MailjetVariables mailjetVariables;

    @BeforeEach
    void setUp() {
        // Initialize a new MailjetVariables object before each test
        mailjetVariables = new MailjetVariables();
    }

    @Test
    void testSetAndGetPortalUser() {
        // Arrange
        String testPortalUser = "testuser123";

        // Act
        mailjetVariables.setPortal_User(testPortalUser);

        // Assert
        assertEquals(testPortalUser, mailjetVariables.getPortal_User());
    }

    @Test
    void testSetAndGetPortalUserWithNull() {
        // Act
        mailjetVariables.setPortal_User(null);

        // Assert
        assertNull(mailjetVariables.getPortal_User());
    }

    @Test
    void testSetAndGetSignIn() {
        // Arrange
        String testSignIn = "https://example.com/signin";

        // Act
        mailjetVariables.setSign_In(testSignIn);

        // Assert
        assertEquals(testSignIn, mailjetVariables.getSign_In());
    }

    @Test
    void testSetAndGetSignInWithNull() {
        // Act
        mailjetVariables.setSign_In(null);

        // Assert
        assertNull(mailjetVariables.getSign_In());
    }

    @Test
    void testFullObjectCreation() {
        // Arrange
        String testPortalUser = "testuser123";
        String testSignIn = "https://example.com/signin";

        // Act
        mailjetVariables.setPortal_User(testPortalUser);
        mailjetVariables.setSign_In(testSignIn);

        // Assert
        assertEquals(testPortalUser, mailjetVariables.getPortal_User());
        assertEquals(testSignIn, mailjetVariables.getSign_In());
    }

    @Test
    void testDefaultConstructor() {
        // Arrange & Act
        MailjetVariables defaultVariables = new MailjetVariables();

        // Assert
        assertNull(defaultVariables.getPortal_User());
        assertNull(defaultVariables.getSign_In());
    }

    @Test
    void testSerializedNameAnnotations() throws NoSuchFieldException {
        // Test portal_User field annotation
        Field portalUserField = MailjetVariables.class.getDeclaredField("portal_User");
        SerializedName portalUserSerializedName = portalUserField.getAnnotation(SerializedName.class);
        assertNotNull(portalUserSerializedName);
        assertEquals("portal_User", portalUserSerializedName.value());

        // Test sign_In field annotation
        Field signInField = MailjetVariables.class.getDeclaredField("sign_In");
        SerializedName signInSerializedName = signInField.getAnnotation(SerializedName.class);
        assertNotNull(signInSerializedName);
        assertEquals("sign_In", signInSerializedName.value());
    }

    @Test
    void testSettersWithEmptyStrings() {
        // Arrange
        String emptyString = "";

        // Act
        mailjetVariables.setPortal_User(emptyString);
        mailjetVariables.setSign_In(emptyString);

        // Assert
        assertEquals(emptyString, mailjetVariables.getPortal_User());
        assertEquals(emptyString, mailjetVariables.getSign_In());
    }

    @Test
    void testSettersWithWhitespaceStrings() {
        // Arrange
        String whitespaceString = "   ";

        // Act
        mailjetVariables.setPortal_User(whitespaceString);
        mailjetVariables.setSign_In(whitespaceString);

        // Assert
        assertEquals(whitespaceString, mailjetVariables.getPortal_User());
        assertEquals(whitespaceString, mailjetVariables.getSign_In());
    }

    @Test
    void testMultipleSetOperations() {
        // Arrange
        String portalUser1 = "user1";
        String signIn1 = "https://example.com/signin1";
        String portalUser2 = "user2";
        String signIn2 = "https://example.com/signin2";

        // Act
        mailjetVariables.setPortal_User(portalUser1);
        mailjetVariables.setSign_In(signIn1);
        mailjetVariables.setPortal_User(portalUser2);
        mailjetVariables.setSign_In(signIn2);

        // Assert
        assertEquals(portalUser2, mailjetVariables.getPortal_User());
        assertEquals(signIn2, mailjetVariables.getSign_In());
    }

    @Test
    void testObjectEquality() {
        // Arrange
        MailjetVariables variables1 = new MailjetVariables();
        MailjetVariables variables2 = new MailjetVariables();
        
        // Act
        variables1.setPortal_User("user1");
        variables1.setSign_In("signin1");
        
        variables2.setPortal_User("user1");
        variables2.setSign_In("signin1");

        // Assert
        assertNotSame(variables1, variables2);
        assertEquals(variables1.getPortal_User(), variables2.getPortal_User());
        assertEquals(variables1.getSign_In(), variables2.getSign_In());
    }
}