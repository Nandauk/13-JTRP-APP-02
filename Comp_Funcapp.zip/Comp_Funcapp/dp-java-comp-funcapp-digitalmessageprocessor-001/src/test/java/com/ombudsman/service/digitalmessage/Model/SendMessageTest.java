package com.ombudsman.service.digitalmessage.Model;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

class SendMessageTest {

    private sendMessage message;

    @BeforeEach
    void setUp() {
        // Initialize a new sendMessage object before each test
        message = new sendMessage();
    }

    @Test
    void testSetAndGetFrom() {
        // Arrange
        String testFrom = "sender@example.com";

        // Act
        message.setFrom(testFrom);

        // Assert
        assertEquals(testFrom, message.getFrom());
    }

    @Test
    void testSetAndGetFromWithNull() {
        // Act
        message.setFrom(null);

        // Assert
        assertNull(message.getFrom());
    }

    @Test
    void testSetAndGetTo() {
        // Arrange
        List<String> testRecipients = Arrays.asList(
            "recipient1@example.com", 
            "recipient2@example.com"
        );

        // Act
        message.setTo(testRecipients);

        // Assert
        assertEquals(testRecipients, message.getTo());
        assertEquals(2, message.getTo().size());
    }

    @Test
    void testSetAndGetToWithEmptyList() {
        // Arrange
        List<String> emptyList = new ArrayList<>();

        // Act
        message.setTo(emptyList);

        // Assert
        assertNotNull(message.getTo());
        assertTrue(message.getTo().isEmpty());
    }

    @Test
    void testSetAndGetToWithNull() {
        // Act
        message.setTo(null);

        // Assert
        assertNull(message.getTo());
    }

    @Test
    void testSetAndGetBody() {
        // Arrange
        String testBody = "This is a test message body";

        // Act
        message.setBody(testBody);

        // Assert
        assertEquals(testBody, message.getBody());
    }

    @Test
    void testSetAndGetBodyWithEmptyString() {
        // Act
        message.setBody("");

        // Assert
        assertEquals("", message.getBody());
    }

    @Test
    void testSetAndGetBodyWithNull() {
        // Act
        message.setBody(null);

        // Assert
        assertNull(message.getBody());
    }

    @Test
    void testFullObjectCreation() {
        // Arrange
        String testFrom = "sender@example.com";
        List<String> testRecipients = Arrays.asList(
            "recipient1@example.com", 
            "recipient2@example.com"
        );
        String testBody = "Test message content";

        // Act
        message.setFrom(testFrom);
        message.setTo(testRecipients);
        message.setBody(testBody);

        // Assert
        assertEquals(testFrom, message.getFrom());
        assertEquals(testRecipients, message.getTo());
        assertEquals(testBody, message.getBody());
    }

    @Test
    void testDefaultConstructor() {
        // Arrange & Act
        sendMessage defaultMessage = new sendMessage();

        // Assert
        assertNull(defaultMessage.getFrom());
        assertNull(defaultMessage.getTo());
        assertNull(defaultMessage.getBody());
    }
}