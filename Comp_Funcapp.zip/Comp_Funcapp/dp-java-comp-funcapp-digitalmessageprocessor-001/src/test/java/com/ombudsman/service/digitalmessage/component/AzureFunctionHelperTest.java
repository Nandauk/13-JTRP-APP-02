package com.ombudsman.service.digitalmessage.component;

import com.ombudsman.service.digitalmessage.Model.BaseTableDTO;
import com.ombudsman.service.digitalmessage.Model.PhoenixServiceBusMessage;
import org.junit.jupiter.api.Test;

import java.time.LocalDateTime;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;

public class AzureFunctionHelperTest {

    @Test
    public void testSetValuesToBaseTable_withValidPhoenixServiceBusMessage() {
        AzureFunctionHelper helper = new AzureFunctionHelper();

        UUID toUUID = UUID.randomUUID();
        UUID fromUUID = UUID.randomUUID();
        UUID createdByUUID = UUID.randomUUID();
        UUID ownerUUID = UUID.randomUUID();
        UUID regardingUUID = UUID.randomUUID();
        UUID messageSentByUUID = UUID.randomUUID();

        PhoenixServiceBusMessage message = new PhoenixServiceBusMessage();
        message.setTo(toUUID);
        message.setFrom(fromUUID);
        message.setUserName("senderUser");
        message.setMessage("Test message content");
        LocalDateTime now = LocalDateTime.now();
        message.setCreatedOn(now);
        message.setMessageSentByDpUserAdOid(createdByUUID);  // note: SB comment in original code
        message.setOwner(ownerUUID);
        message.setRegardingObjectId(regardingUUID);
        message.setSubject("Test Subject");
        message.setMessageSentByDpUserAdOid(messageSentByUUID);
        message.setMessageSentByDpUserAdName("Message Sender AD Name");

        BaseTableDTO baseTable = helper.setValuesToBaseTable(message);

        // Assert basic string fields with fixed values
        assertEquals("140000000", baseTable.getFosDirection());
        assertEquals("Incoming", baseTable.getFosDirectionName());
        assertEquals("140000000", baseTable.getFosPortalType());
        assertEquals("Complainant", baseTable.getFosPortalTypeName());

        // Assert UUID fields taken from message
        assertEquals(toUUID, baseTable.getTo());
        assertEquals(fromUUID, baseTable.getFrom());

        // Names and description mapping
        assertEquals("Financial Ombudsman Service", baseTable.getToName());
        assertEquals("senderUser", baseTable.getFromName());
        assertEquals("Test message content", baseTable.getDescription());

        // CreatedOn and override
        assertEquals(now, baseTable.getCreatedOn());
        assertEquals(now, baseTable.getOverrideCreatedOn());

        // CreatedBy is set from message.getMessageSentByDpUserAdOid
        assertEquals(messageSentByUUID, baseTable.getCreatedBy());

        // Null values per original code
        assertNull(baseTable.getCreatedByName());
        assertNull(baseTable.getModifiedOn());
        assertNull(baseTable.getModifiedBy());
        assertNull(baseTable.getModifiedByName());
        assertNull(baseTable.getOwningUserIdName());
        assertNull(baseTable.getRegardingObjectIdName());

        // Owner and regarding IDs
        assertEquals(ownerUUID, baseTable.getOwningUserId());
        assertEquals(regardingUUID, baseTable.getRegardingObjectId());

        // Status and codes
        assertEquals(0, baseTable.getStateCode());
        assertEquals("Open", baseTable.getStateCodeName()); // Note: setStateCodeName called twice in original code - last one expected
        assertEquals(1, baseTable.getStatusCode());

        // Fixed category values
        assertEquals(140000036, baseTable.getFosActivityCategory());
        assertEquals("Digital Messaging", baseTable.getFosActivityCategoryName());

        // Subject mapped from message
        assertEquals("Test Subject", baseTable.getSubject());

        // Scheduled dates null as per code
        assertNull(baseTable.getScheduledStart());
        assertNull(baseTable.getScheduledEnd());

        // ForeFile strings fixed
        assertEquals("Complainant Portal", baseTable.getFosFromForeFile());
        assertEquals("Financial Ombudsman Service", baseTable.getFosToForeFile());

        // Message sent by DP user AD fields
        assertEquals(messageSentByUUID, baseTable.getMessageSentByDpUserAdOid());
        assertEquals("Message Sender AD Name", baseTable.getMessageSentByDpUserAdName());

        // Notification send status false
        assertFalse(baseTable.isUserNotificationSendStatus());
    }

    @Test
    public void testSetValuesToBaseTable_withNullFieldsInMessage() {
        AzureFunctionHelper helper = new AzureFunctionHelper();
        PhoenixServiceBusMessage message = new PhoenixServiceBusMessage();

        // Leave all fields null
        BaseTableDTO baseTable = helper.setValuesToBaseTable(message);

        // Fixed strings set regardless of message
        assertEquals("140000000", baseTable.getFosDirection());
        assertEquals("Incoming", baseTable.getFosDirectionName());
        assertEquals("140000000", baseTable.getFosPortalType());
        assertEquals("Complainant", baseTable.getFosPortalTypeName());
        assertEquals("Financial Ombudsman Service", baseTable.getToName());
        assertEquals("Complainant Portal", baseTable.getFosFromForeFile());
        assertEquals("Financial Ombudsman Service", baseTable.getFosToForeFile());

        // Nullable fields should reflect null input or fixed default
        assertNull(baseTable.getTo());
        assertNull(baseTable.getFrom());
        assertNull(baseTable.getFromName());
        assertNull(baseTable.getDescription());
        assertNull(baseTable.getCreatedOn());
        assertNull(baseTable.getCreatedBy());
        assertNull(baseTable.getOverrideCreatedOn());
        assertNull(baseTable.getCreatedByName());
        assertNull(baseTable.getModifiedOn());
        assertNull(baseTable.getModifiedBy());
        assertNull(baseTable.getModifiedByName());
        assertNull(baseTable.getOwningUserId());
        assertNull(baseTable.getOwningUserIdName());
        assertNull(baseTable.getRegardingObjectId());
        assertNull(baseTable.getRegardingObjectIdName());
        assertNull(baseTable.getSubject());
        assertNull(baseTable.getScheduledStart());
        assertNull(baseTable.getScheduledEnd());
        assertNull(baseTable.getMessageSentByDpUserAdOid());
        assertNull(baseTable.getMessageSentByDpUserAdName());

        // Codes and statuses as per original
        assertEquals(0, baseTable.getStateCode());
        assertEquals("Open", baseTable.getStateCodeName());
        assertEquals(1, baseTable.getStatusCode());
        assertEquals(140000036, baseTable.getFosActivityCategory());
        assertEquals("Digital Messaging", baseTable.getFosActivityCategoryName());

        // Notification Send Status False
        assertFalse(baseTable.isUserNotificationSendStatus());
    }
}