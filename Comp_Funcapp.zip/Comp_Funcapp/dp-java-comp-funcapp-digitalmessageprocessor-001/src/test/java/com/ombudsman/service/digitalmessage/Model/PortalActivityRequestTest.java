package com.ombudsman.service.digitalmessage.Model;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

class PortalActivityRequestTest {

    private PortalActivityRequest portalActivityRequest;

    @BeforeEach
    void setUp() {
        portalActivityRequest = new PortalActivityRequest();
    }
    @Test
    void testGetFos_activitycategory() {
    	PortalActivityRequest obj = new PortalActivityRequest();
        Long expectedValue = 100L;
        obj.setFos_activitycategory(expectedValue); // assuming there's a setter
        assertEquals(expectedValue, obj.getFos_activitycategory());
    }
    @Test
    void testSetAndGetActivityId() {
        // Arrange
        UUID testActivityId = UUID.randomUUID();

        // Act
        portalActivityRequest.setActivityId(testActivityId);

        // Assert
        assertEquals(testActivityId, portalActivityRequest.getActivityId());
    }

    @Test
    void testSetAndGetOwnerId() {
        // Arrange
        String testOwnerId = "test-owner-id";

        // Act
        portalActivityRequest.setOwnerId(testOwnerId);

        // Assert
        assertEquals(testOwnerId, portalActivityRequest.getOwnerId());
    }

    @Test
    void testSetAndGetRegardingObjectIdIncidentFosPortal() {
        // Arrange
        String testRegardingObjectId = "test-regarding-object-id";

        // Act
        portalActivityRequest.setRegardingObjectIdIncidentFosPortal(testRegardingObjectId);

        // Assert
        assertEquals(testRegardingObjectId, portalActivityRequest.getRegardingObjectIdIncidentFosPortal());
    }

    @Test
    void testSetAndGetSubject() {
        // Arrange
        String testSubject = "Test Subject";

        // Act
        portalActivityRequest.setSubject(testSubject);

        // Assert
        assertEquals(testSubject, portalActivityRequest.getSubject());
    }

    @Test
    void testSetAndGetFosDirection() {
        // Arrange
        Long testFosDirection = 123L;

        // Act
        portalActivityRequest.setFosdirection(testFosDirection);

        // Assert
        assertEquals(testFosDirection, portalActivityRequest.getFosdirection());
    }

    @Test
    void testSetAndGetDescription() {
        // Arrange
        String testDescription = "Test Description";

        // Act
        portalActivityRequest.setDescription(testDescription);

        // Assert
        assertEquals(testDescription, portalActivityRequest.getDescription());
    }

    @Test
    void testSetAndGetFosPortalType() {
        // Arrange
        Long testFosPortalType = 456L;

        // Act
        portalActivityRequest.setFosportaltype(testFosPortalType);

        // Assert
        assertEquals(testFosPortalType, portalActivityRequest.getFosportaltype());
    }

    @Test
    void testSetAndGetStateCode() {
        // Arrange
        int testStateCode = 1;

        // Act
        portalActivityRequest.setStatecode(testStateCode);

        // Assert
        assertEquals(testStateCode, portalActivityRequest.getStatecode());
    }

    @Test
    void testSetAndGetStatusCode() {
        // Arrange
        int testStatusCode = 2;

        // Act
        portalActivityRequest.setStatuscode(testStatusCode);

        // Assert
        assertEquals(testStatusCode, portalActivityRequest.getStatuscode());
    }

    @Test
    void testSetAndGetFosToForFile() {
        // Arrange
        String testFosToForFile = "test-to-file";

        // Act
        portalActivityRequest.setFos_toforefile(testFosToForFile);

        // Assert
        assertEquals(testFosToForFile, portalActivityRequest.getFos_toforefile());
    }

    @Test
    void testSetAndGetFosPortalActivityParties() {
        // Arrange
        List<PortalActivityRequest.FosPortalActivityParty> testParties = new ArrayList<>();
        PortalActivityRequest.FosPortalActivityParty party = new PortalActivityRequest.FosPortalActivityParty();
        party.setPartyIdContact("test-contact-id");
        testParties.add(party);

        // Act
        portalActivityRequest.setFosPortalActivityParties(testParties);

        // Assert
        assertEquals(testParties, portalActivityRequest.getFosPortalActivityParties());
        assertEquals(1, portalActivityRequest.getFosPortalActivityParties().size());
    }

    @Test
    void testSetAndGetCreatedon() {
        // Arrange
        String testCreatedOn = "2023-01-01T00:00:00";

        // Act
        portalActivityRequest.setCreatedon(testCreatedOn);

        // Assert
        assertEquals(testCreatedOn, portalActivityRequest.getCreatedon());
    }

    @Test
    void testSetAndGetScheduledEnd() {
        // Arrange
        String testScheduledEnd = "2023-01-02T00:00:00";

        // Act
        portalActivityRequest.setScheduledend(testScheduledEnd);

        // Assert
        assertEquals(testScheduledEnd, portalActivityRequest.getScheduledend());
    }

    @Test
    void testFosPortalActivityPartyMethods() {
        // Arrange
        PortalActivityRequest.FosPortalActivityParty party = new PortalActivityRequest.FosPortalActivityParty();
        
        // Test setters and getters
        party.setType("test-type");
        party.setPartyIdSystemUser("test-system-user");
        party.setPartyIdContact("test-contact");
        party.setParticipationTypeMask(1);

        // Assert
        assertEquals("test-type", party.getType());
        assertEquals("test-system-user", party.getPartyIdSystemUser());
        assertEquals("test-contact", party.getPartyIdContact());
        assertEquals(1, party.getParticipationTypeMask());
    }

    @Test
    void testDefaultConstructor() {
        // Arrange & Act
        PortalActivityRequest defaultRequest = new PortalActivityRequest();

        // Assert
        assertNull(defaultRequest.getActivityId());
        assertNull(defaultRequest.getOwnerId());
        assertNull(defaultRequest.getRegardingObjectIdIncidentFosPortal());
        assertNull(defaultRequest.getSubject());
        assertNull(defaultRequest.getFosdirection());
        assertNull(defaultRequest.getDescription());
        assertNull(defaultRequest.getFosportaltype());
        assertEquals(0, defaultRequest.getStatecode());
        assertEquals(0, defaultRequest.getStatuscode());
        assertNull(defaultRequest.getFos_toforefile());
        assertNull(defaultRequest.getFosPortalActivityParties());
    }
}