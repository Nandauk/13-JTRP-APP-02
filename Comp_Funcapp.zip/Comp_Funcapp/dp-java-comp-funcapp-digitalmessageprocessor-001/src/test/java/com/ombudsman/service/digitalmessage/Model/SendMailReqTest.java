package com.ombudsman.service.digitalmessage.Model;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import java.util.List;
import java.util.ArrayList;

public class SendMailReqTest {

    @Test
    void testGetMessages() {
        SendMailReq sendMailReq = new SendMailReq();
        Messages message = new Messages();
        List<Messages> expectedMessages = new ArrayList<>();
        expectedMessages.add(message);

        sendMailReq.setMessages(expectedMessages);

        assertEquals(expectedMessages, sendMailReq.getMessages());
    }
}
