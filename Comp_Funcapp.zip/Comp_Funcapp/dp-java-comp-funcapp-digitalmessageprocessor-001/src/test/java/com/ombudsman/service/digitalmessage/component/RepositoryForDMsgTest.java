package com.ombudsman.service.digitalmessage.component;

import com.ombudsman.service.digitalmessage.Model.BaseTableDTO;
import com.ombudsman.service.digitalmessage.Model.NotificationRequest;
import com.ombudsman.service.digitalmessage.Model.PhoenixServiceBusMessage;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import org.springframework.jdbc.core.JdbcTemplate;

import java.time.LocalDateTime;
import java.util.UUID;

import static org.mockito.Mockito.*;

public class RepositoryForDMsgTest {

    @InjectMocks
    private RepositoryForDMsg repository;

    @Mock
    private JdbcTemplate jdbcTemplate;

    @BeforeEach
    public void setup() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testSendInAppNotificationRepo() throws Exception {
        NotificationRequest request = new NotificationRequest();
        request.setRequestId("REQ123");
        request.setUserOid("USER456");
        request.setRequestingActivityName("TestActivity");
        request.setNotificationStatusId(1);
        request.setMessage("Test message");
        request.setFileDownloadUrl("http://example.com/file.pdf");
        request.setCreatedBy("admin");
        request.setCreatedOn(LocalDateTime.now());
        request.setModifiedBy("admin");
        request.setModifiedOn(LocalDateTime.now().toString());

        repository.sendInAppNotificationRepo(request, jdbcTemplate);

        verify(jdbcTemplate, times(1)).update(anyString(), any(Object[].class));
    }

    @Test
    public void testUpdateDpDatabase() {
        PhoenixServiceBusMessage message = new PhoenixServiceBusMessage();
        message.setTempDigitalMessageProcessingID(UUID.randomUUID());

        repository.updateDpDatabase(message, jdbcTemplate);

        verify(jdbcTemplate, times(1)).update(anyString(), any(Object[].class));
    }

    @Test
    public void testInsertIntoBaseTable() {
        PhoenixServiceBusMessage message = new PhoenixServiceBusMessage();
        UUID activityId = UUID.randomUUID();

        BaseTableDTO dto = new BaseTableDTO();
        dto.setFosDirection("1");
        dto.setFosDirectionName("Inbound");
        dto.setFosPortalType("2");
        dto.setFosPortalTypeName("Web");
        dto.setTo(UUID.randomUUID());
        dto.setToName("Recipient");
        dto.setFrom(UUID.randomUUID());
        dto.setFromName("Sender");
        dto.setDescription("Test Description");
        dto.setCreatedOn(LocalDateTime.now());
        dto.setCreatedBy(UUID.randomUUID());
        dto.setOverrideCreatedOn(LocalDateTime.now());
        dto.setCreatedByName("Admin User");
        dto.setModifiedOn(LocalDateTime.now());
        dto.setModifiedBy(UUID.randomUUID());
        dto.setModifiedByName("Admin User");
        dto.setOwningUserId(UUID.randomUUID());
        dto.setOwningUserIdName("Owner");
        dto.setStateCode(0);
        dto.setStateCodeName("Active");
        dto.setStatusCode(1);
        dto.setStatusCodeName("Sent");
        dto.setFosActivityCategory(3L);
        dto.setFosActivityCategoryName("Notification");
        dto.setRegardingObjectId(UUID.randomUUID());
        dto.setRegardingObjectIdName("Case123");
        dto.setSubject("Test Subject");
        dto.setScheduledStart(LocalDateTime.now());
        dto.setScheduledEnd(LocalDateTime.now().plusHours(1));
        dto.setFosFromForeFile("fromFile");
        dto.setFosToForeFile("toFile");
        dto.setMessageSentByDpUserAdOid(UUID.randomUUID());
        dto.setMessageSentByDpUserAdName("DP User");
        dto.setIncrementalDataLoadJobAuditId(UUID.randomUUID());
        dto.setDpRecordCreatedOn(LocalDateTime.now());
        dto.setDpRecordModifiedOn(LocalDateTime.now());
        dto.setUserNotificationSendStatus(true);

        RepositoryForDMsg repoWithHelper = new RepositoryForDMsg() {
            @Override
            public boolean insertintoBaseTable(PhoenixServiceBusMessage msg, JdbcTemplate jdbc, UUID actId) {
                AzureFunctionHelper helper = mock(AzureFunctionHelper.class);
                when(helper.setValuesToBaseTable(any())).thenReturn(dto);
                BaseTableDTO baseTableDTO = helper.setValuesToBaseTable(msg);
                return super.insertintoBaseTable(msg, jdbc, actId);
            }
        };

        boolean result = repoWithHelper.insertintoBaseTable(message, jdbcTemplate, activityId);

        verify(jdbcTemplate, times(1)).update(anyString(), any(Object[].class));
        assert result;
    }

    @Test
    public void testMarkMessageAsFailed() {
        String tempId = "TEMP123";
        when(jdbcTemplate.update(anyString(), any(Object[].class))).thenReturn(1);

        boolean result = repository.markMessageAsFailed(tempId, jdbcTemplate);
        assert result;
    }

    @Test
    public void testDeleteFromTempTable() {
        String tempId = "TEMP123";
        when(jdbcTemplate.update(anyString(), any(Object[].class))).thenReturn(1);

        boolean result = repository.deleteFromTempTable(tempId, jdbcTemplate);
        assert result;
    }

    @Test
    public void testUpdateBaseTableAsNotified() {
        String activityId = UUID.randomUUID().toString();

        repository.updateBaseTableAsNotified(activityId, jdbcTemplate);

        verify(jdbcTemplate, times(1)).update(anyString(), any(Object[].class));
    }
}
