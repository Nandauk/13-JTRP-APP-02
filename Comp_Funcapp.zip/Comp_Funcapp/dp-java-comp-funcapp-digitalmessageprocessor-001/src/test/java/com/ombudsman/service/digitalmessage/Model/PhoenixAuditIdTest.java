package com.ombudsman.service.digitalmessage.Model;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

public class PhoenixAuditIdTest {

    @Test
    void testAuditidGetterSetter() {
        PhoenixAuditId audit = new PhoenixAuditId();
        String expectedAuditId = "PHX-AUDIT-001";

        audit.setAuditid(expectedAuditId);

        assertEquals(expectedAuditId, audit.getAuditid());
    }
}
