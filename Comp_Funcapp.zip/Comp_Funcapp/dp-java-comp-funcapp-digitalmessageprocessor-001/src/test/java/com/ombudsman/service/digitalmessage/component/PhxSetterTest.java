package com.ombudsman.service.digitalmessage.component;

import com.ombudsman.service.digitalmessage.Model.PhoenixServiceBusMessage;
import com.ombudsman.service.digitalmessage.Model.PortalActivityRequest;
import com.ombudsman.service.digitalmessage.Model.PortalActivityRequest.FosPortalActivityParty;

import org.junit.jupiter.api.Test;

import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;

import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

import org.junit.jupiter.api.Test;

import com.ombudsman.service.digitalmessage.Model.PhoenixServiceBusMessage;
import com.ombudsman.service.digitalmessage.Model.PortalActivityRequest;
import com.ombudsman.service.digitalmessage.Model.PortalActivityRequest.FosPortalActivityParty;
import com.ombudsman.service.digitalmessage.component.PhxSetter;

public class PhxSetterTest {

    @Test
    public void testSettingValues() throws Exception {
        // Arrange
        PhoenixServiceBusMessage message = new PhoenixServiceBusMessage();
        message.setOwner(UUID.randomUUID());
        message.setRegardingObjectId(UUID.randomUUID());
        message.setSubject("Test Subject");
        message.setMessage("Test Message");
        message.setCreatedOn(LocalDateTime.now());
        message.setTo(UUID.randomUUID());
        message.setFrom(UUID.randomUUID());
        message.setToForEfile("to@efile.com");
        message.setCaseOwnerUserType("systemusers");

        PhxSetter setter = new PhxSetter();

        // Act
        PortalActivityRequest result = setter.settingValues(message);

        // Assert
        assertNotNull(result);
        assertNotNull(result.getActivityId());
        assertEquals("/systemusers(" + message.getOwner() + ")", result.getOwnerId());
        assertEquals("/incidents(" + message.getRegardingObjectId() + ")", result.getRegardingObjectIdIncidentFosPortal());
        assertEquals("Test Subject", result.getSubject());
        assertEquals("Test Message", result.getDescription());
        assertEquals("to@efile.com", result.getFos_toforefile());
        assertEquals("Financial Ombudsman Service", result.getFos_fromforefile());

        List<FosPortalActivityParty> parties = result.getFosPortalActivityParties();
        assertEquals(2, parties.size());
        assertTrue(parties.stream().anyMatch(p -> p.getParticipationTypeMask() == 1));
        assertTrue(parties.stream().anyMatch(p -> p.getParticipationTypeMask() == 2));
    }
}
