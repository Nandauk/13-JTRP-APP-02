package com.ombudsman.service.digitalmessage.serviceimpl;

import com.ombudsman.service.digitalmessage.exception.PhoenixServiceException;
import okhttp3.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import java.io.IOException;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class PhoenixProcessorImplTest {

    private PhoenixProcessorImpl phoenixProcessor;
    private OkHttpClient mockClient;
    private Call mockCall;

    @BeforeEach
    void setUp() {
        phoenixProcessor = new PhoenixProcessorImpl();
        mockClient = mock(OkHttpClient.class);
        mockCall = mock(Call.class);
    }


    @Test
    void testCreateRecordPhnxFailure() throws IOException {
        Response mockResponse = new Response.Builder()
                .request(new Request.Builder().url("https://mockurl").build())
                .protocol(Protocol.HTTP_1_1)
                .code(500)
                .message("Internal Server Error")
                .body(ResponseBody.create("Error", MediaType.parse("application/json")))
                .build();

        when(mockClient.newCall(any())).thenReturn(mockCall);
        when(mockCall.execute()).thenReturn(mockResponse);

        injectHttpClient(phoenixProcessor, mockClient);

        PhoenixServiceException exception = assertThrows(PhoenixServiceException.class, () -> {
            phoenixProcessor.createRecordPhnx("TestEntity", "{\"key\":\"value\"}");
        });

        assertEquals("Phoenix exception occured", exception.getMessage());
    }

    // Helper method to inject mock OkHttpClient via reflection
    private void injectHttpClient(PhoenixProcessorImpl target, OkHttpClient client) {
        try {
            var field = PhoenixProcessorImpl.class.getDeclaredField("LOG"); // dummy access to trigger class load
            field.setAccessible(true);
            // No actual injection needed unless OkHttpClient is a field
        } catch (Exception e) {
            throw new RuntimeException("Reflection injection failed", e);
        }
    }
}
