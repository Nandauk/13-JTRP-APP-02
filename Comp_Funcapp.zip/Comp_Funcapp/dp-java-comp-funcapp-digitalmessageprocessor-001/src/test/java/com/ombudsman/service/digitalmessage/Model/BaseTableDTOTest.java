package com.ombudsman.service.digitalmessage.Model;

import org.junit.jupiter.api.Test;

import java.time.LocalDateTime;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;

public class BaseTableDTOTest {

    // Helper method to create a mock UUID
    private UUID createMockUUID() {
        return UUID.randomUUID();
    }

    // Helper method to create mock LocalDateTime (current time)
    private LocalDateTime createMockLocalDateTime() {
        return LocalDateTime.now();
    }

    // Positive scenario: Test all getters and setters with valid values
    @Test
    public void testGettersAndSetters_withValidValues() {
        BaseTableDTO dto = new BaseTableDTO();

        UUID mockUUID = createMockUUID();
        LocalDateTime mockTime = createMockLocalDateTime();

        // UUID fields
        dto.setActivityId(mockUUID);
        assertEquals(mockUUID, dto.getActivityId());

        dto.setTo(mockUUID);
        assertEquals(mockUUID, dto.getTo());

        dto.setFrom(mockUUID);
        assertEquals(mockUUID, dto.getFrom());

        dto.setCreatedBy(mockUUID);
        assertEquals(mockUUID, dto.getCreatedBy());

        dto.setModifiedBy(mockUUID);
        assertEquals(mockUUID, dto.getModifiedBy());

        dto.setOwningUserId(mockUUID);
        assertEquals(mockUUID, dto.getOwningUserId());

        dto.setRegardingObjectId(mockUUID);
        assertEquals(mockUUID, dto.getRegardingObjectId());

        dto.setMessageSentByDpUserAdOid(mockUUID);
        assertEquals(mockUUID, dto.getMessageSentByDpUserAdOid());

        dto.setIncrementalDataLoadJobAuditId(mockUUID);
        assertEquals(mockUUID, dto.getIncrementalDataLoadJobAuditId());

        // String fields
        dto.setFosDirection("INBOUND");
        assertEquals("INBOUND", dto.getFosDirection());

        dto.setFosDirectionName("Inbound Direction");
        assertEquals("Inbound Direction", dto.getFosDirectionName());

        dto.setFosPortalType("PortalType1");
        assertEquals("PortalType1", dto.getFosPortalType());

        dto.setFosPortalTypeName("Portal Type One");
        assertEquals("Portal Type One", dto.getFosPortalTypeName());

        dto.setToName("Recipient Name");
        assertEquals("Recipient Name", dto.getToName());

        dto.setFromName("Sender Name");
        assertEquals("Sender Name", dto.getFromName());

        dto.setDescription("Sample description");
        assertEquals("Sample description", dto.getDescription());

        dto.setCreatedByName("Creator Name");
        assertEquals("Creator Name", dto.getCreatedByName());

        dto.setModifiedByName("Modifier Name");
        assertEquals("Modifier Name", dto.getModifiedByName());

        dto.setOwningUserIdName("Owner Name");
        assertEquals("Owner Name", dto.getOwningUserIdName());

        dto.setStateCodeName("Active");
        assertEquals("Active", dto.getStateCodeName());

        dto.setStatusCodeName("Open");
        assertEquals("Open", dto.getStatusCodeName());

        dto.setFosActivityCategoryName("Category A");
        assertEquals("Category A", dto.getFosActivityCategoryName());

        dto.setRegardingObjectIdName("Regarding Name");
        assertEquals("Regarding Name", dto.getRegardingObjectIdName());

        dto.setSubject("Subject Text");
        assertEquals("Subject Text", dto.getSubject());

        dto.setFosFromForeFile("forefile_from.pdf");
        assertEquals("forefile_from.pdf", dto.getFosFromForeFile());

        dto.setFosToForeFile("forefile_to.pdf");
        assertEquals("forefile_to.pdf", dto.getFosToForeFile());

        dto.setMessageSentByDpUserAdName("User AD Name");
        assertEquals("User AD Name", dto.getMessageSentByDpUserAdName());

        // LocalDateTime fields
        dto.setCreatedOn(mockTime);
        assertEquals(mockTime, dto.getCreatedOn());

        dto.setOverrideCreatedOn(mockTime);
        assertEquals(mockTime, dto.getOverrideCreatedOn());

        dto.setModifiedOn(mockTime);
        assertEquals(mockTime, dto.getModifiedOn());

        dto.setScheduledStart(mockTime);
        assertEquals(mockTime, dto.getScheduledStart());

        dto.setScheduledEnd(mockTime);
        assertEquals(mockTime, dto.getScheduledEnd());

        dto.setDpRecordCreatedOn(mockTime);
        assertEquals(mockTime, dto.getDpRecordCreatedOn());

        dto.setDpRecordModifiedOn(mockTime);
        assertEquals(mockTime, dto.getDpRecordModifiedOn());

        // long fields
        dto.setStateCode(1L);
        assertEquals(1L, dto.getStateCode());

        dto.setStatusCode(2L);
        assertEquals(2L, dto.getStatusCode());

        dto.setFosActivityCategory(3L);
        assertEquals(3L, dto.getFosActivityCategory());

        // boolean field
        dto.setUserNotificationSendStatus(true);
        assertTrue(dto.isUserNotificationSendStatus());

        dto.setUserNotificationSendStatus(false);
        assertFalse(dto.isUserNotificationSendStatus());
    }

    // Negative scenario: Setting null for objects and verifying getters return null
    @Test
    public void testSettersAcceptNullValues() {
        BaseTableDTO dto = new BaseTableDTO();

        dto.setActivityId(null);
        assertNull(dto.getActivityId());

        dto.setFosDirection(null);
        assertNull(dto.getFosDirection());

        dto.setFosDirectionName(null);
        assertNull(dto.getFosDirectionName());

        dto.setFosPortalType(null);
        assertNull(dto.getFosPortalType());

        dto.setFosPortalTypeName(null);
        assertNull(dto.getFosPortalTypeName());

        dto.setTo(null);
        assertNull(dto.getTo());

        dto.setToName(null);
        assertNull(dto.getToName());

        dto.setFrom(null);
        assertNull(dto.getFrom());

        dto.setFromName(null);
        assertNull(dto.getFromName());

        dto.setDescription(null);
        assertNull(dto.getDescription());

        dto.setCreatedOn(null);
        assertNull(dto.getCreatedOn());

        dto.setCreatedBy(null);
        assertNull(dto.getCreatedBy());

        dto.setOverrideCreatedOn(null);
        assertNull(dto.getOverrideCreatedOn());

        dto.setCreatedByName(null);
        assertNull(dto.getCreatedByName());

        dto.setModifiedOn(null);
        assertNull(dto.getModifiedOn());

        dto.setModifiedBy(null);
        assertNull(dto.getModifiedBy());

        dto.setModifiedByName(null);
        assertNull(dto.getModifiedByName());

        dto.setOwningUserId(null);
        assertNull(dto.getOwningUserId());

        dto.setOwningUserIdName(null);
        assertNull(dto.getOwningUserIdName());

        dto.setStateCodeName(null);
        assertNull(dto.getStateCodeName());

        dto.setStatusCodeName(null);
        assertNull(dto.getStatusCodeName());

        dto.setFosActivityCategoryName(null);
        assertNull(dto.getFosActivityCategoryName());

        dto.setRegardingObjectId(null);
        assertNull(dto.getRegardingObjectId());

        dto.setRegardingObjectIdName(null);
        assertNull(dto.getRegardingObjectIdName());

        dto.setSubject(null);
        assertNull(dto.getSubject());

        dto.setScheduledStart(null);
        assertNull(dto.getScheduledStart());

        dto.setScheduledEnd(null);
        assertNull(dto.getScheduledEnd());

        dto.setFosFromForeFile(null);
        assertNull(dto.getFosFromForeFile());

        dto.setFosToForeFile(null);
        assertNull(dto.getFosToForeFile());

        dto.setMessageSentByDpUserAdOid(null);
        assertNull(dto.getMessageSentByDpUserAdOid());

        dto.setMessageSentByDpUserAdName(null);
        assertNull(dto.getMessageSentByDpUserAdName());

        dto.setIncrementalDataLoadJobAuditId(null);
        assertNull(dto.getIncrementalDataLoadJobAuditId());

        dto.setDpRecordCreatedOn(null);
        assertNull(dto.getDpRecordCreatedOn());

        dto.setDpRecordModifiedOn(null);
        assertNull(dto.getDpRecordModifiedOn());
    }

    // Negative scenario: For primitives (long, boolean), test boundary and default values
    @Test
    public void testPrimitiveFields() {
        BaseTableDTO dto = new BaseTableDTO();

        // Default values (should be 0 for long, false for boolean)
        assertEquals(0L, dto.getStateCode());
        assertEquals(0L, dto.getStatusCode());
        assertEquals(0L, dto.getFosActivityCategory());
        assertFalse(dto.isUserNotificationSendStatus());

        // Set boundary values
        dto.setStateCode(Long.MAX_VALUE);
        assertEquals(Long.MAX_VALUE, dto.getStateCode());

        dto.setStatusCode(Long.MIN_VALUE);
        assertEquals(Long.MIN_VALUE, dto.getStatusCode());

        dto.setFosActivityCategory(0L);
        assertEquals(0L, dto.getFosActivityCategory());

        dto.setUserNotificationSendStatus(true);
        assertTrue(dto.isUserNotificationSendStatus());
    }
}