package com.ombudsman.service.digitalmessage.Response;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class MailjetResponseBodyTest {

    private MailjetResponseBody mailjetResponseBody;
    private ObjectMapper objectMapper;

    @BeforeEach
    void setUp() {
        mailjetResponseBody = new MailjetResponseBody();
        objectMapper = new ObjectMapper();
    }

    @Test
    void testCreateMailjetResponseBody() {
        // Create test data
        List<MailjetResponseBody.Message> messages = new ArrayList<>();
        
        // Create first message
        MailjetResponseBody.Message message1 = new MailjetResponseBody.Message();
        message1.setStatus("success");
        message1.setCustomID("custom-123");
        
        // Create recipients
        List<MailjetResponseBody.Recipient> recipients = new ArrayList<>();
        MailjetResponseBody.Recipient recipient = new MailjetResponseBody.Recipient();
        recipient.setEmail("test@example.com");
        recipient.setMessageUUID("uuid-123");
        recipient.setMessageID(12345L);
        recipient.setMessageHref("https://example.com/message");
        recipients.add(recipient);
        
        message1.setTo(recipients);
        message1.setCc(new ArrayList<>());
        message1.setBcc(new ArrayList<>());
        
        messages.add(message1);
        
        // Set messages to response body
        mailjetResponseBody.setMessages(messages);

        // Assertions
        assertNotNull(mailjetResponseBody.getMessages());
        assertEquals(1, mailjetResponseBody.getMessages().size());
        
        MailjetResponseBody.Message retrievedMessage = mailjetResponseBody.getMessages().get(0);
        assertEquals("success", retrievedMessage.getStatus());
        assertEquals("custom-123", retrievedMessage.getCustomID());
        
        // Recipient assertions
        List<MailjetResponseBody.Recipient> retrievedRecipients = retrievedMessage.getTo();
        assertNotNull(retrievedRecipients);
        assertEquals(1, retrievedRecipients.size());
        
        MailjetResponseBody.Recipient retrievedRecipient = retrievedRecipients.get(0);
        assertEquals("test@example.com", retrievedRecipient.getEmail());
        assertEquals("uuid-123", retrievedRecipient.getMessageUUID());
        assertEquals(12345L, retrievedRecipient.getMessageID());
        assertEquals("https://example.com/message", retrievedRecipient.getMessageHref());
    }

    @Test
    void testToString() {
        // Create test data
        List<MailjetResponseBody.Message> messages = new ArrayList<>();
        MailjetResponseBody.Message message = new MailjetResponseBody.Message();
        message.setStatus("success");
        message.setCustomID("custom-123");
        messages.add(message);
        
        mailjetResponseBody.setMessages(messages);

        // Test toString method
        String toString = mailjetResponseBody.toString();
        assertNotNull(toString);
        assertTrue(toString.contains("Message :"));
        assertTrue(toString.contains("success"));
        assertTrue(toString.contains("custom-123"));
    }

    @Test
    void testMessageToString() {
        // Create test data
        MailjetResponseBody.Message message = new MailjetResponseBody.Message();
        message.setStatus("success");
        message.setCustomID("custom-123");
        
        // Create recipients
        List<MailjetResponseBody.Recipient> toRecipients = new ArrayList<>();
        MailjetResponseBody.Recipient toRecipient = new MailjetResponseBody.Recipient();
        toRecipient.setEmail("to@example.com");
        toRecipients.add(toRecipient);
        
        List<MailjetResponseBody.Recipient> ccRecipients = new ArrayList<>();
        MailjetResponseBody.Recipient ccRecipient = new MailjetResponseBody.Recipient();
        ccRecipient.setEmail("cc@example.com");
        ccRecipients.add(ccRecipient);
        
        message.setTo(toRecipients);
        message.setCc(ccRecipients);
        message.setBcc(new ArrayList<>());

        // Test toString method
        String toString = message.toString();
        assertNotNull(toString);
        assertTrue(toString.contains("Status: success"));
        assertTrue(toString.contains("CustomID: custom-123"));
        assertTrue(toString.contains("to@example.com"));
        assertTrue(toString.contains("cc@example.com"));
    }

    @Test
    void testRecipientToString() {
        // Create test data
        MailjetResponseBody.Recipient recipient = new MailjetResponseBody.Recipient();
        recipient.setEmail("test@example.com");
        recipient.setMessageUUID("uuid-123");
        recipient.setMessageID(12345L);
        recipient.setMessageHref("https://example.com/message");

        // Test toString method
        String toString = recipient.toString();
        assertNotNull(toString);
        assertTrue(toString.contains("email: test@example.com"));
        assertTrue(toString.contains("messageUUID: uuid-123"));
        assertTrue(toString.contains("messageID : 12345"));
        assertTrue(toString.contains("messageHref : https://example.com/message"));
    }

    @Test
    void testJsonSerialization() throws Exception {
        // Create test data
        MailjetResponseBody responseBody = new MailjetResponseBody();
        List<MailjetResponseBody.Message> messages = new ArrayList<>();
        
        MailjetResponseBody.Message message = new MailjetResponseBody.Message();
        message.setStatus("success");
        message.setCustomID("custom-123");
        
        List<MailjetResponseBody.Recipient> recipients = new ArrayList<>();
        MailjetResponseBody.Recipient recipient = new MailjetResponseBody.Recipient();
        recipient.setEmail("test@example.com");
        recipient.setMessageUUID("uuid-123");
        recipient.setMessageID(12345L);
        recipient.setMessageHref("https://example.com/message");
        recipients.add(recipient);
        
        message.setTo(recipients);
        messages.add(message);
        
        responseBody.setMessages(messages);

        // Serialize to JSON
        String json = objectMapper.writeValueAsString(responseBody);
        assertNotNull(json);
        
        // Deserialize back to object
        MailjetResponseBody deserializedBody = objectMapper.readValue(json, MailjetResponseBody.class);
        assertNotNull(deserializedBody);
        assertNotNull(deserializedBody.getMessages());
        assertEquals(1, deserializedBody.getMessages().size());
        
        MailjetResponseBody.Message deserializedMessage = deserializedBody.getMessages().get(0);
        assertEquals("success", deserializedMessage.getStatus());
        assertEquals("custom-123", deserializedMessage.getCustomID());
    }

    @Test
    void testEmptyResponseBody() {
        // Create an empty response body
        MailjetResponseBody emptyResponseBody = new MailjetResponseBody();
        emptyResponseBody.setMessages(new ArrayList<>());

        // Assertions
        assertNotNull(emptyResponseBody.getMessages());
        assertTrue(emptyResponseBody.getMessages().isEmpty());
        
        // Test toString for empty response
        String toString = emptyResponseBody.toString();
        assertNotNull(toString);
        assertTrue(toString.contains("Message :[]"));
    }
}