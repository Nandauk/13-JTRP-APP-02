package com.ombudsman.service.digitalmessage.component;

import com.ombudsman.service.digitalmessage.Model.*;
import com.ombudsman.service.digitalmessage.Response.MailjetResponseBody;
import com.ombudsman.service.digitalmessage.exception.MailJetServiceException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.MockitoAnnotations;
import org.springframework.http.MediaType;
import org.springframework.web.reactive.function.BodyInserter;
import org.springframework.web.reactive.function.client.*;

import reactor.core.publisher.Mono;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class SendEmailNotificationBodyTest {

    @InjectMocks
    private SendEmailNotificationBody sendEmailNotificationBody;

    @Mock
    private WebClient webClient;

    @Mock
    private WebClient.RequestBodyUriSpec uriSpec;

    @Mock
    private WebClient.RequestBodySpec bodySpec;

    @Mock
    private WebClient.ResponseSpec responseSpec;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        }

    @Test
    void testSetIfNotEmpty() {
        MailjetVariables var = new MailjetVariables();
        sendEmailNotificationBody.setIfNotEmpty("value", var::setPortal_User);
        assertEquals("value", var.getPortal_User());
    }

    @Test
    void testSendSuccess() throws Exception {
        SendMailReq req = new SendMailReq();
        Messages message = new Messages();
        message.setTemplateID(12345L);
        List<Messages> messages = new ArrayList<>();
        messages.add(message);
        req.setMessages(messages);

        MailjetResponseBody mockResponse = new MailjetResponseBody();
        MailjetResponseBody.Message status = new MailjetResponseBody.Message();
        status.setStatus("success");
        mockResponse.setMessages(List.of(status));

        try (MockedStatic<WebClient> webClientStatic = mockStatic(WebClient.class)) {
            webClientStatic.when(WebClient::create).thenReturn(webClient);

            when(webClient.post()).thenReturn(uriSpec);
            when(uriSpec.uri(anyString())).thenReturn(bodySpec);
            when(bodySpec.body(any(BodyInserter.class))).thenReturn(bodySpec);
            when(bodySpec.accept(any())).thenReturn(bodySpec);
            when(bodySpec.retrieve()).thenReturn(responseSpec);
            when(responseSpec.bodyToMono(MailjetResponseBody.class)).thenReturn(Mono.just(mockResponse));

            String result = sendEmailNotificationBody.send(req);
            assertEquals("success", result);
        }
    }

    @Test
    void testSendFailure() {
        SendMailReq req = new SendMailReq();
        Messages message = new Messages();
        message.setTemplateID(12345L);
        req.setMessages(List.of(message));

        try (MockedStatic<WebClient> webClientStatic = mockStatic(WebClient.class)) {
            webClientStatic.when(WebClient::create).thenReturn(webClient);

            when(webClient.post()).thenReturn(uriSpec);
            when(uriSpec.uri(anyString())).thenReturn(bodySpec);
            when(bodySpec.body(any(BodyInserter.class))).thenReturn(bodySpec);
            when(bodySpec.accept(any())).thenReturn(bodySpec);
            when(bodySpec.retrieve()).thenReturn(responseSpec);
            when(responseSpec.bodyToMono(MailjetResponseBody.class))
                    .thenThrow(new RuntimeException("WebClient error"));

            assertThrows(MailJetServiceException.class, () -> sendEmailNotificationBody.send(req));
        }
    }
}
