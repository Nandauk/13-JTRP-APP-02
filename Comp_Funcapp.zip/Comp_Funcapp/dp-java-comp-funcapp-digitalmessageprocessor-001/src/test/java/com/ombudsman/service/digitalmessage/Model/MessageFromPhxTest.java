package com.ombudsman.service.digitalmessage.Model;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

public class MessageFromPhxTest {

    @Test
    void testIncrementalobAuditIDGetterSetter() {
        MessageFromPhx message = new MessageFromPhx();
        String expectedId = "AUDIT123";

        message.setIncrementalobAuditID(expectedId);

        assertEquals(expectedId, message.getIncrementalobAuditID());
    }
}
