package com.ombudsman.service.digitalmessage.Model;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class DpSupportQueueMessageTest {

  
    @Test
    public void testGettersAndSetters_withValidStrings() {
        DpSupportQueueMessage message = new DpSupportQueueMessage();

        // Set and assert all string fields with normal values
        message.setTempDigitalMessageProcessingId("tempId123");
        assertEquals("tempId123", message.getTempDigitalMessageProcessingId());

        message.setCaseReferenceNumberIncidentId("caseRef456");
        assertEquals("caseRef456", message.getCaseReferenceNumberIncidentId());

        message.setFailedSbMessageId("failedMsg789");
        assertEquals("failedMsg789", message.getFailedSbMessageId());

        message.setSource("SystemA");
        assertEquals("SystemA", message.getSource());

        message.setErrorInfo("ErrorCode404");
        assertEquals("ErrorCode404", message.getErrorInfo());

        message.setErrorDetails("Detailed error message");
        assertEquals("Detailed error message", message.getErrorDetails());

        message.setDateTimeErrorOccurred("2024-01-01T10:15:30");
        assertEquals("2024-01-01T10:15:30", message.getDateTimeErrorOccurred());

        // Set empty strings and verify
        message.setTempDigitalMessageProcessingId("");
        assertEquals("", message.getTempDigitalMessageProcessingId());

        message.setCaseReferenceNumberIncidentId("");
        assertEquals("", message.getCaseReferenceNumberIncidentId());
    }

    // Negative test: Setting null and verifying getters return null
    @Test
    public void testSettersAcceptNullValues() {
        DpSupportQueueMessage message = new DpSupportQueueMessage();

        message.setTempDigitalMessageProcessingId(null);
        assertNull(message.getTempDigitalMessageProcessingId());

        message.setCaseReferenceNumberIncidentId(null);
        assertNull(message.getCaseReferenceNumberIncidentId());

        message.setFailedSbMessageId(null);
        assertNull(message.getFailedSbMessageId());

        message.setSource(null);
        assertNull(message.getSource());

        message.setErrorInfo(null);
        assertNull(message.getErrorInfo());

        message.setErrorDetails(null);
        assertNull(message.getErrorDetails());

        message.setDateTimeErrorOccurred(null);
        assertNull(message.getDateTimeErrorOccurred());
    }

    // Additional test: Validate typical date time format string usage
    @Test
    public void testDateTimeErrorOccurredFormat() {
        DpSupportQueueMessage message = new DpSupportQueueMessage();
        String validDateTime = "2024-06-15T08:30:00";

        message.setDateTimeErrorOccurred(validDateTime);
        assertEquals(validDateTime, message.getDateTimeErrorOccurred());

        // While the field accepts any string, you could add format validations here if implemented in future
    }
}