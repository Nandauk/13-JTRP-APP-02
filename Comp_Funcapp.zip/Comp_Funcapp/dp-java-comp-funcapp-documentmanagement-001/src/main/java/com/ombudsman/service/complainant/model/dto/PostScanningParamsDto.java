package com.ombudsman.service.complainant.model.dto;

import java.util.List;

public class PostScanningParamsDto {
	private String packageId ;
	private List<ScanResultDto> scanningResults ;
	private UploadCompletedMessageDto message ;
	private boolean ingestionMessageSent;
	
	public String getPackageId() {
		return packageId;
	}
	public void setPackageId(String packageId) {
		this.packageId = packageId;
	}
	public List<ScanResultDto> getScanningResults() {
		return scanningResults;
	}
	public void setScanningResults(List<ScanResultDto> scanningResults) {
		this.scanningResults = scanningResults;
	}
	public UploadCompletedMessageDto getMessage() {
		return message;
	}
	public void setMessage(UploadCompletedMessageDto message) {
		this.message = message;
	}
	public boolean isIngestionMessageSent() {
		return ingestionMessageSent;
	}
	public void setIngestionMessageSent(boolean ingestionMessageSent) {
		this.ingestionMessageSent = ingestionMessageSent;
	}
    
    
	
    
    
    
}
