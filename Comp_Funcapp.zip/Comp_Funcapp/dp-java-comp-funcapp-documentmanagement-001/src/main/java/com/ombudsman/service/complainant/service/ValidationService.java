package com.ombudsman.service.complainant.service;

import java.util.List;

import com.microsoft.azure.functions.OutputBinding;
import com.ombudsman.service.complainant.model.dto.PostScanningParamsDto;
import com.ombudsman.service.complainant.model.dto.UploadCompletedMessageDto;

public interface ValidationService {

	
	
	public boolean postScanning(PostScanningParamsDto postScanningParams, OutputBinding<String> outputMessage);
	public List<String> preScanning(UploadCompletedMessageDto message);


}
