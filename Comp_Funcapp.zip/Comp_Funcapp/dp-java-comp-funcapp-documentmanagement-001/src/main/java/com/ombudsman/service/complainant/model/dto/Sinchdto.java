package com.ombudsman.service.complainant.model.dto;

public class Sinchdto {

	String communicationPreference;
	String mobileNumber;
	public String getCommunicationPreference() {
		return communicationPreference;
	}
	public void setCommunicationPreference(String communicationPreference) {
		this.communicationPreference = communicationPreference;
	}
	public String getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	
	
}
