package com.ombudsman.service.complainant.model;

import java.time.LocalDateTime;
import java.time.OffsetDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Entity
@Table(name = "dp_complainant_user_notification")
@Data
public class Notification {

	@Id
	@Column(name = "notification_id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long notification_id;
	private String request_id;
	private String user_oid;
	private String requesting_activity_name;
	private String message;
	private int notification_status_id;
	private String file_download_url;
	private String modified_by;
	private String created_on;
	private String created_by;
	private String modified_on;

	public Long getNotification_id() {
		return notification_id;
	}

	public void setNotification_id(Long notification_id) {
		this.notification_id = notification_id;
	}

	public String getRequest_id() {
		return request_id;
	}

	public void setRequest_id(String request_id) {
		this.request_id = request_id;
	}

	public String getUser_oid() {
		return user_oid;
	}

	public void setUser_oid(String user_oid) {
		this.user_oid = user_oid;
	}

	public String getRequesting_activity_name() {
		return requesting_activity_name;
	}

	public void setRequesting_activity_name(String requesting_activity_name) {
		this.requesting_activity_name = requesting_activity_name;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public int getNotification_status_id() {
		return notification_status_id;
	}

	public void setNotification_status_id(int notification_status_id) {
		this.notification_status_id = notification_status_id;
	}

	public String getFile_download_url() {
		return file_download_url;
	}

	public void setFile_download_url(String file_download_url) {
		this.file_download_url = file_download_url;
	}

	public String getModified_by() {
		return modified_by;
	}

	public void setModified_by(String modified_by) {
		this.modified_by = modified_by;
	}

	

	public String getCreated_on() {
		return created_on;
	}

	public void setCreated_on(String offsetDateTime) {
		this.created_on = offsetDateTime;
	}

	public String getCreated_by() {
		return created_by;
	}

	public void setCreated_by(String created_by) {
		this.created_by = created_by;
	}

	public String getModified_on() {
		return modified_on;
	}

	public void setModified_on(String modified_on) {
		this.modified_on = modified_on;
	}

}
