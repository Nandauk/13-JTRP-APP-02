package com.ombudsman.service.complainant.serviceimpl;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.text.StringEscapeUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONException;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.WebClient;

import com.azure.storage.blob.BlobClient;
import com.azure.storage.blob.BlobContainerClient;
import com.azure.storage.blob.BlobServiceClientBuilder;
import com.google.gson.Gson;
import com.microsoft.azure.functions.OutputBinding;
import com.ombudsman.service.complainant.exception.MailJetServiceException;
import com.ombudsman.service.complainant.helper.ValidationServiceHelper;
import com.ombudsman.service.complainant.model.EmailNotificationResponse;
import com.ombudsman.service.complainant.model.From;
import com.ombudsman.service.complainant.model.GetResponseMessage;
import com.ombudsman.service.complainant.model.MailjetResponseBody;
import com.ombudsman.service.complainant.model.MailjetVariables;
import com.ombudsman.service.complainant.model.Messages;
import com.ombudsman.service.complainant.model.Notification;
import com.ombudsman.service.complainant.model.SendMailReq;
import com.ombudsman.service.complainant.model.To;
import com.ombudsman.service.complainant.model.UserMailjetRequest;
import com.ombudsman.service.complainant.model.dto.PostScanningParamsDto;
import com.ombudsman.service.complainant.model.dto.ScanResultDto;
import com.ombudsman.service.complainant.model.dto.SinchApiRequest;
import com.ombudsman.service.complainant.model.dto.Sinchdto;
import com.ombudsman.service.complainant.model.dto.UploadCompletedMessageDto;
import com.ombudsman.service.complainant.model.dto.UploadFileInfoDto;
import com.ombudsman.service.complainant.model.request.UploadRequestFile;
import com.ombudsman.service.complainant.service.ValidationService;

import reactor.core.publisher.Mono;

@Service
public class ValidationServiceImpl implements ValidationService {

	static Logger log = LogManager.getRootLogger();
	ValidationServiceHelper validationServiceHelper = new ValidationServiceHelper();
	private static final String get_token_status = "SELECT TOP 1 token_status FROM dp_complainant_user_session WHERE oid=? ORDER BY last_activity_datetime DESC";
	private static final String SQLQUERY_TO_UPDATE_UPLOAD_STATUS = "Update dp_complainant_upload_request_files SET status = 'Failed',is_uploaded='Failed' where complainant_upload_requests_id = ?";
	private static final String SQLQUERY_TO_UPDATE_ctaTriggred = "Update dp_complainant_upload_requests SET cta_triggred = 'true' where package_id = ?";
	private static final String select_ctaTriggred = "select cta_triggred from dp_complainant_upload_requests where package_id = ?";
	private static final String SQLQUERY_communication_preference = "Select communication_preference from [dbo].[dp_user_dpcomplainant] where oid = ?";
	private static final String SQLQUERY_mobile_number = "select mobile_number from [dbo].[dp_user_dpcomplainant] where oid =?";
	public static final String FAILURESMSTEXT = "Something you tried to do in Ombudsman Connect didn't work. Please log in to review what's happened. Kind regards. The Financial Ombudsman Service. Sign in ";
	JdbcTemplate jdbcTemplate = jdbcConnection();

	@Override
	public boolean postScanning(PostScanningParamsDto postScanningParams, OutputBinding<String> outputMessage) {
		Boolean okToSendForUpload = false;
		try {
			int count = 0;
			log.info(String.format("postScanning started :: PackageId :-%s", postScanningParams.getPackageId()));
			List<String> badFiles = new ArrayList<>();
			List<String> cleanFiles = new ArrayList<>();
			List<ScanResultDto> scanningResults = postScanningParams.getScanningResults();
			List<ScanResultDto> scanResultDtoList = new ArrayList<>();

			for (ScanResultDto scanResultDto : scanningResults) {
				if (!scanResultDto.getClean()) {
					log.info(String.format("badfile is present "));
					count++;
					badFiles.add(postScanningParams.getPackageId() + "/" + scanResultDto.getDocumentId());
					// validationServiceHelper.moveFolderActivity(postScanningParams.getPackageId());
					// vservice.deleteFilesfromSourceContainer(postScanningParams);
					log.info(String.format("bad file count :-%s", count));
				} else {
					log.info(String.format("Post Scanning inside else   :-%s", count));
					log.info(String.format("PostScanninginside else scanResultDto.getClean()  :-%s",
							scanResultDto.getClean()));
					log.info(String.format("Document IDs Added inside else  :-%s", scanResultDto.getDocumentId()));
					if (scanResultDto.getClean()) {
						scanResultDtoList.add(scanResultDto);
						log.info(String.format("clean file is present "));
						cleanFiles.add(postScanningParams.getPackageId() + "/" + scanResultDto.getDocumentId());
						log.info(String.format("added clean file successfully  :-%s",
								postScanningParams.getPackageId() + "/" + scanResultDto.getDocumentId()));
					}
					log.info(String.format("clean file count :-%s", cleanFiles.size()));

				}
			}

			if (!badFiles.isEmpty()) {
				log.info(String.format("getting bad file, moving dpfile to quartine container"));
				// int countBadfile =
				// validationServiceHelper.deleteBadFilesfromSourceContainer(badFiles,System.getenv("QUARATINE_CONTAINER"));
				validationServiceHelper.moveFile(cleanFiles, System.getenv("DPFILE_CONTAINER"),
						System.getenv("QUARATINE_CONTAINER"));
				log.info("moveFile dpfile to quartine successfully");
			}
			if (!cleanFiles.isEmpty()) {
				log.info(String.format("getting clean file, moving dpfile to upload container"));
				validationServiceHelper.moveFile(cleanFiles, System.getenv("DPFILE_CONTAINER"),
						System.getenv("UPLOAD_CONTAINER"));
				// validationServiceHelper.moveFile(postlist,System.getenv("QUARATINE_CONTAINER"),
				// System.getenv("UPLOAD_CONTAINER"));
				log.info("moveFile dpfile to upload successfully");
			}

			log.info(String.format("bad file  :-%s", badFiles));
			validationServiceHelper.deletefileFromContainer(badFiles, System.getenv("DPFILE_CONTAINER"));
			log.info(String.format("delete bad file From dpfile "));
			log.info(String.format("clean file  :-%s", cleanFiles));
			validationServiceHelper.deletefileFromContainer(cleanFiles, System.getenv("DPFILE_CONTAINER"));
			log.info(String.format("delete clean file From dpfile "));
			int value = validationServiceHelper.prepareForIngestion(postScanningParams,
					System.getenv("UPLOAD_CONTAINER"));
			// postScanningParams.setScanningResults(cleanF)
			postScanningParams.setScanningResults(scanResultDtoList);
			log.info(String.format("PrepareForSendForUploadActivity end  :-%s", value));
			if (value > 0) {
				List<UploadFileInfoDto> baddocument = new ArrayList();
				UploadCompletedMessageDto message = postScanningParams.getMessage();
				List<UploadFileInfoDto> files = message.getFiles();
				if (!files.isEmpty()) {
					for (UploadFileInfoDto uploadFileInfoDto : files) {
						if (!cleanFiles.isEmpty() && cleanFiles.contains(
								postScanningParams.getPackageId() + "/" + uploadFileInfoDto.getDocumentId())) {
							log.info(String.format("document id is clean  :-%s", uploadFileInfoDto.getDocumentId()));
						} else {
							if (!cleanFiles.isEmpty() && !(cleanFiles.contains(
									postScanningParams.getPackageId() + "/" + uploadFileInfoDto.getDocumentId()))) {
								log.info(String.format("documentid is not clean  :-%s",
										uploadFileInfoDto.getDocumentId()));
								baddocument.add(uploadFileInfoDto);
							}
						}
					}

					files.removeAll(baddocument);
				}
				message.setFiles(files);
				log.info(String.format("message for postscanning  :-%s", message));
				Boolean ingestionMessageSent = validationServiceHelper.sendPortalActivityAddedMessage(message,
						outputMessage);
				log.info(String.format("Setting ingestionMessage in postScanningParams Model :-%s",
						ingestionMessageSent));
				log.info(String.format("package ID when setIngestionMessageSent  :-%s",
						postScanningParams.getPackageId()));
				postScanningParams.setIngestionMessageSent(ingestionMessageSent);
			}
			validationServiceHelper.updateRequest(postScanningParams);
		} catch (Exception ex) {
			log.info(String.format("Error in PostScanning Method :-%s", ex.getMessage()));
		}
		log.info(String.format("PostScanning Method  ended  :-%s", postScanningParams));
		return okToSendForUpload;

	}

	@Override
	public List<String> preScanning(UploadCompletedMessageDto message) {
		log.info(String.format("preScanning Method Started :: package id :-%s", message.getPackageId()));
		validationServiceHelper.removeCancelledFiles(message.getPackageId(), message.getUploadRequestId(),
				System.getenv("DPFILE_CONTAINER"));
		// List<String> filesCopiedToUploadContainer =
		// validationServiceHelper.moveFolderActivity(message.getPackageId());
		List<String> filesCopiedToScanContainer = validationServiceHelper.moveFolderToScan(message.getPackageId());
		log.info(String.format("preScanning Method Ended ::filesCopieddpfileToScanContainer :-%s",
				filesCopiedToScanContainer));
		return filesCopiedToScanContainer;
	}

	public void sendInvite(UploadCompletedMessageDto dto, GetResponseMessage genericResponse) throws SQLException {

		Notification notification = new Notification();
		// UTC time
		ZonedDateTime utcTime = ZonedDateTime.now(ZoneId.of("UTC"));
		log.info("Notification Update Started in Azure Function ");
		notification.setModified_on(utcTime.toLocalDateTime().toString());
		notification.setRequest_id(dto.getNotificationRequestId());
		notification.setNotification_status_id(3);
		notificationJdbcCall(notification, jdbcTemplate); // custom exception
		log.info("Notification Update Ended in Azure Function ");

		// if user inactive valid session or not
		try {

			Object[] updateDownloadParams = new Object[] { dto.getUploadRequestId() };
			log.info(String.format("params for update Download : %s ", dto.getUploadRequestId()));
			jdbcTemplate.update(SQLQUERY_TO_UPDATE_UPLOAD_STATUS, updateDownloadParams);
			try {

				boolean ctaTriggred = jdbcTemplate.queryForObject(select_ctaTriggred, Boolean.class,
						dto.getPackageId());
				log.info(String.format("ctaTriggred : %s", ctaTriggred));
				Optional<String> tokenstatus = getUserSessionStatus(dto.getUserId(), jdbcTemplate);
				log.info(String.format("tokenstatus 1234 : %s", tokenstatus.isEmpty()?null:tokenstatus.get()));

				SinchApiRequest sinchReq = new SinchApiRequest();
				Sinchdto sinch = sinch(dto.getUserId());

				if (("invalid".equalsIgnoreCase(tokenstatus.get())) && ctaTriggred == false) {
					log.info(String.format("inside not valid status123 : %s", tokenstatus));// sinch started :
					callToActionUpload(dto, sinchReq, sinch);
					Object[] packageParams = new Object[] { dto.getPackageId() };
					log.info(String.format("params for update Download 123  : %s", dto.getPackageId()));
					jdbcTemplate.update(SQLQUERY_TO_UPDATE_ctaTriggred, packageParams);
					log.info(String.format("update ctaTriggred successfully12 "));
				}
			}

			catch (Exception ex) {
				log.info(String.format("error in catch block : %s ", ex.getMessage()));
				Thread.currentThread().interrupt();
			}

		} catch (Exception e) {
			log.info(String.format("line 231 : %s ", e.getMessage()));
		}

	}

	private Optional<String> getUserSessionStatus(String oid, JdbcTemplate templateConnection) {
		log.info("method::getUserSessionStatus  {}", oid);
		String history = "SELECT TOP 1 token_status FROM dp_complainant_user_session_history WHERE oid=? ORDER BY last_activity_datetime DESC";
		String sql = "SELECT TOP 1 token_status FROM dp_complainant_user_session WHERE oid=? ORDER BY last_activity_datetime DESC";
		try {
			log.info("getUserSessionStatus try block  {}", oid);
			return Optional.of(templateConnection.queryForObject(sql, String.class, oid));
		} catch (Exception e) {
			log.info("getUserSessionStatus catch block  {}", oid);
			return Optional.of(templateConnection.queryForObject(history, String.class, oid));
		}

	}

	private void callToActionUpload(UploadCompletedMessageDto dto, SinchApiRequest sinchReq, Sinchdto sinch) {
		if (sinch.getMobileNumber() != null && "phone".equalsIgnoreCase(sinch.getCommunicationPreference())) {
			log.info(String.format("inside phone  :-%s ", sinch.getCommunicationPreference()));
			String failureSMSText = FAILURESMSTEXT + "(" + System.getenv("Portal_SignInUrl") + ")";
			String readable = StringEscapeUtils.unescapeJava(failureSMSText);
			List<String> toNumbers = new ArrayList<>();
			toNumbers.add(sinch.getMobileNumber());
			sinchReq.setTo(toNumbers);
			sinchReq.setBody(readable);
			communicationSmsApiCall(sinchReq);
		} else if (dto.getUserEmail() != null && "email".equalsIgnoreCase(sinch.getCommunicationPreference())) {
			log.info(String.format("inside email  :-%s ", sinch.getCommunicationPreference()));
			UserMailjetRequest inviteRequest = new UserMailjetRequest();
			inviteRequest.setEmailId(dto.getUserEmail());
			inviteRequest.setFullName(dto.getUserName());
			inviteRequest.setPortal_User(fetchfullname(dto.getUserEmail()));
			inviteRequest.setSign_In(System.getenv("Portal_SignInUrl"));
			inviteRequest.setTemplateId(6724496);
			inviteRequest.setTemplateName("Failure Notification");
			SendMailReq contructSendEmailBody = contructSendEmailBody(inviteRequest);
			send(contructSendEmailBody);
		}
	}

	public String fetchfullname(final String emailAdress) {
		final JdbcTemplate jdbcTemplate = jdbcConnection();
		String sql = "SELECT firstname FROM contact WHERE emailaddress1 = ?";
		List<String> result = jdbcTemplate.query(sql, (rs, rowNum) -> rs.getString("firstname"), emailAdress);
		return result.isEmpty() ? null : result.get(0);
	}

	public void communicationSmsApiCall(SinchApiRequest sinchReq) {
		log.info("communcation Send SMS webclient call Started");
		EmailNotificationResponse response = new EmailNotificationResponse();
		try {
			String url = System.getenv("APIM_URL")
					+ "/compcommunicationservice/compcommunicationservice/v1/communicationservice/sendsms";
			log.info(String.format("Communication SendSMS apim url :: %s", url));
			response = WebClient.create().post().uri(url).header("X-API-KEY", "13671429-6adc-4c59-a3cd-b89c85f99611")
					.header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
					.body(Mono.just(sinchReq), SinchApiRequest.class).accept(MediaType.APPLICATION_JSON).retrieve()
					.bodyToMono(EmailNotificationResponse.class).block();
			log.info(String.format("Communication Webclient Method call to Sendsms Ended %s", response.toString()));
		} catch (Exception e) {
			log.info(String.format("Connectivity of communication Webclient Sendsms call  Failed %s", e.getMessage()));

		}

	}

	private Sinchdto sinch(String oid) {
		Sinchdto sinchdto = new Sinchdto();

		try {

			String communication_preference = jdbcTemplate.queryForObject(SQLQUERY_communication_preference,
					String.class, oid);
			log.info(String.format("oid for communication_preference : %s", oid));
			sinchdto.setCommunicationPreference(communication_preference);
			log.info(String.format("role communication_preference :-%s ", communication_preference));
		} catch (Exception e) {
			log.info(String.format("line 301 :-%s ", e.getMessage()));
		}
		try {

			String mobile_number = jdbcTemplate.queryForObject(SQLQUERY_mobile_number, String.class, oid);
			log.info(String.format("oid for communication_preference : %s", oid));
			sinchdto.setMobileNumber(mobile_number);
			log.info(String.format("role :-%s ", mobile_number));
		} catch (Exception e) {
			log.info(String.format("line 194 :-%s ", e.getMessage()));
		}
		return sinchdto;

	}

	public JdbcTemplate jdbcConnection() {
		JdbcTemplate jdbcTemplate = new JdbcTemplate();
		DriverManagerDataSource dataSource = new DriverManagerDataSource();
		dataSource.setDriverClassName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
		dataSource.setUrl(System.getenv("SQL_DATASOURCE_URL"));
		dataSource.setUsername(System.getenv("SQL_DATASOURCE_USERNAME"));
		dataSource.setPassword(System.getenv("SQL_DATASOURCE_PASSWORD"));
		jdbcTemplate = new JdbcTemplate(dataSource);
		return jdbcTemplate;
	}

	public void notificationJdbcCall(Notification notification, JdbcTemplate jdbcTemplate) {
		log.info("notificationJdbcCall method started ");

		try {

			Object[] paramNotification = new Object[] { notification.getModified_on(),
					notification.getNotification_status_id(), notification.getRequest_id() };
			log.info(String.format("paramNotification:-%s", paramNotification));

			String sql = "update dp_complainant_user_notification set modified_on= ?,notification_status_id= ? where request_id= ?";
			log.info(String.format("sql:-%s", sql));

			jdbcTemplate.update(sql, paramNotification);
			log.info(String.format("Notification data updated in Database:-%s", jdbcTemplate));

		} catch (Exception e) {
			log.error("Error in notification {}", e.getMessage());
		}
		log.info("notificationJdbcCall method Ended ");
	}

	public SendMailReq contructSendEmailBody(UserMailjetRequest inviteRequest) {
		log.info("contructSendEmailBody method started ");
		List<To> to = new ArrayList<>();
		To toEmailAddress = new To();
		toEmailAddress.setEmail(inviteRequest.getEmailId());
		toEmailAddress.setName(inviteRequest.getFullName());
		to.add(toEmailAddress);

		Messages message = new Messages();
		message.setTemplateID(inviteRequest.getTemplateId());
		message.setName(inviteRequest.getTemplateName());
		log.info("-----TemplateID and templateName set Inside helper method successfully----");
		message.setTemplateLanguage(true);
		message.setTo(to);

		From fromEmailAddress = new From();
		fromEmailAddress.setEmail(System.getenv("FROM_MAIL"));// No-Reply@DigitalSelfServe.Financial-Ombudsman.org.uk;
		fromEmailAddress.setName("FOS Email Notification");
		message.setFrom(fromEmailAddress);

		MailjetVariables var = new MailjetVariables();

		setIfNotEmpty(inviteRequest.getPortal_User(), var::setPortal_User);
		setIfNotEmpty(inviteRequest.getSign_In(), var::setSign_In);

		log.info("getPortalSigninUrl invite Url %s ", var.getSign_In());

		message.setVar(var);
		List<Messages> sendmessage = new ArrayList<>();
		sendmessage.add(message);
		SendMailReq sendMailReq = new SendMailReq();
		sendMailReq.setMessages(sendmessage);

		log.info("contructSendEmailBody method ended ");
		return sendMailReq;

	}

	public void setIfNotEmpty(String variableValue, Consumer<String> setter) {
		if (!StringUtils.trimToEmpty(variableValue).isEmpty()) {
			setter.accept(variableValue);
			log.info("Value successfully set under variables " + variableValue);
		} else {
			log.info("Value fialed to set  under variables " + variableValue);
		}
	}

	public String send(SendMailReq req) throws JSONException {
		log.info("Mailjet Send request method started");
		Gson gson = new Gson();
		String json = gson.toJson(req);
		MailjetResponseBody responseBody = new MailjetResponseBody();
		String status = null;
		log.info(String.format("Request data for Send API:-%s", json));
		String url = System.getenv("APIM_URL") + "/mailjet/send";
		log.info(String.format("Send API Url :-%s", url));

		try {
			responseBody = WebClient.create().post().uri(url).body(BodyInserters.fromValue(json))
					.accept(MediaType.APPLICATION_JSON).retrieve().bodyToMono(MailjetResponseBody.class).block();
			if (responseBody != null) {
				status = responseBody.getMessages().get(0).getStatus();
				log.info(String.format("Response:-%s", status));
			}
		} catch (Exception ex) {
			log.error("Webclient call failed {}", ex.getMessage());
			throw new MailJetServiceException("Mailjet Exception occured {}", ex.getMessage(), ex.getStackTrace());
		}
		log.info(String.format("responseBody:-%s", responseBody));
		if (null != responseBody) {
			status = responseBody.getMessages().get(0).getStatus();
		}

		return status;

	}

	public Connection connectionjdbc() throws SQLException {
		log.info(String.format("inside Connectionjdbc "));
		return DriverManager.getConnection(System.getenv("SQL_DATASOURCE_URL"),
				System.getenv("SQL_DATASOURCE_USERNAME"), System.getenv("SQL_DATASOURCE_PASSWORD"));
	}

	public void cleanUpJob() throws SQLException {
		List<UploadRequestFile> fileQuery = new ArrayList<>();
		UploadRequestFile file = new UploadRequestFile();

		Connection conn = connectionjdbc();
		// DB connection
		final JdbcTemplate jdbcTemplate = jdbcConnection();
		PreparedStatement pstmt = conn.prepareStatement(
				"select document_id, complainant_upload_requests_id from dp_complainant_upload_request_files where is_uploaded=?");
		pstmt.setString(1, "true");

		try (ResultSet rs = pstmt.executeQuery()) {

			while (rs.next()) {
				file.setUploadRequestId(rs.getInt("complainant_upload_requests_id"));
				file.setStatus(rs.getString("document_id"));
				fileQuery.add(file);
				log.info(String.format("updateRequest RS :: get status from Uploadrequestsfile table :: %s",
						file.getStatus()));
				log.info(String.format("updateRequest RS :: get UploadRequestId from Uploadrequestsfile table :: %s",
						file.getUploadRequestId()));
			}
		} catch (Exception e) {
			log.error(String.format("catch block one :: %s ", e.getMessage()));
		}

		for (UploadRequestFile uploaddto : fileQuery) {

			Integer reqId = uploaddto.getUploadRequestId();
			Object[] id = new Object[] { reqId };
			log.info(String.format("id: %d", id));

			String getidsql = "select package_id from dp_complainant_upload_requests where complainant_upload_requests_id=?";
			log.info(String.format("getidsql: %s", getidsql));

			String packageid = jdbcTemplate.queryForObject(getidsql, String.class, reqId);
			log.info(String.format("packageid : %s", packageid));

			deleteFilesfromContainer(packageid, uploaddto.getDocumentId(), System.getenv("DPFILE_CONTAINER"));
			deleteFilesfromContainer(packageid, uploaddto.getDocumentId(), System.getenv("UPLOAD_CONTAINER"));

		}
	}

	public int deleteFilesfromContainer(String packagid, String documentid, String container) {
		log.info(String.format("deleteFilesfromContainer Started with package id  :: %s", packagid));
		List<String> lst = new ArrayList<>();
		lst.add(packagid + "/" + documentid);

		if (!lst.isEmpty()) {
			log.info(String.format(
					"deleteFilesfromContainer Method list is not empty- proceeding to Move file Method :: %s", lst));
			delFile(lst, container);
		}
		return lst.size();
	}

	public boolean delFile(List<String> fileNames, String sourceContainerName) {
		log.info(String.format("delFile Method started :: %s", fileNames));
		BlobServiceClientBuilder b = new BlobServiceClientBuilder()
				.connectionString(System.getenv("CONNECTION_STRING"));
		BlobContainerClient sourceContainerClient = b.buildClient().getBlobContainerClient(sourceContainerName);
		if (!sourceContainerClient.exists()) {
			return false;
		}

		for (String fileName : fileNames) {
			log.info(String.format("fileName :: %s", fileName));
			deleteBlob(fileName, sourceContainerClient);
		}
		log.info(String.format("delFile Method ended :: %s", fileNames));
		return true;
	}

	public void deleteBlob(String blobName, BlobContainerClient containerClient) {
		log.info(String.format("deleteBlob method started %s", blobName));
		BlobClient blobClient = containerClient.getBlobClient(blobName);
		blobClient.delete();
		log.info(String.format("deleteBlob method ended %s", blobName));
	}

}
