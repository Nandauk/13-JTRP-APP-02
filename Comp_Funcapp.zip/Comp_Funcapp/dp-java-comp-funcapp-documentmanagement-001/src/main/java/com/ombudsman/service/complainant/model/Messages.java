package com.ombudsman.service.complainant.model;

import java.util.List;

import com.google.gson.annotations.SerializedName;

public class Messages {

	@SerializedName("From")
	From From;

	@SerializedName("To")
	List<To> To;

	@SerializedName("TemplateID")
	int TemplateID;

	@SerializedName("TemplateLanguage")
	boolean TemplateLanguage;

	@SerializedName("Name")
	String Name;

	@SerializedName("Variables")
	MailjetVariables var;

	public MailjetVariables getVar() {
		return var;
	}

	public void setVar(MailjetVariables var) {
		this.var = var;
	}

	public void setFrom(From From) {
		this.From = From;
	}

	public From getFrom() {
		return From;
	}

	public void setTo(List<To> To) {
		this.To = To;
	}

	public List<To> getTo() {
		return To;
	}

	public void setTemplateID(int TemplateID) {
		this.TemplateID = TemplateID;
	}

	public int getTemplateID() {
		return TemplateID;
	}

	public void setTemplateLanguage(boolean TemplateLanguage) {
		this.TemplateLanguage = TemplateLanguage;
	}

	public boolean getTemplateLanguage() {
		return TemplateLanguage;
	}

	public void setName(String Name) {
		this.Name = Name;
	}

	public String getName() {
		return Name;
	}

}