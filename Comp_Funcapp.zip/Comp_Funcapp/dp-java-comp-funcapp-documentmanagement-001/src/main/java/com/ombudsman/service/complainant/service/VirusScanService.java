package com.ombudsman.service.complainant.service;

import java.io.IOException;
import java.net.http.HttpClient;
import java.util.concurrent.ExecutionException;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ombudsman.service.complainant.model.CloudmersivePayload;
import com.ombudsman.service.complainant.model.dto.ScanResultDto;

public interface VirusScanService {
	
	CloudmersivePayload initializePayload();

	ScanResultDto scanBlob(CloudmersivePayload payload,HttpClient client) throws JsonProcessingException, InterruptedException, ExecutionException, IOException;
	ScanResultDto virusScanClientActivity(CloudmersivePayload payload) throws InterruptedException, ExecutionException, IOException;
	
}
