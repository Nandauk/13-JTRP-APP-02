package com.ombudsman.service.complainant.exception;

public class InvalidADOrganizationException extends RespondentsServiceExceptions {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	

	public InvalidADOrganizationException(String message,String exceptionMessage,StackTraceElement[] stackTrace) {
		super(message, "RESPONDENT_INVALID_AD_ORG_1000",exceptionMessage,stackTrace);
	}
	
	


}
