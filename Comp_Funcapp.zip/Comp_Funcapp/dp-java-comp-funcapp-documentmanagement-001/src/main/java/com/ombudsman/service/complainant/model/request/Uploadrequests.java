package com.ombudsman.service.complainant.model.request;

import java.io.Serializable;
import java.time.OffsetDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;


//@Data
@Entity
@Table(name = "dp_complainant_upload_requests")
public class Uploadrequests implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name = "complainant_upload_requests_id")
	private Integer id;
	@Column(name = "package_id")
	private String packageid;
	@Column(name = "status")
	private String status;
	@Column(name = "case_id")
	private String caseid;
	@Column(name = "pnx")
	private String pnx;
	@Column(name = "user_id")
	private String userid;
	@Column(name = "created")
	private OffsetDateTime created;
	@Column(name = "comments")
	private String comments;
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getPackageid() {
		return packageid;
	}
	public void setPackageid(String packageid) {
		this.packageid = packageid;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getCaseid() {
		return caseid;
	}
	public void setCaseid(String caseid) {
		this.caseid = caseid;
	}
	public String getPnx() {
		return pnx;
	}
	public void setPnx(String pnx) {
		this.pnx = pnx;
	}
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	public OffsetDateTime getCreated() {
		return created;
	}
	public void setCreated(OffsetDateTime created) {
		this.created = created;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	
	
	
}