package com.ombudsman.service.complainant.model;

import com.google.gson.annotations.SerializedName;

public class UserMailjetRequest {

	String emailId; 
    String fullName;
    int templateId;
    String templateName;
    String portal_User;
    String sign_In;
 
    public String getPortal_User() {
		return portal_User;
	}

	public void setPortal_User(String portal_User) {
		this.portal_User = portal_User;
	}

	public String getSign_In() {
		return sign_In;
	}

	public void setSign_In(String sign_In) {
		this.sign_In = sign_In;
	}

	public String getEmailId() {
        return emailId;
    }
 
    public void setEmailId(String emailId) {
        this.emailId = emailId;
    }
 
    public String getFullName() {
        return fullName;
    }
 
    public void setFullName(String fullName) {
        this.fullName = fullName;
    }
 
    public int getTemplateId() {
        return templateId;
    }
 
    public void setTemplateId(int templateId) {
        this.templateId = templateId;
    }
 
    public String getTemplateName() {
        return templateName;
    }
 
    public void setTemplateName(final String templateName) {
        this.templateName = templateName;
    }
	
}
