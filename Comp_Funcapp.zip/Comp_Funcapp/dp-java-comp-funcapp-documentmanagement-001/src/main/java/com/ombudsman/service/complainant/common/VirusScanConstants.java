package com.ombudsman.service.complainant.common;

public class VirusScanConstants {

	public static final String CONTAINS_EXECUTABLE_FIELD_NAME = "ContainsExecutableFieldName";
	public static final String CONTAINS_EXECUTABLE = "Contains Executable";
	public static final String CONTAINS_INVALID_FILE_FIELD_NAME = "ContainsInvalidFileFieldName";
	public static final String CONTAINS_INVALID_FILE = "Contains Invalid File";
	public static final String CONTAINS_MACROS_FIELD_NAME = "ContainsMacrosFieldName";
	public static final String CONTAINS_MACROS = "Contains Macros";
	public static final String CONTAINS_Ps_PROTECTED_FILE_FIELD_NAME = "ContainsPasswordProtectedFileFieldName";
	public static final String CONTAINS_Ps_PROTECTED_FILE = "Contains Password Protected File";
	public static final String CONTAINS_RESTRICTED_FILE_FORMAT_FIELD_NAME = "ContainsRestrictedFileFormatFieldName";
	public static final String CONTAINS_RESTRICTED_FILE_FORMAT = "Contains Restricted File Format";
	public static final String CONTAINS_SCRIPT_FIELD_NAME = "ContainsScriptFieldName";
	public static final String CONTAINS_SCRIPT = "Contains Script";
	public static final String CONTAINS_HTML_FIELD_NAME = "ContainsHtmlFieldName";
	public static final String CONTAINS_HTML = "Contains HTML";
	public static final String CONTAINS_XML_EXTERNAL_ENTITIES_FIELD_NAME = "ContainsXmlExternalEntitiesFieldName";
	public static final String CONTAINS_XML_EXTERNAL_ENTITIES = "Contains XML External Entities";
	public static final String CONTAINS_INSECURE_DESERIALIZATION_FIELD_NAME = "ContainsInsecureDeserializationFieldName";
	public static final String CONTAINS_INSECURE_DESERIALIZATION = "Contains Insecure Deserialization";
	public static final String CONTAINS_UNSAFE_ARCHIVE_FIELD_NAME = "ContainsUnsafeArchiveFieldName";
	public static final String CONTAINS_UNSAFE_ARCHIVE = "Contains Unsafe Archive";
}
