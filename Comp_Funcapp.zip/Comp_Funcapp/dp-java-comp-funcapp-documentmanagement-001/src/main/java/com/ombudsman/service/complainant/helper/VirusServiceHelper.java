package com.ombudsman.service.complainant.helper;

import java.util.List;
import java.util.stream.Collectors;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.context.annotation.Configuration;

import com.ombudsman.service.complainant.common.VirusScanErrorTextConstants;
import com.ombudsman.service.complainant.model.request.VirusScanResponse;


@Configuration
public class VirusServiceHelper {
	
	Logger log = LogManager.getRootLogger();
	 public String getResultInformation(VirusScanResponse response) {
		log.info(String.format("getResultInformation method called in VirusScanServiceImpl method Started :-%s", response));

		StringBuilder builder = new StringBuilder();
		if (response == null)
			return "no data found";

		if (!response.getSuccessful()) {
			log.info(String.format("getResultInformation method : when response is not successfull :-%s", response));
			return response.getErrorDetailedDescription() == null ? "scan not successful"
					: response.getErrorDetailedDescription();
		}

		if (response.getCleanResult())
			return "scan successful";

		log.info(String.format("getFieldsThatAreTrueInResult in Method getResultInformation : sending response :-%s", response));
		List<String> fields = getFieldsThatAreTrueInResult(response, "contains");
		for (String propertyName : fields) {
			builder.append(VirusScanErrorTextConstants.getErrorText(propertyName));
		}
		/*
		 * if (response.getFoundViruses() != null) { for (FoundVirus virus :
		 * response.getFoundViruses()) { builder.append(virus.getFileName() +
		 * " infected with " + virus.getVirusName()); } }
		 */
		log.info(String.format("getResultInformation method called in VirusScanServiceImpl method ended :-%s", builder.toString()));
		return builder.toString();
	}
	 
	 private <T> List<String> getFieldsThatAreTrueInResult(T typeToCheck, String fieldPrefix) {
			log.info(String.format("getFieldsThatAreTrueInResult Method Started :: response :-%s", typeToCheck));
			return List.of(typeToCheck.getClass().getDeclaredFields()).stream()
					.filter(field -> field.getName().toLowerCase().contains(fieldPrefix)).filter(field -> {
						try {
							field.setAccessible(true);
							return field.getBoolean(typeToCheck);
						}

					catch (IllegalAccessException e) {
							e.printStackTrace();
						}
						return false;
					}).map(field -> field.getName()).collect(Collectors.toList());
		}
	
}
