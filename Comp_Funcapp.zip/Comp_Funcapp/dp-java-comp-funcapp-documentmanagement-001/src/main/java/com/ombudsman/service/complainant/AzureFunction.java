package com.ombudsman.service.complainant;

import java.beans.Transient;
import java.io.IOException;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.microsoft.azure.functions.ExecutionContext;
import com.microsoft.azure.functions.OutputBinding;
import com.microsoft.azure.functions.annotation.FunctionName;
import com.microsoft.azure.functions.annotation.ServiceBusQueueOutput;
import com.microsoft.azure.functions.annotation.ServiceBusQueueTrigger;
import com.microsoft.azure.functions.annotation.TimerTrigger;
import com.ombudsman.service.complainant.helper.ValidationServiceHelper;
import com.ombudsman.service.complainant.model.CloudmersivePayload;
import com.ombudsman.service.complainant.model.GetResponseMessage;
import com.ombudsman.service.complainant.model.dto.PostScanningParamsDto;
import com.ombudsman.service.complainant.model.dto.ScanResultDto;
import com.ombudsman.service.complainant.model.dto.UploadCompletedMessageDto;

import com.ombudsman.service.complainant.serviceimpl.ValidationServiceImpl;
import com.ombudsman.service.complainant.serviceimpl.VirusScanServiceImpl;


@Component
public class AzureFunction {

	Logger log = LogManager.getRootLogger();
	ValidationServiceImpl validationService = new ValidationServiceImpl();
	VirusScanServiceImpl  virusService =new VirusScanServiceImpl();

    private static boolean hasExecuted = false;


	@FunctionName("uploadorchestrator")
	@Transient(true)
	public void runDurableFunc(
			@ServiceBusQueueTrigger(name = "message", queueName = "%QueueName%", connection = "AzureWebJobsServiceBus") String request,
	        @ServiceBusQueueOutput(name = "outputMessage", queueName = "%InputQueue%", connection = "AzureWebJobsServiceBus") OutputBinding<String> outputMessage)
	//			@HttpTrigger(name = "req", methods = { HttpMethod.GET,HttpMethod.POST }, authLevel = AuthorizationLevel.ANONYMOUS) final HttpRequestMessage<String> request)
			throws InterruptedException, ExecutionException, IOException, SQLException {
		
		//convert request data in UploadCompletedMessageDto
		log.info(String.format("Start UploadOrchestrator:-%s", request));
		UploadCompletedMessageDto dto = new UploadCompletedMessageDto();
		dto = new ObjectMapper().readValue(request, UploadCompletedMessageDto.class);
		log.info(String.format("packageid when request recive from scan queue:-%s", dto.getPackageId()));
		//object assign
		CloudmersivePayload payload = new CloudmersivePayload();
		ScanResultDto callActivity = new ScanResultDto();
		List<ScanResultDto> results = new ArrayList<>();
		VirusScanServiceImpl virusScanService = new VirusScanServiceImpl();
		ValidationServiceHelper validationServiceHelper = new ValidationServiceHelper();
		GetResponseMessage genericResponse = new GetResponseMessage();
		
		List<String> copiedFiles = validationService.preScanning(dto);
		log.info(String.format("copiedFilesFuture:-%s", copiedFiles));
		log.info(String.format("copiedFilesFuture size:-%s", copiedFiles.size()));
		if (!copiedFiles.isEmpty()) {
			payload = virusScanService.initializePayload();
			for (String file : copiedFiles) {
				log.info("********************************");
				payload.setBlobPath(file); // file name - blob name stored in payload *****
				payload.setDocumentId(file.split("/")[1]); // documentid of blob ******
				log.info(String.format("payload blobpath:-%s", payload.getBlobPath()));
				log.info(String.format("payload documentId:-%s", payload.getDocumentId()));
				log.info("Before proceeding to VirusScanClientActivity Method ");
				callActivity = virusService.virusScanClientActivity(payload);
				log.info(String.format("after virusScanClientActivity:-%s", callActivity));
				
				if(!callActivity.getClean()==true) {
					validationService.sendInvite(dto,genericResponse);
				}
				results.add(callActivity);
				log.info(String.format("results:-%s", results));
			}

//			**** Process all data till now from the above code ****
			PostScanningParamsDto postScanningParams = new PostScanningParamsDto();
			postScanningParams.setMessage(dto);
			postScanningParams.setScanningResults(results);
			postScanningParams.setPackageId(dto.getPackageId());
			validationServiceHelper.deleteFromScanContainer(postScanningParams.getPackageId(), System.getenv("SCAN_CONTAINER"));
			log.info(String.format("before postScanningParams:-%s", postScanningParams));
			Boolean postScanning = validationService.postScanning(postScanningParams,outputMessage);
			postScanningParams.setIngestionMessageSent(postScanning);
			log.info(String.format("after postScanningParams , data added in Ingestion service bus:-%s", postScanningParams));

		}
		log.info("end UploadOrchestrator changes");
	}
	
	
	// 0 0 0 * * *
		/** * This function runs once every 24 hours. */
		@FunctionName("TimerTriggerFunction")
		public void run(@TimerTrigger(name = "timerInfo", schedule = "0 0 0 * * *") String packgid,
				final ExecutionContext context) {
			log.info("Java Timer Trigger function App Started");
			log.info(String.format("Java Timer trigger function executed at: %s", java.time.LocalDateTime.now()));
			try {
				ValidationServiceImpl validationServiceImpl = new ValidationServiceImpl();
				validationServiceImpl.cleanUpJob();

			} catch (Exception e) {
				log.error(String.format("Error in TimerTriggerFunction %s", e.getMessage()));
			}
			context.getLogger().info("Processing the 24-hour task.");
		}
	
	
}