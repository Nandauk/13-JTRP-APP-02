package com.ombudsman.service.complainant.model;

import java.io.Serializable;

public class ContentInformation implements Serializable {
	 /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	boolean containsJSON;
	 boolean containsXML;
	 boolean containsImage;
	 String relevantSubfileName;
	public boolean getContainsJSON() {
		return containsJSON;
	}
	public void setContainsJSON(boolean containsJSON) {
		this.containsJSON = containsJSON;
	}
	public boolean getContainsXML() {
		return containsXML;
	}
	public void setContainsXML(boolean containsXML) {
		this.containsXML = containsXML;
	}
	public boolean getContainsImage() {
		return containsImage;
	}
	public void setContainsImage(boolean containsImage) {
		this.containsImage = containsImage;
	}
	public String getRelevantSubfileName() {
		return relevantSubfileName;
	}
	public void setRelevantSubfileName(String relevantSubfileName) {
		this.relevantSubfileName = relevantSubfileName;
	}
	 
	 
	
	
	
	
	
	
}
