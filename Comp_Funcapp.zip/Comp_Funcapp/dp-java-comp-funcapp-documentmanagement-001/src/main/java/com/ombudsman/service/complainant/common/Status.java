package com.ombudsman.service.complainant.common;

public class Status {
	
	public static final String Passed = "Passed";
	public static final String Failed = "Failed";
	public static final String Submitted = "Submitted for uploading";
	public static final String Ingested = "Uploaded";
	public static final String CleanedUp = "Cleaned Up";
	private Status() {
		
	}

	
	
}
