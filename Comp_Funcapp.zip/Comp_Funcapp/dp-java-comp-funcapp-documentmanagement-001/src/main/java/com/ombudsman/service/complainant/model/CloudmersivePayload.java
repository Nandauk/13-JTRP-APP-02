package com.ombudsman.service.complainant.model;

public class CloudmersivePayload {

	
	private String connectionString ;
	private String containerName ;
	private String blobPath ;
	private String apikey ;
	private String scanUrl ;
	private String documentId ;
	private boolean scanEnabled ;
	public String getConnectionString() {
		return connectionString;
	}
	public void setConnectionString(String connectionString) {
		this.connectionString = connectionString;
	}
	public String getContainerName() {
		return containerName;
	}
	public void setContainerName(String containerName) {
		this.containerName = containerName;
	}
	public String getBlobPath() {
		return blobPath;
	}
	public void setBlobPath(String blobPath) {
		this.blobPath = blobPath;
	}
	public String getApikey() {
		return apikey;
	}
	public void setApikey(String apikey) {
		this.apikey = apikey;
	}
	public String getScanUrl() {
		return scanUrl;
	}
	public void setScanUrl(String scanUrl) {
		this.scanUrl = scanUrl;
	}
	public String getDocumentId() {
		return documentId;
	}
	public void setDocumentId(String documentId) {
		this.documentId = documentId;
	}
	public boolean isScanEnabled() {
		return scanEnabled;
	}
	public void setScanEnabled(boolean scanEnabled) {
		this.scanEnabled = scanEnabled;
	}
	
}
