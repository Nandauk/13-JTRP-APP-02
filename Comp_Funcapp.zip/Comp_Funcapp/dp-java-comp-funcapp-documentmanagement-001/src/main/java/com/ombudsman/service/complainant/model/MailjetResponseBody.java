package com.ombudsman.service.complainant.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.List;

public class MailjetResponseBody {

	private List<Message> messages;

	@JsonProperty("Messages")
	public List<Message> getMessages() {
		return messages;
	}

	public void setMessages(List<Message> messages) {
		this.messages = messages;
	}

	public String toString() {
		return "Message :" + this.getMessages();
	}

	public static class Message {
		private String status;
		private String customID;
		private List<Recipient> to;
		private List<Recipient> cc;
		private List<Recipient> bcc;

		@JsonProperty("Status")
		public String getStatus() {
			return status;
		}

		public void setStatus(String status) {
			this.status = status;
		}

		@JsonProperty("CustomID")
		public String getCustomID() {
			return customID;
		}

		public void setCustomID(String customID) {
			this.customID = customID;
		}

		@JsonProperty("To")
		public List<Recipient> getTo() {
			return to;
		}

		public void setTo(List<Recipient> to) {
			this.to = to;
		}

		@JsonProperty("Cc")
		public List<Recipient> getCc() {
			return cc;
		}

		public void setCc(List<Recipient> cc) {
			this.cc = cc;
		}

		@JsonProperty("Bcc")
		public List<Recipient> getBcc() {
			return bcc;
		}

		public void setBcc(List<Recipient> bcc) {
			this.bcc = bcc;
		}

		public String toString() {
			return "Status: " + this.getStatus() + ",CustomID: " + this.getCustomID() + ",TO : " + this.getTo()
					+ " ,Cc : " + this.getCc() + " ,Bcc : " + this.getBcc();
		}
	}

	public static class Recipient {
		private String email;
		private String messageUUID;
		private long messageID;
		private String messageHref;

		@JsonProperty("Email")
		public String getEmail() {
			return email;
		}

		public void setEmail(String email) {
			this.email = email;
		}

		@JsonProperty("MessageUUID")
		public String getMessageUUID() {
			return messageUUID;
		}

		public void setMessageUUID(String messageUUID) {
			this.messageUUID = messageUUID;
		}

		@JsonProperty("MessageID")
		public long getMessageID() {
			return messageID;
		}

		public void setMessageID(long messageID) {
			this.messageID = messageID;
		}

		@JsonProperty("MessageHref")
		public String getMessageHref() {
			return messageHref;
		}

		public void setMessageHref(String messageHref) {
			this.messageHref = messageHref;
		}

		public String toString() {
			return " email: " + this.getEmail() + ", messageUUID: " + this.getMessageUUID() + " ,messageID : "
					+ this.getMessageID() + " ,messageHref : " + this.getMessageHref();
		}
	}

}
