package com.ombudsman.service.complainant.helper.test;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.sql.Connection;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.ombudsman.service.complainant.common.VirusScanErrorTextConstants;
import com.ombudsman.service.complainant.helper.VirusServiceHelper;
import com.ombudsman.service.complainant.model.ContentInformation;
import com.ombudsman.service.complainant.model.request.VirusScanResponse;

@ExtendWith(SpringExtension.class)
public class VirusServiceHelperTest {

	@InjectMocks
	VirusServiceHelper testInstance;
	
	@Mock
	Connection jdbcConnection;
	
	@Test
	 public void getResultInformationTest() {
		
		VirusScanResponse response = new VirusScanResponse ();
		
		response.setCleanResult(true);
		response.setSuccessful(true);
		
		String result = testInstance.getResultInformation(response);
		assertEquals(result,"scan successful");
	}
	 

	@Test
	 public void getResultInformationTestNull() {
		
		VirusScanResponse response = new VirusScanResponse ();
		response = null;
		
		String result = testInstance.getResultInformation(response);
		assertEquals(result,"no data found");
	}
	
	@Test
	 public void getResultInformationTestsuccess() {
		
		VirusScanResponse response = new VirusScanResponse ();
		response.setSuccessful(false);
		
		String result = testInstance.getResultInformation(response);
		assertEquals(result,"scan not successful");
	}
	
	@Test
	 public void getResultInformationScanFalse() {
		
		VirusScanResponse response = new VirusScanResponse ();
		
		response.setCleanResult(false);
		response.setSuccessful(true);
		
		String result = testInstance.getResultInformation(response);
		assertEquals(result,"");
	}
	
}
