package com.ombudsman.service.complainant.model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.ombudsman.service.complainant.model.ContentInformation;

@ExtendWith(SpringExtension.class)
public class ContentInformationTest {

	@Test
	public void  testContentInformationTest() {
		 
		ContentInformation contentInformation = new ContentInformation();
	
		boolean containsJSON = true;
		boolean containsXML = true; 
		boolean containsImage  =true;
		String relevantSubfileName = "relevantTime";
		
		
		contentInformation.setContainsImage(containsImage);
		contentInformation.setContainsJSON(containsJSON);
		contentInformation.setContainsXML(containsXML);
		contentInformation.setRelevantSubfileName(relevantSubfileName);
		
		 assertEquals(contentInformation.getContainsImage(),true);
		 assertEquals(contentInformation.getContainsJSON(),true);
		 assertEquals(contentInformation.getContainsImage(),true);
		 assertEquals(contentInformation.getRelevantSubfileName(),relevantSubfileName);
	}
}
