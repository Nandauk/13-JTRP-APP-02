package com.ombudsman.service.complainant.model.dto;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.ombudsman.service.complainant.model.dto.PostScanningParamsDto;
import com.ombudsman.service.complainant.model.dto.ScanResultDto;
import com.ombudsman.service.complainant.model.dto.UploadCompletedMessageDto;

@ExtendWith(SpringExtension.class)
public class PostScanningParamsDtoTest {

	@Test
	public void  testPostScanningParamsDto() {
	
		PostScanningParamsDto testinstance = new PostScanningParamsDto(); 
		 String packageId = "mockID" ;
		 
		 ScanResultDto data = new ScanResultDto();
		 data.setFileName("packageId");
		 data.setComment("comment");
		 data.setDocumentId("documentID");
		 data.setClean(false);
		 
		 List<ScanResultDto> scanningResults = new ArrayList<>() ;
		 scanningResults.add(data);
		 
		 UploadCompletedMessageDto message = new UploadCompletedMessageDto()  ;
		 message.setCaseId("caseID");
		 
		 boolean ingestionMessageSent = true;
		 testinstance.setIngestionMessageSent(ingestionMessageSent);
		 testinstance.setMessage(message);
		 testinstance.setPackageId(packageId);
		 testinstance.setScanningResults(scanningResults);
		 
		 assertEquals(testinstance.isIngestionMessageSent(),ingestionMessageSent);
		 assertEquals(testinstance.getMessage(),message);
		 assertEquals(testinstance.getPackageId(),packageId);
		 assertEquals(testinstance.getScanningResults(),scanningResults);

		 
		 
		
		
	}
	
}
