package com.ombudsman.service.complainant.serviceimpl.test;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.when;

import java.net.http.HttpClient;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.microsoft.azure.functions.OutputBinding;
import com.ombudsman.service.complainant.helper.ValidationServiceHelper;
import com.ombudsman.service.complainant.model.CloudmersivePayload;
import com.ombudsman.service.complainant.model.dto.PostScanningParamsDto;
import com.ombudsman.service.complainant.model.dto.ScanResultDto;
import com.ombudsman.service.complainant.model.dto.UploadCompletedMessageDto;
import com.ombudsman.service.complainant.serviceimpl.ValidationServiceImpl;


@ExtendWith(SpringExtension.class)
public class ValidationServiceImplTest {

	@InjectMocks
	ValidationServiceImpl testInstance;
	
	@Mock
	ValidationServiceHelper validationServiceHelper;
	
	@Mock
	CloudmersivePayload payload;
	
	@Test
	public void postScanningTestClean() {
		
		ScanResultDto data = new ScanResultDto();
		data.setClean(true);
		data.setComment("good");
		data.setDocumentId("doc11");
		data.setFileName("fileNameMock");
		List<ScanResultDto> scanResultList = new ArrayList<ScanResultDto>();
		scanResultList.add(data);
		
		UploadCompletedMessageDto messageData = new UploadCompletedMessageDto();
		messageData.setCaseId("case1");
		
		PostScanningParamsDto postScanningParams = new PostScanningParamsDto();
		postScanningParams.setPackageId("acv123");
		postScanningParams.setIngestionMessageSent(true);
		postScanningParams.setScanningResults(scanResultList);
		postScanningParams.setMessage(messageData);
		
		when(validationServiceHelper.prepareForIngestion(postScanningParams,
				System.getenv("UPLOAD_CONTAINER"))).thenReturn(1);
		
		OutputBinding<String> msg = null;
		boolean response = testInstance.postScanning(postScanningParams, msg);
		
		assertFalse(response);
		
	}
	
	@Test
	public void postScanningTestNotClean() {
		
		ScanResultDto data = new ScanResultDto();
		data.setClean(false); //not clean
		data.setComment("good");
		data.setDocumentId("doc11");
		data.setFileName("fileNameMock");
		List<ScanResultDto> scanResultList = new ArrayList<ScanResultDto>();
		scanResultList.add(data);
		
		UploadCompletedMessageDto messageData = new UploadCompletedMessageDto();
		messageData.setCaseId("case1");
		
		PostScanningParamsDto postScanningParams = new PostScanningParamsDto();
		postScanningParams.setPackageId("acv123");
		postScanningParams.setIngestionMessageSent(true);
		postScanningParams.setScanningResults(scanResultList);
		postScanningParams.setMessage(messageData);
		OutputBinding<String> msg = null;
		boolean response = testInstance.postScanning(postScanningParams,msg);
		
		assertFalse(response);
		
	}
	
	@Test
	public void preScanningTest() {
		
		UploadCompletedMessageDto messageData = new UploadCompletedMessageDto();
		messageData.setCaseId("case1");
		messageData.setComments("mockComment");
		
		List<String> response = testInstance.preScanning(messageData);
		assertNotNull(response);
	}
	
	
}
