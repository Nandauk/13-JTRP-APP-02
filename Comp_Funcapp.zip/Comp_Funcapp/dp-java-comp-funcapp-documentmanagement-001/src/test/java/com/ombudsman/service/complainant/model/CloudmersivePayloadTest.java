package com.ombudsman.service.complainant.model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.ombudsman.service.complainant.model.CloudmersivePayload;

@ExtendWith(SpringExtension.class)
public class CloudmersivePayloadTest {

	@Test
	public void  testCloudmersivePayload() {
	
	CloudmersivePayload cloudmersivePayload = new CloudmersivePayload();
	
	 String connectionString = "mockString" ;
	 String containerName = "mockContainer" ;
	 String blobPath = "mockBlobPath" ;
	 String apikey = "123Api" ;
	 String scanUrl = "mockSanUrl";
	 String documentId = "MockDocumentId";
	 boolean scanEnabled = true;
	 
	 cloudmersivePayload.setDocumentId(documentId);
	 cloudmersivePayload.setApikey(apikey);
	 cloudmersivePayload.setBlobPath(blobPath);
	 cloudmersivePayload.setConnectionString(connectionString);
	 cloudmersivePayload.setContainerName(containerName);
	 cloudmersivePayload.setScanEnabled(scanEnabled);
	 cloudmersivePayload.setScanUrl(scanUrl);
	 
	 assertEquals(cloudmersivePayload.getDocumentId(),documentId);
	 assertEquals(cloudmersivePayload.getApikey(),apikey);
	 assertEquals(cloudmersivePayload.getBlobPath(),blobPath);
	 assertEquals(cloudmersivePayload.getConnectionString(),connectionString);
	 assertEquals(cloudmersivePayload.getContainerName(),containerName);
	 assertEquals(cloudmersivePayload.isScanEnabled(),scanEnabled);
	 assertEquals(cloudmersivePayload.getScanUrl(),scanUrl);
	 
	 
	}	
	
}
