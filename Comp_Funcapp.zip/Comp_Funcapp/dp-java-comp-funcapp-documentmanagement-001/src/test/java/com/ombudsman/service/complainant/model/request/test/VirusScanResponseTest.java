package com.ombudsman.service.complainant.model.request.test;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.ombudsman.service.complainant.model.ContentInformation;
import com.ombudsman.service.complainant.model.request.VirusScanResponse;

@ExtendWith(SpringExtension.class)
public class VirusScanResponseTest {

	@Test
	public void  testVirusScanResponse() {
	
		VirusScanResponse testInstance = new VirusScanResponse();
		
		boolean successful = true;
		boolean cleanResult = true;
		boolean containsExecutable = true;
		boolean containsInvalidFile = true;
		boolean containsScript = true;
		boolean containsPasswordProtectedFile = true;
		boolean containsRestrictedFileFormat = true;
		boolean containsMacros = true;
		String verifiedFileFormat = "mockValue";
		String foundViruses = "mockValue";
		String errorDetailedDescription = "mockValue";
		int fileSize = 123;
		ContentInformation contentInformation = new ContentInformation();
		contentInformation.setContainsImage(true);
		
		testInstance.setCleanResult(cleanResult);
		testInstance.setContainsExecutable(containsExecutable);
		testInstance.setContainsInvalidFile(containsInvalidFile);
		testInstance.setContainsMacros(containsMacros);
		testInstance.setContainsPasswordProtectedFile(containsPasswordProtectedFile);
		testInstance.setContainsRestrictedFileFormat(containsRestrictedFileFormat);
		testInstance.setContainsScript(containsScript);
		testInstance.setContentInformation(contentInformation);
		testInstance.setErrorDetailedDescription(errorDetailedDescription);
		testInstance.setFileSize(fileSize);
		testInstance.setFoundViruses(foundViruses);
		testInstance.setSuccessful(successful);
		testInstance.setVerifiedFileFormat(verifiedFileFormat);
		 
		assertEquals(testInstance.getCleanResult(),cleanResult);
		assertEquals(testInstance.getContainsExecutable(),containsExecutable);
		assertEquals(testInstance.getContainsInvalidFile(),containsInvalidFile);
		assertEquals(testInstance.getContainsMacros(),containsMacros);
		assertEquals(testInstance.getContainsPasswordProtectedFile(),containsPasswordProtectedFile);
		assertEquals(testInstance.getContainsRestrictedFileFormat(),containsRestrictedFileFormat);
		assertEquals(testInstance.getContainsScript(),containsScript);
		assertEquals(testInstance.getContentInformation(),contentInformation);
		assertEquals(testInstance.getErrorDetailedDescription(),errorDetailedDescription);
		assertEquals(testInstance.getFileSize(),fileSize);
		assertEquals(testInstance.getFoundViruses(),foundViruses);
		assertEquals(testInstance.getSuccessful(),successful);
		assertEquals(testInstance.getVerifiedFileFormat(),verifiedFileFormat);
		
		
	}
}
