package com.ombudsman.service.complainant.exception.test;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.time.LocalDateTime;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.http.HttpStatus;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.ombudsman.service.complainant.exception.ApiError;

@ExtendWith(SpringExtension.class)
public class ApiErrorTest {
	
	@Test
	public void  testApiError() {
		
		ApiError instance =  new ApiError(LocalDateTime.now(), HttpStatus.ACCEPTED, "status", "errorMessage");
		
		instance.setErrorCode("code");
		instance.setErrorMessage("errorMessage");
		instance.setStatus(HttpStatus.ACCEPTED);
		instance.setTimestamp(LocalDateTime.now());
		
		assertEquals(instance.getErrorCode(),"code");
		assertEquals(instance.getErrorMessage(),"errorMessage");
		assertEquals(instance.getStatus(),HttpStatus.ACCEPTED);
		
		
	}

}
