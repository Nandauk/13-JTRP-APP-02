package com.ombudsman.service.respondent;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.ombudsman.service.common.model.GetResponseMessage;

@ExtendWith(SpringExtension.class)
public class GetResponseMessageTest {
	
	@InjectMocks
	GetResponseMessage mMockGetResponseMessage;
	
	@Test
	public void testGetterAndSetter() {
		
		mMockGetResponseMessage.setMessage("msg");
		assertEquals("msg",mMockGetResponseMessage.getMessage());
		
	}

}
