package com.ombudsman.service.respondent;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.time.OffsetDateTime;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.ombudsman.service.common.model.ComplainantUploadRequestFile;

@ExtendWith(SpringExtension.class)
public class UploadRequestFileTest {
	
	@InjectMocks
	ComplainantUploadRequestFile mMockUploadRequestFile;
	OffsetDateTime now = OffsetDateTime.now();
	
	@Test
	public void testGetterAndSetter() {
		mMockUploadRequestFile.setDocumentId("docid");
		mMockUploadRequestFile.setComments("Hello");
		mMockUploadRequestFile.setFileName("File123");
		mMockUploadRequestFile.setFileSize("10");
		mMockUploadRequestFile.setId(2);
		mMockUploadRequestFile.setLastUpdatedTime(now);
		mMockUploadRequestFile.setStatus("sts123");
		mMockUploadRequestFile.setUploaded(false);
		mMockUploadRequestFile.setUploadRequestId(12);
		
		assertEquals("docid",mMockUploadRequestFile.getDocumentId());
		assertEquals("Hello",mMockUploadRequestFile.getComments());
		assertEquals("File123",mMockUploadRequestFile.getFileName());
		assertEquals("10", mMockUploadRequestFile.getFileSize());
		assertEquals(2,mMockUploadRequestFile.getId());
		assertEquals(now,mMockUploadRequestFile.getLastUpdatedTime());
		assertEquals("sts123", mMockUploadRequestFile.getStatus());
		assertEquals(false,mMockUploadRequestFile.getUploaded());
		assertEquals(12,mMockUploadRequestFile.getUploadRequestId());
		
		
	}

}
