package com.ombudsman.service.respondent;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.json.JSONException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.mockito.stubbing.OngoingStubbing;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.azure.storage.blob.BlobClient;
import com.azure.storage.blob.BlobContainerClient;
import com.microsoft.azure.functions.ExecutionContext;
import com.microsoft.azure.functions.annotation.TimerTrigger;
import com.ombudsman.service.common.NotificationAzureFunction;
import com.ombudsman.service.common.model.NotificationUploadRequest;
import com.sun.jdi.connect.spi.Connection;


import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;
import java.util.logging.Logger;



import java.sql.SQLException;
import java.util.Arrays;
import java.util.HashMap;



@ExtendWith(SpringExtension.class)
public class NotificationAzureFunctionTest {

	@InjectMocks
	NotificationAzureFunction mMockNotificationAzureFunction;

	@Mock
	ExecutionContext context;
	
    @Mock
    BlobContainerClient containerClient;

    @Mock
    BlobClient blobClient;

	@Mock
	JdbcTemplate jdbcTemplate;
	@Captor
	ArgumentCaptor<Object[]> objCap;
	@Captor
	ArgumentCaptor<int[]> intCap;
	

	    @Mock
	    private Connection mockConnection;

	    @Mock
	    private PreparedStatement mockPreparedStatement;

	    @Mock
	    private ResultSet mockResultSet;
	    
	   


	 
	@BeforeEach
	public void setUp() {
		MockitoAnnotations.openMocks(this);
	}

	
	
	
	
	

	@Test
	void testApitoServiceBus_SUCCESS() {
		NotificationUploadRequest message = new NotificationUploadRequest();
		message.setIsSuccessful("true");
		message.setPackageId("testPackage");
		String response = "success";

		when(jdbcTemplate.update(Mockito.anyString(), objCap.capture())).thenReturn(1);
		mMockNotificationAzureFunction.apitoServiceBus(message, context);

		assertEquals("success", response);
	}

	@Test
	void testApitoServiceBus_fail() {
		NotificationUploadRequest message = new NotificationUploadRequest();
		message.setIsSuccessful("false");
		message.setPackageId("testPackage");
		String response = "fail";

		when(jdbcTemplate.update(Mockito.anyString(), objCap.capture())).thenReturn(1);
		mMockNotificationAzureFunction.apitoServiceBus(message, context);

		assertEquals("fail", response);
	}
}
