package com.ombudsman.service.respondent;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.ombudsman.service.common.model.NotificationUploadRequest;

@ExtendWith(SpringExtension.class)
public class NotificationUploadRequestTest {
	
	@InjectMocks
	NotificationUploadRequest mMockNotificationUploadRequest;
	
	@Test
	public void testGetterAndSetter() {
		
		mMockNotificationUploadRequest.setIsSuccessful("true");
		mMockNotificationUploadRequest.setPackageId("pkgId");
		mMockNotificationUploadRequest.setReasonForChange("TEST");
		mMockNotificationUploadRequest.setRecordId("RECID");
		mMockNotificationUploadRequest.setStatus("status");
		
		assertEquals("true",mMockNotificationUploadRequest.getIsSuccessful());
		assertEquals("pkgId",mMockNotificationUploadRequest.getPackageId());
		assertEquals("TEST",mMockNotificationUploadRequest.getReasonForChange());
		assertEquals("RECID",mMockNotificationUploadRequest.getRecordId());
		assertEquals("status",mMockNotificationUploadRequest.getStatus());
		
	}

}
