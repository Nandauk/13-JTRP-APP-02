package com.ombudsman.service.common.model;

public class NotificationUploadRequest {

	private String RecordId;
	private String IsSuccessful;
	private String ReasonForChange;
	private String PackageId;
	private String Status;
	private String PortalType;

	public String getRecordId() {
		return RecordId;
	}

	public void setRecordId(String recordId) {
		RecordId = recordId;
	}

	public String getIsSuccessful() {
		return IsSuccessful;
	}

	public void setIsSuccessful(String isSuccessful) {
		IsSuccessful = isSuccessful;
	}

	public String getReasonForChange() {
		return ReasonForChange;
	}

	public void setReasonForChange(String reasonForChange) {
		ReasonForChange = reasonForChange;
	}

	public String getPackageId() {
		return PackageId;
	}

	public void setPackageId(String packageId) {
		PackageId = packageId;
	}

	public String getStatus() {
		return Status;
	}

	public void setStatus(String status) {
		Status = status;
	}

	public String getPortalType() {
		return PortalType;
	}

	public void setPortalType(String portalType) {
		PortalType = portalType;
	}

}
