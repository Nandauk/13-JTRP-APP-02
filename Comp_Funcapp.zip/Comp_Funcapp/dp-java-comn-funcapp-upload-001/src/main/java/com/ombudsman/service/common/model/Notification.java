package com.ombudsman.service.common.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.transaction.Transactional;
@Entity
@Table(name = "dp_user_notification")
@Transactional
public class Notification {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "notification_id")
	private Long notificationId;
	@Column(name = "request_id")
	private String requestId; // notnull
	@Column(name = "user_oid")
	private String userOid; // notnull
	@Column(name = "requesting_activity_name")
	private String requestingActivityName; // notnull
	@Column(name = "notification_status_id")
	private String notificationStatusId; // notnull
	@Column(name = "notification_status_description")
	private String notificationStatusDescription; // notnull
	@Column(name = "message")
	private String message;
	@Column(name = "file_download_url")
	private String fileDownloadUrl;
	@Column(name = "created_by")
	private String createdBy; // notnull
	@Column(name = "modified_on")
	private String modifiedOn;
	@Column(name = "modified_by")
	private String modifiedBy;

	public String getRequestId() {
		return requestId;
	}

	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}

	public String getNotificationStatusId() {
		return notificationStatusId;
	}

	public void setNotificationStatusId(String notificationStatusId) {
		this.notificationStatusId = notificationStatusId;
	}

	public Long getNotificationId() {
		return notificationId;
	}

	public void setNotificationId(Long notificationId) {
		this.notificationId = notificationId;
	}

	
	public String getUserOid() {
		return userOid;
	}

	public void setUserOid(String userOid) {
		this.userOid = userOid;
	}

	public String getRequestingActivityName() {
		return requestingActivityName;
	}

	public void setRequestingActivityName(String requestingActivityName) {
		this.requestingActivityName = requestingActivityName;
	}

	public String getNotificationStatusDescription() {
		return notificationStatusDescription;
	}

	public void setNotificationStatusDescription(String notificationStatusDescription) {
		this.notificationStatusDescription = notificationStatusDescription;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getFileDownloadUrl() {
		return fileDownloadUrl;
	}

	public void setFileDownloadUrl(String fileDownloadUrl) {
		this.fileDownloadUrl = fileDownloadUrl;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getModifiedOn() {
		return modifiedOn;
	}

	public void setModifiedOn(String modifiedOn) {
		this.modifiedOn = modifiedOn;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
}
