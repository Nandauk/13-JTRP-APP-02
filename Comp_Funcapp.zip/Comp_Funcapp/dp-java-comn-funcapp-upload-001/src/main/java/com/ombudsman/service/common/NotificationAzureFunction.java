package com.ombudsman.service.common;

import java.beans.Transient;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

import com.microsoft.azure.functions.ExecutionContext;
import com.microsoft.azure.functions.annotation.FunctionName;
import com.microsoft.azure.functions.annotation.ServiceBusQueueTrigger;
import com.ombudsman.service.common.model.NotificationUploadRequest;

public class NotificationAzureFunction {

	private static final String SUCCESS = "Success";
	private static final String FAILED = "Failed";
	private static final String TRUE = "true";
	private static final String FALSE = "false";

	Logger log = LogManager.getRootLogger();

	// DB connection
	final JdbcTemplate jdbcTemplate = jdbcConnection();

	@FunctionName("commonNotificationUpload")
	@Transient(true)
	public String apitoServiceBus(
			@ServiceBusQueueTrigger(name = "message", queueName = "%QueueNameUpload%", connection = "AzureWebJobsServiceBus") NotificationUploadRequest message,
			final ExecutionContext context) {

		log.info(String.format("Request message for Upload : %s", message.getPackageId()));

		try {
			if(message.getPortalType().equals("Complainant"))
			uploadNotificationForComplainant(message);
			
			else
			uploadNotificationForRespondet(message);
			
			
		} catch (Exception e) {
			log.error(String.format("Error in notification %s", e.getMessage()));
		}

		return SUCCESS;
	}

	private String uploadNotificationForRespondet(NotificationUploadRequest message) {
		if (FALSE.equalsIgnoreCase(message.getIsSuccessful())) {
			Object[] paramNotification = new Object[] { message.getPackageId() };
			log.info(String.format("Failed for package id : %s", message.getPackageId()));

			String sql = "update dp_upload_request_files set is_uploaded ='false' where upload_request_id IN (select id from dp_upload_requests where package_id=?) and status='Passed'";
			log.info(String.format("sql to update is uploaded is false : %s", sql));

			jdbcTemplate.update(sql, paramNotification);
			log.info(String.format("Failed :: IsSuccessfull Message: %s", message.getIsSuccessful()));
			log.info(String.format("Notification data updated is_uploaded as false in Database for package Id : %s",
					message.getPackageId()));

			return FAILED;

		} else if (TRUE.equalsIgnoreCase(message.getIsSuccessful())) {

			Object[] paramNotification = new Object[] { message.getPackageId() };
			log.info(String.format("Passed for package id : %s", message.getPackageId()));

			String sql = "update dp_upload_request_files set is_uploaded ='true' where upload_request_id IN (select id from dp_upload_requests where package_id=?) and status='Passed'";
			log.info(String.format("sql to update is uploaded is true : %s", sql));

			jdbcTemplate.update(sql, paramNotification);
			log.info(String.format(
					"In Upload Request Files data updated for is_uploaded as true for package Id : %s",
					message.getPackageId()));
		}
		return SUCCESS;
		
	}

	private String uploadNotificationForComplainant(NotificationUploadRequest message) {
		if (FALSE.equalsIgnoreCase(message.getIsSuccessful())) {
			Object[] paramNotification = new Object[] { message.getPackageId() };
			log.info(String.format("Complainant Failed for package id : %s", message.getPackageId()));

			String sql = "update dp_complainant_upload_request_files set is_uploaded ='false' where complainant_upload_requests_id IN (select complainant_upload_requests_id from dp_complainant_upload_requests where package_id=?) and status='Passed'";
			log.info(String.format("Complainant sql to update is uploaded is false : %s", sql));

			jdbcTemplate.update(sql, paramNotification);
			log.info(String.format("Complainant Failed :: IsSuccessfull Message: %s", message.getIsSuccessful()));
			log.info(String.format("Complainant Notification data updated is_uploaded as false in Database for package Id : %s",
					message.getPackageId()));

			return FAILED;

		} else if (TRUE.equalsIgnoreCase(message.getIsSuccessful())) {

			Object[] paramNotification = new Object[] { message.getPackageId() };
			log.info(String.format("Complainant Passed for package id : %s", message.getPackageId()));

			String sql = "update dp_complainant_upload_request_files set is_uploaded ='true' where complainant_upload_requests_id IN (select complainant_upload_requests_id from dp_complainant_upload_requests where package_id=?) and status='Passed'";
			log.info(String.format("Complainant sql to update is uploaded is true : %s", sql));

			jdbcTemplate.update(sql, paramNotification);
			log.info(String.format(
					"Complainant In Upload Request Files data updated for is_uploaded as true for package Id : %s",
					message.getPackageId()));
		}
		return SUCCESS;
		
	}

	private JdbcTemplate jdbcConnection() {
		JdbcTemplate jdbcTemplateConn;
		DriverManagerDataSource dataSource = new DriverManagerDataSource();
		dataSource.setDriverClassName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
		dataSource.setUrl(System.getenv("SQL_DATASOURCE_URL"));
		dataSource.setUsername(System.getenv("SQL_DATASOURCE_USERNAME"));
		dataSource.setPassword(System.getenv("SQL_DATASOURCE_PASSWORD"));
		jdbcTemplateConn = new JdbcTemplate(dataSource);
		return jdbcTemplateConn;
	}

}
