package com.ombudsman.service.common.model;

import java.time.OffsetDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "dp_upload_request_files")
public class UploadRequestFile {
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Id
	@Column(name = "id")
	private int id;
	@Column(name = "upload_request_id")
	private int uploadRequestId;
	@Column(name = "status")
	private String status;
	@Column(name = "comments")
	private String comments;
	@Column(name = "last_updated_time")
	private OffsetDateTime lastUpdatedTime;
	@Column(name = "file_name")
	private String fileName;
	@Column(name = "document_id")
	private String documentId;
	@Column(name = "file_size")
	private String fileSize;
	@Column(name = "is_uploaded")
	private boolean isUploaded;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getUploadRequestId() {
		return uploadRequestId;
	}

	public void setUploadRequestId(int uploadRequestId) {
		this.uploadRequestId = uploadRequestId;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public OffsetDateTime getLastUpdatedTime() {
		return lastUpdatedTime;
	}

	public void setLastUpdatedTime(OffsetDateTime lastUpdatedTime) {
		this.lastUpdatedTime = lastUpdatedTime;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getDocumentId() {
		return documentId;
	}

	public void setDocumentId(String documentId) {
		this.documentId = documentId;
	}

	public String getFileSize() {
		return fileSize;
	}

	public void setFileSize(String fileSize) {
		this.fileSize = fileSize;
	}

	public boolean getUploaded() {
		return isUploaded;
	}

	public void setUploaded(boolean isUploaded) {
		this.isUploaded = isUploaded;
	}

}
