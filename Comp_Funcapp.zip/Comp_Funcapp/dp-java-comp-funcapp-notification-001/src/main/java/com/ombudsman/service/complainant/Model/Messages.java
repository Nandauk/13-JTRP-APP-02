package com.ombudsman.service.complainant.Model;
import java.util.List;

import com.google.gson.annotations.SerializedName;


public class Messages {

	@SerializedName("From")
	From From;

	@SerializedName("To")
	List<To> To;

	@SerializedName("TemplateID")
	Long TemplateID;

	@SerializedName("TemplateLanguage")
	boolean TemplateLanguage;

	@SerializedName("Variables")
	MailjetVariables Variables;


	public MailjetVariables getVariables() {
		return Variables;
	}
	public void setVariables(MailjetVariables variables) {
		Variables = variables;
	}
	public void setFrom(From From) {
		this.From = From;
	}
	public From getFrom() {
		return From;
	}

	public void setTo(List<To> To) {
		this.To = To;
	}
	public List<To> getTo() {
		return To;
	}

	public void setTemplateID(Long TemplateID) {
		this.TemplateID = TemplateID;
	}
	public Long getTemplateID() {
		return TemplateID;
	}

	public void setTemplateLanguage(boolean TemplateLanguage) {
		this.TemplateLanguage = TemplateLanguage;
	}
	public boolean getTemplateLanguage() {
		return TemplateLanguage;
	}



}