package com.ombudsman.service.complainant.components;

import java.util.concurrent.TimeUnit;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.jdbc.core.JdbcTemplate;


import com.fasterxml.jackson.core.JsonProcessingException;
import com.microsoft.azure.servicebus.primitives.ServiceBusException;
import com.ombudsman.service.complainant.Model.NotificationRequest;
import com.ombudsman.service.complainant.Model.UserMailjetRequest;
import com.ombudsman.service.complainant.Model.UserRequestBody;
import com.ombudsman.service.complainant.exception.MessageSaveException;

public class RetryMechanism {

	private static final int MAX_RETRIES = 1;
	private static final int[] RETRY_INTERVALS = {1,3,3};
	private static final String FAILURE = "failure";
	private static final String RETRY_INTERRUPTED = "Retry interrupted.";
	private static final String NOTIFICATION_SENT = "Notification sent successfully.";
	private static final String FAILED_TO_SEND_NOTIFICATION = "Failed to send notification after ";
	Logger log = LogManager.getRootLogger();
	public void sendInAppNotificationWithRetry(NotificationRequest notificationRequest,JdbcTemplate jdbcTemplate) throws JsonProcessingException, InterruptedException, ServiceBusException {
		int attempt = 0;
		while (attempt < MAX_RETRIES) {
			try {
				log.info("Attempting to  saving message. Attempt: {}", attempt + 1);
				String sql = "INSERT INTO dp_complainant_user_notification (request_id, user_oid, requesting_activity_name, notification_status_id, message, file_download_url, created_on,created_by, modified_on, modified_by) " +
						"VALUES (?, ?, ?, ?, ?, ?, ?, ?,?,?)";
				Object[] params = new Object[] {
						notificationRequest.getRequestId(),
						notificationRequest.getUserOid(),
						notificationRequest.getRequestingActivityName(),
						notificationRequest.getNotificationStatusId(),
						notificationRequest.getMessage(),
						notificationRequest.getFileDownloadUrl(),
						notificationRequest.getCreatedOn(),
						notificationRequest.getCreatedBy(),
						notificationRequest.getModifiedOn(),
						notificationRequest.getModifiedBy()
				};
				jdbcTemplate.update(sql, params);
				return;
			} catch (Exception e) {
				log.error("Error saving message. Attempt: {}", attempt + 1, e);
				attempt++;
				if (attempt >= MAX_RETRIES) {
					System.out.println("The exception "+e.toString());
					throw new MessageSaveException("Failed to save message after " + MAX_RETRIES + " attempts", e);

				}
				sleepBeforeRetry(attempt);
			}
		}
	}
	public void sendEmailNotificationWithRetry(UserRequestBody mailBody) throws JsonProcessingException, InterruptedException, ServiceBusException {	
		int attempt = 0;
		MailjetWebclient mailjetwebclientcall=new MailjetWebclient();

	while (attempt < MAX_RETRIES) {
		try {
			log.info("Attempting to  sending email. Attempt: {}", attempt + 1);
			mailjetwebclientcall.sendemail(mailBody);
			return;
		} catch (Exception e) {
			log.error("Error sending email. Attempt: {}", attempt + 1, e);
			attempt++;
			if (attempt >= MAX_RETRIES) {
				throw new MessageSaveException("Failed to save message after " + MAX_RETRIES + " attempts", e);
			}
			sleepBeforeRetry(attempt);
		}
	}
	}

	//	private void sendFailureMessageToSupportQueue(Object notification, GenericResponse response) throws JsonProcessingException, InterruptedException, ServiceBusException {
	//		DPSupportQueueModel error = new DPSupportQueueModel();
	//		try {
	//			error.setTempDigitalMessageProcessingId(UUID.randomUUID().toString());
	//			error.setCaseReferenceNumberIncidentId(UUID.randomUUID().toString());
	//			error.setFailedSbMessageId(UUID.randomUUID().toString());
	//			error.setSource(notification.getClass().getSimpleName());
	//			error.setOutgoingDigitalMessageProcessorWorkerFunction("RetryMechanism");
	//			error.setErrorInfo(response.getStatus());
	//			error.setErrorDetails(response.getMessage());
	//			error.setDateTimeErrorOccurred(new Date().toString());
	//
	//			messageSender.sendFailureMessage(error);
	//		}
	//		catch(Exception e)
	//		{
	//
	//		}
	//	}
	private void sleepBeforeRetry(int attempt) {
		try {
			TimeUnit.MINUTES.sleep(RETRY_INTERVALS[attempt - 1]);
		} catch (InterruptedException ie) {
			Thread.currentThread().interrupt();
			throw new RuntimeException("Thread interrupted during retry delay", ie);
		}
	}
}