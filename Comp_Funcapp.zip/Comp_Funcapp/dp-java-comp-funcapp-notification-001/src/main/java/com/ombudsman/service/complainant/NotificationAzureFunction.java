package com.ombudsman.service.complainant;

import java.beans.Transient;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.microsoft.azure.functions.ExecutionContext;
import com.microsoft.azure.functions.OutputBinding;
import com.microsoft.azure.functions.annotation.BindingName;
import com.microsoft.azure.functions.annotation.FunctionName;
import com.microsoft.azure.functions.annotation.ServiceBusQueueOutput;
import com.microsoft.azure.functions.annotation.ServiceBusQueueTrigger;
import com.microsoft.azure.functions.annotation.TimerTrigger;
import com.microsoft.azure.servicebus.primitives.ServiceBusException;
import com.ombudsman.service.complainant.Model.DPSupportQueueModel;
import com.ombudsman.service.complainant.Model.IncomingNotificationPhx;
import com.ombudsman.service.complainant.Model.NotificationRequest;
import com.ombudsman.service.complainant.Model.SinchModel;
import com.ombudsman.service.complainant.Model.UserRequestBody;
import com.ombudsman.service.complainant.Model.Response.SinchApiResponse;
import com.ombudsman.service.complainant.components.MailjetWebclient;
import com.ombudsman.service.complainant.components.RetryMechanism;
import com.ombudsman.service.complainant.components.SinchSmsCall;


public class NotificationAzureFunction {

	Logger log = LogManager.getRootLogger();
	private static final LocalTime MORNING_CUTOFF = parseCutoffTime(System.getenv("START_TIME"));//"06:30"
	private static final LocalTime EVENING_CUTOFF = parseCutoffTime(System.getenv("END_TIME"));//"21:45"
	private static final String templateId=System.getenv("TEMPLATEID");
	private static final String templateName="New DocumentNotification";
	private static final String FROM="Ombudsman";
	private static final String SignInUrl=System.getenv("SIGNURL");
	private static final String BATCHSIZE=System.getenv("BATCH_SIZE");
	private static final String PORTAL="COMPLAINANT";
	private static final String fromDB="InProgress";
	private static final String afterDB="PushedForProcessing";
	private static final String TIMERANGE=System.getenv("TIME_RANGE");
	final JdbcTemplate jdbcTemplate = jdbcConnection();
	private JdbcTemplate jdbcConnection() {
		JdbcTemplate jdbcTemplateConn;
		DriverManagerDataSource dataSource = new DriverManagerDataSource();
		dataSource.setDriverClassName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
		dataSource.setUrl(System.getenv("SQL_DATASOURCE_URL"));
		dataSource.setUsername(System.getenv("SQL_DATASOURCE_USERNAME"));
		dataSource.setPassword(System.getenv("SQL_DATASOURCE_PASSWORD"));
		jdbcTemplateConn = new JdbcTemplate(dataSource);
		return jdbcTemplateConn;
	}
	@FunctionName("HandleIncomingNotification")
	@Transient(true)
	public void handleIncomingNotification(
			@ServiceBusQueueTrigger(name = "message", queueName = "%QueueNameNotificationFromFOS%", connection = "AzureWebJobsServiceBusExt") String messagefromphx,@BindingName("MessageId") String messageId,
			@ServiceBusQueueOutput(name = "outputMessage", queueName = "%DPSupportQueue%", connection = "AzureWebJobsServiceBusInt") OutputBinding<String> outputMessage,
			final ExecutionContext context) throws JsonMappingException, JsonProcessingException {

		log.info(String.format("The message received from the queue is :%s",messagefromphx));
		String queueName=System.getenv("QUEUENAME");
		ObjectMapper mapper=new ObjectMapper();
		mapper.registerModule(new JavaTimeModule());
		//To maintain the exact date format while Serialization
		mapper.disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
		IncomingNotificationPhx message=mapper.readValue(messagefromphx, IncomingNotificationPhx.class);
		OffsetDateTime enqueuedTime=null;
		if("E-File Modification".equalsIgnoreCase(message.getSource())||"Correspondence Generated".equalsIgnoreCase(message.getSource()))
		{
			if("E-File Modification".equalsIgnoreCase(message.getSource()))
			{
				enqueuedTime=message.getEfileModifiedDateTime();
			}
			else {
				enqueuedTime=message.getCorrespondenceDateTime();
			}
			LocalDateTime messageArrivalTime =enqueuedTime.toLocalDateTime();
			LocalDateTime deliveryTime=calculateDeferredTime(enqueuedTime.toZonedDateTime());
			String  document_received_notification_id=UUID.randomUUID().toString();
			String messageProcessingStatus="ReadyForProcess";
			try
			{
				String source=message.getSource();
				message.setEventFor(source);
				message.setSource("NotifyCaseParties");
				message.setDocumentReceivedNotificationID(document_received_notification_id);
				String messagetoDB=mapper.writeValueAsString(message);
				log.info("From Service Bus to DB Started");
				String sql = "INSERT INTO dp_incoming_document_notification_processing (document_received_notification_id, service_bus_queue_message_id, message_body, message_arrival_datetime, deferred_message_delivery_datetime, message_processing_status,subscriber_portal) " +
						"VALUES (?, ?, ?, ?, ?, ?,?)";
				Object[] params = new Object[] {
						document_received_notification_id,messageId,messagetoDB,messageArrivalTime,deliveryTime,messageProcessingStatus,PORTAL};
				jdbcTemplate.update(sql, params);
				log.info("From Service Bus to DB End");
			}
			catch(Exception e)
			{
				log.error(String.format("The exception suring the insert to Table:%s", e.toString()));
			}

		}
		else if(message.getSource().equalsIgnoreCase("NotifyCaseParties"))
		{
			log.info(String.format("The message received from the queue is :{}",messagefromphx));
			boolean flagDpsupport=false;
			try {
				if ("Correspondence Generated".equalsIgnoreCase(message.getEventFor())) {
					log.info("The source recieved from the Queue is CorrespondenceGenerated");
					Map<String,Object> userDetails = querySP(message.getCaseId(), message.getComplainantContactId());
					log.info(String.format("The Details of the user retrieved from the DB are :%s" ,userDetails));
					List<Map<String,String>>listOfDetails=(List<Map<String, String>>) userDetails.get("#result-set-1");
					if(!listOfDetails.isEmpty())
					{
						for(Map<String, String> values:listOfDetails)
						{
							sendingNotificationHelper(values, message);
						}

					}
					else
					{						
						log.error(String.format("The Details of the user retived from the DB NULL"));
						flagDpsupport=true;
					}

				} else if ("E-File Modification".equalsIgnoreCase(message.getEventFor())) {
					log.info("The source recieved from the Queue is EfileGenerated");
					Map<String,Object> userDetails = querySP(message.getCaseId(), null);
					List<Map<String,String>>listOfDetails=(List<Map<String, String>>) userDetails.get("#result-set-1");
					log.info(String.format("The Details of the user retived from the DB are :%s" ,listOfDetails));
					if(!listOfDetails.isEmpty())
					{
						for(Map<String, String> values:listOfDetails)
						{
							sendingNotificationHelper(values, message);
						}

					}
					else
					{
						log.error(String.format("The Details of the user retived from the DB NULL"));
						flagDpsupport=true;
					}
				}

				else {
					log.error("Unknown source from phoenix: " + message.getSource());
				}
				log.info("the flagDpsupport:"+flagDpsupport);
				if(flagDpsupport)
				{
					String dpSupportQueuevalues=dpSupport(message.getCaseId(),messageId,queueName,"HandleIncomingNotification","DB Exception","Getting Null values while querying SP prc_getQualifiedNotificationRecordsForReceivingDocuments");
					log.info(String.format("DpSupport team values is :%s",dpSupportQueuevalues));
					outputMessage.setValue(dpSupportQueuevalues);
					log.info("DpSupport team email is sent");
				}
			}

			catch (Exception e) {
				log.error("Exception occurred:{}" + e.getMessage());
				String errorInfo=null;
				if(null!=e.getClass().getName())
				{
					errorInfo=e.getClass().getName();
				}
				String dpSupportQueuevalues=dpSupport(message.getCaseId(),messageId,queueName,"HandleIncomingNotification",errorInfo,e.getMessage());
				outputMessage.setValue(dpSupportQueuevalues);
			}
		}
	}
	@FunctionName("TimetiggerFromDBtoSB")
	public void timeTriggerfromDBtoSB(
			@TimerTrigger(name="timerInfo",schedule="0 */5 * * * *")String timerInfo,
			@ServiceBusQueueOutput(name = "outputMessage", queueName = "%QueueNameNotificationFromFOS%", connection = "AzureWebJobsServiceBusExt") OutputBinding<List<String>> outputMessage,final ExecutionContext context) throws JsonMappingException, JsonProcessingException

	{

		int limit=Integer.valueOf(BATCHSIZE);
		String messageProcessingStatus="ReadyForProcess";
		String sql="select TOP (?) message_body from dp_incoming_document_notification_processing where message_processing_status=? and deferred_message_delivery_datetime<= getUTCdate() ORDER BY deferred_message_delivery_datetime DESC";
		List<String>listOfMessage=jdbcTemplate.queryForList(sql,String.class,limit,messageProcessingStatus);
		log.info(String.format("The message size that fetched From DB to SB is :%d", listOfMessage.size()));
		if(!listOfMessage.isEmpty())
		{
			List<String>outputQueue=new ArrayList<>();
			for(String queueMessage:listOfMessage)
			{
				updateStaggingTable(queueMessage,fromDB);
				outputQueue.add(queueMessage);
			}
			outputMessage.setValue(outputQueue);
			log.info(String.format("The message pushed from DB to SB is :%s",outputQueue.toString()));
			if(!outputQueue.isEmpty())
			{
				for(String messageUpdate:outputQueue)
				{
					updateStaggingTable(messageUpdate,afterDB);
					log.info(String.format("The message status is changed to pushForprocessing :%s",messageUpdate));
				}
			}
		}
	}


	private void handleNotificationBasedOnStatus(RetryMechanism retryMechanism, String actionSessionStatus, String communicationMode,UserRequestBody mailBody,SinchModel smsModel ) throws JsonProcessingException {
		boolean activeStatus=Boolean.valueOf(actionSessionStatus);
		log.info("Handling notification based on User status: " + activeStatus);
		if (!activeStatus) {
			if ("phone".equalsIgnoreCase(communicationMode)) {
				SinchSmsCall smsCall=new SinchSmsCall();
				log.info(String.format("The request for Sinch: %s",converterOfObjecttoString(smsModel)));
				SinchApiResponse response = smsCall.sendSms(smsModel);
				log.info(String.format("The response from Sinch: %s",converterOfObjecttoString(response)));

			} else {
				log.info("Handling email notification");
				processDocumentEmail(retryMechanism, mailBody);
			}
		}
	}
	private void processNotification(RetryMechanism retryMechanism, String userId,String phxCaseNumber) {
		log.info("Processing notification for user ID: " + userId);
		NotificationRequest notificationRequest = sendInAppNotification(userId,phxCaseNumber);
		try {
			String sql = "INSERT INTO dp_complainant_user_notification (request_id, user_oid, requesting_activity_name, notification_status_id, message, file_download_url, created_on, created_by, modified_on, modified_by) " +
					"VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?,?)";
			Object[] params = new Object[]{
					notificationRequest.getRequestId(),
					notificationRequest.getUserOid(),
					notificationRequest.getRequestingActivityName(),
					notificationRequest.getNotificationStatusId(),
					notificationRequest.getMessage(),
					notificationRequest.getFileDownloadUrl(),
					notificationRequest.getCreatedOn(),
					notificationRequest.getCreatedBy(),
					notificationRequest.getModifiedOn(),
					notificationRequest.getModifiedBy()
			};
			jdbcTemplate.update(sql, params);
		} catch (Exception e) {
			log.info("Error inserting notification: " + e.getMessage());
			try {
				retryMechanism.sendInAppNotificationWithRetry(notificationRequest, jdbcTemplate);
			} catch (JsonProcessingException | InterruptedException | ServiceBusException ex) {
				log.info("Retry failed: " + ex.getMessage());
			}
		}
	}

	private void processDocumentEmail(RetryMechanism retryMechanism, UserRequestBody mailBody) {
		log.info("Processing document email for: " + mailBody.getEmailId());
		MailjetWebclient mailjetwebclientcall=new MailjetWebclient();
		try {
			mailjetwebclientcall.sendemail(mailBody);

		} catch (Exception e) {
			log.error("Error sending email: " + e.getMessage());
			try {
				retryMechanism.sendEmailNotificationWithRetry(mailBody);
			} catch (JsonProcessingException | InterruptedException | ServiceBusException ex) {
				log.error("Retry failed: " + ex.getMessage());
			}
		}
	}

	public NotificationRequest sendInAppNotification(String userId, String phxCaseNumber) {
		log.info("Sending in-app notification for user ID: " + userId);
		NotificationRequest notification = new NotificationRequest();
		notification.setRequestId(UUID.randomUUID().toString());
		notification.setUserOid(userId);
		notification.setRequestingActivityName("newDocument");
		notification.setNotificationStatusId(1);
		notification.setMessage(phxCaseNumber+":newDocument");
		notification.setFileDownloadUrl(null);
		notification.setCreatedBy("Financial Ombudsman Service");
		notification.setCreatedOn(getutcTime());
		notification.setModifiedOn(null);
		notification.setModifiedBy(null);
		return notification;
	}

	private Map<String, Object> querySP(String incidentId,String contactId)
	{
		String finalContactID=(contactId==null||contactId.trim().isEmpty()?"#":contactId);
		SimpleJdbcCall jdbcCall=new SimpleJdbcCall(jdbcTemplate).withProcedureName("prc_getQualifiedNotificationRecordsForReceivingDocuments");
		MapSqlParameterSource inparams=new MapSqlParameterSource()
				.addValue("incidentids", incidentId)
				.addValue("contactids", finalContactID);
		return jdbcCall.execute(inparams);
	}
	public String dpSupport(String caseReferenceNumberIncidentId,String failedSbMessageId,String source,String outgoingDigitalMessageProcessorWorkerFunction,String errorInfo,String errorDetails ) throws JsonProcessingException
	{

		DPSupportQueueModel supportModel=new DPSupportQueueModel();
		supportModel.setCaseReferenceNumberIncidentId(caseReferenceNumberIncidentId);
		supportModel.setDateTimeErrorOccurred(LocalDateTime.now().toString());
		supportModel.setFailedSbMessageId(failedSbMessageId);
		supportModel.setSource(source);
		supportModel.setOutgoingDigitalMessageProcessorWorkerFunction(outgoingDigitalMessageProcessorWorkerFunction);
		supportModel.setErrorInfo(errorInfo);
		supportModel.setErrorDetails(errorDetails);
		ObjectMapper mapper=new ObjectMapper();
		return mapper.writeValueAsString(mapper);
	}
	private LocalDateTime getutcTime()
	{
		ZonedDateTime utcTime=ZonedDateTime.now(ZoneOffset.UTC);
		LocalDateTime createdon=utcTime.toLocalDateTime();
		return createdon;
	}
	public String converterOfObjecttoString(Object objectToConvert) throws JsonProcessingException
	{
		ObjectMapper mapper=new ObjectMapper();
		mapper.registerModule(new JavaTimeModule());
		return mapper.writeValueAsString(objectToConvert);
	}
	private void updateStaggingTable(String docID)
	{
		String status="NotificationSent";
		try {
			String updateSql = "UPDATE dp_incoming_document_notification_processing SET message_processing_status = ? WHERE document_received_notification_id = ?";
			Object[] params = new Object[] {status,docID};

			jdbcTemplate.update(updateSql, params);
		}
		catch(Exception e)
		{
			log.info(String.format("the exception while updating the stagging table", e.toString()));
		}
	}
	private void updateStaggingTable(String messageBody,String status) throws JsonMappingException, JsonProcessingException
	{
		ObjectMapper mapper=new ObjectMapper();
		mapper.registerModule(new JavaTimeModule());
		IncomingNotificationPhx messageFromDB=mapper.readValue(messageBody, IncomingNotificationPhx.class);
		String documentId=messageFromDB.getDocumentReceivedNotificationID();
		log.info(String.format("the documentId: %s for Updateing "+status,documentId));

		try {
			String updateSql = "UPDATE dp_incoming_document_notification_processing SET message_processing_status = ? WHERE document_received_notification_id = ?";
			Object[] params = new Object[] {status,documentId};

			jdbcTemplate.update(updateSql, params);
		}
		catch(Exception e)
		{
			log.info(String.format("the exception while updating the stagging table", e.toString()));
		}
	}
	public void sendingNotificationHelper(Map<String, String>values,IncomingNotificationPhx message) throws JsonProcessingException
	{
		RetryMechanism retryMechanism = new RetryMechanism();
		UserRequestBody mailBody=new UserRequestBody();
		SinchModel smsModel=new SinchModel();
		String smsBody=System.getenv("SMS_BODY");
		Map<String,Object>Variables=new HashMap<>();
		if("phone".equalsIgnoreCase(values.get("comPref")))
		{
			if(!StringUtils.isEmpty(values.get("phone")))
			{
				//replace the ' quotes from the Sms Body else pipeline will fail 
				smsBody=smsBody.replaceAll("'", "");
				smsModel.setBody(smsBody.replaceAll("\\\\n", "\n"));
				smsModel.setTo(List.of(values.get("phone")));
				processNotification(retryMechanism, values.get("oid"),values.get("caseRefNumber"));
				handleNotificationBasedOnStatus(retryMechanism, values.get("userActiveSessionStatus"), values.get("comPref"), mailBody,smsModel);
				updateStaggingTable(message.getDocumentReceivedNotificationID());

			}
			else
			{
				log.info(String.format("Phone is Null for the useroid: %s",values.get("oid")));

			}

		}
		else
		{
			String firstName=values.get("first_name");
			mailBody.setEmailId(values.get("contactEmailAddress"));
			mailBody.setFullName(firstName);
			mailBody.setTemplateName(templateName);
			mailBody.setTemplateID(Integer.valueOf(templateId));
			Variables.put("portal_User", firstName);
			Variables.put("sign_In", SignInUrl);
			mailBody.setVariables(Variables);
			log.info(String.format("The mailbody to Communication service:%s", mailBody));
			processNotification(retryMechanism, values.get("oid"),values.get("caseRefNumber"));
			handleNotificationBasedOnStatus(retryMechanism, values.get("userActiveSessionStatus"), values.get("comPref"), mailBody,smsModel);
			updateStaggingTable(message.getDocumentReceivedNotificationID());


		}
		log.info("The Notification is sent to the User");
	}
	public  LocalDateTime calculateDeferredTime(ZonedDateTime arrivalTimeUTC) {

		LocalTime arrivalTimeOnly = arrivalTimeUTC.toLocalTime();
		if (arrivalTimeOnly.isAfter(MORNING_CUTOFF) && arrivalTimeOnly.isBefore(EVENING_CUTOFF)) {
			return arrivalTimeUTC.plusMinutes(Integer.parseInt(TIMERANGE)).toLocalDateTime();
		}
		if (arrivalTimeOnly.isBefore(MORNING_CUTOFF)) {
			return arrivalTimeUTC
					.withHour(6).withMinute(30)
					.withSecond(0).withNano(0)
					.toLocalDateTime();
		}
		return arrivalTimeUTC.plusDays(1)
				.withHour(6).withMinute(30)
				.withSecond(0).withNano(0)
				.toLocalDateTime();

	}
	private static  LocalTime parseCutoffTime(String timeStr) {
		if (timeStr == null || !timeStr.matches("\\d{1,2}:\\d{2}")) {
			throw new IllegalArgumentException("Invalid cutoff time format: " + timeStr);
		}
		String[] parts = timeStr.split(":");
		int hour = Integer.parseInt(parts[0]);
		int minute = Integer.parseInt(parts[1]);
		return LocalTime.of(hour, minute);
	}
}
