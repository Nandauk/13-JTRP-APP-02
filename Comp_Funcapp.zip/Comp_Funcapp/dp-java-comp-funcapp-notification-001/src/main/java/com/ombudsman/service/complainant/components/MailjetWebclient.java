package com.ombudsman.service.complainant.components;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.MediaType;
import org.springframework.web.reactive.function.client.WebClient;

import com.ombudsman.service.complainant.Model.SinchModel;
import com.ombudsman.service.complainant.Model.UserRequestBody;
import com.ombudsman.service.complainant.Model.Response.EmailNotificationResponse;

public class MailjetWebclient {
	private static final String ENPOINT="/compcommunicationservice/compcommunicationservice/v1/communicationservice/sendemailtoUser";
	Logger LOG = LogManager.getRootLogger();

	final static String xapiKey=System.getenv("XAPIKEY");
	public EmailNotificationResponse sendemail(UserRequestBody mailBody)
	{
		LOG.info("Inside the mailjetwebclient call");
		var response=new EmailNotificationResponse();
		final String apimURL=System.getenv("APIM_URL")+ENPOINT;
		try {
			response = WebClient.create().post().uri(apimURL).header("X-API-KEY", xapiKey)
					.contentType(MediaType.APPLICATION_JSON).bodyValue(mailBody)
					.accept(MediaType.APPLICATION_JSON)
					.retrieve()
					.bodyToMono(EmailNotificationResponse.class).block();
			LOG.info("Inside the mailjetwebclient call ended");
			
		} catch (Exception e) {
			LOG.error("Exception occured while calling Session API: {} ", e.getMessage());
		}
		return response;

	}

}
