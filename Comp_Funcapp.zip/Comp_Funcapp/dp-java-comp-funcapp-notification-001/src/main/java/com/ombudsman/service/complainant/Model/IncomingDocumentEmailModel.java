package com.ombudsman.service.complainant.Model;

public class IncomingDocumentEmailModel {

	private String siginURL;
	private String userName;
	private String emailId;
	private String templateName;
	public String getTemplateName() {
		return templateName;
	}
	public void setTemplateName(String templateName) {
		this.templateName = templateName;
	}
	public String getSiginURL() {
		return siginURL;
	}
	public void setSiginURL(String siginURL) {
		this.siginURL = siginURL;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
}
