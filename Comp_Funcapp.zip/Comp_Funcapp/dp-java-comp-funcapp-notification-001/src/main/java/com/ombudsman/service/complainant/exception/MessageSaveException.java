package com.ombudsman.service.complainant.exception;
public class MessageSaveException extends RuntimeException {
    public MessageSaveException(String message, Throwable cause) {
        super(message, cause);
    }
}
