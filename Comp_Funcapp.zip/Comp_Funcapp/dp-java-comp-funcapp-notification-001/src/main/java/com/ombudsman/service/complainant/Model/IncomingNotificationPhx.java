package com.ombudsman.service.complainant.Model;

import java.time.OffsetDateTime;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
@JsonIgnoreProperties(ignoreUnknown = true)
public class IncomingNotificationPhx {
	@JsonProperty("DocumentReceivedNotificationID")
	private String documentReceivedNotificationID;
	@JsonProperty("PortalType")
	private String portalType;
	@JsonProperty("CaseId")
	private String caseId;
	@JsonProperty("Source")
	private String source;
	@JsonProperty("EfileModifiedDateTime")
	private OffsetDateTime efileModifiedDateTime;
	@JsonProperty("FilesModified")
	private List<FilesModified> filesModified;
	@JsonProperty("ComplainantContactId")
	private String complainantContactId;
	@JsonProperty("ActivityId")
	private String activityId;
	@JsonProperty("CorrespondenceDateTime")
	private OffsetDateTime correspondenceDateTime;
	@JsonProperty("EventFor")
	private String eventFor;
	public String getDocumentReceivedNotificationID() {
		return documentReceivedNotificationID;
	}
	public void setDocumentReceivedNotificationID(String documentReceivedNotificationID) {
		this.documentReceivedNotificationID = documentReceivedNotificationID;
	}
	public String getPortalType() {
		return portalType;
	}
	public void setPortalType(String portalType) {
		this.portalType = portalType;
	}
	public String getCaseId() {
		return caseId;
	}
	public void setCaseId(String caseId) {
		this.caseId = caseId;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public OffsetDateTime getEfileModifiedDateTime() {
		return efileModifiedDateTime;
	}
	public void setEfileModifiedDateTime(OffsetDateTime efileModifiedDateTime) {
		this.efileModifiedDateTime = efileModifiedDateTime;
	}
	public List<FilesModified> getFilesModified() {
		return filesModified;
	}
	public void setFilesModified(List<FilesModified> filesModified) {
		this.filesModified = filesModified;
	}
	public String getComplainantContactId() {
		return complainantContactId;
	}
	public void setComplainantContactId(String complainantContactId) {
		this.complainantContactId = complainantContactId;
	}
	public String getActivityId() {
		return activityId;
	}
	public void setActivityId(String activityId) {
		this.activityId = activityId;
	}
	public OffsetDateTime getCorrespondenceDateTime() {
		return correspondenceDateTime;
	}
	public void setCorrespondenceDateTime(OffsetDateTime correspondenceDateTime) {
		this.correspondenceDateTime = correspondenceDateTime;
	}
	public String getEventFor() {
		return eventFor;
	}
	public void setEventFor(String eventFor) {
		this.eventFor = eventFor;
	}
	
	
	}


