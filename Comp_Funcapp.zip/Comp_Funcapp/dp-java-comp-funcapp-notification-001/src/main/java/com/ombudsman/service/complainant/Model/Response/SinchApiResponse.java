package com.ombudsman.service.complainant.Model.Response;

import java.util.List;

import org.springframework.http.HttpStatus;

public class SinchApiResponse {
	
	String status;
	  String message;
	  HttpStatus httpStatus;
	  
	  public String getStatus() {
	      return status;
	  }
	  public void setStatus(String status) {
	      this.status = status;
	  }
	  public String getMessage() {
	      return message;
	  }
	  public void setMessage(String message) {
	      this.message = message;
	  }
	public HttpStatus getHttpStatus() {
		return httpStatus;
	}
	public void setHttpStatus(HttpStatus httpStatus) {
		this.httpStatus = httpStatus;
	}

}
