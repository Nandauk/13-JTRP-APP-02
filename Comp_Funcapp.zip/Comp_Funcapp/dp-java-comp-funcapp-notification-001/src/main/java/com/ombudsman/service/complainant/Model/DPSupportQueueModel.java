package com.ombudsman.service.complainant.Model;

public class DPSupportQueueModel {
	 private String tempDigitalMessageProcessingId;
	    private String caseReferenceNumberIncidentId;
	    private String failedSbMessageId;
	    private String source;
	    private String outgoingDigitalMessageProcessorWorkerFunction;
	    private String errorInfo;
	    private String errorDetails;
	    private String dateTimeErrorOccurred;
		public String getTempDigitalMessageProcessingId() {
			return tempDigitalMessageProcessingId;
		}
		public void setTempDigitalMessageProcessingId(String tempDigitalMessageProcessingId) {
			this.tempDigitalMessageProcessingId = tempDigitalMessageProcessingId;
		}
		public String getCaseReferenceNumberIncidentId() {
			return caseReferenceNumberIncidentId;
		}
		public void setCaseReferenceNumberIncidentId(String caseReferenceNumberIncidentId) {
			this.caseReferenceNumberIncidentId = caseReferenceNumberIncidentId;
		}
		public String getFailedSbMessageId() {
			return failedSbMessageId;
		}
		public void setFailedSbMessageId(String failedSbMessageId) {
			this.failedSbMessageId = failedSbMessageId;
		}
		public String getSource() {
			return source;
		}
		public void setSource(String source) {
			this.source = source;
		}
		public String getOutgoingDigitalMessageProcessorWorkerFunction() {
			return outgoingDigitalMessageProcessorWorkerFunction;
		}
		public void setOutgoingDigitalMessageProcessorWorkerFunction(String outgoingDigitalMessageProcessorWorkerFunction) {
			this.outgoingDigitalMessageProcessorWorkerFunction = outgoingDigitalMessageProcessorWorkerFunction;
		}
		public String getErrorInfo() {
			return errorInfo;
		}
		public void setErrorInfo(String errorInfo) {
			this.errorInfo = errorInfo;
		}
		public String getErrorDetails() {
			return errorDetails;
		}
		public void setErrorDetails(String errorDetails) {
			this.errorDetails = errorDetails;
		}
		public String getDateTimeErrorOccurred() {
			return dateTimeErrorOccurred;
		}
		public void setDateTimeErrorOccurred(String dateTimeErrorOccurred) {
			this.dateTimeErrorOccurred = dateTimeErrorOccurred;
		}
	    
}
