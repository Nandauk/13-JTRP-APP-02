package com.ombudsman.service.complainant.Model;

import java.util.Map;

import com.fasterxml.jackson.annotation.JsonProperty;

public class UserRequestBody {

	@JsonProperty("emailId")
	String emailId;
	
	@JsonProperty("fullName")
	String fullName;
	
	@JsonProperty("templateID")
	int templateID;
	
	@JsonProperty("templateName")
	String templateName;

	@JsonProperty("Variables")
	private Map<String,Object> Variables;

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public int getTemplateID() {
		return templateID;
	}

	public void setTemplateID(int templateID) {
		this.templateID = templateID;
	}

	public String getTemplateName() {
		return templateName;
	}

	public void setTemplateName(String templateName) {
		this.templateName = templateName;
	}

	public Map<String, Object> getVariables() {
		return Variables;
	}

	public void setVariables(Map<String, Object> variables) {
		this.Variables = variables;
	}
	
	
}
