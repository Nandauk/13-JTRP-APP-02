package com.ombudsman.service.complainant.components;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.http.MediaType;
import com.ombudsman.service.complainant.Model.SinchModel;
import com.ombudsman.service.complainant.Model.Response.SinchApiResponse;

public class SinchSmsCall {

	private static final String ENPOINT="/compcommunicationservice/compcommunicationservice/v1/communicationservice/sendsms";
	Logger LOG = LogManager.getRootLogger();
	final static String xapiKey=System.getenv("XAPIKEY");
	public SinchApiResponse sendSms(SinchModel smsRequest)
	{
		var response=new SinchApiResponse();
		final String apimURL=System.getenv("APIM_URL")+ENPOINT;
		try {
			response = WebClient.create().post().uri(apimURL).header("X-API-KEY", xapiKey)
					.contentType(MediaType.APPLICATION_JSON).bodyValue(smsRequest)
					.accept(MediaType.APPLICATION_JSON)
					.retrieve()
					.bodyToMono(SinchApiResponse.class).block();
		} catch (Exception e) {
			LOG.error("Exception occured while calling Session API: {} ", e.getMessage());
		}
		return response;

	}

}
