package com.ombudsman.service.complainant.Model;

public class UserMailjetRequest {


	private String emailId;
	private String fullName;
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getFullName() {
		return fullName;
	}
	public void setFullName(String fullName) {
		this.fullName = fullName;
	}
	
}
