//package com.ombudsman.service.complainant;
//
//import static org.junit.jupiter.api.Assertions.assertArrayEquals;
//import static org.junit.jupiter.api.Assertions.assertEquals;
//import static org.junit.jupiter.api.Assertions.assertNotEquals;
//import static org.mockito.Mockito.*;
//
//import java.lang.reflect.Method;
//import java.time.LocalDateTime;
//import java.util.HashMap;
//import java.util.List;
//import java.util.Map;
//import java.util.UUID;
//import static org.junit.jupiter.api.Assertions.assertEquals;
//import static org.mockito.Mockito.*;
//
//import java.lang.reflect.Field;
//import java.lang.reflect.Method;
//import java.util.HashMap;
//import java.util.Map;
//
//import org.junit.jupiter.api.BeforeEach;
//import org.junit.jupiter.api.Test;
//import org.mockito.InjectMocks;
//import org.mockito.Mock;
//import org.mockito.MockitoAnnotations;
//import org.springframework.jdbc.core.JdbcTemplate;
//import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
//import org.springframework.jdbc.core.simple.SimpleJdbcCall;
//
//import com.fasterxml.jackson.core.JsonProcessingException;
//import com.fasterxml.jackson.databind.ObjectMapper;
//import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
//import com.microsoft.azure.functions.ExecutionContext;
//import com.microsoft.azure.functions.OutputBinding;
//import com.ombudsman.service.complainant.Model.IncomingNotificationPhx;
//import com.ombudsman.service.complainant.Model.NotificationRequest;
//import com.ombudsman.service.complainant.Model.UserMailjetRequest;
//import com.ombudsman.service.complainant.Model.Response.GenericResponse;
//import com.ombudsman.service.complainant.Model.DPSupportQueueModel;
//import com.ombudsman.service.complainant.components.RetryMechanism;
//import com.ombudsman.service.complainant.components.SendEmailNotificationBody;
//import java.lang.reflect.Field;
//import javax.sql.DataSource;
//
//import org.junit.jupiter.api.BeforeEach;
//import org.junit.jupiter.api.Test;
//import org.mockito.ArgumentCaptor;
//import org.mockito.InjectMocks;
//import org.mockito.Mock;
//import org.mockito.MockitoAnnotations;
//import org.springframework.jdbc.core.JdbcTemplate;
//import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
//import org.springframework.jdbc.core.simple.SimpleJdbcCall;
//
//public class NotificationAzureFunctionTest {
//    @Mock
//    private ExecutionContext context;
//
//    @Mock
//    private OutputBinding<String> outputMessage;
//
//    @Mock
//    private JdbcTemplate jdbcTemplate;
//
//    @Mock
//    private SimpleJdbcCall mockJdbcCall;
//    
//    @Mock
//    private RetryMechanism retryMechanism;
//    @Mock
//    private DataSource dataSource;
//
//    @Mock
//    private SendEmailNotificationBody sendDocNotifyEmail;
//
//    @InjectMocks
//    private NotificationAzureFunction function;
//
//    @BeforeEach
//    public void setUp() throws NoSuchFieldException, SecurityException, IllegalArgumentException, IllegalAccessException {
//        MockitoAnnotations.openMocks(this);
//        function = new NotificationAzureFunction();
//        // Use reflection to set the final field
//        Field jdbcTemplateField = NotificationAzureFunction.class.getDeclaredField("jdbcTemplate");
//        jdbcTemplateField.setAccessible(true);
//        jdbcTemplateField.set(function, jdbcTemplate);
//        
//        // Mock the DataSource and set it in JdbcTemplate
//        when(jdbcTemplate.getDataSource()).thenReturn(dataSource);
//        
//        // Mock the SimpleJdbcCall to use the mocked DataSource
//        SimpleJdbcCall mockJdbcCall = mock(SimpleJdbcCall.class);
//        when(mockJdbcCall.withProcedureName(anyString())).thenReturn(mockJdbcCall);
//        when(mockJdbcCall.execute(any(MapSqlParameterSource.class))).thenReturn(new HashMap<>());
//
//        // Use reflection to set the SimpleJdbcCall field
//        Field jdbcCallField = NotificationAzureFunction.class.getDeclaredField("jdbcTemplate");
//        jdbcCallField.setAccessible(true);
//        jdbcCallField.set(function, jdbcTemplate);
//    }
//
//    @Test
//    public void testHandleIncomingNotification_CorrespondenceGenerated() throws JsonProcessingException {
//        String messagefromphx = "{\"source\":\"CorrespondenceGenerated\",\"caseID\":\"testCaseID\",\"complainantContactID\":\"testContactID\"}";
//        String messageId = "testMessageId";
//        String queueName = "testQueueName";
//
//        ObjectMapper mapper = new ObjectMapper();
//        mapper.registerModule(new JavaTimeModule());
//        IncomingNotificationPhx message = mapper.readValue(messagefromphx, IncomingNotificationPhx.class);
//
//        Map<String, Object> userDetails = new HashMap<>();
//        userDetails.put("#result-set-1", List.of(Map.of("contactEmailAddress", "test@example.com", "full_name", "Test User", "oid", "testOid", "caseRefNumber", "testCaseRefNumber", "userActiveSessionStatus", "active", "comPref", "email")));
//
//        // Mock the querySP method
//        NotificationAzureFunction spyFunction = spy(function);
//        doReturn(userDetails).when(spyFunction).querySP(anyString(), anyString());
//
//        spyFunction.handleIncomingNotification(messagefromphx, messageId, outputMessage, context);
//
//        ArgumentCaptor<String> outputCaptor = ArgumentCaptor.forClass(String.class);
//        verify(outputMessage, times(1)).setValue(outputCaptor.capture());
//
//        String dpSupportQueuevalues = spyFunction.dpSupport(message.getCaseID(), messageId, queueName, "HandleIncomingNotification", "DB Exception", "Getting Null values while querying SP prc_getQualifiedNotificationRecordsForReceivingDocuments");
//        assertEquals(dpSupportQueuevalues, outputCaptor.getValue());
//    }
//
//    @Test
//    public void testHandleIncomingNotification_EfileGenerated() throws JsonProcessingException {
//        String messagefromphx = "{\"source\":\"EfileGenerated\",\"caseID\":\"testCaseID\",\"complainantContactID\":\"testContactID\",\"filesModified\":[{\"documentID\":\"doc123\",\"activityID\":\"act456\"}]}";
//        String messageId = "testMessageId";
//        String queueName = "testQueueName";
//
//        ObjectMapper mapper = new ObjectMapper();
//        mapper.registerModule(new JavaTimeModule());
//        IncomingNotificationPhx message = mapper.readValue(messagefromphx, IncomingNotificationPhx.class);
//
//        Map<String, Object> userDetails = new HashMap<>();
//        userDetails.put("#result-set-1", List.of(Map.of("contactEmailAddress", "test@example.com", "full_name", "Test User", "oid", "testOid", "caseRefNumber", "testCaseRefNumber", "userActiveSessionStatus", "active", "comPref", "email")));
//
//        // Mock the querySP method
//        NotificationAzureFunction spyFunction = spy(function);
//        doReturn(userDetails).when(spyFunction).querySP(anyString(), anyString());
//
//        spyFunction.handleIncomingNotification(messagefromphx, messageId, outputMessage, context);
//
//        ArgumentCaptor<String> outputCaptor = ArgumentCaptor.forClass(String.class);
//        verify(outputMessage, times(1)).setValue(outputCaptor.capture());
//
//        String dpSupportQueuevalues = spyFunction.dpSupport(message.getCaseID(), messageId, queueName, "HandleIncomingNotification", "DB Exception", "Getting Null values while querying SP prc_getQualifiedNotificationRecordsForReceivingDocuments");
//        assertEquals(dpSupportQueuevalues, outputCaptor.getValue());
//    }
//    
//    @Test
//    public void testHandleNotificationBasedOnStatus_Email() throws Exception {
//        String actionSessionStatus = "false";
//        String communicationMode = "email";
//        String templateId = "template123";
//        UserMailjetRequest userMailjetRequest = new UserMailjetRequest();
//        userMailjetRequest.setEmailId("test@example.com");
//        userMailjetRequest.setFullName("Test User");
//
//        Method method = NotificationAzureFunction.class.getDeclaredMethod("handleNotificationBasedOnStatus", RetryMechanism.class, String.class, String.class, String.class, UserMailjetRequest.class);
//        method.setAccessible(true);
//        method.invoke(function, retryMechanism, actionSessionStatus, communicationMode, templateId, userMailjetRequest);
//
//        verify(retryMechanism, times(1)).sendEmailNotificationWithRetry(templateId, userMailjetRequest);
//    }
//
//    @Test
//    public void testHandleNotificationBasedOnStatus_SMS() throws Exception {
//        String actionSessionStatus = "false";
//        String communicationMode = "SMS";
//        String templateId = "template123";
//        UserMailjetRequest userMailjetRequest = new UserMailjetRequest();
//        userMailjetRequest.setEmailId("test@example.com");
//        userMailjetRequest.setFullName("Test User");
//
//        Method method = NotificationAzureFunction.class.getDeclaredMethod("handleNotificationBasedOnStatus", RetryMechanism.class, String.class, String.class, String.class, UserMailjetRequest.class);
//        method.setAccessible(true);
//        method.invoke(function, retryMechanism, actionSessionStatus, communicationMode, templateId, userMailjetRequest);
//
//        verify(retryMechanism, never()).sendEmailNotificationWithRetry(templateId, userMailjetRequest);
//    }
//
//    @Test
//    public void testHandleNotificationBasedOnStatus_ActiveStatus() throws Exception {
//        String actionSessionStatus = "true";
//        String communicationMode = "email";
//        String templateId = "template123";
//        UserMailjetRequest userMailjetRequest = new UserMailjetRequest();
//        userMailjetRequest.setEmailId("test@example.com");
//        userMailjetRequest.setFullName("Test User");
//
//        Method method = NotificationAzureFunction.class.getDeclaredMethod("handleNotificationBasedOnStatus", RetryMechanism.class, String.class, String.class, String.class, UserMailjetRequest.class);
//        method.setAccessible(true);
//        method.invoke(function, retryMechanism, actionSessionStatus, communicationMode, templateId, userMailjetRequest);
//
//        verify(retryMechanism, never()).sendEmailNotificationWithRetry(templateId, userMailjetRequest);
//    }
//    
//    @Test
//    public void testProcessNotification_Success() throws Exception {
//        String userId = "testUserId";
//        String phxCaseNumber = "testCaseNumber";
//
//        NotificationRequest notificationRequest = new NotificationRequest();
//        notificationRequest.setRequestId(UUID.randomUUID().toString());
//        notificationRequest.setUserOid(userId);
//        notificationRequest.setRequestingActivityName("newDocument");
//        notificationRequest.setNotificationStatusId(1);
//        notificationRequest.setMessage(phxCaseNumber + ":newDocument");
//        notificationRequest.setFileDownloadUrl(null);
//        notificationRequest.setCreatedBy("Financial Ombudsman Service");
//        notificationRequest.setCreatedOn(LocalDateTime.now());
//        notificationRequest.setModifiedOn(null);
//        notificationRequest.setModifiedBy(null);
//
//        // Create a spy for the NotificationAzureFunction class
//        NotificationAzureFunction spyFunction = spy(function);
//
//        // Mock the sendInAppNotification method to return the notificationRequest
//        doReturn(notificationRequest).when(spyFunction).sendInAppNotification(userId, phxCaseNumber);
//
//        // Mock the jdbcTemplate.update method to return 1
//        when(jdbcTemplate.update(anyString(), any(Object[].class))).thenReturn(1);
//
//        // Invoke the processNotification method directly on the spy
//        Method method = NotificationAzureFunction.class.getDeclaredMethod("processNotification", RetryMechanism.class, String.class, String.class);
//        method.setAccessible(true);
//        method.invoke(spyFunction, retryMechanism, userId, phxCaseNumber);
//
//        ArgumentCaptor<String> sqlCaptor = ArgumentCaptor.forClass(String.class);
//        ArgumentCaptor<Object[]> paramsCaptor = ArgumentCaptor.forClass(Object[].class);
//
//        verify(jdbcTemplate, times(1)).update(sqlCaptor.capture(), paramsCaptor.capture());
//
//        // Add assertions to verify the captured values if needed
//        assertEquals("INSERT INTO dp_complainant_user_notification (request_id, user_oid, requesting_activity_name, notification_status_id, message, file_download_url, created_on, created_by, modified_on, modified_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?,?)", sqlCaptor.getValue());
//        assertArrayEquals(new Object[]{
//            notificationRequest.getRequestId(),
//            notificationRequest.getUserOid(),
//            notificationRequest.getRequestingActivityName(),
//            notificationRequest.getNotificationStatusId(),
//            notificationRequest.getMessage(),
//            notificationRequest.getFileDownloadUrl(),
//            notificationRequest.getCreatedOn(),
//            notificationRequest.getCreatedBy(),
//            notificationRequest.getModifiedOn(),
//            notificationRequest.getModifiedBy()
//        }, paramsCaptor.getValue());
//
//        verify(retryMechanism, never()).sendInAppNotificationWithRetry(any(NotificationRequest.class), eq(jdbcTemplate));
//    }
//
//    @Test
//    public void testProcessNotification_Retry() throws Exception {
//        String userId = "testUserId";
//        String phxCaseNumber = "testCaseNumber";
//
//        NotificationRequest notificationRequest = new NotificationRequest();
//        notificationRequest.setRequestId(UUID.randomUUID().toString());
//        notificationRequest.setUserOid(userId);
//        notificationRequest.setRequestingActivityName("newDocument");
//        notificationRequest.setNotificationStatusId(1);
//        notificationRequest.setMessage(phxCaseNumber + ":newDocument");
//        notificationRequest.setFileDownloadUrl(null);
//        notificationRequest.setCreatedBy("Financial Ombudsman Service");
//        notificationRequest.setCreatedOn(LocalDateTime.now());
//        notificationRequest.setModifiedOn(null);
//        notificationRequest.setModifiedBy(null);
//
//        // Create a spy for the NotificationAzureFunction class
//        NotificationAzureFunction spyFunction = spy(function);
//
//        // Mock the sendInAppNotification method to return the notificationRequest
//        doReturn(notificationRequest).when(spyFunction).sendInAppNotification(userId, phxCaseNumber);
//
//        // Mock the jdbcTemplate.update method to throw an exception
//        when(jdbcTemplate.update(anyString(), any(Object[].class))).thenThrow(new RuntimeException("DB error"));
//
//        // Invoke the processNotification method directly on the spy
//        Method method = NotificationAzureFunction.class.getDeclaredMethod("processNotification", RetryMechanism.class, String.class, String.class);
//        method.setAccessible(true);
//        method.invoke(spyFunction, retryMechanism, userId, phxCaseNumber);
//
//        ArgumentCaptor<String> sqlCaptor = ArgumentCaptor.forClass(String.class);
//        ArgumentCaptor<Object[]> paramsCaptor = ArgumentCaptor.forClass(Object[].class);
//
//        verify(jdbcTemplate, times(1)).update(sqlCaptor.capture(), paramsCaptor.capture());
//
//        // Add assertions to verify the captured values if needed
//        assertEquals("INSERT INTO dp_complainant_user_notification (request_id, user_oid, requesting_activity_name, notification_status_id, message, file_download_url, created_on, created_by, modified_on, modified_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?,?)", sqlCaptor.getValue());
//        assertArrayEquals(new Object[]{
//            notificationRequest.getRequestId(),
//            notificationRequest.getUserOid(),
//            notificationRequest.getRequestingActivityName(),
//            notificationRequest.getNotificationStatusId(),
//            notificationRequest.getMessage(),
//            notificationRequest.getFileDownloadUrl(),
//            notificationRequest.getCreatedOn(),
//            notificationRequest.getCreatedBy(),
//            notificationRequest.getModifiedOn(),
//            notificationRequest.getModifiedBy()
//        }, paramsCaptor.getValue());
//
//        verify(retryMechanism, times(1)).sendInAppNotificationWithRetry(any(NotificationRequest.class), eq(jdbcTemplate));
//    }
//    
//    @Test
//    public void testProcessDocumentEmail_Success() throws Exception {
//        String templateId = "template123";
//        UserMailjetRequest incomingDocumentEmailModel = new UserMailjetRequest();
//        incomingDocumentEmailModel.setEmailId("test@example.com");
//        incomingDocumentEmailModel.setFullName("Test User");
//
//        // Create a spy for the NotificationAzureFunction class
//        NotificationAzureFunction spyFunction = spy(function);
//
//        // Mock the SendEmailNotificationBody to avoid actual email sending
//        SendEmailNotificationBody sendDocNotifyEmailMock = mock(SendEmailNotificationBody.class);
//        when(sendDocNotifyEmailMock.requestEmailBody(incomingDocumentEmailModel, templateId)).thenReturn(new GenericResponse());
//
//        // Use reflection to mock the instantiation of SendEmailNotificationBody within the method
//        Method method = NotificationAzureFunction.class.getDeclaredMethod("processDocumentEmail", RetryMechanism.class, UserMailjetRequest.class, String.class);
//        method.setAccessible(true);
//
//        // Replace the instantiation of SendEmailNotificationBody with the mock
//        doAnswer(invocation -> {
//            SendEmailNotificationBody sendDocNotifyEmail = sendDocNotifyEmailMock;
//            return sendDocNotifyEmail.requestEmailBody(incomingDocumentEmailModel, templateId);
//        }).when(spyFunction).processDocumentEmail(retryMechanism, incomingDocumentEmailModel, templateId);
//
//        // Invoke the processDocumentEmail method directly on the spy
//        method.invoke(spyFunction, retryMechanism, incomingDocumentEmailModel, templateId);
//
//        verify(sendDocNotifyEmailMock, times(1)).requestEmailBody(incomingDocumentEmailModel, templateId);
//        verify(retryMechanism, never()).sendEmailNotificationWithRetry(anyString(), any(UserMailjetRequest.class));
//    }
//
//    @Test
//    public void testProcessDocumentEmail_Retry() throws Exception {
//        String templateId = "template123";
//        UserMailjetRequest incomingDocumentEmailModel = new UserMailjetRequest();
//        incomingDocumentEmailModel.setEmailId("test@example.com");
//        incomingDocumentEmailModel.setFullName("Test User");
//
//        // Mock the SendEmailNotificationBody to throw an exception
//        SendEmailNotificationBody sendDocNotifyEmailMock = mock(SendEmailNotificationBody.class);
//        when(sendDocNotifyEmailMock.requestEmailBody(incomingDocumentEmailModel, templateId)).thenThrow(new RuntimeException("Email sending error"));
//
//        // Create an instance of NotificationAzureFunction and inject the mocked SendEmailNotificationBody
//        NotificationAzureFunction function = new NotificationAzureFunction();
//        function.setSendDocNotifyEmail(sendDocNotifyEmailMock);
//
//        // Mock the retry mechanism to avoid actual retries
//        RetryMechanism retryMechanismMock = mock(RetryMechanism.class);
//        doNothing().when(retryMechanismMock).sendEmailNotificationWithRetry(templateId, incomingDocumentEmailModel);
//
//        // Invoke the processDocumentEmail method directly
//        function.processDocumentEmail(retryMechanismMock, incomingDocumentEmailModel, templateId);
//
//        // Verify the interactions with the mocks
//        verify(sendDocNotifyEmailMock, times(1)).requestEmailBody(incomingDocumentEmailModel, templateId);
//        verify(retryMechanismMock, times(1)).sendEmailNotificationWithRetry(templateId, incomingDocumentEmailModel);
//    }
//
//
//
//
//
//    @Test
//    public void testSendInAppNotification() {
//        String userId = "testUserId";
//        String phxCaseNumber = "testPhxCaseNumber";
//
//        NotificationRequest notification = function.sendInAppNotification(userId, phxCaseNumber);
//
//        assertEquals(userId, notification.getUserOid());
//        assertEquals("newDocument", notification.getRequestingActivityName());
//        assertEquals(1, notification.getNotificationStatusId());
//        assertEquals(phxCaseNumber + ":newDocument", notification.getMessage());
//        assertEquals("Financial Ombudsman Service", notification.getCreatedBy());
//        assertEquals(LocalDateTime.now().getDayOfYear(), notification.getCreatedOn().getDayOfYear());
//    }
//    
//
//    @Test
//    public void testQuerySP() throws Exception {
//        String incidentId = "testIncidentId";
//        String contactId = "testContactId";
//        String finalContactID = contactId;
//
//        MapSqlParameterSource inparams = new MapSqlParameterSource()
//                .addValue("incidentids", incidentId)
//                .addValue("contactids", finalContactID);
//
//        // Directly test the SimpleJdbcCall
//        Map<String, Object> result = mockJdbcCall.execute(inparams);
//
//        assertEquals(new HashMap<>(), result);
//    }
//    
//    @Test
//    public void testDpSupport() throws JsonProcessingException {
//        String caseReferenceNumberIncidentId = "testCaseReferenceNumberIncidentId";
//        String failedSbMessageId = "testFailedSbMessageId";
//        String source = "testSource";
//        String outgoingDigitalMessageProcessorWorkerFunction = "testWorkerFunction";
//        String errorInfo = "testErrorInfo";
//        String errorDetails = "testErrorDetails";
//
//        DPSupportQueueModel supportModel = new DPSupportQueueModel();
//        supportModel.setCaseReferenceNumberIncidentId(caseReferenceNumberIncidentId);
//        supportModel.setDateTimeErrorOccurred(LocalDateTime.now().toString());
//        supportModel.setFailedSbMessageId(failedSbMessageId);
//        supportModel.setSource(source);
//        supportModel.setOutgoingDigitalMessageProcessorWorkerFunction(outgoingDigitalMessageProcessorWorkerFunction);
//        supportModel.setErrorInfo(errorInfo);
//        supportModel.setErrorDetails(errorDetails);
//
//        ObjectMapper mapper = new ObjectMapper();
//        String expectedJson = mapper.writeValueAsString(supportModel);
//
//        String resultJson = function.dpSupport(caseReferenceNumberIncidentId, failedSbMessageId, source, outgoingDigitalMessageProcessorWorkerFunction, errorInfo, errorDetails);
//
//        assertNotEquals(expectedJson, resultJson);
//    }
//}