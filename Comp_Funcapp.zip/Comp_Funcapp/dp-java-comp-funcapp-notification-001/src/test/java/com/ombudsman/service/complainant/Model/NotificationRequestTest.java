package com.ombudsman.service.complainant.Model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.time.LocalDateTime;

import org.junit.jupiter.api.Test;

public class NotificationRequestTest {

    @Test
    public void testNotificationRequest() {
        NotificationRequest request = new NotificationRequest();
        
        Long notificationId = 1L;
        String requestId = "REQ123";
        String userOid = "USER456";
        String requestingActivityName = "ActivityName";
        int notificationStatusId = 2;
        String message = "Test message";
        String fileDownloadUrl = "http://example.com/file";
        String createdBy = "creator";
        LocalDateTime createdOn = LocalDateTime.now();
        String modifiedOn = "2025-05-07T19:30:32";
        String modifiedBy = "modifier";

        request.setNotificationId(notificationId);
        request.setRequestId(requestId);
        request.setUserOid(userOid);
        request.setRequestingActivityName(requestingActivityName);
        request.setNotificationStatusId(notificationStatusId);
        request.setMessage(message);
        request.setFileDownloadUrl(fileDownloadUrl);
        request.setCreatedBy(createdBy);
        request.setCreatedOn(createdOn);
        request.setModifiedOn(modifiedOn);
        request.setModifiedBy(modifiedBy);

        assertEquals(notificationId, request.getNotificationId());
        assertEquals(requestId, request.getRequestId());
        assertEquals(userOid, request.getUserOid());
        assertEquals(requestingActivityName, request.getRequestingActivityName());
        assertEquals(notificationStatusId, request.getNotificationStatusId());
        assertEquals(message, request.getMessage());
        assertEquals(fileDownloadUrl, request.getFileDownloadUrl());
        assertEquals(createdBy, request.getCreatedBy());
        assertEquals(createdOn, request.getCreatedOn());
        assertEquals(modifiedOn, request.getModifiedOn());
        assertEquals(modifiedBy, request.getModifiedBy());
    }
}
