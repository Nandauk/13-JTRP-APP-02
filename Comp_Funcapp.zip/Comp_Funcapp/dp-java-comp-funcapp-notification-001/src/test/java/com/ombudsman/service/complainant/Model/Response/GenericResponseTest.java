package com.ombudsman.service.complainant.Model.Response;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

public class GenericResponseTest {

    @Test
    public void testGenericResponse() {
        GenericResponse response = new GenericResponse();
        
        response.setStatus("success");
        response.setMessage("Operation completed successfully");
        response.setResult("result data");

        assertEquals("success", response.getStatus());
        assertEquals("Operation completed successfully", response.getMessage());
        assertEquals("result data", response.getResult());
    }
}
