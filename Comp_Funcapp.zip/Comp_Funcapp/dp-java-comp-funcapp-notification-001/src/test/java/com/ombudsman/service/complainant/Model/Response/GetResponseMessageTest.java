package com.ombudsman.service.complainant.Model.Response;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

public class GetResponseMessageTest {

    @Test
    public void testGetResponseMessage() {
        GetResponseMessage response = new GetResponseMessage();
        
        response.setMessage("This is a test message");
        response.setStatus("success");

        assertEquals("This is a test message", response.getMessage());
        assertEquals("success", response.getStatus());
    }
}
