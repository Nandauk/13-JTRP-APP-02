package com.ombudsman.service.complainant.Model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

public class ToTest {

    @Test
    public void testTo() {
        To to = new To();
        
        String email = "to@example.com";
        String name = "To Name";

        to.setEmail(email);
        to.setName(name);

        assertEquals(email, to.getEmail());
        assertEquals(name, to.getName());
    }
}
