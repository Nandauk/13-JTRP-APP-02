package com.ombudsman.service.complainant.exception;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.springframework.test.context.junit.jupiter.SpringExtension;

@ExtendWith(SpringExtension.class)
public class MailJetServiceExceptionTest {

	@InjectMocks
	MailJetServiceException mailJetServiceException;
	
	 @Test
	    public void testConstructor() {
	        String message = "Test message";
	        String exceptionMessage = "Test exception message";
	        StackTraceElement[] stackTrace = new StackTraceElement[0];

	        MailJetServiceException exception = new MailJetServiceException(message, exceptionMessage, stackTrace);

	        assertEquals(message, exception.getMessage());
	        assertEquals("RESPONDENT_AZURE_1000", exception.getCode());
	        assertEquals(exceptionMessage, exception.getExceptionMessage());
	    }
}
