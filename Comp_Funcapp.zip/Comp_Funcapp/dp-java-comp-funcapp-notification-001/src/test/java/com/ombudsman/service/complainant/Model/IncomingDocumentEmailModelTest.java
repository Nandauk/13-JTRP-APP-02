package com.ombudsman.service.complainant.Model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

public class IncomingDocumentEmailModelTest {

    @Test
    public void testIncomingDocumentEmailModel() {
        IncomingDocumentEmailModel model = new IncomingDocumentEmailModel();
        
        String siginURL = "http://example.com/signin";
        String userName = "testUser";
        String emailId = "test@example.com";
        String templateName = "defaultTemplate";

        model.setSiginURL(siginURL);
        model.setUserName(userName);
        model.setEmailId(emailId);
        model.setTemplateName(templateName);

        assertEquals(siginURL, model.getSiginURL());
        assertEquals(userName, model.getUserName());
        assertEquals(emailId, model.getEmailId());
        assertEquals(templateName, model.getTemplateName());
    }
}
