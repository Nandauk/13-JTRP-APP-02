package com.ombudsman.service.complainant.Model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

public class FileModifiedTest {

    @Test
    public void testFileModified() {
        FilesModified fileModified = new FilesModified();
        
        String documentID = "DOC123";
        String activityID = "ACT456";

        fileModified.setDocumentId(documentID);
        fileModified.setActivityId(activityID);

        assertEquals(documentID, fileModified.getDocumentId());
        assertEquals(activityID, fileModified.getActivityId());
    }
}
