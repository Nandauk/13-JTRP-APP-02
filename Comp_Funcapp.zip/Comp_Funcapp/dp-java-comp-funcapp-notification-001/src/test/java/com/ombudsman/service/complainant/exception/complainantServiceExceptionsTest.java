package com.ombudsman.service.complainant.exception;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertArrayEquals;

import org.junit.jupiter.api.Test;

public class complainantServiceExceptionsTest {

    @Test
    public void testComplainantServiceExceptions() {
        String message = "Test message";
        String code = "ERR001";
        String exceptionMessage = "Exception occurred";
        StackTraceElement[] stackTraceElements = new StackTraceElement[0];

        complainantServiceExceptions exception = new complainantServiceExceptions(message, code, exceptionMessage, stackTraceElements);

        assertEquals(message, exception.getMessage());
        assertEquals(code, exception.getCode());
        assertEquals(exceptionMessage, exception.getExceptionMessage());
        assertArrayEquals(stackTraceElements, exception.getStackTraceMessage());
    }
}
