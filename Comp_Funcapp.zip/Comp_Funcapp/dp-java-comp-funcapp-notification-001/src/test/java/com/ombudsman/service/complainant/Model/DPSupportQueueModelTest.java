package com.ombudsman.service.complainant.Model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

public class DPSupportQueueModelTest {

    @Test
    public void testDPSupportQueueModel() {
        DPSupportQueueModel model = new DPSupportQueueModel();
        
        String tempDigitalMessageProcessingId = "TMP123";
        String caseReferenceNumberIncidentId = "CASE456";
        String failedSbMessageId = "MSG789";
        String source = "source";
        String outgoingDigitalMessageProcessorWorkerFunction = "workerFunction";
        String errorInfo = "errorInfo";
        String errorDetails = "errorDetails";
        String dateTimeErrorOccurred = "2025-05-07T19:30:32";

        model.setTempDigitalMessageProcessingId(tempDigitalMessageProcessingId);
        model.setCaseReferenceNumberIncidentId(caseReferenceNumberIncidentId);
        model.setFailedSbMessageId(failedSbMessageId);
        model.setSource(source);
        model.setOutgoingDigitalMessageProcessorWorkerFunction(outgoingDigitalMessageProcessorWorkerFunction);
        model.setErrorInfo(errorInfo);
        model.setErrorDetails(errorDetails);
        model.setDateTimeErrorOccurred(dateTimeErrorOccurred);

        assertEquals(tempDigitalMessageProcessingId, model.getTempDigitalMessageProcessingId());
        assertEquals(caseReferenceNumberIncidentId, model.getCaseReferenceNumberIncidentId());
        assertEquals(failedSbMessageId, model.getFailedSbMessageId());
        assertEquals(source, model.getSource());
        assertEquals(outgoingDigitalMessageProcessorWorkerFunction, model.getOutgoingDigitalMessageProcessorWorkerFunction());
        assertEquals(errorInfo, model.getErrorInfo());
        assertEquals(errorDetails, model.getErrorDetails());
        assertEquals(dateTimeErrorOccurred, model.getDateTimeErrorOccurred());
    }
}
