package com.ombudsman.service.complainant.Model;

import static org.junit.jupiter.api.Assertions.assertSame;

import java.util.Collections;
import java.util.List;

import org.junit.jupiter.api.Test;

public class SendMailReqTest {

    @Test
    public void testSendMailReq() {
        SendMailReq sendMailReq = new SendMailReq();
        
        Messages message = new Messages();
        From from = new From();
        from.setEmail("from@example.com");
        from.setName("From Name");
        message.setFrom(from);
        
        List<Messages> messagesList = Collections.singletonList(message);

        sendMailReq.setMessages(messagesList);

        assertSame(messagesList, sendMailReq.getMessages());
    }
}
