package com.ombudsman.service.complainant.Model.Response;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertSame;

import java.util.Collections;
import java.util.List;

import org.junit.jupiter.api.Test;

public class MailjetResponseBodyTest {

    @Test
    public void testMailjetResponseBody() {
        MailjetResponseBody mailjetResponseBody = new MailjetResponseBody();
        MailjetResponseBody.Message message = new MailjetResponseBody.Message("success");
        List<MailjetResponseBody.Message> messages = Collections.singletonList(message);

        mailjetResponseBody.setMessages(messages);

        assertSame(messages, mailjetResponseBody.getMessages());
        assertEquals("Message :" + messages, mailjetResponseBody.toString());
    }

    @Test
    public void testMessage() {
        MailjetResponseBody.Message message = new MailjetResponseBody.Message("success");
        message.setCustomID("12345");
        MailjetResponseBody.Recipient recipient = new MailjetResponseBody.Recipient();
        recipient.setEmail("test@example.com");
        List<MailjetResponseBody.Recipient> recipients = Collections.singletonList(recipient);

        message.setTo(recipients);
        message.setCc(recipients);
        message.setBcc(recipients);

        assertEquals("success", message.getStatus());
        assertEquals("12345", message.getCustomID());
        assertSame(recipients, message.getTo());
        assertSame(recipients, message.getCc());
        assertSame(recipients, message.getBcc());
        assertEquals("Status: success,CustomID: 12345,TO : " + recipients + " ,Cc : " + recipients + " ,Bcc : " + recipients, message.toString());
    }

    @Test
    public void testSetStatus() {
        MailjetResponseBody.Message message = new MailjetResponseBody.Message("initial status");
        message.setStatus("updated status");

        assertEquals("updated status", message.getStatus());
    }

    @Test
    public void testRecipient() {
        MailjetResponseBody.Recipient recipient = new MailjetResponseBody.Recipient();
        recipient.setEmail("test@example.com");
        recipient.setMessageUUID("uuid-1234");
        recipient.setMessageID(12345L);
        recipient.setMessageHref("http://example.com/message/12345");

        assertEquals("test@example.com", recipient.getEmail());
        assertEquals("uuid-1234", recipient.getMessageUUID());
        assertEquals(12345L, recipient.getMessageID());
        assertEquals("http://example.com/message/12345", recipient.getMessageHref());
        assertEquals(" email: test@example.com, messageUUID: uuid-1234 ,messageID : 12345 ,messageHref : http://example.com/message/12345", recipient.toString());
    }
}
