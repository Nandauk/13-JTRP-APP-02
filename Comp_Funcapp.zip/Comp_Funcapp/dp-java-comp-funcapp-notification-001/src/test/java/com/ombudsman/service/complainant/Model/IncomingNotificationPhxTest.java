package com.ombudsman.service.complainant.Model;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertSame;

import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.util.Collections;
import java.util.List;

import org.junit.jupiter.api.Test;

public class IncomingNotificationPhxTest {

	@Test
	public void testIncomingNotificationPhx() {
		IncomingNotificationPhx notification = new IncomingNotificationPhx();

		String caseID = "123";
		String caseUniqueIdentifier = "ABC123";
		LocalDateTime correspondenceGenerationDateTime = LocalDateTime.now();
		String activityID = "ACT001";
		String emailActivityUniqueIdentifier = "EMAIL001";
		String source = "source";
		String complainantContactID = "CONTACT001";
		OffsetDateTime eFileModificationDateTime = OffsetDateTime.now();
		String sourceEFileModification = "sourceModification";
		List<FilesModified> filesModified = Collections.emptyList();

		//        notification.setCaseId(caseID);
		//        notification.setCaseUniqueIdentifier(caseUniqueIdentifier);
		//        notification.setCorrespondenceGenerationDateTime(correspondenceGenerationDateTime);
		//        notification.setActivityID(activityID);
		//        notification.setEmailActivityUniqueIdentifier(emailActivityUniqueIdentifier);
		notification.setSource(source);
		//        notification.setComplainantContactID(complainantContactID);
		notification.setEfileModifiedDateTime(eFileModificationDateTime);
		//        notification.setSourceEFileModification(sourceEFileModification);
		notification.setFilesModified(filesModified);

		//assertEquals(caseID, notification.getCaseId());
		//   assertEquals(caseUniqueIdentifier, notification.getCaseUniqueIdentifier());
		// assertEquals(correspondenceGenerationDateTime, notification.getCorrespondenceGenerationDateTime());
		// assertEquals(activityID, notification.getActivityID());
		// assertEquals(emailActivityUniqueIdentifier, notification.getEmailActivityUniqueIdentifier());
		assertEquals(source, notification.getSource());
		// assertEquals(complainantContactID, notification.getComplainantContactID());
		// assertEquals(eFileModificationDateTime, notification.getEfileModifiedDateTime());
		// assertEquals(sourceEFileModification, notification.getSourceEFileModification());
		assertSame(filesModified, notification.getFilesModified());
	}
}
