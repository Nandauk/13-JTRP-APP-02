package com.ombudsman.service.complainant.components;

import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.*;

import java.time.LocalDateTime;
import java.lang.reflect.Method;

import org.junit.jupiter.api.Test;
import org.springframework.jdbc.core.JdbcTemplate;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.microsoft.azure.servicebus.primitives.ServiceBusException;
import com.ombudsman.service.complainant.Model.NotificationRequest;
import com.ombudsman.service.complainant.Model.UserMailjetRequest;
import com.ombudsman.service.complainant.exception.MessageSaveException;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
public class RetryMechanismTest {

    @Mock
    private JdbcTemplate jdbcTemplate;

//   @Mock
//    private SendEmailNotificationBody sendDocNotifyEmail;

    @InjectMocks
    private RetryMechanism retryMechanism;

    private NotificationRequest notificationRequest;
    private UserMailjetRequest userMailjetRequest;
    private static final int[] RETRY_INTERVALS = {1, 3, 3}; // Ensure RETRY_INTERVALS is defined


    @BeforeEach
    public void setUp() {
        notificationRequest = new NotificationRequest();
        notificationRequest.setRequestId("requestId");
        notificationRequest.setUserOid("userOid");
        notificationRequest.setRequestingActivityName("activityName");
        notificationRequest.setNotificationStatusId(1);
        notificationRequest.setMessage("message");
        notificationRequest.setFileDownloadUrl("url");
        notificationRequest.setCreatedOn(LocalDateTime.now());
        notificationRequest.setCreatedBy("createdBy");
        notificationRequest.setModifiedOn(LocalDateTime.now().toString());
        notificationRequest.setModifiedBy("modifiedBy");

        userMailjetRequest = new UserMailjetRequest();
        userMailjetRequest.setEmailId("test@example.com");
        userMailjetRequest.setFullName("Test User");
    }

    @Test
    public void testSendInAppNotificationWithRetrySuccess() throws JsonProcessingException, InterruptedException, ServiceBusException {
        doReturn(1).when(jdbcTemplate).update(anyString(), any(Object[].class));

        retryMechanism.sendInAppNotificationWithRetry(notificationRequest, jdbcTemplate);

        verify(jdbcTemplate, times(1)).update(anyString(), any(Object[].class));
    }

    @Test
    public void testSendInAppNotificationWithRetryFailure() throws JsonProcessingException, InterruptedException, ServiceBusException {
        doThrow(new RuntimeException("Database error")).when(jdbcTemplate).update(anyString(), any(Object[].class));

        try {
            retryMechanism.sendInAppNotificationWithRetry(notificationRequest, jdbcTemplate);
        } catch (MessageSaveException e) {
            verify(jdbcTemplate, times(1)).update(anyString(), any(Object[].class));
        }
    }
    
    @Test
    public void testSleepBeforeRetry() throws Exception {
        // Use reflection to access the private sleepBeforeRetry method
        Method sleepBeforeRetryMethod = RetryMechanism.class.getDeclaredMethod("sleepBeforeRetry", int.class);
        sleepBeforeRetryMethod.setAccessible(true);
     


        // Call the method
        sleepBeforeRetryMethod.invoke(retryMechanism, 1);
     
      

        // Verify that the method completes without throwing an exception
        assertTrue(true);
      

    }

    @Test
    public void testSleepBeforeRetryInterruptedException() throws Exception {
        // Use reflection to access the private sleepBeforeRetry method
        Method sleepBeforeRetryMethod = RetryMechanism.class.getDeclaredMethod("sleepBeforeRetry", int.class);
        sleepBeforeRetryMethod.setAccessible(true);

        // Simulate InterruptedException
        Thread.currentThread().interrupt(); // Interrupt the current thread

        // Call the method and verify that it throws a RuntimeException
        try {
            sleepBeforeRetryMethod.invoke(retryMechanism, 1);
        } catch (Exception e) {
            assertTrue(e.getCause() instanceof RuntimeException);
        }

        // Clear the interrupted status for other tests
        Thread.interrupted();
    }
}