package com.ombudsman.service.complainant.Model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

public class UserMailjetRequestTest {

    @Test
    public void testUserMailjetRequest() {
        UserMailjetRequest request = new UserMailjetRequest();
        
        String emailId = "user@example.com";
        String fullName = "User Name";

        request.setEmailId(emailId);
        request.setFullName(fullName);

        assertEquals(emailId, request.getEmailId());
        assertEquals(fullName, request.getFullName());
    }
}
