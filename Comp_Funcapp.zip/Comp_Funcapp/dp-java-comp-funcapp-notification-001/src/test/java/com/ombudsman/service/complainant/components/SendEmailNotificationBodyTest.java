//package com.ombudsman.service.complainant.components;
//
//import static org.junit.jupiter.api.Assertions.*;
//import static org.mockito.Mockito.*;
//
//import java.util.ArrayList;
//import java.util.List;
//
//import org.json.JSONException;
//import org.junit.jupiter.api.BeforeEach;
//import org.junit.jupiter.api.Test;
//import org.mockito.InjectMocks;
//import org.mockito.Mock;
//import org.mockito.MockitoAnnotations;
//import org.springframework.web.reactive.function.client.WebClient;
//import org.springframework.web.reactive.function.client.WebClient.ResponseSpec;
//import org.springframework.web.reactive.function.client.WebClient.RequestBodyUriSpec;
//import org.springframework.web.reactive.function.client.WebClient.RequestHeadersSpec;
//import org.springframework.web.reactive.function.client.WebClient.RequestHeadersUriSpec;
//import org.springframework.web.reactive.function.client.WebClient.RequestBodySpec;
//import reactor.core.publisher.Mono;
//
//import com.fasterxml.jackson.core.JsonProcessingException;
//import com.ombudsman.service.complainant.Model.From;
//import com.ombudsman.service.complainant.Model.MailjetVariables;
//import com.ombudsman.service.complainant.Model.Messages;
//import com.ombudsman.service.complainant.Model.SendMailReq;
//import com.ombudsman.service.complainant.Model.To;
//import com.ombudsman.service.complainant.Model.UserMailjetRequest;
//import com.ombudsman.service.complainant.Model.Response.GenericResponse;
//import com.ombudsman.service.complainant.Model.Response.MailjetResponseBody;
//import com.ombudsman.service.complainant.exception.MailJetServiceException;
//
//class SendEmailNotificationBodyTest {
//
//    @InjectMocks
//    private SendEmailNotificationBody sendEmailNotificationBody;
//
//    @Mock
//    private WebClient.Builder webClientBuilder;
//
//    @Mock
//    private WebClient webClient;
//
//    @Mock
//    private RequestBodyUriSpec requestBodyUriSpec;
//
//    @Mock
//    private RequestHeadersSpec requestHeadersSpec;
//
//    @Mock
//    private ResponseSpec responseSpec;
//
//    @BeforeEach
//    void setUp() {
//        MockitoAnnotations.openMocks(this);
//
//        // Set environment variables
//        System.setProperty("APIM_URL", "http://mock-api-url.com");
//        System.setProperty("FROMEMAIL", "[email protected]");
//        System.setProperty("FROMEMAILNAME", "No Reply");
//        System.setProperty("SIGNURL", "http://mock-sign-url.com");
//
//        when(webClientBuilder.build()).thenReturn(webClient);
//        when(webClient.post()).thenReturn(requestBodyUriSpec);
//        when(requestBodyUriSpec.uri(anyString())).thenReturn(requestBodyUriSpec);
//        when(requestBodyUriSpec.body(any())).thenReturn(requestHeadersSpec);
//        when(requestHeadersSpec.accept(any())).thenReturn(requestHeadersSpec);
//        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
//    }
//
//
//
//    @Test
//    void testSetIfNotEmpty() {
//        MailjetVariables var = new MailjetVariables();
//        sendEmailNotificationBody.setIfNotEmpty("value", var::setPortal_User);
//        assertEquals("value", var.getPortal_User());
//    }
//
//
//
//    @Test
//    void testSendFailure() throws JSONException {
//        SendMailReq req = new SendMailReq();
//        List<Messages> messages = new ArrayList<>();
//        Messages message = new Messages();
//        message.setTemplateID(12345L);
//        messages.add(message);
//        req.setMessages(messages);
//
//        when(responseSpec.bodyToMono(MailjetResponseBody.class)).thenThrow(new MailJetServiceException("Mailjet Exception occurred", "url", new StackTraceElement[0]));
//
//        assertThrows(MailJetServiceException.class, () -> sendEmailNotificationBody.send(req));
//    }
//}
