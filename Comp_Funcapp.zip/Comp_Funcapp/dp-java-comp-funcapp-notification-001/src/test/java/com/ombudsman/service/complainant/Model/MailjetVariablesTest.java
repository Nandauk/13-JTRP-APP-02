package com.ombudsman.service.complainant.Model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

public class MailjetVariablesTest {

    @Test
    public void testMailjetVariables() {
        MailjetVariables variables = new MailjetVariables();
        
        String portalUser = "testUser";
        String signIn = "http://example.com/signin";

        variables.setPortal_User(portalUser);
        variables.setSign_In(signIn);

        assertEquals(portalUser, variables.getPortal_User());
        assertEquals(signIn, variables.getSign_In());
    }
}
