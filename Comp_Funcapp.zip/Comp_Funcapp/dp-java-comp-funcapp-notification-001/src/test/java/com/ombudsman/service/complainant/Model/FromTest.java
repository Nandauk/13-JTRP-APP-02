package com.ombudsman.service.complainant.Model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

public class FromTest {

    @Test
    public void testFrom() {
        From from = new From();
        
        String email = "test@example.com";
        String name = "Test Name";

        from.setEmail(email);
        from.setName(name);

        assertEquals(email, from.getEmail());
        assertEquals(name, from.getName());
    }
}
