package com.ombudsman.service.complainant.exception;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertSame;

import org.junit.jupiter.api.Test;

public class MessageSaveExceptionTest {

    @Test
    public void testMessageSaveException() {
        String message = "Error saving message";
        Throwable cause = new Throwable("Cause of the error");

        MessageSaveException exception = new MessageSaveException(message, cause);

        assertEquals(message, exception.getMessage());
        assertSame(cause, exception.getCause());
    }
}
