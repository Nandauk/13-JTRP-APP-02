package com.ombudsman.service.complainant.Model;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertSame;

import java.util.Collections;
import java.util.List;

import org.junit.jupiter.api.Test;

public class MessagesTest {

    @Test
    public void testMessages() {
        Messages messages = new Messages();
        
        From from = new From();
        from.setEmail("from@example.com");
        from.setName("From Name");

        To to = new To();
        to.setEmail("to@example.com");
        to.setName("To Name");
        List<To> toList = Collections.singletonList(to);

        Long templateID = 12345L;
        boolean templateLanguage = true;
        MailjetVariables variables = new MailjetVariables();
        variables.setPortal_User("testUser");
        variables.setSign_In("http://example.com/signin");

        messages.setFrom(from);
        messages.setTo(toList);
        messages.setTemplateID(templateID);
        messages.setTemplateLanguage(templateLanguage);
        messages.setVariables(variables);

        assertSame(from, messages.getFrom());
        assertSame(toList, messages.getTo());
        assertEquals(templateID, messages.getTemplateID());
        assertEquals(templateLanguage, messages.getTemplateLanguage());
        assertSame(variables, messages.getVariables());
    }
}
