package com.ombudsman.service.complainant.model;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class DeleteUserRequestTest {

    @Test
    public void testAuditIdGetterAndSetter() {
        DeleteUserRequest request = new DeleteUserRequest();

        String auditId = "audit-123";
        request.setAuditid(auditId);

        assertEquals(auditId, request.getAuditid());
    }
}
