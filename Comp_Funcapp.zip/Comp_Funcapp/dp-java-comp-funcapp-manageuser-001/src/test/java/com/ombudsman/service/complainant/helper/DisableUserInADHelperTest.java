package com.ombudsman.service.complainant.helper;

import static org.mockito.Mockito.*;

import java.util.UUID;

import com.ombudsman.service.complainant.common.ManageUserWebClient;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

public class DisableUserInADHelperTest {

    @Mock
    private ManageUserWebClient manageUserWebClient;

    @InjectMocks
    private DisableUserInADHelper disableUserInADHelper;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testDisableUser_Success() {
        UUID userId = UUID.randomUUID();

        // No exception expected, so just verify the method call
        disableUserInADHelper.disableUser(userId);

        verify(manageUserWebClient, times(1)).setIsAccountStatus(userId.toString(), false);
    }

    @Test
    public void testDisableUser_ExceptionHandled() {
        UUID userId = UUID.randomUUID();

        doThrow(new RuntimeException("Simulated error")).when(manageUserWebClient)
                .setIsAccountStatus(userId.toString(), false);

        // Should not throw, just log the error
        disableUserInADHelper.disableUser(userId);

        verify(manageUserWebClient, times(1)).setIsAccountStatus(userId.toString(), false);
    }
}
