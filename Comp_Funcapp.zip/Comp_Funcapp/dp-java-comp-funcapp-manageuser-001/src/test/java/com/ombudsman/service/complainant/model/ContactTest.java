package com.ombudsman.service.complainant.model;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class ContactTest {

    @Test
    public void testContactSettersAndGetters() {
        Contact contact = new Contact();

        String contactId = "contact-001";
        int stateCode = 1;
        String inviteStatus = "Sent";

        contact.setContactId(contactId);
        contact.setStatecode(stateCode);
        contact.setFos_digitalportalinvitestatus(inviteStatus);

        assertEquals(contactId, contact.getContactId());
        assertEquals(stateCode, contact.getStatecode());
        assertEquals(inviteStatus, contact.getFos_digitalportalinvitestatus());
    }
}
