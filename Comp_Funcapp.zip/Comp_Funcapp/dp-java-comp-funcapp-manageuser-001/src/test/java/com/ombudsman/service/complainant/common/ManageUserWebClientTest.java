package com.ombudsman.service.complainant.common;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import com.microsoft.graph.models.User;
import org.json.simple.JSONObject;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.MockedStatic;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.MediaType;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClient.ResponseSpec;
import org.springframework.web.reactive.function.client.WebClient.RequestBodyUriSpec;
import org.springframework.web.reactive.function.client.WebClient.RequestHeadersSpec;
import org.springframework.web.reactive.function.client.WebClient.RequestHeadersUriSpec;
import reactor.core.publisher.Mono;

@ExtendWith(MockitoExtension.class)
public class ManageUserWebClientTest {

	private final ManageUserWebClient manageUserWebClient = new ManageUserWebClient();
	private final WebClient webClientMock = mock(WebClient.class);

	@Test
	public void testDeleteUserfromB2C() {
		try (MockedStatic mockedWebClient = mockStatic(WebClient.class)) {
			// Arrange
			String userId = "12345";
			String expectedResponse = "User deleted Successfully from Azure";

			WebClient.RequestHeadersUriSpec requestHeadersUriSpecMock = mock(WebClient.RequestHeadersUriSpec.class);
			WebClient.RequestHeadersSpec requestHeadersSpecMock = mock(WebClient.RequestHeadersSpec.class);
			ResponseSpec responseSpecMock = mock(WebClient.ResponseSpec.class);

			mockedWebClient.when(WebClient::create).thenReturn(webClientMock);
			when(webClientMock.delete()).thenReturn(requestHeadersUriSpecMock);
			when(requestHeadersUriSpecMock.uri(anyString())).thenReturn(requestHeadersUriSpecMock);
			when(requestHeadersUriSpecMock.accept(MediaType.APPLICATION_JSON)).thenReturn(requestHeadersSpecMock);
			when(requestHeadersSpecMock.retrieve()).thenReturn(responseSpecMock);
			when(responseSpecMock.bodyToMono(User.class)).thenReturn(Mono.empty());

			// Act
			String actualResponse = manageUserWebClient.deleteUserfromB2C(userId);

			// Assert
			assertEquals(expectedResponse, actualResponse);
		}
	}
	@Test
	public void testUpdateUserinB2C() {
	    try (MockedStatic<WebClient> mockedWebClient = mockStatic(WebClient.class)) {
	        // Arrange
	        User userAction = new User();
	        String userId = "12345";
	        String expectedResponse = "Success";

	        WebClient.RequestBodyUriSpec requestBodyUriSpecMock = mock(WebClient.RequestBodyUriSpec.class);
	        WebClient.RequestHeadersSpec requestHeadersSpecMock = mock(WebClient.RequestHeadersSpec.class);
	        WebClient.ResponseSpec responseSpecMock = mock(WebClient.ResponseSpec.class);

	        mockedWebClient.when(WebClient::create).thenReturn(webClientMock);
	        when(webClientMock.patch()).thenReturn(requestBodyUriSpecMock);
	        when(requestBodyUriSpecMock.uri(anyString())).thenReturn(requestBodyUriSpecMock);
	        when(requestBodyUriSpecMock.body(any(), eq(User.class))).thenReturn(requestHeadersSpecMock);
	        when(requestHeadersSpecMock.accept(MediaType.APPLICATION_JSON)).thenReturn(requestHeadersSpecMock);
	        when(requestHeadersSpecMock.retrieve()).thenReturn(responseSpecMock);
	        when(responseSpecMock.bodyToMono(String.class)).thenReturn(Mono.just(expectedResponse));

	        // Act
	        String actualResponse = manageUserWebClient.updateUserinB2C(userAction, userId);

	        // Assert
	        assertEquals(expectedResponse, actualResponse);
	    }
	}

	@Test
	public void testGetUserData() {
		try (MockedStatic mockedWebClient = mockStatic(WebClient.class)) {
			// Arrange
			String businessEmailId = "test@example.com";
			User expectedUser = new User();
			expectedUser.id = "12345";

			WebClient.RequestHeadersUriSpec requestHeadersUriSpecMock = mock(WebClient.RequestHeadersUriSpec.class);
			WebClient.RequestHeadersSpec requestHeadersSpecMock = mock(WebClient.RequestHeadersSpec.class);
			ResponseSpec responseSpecMock = mock(WebClient.ResponseSpec.class);

			mockedWebClient.when(WebClient::create).thenReturn(webClientMock);
			when(webClientMock.get()).thenReturn(requestHeadersUriSpecMock);
			when(requestHeadersUriSpecMock.uri(anyString())).thenReturn(requestHeadersUriSpecMock);
			when(requestHeadersUriSpecMock.accept(MediaType.APPLICATION_JSON)).thenReturn(requestHeadersSpecMock);
			when(requestHeadersSpecMock.retrieve()).thenReturn(responseSpecMock);
			when(responseSpecMock.bodyToMono(User.class)).thenReturn(Mono.just(expectedUser));

			// Act
			User actualUser = manageUserWebClient.getUserData(businessEmailId);

			// Assert
			assertEquals(expectedUser.id, actualUser.id);
		}
	}
	
	@Test
	public void testSetIsAccountStatus() {
	    try (MockedStatic<WebClient> mockedWebClient = mockStatic(WebClient.class)) {
	        // Arrange
	        String oidOfUser = "12345";
	        String expectedResponse = "Failed";

	        WebClient.RequestBodyUriSpec requestBodyUriSpecMock = mock(WebClient.RequestBodyUriSpec.class);
	        WebClient.RequestHeadersSpec requestHeadersSpecMock = mock(WebClient.RequestHeadersSpec.class);
	        WebClient.ResponseSpec responseSpecMock = mock(WebClient.ResponseSpec.class);

	        mockedWebClient.when(WebClient::create).thenReturn(webClientMock);
	        when(webClientMock.patch()).thenReturn(requestBodyUriSpecMock);
	        when(requestBodyUriSpecMock.uri(anyString())).thenReturn(requestBodyUriSpecMock);
	      //  when(requestBodyUriSpecMock.body(any(), eq(JSONObject.class))).thenReturn(requestHeadersSpecMock);
	      //  when(requestHeadersSpecMock.accept(MediaType.APPLICATION_JSON)).thenReturn(requestHeadersSpecMock);
	//        when(requestHeadersSpecMock.retrieve()).thenReturn(responseSpecMock);
	  //      when(responseSpecMock.bodyToMono(Object.class)).thenReturn(Mono.just(new Object()));

	        // Act
	        String actualResponse = manageUserWebClient.setIsAccountStatus(oidOfUser, true);

	        // Assert
	        assertEquals(expectedResponse, actualResponse);
	    }
	}


}