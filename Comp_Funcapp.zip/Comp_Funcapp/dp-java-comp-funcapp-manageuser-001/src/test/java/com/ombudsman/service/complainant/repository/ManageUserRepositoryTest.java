package com.ombudsman.service.complainant.repository;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class ManageUserRepositoryTest {

	@Mock
	private JdbcTemplate jdbcTemplate;

	@InjectMocks
	private ManageUserRepository repository;

	@Mock
	private NamedParameterJdbcTemplate namedJdbcTemplate;

	@BeforeEach
	public void setup() {
		MockitoAnnotations.openMocks(this);
	}

	@Test
	public void testGetAdOidByContactId_Success() {
		String contactId = "123e4567-e89b-12d3-a456-426614174000";
		UUID expectedUUID = UUID.randomUUID();

		when(jdbcTemplate.queryForObject(anyString(), eq(UUID.class), eq(contactId))).thenReturn(expectedUUID);

		UUID result = repository.getAdOidByContactId(contactId, jdbcTemplate);

		assertNotNull(result);
		assertEquals(expectedUUID, result);
	}

	@Test
	public void testGetAdOidByContactId_Exception() {
		String contactId = "invalid-uuid";

		when(jdbcTemplate.queryForObject(anyString(), eq(UUID.class), eq(contactId)))
				.thenThrow(new RuntimeException("DB Error"));

		UUID result = repository.getAdOidByContactId(contactId, jdbcTemplate);

		assertNull(result);
	}

	@Test
	public void testGetAdOidByAuditId_Success() {
		String auditId = "sample-audit-id";
		UUID sampleUUID = UUID.randomUUID();
		List<UUID> expected = Collections.singletonList(sampleUUID);

		when(namedJdbcTemplate.queryForList(anyString(), anyMap(), eq(UUID.class))).thenReturn(expected);

		List<UUID> result = repository.getAdOidByAuditId(auditId, namedJdbcTemplate);

		assertNotNull(result);
		assertEquals(1, result.size());
		assertEquals(sampleUUID, result.get(0));
	}

	@Test
	public void testGetAdOidByAuditId_Exception() {
		String auditId = "sample-audit-id";

		when(namedJdbcTemplate.queryForList(anyString(), anyMap(), eq(UUID.class)))
				.thenThrow(new RuntimeException("DB error"));

		List<UUID> result = repository.getAdOidByAuditId(auditId, namedJdbcTemplate);

		assertNotNull(result);
		assertTrue(result.isEmpty());
	}
	
	@Test
	public void testGetOidByContactId_success() {
		// Arrange
		UUID id1 = UUID.randomUUID();
		UUID id2 = UUID.randomUUID();
		List<UUID> inputList = Arrays.asList(id1, id2);
		List<UUID> resultList = Arrays.asList(UUID.randomUUID(), UUID.randomUUID());

		when(namedJdbcTemplate.queryForList(anyString(), any(MapSqlParameterSource.class), eq(UUID.class)))
				.thenReturn(resultList);

		// Act
		List<UUID> actual = repository.getOidByContactId(inputList, namedJdbcTemplate);

		// Assert
		assertEquals(resultList.size(), actual.size());
		assertEquals(resultList, actual);
	}

	@Test
	public void testGetOidByContactId_exception() {
		// Arrange
		UUID id = UUID.randomUUID();
		List<UUID> inputList = Collections.singletonList(id);

		when(namedJdbcTemplate.queryForList(anyString(), any(MapSqlParameterSource.class), eq(UUID.class)))
				.thenThrow(new RuntimeException("DB error"));

		// Act
		List<UUID> result = repository.getOidByContactId(inputList, namedJdbcTemplate);

		// Assert
		assertNotNull(result);
		assertTrue(result.isEmpty());
	}


	 @Test
	    public void testDeleteCompContactId_Success() {
	        List<UUID> contactIds = Collections.singletonList(UUID.randomUUID());

	        // Mock successful updates
	        when(namedJdbcTemplate.update(any(String.class), any(MapSqlParameterSource.class))).thenReturn(1);

	        repository.deleteCompContactId(contactIds, namedJdbcTemplate);

	        verify(namedJdbcTemplate, times(2)).update(any(String.class), any(MapSqlParameterSource.class));
	    }

	    @Test
	    public void testDeleteCompContactId_Exception() {
	        List<UUID> contactIds = Collections.singletonList(UUID.randomUUID());

	        // Mock one of the update calls to throw exception
	        doThrow(new RuntimeException("DB Error")).when(namedJdbcTemplate)
	                .update(any(String.class), any(MapSqlParameterSource.class));

	        repository.deleteCompContactId(contactIds, namedJdbcTemplate);

	        verify(namedJdbcTemplate, times(1)).update(any(String.class), any(MapSqlParameterSource.class));
	    }
	    
	    @Test
	    public void testUpdateAuditById_Success() {
	        List<UUID> contactIds = Collections.singletonList(UUID.randomUUID());
	        when(namedJdbcTemplate.update(any(String.class), any(MapSqlParameterSource.class))).thenReturn(1);

	        int result = repository.updateAuditById(contactIds, namedJdbcTemplate);

	        assertEquals(1, result);
	        verify(namedJdbcTemplate, times(1)).update(any(String.class), any(MapSqlParameterSource.class));
	    }

	    @Test
	    public void testUpdateAuditById_Exception() {
	        List<UUID> contactIds = Collections.singletonList(UUID.randomUUID());
	        when(namedJdbcTemplate.update(any(String.class), any(MapSqlParameterSource.class)))
	                .thenThrow(new RuntimeException("DB error"));

	        int result = repository.updateAuditById(contactIds,namedJdbcTemplate);

	        assertEquals(0, result);
	        verify(namedJdbcTemplate, times(1)).update(any(String.class), any(MapSqlParameterSource.class));
	    }
	    
	    @Test
	    public void testUpdateUserById_Success() {
	        UUID contactId = UUID.randomUUID();

	        when(jdbcTemplate.update(anyString(), any(UUID.class))).thenReturn(1);

	        repository.updateUserById(contactId, jdbcTemplate);

	        verify(jdbcTemplate, times(1)).update(anyString(), eq(contactId));
	    }

	    @Test
	    public void testUpdateUserById_Exception() {
	        UUID contactId = UUID.randomUUID();

	        doThrow(new RuntimeException("DB error"))
	                .when(jdbcTemplate).update(anyString(), any(UUID.class));

	        repository.updateUserById(contactId, jdbcTemplate);

	        verify(jdbcTemplate, times(1)).update(anyString(), eq(contactId));
	    }


	
}
