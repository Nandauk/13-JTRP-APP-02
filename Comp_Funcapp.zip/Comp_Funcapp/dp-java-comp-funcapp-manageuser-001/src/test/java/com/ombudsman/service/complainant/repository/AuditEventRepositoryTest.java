package com.ombudsman.service.complainant.repository;

import com.ombudsman.service.complainant.model.AuditEventRequest;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.springframework.jdbc.core.JdbcTemplate;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

import java.time.LocalDateTime;

public class AuditEventRepositoryTest {

    private JdbcTemplate jdbcTemplate;
    private AuditEventRepository auditEventRepository;

    @BeforeEach
    public void setUp() {
        jdbcTemplate = mock(JdbcTemplate.class);
        auditEventRepository = new AuditEventRepository();
    }

    @Test
    public void testCreateAuditEventRecord() throws Exception {
        // Arrange
        AuditEventRequest request = new AuditEventRequest();
        request.setUserOid("user123");
        request.setAudit_event_timestamp(LocalDateTime.now());
        request.setAudit_event_name("LOGIN");
        request.setPre_audit_snapshot("{\"status\":\"before\"}");
        request.setCreatedOn(LocalDateTime.now());
        request.setCreatedBy("admin");

        // Act
        auditEventRepository.createAuditEventRecord(request, jdbcTemplate);

        // Assert
        ArgumentCaptor<String> sqlCaptor = ArgumentCaptor.forClass(String.class);
        ArgumentCaptor<Object[]> paramsCaptor = ArgumentCaptor.forClass(Object[].class);

        verify(jdbcTemplate, times(1)).update(sqlCaptor.capture(), paramsCaptor.capture());

        assertEquals("INSERT INTO dp_complainant_audit_event (user_oid, audit_event_timestamp, audit_event_name, pre_audit_snapshot, created_on,created_by) VALUES (?, ?, ?, ?, ?, ?)", sqlCaptor.getValue());
        Object[] params = paramsCaptor.getValue();
        assertEquals("user123", params[0]);
        assertEquals("LOGIN", params[2]);
        assertEquals("{\"status\":\"before\"}", params[3]);
        assertEquals("admin", params[5]);
    }
}
