package com.ombudsman.service.complainant.exception;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import jakarta.servlet.http.HttpServletRequest;

import java.time.LocalDateTime;
import java.util.Locale;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class GlobalExceptionHandlerTest {

    @InjectMocks
    private GlobalExceptionHandler exceptionHandler;

    @Mock
    private MessageSource messageSource;

    @Mock
    private HttpServletRequest request;

    @BeforeEach
    public void setup() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testHandleUserUnauthoriseException() {
        String expectedMessage = "Unauthorized access";
        String requestUrl = "http://localhost/test";

        when(messageSource.getMessage(eq("api.error.unauthorised"), any(), eq(Locale.ENGLISH)))
                .thenReturn(expectedMessage);
        when(request.getRequestURL()).thenReturn(new StringBuffer(requestUrl));

        Exception ex = new Exception("Simulated exception");

        ResponseEntity<ApiError> response = exceptionHandler.handleUserUnauthoriseException(request, ex);

        assertNotNull(response);
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());

        ApiError error = response.getBody();
        assertNotNull(error);
        assertEquals(HttpStatus.UNAUTHORIZED, error.getStatus());
        assertEquals(String.valueOf(HttpStatus.UNAUTHORIZED.value()), error.getErrorCode());
        assertEquals(expectedMessage, error.getErrorMessage());
        assertTrue(error.getTimestamp().isBefore(LocalDateTime.now().plusSeconds(1)));
    }
}
