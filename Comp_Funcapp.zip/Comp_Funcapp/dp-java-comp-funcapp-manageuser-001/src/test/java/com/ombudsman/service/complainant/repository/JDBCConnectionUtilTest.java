package com.ombudsman.service.complainant.repository;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

import static org.junit.jupiter.api.Assertions.*;

public class JDBCConnectionUtilTest {

    @BeforeEach
    public void setUp() {
        // Set environment variables for testing
        System.setProperty("SQL_DATASOURCE_URL", "jdbc:sqlserver://localhost:1433;databaseName=testdb");
        System.setProperty("SQL_DATASOURCE_USERNAME", "testuser");
        System.setProperty("SQL_DATASOURCE_PASSWORD", "testpass");
    }

    @Test
    public void testGetJdbcConnection_NotNull() {
        JdbcTemplate jdbcTemplate = JDBCConnectionUtil.getJdbcConnection();
        assertNotNull(jdbcTemplate);
        assertNotNull(jdbcTemplate.getDataSource());
        assertTrue(jdbcTemplate.getDataSource() instanceof DriverManagerDataSource);
    }

    @Test
    public void testGetNamedParameterJdbcConnection_NotNull() {
        NamedParameterJdbcTemplate namedJdbcTemplate = JDBCConnectionUtil.getNamedParameterJdbcConnection();
        assertNotNull(namedJdbcTemplate);
    }

    @Test
    public void testDataSourceConfiguration() {
        JdbcTemplate jdbcTemplate = JDBCConnectionUtil.getJdbcConnection();
        assertNotNull(jdbcTemplate);

        DriverManagerDataSource ds = (DriverManagerDataSource) jdbcTemplate.getDataSource();
        assertNotNull(ds);
        assertEquals(null, ds.getUrl());
        assertEquals(null, ds.getUsername());
        assertEquals(null, ds.getPassword());
    }

    private DriverManagerDataSource getTestDataSource() {
        return (DriverManagerDataSource) JDBCConnectionUtil.getJdbcConnection().getDataSource();
    }
}
