package com.ombudsman.service.complainant.exception;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class AzureServiceExceptionTest {

    @Test
    public void testAzureServiceExceptionConstructor() {
        String message = "Azure error occurred";
        String exceptionMessage = "Detailed Azure exception message";
        StackTraceElement[] stackTrace = Thread.currentThread().getStackTrace();

        AzureServiceException exception = new AzureServiceException(message, exceptionMessage, stackTrace);

        assertEquals("Azure error occurred", exception.getMessage());
        assertEquals("COMPALINANT_AZURE_1000", exception.getCode());
        assertEquals("Detailed Azure exception message", exception.getExceptionMessage());
       // assertNotEquals("71", exception.getStackTrace());
    }
}
