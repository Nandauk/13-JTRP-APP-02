package com.ombudsman.service.complainant.exception;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class ComplainantServiceExceptionsTest {

    @Test
    public void testExceptionFields() {
        String message = "Custom error message";
        String code = "ERR001";
        String exceptionMessage = "Detailed exception message";
        StackTraceElement[] stackTrace = Thread.currentThread().getStackTrace();

        ComplainantServiceExceptions exception = new ComplainantServiceExceptions(
                message, code, exceptionMessage, stackTrace
        );

        assertEquals(message, exception.getMessage());
        assertEquals(code, exception.getCode());
        assertEquals(exceptionMessage, exception.getExceptionMessage());
        assertArrayEquals(stackTrace, exception.getStackTraceMessage());
    }
}
