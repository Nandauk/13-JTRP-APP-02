package com.ombudsman.service.complainant.common;

import okhttp3.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;

import com.ombudsman.service.complainant.exception.PhoenixServiceException;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;
import okhttp3.mockwebserver.MockResponse;
import okhttp3.mockwebserver.MockWebServer;
import org.junit.jupiter.api.*;
@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
public class PhoenixUpdateTest {
	class TestPhoenixUpdate extends PhoenixUpdate {
	    private final String baseUrl;

	    public TestPhoenixUpdate(String baseUrl) {
	        this.baseUrl = baseUrl;
	    }

	    @Override
	    public int updatePhoenixEntity(String entity, String guid, String jsonBody, String path) {
	        try {
	            OkHttpClient client = new OkHttpClient();
	            MediaType mediaType = MediaType.parse("application/json; charset=utf-8");

	            HttpUrl url = HttpUrl.parse(baseUrl)
	                    .newBuilder()
	                    .addPathSegment("phoenixapimp")
	                    .addPathSegment(entity + "(" + guid + ")")
	                    .addPathSegment(path)
	                    .build();

	            RequestBody body = RequestBody.create(mediaType, jsonBody);
	            Request request = getPhoenixRequestBuild(url.toString(), body);
	            Response response = client.newCall(request).execute();
	            return response.code();
	        } catch (Exception e) {
	            throw new PhoenixServiceException("Phoenix conectivity error occured  inside UserDetailUpdateInPNXMethod method", e.getMessage(), e.getStackTrace());
	        }
	    }
	}


    @Mock
    private OkHttpClient mockClient;

    @Mock
    private Call mockCall;

    @Mock
    private Response mockResponse;
    private MockWebServer mockWebServer; // ✅ Declare it here

    private PhoenixUpdate phoenixUpdate;
    

    @BeforeEach
    public void setup() throws Exception {
        mockWebServer = new MockWebServer();
        mockWebServer.start();

        // Remove trailing slash and set only host:port
        String hostWithPort = mockWebServer.getHostName() + ":" + mockWebServer.getPort();
        System.setProperty("APIM_HOST", "http://" + hostWithPort);

        phoenixUpdate = new PhoenixUpdate();
    }


    @AfterEach
    public void tearDown() throws Exception {
        mockWebServer.shutdown();
    }

    
    @Test
    public void testGetPhoenixRequestBuild() {
        PhoenixUpdate phoenixUpdate = new PhoenixUpdate();

        String testUrl = "https://mockhost.com/test";
        MediaType mediaType = MediaType.parse("application/json; charset=utf-8");
        RequestBody requestBody = RequestBody.create(mediaType, "{\"key\":\"value\"}");

        Request request = phoenixUpdate.getPhoenixRequestBuild(testUrl, requestBody);

        assertNotNull(request);
        assertEquals(testUrl, request.url().toString());
        assertEquals("application/json", request.header("Content-Type"));
        assertEquals("4.0", request.header("OData-MaxVersion"));
        assertEquals("4.0", request.header("OData-Version"));
        assertEquals("PATCH", request.method());
    }
    
    @Test
    public void testUpdatePhoenixEntity_Success204() throws Exception {
        // Use a spy to override the method that makes the HTTP call
        PhoenixUpdate spyUpdate = spy(phoenixUpdate);

        // Mock the actual HTTP call inside the method
        doReturn(204).when(spyUpdate).updatePhoenixEntity(anyString(), anyString(), anyString(), anyString());

        int responseCode = spyUpdate.updatePhoenixEntity("contacts", "12345", "{\"key\":\"value\"}", "updateInviteStatusinPnx");

        assertEquals(204, responseCode);
    }

    @Test
    public void testUpdatePhoenixEntity_ThrowsException() {
        PhoenixUpdate spyUpdate = spy(phoenixUpdate);

        // Simulate exception thrown from the method
        doThrow(new PhoenixServiceException("Phoenix error", "Network error", new StackTraceElement[0]))
                .when(spyUpdate).updatePhoenixEntity(anyString(), anyString(), anyString(), anyString());

        PhoenixServiceException exception = assertThrows(PhoenixServiceException.class, () -> {
            spyUpdate.updatePhoenixEntity("contacts", "123", "{}", "updateInviteStatusinPnx");
        });

        assertTrue(exception.getMessage().contains("Phoenix error"));
    }


    @Test
    public void testUserDetailUpdateInPNXMethod_Success() {
        PhoenixUpdate spyUpdate = spy(phoenixUpdate);
        try {
            doReturn(204).when(spyUpdate).updatePhoenixEntity(any(), any(), any(), any());
            assertDoesNotThrow(() -> spyUpdate.userDetailUpdateInPNXMethod("12345"));
        } catch (Exception e) {
            fail("Exception should not be thrown");
        }
    }
    
    @Test
    public void testUpdatePhoenixEntity_Success() throws Exception {
        mockWebServer.enqueue(new MockResponse().setResponseCode(204));

        String baseUrl = mockWebServer.url("/").toString(); // e.g., http://localhost:12345/
        PhoenixUpdate phoenixUpdate = new TestPhoenixUpdate(baseUrl);

        String entity = "contacts";
        String guid = "12345";
        String jsonBody = "{\"status\":\"disabled\"}";
        String path = "updateInviteStatusinPnx";

        int responseCode = phoenixUpdate.updatePhoenixEntity(entity, guid, jsonBody, path);

        assertEquals(204, responseCode);

        var recordedRequest = mockWebServer.takeRequest();
        assertEquals("PATCH", recordedRequest.getMethod());
        assertTrue(recordedRequest.getPath().contains("contacts(12345)/updateInviteStatusinPnx"));
    }


    @Test
    public void testUpdatePhoenixEntity_ExceptionThrown() {
        // Arrange
        System.setProperty("APIM_HOST", "invalid-url"); // Force an error
        String entity = "contacts";
        String guid = "12345";
        String jsonBody = "{\"status\":\"disabled\"}";
        String path = "disable";

        // Act & Assert
        PhoenixServiceException exception = assertThrows(PhoenixServiceException.class, () ->
                phoenixUpdate.updatePhoenixEntity(entity, guid, jsonBody, path));

        assertTrue(exception.getMessage().contains("Phoenix error"));
    }

}
