package com.ombudsman.service.complainant.helper;

import com.ombudsman.service.complainant.model.AuditEventRequest;
import org.junit.jupiter.api.Test;

import java.time.LocalDateTime;

import static org.junit.jupiter.api.Assertions.*;

public class AuditEventHelperTest {

    @Test
    public void testCreateAuditEventRequest() {
        // Arrange
        AuditEventHelper helper = new AuditEventHelper();
        String contactId = "test-contact-id";

        // Act
        AuditEventRequest result = helper.createAuditEventRequest(contactId);

        // Assert
        assertNotNull(result);
        assertEquals(contactId, result.getUserOid());
        assertEquals("LOGICAPPDISABLEUSER", result.getAudit_event_name());
        assertEquals("LOGICAPPDISABLEUSERFUNCAPP", result.getCreatedBy());
        assertNotNull(result.getAudit_event_timestamp());
        assertNotNull(result.getCreatedOn());

        // Optional: Check timestamps are close to now
        LocalDateTime now = LocalDateTime.now();
        assertTrue(result.getAudit_event_timestamp().isBefore(now.plusSeconds(1)));
        assertTrue(result.getCreatedOn().isBefore(now.plusSeconds(1)));
    }
}
