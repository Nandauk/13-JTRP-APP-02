package com.ombudsman.service.complainant.exception;

import org.junit.jupiter.api.Test;
import org.springframework.http.HttpStatus;

import java.time.LocalDateTime;

import static org.junit.jupiter.api.Assertions.*;

public class ApiErrorTest {

    @Test
    public void testApiErrorConstructorAndGetters() {
        LocalDateTime now = LocalDateTime.now();
        HttpStatus status = HttpStatus.BAD_REQUEST;
        String errorCode = "400";
        String errorMessage = "Invalid request";

        ApiError apiError = new ApiError(now, status, errorCode, errorMessage);

        assertEquals(now, apiError.getTimestamp());
        assertEquals(status, apiError.getStatus());
        assertEquals(errorCode, apiError.getErrorCode());
        assertEquals(errorMessage, apiError.getErrorMessage());
    }

    @Test
    public void testSetters() {
        ApiError apiError = new ApiError(LocalDateTime.now(), HttpStatus.OK, "200", "OK");

        LocalDateTime newTime = LocalDateTime.of(2025, 5, 15, 12, 0);
        HttpStatus newStatus = HttpStatus.INTERNAL_SERVER_ERROR;
        String newCode = "500";
        String newMessage = "Server error";

        apiError.setTimestamp(newTime);
        apiError.setStatus(newStatus);
        apiError.setErrorCode(newCode);
        apiError.setErrorMessage(newMessage);

        assertEquals(newTime, apiError.getTimestamp());
        assertEquals(newStatus, apiError.getStatus());
        assertEquals(newCode, apiError.getErrorCode());
        assertEquals(newMessage, apiError.getErrorMessage());
    }
}
