package com.ombudsman.service.complainant;
import static org.mockito.Mockito.*;

import java.util.List;
import java.util.UUID;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.microsoft.azure.functions.ExecutionContext;
import com.ombudsman.service.complainant.common.ManageUserWebClient;
import com.ombudsman.service.complainant.common.PhoenixUpdate;
import com.ombudsman.service.complainant.dao.ManageUserDataAccess;
import com.ombudsman.service.complainant.helper.AuditEventHelper;
import com.ombudsman.service.complainant.model.AuditEventRequest;
import com.ombudsman.service.complainant.model.Contact;
import com.ombudsman.service.complainant.model.DeleteUserRequest;
import com.ombudsman.service.complainant.repository.AuditEventRepository;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

public class ManagerUserAzureFunctionTest {

    @InjectMocks
    private ManagerUserAzureFunction function;

    @Mock private ManageUserDataAccess manageUserDataAccess;
    @Mock private ManageUserWebClient manageUserWebClient;
    @Mock private PhoenixUpdate phoenixUpdate;
    @Mock private AuditEventHelper auditEventHelper;
    @Mock private AuditEventRepository auditEventRepository;
    @Mock private JdbcTemplate jdbcTemplate;
    @Mock private ExecutionContext context;
    @Mock private NamedParameterJdbcTemplate namedJdbcTemplate;

    @BeforeEach
    public void setup() {
        MockitoAnnotations.openMocks(this);

        // Inject mocks into the final fields using reflection
        function = new ManagerUserAzureFunction();

        // Use reflection to inject mocks into final fields
        injectField(function, "manageUserDataAccess", manageUserDataAccess);
        injectField(function, "manageUserWebClient", manageUserWebClient);
        injectField(function, "phoenixUpdate", phoenixUpdate);
        injectField(function, "auditEventHelper", auditEventHelper);
        injectField(function, "auditEventRepository", auditEventRepository);
        injectField(function, "jdbcConnection", jdbcTemplate);
        injectField(function, "namedJdbcTemplate", namedJdbcTemplate);
    }

    private void injectField(Object target, String fieldName, Object value) {
        try {
            var field = target.getClass().getDeclaredField(fieldName);
            field.setAccessible(true);
            field.set(target, value);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Test
    public void testDisableUserFunction_withValidContact() throws Exception {
        Contact contact = new Contact();
        contact.setContactId("1234");
        contact.setStatecode(1);

        UUID adOid = UUID.randomUUID();
        AuditEventRequest auditEventRequest = new AuditEventRequest();

        when(auditEventHelper.createAuditEventRequest("1234")).thenReturn(auditEventRequest);
        doNothing().when(auditEventRepository).createAuditEventRecord(any(), eq(jdbcTemplate));
        when(manageUserDataAccess.getAdOidByContactId(eq("1234"), eq(jdbcTemplate))).thenReturn(adOid);
        when(manageUserWebClient.setIsAccountStatus(adOid.toString(), false)).thenReturn("Success");

        ObjectMapper mapper = new ObjectMapper();
        String message = mapper.writeValueAsString(contact);

        function.disableUserFunction(message, context);

        verify(manageUserWebClient).setIsAccountStatus(adOid.toString(), false);
        verify(phoenixUpdate).userDetailUpdateInPNXMethod("1234");
    }

    @Test
    public void testDeleteUserFunction_withValidAuditId() throws Exception {
        DeleteUserRequest request = new DeleteUserRequest();
        request.setAuditid("audit1"); 

        List<UUID> contactIds = List.of(UUID.randomUUID(), UUID.randomUUID());

        when(manageUserDataAccess.getAdOidByAuditId(eq("audit1"), eq(namedJdbcTemplate))).thenReturn(contactIds);
        when(manageUserDataAccess.getOidByContactId(any(), eq(namedJdbcTemplate))).thenReturn(contactIds);

        ObjectMapper mapper = new ObjectMapper();
        String message = mapper.writeValueAsString(request);

        function.deleteUserFunction(message, context);

      //  verify(manageUserWebClient, times(2)).deleteUserfromB2C(anyString());
      //  verify(manageUserDataAccess).deleteCompContactId(contactIds, jdbcTemplate);
        //verify(manageUserDataAccess).updateAuditById(contactIds, jdbcTemplate);
    }

}
