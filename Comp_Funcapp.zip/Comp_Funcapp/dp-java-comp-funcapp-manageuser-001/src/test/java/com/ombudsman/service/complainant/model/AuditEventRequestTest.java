package com.ombudsman.service.complainant.model;

import org.junit.jupiter.api.Test;

import java.time.LocalDateTime;

import static org.junit.jupiter.api.Assertions.*;

public class AuditEventRequestTest {

    @Test
    public void testAuditEventRequestSettersAndGetters() {
        AuditEventRequest request = new AuditEventRequest();

        String userOid = "user-123";
        LocalDateTime auditTimestamp = LocalDateTime.now();
        String auditEventName = "USER_DISABLED";
        String preAuditSnapshot = "{\"status\":\"active\"}";
        String createdBy = "admin";
        LocalDateTime createdOn = LocalDateTime.now();
        String modifiedOn = "2025-05-22T10:00:00";
        String modifiedBy = "system";

        request.setUserOid(userOid);
        request.setAudit_event_timestamp(auditTimestamp);
        request.setAudit_event_name(auditEventName);
        request.setPre_audit_snapshot(preAuditSnapshot);
        request.setCreatedBy(createdBy);
        request.setCreatedOn(createdOn);
        request.setModifiedOn(modifiedOn);
        request.setModifiedBy(modifiedBy);

        assertEquals(userOid, request.getUserOid());
        assertEquals(auditTimestamp, request.getAudit_event_timestamp());
        assertEquals(auditEventName, request.getAudit_event_name());
        assertEquals(preAuditSnapshot, request.getPre_audit_snapshot());
        assertEquals(createdBy, request.getCreatedBy());
        assertEquals(createdOn, request.getCreatedOn());
        assertEquals(modifiedOn, request.getModifiedOn());
        assertEquals(modifiedBy, request.getModifiedBy());
    }
}
