package com.ombudsman.service.complainant.dao;

import com.ombudsman.service.complainant.repository.ManageUserRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class ManageUserDataAccessTest {

    private ManageUserDataAccess dataAccess;

    @Mock
    private ManageUserRepository mockRepository;

    @Mock
    private JdbcTemplate jdbcTemplate;

    @Mock
    private NamedParameterJdbcTemplate namedJdbcTemplate;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
        dataAccess = new ManageUserDataAccess();
        dataAccess.repository = mockRepository; // Inject mock
    }

    @Test
    public void testGetAdOidByContactId() {
        String contactId = "contact123";
        UUID expected = UUID.randomUUID();
        when(mockRepository.getAdOidByContactId(contactId, jdbcTemplate)).thenReturn(expected);

        UUID result = dataAccess.getAdOidByContactId(contactId, jdbcTemplate);
        assertEquals(expected, result);
    }

    @Test
    public void testGetAdOidByAuditId() {
        String auditId = "audit123";
        List<UUID> expected = Collections.singletonList(UUID.randomUUID());
        when(mockRepository.getAdOidByAuditId(auditId, namedJdbcTemplate)).thenReturn(expected);

        List<UUID> result = dataAccess.getAdOidByAuditId(auditId, namedJdbcTemplate);
        assertEquals(expected, result);
    }

    @Test
    public void testGetOidByContactId() {
        List<UUID> contactIds = Collections.singletonList(UUID.randomUUID());
        List<UUID> expected = Collections.singletonList(UUID.randomUUID());
        when(mockRepository.getOidByContactId(contactIds, namedJdbcTemplate)).thenReturn(expected);

        List<UUID> result = dataAccess.getOidByContactId(contactIds, namedJdbcTemplate);
        assertEquals(expected, result);
    }

    @Test
    public void testDeleteCompContactId() {
        List<UUID> contactIds = Collections.singletonList(UUID.randomUUID());
        doNothing().when(mockRepository).deleteCompContactId(contactIds, namedJdbcTemplate);

        dataAccess.deleteCompContactId(contactIds, namedJdbcTemplate);
        verify(mockRepository, times(1)).deleteCompContactId(contactIds, namedJdbcTemplate);
    }

    @Test
    public void testUpdateAuditById() {
        List<UUID> contactIds = Collections.singletonList(UUID.randomUUID());
        when(mockRepository.updateAuditById(contactIds, namedJdbcTemplate)).thenReturn(2);

        int result = dataAccess.updateAuditById(contactIds, namedJdbcTemplate);
        assertEquals(2, result);
    }

    @Test
    public void testUpdateUserById() {
        UUID userId = UUID.randomUUID();
        doNothing().when(mockRepository).updateUserById(userId, jdbcTemplate);

        dataAccess.updateUserById(userId, jdbcTemplate);
        verify(mockRepository, times(1)).updateUserById(userId, jdbcTemplate);
    }
}
