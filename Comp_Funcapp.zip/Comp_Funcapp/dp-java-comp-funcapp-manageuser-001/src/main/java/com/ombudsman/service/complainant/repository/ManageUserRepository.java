package com.ombudsman.service.complainant.repository;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

import com.google.common.collect.Lists;

public class ManageUserRepository {

	private final Logger logger = LogManager.getRootLogger();

	public UUID getAdOidByContactId(String contactId, JdbcTemplate templateConnection) {
		logger.info("method::getAdOidByContactId contactId {}", contactId);

		String sql = "SELECT oid FROM dp_user_dpcomplainant where pnxuuid=? ";
		try {

			return templateConnection.queryForObject(sql, UUID.class, contactId);

		} catch (Exception e) {

			logger.info("Exception occured during getAdOidByContactId method call::{}", e.getMessage());
			return null;
		}

	}

	public List<UUID> getAdOidByAuditId(String auditId, NamedParameterJdbcTemplate namedJdbcTemplate) {
		logger.info("method::getAdOidByAuditId auditId {}", auditId);
		List<UUID> contactId;
		
		try {
			
			String sql = "select id from dp_incremental_entities_delete where entityname='CONTACT_ENTITY' and status='IN_PROGRESS' AND auditid IN (:auditId) ";
			 
		        Map<String, Object> params = new HashMap<>();
		        params.put("auditId", auditId);
		 
		        contactId = namedJdbcTemplate.queryForList(sql, params, UUID.class);
		        
		    		
			 return contactId;

		} catch (Exception e) {

			logger.info("Exception occured during getAdOidByAuditId method call::{}", e.getMessage());
			return Lists.newArrayList();
		}

	}

	
	
	public List<UUID> getOidByContactId(List<UUID> contactId,NamedParameterJdbcTemplate namedJdbcTemplate) {
		logger.info("method::getPnxIdByContactId contactId {}", contactId);
		List<UUID> contactIdList;

		String sql = "SELECT oid FROM dp_user_dpcomplainant where pnxuuid in (:contactId)";
		try {
			
			MapSqlParameterSource params = new MapSqlParameterSource();
			params.addValue("contactId", contactId);
		 
			contactIdList = namedJdbcTemplate.queryForList(sql, params, UUID.class);

			return contactIdList;

		} catch (Exception e) {

			logger.info("Exception occured during getPnxIdByContactId method call::{}", e.getMessage());
			return Lists.newArrayList();
		}

	}
	
	

	public void deleteCompContactId(List<UUID> contactId, NamedParameterJdbcTemplate namedJdbcTemplate) {
		logger.info("method::deleteCompContactId contactId {}", contactId);

		String userGrpSql = "delete from dp_user_group_role_complainant where ad_user_id in (select oid from dp_user_dpcomplainant where pnxuuid in (:contactId))";

		String sql = "delete from dp_user_dpcomplainant where pnxuuid in (:contactId)";
		try {
			
			MapSqlParameterSource params = new MapSqlParameterSource();
			params.addValue("contactId", contactId);
			
			namedJdbcTemplate.update(userGrpSql, params);

			namedJdbcTemplate.update(sql,params);

		} catch (Exception e) {

			logger.info("Exception occured during deleteCompContactId method call::{}", e.getMessage());

		}
	}

	

	public int updateAuditById(List<UUID> contactId, NamedParameterJdbcTemplate namedJdbcTemplate) {
		
		logger.info("method::updateAuditById contactId {}", contactId);
		int updatedContactId = 0;

		String sql = "update dp_incremental_entities_delete set status='Deleted' where id in (:contactId)";
		try {
			
			MapSqlParameterSource params = new MapSqlParameterSource();
			params.addValue("contactId", contactId);
			
			updatedContactId = namedJdbcTemplate.update(sql, params);

			//return templateConnection.queryForObject(sql, List.class, contactId);
			return updatedContactId;

		} catch (Exception e) {

			logger.info("Exception occured during updateAuditById method call::{}", e.getMessage());
			return updatedContactId;
		}

	}
	
	public void updateUserById(UUID contactId, JdbcTemplate templateConnection) {
		logger.info("method::updateUserById contactId {}", contactId);

		String sql = "update dp_user_dpcomplainant set user_ad_status='Disable' where oid=? ";
		try {

			 templateConnection.update(sql, contactId);

		} catch (Exception e) {

			logger.info("Exception occured during updateUserById method call::{}", e.getMessage());
		}

	}
	

}
