package com.ombudsman.service.complainant.exception;

import java.time.LocalDateTime;
import java.util.Locale;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import jakarta.servlet.http.HttpServletRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class GlobalExceptionHandler {
	
	private static final Logger LOG = LoggerFactory.getLogger(GlobalExceptionHandler.class);
	
	@Autowired
	private MessageSource messageSource;
	private static final String API_ERROR_UNAUTHORISED = "api.error.unauthorised";

	
	//@ExceptionHandler({ UnAuthorisedException.class })
	public ResponseEntity<ApiError> handleUserUnauthoriseException(HttpServletRequest request, Exception ex) {
		String message = messageSource.getMessage(API_ERROR_UNAUTHORISED, null, Locale.ENGLISH);
		LOG.info("Errors while executing Respondent User azure or  db query:: URL= {}, complete errors::{}",
				request.getRequestURL(), ex.getMessage());
		ApiError err = new ApiError(LocalDateTime.now(), HttpStatus.UNAUTHORIZED,
				String.valueOf(HttpStatus.UNAUTHORIZED.value()), message);
		return new ResponseEntity<>(err, HttpStatus.INTERNAL_SERVER_ERROR);
	}

}
