package com.ombudsman.service.complainant.helper;

import java.time.LocalDateTime;

import com.ombudsman.service.complainant.model.AuditEventRequest;

public class AuditEventHelper {
	
	private static final String LOGICAPPDISABLEUSERFUNCAPP = "LOGICAPPDISABLEUSERFUNCAPP";
	private static final String LOGICAPPDISABLEUSER = "LOGICAPPDISABLEUSER";

	public AuditEventRequest createAuditEventRequest(String contactId) {
		AuditEventRequest auditEventRequest = new AuditEventRequest();
		auditEventRequest.setUserOid(contactId);
		auditEventRequest.setAudit_event_name(LOGICAPPDISABLEUSER);
		auditEventRequest.setAudit_event_timestamp(LocalDateTime.now());
		auditEventRequest.getPre_audit_snapshot();
		auditEventRequest.setCreatedOn(LocalDateTime.now());
		auditEventRequest.setCreatedBy(LOGICAPPDISABLEUSERFUNCAPP);
		
		return auditEventRequest;
	}

}
