package com.ombudsman.service.complainant.exception;

public class PhoenixServiceException extends ComplainantServiceExceptions {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;


	public PhoenixServiceException(String message,String exceptionMessage,StackTraceElement[] stackTraceElements) {
		super(message, "COMPLAINANT_PHOENIX_1001",exceptionMessage,stackTraceElements);
	}
	
	
	

}
