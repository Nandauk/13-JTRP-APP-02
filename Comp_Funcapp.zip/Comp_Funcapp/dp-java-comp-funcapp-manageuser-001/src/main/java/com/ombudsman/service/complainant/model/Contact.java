package com.ombudsman.service.complainant.model;

public class Contact {
	
	String contactId;
	int statecode;
	String fos_digitalportalinvitestatus;
	

	public String getContactId() {
		return contactId;
	}

	public void setContactId(String contactId) {
		this.contactId = contactId;
	}

	public int getStatecode() {
		return statecode;
	}

	public void setStatecode(int statecode) {
		this.statecode = statecode;
	}

	public String getFos_digitalportalinvitestatus() {
		return fos_digitalportalinvitestatus;
	}

	public void setFos_digitalportalinvitestatus(String fos_digitalportalinvitestatus) {
		this.fos_digitalportalinvitestatus = fos_digitalportalinvitestatus;
	}
	
	

	
	
	

}
