package com.ombudsman.service.complainant.dao;

import java.util.List;
import java.util.UUID;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

import com.ombudsman.service.complainant.repository.ManageUserRepository;

public class ManageUserDataAccess {

	ManageUserRepository repository = new ManageUserRepository();

	public UUID getAdOidByContactId(String contactId, JdbcTemplate jdbcTemplate) {

		return repository.getAdOidByContactId(contactId, jdbcTemplate);

	}

	public List<UUID> getAdOidByAuditId(String auditId, NamedParameterJdbcTemplate namedJdbcTemplate) {

		return repository.getAdOidByAuditId(auditId, namedJdbcTemplate);

	}

	

	public List<UUID> getOidByContactId(List<UUID> conatctId, NamedParameterJdbcTemplate namedJdbcTemplate) {

		return repository.getOidByContactId(conatctId, namedJdbcTemplate);

	}

	public void deleteCompContactId(List<UUID> conatctId, NamedParameterJdbcTemplate namedJdbcTemplate) {

		repository.deleteCompContactId(conatctId, namedJdbcTemplate);

	}

	public int updateAuditById(List<UUID> conatctId, NamedParameterJdbcTemplate namedJdbcTemplate) {

		return repository.updateAuditById(conatctId, namedJdbcTemplate);

	}

	public void updateUserById(UUID adOid, JdbcTemplate jdbcTemplate) {

		repository.updateUserById(adOid, jdbcTemplate);

	}

}
