package com.ombudsman.service.complainant.repository;

import org.springframework.jdbc.core.JdbcTemplate;

import com.azure.json.implementation.jackson.core.JsonProcessingException;
import com.azure.messaging.servicebus.ServiceBusException;
import com.ombudsman.service.complainant.model.AuditEventRequest;

public class AuditEventRepository {
	
	public void createAuditEventRecord(AuditEventRequest auditEventRequest,JdbcTemplate jdbcTemplate) throws JsonProcessingException, InterruptedException, ServiceBusException {

		String sql = "INSERT INTO dp_complainant_audit_event (user_oid, audit_event_timestamp, audit_event_name, pre_audit_snapshot, created_on,created_by) " +
				"VALUES (?, ?, ?, ?, ?, ?)";
		Object[] params = new Object[] {
				auditEventRequest.getUserOid(),
				auditEventRequest.getAudit_event_timestamp(),
				auditEventRequest.getAudit_event_name(),
				auditEventRequest.getPre_audit_snapshot(),
				auditEventRequest.getCreatedOn(),
				auditEventRequest.getCreatedBy()				
		};
		jdbcTemplate.update(sql, params);


	}

}
