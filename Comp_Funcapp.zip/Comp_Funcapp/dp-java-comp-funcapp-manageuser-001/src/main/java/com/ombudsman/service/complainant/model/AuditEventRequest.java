package com.ombudsman.service.complainant.model;

import java.time.LocalDateTime;

public class AuditEventRequest {
	

	private String userOid; // notnull

	private LocalDateTime audit_event_timestamp; // notnull

	private String audit_event_name; // notnull
	
	private String pre_audit_snapshot;
	
	
	private String createdBy; // notnull
	private LocalDateTime createdOn; // notnu
	private String modifiedOn;
	
	private String modifiedBy;

	public String getUserOid() {
		return userOid;
	}

	public void setUserOid(String userOid) {
		this.userOid = userOid;
	}

	

	public LocalDateTime getAudit_event_timestamp() {
		return audit_event_timestamp;
	}

	public void setAudit_event_timestamp(LocalDateTime audit_event_timestamp) {
		this.audit_event_timestamp = audit_event_timestamp;
	}

	public String getAudit_event_name() {
		return audit_event_name;
	}

	public void setAudit_event_name(String audit_event_name) {
		this.audit_event_name = audit_event_name;
	}

	public String getPre_audit_snapshot() {
		return pre_audit_snapshot;
	}

	public void setPre_audit_snapshot(String pre_audit_snapshot) {
		this.pre_audit_snapshot = pre_audit_snapshot;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public LocalDateTime getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(LocalDateTime createdOn) {
		this.createdOn = createdOn;
	}

	public String getModifiedOn() {
		return modifiedOn;
	}

	public void setModifiedOn(String modifiedOn) {
		this.modifiedOn = modifiedOn;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	
	
	
}
