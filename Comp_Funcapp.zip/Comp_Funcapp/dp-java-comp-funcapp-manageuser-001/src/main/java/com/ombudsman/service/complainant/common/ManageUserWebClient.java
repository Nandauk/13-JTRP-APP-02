package com.ombudsman.service.complainant.common;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;

import com.microsoft.graph.models.User;
import reactor.core.publisher.Mono;

@Service
public class ManageUserWebClient {
	
	
	
	private static final String COMPGRAPHAPI_USERS = "/compgraphapi/users/";
	private static final String EXTENSION = "extension_";
	private static final String IS_ACCOUNT_ACTIVE = "_isAccountActive";
	private static final String SUCCESS = "Success";
	
	private static final String apimUrl=System.getenv("APIM_HOST");
	private static final String appRegClientId=System.getenv("B2C_EXTENTION_APP_CLIENTID");

	Logger logger = LogManager.getRootLogger();
		
	public String deleteUserfromB2C(String userId) {
		logger.info("deleteUserfromB2C APIM call started ");
		
		String url = apimUrl+ COMPGRAPHAPI_USERS + userId;
		
		try {
			WebClient.create().delete().uri(url)
					.accept(MediaType.APPLICATION_JSON).retrieve().bodyToMono(User.class).block();
			logger.info(String.format("deleteUserfromB2C userdata deleted for OID %s ",  userId));
		} catch (WebClientResponseException e) {
			logger.error("API call failed: {}",  e.getMessage());
			return "Unable to delete User";
		}
		logger.info("deleteUserfromB2C APIM call ended ");
		return "User deleted Successfully from Azure";

	}

	
	public String updateUserinB2C(User userAction,String userId) {

		logger.info("updateUserinB2C APIM call started ");
		String url = apimUrl + COMPGRAPHAPI_USERS + userId;
		try {
			logger.info(String.format("UpdateUserinB2C APIM userdata inside try %s", userAction));
			return WebClient.create().patch().uri(url)
					.body(Mono.just(userAction), User.class).accept(MediaType.APPLICATION_JSON).retrieve()
					.bodyToMono(String.class).block();
			
		} catch (WebClientResponseException e) {
			logger.error("API call failed: {}" , e.getMessage());
			return null;
		}
	}
		
		
		public User getUserData(String businessEmailId) {
//			tested GET Url without token : https://apim-dev2.financial-ombudsman.org.uk/respgraphapi/users?$filter=mail eq 'asrivastava1@fos.org.uk'
			logger.info("getUserData APIM call started ");
			User userdata ;

			String url = apimUrl +"/compgraphapi/users?$filter=mail eq '" + businessEmailId + "'";
			try {
				userdata = WebClient.create().get().uri(url)
//						.headers(httpHeaders -> httpHeaders.set(AUTHORIZATION, BEARER + userbean.getAuthToken()))
						.accept(MediaType.APPLICATION_JSON).retrieve().bodyToMono(User.class).block();
				logger.info("Completed webclient call");
			} catch (WebClientResponseException e) {
				logger.error("API call failed: {}" , e.getMessage());
				 userdata = null;
			}
			logger.info("getUserData APIM call ended ");
			return userdata;

		}
		
		public String setIsAccountStatus(String oidOfUser, boolean value) {
			logger.info("setIsAccountStatus started ");
			JSONObject obj = new JSONObject();
			obj.put(EXTENSION+ appRegClientId + IS_ACCOUNT_ACTIVE, value);
			
			try {
				
				String activeAccountUrl = apimUrl +COMPGRAPHAPI_USERS + oidOfUser ;
				logger.info(String.format("setIsAccountStatus URL : %s ", activeAccountUrl));

//				webclient call to update MFAmethods to make it null 
				Object activeAccountUpdate = WebClient.create().patch().uri(activeAccountUrl).accept(MediaType.APPLICATION_JSON)
				.body(Mono.just(obj), JSONObject.class).accept(MediaType.APPLICATION_JSON).retrieve()
				.bodyToMono(Object.class).block();

				logger.info(String.format("setIsAccountStatus Method Ended %s ",activeAccountUpdate));

			} catch (Exception e) {
				logger.info(String.format("Error in setIsAccountStatus Method %s ",e.getMessage()));
				return "Failed";
			}
			logger.info("setIsAccountStatus Ended ");

			return SUCCESS;
		}
		

	
}
