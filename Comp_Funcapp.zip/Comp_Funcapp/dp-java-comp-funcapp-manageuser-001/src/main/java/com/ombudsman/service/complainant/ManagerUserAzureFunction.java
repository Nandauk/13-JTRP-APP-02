package com.ombudsman.service.complainant;

import java.beans.Transient;
import java.io.IOException;
import java.util.List;
import java.util.UUID;

import org.apache.commons.collections.CollectionUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Component;

import com.azure.messaging.servicebus.ServiceBusException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.microsoft.azure.functions.ExecutionContext;
import com.microsoft.azure.functions.annotation.FunctionName;
import com.microsoft.azure.functions.annotation.ServiceBusQueueTrigger;
import com.ombudsman.service.complainant.common.ManageUserWebClient;
import com.ombudsman.service.complainant.common.PhoenixUpdate;
import com.ombudsman.service.complainant.dao.ManageUserDataAccess;
import com.ombudsman.service.complainant.helper.AuditEventHelper;
import com.ombudsman.service.complainant.model.AuditEventRequest;
import com.ombudsman.service.complainant.model.Contact;
import com.ombudsman.service.complainant.model.DeleteUserRequest;
import com.ombudsman.service.complainant.model.GenericResponse;
import com.ombudsman.service.complainant.repository.AuditEventRepository;
import com.ombudsman.service.complainant.repository.JDBCConnectionUtil;

@Component
public class ManagerUserAzureFunction {

	Logger logger = LogManager.getRootLogger();

	final ManageUserDataAccess manageUserDataAccess = new ManageUserDataAccess();
	final ManageUserWebClient manageUserWebClient = new ManageUserWebClient();
	//final GenericResponse genericResponse = new GenericResponse();
	final JdbcTemplate jdbcConnection = JDBCConnectionUtil.getJdbcConnection();
	final AuditEventHelper auditEventHelper = new AuditEventHelper();
	final AuditEventRepository auditEventRepository = new AuditEventRepository();
	final PhoenixUpdate phoenixUpdate = new PhoenixUpdate();
	final NamedParameterJdbcTemplate namedJdbcTemplate = JDBCConnectionUtil.getNamedParameterJdbcConnection();

	@FunctionName("disableUserFunction")
	@Transient(true)

	public void disableUserFunction(

			@ServiceBusQueueTrigger(name = "message", queueName = "%QueueNameDisableUser%", connection = "AzureWebJobsServiceBus") String message,
			final ExecutionContext context) throws IOException, ServiceBusException, InterruptedException {

		logger.info("disableUserFunction Azure Fuction Started. {}", message);
        
		ObjectMapper mapper = new ObjectMapper();
		Contact contactMessage = mapper.readValue(message, Contact.class);
		logger.info("scope {}", contactMessage);

		String contactId = contactMessage.getContactId();
		int stateCode = contactMessage.getStatecode();
		
		logger.info("Contactid {} and statCode   {}", contactId,stateCode);

		AuditEventRequest getAuditEvent = auditEventHelper.createAuditEventRequest(contactId);
		auditEventRepository.createAuditEventRecord(getAuditEvent, jdbcConnection);

		logger.info("Calling getAdOidByContactId to get the user id ");
		final UUID adOid = manageUserDataAccess.getAdOidByContactId(contactId, jdbcConnection);
		
		logger.info("adOid is{} ", adOid);

		if (adOid != null) {
			logger.info("Calling setIsAccountStatus to disable the user in Azure AD and user id :{} ", adOid);
			String adResponse = manageUserWebClient.setIsAccountStatus(adOid.toString(), false);
			logger.info("Response by setIsAccountStatus method is:   {}", adResponse);

			logger.info("Calling updateUserById Method to update the user details ");
			manageUserDataAccess.updateUserById(adOid, jdbcConnection);

		}

		if (stateCode == 1) {
			logger.info("Calling userDetailUpdateInPNXMethod to update the user details as statecode is 1 ");
			phoenixUpdate.userDetailUpdateInPNXMethod(contactId);
		}
		
			

	}

	@FunctionName("deleteUserFunction")
	@Transient(true)
	public void deleteUserFunction(
			@ServiceBusQueueTrigger(name = "message", queueName = "%QueueNameDeleteUser%", connection = "AzureWebJobsServiceBus") String message,
			final ExecutionContext context) throws IOException {

		logger.info("DeleteUserFunction Started. {}", message);

		ObjectMapper mapper = new ObjectMapper();
		DeleteUserRequest auditIdMessage = mapper.readValue(message, DeleteUserRequest.class);
		logger.info("scope {}", auditIdMessage);

		String auditId = auditIdMessage.getAuditid();
		logger.info("Audit id  is  {}", auditId);

		final List<UUID> contactId = manageUserDataAccess.getAdOidByAuditId(auditId, namedJdbcTemplate);
		logger.info("Contact id size is  {}", contactId.size());

		
		if (CollectionUtils.isNotEmpty(contactId)) {
			
		final List<UUID> adUserId = manageUserDataAccess.getOidByContactId(contactId, namedJdbcTemplate);
		logger.info("Azure User id size is  {}", adUserId.size());
		
		if (CollectionUtils.isNotEmpty(contactId)) {
			
		for (UUID userId : adUserId) {
			String userOid = userId.toString();

			logger.info("calling deleteUserfromB2C method to delete the user in AD ");
			manageUserWebClient.deleteUserfromB2C(userOid);
			logger.info("Response by deleteUserfromB2C ");

		}
		}

		logger.info("calling deleteCompContactId method delete the user in DB ");
		manageUserDataAccess.deleteCompContactId(contactId, namedJdbcTemplate);
		logger.info("Response by deleteCompContactId ");

		logger.info("calling updateAuditById method to update Audit table ");
		manageUserDataAccess.updateAuditById(contactId, namedJdbcTemplate);

	}
	}

}
