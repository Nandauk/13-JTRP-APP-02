package com.ombudsman.service.complainant.helper;

import java.util.UUID;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Service;
import com.ombudsman.service.complainant.common.ManageUserWebClient;


@Service
public class DisableUserInADHelper {

	Logger log = LogManager.getRootLogger();
	
	
	ManageUserWebClient manageUserWebClient = new ManageUserWebClient();
	
	

	public void disableUser(UUID adOid) {

		try {

			 manageUserWebClient.setIsAccountStatus(adOid.toString(), false);
			 
					
			
		} catch (Exception e) {
			log.error("Error while updating user in Azure AD through graph API::{}", e.getMessage());
		}

	}
	
	
	
}
