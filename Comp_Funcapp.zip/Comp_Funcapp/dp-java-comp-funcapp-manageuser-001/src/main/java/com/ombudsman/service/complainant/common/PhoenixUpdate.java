package com.ombudsman.service.complainant.common;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import com.ombudsman.service.complainant.exception.PhoenixServiceException;

import okhttp3.HttpUrl;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;


public class PhoenixUpdate {
	
	Logger log = LogManager.getRootLogger();
	
	private static final String UPDATE_INVITE_STATUSIN_PNX = "updateInviteStatusinPnx";
	private static final String CONTACTS = "contacts";
	private static final int TWO_ZERO_FOUR = 204;
	private static final String apimUrl=System.getenv("APIM_HOST");
	
	
	public Request getPhoenixRequestBuild(String httpUrl,RequestBody body1) {
		return new Request.Builder().url(httpUrl)
				.addHeader("Content-Type", "application/json").addHeader("OData-MaxVersion", "4.0")
				.addHeader("OData-Version", "4.0")
				//.addHeader("Authorization", "Bearer " + accessToken)
				.patch(body1)
				.build();
	}
	
	
	
	
	/**
	 * 
	 * @return the response code.
	 * 
	 */
	// Code Changes for PBI:4005/4004 Started
	public int updatePhoenixEntity(String entity,String guid,String jsonBody, String path) {
		Response response;
				
		try {

			log.info("Entering to updatePhoenixEntity method");

			OkHttpClient client = new OkHttpClient();

			MediaType mediaType = MediaType.parse("application/json; charset=utf-8");
			String apimUrlforPnx = apimUrl;
			log.info(String.format("phoenix host  : %s", apimUrlforPnx));
			String cleanHost = apimUrlforPnx.replaceFirst("^https?://", "");
			log.info(String.format("phoenix clean host: %s", cleanHost));


			String httpUrl = new HttpUrl.Builder()
			        .scheme("https")
			        .host(cleanHost)
			        .addPathSegment("phoenixapimp")
			        .addPathSegment(entity + "(" + guid + ")")
			        .addPathSegment(path)
			        .build()
			        .toString();

			log.info(String.format("phoenix update URL : %s", httpUrl));
			@SuppressWarnings("deprecation")
			RequestBody body1 = RequestBody.create(mediaType, jsonBody);
			log.info(String.format("phoenix update body : %s", body1));
			Request request = getPhoenixRequestBuild(httpUrl,body1);
			log.info(String.format("phoenix request body : %s", request));
			response = client.newCall(request).execute();
			log.info(String.format("update pnx method response code : %s", response.code()));
			log.info("updatePhoenixEntity Method Sucess");
			return(response.code());
		} catch (Exception e) {
			throw new PhoenixServiceException("Phoenix error ",e.getMessage(), e.getStackTrace());
		}
		
	} 
	
	public void userDetailUpdateInPNXMethod(String contactId) {
		log.info(String.format("UserDetailUpdateInPNXMethod Method started {}", contactId));

		try {

			String updateJSON = null;
			int responseCode = 0;
			//String contactId = userComplainantRepository.fetchContactIdByOid(request.getUserId());
			log.info(String.format("UserDetailUpdateInPNXMethod:: contact Id : %s ", contactId));
			
			updateJSON = String.format("{\"fos_digitalportalinvitestatus\":140000006 }");
			log.info(String.format("UserDetailUpdateInPNXMethod:: jsonForAdStatus %s ", updateJSON));

			responseCode = updatePhoenixEntity(CONTACTS, contactId, updateJSON, UPDATE_INVITE_STATUSIN_PNX);
			log.info(String.format("Phoenix update response code: %d", responseCode));
			


				if (responseCode == TWO_ZERO_FOUR) {
					
					log.info("Data Updated in PNX successfully");
				} else {
					
					log.warn("Data Updation failed in PNX.");
				}

			
		} catch (Exception e) {
			log.info(String.format("UserDetailUpdateInPNXMethod Method  %s", e.getMessage().toString()));
			throw new PhoenixServiceException("Phoenix conectivity error occured  inside UserDetailUpdateInPNXMethod method ",e.getMessage(), e.getStackTrace());
		}
		log.info("UserDetailUpdateInPNXMethod Method ended ");

	}
	
	
	

}
