package com.ombudsman.service.complainant.exception;

public class AzureServiceException extends ComplainantServiceExceptions {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	

	public AzureServiceException(String message,String exceptionMessage,StackTraceElement[] stackTrace) {
		super(message, "COMPALINANT_AZURE_1000",exceptionMessage,stackTrace);
	}
}
