package com.ombudsman.service.complainant.model;

import java.util.List;

public class DeleteUserRequest {
	
	String auditid;

	public String getAuditid() {
		return auditid;
	}

	public void setAuditid(String auditid) {
		this.auditid = auditid;
	}

	
	
	

}
