package com.ombudsman.service.communication.common;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ombudsman.service.communication.exception.UnAuthorisedException;
import com.ombudsman.service.communication.model.response.GenericResponse;


@Component
public class ValidateUserSession {
	private static final String TRUE = "true";
	private static final String FALSE = "false";
	private static final String INVALID_SESSION = "invalid user session";
	public static final String VALID="valid";
	
	@Autowired
	CommonUtil commonUtil;
	@Autowired
	SessionWebClient manageUserWebClient;
	
	public boolean isValidSession() throws UnAuthorisedException {

		Logger log = LogManager.getRootLogger();

		try {
			final String sessionFlag = commonUtil.sessionFlag;
			GenericResponse tokenStatus;
			if (TRUE.equalsIgnoreCase(sessionFlag)) {
				tokenStatus = manageUserWebClient.getResponseForSessionActivity();
				log.info("Token Status:: {} when session flag::{}", format(tokenStatus.getStatus()), format(sessionFlag));				
				if (VALID.equalsIgnoreCase(tokenStatus.getStatus())) {					
					return true;
				} else {
					log.info("Token status:{}",format(tokenStatus.getStatus()));
					throw new UnAuthorisedException(INVALID_SESSION);
				}
			}
			if (FALSE.equalsIgnoreCase(sessionFlag)) {				
				return false;
			}

		} catch (Exception e) {
			log.error("Error while validating user session::{}",e.getMessage());
			throw new UnAuthorisedException(INVALID_SESSION);
		}
		return false;
	}
	private String format(String original) {
		String clean = original.replace('\n', '_').replace('\r', '_');
		StringBuilder sb = new StringBuilder(clean);
		return sb.toString();
	}

}