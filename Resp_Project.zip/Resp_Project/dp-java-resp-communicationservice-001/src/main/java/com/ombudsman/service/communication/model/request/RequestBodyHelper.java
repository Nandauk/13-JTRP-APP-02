package com.ombudsman.service.communication.model.request;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ombudsman.service.communication.common.CommonUtil;
import com.ombudsman.service.communication.exception.InputValidationException;

@Service
public class RequestBodyHelper {
	
	@Autowired
	CommonUtil commonUtil;
	
	private static final String REQUEST_INVALID = "Request Body format is incorrect!!";
	
	Logger LOG = LogManager.getRootLogger();
	private static final boolean TRUE = true;
	
	public SendMailReq contructSendEmailBody(UserMailjetRequest inviteRequest){
		LOG.info("contructSendEmailBody method started ");
		
		if(!validateInviteRequest(inviteRequest)) 
			throw new InputValidationException(REQUEST_INVALID, "RESPONDENT_USER_1000", null, null);
		
		
		List<To> to = new ArrayList<>(); 
		To toEmailAddress = new To(); 
		toEmailAddress.setToEmail(inviteRequest.getEmailId());
		toEmailAddress.setToName(inviteRequest.getFullName());
		to.add(toEmailAddress);
		
		Messages message = new Messages();
		message.setTemplateID(inviteRequest.getTemplateId());
		message.setName(inviteRequest.getTemplateName());
		LOG.info("-----TemplateID and templateName set Inside helper method successfully----");
		message.setTemplateLanguage(TRUE);
		message.setTo(to);
		
		From fromEmailAddress = new From();
		fromEmailAddress.setFromEmail(commonUtil.MAILJET_FROM_EMAIL);
		fromEmailAddress.setFromName(commonUtil.MAILJET_SERVER_NAME);
		message.setFrom(fromEmailAddress);

		MailjetVariables var = new MailjetVariables();
		
		setIfNotEmpty(inviteRequest.getIssuerEmailID(), var::setIssuerEmailID);
		setIfNotEmpty(inviteRequest.getIssuerAccount(), var::setIssuerAccount);
		
		
		var.setPortalSigninUrl(inviteRequest.getSendInviteUrl()); //will be picked env wise
//		var.setPortalSigninUrl(commonUtil.PORTAL_SIGN_IN);
		LOG.info("getPortalSigninUrl invite Url %s ", var.getPortalSigninUrl());
		
		message.setVar(var);
		List<Messages> sendmessage = new ArrayList<>();
		sendmessage.add(message);
		SendMailReq sendMailReq = new SendMailReq();
		sendMailReq.setMessages(sendmessage);
		
		LOG.info("contructSendEmailBody method ended ");
		return sendMailReq;
			
	}
	
public boolean validateInviteRequest(UserMailjetRequest inviteRequest) {
		
		return (commonUtil.isValidEmailInput(inviteRequest.getEmailId())
				&& commonUtil.isValidNameInput(StringUtils.trim(inviteRequest.getFullName())) 
				&& commonUtil.isValidNumeric(String.valueOf(inviteRequest.getTemplateId()))
				&& commonUtil.isValidNameInput(inviteRequest.getTemplateName()));	
	
    }
	
public void setIfNotEmpty(String variableValue, Consumer<String> setter ) {
	if(!StringUtils.trimToEmpty(variableValue).isEmpty()) {
		setter.accept(variableValue); 	
		LOG.info("Value successfully set under variables " + variableValue );
	}else {
		LOG.info("Value fialed to set  under variables " + variableValue );
	}
}

}
