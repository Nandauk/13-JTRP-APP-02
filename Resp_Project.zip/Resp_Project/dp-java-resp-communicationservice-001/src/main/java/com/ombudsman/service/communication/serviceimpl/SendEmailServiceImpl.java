package com.ombudsman.service.communication.serviceimpl;

import java.io.UnsupportedEncodingException;
import java.text.ParseException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.WebClient;

import com.google.gson.Gson;
import com.ombudsman.service.communication.common.CommonUtil;
import com.ombudsman.service.communication.exception.InputValidationException;
import com.ombudsman.service.communication.exception.MailJetServiceException;
import com.ombudsman.service.communication.model.request.RequestBodyHelper;
import com.ombudsman.service.communication.model.request.SendMailReq;
import com.ombudsman.service.communication.model.request.UserMailjetRequest;
import com.ombudsman.service.communication.model.response.EmailNotificationResponse;
import com.ombudsman.service.communication.model.response.MailjetResponseBody;

@Service
public class SendEmailServiceImpl {

	private static final boolean TRUE = true;

	@Autowired
	CommonUtil commonUtil;
	
	@Autowired
	RequestBodyHelper requestBodyHelper;
		
	private static final String RESPONSE_IS_NULL = "Response is null";
	
	Logger LOG = LogManager.getRootLogger();

	public EmailNotificationResponse sendInviteEmail(UserMailjetRequest inviteRequest) throws InputValidationException, UnsupportedEncodingException, ParseException, JSONException, MailJetServiceException {
		
		LOG.info("sendInviteEmail method started");
		EmailNotificationResponse result = new EmailNotificationResponse();
		
		MailjetResponseBody response = new MailjetResponseBody();
		
		SendMailReq sendMailReq = new SendMailReq();
		
		LOG.info("Inside sendInviteEmail impl method {}");
	 	
						
		sendMailReq = requestBodyHelper.contructSendEmailBody(inviteRequest); 
						
		response = send(sendMailReq);
						
		LOG.info("Response received from SEND method {}", response);
		
			String status = response.getMessages().get(0).getStatus();
			if(status.equals("success")) {
				LOG.info("MailJet API call success ");
				result.setStatus(status);
				result.setMessage("MailJet API call success :{}");
			}else {
				LOG.info("MailJet API call failed ");
				result.setStatus(status);
				result.setMessage("MailJet API call failed :{}");
			}
		
		LOG.info("sendInviteEmail method ended ");
		return result;
	}

	public EmailNotificationResponse sendCaseListEmail(UserMailjetRequest inviteRequest) throws InputValidationException, UnsupportedEncodingException, ParseException, JSONException, MailJetServiceException {
		
		LOG.info("Inside sendCaseListEmail impl method {}");
		
		EmailNotificationResponse result = new EmailNotificationResponse();
		
		MailjetResponseBody response = new MailjetResponseBody();
		
		SendMailReq sendMailReq = new SendMailReq();
			
		sendMailReq = requestBodyHelper.contructSendEmailBody(inviteRequest);
		
		response = send(sendMailReq);
		
		LOG.info("Response received from SEND method {}");
			String status = response.getMessages().get(0).getStatus();
			if(status.equals("success")) {
				result.setStatus(status);
				result.setMessage("MailJet API call success : {}");
			}else {
				result.setStatus(status);
				result.setMessage("MailJet API call failed : {}");
			}
		
			
		return result;
	}

public MailjetResponseBody send(SendMailReq req) throws UnsupportedEncodingException, JSONException, ParseException, MailJetServiceException {
		
		LOG.info("Mailjet Send request method started");
		Gson gson = new Gson();
		String json = gson.toJson(req);
		LOG.info("Mailjet Send request : %s",json);
		MailjetResponseBody responseBody = new MailjetResponseBody() ;
		
		try {
			responseBody = WebClient.create()
					  .post().uri(commonUtil.mailjetApimUrl)
					  .body(BodyInserters.fromValue(json)).accept(MediaType.APPLICATION_JSON).retrieve().bodyToMono(MailjetResponseBody.class).block();
			LOG.info("Response from mailjet webclient is : {}", responseBody);
			if(responseBody!=null) {
				String status = responseBody.getMessages().get(0).getStatus();
			}else {
				LOG.info("No response retrieved from Mailjet API : {}");
			}
		}catch(Exception ex) {
			LOG.info("Mailjet Webclient call failed " + ex);
			throw new MailJetServiceException("Mailjet Webclient call failed :");
	
		}
		
				
		return responseBody;

	}

	

}
