package com.ombudsman.service.communication.exception;

import java.time.LocalDateTime;
import java.util.Locale;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.HttpMediaTypeNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;
import org.springframework.web.servlet.NoHandlerFoundException;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.ombudsman.service.communication.common.UserBean;

import jakarta.validation.ConstraintViolationException;

import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.LogManager;

@ControllerAdvice
public class GobalExceptionHandler extends ResponseEntityExceptionHandler {

	private static final String API_ERROR_MESSAGENOTREADABLE = "api.error.messagenotreadable";



	private static final String API_ERROR_EXCEPTIONMSG = "api.error.exceptionmsg";



	private static final String RESPONDENT_1002 = "RESPONDENT_1002";



	private static final String ERROR_IN_OID_CUSTOM_ERROR_MESSAGE = "Error Code:- {} OID:-{} Error Description:-{} Stack Trace:-{} CorrelationId:-{}";



	@Autowired
	UserBean userbean;

	

	@Autowired
	private MessageSource messageSource;
	
	Logger LOG =  LogManager.getRootLogger();

	
	public ResponseEntity<Object> handleHttpMediaTypeNotSupported(HttpMediaTypeNotSupportedException ex) {

		

		ApiError err = new ApiError(LocalDateTime.now(), HttpStatus.BAD_REQUEST,
				messageSource.getMessage(API_ERROR_MESSAGENOTREADABLE, null, Locale.ENGLISH),RESPONDENT_1002);
		

		LOG.error(ERROR_IN_OID_CUSTOM_ERROR_MESSAGE, RESPONDENT_1002,
				userbean.getUserObjectId(), ex.getMessage(),ex.getStackTrace(),userbean.getCorrelationId());


		return ResponseEntityBuilder.build(err);

	}

	// handleHttpMessageNotReadable : triggers when the JSON is malformed
	
	public ResponseEntity<Object> handleHttpMessageNotReadable(HttpMessageNotReadableException ex) {

		ApiError err = new ApiError(LocalDateTime.now(), HttpStatus.BAD_REQUEST,
				messageSource.getMessage(API_ERROR_MESSAGENOTREADABLE, null, Locale.ENGLISH) ,RESPONDENT_1002);
		
		LOG.error(ERROR_IN_OID_CUSTOM_ERROR_MESSAGE, RESPONDENT_1002,
				userbean.getUserObjectId(),ex.getMessage(),ex.getStackTrace(),userbean.getCorrelationId());

		return ResponseEntityBuilder.build(err);
	}

	// handleMethodArgumentsNotValid: triggers when @Valid fails

	
	public ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException ex) {


		String message = messageSource.getMessage(API_ERROR_EXCEPTIONMSG, null, Locale.ENGLISH);
		ApiError err = new ApiError(LocalDateTime.now(), HttpStatus.BAD_REQUEST, message,RESPONDENT_1002
				);

		LOG.error(ERROR_IN_OID_CUSTOM_ERROR_MESSAGE, RESPONDENT_1002,
				userbean.getUserObjectId(), ex.getMessage(),ex.getStackTrace(),userbean.getCorrelationId());

		return ResponseEntityBuilder.build(err);
	}

	// handleMissingServletRequestParameter: triggers when there are missing
	// parameters

	
	public ResponseEntity<Object> handleMissingServletRequestParameter(MissingServletRequestParameterException ex) {


		ApiError err = new ApiError(LocalDateTime.now(), HttpStatus.BAD_REQUEST, messageSource.getMessage(API_ERROR_MESSAGENOTREADABLE, null, Locale.ENGLISH),
				RESPONDENT_1002);
		
		LOG.error(ERROR_IN_OID_CUSTOM_ERROR_MESSAGE, RESPONDENT_1002,
				userbean.getUserObjectId(), ex.getMessage(),ex.getStackTrace(),userbean.getCorrelationId());

		
		return ResponseEntityBuilder.build(err);
	}

	// handleMethodArgumentsTypeMismatch: triggers when a parameter's type does not
	// match
	@ExceptionHandler(MethodArgumentTypeMismatchException.class)
	public ResponseEntity<Object> handleMethodArgumentTypeMismatch(MethodArgumentTypeMismatchException ex,
			WebRequest request) {


		String message = messageSource.getMessage(API_ERROR_EXCEPTIONMSG, null, Locale.ENGLISH);
		ApiError err = new ApiError(LocalDateTime.now(), HttpStatus.BAD_REQUEST,message, RESPONDENT_1002
				);
		
		
		LOG.error(ERROR_IN_OID_CUSTOM_ERROR_MESSAGE, RESPONDENT_1002,
				userbean.getUserObjectId(), ex.getMessage(),ex.getStackTrace(),userbean.getCorrelationId());

		
		return ResponseEntityBuilder.build(err);

	}

	@ExceptionHandler(InterruptedException.class)
	public ResponseEntity<Object> handleInterruptedExceptionException(Exception ex) {

		String message = messageSource.getMessage(API_ERROR_EXCEPTIONMSG, null, Locale.ENGLISH);
		ApiError err = new ApiError(LocalDateTime.now(), HttpStatus.BAD_REQUEST,message, RESPONDENT_1002
				);

		LOG.error(ERROR_IN_OID_CUSTOM_ERROR_MESSAGE, RESPONDENT_1002,
				userbean.getUserObjectId(), ex.getMessage(),ex.getStackTrace(),userbean.getCorrelationId());

		
		return ResponseEntityBuilder.build(err);

	}

	// handleConstraintViolationException: triggers when @Validates fails
	@ExceptionHandler(ConstraintViolationException.class)
	public ResponseEntity<Object> handleConstraintViolationException(Exception ex, WebRequest request) {


		String message = messageSource.getMessage(API_ERROR_EXCEPTIONMSG, null, Locale.ENGLISH);
		ApiError err = new ApiError(LocalDateTime.now(), HttpStatus.BAD_REQUEST,message, RESPONDENT_1002
				);
		LOG.error(ERROR_IN_OID_CUSTOM_ERROR_MESSAGE, RESPONDENT_1002,
				userbean.getUserObjectId(),ex.getMessage(),ex.getStackTrace(),userbean.getCorrelationId());

		
		return ResponseEntityBuilder.build(err);

	}

	// handleResourceNotFoundException: triggers when there is not resource with the
	// specified ID in BDD
	@ExceptionHandler(ResourceNotFoundException.class)
	public ResponseEntity<Object> handleResourceNotFoundException(ResourceNotFoundException ex) {

		String message = messageSource.getMessage(API_ERROR_EXCEPTIONMSG, null, Locale.ENGLISH);
		ApiError err = new ApiError(LocalDateTime.now(), HttpStatus.NOT_FOUND,
				message, "RESPONDENT_1004");
		
		LOG.error(ERROR_IN_OID_CUSTOM_ERROR_MESSAGE, RESPONDENT_1002,
				userbean.getUserObjectId(), ex.getMessage(),ex.getStackTrace(),userbean.getCorrelationId());

		return ResponseEntityBuilder.build(err);

	}

	// handleNoHandlerFoundException: triggers when the handler method is invalid
	
	public ResponseEntity<Object> handleNoHandlerFoundException(NoHandlerFoundException ex) {


		ApiError err = new ApiError(LocalDateTime.now(), HttpStatus.BAD_REQUEST, "", ex.getMessage());
		
		LOG.error(ERROR_IN_OID_CUSTOM_ERROR_MESSAGE, RESPONDENT_1002,
				userbean.getUserObjectId(), ex.getMessage(),ex.getStackTrace(),userbean.getCorrelationId());

		
		return ResponseEntityBuilder.build(err);

	}

	@ExceptionHandler(RespondentsServiceExceptions.class)
	public ResponseEntity<Object> handleRespondentsServiceExceptions(RespondentsServiceExceptions respondentsServiceExceptions) {


		ApiError err = new ApiError(LocalDateTime.now(), HttpStatus.BAD_REQUEST, respondentsServiceExceptions.getMessage(),respondentsServiceExceptions.getCode()
				);

		LOG.error(ERROR_IN_OID_CUSTOM_ERROR_MESSAGE, respondentsServiceExceptions.getCode(),
				userbean.getUserObjectId(), respondentsServiceExceptions.getExceptionMessage(),respondentsServiceExceptions.getStackTrace(),userbean.getCorrelationId());

		
		return ResponseEntityBuilder.build(err);

	}
	
	@ExceptionHandler(InputValidationException.class)
	public ResponseEntity<Object> handleExceptionInputInvalid(InputValidationException inputValidationException) {


		ApiError err = new ApiError(LocalDateTime.now(), HttpStatus.BAD_REQUEST,inputValidationException.getMessage(), inputValidationException.getCode()
				);;

		LOG.error(ERROR_IN_OID_CUSTOM_ERROR_MESSAGE, inputValidationException.getCode(),
				userbean.getUserObjectId(), inputValidationException.getExceptionMessage(),inputValidationException.getStackTrace(),userbean.getCorrelationId());

		
		return ResponseEntityBuilder.build(err);

	}

	@ExceptionHandler({ Exception.class })
	public ResponseEntity<Object> handleException(Exception e) {


		String message = messageSource.getMessage(API_ERROR_EXCEPTIONMSG, null, Locale.ENGLISH);
		ApiError err = new ApiError(LocalDateTime.now(), HttpStatus.BAD_REQUEST,
				message,"RESPONDENT_1004");
		
		LOG.error(ERROR_IN_OID_CUSTOM_ERROR_MESSAGE, "RESPONDENT_1004",
				userbean.getUserObjectId(), e.getMessage(),e.getStackTrace(),userbean.getCorrelationId());

		
		return ResponseEntityBuilder.build(err);
	}
	
	@ExceptionHandler({MailJetServiceException.class})
	public ResponseEntity<Object> handleMailjetException(MailJetServiceException e){
		
		
		ApiError err = new ApiError(LocalDateTime.now(), HttpStatus.BAD_GATEWAY,
				e.getMessage(),"RESPONDENT_1004");

		LOG.error(ERROR_IN_OID_CUSTOM_ERROR_MESSAGE, "RESPONDENT_1004",
				userbean.getUserObjectId(), e.getMessage(),e.getStackTrace(),userbean.getCorrelationId());

		
		return ResponseEntityBuilder.build(err);
	}


	
}
