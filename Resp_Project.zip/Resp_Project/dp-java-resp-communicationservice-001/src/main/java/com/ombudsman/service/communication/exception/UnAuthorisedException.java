package com.ombudsman.service.communication.exception;

public class UnAuthorisedException extends Exception {
	
	 private static final long serialVersionUID = 1L;

	  public UnAuthorisedException(String orgName){
			super(orgName);
		}


}
