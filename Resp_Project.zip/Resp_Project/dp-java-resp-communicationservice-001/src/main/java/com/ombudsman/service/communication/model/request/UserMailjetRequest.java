package com.ombudsman.service.communication.model.request;

public class UserMailjetRequest {

	String emailId; 
	String fullName;
	int templateId;
	String templateName;
	String sendInviteUrl;
	
	public String getSendInviteUrl() {
		return sendInviteUrl;
	}

	public void setSendInviteUrl(String sendInviteUrl) {
		this.sendInviteUrl = sendInviteUrl;
	}

	//Mailjet Variables 
	String issuerEmailID;
	String issuerAccount;

	
	public String getIssuerEmailID() {
		return issuerEmailID;
	}

	public void setIssuerEmailID(String issuerEmailID) {
		this.issuerEmailID = issuerEmailID;
	}

	public String getIssuerAccount() {
		return issuerAccount;
	}

	public void setIssuerAccount(String issuerAccount) {
		this.issuerAccount = issuerAccount;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public int getTemplateId() {
		return templateId;
	}

	public void setTemplateId(int templateId) {
		this.templateId = templateId;
	}

	public String getTemplateName() {
		return templateName;
	}

	public void setTemplateName(final String templateName) {
		this.templateName = templateName;
	}

	

}
