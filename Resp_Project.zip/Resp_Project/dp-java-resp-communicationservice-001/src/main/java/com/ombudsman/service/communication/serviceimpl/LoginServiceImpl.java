package com.ombudsman.service.communication.serviceimpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ombudsman.service.communication.common.CommonUtil;
import com.ombudsman.service.communication.common.SessionWebClient;
import com.ombudsman.service.communication.model.response.GenericResponse;
import com.ombudsman.service.communication.service.ILoginService;


@Service
public class LoginServiceImpl implements ILoginService {
	
	@Autowired
	CommonUtil commonUtil;

	@Autowired
	SessionWebClient webClientData;
	

	@Override
	public GenericResponse getSessionTokenStatus() throws Exception {
				
		return webClientData.getResponseForSessionActivity();
	}
	
	

}
