package com.ombudsman.service.communication.service;

import com.ombudsman.service.communication.exception.InputValidationException;
import com.ombudsman.service.communication.model.request.UserMailjetRequest;
import com.ombudsman.service.communication.model.response.EmailNotificationResponse;

import jakarta.validation.Valid;

public interface ISendEmailService {
	public EmailNotificationResponse sendInviteEmail(@Valid UserMailjetRequest request) throws InputValidationException;

	EmailNotificationResponse sendCaseListExport(@Valid UserMailjetRequest inviteRequest) throws InputValidationException;

}
