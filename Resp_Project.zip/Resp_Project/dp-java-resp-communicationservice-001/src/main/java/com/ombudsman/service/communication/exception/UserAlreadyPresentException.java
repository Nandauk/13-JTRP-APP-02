package com.ombudsman.service.communication.exception;

public class UserAlreadyPresentException extends RespondentsServiceExceptions {

	private static final long serialVersionUID = 1L;

	public UserAlreadyPresentException(String message, String exceptionMessage, StackTraceElement[] stackTrace) {
		super(message, "RESPONDENT_USER_1000", exceptionMessage, stackTrace);
	}
}
