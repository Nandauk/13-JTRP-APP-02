package com.ombudsman.service.communication.exception;

public class PhoenixServiceException extends RespondentsServiceExceptions {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public PhoenixServiceException(String message,String exceptionMessage,StackTraceElement[] stackTraceElements) {
		super(message, "RESPONDENT_PHOENIX_1001",exceptionMessage,stackTraceElements);
	}
	
	

}
