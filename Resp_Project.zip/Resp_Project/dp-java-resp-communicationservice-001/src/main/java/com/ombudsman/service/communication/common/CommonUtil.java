/**
 * 
 */
package com.ombudsman.service.communication.common;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.text.ParseException;
import java.time.Instant;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

@Configuration
@Service
public class CommonUtil {

	@Autowired
	UserBean userbean;

	@Autowired
	private MessageSource messageSource;

	@Autowired
	KeyVaultConfiguration keyValutProps;

	@Value("${app.session_base_url}")
	public String sessionBaseUrl;
	
	@Value("${app.mailjet-apim-url}")
	public String mailjetApimUrl;

	@Value("${app.session_flag}")
	public String sessionFlag;
	
	@Value("${emailRegex}")
	public String mlRgx;

	@Value("${app.mj-server-email}")
	public String MAILJET_FROM_EMAIL;
	
	@Value("${app.mj-server-name}")
	public String MAILJET_SERVER_NAME;
	

	
	
	private static final String JWT_HEADER = "{\"alg\":\"HS256\",\"typ\":\"JWT\"}";
	Logger LOG = LogManager.getRootLogger();


	public String getZendeskJwtToken() {
		
		Map<String, Object> header = new HashMap<>();
		String jwtToken1 = new String();
		header.put("typ", "JWT");
		header.put("kid", keyValutProps.zenDeskId);
		if(userbean.getEmail()!= null) {
		String[] extractedName = userbean.getEmail().split("@");
		
		LOG.info("Inside getZendeskJwtToken : extractedName value :" + extractedName );

		jwtToken1 = Jwts.builder().setHeaderParams(header).claim("external_id", extractedName[0])
				.claim("email", userbean.getEmail()).claim("email_verified", true).claim("exp", userbean.getExp())
				.claim("scope", "user").claim("name", userbean.getName())
				.signWith(SignatureAlgorithm.HS256, keyValutProps.zenDeskSecretKeyChatWizard.getBytes()).compact();

		}
		
		LOG.info("Method getZendeskJwtToken ended : {}" );
		
		return jwtToken1;

	}

	public String getZendeskUrlWebForm() throws UnsupportedEncodingException, JSONException, ParseException {
		
		String signature = "";
		String encodedHeader = "";
		JSONObject payload = new JSONObject();
		
		encodedHeader = encode(new JSONObject(JWT_HEADER));
		payload.put("iat", Instant.now().getEpochSecond());
		payload.put("jti", UUID.randomUUID().toString());
		if(userbean != null) {
			payload.put("email", userbean.getEmail());
			payload.put("name", userbean.getName());
		}else {
			LOG.info("Userbean is null : {}" );
		}
		
		String name = userbean.getName();
		int idx = name.lastIndexOf(' ');
		if (idx == -1)
		    throw new IllegalArgumentException("Only a single name: " + name);
		String firstName = name.substring(0, idx);
		String lastName  = name.substring(idx + 1);
		LOG.info("First name extracted : {}", firstName);
		LOG.info("Last name extracted : {}", lastName);
		signature = hmacSha256(encodedHeader + "." + encode(payload), keyValutProps.zenDeskSecretKeyWebForm);
		String resJWT = encodedHeader + "." + encode(payload) + "." + signature;
		
		String redirectUrl = "https://" + keyValutProps.zendeskSubDomainJwt + ".zendesk.com/access/jwt?jwt=" + resJWT;
		
		redirectUrl += "&return_to=" + URLEncoder
				.encode("https://" + keyValutProps.zendeskSubDomain + ".zendesk.com/hc/en-gb/requests/new", "UTF-8");
		
		String preFillForm = redirectUrl+  "?tf_11468471496477="+URLEncoder.encode(firstName, "UTF-8")+"%26tf_11515373781917="+URLEncoder.encode(lastName, "UTF-8");
		
		
		return preFillForm;

	}

	private String hmacSha256(String data, String secret) {
		try {

			byte[] hash = secret.getBytes(StandardCharsets.UTF_8);

			Mac sha256Hmac = Mac.getInstance("HmacSHA256");
			SecretKeySpec secretKey = new SecretKeySpec(hash, "HmacSHA256");
			sha256Hmac.init(secretKey);

			byte[] signedBytes = sha256Hmac.doFinal(data.getBytes(StandardCharsets.UTF_8));
			return encode(signedBytes);
		} catch (NoSuchAlgorithmException | InvalidKeyException ex) {

			return null;
		}
	}

	public boolean isValidEmailInput(String input) {
		String regex = mlRgx;
		Pattern pattern = Pattern.compile(regex);
		Matcher matcher = pattern.matcher(input);
		boolean matches = matcher.matches();
		LOG.info("Input email " + input + " matches " + matches);
		return matches;
	}
	
	public boolean isValidInput(String input) {
		String regex = "^[a-zA-Z0-9-]+$";
		Pattern pattern = Pattern.compile(regex);
		Matcher matcher = pattern.matcher(input);
		return matcher.matches();
	}

	public boolean isValidNameInput(String input) {
		String regex = "^[a-zA-Z0-9-'_%+.\s]+$";
		Pattern pattern = Pattern.compile(regex);
		Matcher matcher = pattern.matcher(input);
		boolean matches = matcher.matches();
		LOG.info("Input Name " + input + " matches " + matches);
		return matches;
	}

	public boolean isValidPhoneInput(String input) {
		String regex = "^[0-9-+]+$";
		Pattern pattern = Pattern.compile(regex);
		Matcher matcher = pattern.matcher(input);
		return matcher.matches();
	}
	
	public boolean isValidNumeric(String input) {
		String regex = "^[0-9]+$";
		Pattern pattern = Pattern.compile(regex);
		Matcher matcher = pattern.matcher(input);
		boolean matches = matcher.matches();
		LOG.info("Input Numeric " + input + " matches " + matches);
		return matches;
	}
	
	private static String encode(JSONObject obj) {
		return encode(obj.toString().getBytes(StandardCharsets.UTF_8));
	}

	private static String encode(byte[] bytes) {
		return Base64.getUrlEncoder().withoutPadding().encodeToString(bytes);
	}

}
