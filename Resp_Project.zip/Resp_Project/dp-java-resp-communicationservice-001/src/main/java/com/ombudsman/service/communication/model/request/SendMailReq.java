package com.ombudsman.service.communication.model.request;


	import java.util.List;

import com.google.gson.annotations.SerializedName;

	   
	public class SendMailReq {

	   @SerializedName("Messages")
	   List<Messages> messages;


	    public void setMessages(List<Messages> messages) {
	        this.messages = messages;
	    }
	    public List<Messages> getMessages() {
	        return messages;
	    }
	    
	}