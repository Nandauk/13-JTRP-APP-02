package com.ombudsman.service.communication.model.request;


import com.google.gson.annotations.SerializedName;

public class MailjetVariables {

	 @SerializedName("issuerEmailID")
	 String issuerEmailID;
	 
	 @SerializedName("issuerAccount")
	 String issuerAccount;
	 
	 @SerializedName("PORTAL_SIGN_IN")
	 String portalSigninUrl;

	public String getPortalSigninUrl() {
		return portalSigninUrl;
	}

	public void setPortalSigninUrl(String portalSigninUrl) {
		this.portalSigninUrl = portalSigninUrl;
	}
	public String getIssuerEmailID() {
		return issuerEmailID;
	}

	public void setIssuerEmailID(String issuerEmailID) {
		this.issuerEmailID = issuerEmailID;
	}

	public String getIssuerAccount() {
		return issuerAccount;
	}

	public void setIssuerAccount(String issuerAccount) {
		this.issuerAccount = issuerAccount;
	}

	
	 
}
