package com.ombudsman.service.communication.common;

import java.util.Arrays;
import java.util.List;

public class Constants {
	
	public static final String MSG_FAILURE="Failure";
	public static final String MSG_SUCCESS="Success";
	public static final String VALID = "valid";
	public static final String CASEWOKER = "CaseWorker";
	public static final String SUPERVISOR = "Supervisor";
	public static final String RESPONDENT_ADMIN = "RespondentAdmin";
	public static final String OMBUDSMAN_ADMIN = "OmbudsmanAdmin";
	public static final List<String> ALL_ROLES =Arrays.asList("Supervisor","CaseWorker","OmbudsmanAdmin","RespondentAdmin"); 
	public static final List<String> RESP_OMBUDS_ROLES = Arrays.asList("OmbudsmanAdmin","RespondentAdmin");
	public static final List<String> SUPERVISOR_CASEWOKER_ROLES = Arrays.asList("Supervisor","CaseWorker");
	
	private Constants() {
	      //not called
	   }
	

}
