package com.ombudsman.service.communication.exception.test;


import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.ombudsman.service.communication.exception.UserAlreadyPresentException;
@ExtendWith(SpringExtension.class)
public class UserAlreadyPresentExceptionTest {
	
	
	 @Test
	   public void testConstructor() {
		 String message = "User already exists";
	        String exceptionMessage = "User with ID 123 already registered";
	        StackTraceElement[] stackTrace = new StackTraceElement[0];

	        UserAlreadyPresentException exception = new UserAlreadyPresentException(message, exceptionMessage, stackTrace);

	      Assertions.assertEquals(message,exception.getMessage());

	      
	    }

}

