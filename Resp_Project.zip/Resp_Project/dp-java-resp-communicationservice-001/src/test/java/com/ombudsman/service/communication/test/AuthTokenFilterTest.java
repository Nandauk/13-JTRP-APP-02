package com.ombudsman.service.communication.test;

import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Date;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.ombudsman.service.communication.AuthTokenFilter;
import com.ombudsman.service.communication.common.UserBean;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletContext;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@ExtendWith(SpringExtension.class)
class AuthTokenFilterTest {

	@InjectMocks
	private AuthTokenFilter authTokenFilter;

	@Mock
	private HttpServletRequest request;

	@Mock
	private HttpServletResponse response;

	@Mock
	private FilterChain filterChain;

	@Mock
	private WebApplicationContext webApplicationContext;
	
	@Mock
	private ServletContext mMockServletContext;

	@Mock
	private UserBean userBean;

	private MockMvc mockMvc;

	@BeforeEach
	public void setup() {
		mockMvc = MockMvcBuilders.standaloneSetup(authTokenFilter).build();
	}

	@Test
	void testDoFilterInternal_ValidToken() throws Exception {
		String token = "Bearer token";
		when(request.getHeader("Authorization")).thenReturn(token);
		when(request.getHeader("Correlation-Id")).thenReturn("correlation-id");

		when(WebApplicationContextUtils.getWebApplicationContext(mMockServletContext)).thenReturn(webApplicationContext);
		when(webApplicationContext.getBean(UserBean.class)).thenReturn(userBean);
		
		Date futureDate = new Date(System.currentTimeMillis() + 100000);
		when(userBean.getCorrelationId()).thenReturn("correlation-id");
		when(request.getServletContext()).thenReturn(mMockServletContext);

		authTokenFilter.doFilterInternal(request, response, filterChain);
		verify(request).getServletContext();

	}

	/*@Test
	void testDoFilterInternal_MissingToken() throws Exception {
		when(request.getHeader("Authorization")).thenReturn(null);

		authTokenFilter.doFilterInternal(request, response, filterChain);

		// Verify filter chain is called without setting user bean values
		verify(filterChain).doFilter(request, response);

	}*/
}
