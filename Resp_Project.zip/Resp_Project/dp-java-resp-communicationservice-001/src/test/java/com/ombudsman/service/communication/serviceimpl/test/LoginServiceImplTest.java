package com.ombudsman.service.communication.serviceimpl.test;


import static org.junit.jupiter.api.Assertions.assertSame;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.ombudsman.service.communication.common.CommonUtil;
import com.ombudsman.service.communication.common.SessionWebClient;
import com.ombudsman.service.communication.model.response.GenericResponse;
import com.ombudsman.service.communication.serviceimpl.LoginServiceImpl;



@ExtendWith(SpringExtension.class)
public class LoginServiceImplTest{

	@InjectMocks
	LoginServiceImpl LoginServiceImpl;
	
	@Mock
	SessionWebClient webClientData;

	@Mock
	CommonUtil commonUtil;
	
	@Mock
	GenericResponse genericResponse;
	
	
	@DisplayName("getSessionTokenStatusTest")
	@Test
	public void getSessionTokenStatusTest() throws Exception {
		
		GenericResponse response = new GenericResponse();
		response.setMessage("Success");
		response.setStatus("VALID");
		Mockito.when(webClientData.getResponseForSessionActivity()).thenReturn(response);
		genericResponse = LoginServiceImpl.getSessionTokenStatus();
		assertSame("Success", genericResponse.getMessage());
		assertSame("VALID", genericResponse.getStatus());
	}

}
