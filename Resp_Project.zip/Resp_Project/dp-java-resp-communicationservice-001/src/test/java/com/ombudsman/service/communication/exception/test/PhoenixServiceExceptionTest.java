package com.ombudsman.service.communication.exception.test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import com.ombudsman.service.communication.exception.PhoenixServiceException;

@ExtendWith(SpringExtension.class)
public class PhoenixServiceExceptionTest {

	 @Test
	    void testConstructor() {
	        String message = "Test Message";
	        String exceptionMessage = "Test Exception Message";
	        StackTraceElement[] stackTraceElements = Thread.currentThread().getStackTrace();

	        PhoenixServiceException ex = new PhoenixServiceException(message, exceptionMessage, stackTraceElements);

	        assertEquals(message, ex.getMessage());
	    }
}

