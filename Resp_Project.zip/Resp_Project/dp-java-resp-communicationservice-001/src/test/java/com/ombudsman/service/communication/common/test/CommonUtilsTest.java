package com.ombudsman.service.communication.common.test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.text.ParseException;
import java.time.Instant;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.json.JSONException;
import org.json.JSONObject;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.util.ReflectionTestUtils;

import com.ombudsman.service.communication.common.CommonUtil;
import com.ombudsman.service.communication.common.KeyVaultConfiguration;
import com.ombudsman.service.communication.common.UserBean;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

@ExtendWith(SpringExtension.class)
public class CommonUtilsTest {

	@InjectMocks
	CommonUtil commonUtil;
	
	@Mock
	UserBean userbean;
	
	@Mock
	Pattern pattern;
	
	@Mock
	Matcher matcher;
	
	@Mock
	KeyVaultConfiguration keyValutProps;

	
	
	@DisplayName("getZendeskJwtTokenTest")
	@Test
	public void getZendeskJwtTokenTest() {
	
		ReflectionTestUtils.setField(keyValutProps, "zenDeskId" , "Z53UMx5kWLj1IQZsoVcmnyARC");
		ReflectionTestUtils.setField(keyValutProps, "zenDeskSecretKeyChatWizard" , "qAwCzHZr0u22E9gc8iTmR9EdR1GYq3mNdvk_5T");
		Mockito.when(userbean.getEmail()).thenReturn("mock@gmail.com");
		Mockito.when(userbean.getExp()).thenReturn((long) 1234553);
		Mockito.when(userbean.getName()).thenReturn("Mock Name");
		
		String jwtToken1 = null;
		jwtToken1 = commonUtil.getZendeskJwtToken();
		assertNotNull(jwtToken1);

	}
	
	
	@DisplayName("getZendeskUrlWebFormTest")
	@Test
	public void getZendeskUrlWebFormTest() throws UnsupportedEncodingException, JSONException, ParseException {

		ReflectionTestUtils.setField(keyValutProps, "zenDeskSecretKeyWebForm" , "Z53UM_mock");
		ReflectionTestUtils.setField(keyValutProps, "zendeskSubDomainJwt" , "financial-ombudsmanuk");
		ReflectionTestUtils.setField(keyValutProps, "zendeskSubDomain" , "financial-ombudsmanuk-dev");
		Mockito.when(userbean.getName()).thenReturn("Mock Name");
		String redirectUrl = null;
		redirectUrl = commonUtil.getZendeskUrlWebForm();
		assertNotNull(redirectUrl);

	}
	
	
	
	@DisplayName("sendInviteEmailTest")
	@Test
	public void isValidEmailInputTest() {
		
		String input = "mockemail@gmail.com";
		ReflectionTestUtils.setField(commonUtil, "mlRgx" , "^[_A-Za-z0-9-\\\\+]+(\\\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9-]+(\\\\.[A-Za-z0-9]+)*(\\\\.[A-Za-z]{2,})$");
		Mockito.when(matcher.matches()).thenReturn(true);
		boolean result = commonUtil.isValidEmailInput(input);
		assertEquals(result,false);
		
	}
	
	
	@DisplayName("isValidNameInputTest")
	@Test
	public void isValidNameInputTest() {
		
		String input = "Mock-2%+_. Name";
		boolean result = commonUtil.isValidNameInput(input);
		assertEquals(result,true);
		
	}
	
	@DisplayName("isValidInputTest")
	@Test
	public void isValidInputTest() {
		
		String input = "MockName1";
		boolean result = commonUtil.isValidInput(input);
		assertEquals(result,true);
		
	}
	
	
	@DisplayName("isValidPhoneInputTest")
	@Test
	public void isValidPhoneInputTest() {
		
		String input = "9945822731";
		boolean result = commonUtil.isValidPhoneInput(input);
		assertEquals(result,true);
		
	}
	
	@DisplayName("isValidPhoneInputTest")
	@Test
	public void isValidNumericTest() {
		
		String input = "1384";
		boolean result = commonUtil.isValidNumeric(input);
		assertEquals(result,true);
		
	}
	
}
