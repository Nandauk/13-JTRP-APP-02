package com.ombudsman.service.communication.common.test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import com.ombudsman.service.communication.common.UserBean;

@ExtendWith(SpringExtension.class)
public class UserBeanTest {
	
	
	@Value("${spring.security.oauth2.resourceserver.jwt.jwk-set-uri}")
    private String jwkUri;

    @Test
    public void testUserBeanProperties() {
        UserBean userBean = new UserBean();
        userBean.setUserObjectId("user123");
        userBean.setAuthToken("token123");
        userBean.setCorrelationId("correlation123");
        userBean.setName("John Doe");
        userBean.setGroups(List.of("group1", "group2"));
        userBean.setRoles(List.of("role1", "role2"));
        userBean.setExp(1234567890L);
        userBean.getJwkUri();

        String authToken = userBean.getAuthToken();
        String userObject = userBean.getUserObjectId();
        String corecationId = userBean.getCorrelationId();
        String name = userBean.getName();
        List<String> groups = userBean.getGroups();
        long exp = userBean.getExp();

        assertNotNull(authToken);
        assertEquals("token123",authToken);
        assertEquals("user123",userObject);
        assertEquals("correlation123",corecationId);
        assertEquals("John Doe",name);
        assertEquals(1234567890L,exp);
    
    }
    
    

	
	
    
}

