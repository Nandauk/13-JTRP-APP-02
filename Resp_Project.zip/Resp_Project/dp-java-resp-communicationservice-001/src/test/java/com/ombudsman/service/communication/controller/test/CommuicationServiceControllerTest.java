package com.ombudsman.service.communication.controller.test;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.text.ParseException;

import org.json.JSONException;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.bind.annotation.RequestBody;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ombudsman.service.communication.common.CommonUtil;
import com.ombudsman.service.communication.common.SessionWebClient;
import com.ombudsman.service.communication.common.UserBean;
import com.ombudsman.service.communication.common.ValidateUserSession;
import com.ombudsman.service.communication.controller.CommunicationServiceController;
import com.ombudsman.service.communication.exception.InputValidationException;
import com.ombudsman.service.communication.exception.MailJetServiceException;
import com.ombudsman.service.communication.exception.UnAuthorisedException;
import com.ombudsman.service.communication.model.request.UserMailjetRequest;
import com.ombudsman.service.communication.model.response.EmailNotificationResponse;
import com.ombudsman.service.communication.model.response.GenericResponse;
import com.ombudsman.service.communication.model.response.GetZenDeskJwtToken;
import com.ombudsman.service.communication.model.response.GetZenDeskUrlWebForm;
import com.ombudsman.service.communication.serviceimpl.SendEmailServiceImpl;

import jakarta.servlet.http.HttpServletResponse;
import jakarta.validation.Valid;

@ExtendWith(SpringExtension.class)
class CommuicationServiceControllerTest{
	
	@InjectMocks
	private CommunicationServiceController communicationController;
	
	@Mock
	SendEmailServiceImpl sendEmailService;
	
	@Mock
	UserBean userbean;

	@Mock
	CommonUtil commonUtil;
	
	@Mock
	GenericResponse mMockGenericResponse;
	
	@Mock
	SessionWebClient sessionWebClient;
	
	@Mock
	ValidateUserSession validateUserSession;
	
	@DisplayName("sendInviteEmailTest")
	@Test
	public void sendInviteEmailTest() throws Exception{
		
		UserMailjetRequest request = new UserMailjetRequest();
		request.setEmailId("Mock@gmail.com");
		request.setFullName("Mock Name");
		request.setTemplateId(123);
		request.setTemplateName("MockTemplate");
		
		EmailNotificationResponse response = new EmailNotificationResponse();
		response.setMessage("success");
		Mockito.when(validateUserSession.isValidSession()).thenReturn(true);
		
		Mockito.when(sendEmailService.sendInviteEmail(request)).thenReturn(response);
	
		ResponseEntity<EmailNotificationResponse> result = communicationController.sendInviteEmail(request);
	//	assertThat(result.getStatusCodeValue()).isEqualTo(200);
	}
	
	
	@DisplayName("sendcaselistemailTest")
	@Test
	public void sendCaseListEmailTest() throws JSONException, InterruptedException, ParseException, UnAuthorisedException, InputValidationException, IOException, MailJetServiceException{
		
		UserMailjetRequest request = new UserMailjetRequest();
		request.setEmailId("Mock@gmail.com");
		request.setFullName("Mock Name");
		request.setTemplateId(123);
		request.setTemplateName("MockTemplate");
		request.setIssuerEmailID("Mockemail@fos.com");
		request.setIssuerAccount("FOS ADMIN");
		
		
		EmailNotificationResponse response = new EmailNotificationResponse();
		response.setMessage("success");
		Mockito.when(validateUserSession.isValidSession()).thenReturn(true);
		
		Mockito.when(sendEmailService.sendCaseListEmail(request)).thenReturn(response);
	
		ResponseEntity<EmailNotificationResponse> result = communicationController.sendCaseListExportEmail(request);
	//	assertThat(result.getStatusCodeValue()).isEqualTo(200);
	}

	@DisplayName("getZenDeskJwtTokenTest")
	@Test
	public void getZenDeskJwtTokenTest() throws JSONException, ParseException, IOException, UnAuthorisedException {
		
		
		Mockito.when(commonUtil.getZendeskJwtToken()).thenReturn("MockUrl");
		Mockito.when(validateUserSession.isValidSession()).thenReturn(true);
		
		ResponseEntity<GetZenDeskJwtToken> response = communicationController.getZenDeskJwtToken();
		 
		assertThat(response.hasBody()); 
	}
	
	@DisplayName("getZenDeskUrlWebFormTest")
	@Test
	public void getZenDeskUrlWebFormTest() throws JSONException, ParseException, IOException, UnAuthorisedException {
		
		
		
		Mockito.when(commonUtil.getZendeskUrlWebForm()).thenReturn("MockUrl");
		Mockito.when(validateUserSession.isValidSession()).thenReturn(true);
		
		ResponseEntity<GetZenDeskUrlWebForm> response = communicationController.getZenDeskUrlWebForm();
		 
		assertThat(response.hasBody());  
	}
}