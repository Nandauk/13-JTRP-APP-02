package com.ombudsman.service.communication.exception.test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.ombudsman.service.communication.exception.InvalidADOrganizationException;
@ExtendWith(SpringExtension.class)
public class InvalidADOrganizationExceptionTest {

	
	@Test
    public void testInvalidADOrganizationException() {
        String message = "Test message";
        String exceptionMessage = "Test exception message";
        StackTraceElement[] stackTrace = Thread.currentThread().getStackTrace();

        InvalidADOrganizationException exception = new InvalidADOrganizationException(message, exceptionMessage, stackTrace);

        assertEquals(message, exception.getMessage());
        assertEquals("RESPONDENT_INVALID_AD_ORG_1000", exception.getCode());
        assertEquals(exceptionMessage, exception.getExceptionMessage());
    }
}

