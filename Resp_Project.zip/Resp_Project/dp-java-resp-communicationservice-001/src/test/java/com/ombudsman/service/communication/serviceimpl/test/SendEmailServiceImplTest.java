package com.ombudsman.service.communication.serviceimpl.test;


import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.doReturn;


import java.io.UnsupportedEncodingException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import org.json.JSONException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.springframework.test.context.junit.jupiter.SpringExtension;


import com.ombudsman.service.communication.common.CommonUtil;
import com.ombudsman.service.communication.common.UserBean;
import com.ombudsman.service.communication.exception.InputValidationException;
import com.ombudsman.service.communication.exception.MailJetServiceException;
import com.ombudsman.service.communication.model.request.From;
import com.ombudsman.service.communication.model.request.Messages;
import com.ombudsman.service.communication.model.request.RequestBodyHelper;
import com.ombudsman.service.communication.model.request.SendMailReq;
import com.ombudsman.service.communication.model.request.To;
import com.ombudsman.service.communication.model.request.UserMailjetRequest;
import com.ombudsman.service.communication.model.response.EmailNotificationResponse;
import com.ombudsman.service.communication.model.response.GenericResponse;
import com.ombudsman.service.communication.model.response.MailjetResponseBody;
import com.ombudsman.service.communication.model.response.MailjetResponseBody.Message;
import com.ombudsman.service.communication.model.response.MailjetResponseBody.Recipient;
import com.ombudsman.service.communication.serviceimpl.SendEmailServiceImpl;

@ExtendWith(SpringExtension.class)
public class SendEmailServiceImplTest {

	@InjectMocks
	@Spy
	SendEmailServiceImpl sendEmailServiceImpl;
	
	@Mock
	UserBean userbean;

	@Mock
	CommonUtil commonUtil;

	@Mock
	EmailNotificationResponse result;
	
	@Mock
	SendMailReq sendMailReq ;
	
	@Mock
	MailjetResponseBody response;
	
	@Mock
	UserMailjetRequest request;
	
	@Mock
	Message message ;
	
	@Mock
	From from ;
	
	@Mock
	Messages mes;
	
	@Mock
	Recipient r ;
	
	@Mock
	RequestBodyHelper requestBodyHelper;
	
	@Mock
	private GenericResponse mMockGenericResponse;
	
	@BeforeEach
	public void init() {
		MockitoAnnotations.openMocks(this);
	}
	
	@DisplayName("sendInviteEmailTest_Positive")
	@Test
	public void sendInviteEmailTest_Positive() throws UnsupportedEncodingException, InputValidationException, ParseException, JSONException, MailJetServiceException {
		
		
		UserMailjetRequest request = new UserMailjetRequest();
		request.setEmailId("divyadixit.aa@gmail.com");
		request.setFullName("Mock Name");
		request.setTemplateId(123);
		request.setTemplateName("MockTemplate");
		request.setIssuerEmailID("Mockemail@fos.com");
		request.setIssuerAccount("FOS ADMIN");
		
		List<To> to = new ArrayList<>();
		To to1 = new To();
		to1.setToEmail(request.getEmailId());
		to1.setToName(request.getFullName());
		to.add(to1);
		
		Messages mes = new Messages();
		mes.setTemplateID(12345);
		mes.setName("Mock TempName");
		mes.setTo(to);
		
		From from = new From();
		from.setFromEmail("fromMock@gmail.com");
		from.setFromName("From Mock");
		mes.setFrom(from);
		List<Messages> sendmessage = new ArrayList<>();
		sendmessage.add(mes);
		SendMailReq sendMailReq = new SendMailReq();
		sendMailReq.setMessages(sendmessage);
	
		Mockito.when(requestBodyHelper.contructSendEmailBody(request)).thenReturn(sendMailReq);
		
		//Mailjet Response body MOCK
		
		MailjetResponseBody res = new MailjetResponseBody();
		Recipient r = new Recipient();
		r.setEmail("mockemail");
        r.setMessageHref("wwee");
        r.setMessageID(1);
        r.setMessageUUID("messageUID");
         
         List<Recipient> toRecipient =  new ArrayList<>();
         toRecipient.add(r);
         
		Message msg1 = new Message();
		msg1.setStatus("success");
		msg1.setCustomID("1234");
		msg1.setTo(toRecipient);
		
		List<Message> messageList = new ArrayList<>();
		messageList.add(msg1);
		res.setMessages(messageList);
        
		doReturn(res).when(sendEmailServiceImpl).send(sendMailReq);
		
		result = sendEmailServiceImpl.sendInviteEmail(request);
		
		
		assertEquals("success",result.getStatus());
		
	}
	
	@DisplayName("sendInviteEmailTest_StatusFail")
	@Test
	public void sendInviteEmailTest_StatusFail() throws UnsupportedEncodingException, InputValidationException, ParseException, JSONException, MailJetServiceException {
		
		
		UserMailjetRequest request = new UserMailjetRequest();
		request.setEmailId("divyadixit.aa@gmail.com");
		request.setFullName("Mock Name");
		request.setTemplateId(123);
		request.setTemplateName("MockTemplate");
		request.setIssuerEmailID("Mockemail@fos.com");
		request.setIssuerAccount("FOS ADMIN");
		
		List<To> to = new ArrayList<>();
		To to1 = new To();
		to1.setToEmail(request.getEmailId());
		to1.setToName(request.getFullName());
		to.add(to1);
		
		Messages mes = new Messages();
		mes.setTemplateID(12345);
		mes.setName("Mock TempName");
		mes.setTo(to);
		
		From from = new From();
		from.setFromEmail("fromMock@gmail.com");
		from.setFromName("From Mock");
		mes.setFrom(from);
		List<Messages> sendmessage = new ArrayList<>();
		sendmessage.add(mes);
		SendMailReq sendMailReq = new SendMailReq();
		sendMailReq.setMessages(sendmessage);
	
		Mockito.when(requestBodyHelper.contructSendEmailBody(request)).thenReturn(sendMailReq);
		
		//Mailjet Response body MOCK
		
		MailjetResponseBody res = new MailjetResponseBody();
		Recipient r = new Recipient();
		r.setEmail("mockemail");
        r.setMessageHref("wwee");
        r.setMessageID(1);
        r.setMessageUUID("messageUID");
         
         List<Recipient> toRecipient =  new ArrayList<>();
         toRecipient.add(r);
         
		Message msg1 = new Message();
		msg1.setStatus("Failed");
		msg1.setCustomID("1234");
		msg1.setTo(toRecipient);
		
		List<Message> messageList = new ArrayList<>();
		messageList.add(msg1);
		res.setMessages(messageList);
        
		doReturn(res).when(sendEmailServiceImpl).send(sendMailReq);
		
		result = sendEmailServiceImpl.sendInviteEmail(request);
		
		
		assertEquals("Failed",result.getStatus());
		
	}


	
	@DisplayName("sendCaseListEmailTest_Positive")
	@Test
	public void sendCaseListEmailTest_Positive() throws UnsupportedEncodingException, InputValidationException, ParseException, JSONException, MailJetServiceException {
		
		
		
		UserMailjetRequest request = new UserMailjetRequest();
		request.setEmailId("mockToemail.aa@gmail.com");
		request.setFullName("Mock Name");
		request.setTemplateId(123);
		request.setTemplateName("MockTemplate");
		request.setIssuerEmailID("Mockemail@fos.com");
		request.setIssuerAccount("FOS ADMIN");
		
		
		List<To> to = new ArrayList<>();
		List<Messages> sendmessage = new ArrayList<>();
		To to1 = new To();
		to1.setToEmail(request.getEmailId());
		to1.setToName(request.getFullName());
		to.add(to1);
		
		Messages mes = new Messages();
		mes.setTemplateID(12345);
		mes.setName("Mock TempName");
		mes.setTo(to);
		
		From from = new From();
		from.setFromEmail("fromMock@gmail.com");
		from.setFromName("From Mock");
		mes.setFrom(from);
		sendmessage.add(mes);
		SendMailReq sendMailReq = new SendMailReq();
		sendMailReq.setMessages(sendmessage);
		
		Mockito.when(requestBodyHelper.contructSendEmailBody(request)).thenReturn(sendMailReq);
		
		//Mailjet Response body MOCK
		
		MailjetResponseBody res = new MailjetResponseBody();
		Recipient r = new Recipient();
		r.setEmail("mockemail");
        r.setMessageHref("wwee");
        r.setMessageID(1);
        r.setMessageUUID("messageUID");
         
         List<Recipient> toRecipient =  new ArrayList<>();
         toRecipient.add(r);
         
		Message msg1 = new Message();
		msg1.setStatus("Success");
		msg1.setCustomID("1234");
		msg1.setTo(toRecipient);
		
		List<Message> messageList = new ArrayList<>();
		messageList.add(msg1);
		res.setMessages(messageList);
        
		doReturn(res).when(sendEmailServiceImpl).send(sendMailReq);
		
		result = sendEmailServiceImpl.sendCaseListEmail(request);
		
		assertEquals("Success",result.getStatus());
		
	}
	
	@DisplayName("sendCaseListEmailTest_StatusFail")
	@Test
	public void sendCaseListEmailTest_StatusFail() throws UnsupportedEncodingException, InputValidationException, ParseException, JSONException, MailJetServiceException {
		
		
		UserMailjetRequest request = new UserMailjetRequest();
		request.setEmailId("divyadixit.aa@gmail.com");
		request.setFullName("Mock Name");
		request.setTemplateId(123);
		request.setTemplateName("MockTemplate");
		request.setIssuerEmailID("Mockemail@fos.com");
		request.setIssuerAccount("FOS ADMIN");
		
		List<To> to = new ArrayList<>();
		To to1 = new To();
		to1.setToEmail(request.getEmailId());
		to1.setToName(request.getFullName());
		to.add(to1);
		
		Messages mes = new Messages();
		mes.setTemplateID(12345);
		mes.setName("Mock TempName");
		mes.setTo(to);
		
		From from = new From();
		from.setFromEmail("fromMock@gmail.com");
		from.setFromName("From Mock");
		mes.setFrom(from);
		List<Messages> sendmessage = new ArrayList<>();
		sendmessage.add(mes);
		SendMailReq sendMailReq = new SendMailReq();
		sendMailReq.setMessages(sendmessage);
	
		Mockito.when(requestBodyHelper.contructSendEmailBody(request)).thenReturn(sendMailReq);
		
		//Mailjet Response body MOCK
		
		MailjetResponseBody res = new MailjetResponseBody();
		Recipient r = new Recipient();
		r.setEmail("mockemail");
        r.setMessageHref("wwee");
        r.setMessageID(1);
        r.setMessageUUID("messageUID");
         
         List<Recipient> toRecipient =  new ArrayList<>();
         toRecipient.add(r);
         
		Message msg1 = new Message();
		msg1.setStatus("Failed");
		msg1.setCustomID("1234");
		msg1.setTo(toRecipient);
		
		List<Message> messageList = new ArrayList<>();
		messageList.add(msg1);
		res.setMessages(messageList);
        
		doReturn(res).when(sendEmailServiceImpl).send(sendMailReq);
		
		result = sendEmailServiceImpl.sendCaseListEmail(request);
		
		
		assertEquals("Failed",result.getStatus());
		
	}
	
	@DisplayName("sendCaseListEmailTest_InvalidEmail")
	@Test
	public void sendCaseListEmailTest_InvalidEmail() throws UnsupportedEncodingException, InputValidationException, ParseException {
		
		MailjetResponseBody response = new MailjetResponseBody();
		
		UserMailjetRequest request = new UserMailjetRequest();
		request.setEmailId("mockemailgmail.com");
		request.setFullName("Mock Name");
		request.setTemplateId(123);
		request.setTemplateName("MockTemplate");
		
		List<To> to = new ArrayList<>();
		To to1 = new To();
		to1.setToEmail(request.getEmailId());
		to1.setToName(request.getFullName());
		to.add(to1);
		
		Messages mes = new Messages();
		mes.setTemplateID(12345);
		mes.setName("Mock TempName");
		mes.setTo(to);
		
		From from = new From();
		from.setFromEmail("fromMock@gmail.com");
		from.setFromName("From Mock");
		mes.setFrom(from);
		List<Messages> sendmessage = new ArrayList<>();
		sendmessage.add(mes);
		SendMailReq sendMailReq = new SendMailReq();
		sendMailReq.setMessages(sendmessage);
		
	
		try{
			result = sendEmailServiceImpl.sendCaseListEmail(request);
		  }
		catch(MailJetServiceException e){
			assertEquals("Mailjet Webclient call failed :",e.getMessage());  
		}
		
	}
	
	
}
