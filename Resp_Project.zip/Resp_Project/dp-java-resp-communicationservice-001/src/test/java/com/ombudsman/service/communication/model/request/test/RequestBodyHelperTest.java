package com.ombudsman.service.communication.model.request.test;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.mock;

import org.apache.commons.lang3.StringUtils;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.util.ReflectionTestUtils;

import com.ombudsman.service.communication.common.CommonUtil;
import com.ombudsman.service.communication.common.UserBean;
import com.ombudsman.service.communication.model.request.From;
import com.ombudsman.service.communication.model.request.Messages;
import com.ombudsman.service.communication.model.request.RequestBodyHelper;
import com.ombudsman.service.communication.model.request.SendMailReq;
import com.ombudsman.service.communication.model.request.UserMailjetRequest;
import com.ombudsman.service.communication.model.response.EmailNotificationResponse;
import com.ombudsman.service.communication.model.response.GenericResponse;
import com.ombudsman.service.communication.model.response.MailjetResponseBody;
import com.ombudsman.service.communication.model.response.MailjetResponseBody.Message;
import com.ombudsman.service.communication.serviceimpl.SendEmailServiceImpl;

@ExtendWith(SpringExtension.class)
public class RequestBodyHelperTest {
	
	@InjectMocks
	RequestBodyHelper requestBodyHelper;
	
	@Mock
	UserBean userbean;

	@Mock
	CommonUtil commonUtil;
	
	
	@Mock
	private GenericResponse mMockGenericResponse;
	
	@DisplayName("contructSendEmailBodyTest_Positive")
	@Test
	public void contructSendEmailBodyTest() {
		
		
		UserMailjetRequest request = new UserMailjetRequest();
		request.setEmailId("mockToEmail.aa@gmail.com");
		request.setFullName("Mock Name");
		request.setTemplateId(123);
		request.setTemplateName("MockTemplate");
		request.setIssuerEmailID("Mockemail@fos.com");
		request.setIssuerAccount("FOS ADMIN");
		
		ReflectionTestUtils.setField(commonUtil,"MAILJET_FROM_EMAIL","mockToemail@gmail.com");
		ReflectionTestUtils.setField(commonUtil,"MAILJET_SERVER_NAME","mName mTo");
		
		Mockito.when(commonUtil.isValidEmailInput(request.getEmailId())).thenReturn(true);
		Mockito.when(commonUtil.isValidNameInput(StringUtils.trim(request.getFullName()))).thenReturn(true);
		Mockito.when(commonUtil.isValidNumeric(String.valueOf(request.getTemplateId()))).thenReturn(true);
		Mockito.when(commonUtil.isValidNameInput(request.getTemplateName())).thenReturn(true);
		SendMailReq sendMailReq = requestBodyHelper.contructSendEmailBody(request);
		assertNotNull(sendMailReq);
		
}
	
	
}
