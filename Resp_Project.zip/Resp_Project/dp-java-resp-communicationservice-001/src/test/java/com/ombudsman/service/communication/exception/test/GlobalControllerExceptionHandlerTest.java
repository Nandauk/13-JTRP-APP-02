package com.ombudsman.service.communication.exception.test;


import org.springframework.context.MessageSource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.servlet.NoHandlerFoundException;

import com.ombudsman.service.communication.common.UserBean;
import com.ombudsman.service.communication.exception.ApiError;
import com.ombudsman.service.communication.exception.GobalExceptionHandler;
import com.ombudsman.service.communication.exception.InputValidationException;
import com.ombudsman.service.communication.exception.RespondentsServiceExceptions;

import jakarta.servlet.http.HttpServletRequest;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;

import java.util.Locale;

import javax.security.auth.login.AccountNotFoundException;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@ExtendWith(SpringExtension.class)
public class GlobalControllerExceptionHandlerTest {
	
	@InjectMocks
	GobalExceptionHandler testInstance;
	
	@Mock
	ResponseEntity<ApiError> response;
	
	@Mock
	AccountNotFoundException exception;
	
	@Mock
	HttpServletRequest request;
	
	@Mock
	Exception ex;
	
	@Mock
	UserBean userbean;
	
	@Mock
	MessageSource messageSource;
	
	 @Mock
	    private HttpHeaders headers;
	
	private static final String API_ERROR_EXCEPTIONMSG = "api.error.exceptionmsg";
	private static final String RESPONDENT_1004 = "RESPONDENT_1004";
	private static final String API_ERROR_EXCEPTION_ACCOUNT_ID = "api.error.accountid";
	
	private static final Logger logger =
		      LoggerFactory.getLogger(GobalExceptionHandler.class);	
	  
	
	 
	 @Test
	    public void testhandleExceptionInputInvalid() {
		 	
		 	String message = "Test exception";
	        String code = "123";
	        String exceptionMessage = "Test exception message";
	        StackTraceElement[] stackTraceElements = new StackTraceElement[0];
	        InputValidationException inputValidationException = new InputValidationException(message, code, exceptionMessage, stackTraceElements);

	        ResponseEntity<Object> responseEntity = testInstance.handleExceptionInputInvalid(inputValidationException);
	        
	        ApiError apiError = (ApiError) responseEntity.getBody();
	        assertEquals("RESPONDENT_USER_1000", apiError.getErrorCode());
	        assertEquals(HttpStatus.BAD_REQUEST, responseEntity.getStatusCode());
	        assertEquals("Test exception", apiError.getErrorMessage());

	    }
	 
	 @Test
	    public void handleNoHandlerFoundExceptionTest() {
		 	

		 	String httpMethod = "SomeMethdo";

			String requestURL = "someURL";

	        NoHandlerFoundException noHandlerFoundException = new NoHandlerFoundException(httpMethod,requestURL,headers);
	        ResponseEntity<Object> responseEntity = testInstance.handleNoHandlerFoundException(noHandlerFoundException);
	        
	        ApiError apiError = (ApiError) responseEntity.getBody();
	      
	        assertEquals(HttpStatus.BAD_REQUEST, responseEntity.getStatusCode());
	       // assertEquals("No endpoint SomeMethdo someURL.", apiError.getErrorMessage());
	    }
	 
	 
	 
}