package com.ombudsman.service.communication.model.response.test;

import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;


import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.test.context.junit.jupiter.SpringExtension;


import com.ombudsman.service.communication.model.response.MailjetResponseBody;
import com.ombudsman.service.communication.model.response.MailjetResponseBody.Message;
import com.ombudsman.service.communication.model.response.MailjetResponseBody.Recipient;


@ExtendWith(SpringExtension.class)
public class MailjetResponseBodyTest {

	@DisplayName("testMailjetResponseBody")
    @Test
    public void testMailjetResponseBody(){
		
		Recipient toRecipient = new Recipient();
		toRecipient.setEmail("mocktoemail");
		toRecipient.setMessageHref("wwee");
		toRecipient.setMessageID(1);
		toRecipient.setMessageUUID("tomessageUID");
		
		Recipient bccRecipient = new Recipient();
		bccRecipient.setEmail("mockBccemail");
		bccRecipient.setMessageHref("wwee");
		bccRecipient.setMessageID(2);
		bccRecipient.setMessageUUID("bccmessageUID");
		
		Recipient ccRecipient = new Recipient();
		ccRecipient.setEmail("mockeccmail");
		ccRecipient.setMessageHref("wwee");
		ccRecipient.setMessageID(3);
		ccRecipient.setMessageUUID("ccmessageUID");
         
         List<Recipient> toRecipientList =  new ArrayList<>();
         toRecipientList.add(toRecipient);
         
         List<Recipient> bccRecipientList =  new ArrayList<>();
         bccRecipientList.add(toRecipient);
         
         List<Recipient> ccRecipientList =  new ArrayList<>();
         ccRecipientList.add(toRecipient);
         
		 Message msg = new Message();
		 msg.setStatus("Success");
		 msg.setCustomID("1234");
		 msg.setTo(toRecipientList);
		 msg.setBcc(bccRecipientList);
		 msg.setCc(ccRecipientList);
		
		List<Message> messageList = new ArrayList<>();
		messageList.add(msg);
		
		MailjetResponseBody res = new MailjetResponseBody();
		res.setMessages(messageList);
		
		//Get all things Set above
		
		 String email = toRecipient.getEmail();
         String messageUUID = toRecipient.getMessageUUID();
         long messageID = toRecipient.getMessageID();
         String messageHref = toRecipient.getMessageHref();
         
         String status = msg.getStatus();
         String customID = msg.getCustomID();
         List<Recipient> to = msg.getTo();
         List<Recipient> cc = msg.getCc();
         List<Recipient> bcc = msg.getBcc();
         
         List<Message> messages = res.getMessages();
         assertNotNull(messages);
	
}
}
