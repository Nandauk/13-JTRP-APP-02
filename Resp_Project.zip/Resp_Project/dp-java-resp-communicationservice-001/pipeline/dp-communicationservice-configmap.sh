#! /bin/bash
az account set --subscription "b70424dd-d53a-40a3-98a4-0cf1f27c11f0"
cat <<EOF > dp-api-resp-dv2-configmap.yaml
apiVersion: v1
kind: ConfigMap
metadata:
  name: dp-api-resp-communicationservice
  namespace: var_namespace_respondent
data:
EOF

ENVIRONMENT=dv2
cat <<EOF>> dp-api-resp-${ENVIRONMENT}-configmap.yaml
   AD_RESP_ISSUER_URI: https://ombportalrespb2cdev.b2clogin.com/tfp/65a36538-9d84-4717-a24f-19666eb31ca6/b2c_1a_signin_fosresp_dp/v2.0/
   AD_RESP_B2C_JWT_SET_URI: https://ombportalrespb2cdev.b2clogin.com/ombportalrespb2cdev.onmicrosoft.com/discovery/v2.0/keys?p=b2c_1a_signin_fosresp_dp
   SERVER_PORT: '8443'
   ML_RGX: "^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$"
   SESSION_BASE_URL: https://portal-dev2.financial-ombudsman.org.uk
   SESSION_FLAG: 'true'
   MJ_SERVER_EMAIL: No-Reply@DigitalSelfServe.Financial-Ombudsman.org.uk
   MJ_SERVER_NAME: "FOS Email Notification"
   MJ_APIM_URL: https://apim-dev2.financial-ombudsman.org.uk/mailjet/send
   VAULT_CLIENITID: 22684d8b-7173-4e22-8a56-53491543933e
   VAULT_ENDPOINT: https://kv-dp-app-res-uks-${ENVIRONMENT}-01.vault.azure.net
   INFRA_TENENT_ID: 3df253a5-1a74-47e7-a5e0-204525367f22
EOF

cat dp-api-resp-${ENVIRONMENT}-configmap.yaml