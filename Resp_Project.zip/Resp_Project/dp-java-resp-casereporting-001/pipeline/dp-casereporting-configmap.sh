#! /bin/bash
az account set --subscription "b70424dd-d53a-40a3-98a4-0cf1f27c11f0"
cat <<EOF > dp-api-resp-dv2-configmap.yaml
apiVersion: v1
kind: ConfigMap
metadata:
  name: dp-api-resp-casereporting
  namespace: var_namespace_respondent
data:
EOF

ENVIRONMENT=dv2
cat <<EOF>> dp-api-resp-dv2-configmap.yaml
   AD_RESP_ISSUER_URI: https://ombportalrespb2cdev.b2clogin.com/tfp/65a36538-9d84-4717-a24f-19666eb31ca6/b2c_1a_signin_fosresp_dp/v2.0/
   AD_RESP_B2C_JWT_SET_URI: https://ombportalrespb2cdev.b2clogin.com/ombportalrespb2cdev.onmicrosoft.com/discovery/v2.0/keys?p=b2c_1a_signin_fosresp_dp
   SERVER_PORT: '8443'
   SESSION_BASE_URL: https://portal-dev2.financial-ombudsman.org.uk
   SESSION_FLAG: 'true'
EOF

cat dp-api-resp-${ENVIRONMENT}-configmap.yaml