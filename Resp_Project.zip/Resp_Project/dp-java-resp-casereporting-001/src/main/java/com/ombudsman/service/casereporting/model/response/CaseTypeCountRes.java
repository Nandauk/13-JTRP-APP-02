package com.ombudsman.service.casereporting.model.response;

import java.util.List;

import com.ombudsman.service.casereporting.model.CaseTypeCount;

public class CaseTypeCountRes extends GenericResponse{

	private List<CaseTypeCount> businesscount;
	private List<CaseTypeCount> complainantcount;
	private List<CaseTypeCount> productcount;

	public List<CaseTypeCount> getBusinesscount() {
		return businesscount;
	}
	public void setBusinesscount(List<CaseTypeCount> businesscount) {
		this.businesscount = businesscount;
	}
	public List<CaseTypeCount> getComplainantcount() {
		return complainantcount;
	}
	public void setComplainantcount(List<CaseTypeCount> complainantcount) {
		this.complainantcount = complainantcount;
	}
	public List<CaseTypeCount> getProductcount() {
		return productcount;
	}
	public void setProductcount(List<CaseTypeCount> productcount) {
		this.productcount = productcount;
	}

	
}
