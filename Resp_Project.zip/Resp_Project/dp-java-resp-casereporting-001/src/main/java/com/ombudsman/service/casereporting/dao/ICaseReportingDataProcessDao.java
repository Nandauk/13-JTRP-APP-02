package com.ombudsman.service.casereporting.dao;

import java.util.List;

import org.springframework.dao.DataAccessException;

import com.ombudsman.service.casereporting.dto.CaseLatestOutCome;
import com.ombudsman.service.casereporting.dto.CaseOwnerCountProjectionDto;
import com.ombudsman.service.casereporting.dto.OpenCaseCountByStatusResDto;
import com.ombudsman.service.casereporting.dto.OpenCaseCountSummeryDto;
import com.ombudsman.service.casereporting.dto.RecentCaseDto;
import com.ombudsman.service.casereporting.dto.ViewCaseCountProjectionDto;

public interface ICaseReportingDataProcessDao {
	public List<String> getAccountIds(final String oid);
	public List<CaseLatestOutCome> getLatestOutcomeCount(final List<String> accountids);
	public List<CaseOwnerCountProjectionDto> getCaseOwnerCountSQL(final List<String> accountids);
	public List<OpenCaseCountByStatusResDto> getOpenCaseCount(final List<String> accountids);
	public List<RecentCaseDto> getFetchRecentCase(final List<String> accountids);
	public OpenCaseCountSummeryDto getCaseCountSummery(final String accountids) throws DataAccessException;
	public List<CaseLatestOutCome> getFinalOutcomeCount(final List<String> accountids);
	public List<ViewCaseCountProjectionDto> getBusnissCountList(List<String> accountids) throws DataAccessException;
}
 