package com.ombudsman.service.casereporting.common;

public class Constants {
	public static final String MSG_FAILURE="Failure";
	public static final String MSG_SUCCESS="Success";
	public static final String SESSION_API_URL="/ombudsmanservice/v1/sessionmanagement/verifytokenforresponse";
	public static final String CASEWORKER_ROLES = "CaseWorker";
	public static final String SUPERVISOR_ROLES = "Supervisor";
	public static final String VALID = "valid";
	
	private Constants() {
	      //not called
	   }
	
	
}
