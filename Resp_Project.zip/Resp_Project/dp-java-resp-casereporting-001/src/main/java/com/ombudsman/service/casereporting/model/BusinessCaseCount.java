package com.ombudsman.service.casereporting.model;

import java.util.List;

public class BusinessCaseCount {
	
	private List<GenericCount> businesscount;
	private String casestatus;
	private String totalcount;
	
	
	
	public List<GenericCount> getBusinesscount() {
		return businesscount;
	}
	public void setBusinesscount(List<GenericCount> businesscount) {
		this.businesscount = businesscount;
	}
	public String getCasestatus() {
		return casestatus;
	}
	public void setCasestatus(String casestatus) {
		this.casestatus = casestatus;
	}
	public String getTotalcount() {
		return totalcount;
	}
	public void setTotalcount(String totalcount) {
		this.totalcount = totalcount;
	}
	
	
	
	
	

}
