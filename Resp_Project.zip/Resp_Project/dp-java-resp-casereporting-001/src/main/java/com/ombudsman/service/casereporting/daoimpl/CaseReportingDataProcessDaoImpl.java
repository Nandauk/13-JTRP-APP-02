package com.ombudsman.service.casereporting.daoimpl;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Repository;
import org.apache.commons.lang3.StringUtils;
import com.ombudsman.service.casereporting.dao.ICaseReportingDataProcessDao;
import com.ombudsman.service.casereporting.dto.CaseLatestOutCome;
import com.ombudsman.service.casereporting.dto.CaseOwnerCountProjectionDto;
import com.ombudsman.service.casereporting.dto.OpenCaseCountByStatusResDto;
import com.ombudsman.service.casereporting.dto.OpenCaseCountSummeryDto;
import com.ombudsman.service.casereporting.dto.RecentCaseDto;
import com.ombudsman.service.casereporting.dto.ViewCaseCountProjectionDto;
import com.ombudsman.service.casereporting.repository.RecentCaseRepository;
@Repository
public class CaseReportingDataProcessDaoImpl implements ICaseReportingDataProcessDao{
	@Autowired
	RecentCaseRepository recentCaseRepository;

	@Override
	public List<String> getAccountIds(final String oid) {
		return recentCaseRepository.getAccountId(oid);
	}

	@Override
	public List<CaseLatestOutCome> getLatestOutcomeCount(final List<String> accountids) {
		return recentCaseRepository.getLatestOutcomeCount(accountids);
	}

	@Override
	public List<CaseOwnerCountProjectionDto> getCaseOwnerCountSQL(final List<String> accountids) {
		return recentCaseRepository.getCaseOwnerCountSQL(StringUtils.join(accountids, ','));
	}

	@Override
	public List<OpenCaseCountByStatusResDto> getOpenCaseCount(final List<String> accountids) {
		return recentCaseRepository.getOpenCaseCount(accountids);		
	}

	@Override
	public List<RecentCaseDto> getFetchRecentCase(final List<String> accountids) {		
		return  recentCaseRepository.getFetchRecentCase(accountids);
	}

	@Override
	public OpenCaseCountSummeryDto getCaseCountSummery( final String accountids) throws DataAccessException {		
		return recentCaseRepository.getCaseCountSummery(accountids);
	}

	@Override
	public List<CaseLatestOutCome> getFinalOutcomeCount(final List<String> accountids) throws DataAccessException {	
		return  recentCaseRepository.getFinalOutcomeCount(accountids);
	}

	@Override
	public List<ViewCaseCountProjectionDto> getBusnissCountList(final List<String> accountids) throws DataAccessException {	
		return recentCaseRepository.getBusnissCountList(accountids);
	}
	

}
