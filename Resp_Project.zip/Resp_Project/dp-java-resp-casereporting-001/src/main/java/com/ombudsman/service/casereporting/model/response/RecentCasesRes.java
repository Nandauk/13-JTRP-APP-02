package com.ombudsman.service.casereporting.model.response;

import java.util.List;

import com.ombudsman.service.casereporting.model.RecentCasesList;

public class RecentCasesRes extends GenericResponse{
	
	private List<RecentCasesList> recentcaselist;

	public List<RecentCasesList> getRecentcaselist() {
		return recentcaselist;
	}
	public void setRecentcaselist(List<RecentCasesList> recentcaselist) {
		this.recentcaselist = recentcaselist;
	}
	
	
	
	
	
	

}
