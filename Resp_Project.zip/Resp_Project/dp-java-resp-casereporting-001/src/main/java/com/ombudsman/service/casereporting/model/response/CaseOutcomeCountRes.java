package com.ombudsman.service.casereporting.model.response;

import java.util.List;

import com.ombudsman.service.casereporting.model.CaseOutcomeCount;

public class CaseOutcomeCountRes extends GenericResponse{
	
	private List<CaseOutcomeCount> caseoutcomecount;
	
	public List<CaseOutcomeCount> getCaseoutcomecount() {
		return caseoutcomecount;
	}
	public void setCaseoutcomecount(List<CaseOutcomeCount> caseoutcomecount) {
		this.caseoutcomecount = caseoutcomecount;
	}




}
