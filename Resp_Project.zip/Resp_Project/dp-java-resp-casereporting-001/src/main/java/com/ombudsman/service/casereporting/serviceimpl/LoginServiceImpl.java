package com.ombudsman.service.casereporting.serviceimpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ombudsman.service.casereporting.common.CommonUtil;
import com.ombudsman.service.casereporting.common.CaseReportingWebClient;
import com.ombudsman.service.casereporting.model.response.GenericResponse;
import com.ombudsman.service.casereporting.service.ILoginService;

@Service
public class LoginServiceImpl implements ILoginService {
	
	@Autowired
	CommonUtil commonUtil;

	@Autowired
	CaseReportingWebClient dashBoardWebClient;


	@Override
	public GenericResponse addUserSessionEntry() throws Exception {
		final String sessionType="login";
		return dashBoardWebClient.getResponseForSessionActivity(sessionType);		
	}

	@Override
	public GenericResponse updateUserSessionEntry() throws Exception {
		final String sessionType="";
		return dashBoardWebClient.getResponseForSessionActivity(sessionType);		
	}	
	@Override
	public GenericResponse logoutForUserSession() throws Exception {
		final String sessionType="logout";
		return dashBoardWebClient.getResponseForSessionActivity(sessionType);		
	}

	@Override
	public GenericResponse getSessionTokenStatus() throws Exception {
		final String sessionType="";		
		return dashBoardWebClient.getResponseForSessionActivity(sessionType);
	}
	
	

}
