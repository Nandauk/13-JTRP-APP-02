package com.ombudsman.service.casereporting.model.response;

import java.util.List;

import com.ombudsman.service.casereporting.model.OpenCaseCount;

public class OpenCaseCountByStatusRes extends GenericResponse{

	/*
	 * private List<OpenCaseCount> opencasecount;
	 * 
	 * public List<OpenCaseCount> getOpencasecount() { return opencasecount; }
	 * public void setOpencasecount(List<OpenCaseCount> opencasecount) {
	 * this.opencasecount = opencasecount; }
	 */
	private List<OpenCaseCount> caseprogresscount;
	
	public List<OpenCaseCount> getCaseprogresscount() {
		return caseprogresscount;
	}

	public void setCaseprogresscount(List<OpenCaseCount> caseprogresscount) {
		this.caseprogresscount = caseprogresscount;
	}
}
