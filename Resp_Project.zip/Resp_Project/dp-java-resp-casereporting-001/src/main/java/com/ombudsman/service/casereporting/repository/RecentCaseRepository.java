package com.ombudsman.service.casereporting.repository;

import java.util.List;

import org.springframework.dao.DataAccessException;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.ombudsman.service.casereporting.dto.CaseLatestOutCome;
import com.ombudsman.service.casereporting.dto.CaseOwnerCountProjectionDto;
import com.ombudsman.service.casereporting.dto.OpenCaseCountByStatusResDto;
import com.ombudsman.service.casereporting.dto.OpenCaseCountSummeryDto;
import com.ombudsman.service.casereporting.dto.RecentCaseDto;
import com.ombudsman.service.casereporting.dto.ViewCaseCountProjectionDto;
import com.ombudsman.service.casereporting.model.account;

@Repository
public interface RecentCaseRepository extends JpaRepository<account, String> {

	@Query(value = "EXEC prc_GetDashboardcountByCustomTable ?", nativeQuery = true)	
	OpenCaseCountSummeryDto getCaseCountSummery(@Param("accountids") String accountids) throws DataAccessException;
	
	@Query(value = "EXEC prc_getUserAccountId ?", nativeQuery = true)
	List<String> getAccountId(@Param("accountids") String accountids) throws DataAccessException;

	
	@Query(value = "SELECT sum(recordcount) as totalrecordcount, fos_caseprogress_name as caseprogressname, fos_caseprogress as caseprogresscode, casestagename,casestage FROM c_casebystage WHERE accountid IN :accountids GROUP BY casestagename, casestage, fos_caseprogress, fos_caseprogress_name ORDER BY casestagename ", nativeQuery = true)
	List<OpenCaseCountByStatusResDto> getOpenCaseCount(@Param("accountids") List<String> accountids) throws DataAccessException;
	
	@Query(value = "select id,viewid, name,investigationcount,viewcount,ombudsmancount,total from c_viewcaseby where  accountid IN :accountids", nativeQuery = true)
	List<ViewCaseCountProjectionDto> getBusnissCountList(@Param("accountids") List<String> accountids) throws DataAccessException;
	
	@Query(value = "select top 10 incidentid,ticketnumber,fos_reference,FORMAT(fos_dateofreferral,'dd-MM-yyyy') as fos_dateofreferral,FORMAT(fos_dateofconversion,'dd-MM-yyyy') as fos_datecasefirstmovedtoinvestigation,FORMAT(fos_dateofevent,'dd-MM-yyyy') as fos_dateofevent,FORMAT(br_required,'dd-MM-yyyy') as br_required  from c_caselist where customerid IN :accountids and statecode=0 ORDER BY fos_dateofconversion DESC", nativeQuery = true)
	List<RecentCaseDto> getFetchRecentCase(@Param("accountids") List<String> accountids) throws DataAccessException;
 
	@Query(value = "SELECT finalOut.Outcome_type AS outcomeType, sum(finalOut.All_Count)  as outcomeCount, sum(finalOut.Current_M_Count) as currentMonthCount,sum(finalOut.Last_M_Count) as lastMonthCount FROM c_finaloutcome as finalOut where accountid IN :accountids group by finalOut.Outcome_type", nativeQuery = true)
	List<CaseLatestOutCome> getFinalOutcomeCount(@Param("accountids") List<String> accountids) throws DataAccessException;
	
	
	@Query(value = "SELECT latest.outcometype_string AS outcomeType, sum(latest.outcome_count) AS outcomeCount FROM c_latest_outcomes as latest where accountid IN :accountids group by latest.outcometype_string", nativeQuery = true)
	List<CaseLatestOutCome> getLatestOutcomeCount(@Param("accountids") List<String> accountids) throws DataAccessException;

	@Query(value = "EXEC prc_getcaseowners ?", nativeQuery = true)
	List<CaseOwnerCountProjectionDto> getCaseOwnerCountSQL(@Param("accountids") String accountids) throws DataAccessException;

}
