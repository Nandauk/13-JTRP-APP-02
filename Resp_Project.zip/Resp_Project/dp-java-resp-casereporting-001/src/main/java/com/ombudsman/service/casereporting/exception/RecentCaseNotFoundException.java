package com.ombudsman.service.casereporting.exception;

public class RecentCaseNotFoundException extends Exception {
	/**
   * 
   */
  private static final long serialVersionUID = 1L;

  public RecentCaseNotFoundException(String orgName){
		super(orgName);
	}
}
