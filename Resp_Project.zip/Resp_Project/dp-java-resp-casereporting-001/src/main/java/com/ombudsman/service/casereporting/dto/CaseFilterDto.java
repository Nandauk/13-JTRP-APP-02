package com.ombudsman.service.casereporting.dto;

public interface CaseFilterDto {
	public String getFilterType();
	public String getFilterValue();
	public String getAccountId();

}
