package com.ombudsman.service.casereporting.model;

public class Accounts {

	private String accountid;

	public String getAccountid() {
		return accountid;
	}

	public void setAccountid(String accountid) {
		this.accountid = accountid;
	}
}
