package com.ombudsman.service.casereporting.exception;

public class DashboardCaseException extends Exception {
	/**
   * 
   */
  private static final long serialVersionUID = 1L;

  public DashboardCaseException(String orgName){
		super(orgName);
	}
}
