package com.ombudsman.service.casereporting.model.response;

public class CaseByCaseReferenceRes extends GenericResponse{
	
	private String incidentid;
	
	public String getIncidentid() {
		return incidentid;
	}
	public void setIncidentid(String incidentid) {
		this.incidentid = incidentid;
	}
}
