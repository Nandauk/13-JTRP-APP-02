package com.ombudsman.service.casereporting.model;

import java.util.List;

public class FinalCaseOutcomeCount {
	


	private List<FinalOutComeCount> caseoutcomecountvar;
	private String caseoutcomestatus;
	private Integer totalcount;
	private Integer currentmonthcount;
	private Integer lastmonthcount;

	public Integer getCurrentmonthcount() {
		return currentmonthcount;
	}

	public void setCurrentmonthcount(final Integer currentmonthcount) {
		this.currentmonthcount = currentmonthcount;
	}

	public Integer getLastmonthcount() {
		return lastmonthcount;
	}

	public void setLastmonthcount(final Integer lastmonthcount) {
		this.lastmonthcount = lastmonthcount;
	}

	public List<FinalOutComeCount> getCaseoutcomecountvar() {
		return caseoutcomecountvar;
	}

	public void setCaseoutcomecountvar(final List<FinalOutComeCount> caseoutcomecountvar) {
		this.caseoutcomecountvar = caseoutcomecountvar;
	}

	public String getCaseoutcomestatus() {
		return caseoutcomestatus;
	}

	public void setCaseoutcomestatus(String caseoutcomestatus) {
		this.caseoutcomestatus = caseoutcomestatus;
	}

	public Integer getTotalcount() {
		return totalcount;
	}

	public void setTotalcount(Integer totalcount) {
		this.totalcount = totalcount;
	}



}
