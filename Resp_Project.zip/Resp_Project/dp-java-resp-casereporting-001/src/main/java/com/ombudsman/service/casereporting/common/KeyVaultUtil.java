package com.ombudsman.service.casereporting.common;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import com.azure.identity.DefaultAzureCredentialBuilder;
import com.azure.security.keyvault.secrets.SecretClient;
import com.azure.security.keyvault.secrets.SecretClientBuilder;
public class KeyVaultUtil {	
	
	static Logger LOG = LogManager.getRootLogger();
	
    public static  String getSecret(String KEYVAULT_URL,String APPLICATIONINSIGHTS_CONNECTION_STRING) {
        SecretClient client = new SecretClientBuilder()
            .vaultUrl(KEYVAULT_URL)
            .credential(new DefaultAzureCredentialBuilder().build())
            .buildClient();
        LOG.info(String.format("KEYVAULT_URL :%s,  APPLICATIONINSIGHTS_CONNECTION_STRING: %s", KEYVAULT_URL, APPLICATIONINSIGHTS_CONNECTION_STRING));
        return client.getSecret(APPLICATIONINSIGHTS_CONNECTION_STRING).getValue();
    }
}