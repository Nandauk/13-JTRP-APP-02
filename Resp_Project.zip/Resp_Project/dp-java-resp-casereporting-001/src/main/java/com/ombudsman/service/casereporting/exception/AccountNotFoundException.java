package com.ombudsman.service.casereporting.exception;

public class AccountNotFoundException extends Exception {
	/**
   * 
   */
  private static final long serialVersionUID = 1L;

  public AccountNotFoundException(String orgName){
		super(orgName);
	}
}
