package com.ombudsman.service.casereporting.serviceimpl;

import static com.ombudsman.service.casereporting.common.Constants.MSG_FAILURE;
import static com.ombudsman.service.casereporting.common.Constants.MSG_SUCCESS;

import java.util.List;
import java.util.Optional;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.LogManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ombudsman.service.casereporting.common.UserBean;
import com.ombudsman.service.casereporting.dao.ICaseReportingDataProcessDao;
import com.ombudsman.service.casereporting.dto.CaseLatestOutCome;
import com.ombudsman.service.casereporting.exception.AccountNotFoundException;
import com.ombudsman.service.casereporting.exception.AzureServiceException;
import com.ombudsman.service.casereporting.exception.DashboardCaseException;
import com.ombudsman.service.casereporting.exception.RecentCaseNotFoundException;
import com.ombudsman.service.casereporting.model.CaseOutcomeCount;
import com.ombudsman.service.casereporting.model.response.CaseOutcomeCountRes;
import com.ombudsman.service.casereporting.service.ICaseLatestOutcomeService;
import com.ombudsman.service.casereporting.serviceimpl.helper.CaseReportingDetailsHelper;

@Service
public class GetCaseLatestOutcomeServiceImpl implements ICaseLatestOutcomeService {

	@Autowired
	private ICaseReportingDataProcessDao dashboardDataProcessDao;

	@Autowired
	UserBean userbean;

	@Autowired
	CaseReportingDetailsHelper dashboardCaseDetailsHelper;

	private static final Logger LOG = LogManager.getRootLogger();

	@Override
	public CaseOutcomeCountRes getLatestCount() throws AzureServiceException, AccountNotFoundException,
			RecentCaseNotFoundException, DashboardCaseException {

		final String methodName = "getLatestCount";
		LOG.debug(methodName, "::getLatestCount Method Started.CorrelationId:-{} OID:-{}", userbean.getCorrelationId(),
				userbean.getUserObjectId());

		CaseOutcomeCountRes getLatestOutcome = new CaseOutcomeCountRes();

		LOG.debug(methodName, "::Organisation list is not empty.CorrelationId:-{} OID:-{},accountIds",
				userbean.getCorrelationId(), userbean.getUserObjectId(), userbean.getGroups());

		final List<String> adAccountIds = dashboardDataProcessDao.getAccountIds(userbean.getUserObjectId());
		if (CollectionUtils.isEmpty(adAccountIds)) {
			LOG.info("Data is not present for given OID");
			getLatestOutcome.setStatus(MSG_FAILURE);
			throw new AccountNotFoundException("Account not found in repository");
		}

		final List<CaseLatestOutCome> latestOutcomeCountSQL = Optional
				.ofNullable(dashboardDataProcessDao.getLatestOutcomeCount(adAccountIds))
				.orElseThrow(() -> new RecentCaseNotFoundException("Recent case not found"));
		List<CaseOutcomeCount> latestCases = dashboardCaseDetailsHelper.getCasesCountDetails(latestOutcomeCountSQL);
		getLatestOutcome.setCaseoutcomecount(latestCases);
		getLatestOutcome.setStatus(MSG_SUCCESS);

		LOG.debug("getLatestCount Method Ended.CorrelationId:-{} OID:-{}", userbean.getCorrelationId(),
				userbean.getUserObjectId());
		return getLatestOutcome;
	}

}
