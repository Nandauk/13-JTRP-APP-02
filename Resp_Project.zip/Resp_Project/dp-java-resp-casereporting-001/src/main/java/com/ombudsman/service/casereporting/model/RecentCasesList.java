package com.ombudsman.service.casereporting.model;

public class RecentCasesList {
	
	private String incidentid; //Primary Key
	private String ticketnumber; // Case Reference - incident
	private String fos_reference; // Business Reference - fos_reference, fos_extendedreference - fos_caselink
	private String fos_dateofreferral;    //Enquiry Date - incident
	private String fos_datecasefirstmovedtoinvestigation;  //Conversion Date - incident
	private String fos_dateofevent;  // Event Date - incident
	private String fos_categorycode; // Awaiting action from business - task
	private String br_required; //14+ Conversion Date
	private String fos_prioritycode; //Priority/Standard
	
	public String getIncidentid() {
		return incidentid;
	}
	public void setIncidentid(String incidentid) {
		this.incidentid = incidentid;
	}
	public String getTicketnumber() {
		return ticketnumber;
	}
	public void setTicketnumber(String ticketnumber) {
		this.ticketnumber = ticketnumber;
	}
	public String getFos_reference() {
		return fos_reference;
	}
	public void setFos_reference(String fos_reference) {
		this.fos_reference = fos_reference;
	}
	public String getFos_dateofreferral() {
		return fos_dateofreferral;
	}
	public void setFos_dateofreferral(String fos_dateofreferral) {
		this.fos_dateofreferral = fos_dateofreferral;
	}
	public String getFos_datecasefirstmovedtoinvestigation() {
		return fos_datecasefirstmovedtoinvestigation;
	}
	public void setFos_datecasefirstmovedtoinvestigation(String fos_datecasefirstmovedtoinvestigation) {
		this.fos_datecasefirstmovedtoinvestigation = fos_datecasefirstmovedtoinvestigation;
	}
	public String getFos_dateofevent() {
		return fos_dateofevent;
	}
	public void setFos_dateofevent(String fos_dateofevent) {
		this.fos_dateofevent = fos_dateofevent;
	}
	public String getFos_categorycode() {
		return fos_categorycode;
	}
	public void setFos_categorycode(String fos_categorycode) {
		this.fos_categorycode = fos_categorycode;
	}
	public String getBr_required() {
		return br_required;
	}
	public void setBr_required(String br_required) {
		this.br_required = br_required;
	}
	public String getFos_prioritycode() {
		return fos_prioritycode;
	}
	public void setFos_prioritycode(String fos_prioritycode) {
		this.fos_prioritycode = fos_prioritycode;
	}
	

}
