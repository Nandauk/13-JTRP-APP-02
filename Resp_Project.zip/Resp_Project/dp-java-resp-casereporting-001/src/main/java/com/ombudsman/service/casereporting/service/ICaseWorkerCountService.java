package com.ombudsman.service.casereporting.service;

import com.ombudsman.service.casereporting.exception.AccountNotFoundException;
import com.ombudsman.service.casereporting.exception.DashboardCaseException;
import com.ombudsman.service.casereporting.exception.RecentCaseNotFoundException;
import com.ombudsman.service.casereporting.model.response.CaseWorkerCaseOwnerCountRes;
import com.ombudsman.service.casereporting.model.response.OpenCaseCountByStatusRes;
import com.ombudsman.service.casereporting.model.response.OpenCaseCountRes;

public interface ICaseWorkerCountService {
	
	public CaseWorkerCaseOwnerCountRes getCaseOwnerCount() throws DashboardCaseException, AccountNotFoundException;
	
	public OpenCaseCountByStatusRes getOpenCaseCount() throws RecentCaseNotFoundException, AccountNotFoundException, DashboardCaseException;
	
	public OpenCaseCountRes getOpenCaseCountGeneric() throws  AccountNotFoundException, DashboardCaseException;
	
}
