package com.ombudsman.service.casereporting.dto;

public interface ViewCaseCountProjectionDto {

	public String getId();
	public String getViewid();
	public String getName();
	public String getInvestigationcount();
	public int getViewcount();
	public String getOmbudsmancount();
	public int getTotal();
}
