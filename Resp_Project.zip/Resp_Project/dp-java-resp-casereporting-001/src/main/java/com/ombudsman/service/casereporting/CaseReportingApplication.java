package com.ombudsman.service.casereporting;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.security.servlet.SecurityAutoConfiguration;
import org.springframework.cache.annotation.EnableCaching;

import com.microsoft.applicationinsights.attach.ApplicationInsights;
import com.microsoft.applicationinsights.connectionstring.ConnectionString;
import com.ombudsman.service.casereporting.common.KeyVaultUtil;

@SpringBootApplication(exclude = { SecurityAutoConfiguration.class })
public class CaseReportingApplication {
	
	static String connectionString=null;

	public static void main(String[] args) {
		
		ApplicationInsights.attach();
	     String KEYVAULT_URL=System.getenv("KEYVAULT_URL");
	     String APPLICATIONINSIGHTS_CONNECTION_STRING_S="secret-dp-logging-appidprespfunc-connectionstring";
	     connectionString=KeyVaultUtil.getSecret(KEYVAULT_URL, APPLICATIONINSIGHTS_CONNECTION_STRING_S);
		 ConnectionString.configure(connectionString);
		 
		SpringApplication.run(CaseReportingApplication.class, args);
	}

}
