package com.ombudsman.service.casereporting.serviceimpl.helper;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;

import com.ombudsman.service.casereporting.common.UserBean;
import com.ombudsman.service.casereporting.dto.CaseLatestOutCome;
import com.ombudsman.service.casereporting.dto.RecentCaseDto;
import com.ombudsman.service.casereporting.model.CaseOutcomeCount;
import com.ombudsman.service.casereporting.model.GenericCount;
import com.ombudsman.service.casereporting.model.RecentCasesList;

@Configuration
public class CaseReportingDetailsHelper {
	private static final String LATEST_OUTCOME = "Latest Outcome";

	@Autowired
	UserBean userbean;

	private static final Logger LOG = LogManager.getRootLogger();

	public List<CaseOutcomeCount> getCasesCountDetails(List<CaseLatestOutCome> latestOutcomeCountSQL) {

		List<GenericCount> caseOutcomeCountVar = new ArrayList<>();
		List<CaseOutcomeCount> caseOutcomecountList = new ArrayList<>();
		CaseOutcomeCount caseOutcomeCount = new CaseOutcomeCount();
		latestOutcomeCountSQL.forEach(idx -> {
			final GenericCount gen = new GenericCount();
			gen.setId("");
			gen.setCount(idx.getOutcomeCount());
			gen.setValue(idx.getOutcomeType());
			gen.setEmail("");
			caseOutcomeCountVar.add(gen);
		});
		caseOutcomeCount.setCaseoutcomecountvar(caseOutcomeCountVar);
		caseOutcomeCount
				.setTotalcount(caseOutcomeCountVar.stream().mapToInt(i -> Integer.parseInt(i.getCount())).sum());
		caseOutcomeCount.setCaseoutcomestatus(LATEST_OUTCOME);
		caseOutcomecountList.add(caseOutcomeCount);
		LOG.debug("getCasesCountDetails::{}", caseOutcomecountList);
		return caseOutcomecountList;
	}

	public List<RecentCasesList> getRecentCases(final List<RecentCaseDto> recentCaseDto)
			{
		LOG.debug("getRecentCases method started.CorrelationId:-{} OID:-{}", userbean.getCorrelationId(),
				userbean.getUserObjectId());
		final List<RecentCasesList> recentCases = new ArrayList<>();
		for (RecentCaseDto idx : recentCaseDto) {

			String fosDateCase = idx.getFos_dateofconversion();
			String fosDateOfreferral = idx.getFos_dateofreferral();
			RecentCasesList caseObj = new RecentCasesList();
			caseObj.setIncidentid(idx.getIncidentid());
			caseObj.setTicketnumber(idx.getTicketnumber());
			caseObj.setFos_dateofreferral(fosDateOfreferral);
			caseObj.setFos_datecasefirstmovedtoinvestigation(idx.getFos_datecasefirstmovedtoinvestigation());
			caseObj.setFos_dateofevent(idx.getFos_dateofevent());
			caseObj.setBr_required(idx.getBr_required());

			caseObj.setFos_reference(idx.getFos_reference());
			LOG.debug("Recent case for fosDateCase ::{} and fosDateOfreferral::{}", fosDateCase, fosDateOfreferral);

			recentCases.add(caseObj);
		}

		LOG.debug("getRecentCases method ended.CorrelationId:-{} OID:-{}", userbean.getCorrelationId(),
				userbean.getUserObjectId());
		return recentCases;

	}

	private LocalDateTime getLocalDateTime(final Date date) {
		return LocalDateTime.ofInstant(date.toInstant(), ZoneId.systemDefault());

	}

}
