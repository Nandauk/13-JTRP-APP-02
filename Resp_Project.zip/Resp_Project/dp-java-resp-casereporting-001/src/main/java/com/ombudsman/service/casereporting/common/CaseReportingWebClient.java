package com.ombudsman.service.casereporting.common;

import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.LogManager;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;

import com.ombudsman.service.casereporting.model.response.GenericResponse;

@Component
public class CaseReportingWebClient {
	

	@Autowired
	UserBean userbean;
	@Autowired
	CommonUtil commonUtil;
	private static String sessionApiUrl = "/ombudsmanservice/v1/sessionmanagement/verifytokenforresponse";
	private static final Logger LOG = LogManager.getRootLogger();
	public GenericResponse getResponseForSessionActivity(final String sessionType) throws Exception {
		final String sessionApiBaseUrl=commonUtil.SESSION_BASE_URL;
		LOG.info("Session api base Url :{}",sessionApiBaseUrl);		
		LOG.info("session type  :{}",sessionType);		
		return WebClient.create().get().uri(sessionApiBaseUrl + sessionApiUrl).headers(httpHeaders -> {
			httpHeaders.set("Authorization", "Bearer "+userbean.getAuthToken());
			httpHeaders.set("SessionType", sessionType);
		}).accept(MediaType.APPLICATION_JSON).retrieve().bodyToMono(GenericResponse.class).block();
	}


}
