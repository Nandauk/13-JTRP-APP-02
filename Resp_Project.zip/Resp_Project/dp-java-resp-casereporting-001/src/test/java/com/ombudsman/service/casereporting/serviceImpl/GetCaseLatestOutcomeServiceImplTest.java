package com.ombudsman.service.casereporting.serviceImpl;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.assertj.core.util.Lists;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ombudsman.service.casereporting.common.UserBean;
import com.ombudsman.service.casereporting.dao.ICaseReportingDataProcessDao;
import com.ombudsman.service.casereporting.dto.CaseLatestOutCome;
import com.ombudsman.service.casereporting.exception.AccountNotFoundException;
import com.ombudsman.service.casereporting.exception.AzureServiceException;
import com.ombudsman.service.casereporting.exception.DashboardCaseException;
import com.ombudsman.service.casereporting.exception.RecentCaseNotFoundException;
import com.ombudsman.service.casereporting.model.CaseOutcomeCount;
import com.ombudsman.service.casereporting.model.response.CaseOutcomeCountRes;
import com.ombudsman.service.casereporting.repository.RecentCaseRepository;
import com.ombudsman.service.casereporting.serviceimpl.GetCaseLatestOutcomeServiceImpl;
import com.ombudsman.service.casereporting.serviceimpl.helper.CaseReportingDetailsHelper;

@ExtendWith(SpringExtension.class)
class GetCaseLatestOutcomeServiceImplTest {

	@Mock
	private ICaseReportingDataProcessDao dashboardDataProcessDao;

	@Mock
	private RecentCaseRepository recentCaseRepository;

	@InjectMocks
	private GetCaseLatestOutcomeServiceImpl getCaseLatestOutcomeServiceImpl;

	@Mock
	CaseLatestOutCome caseLatestOutCome;
	@Mock 
	CaseReportingDetailsHelper dashboardCaseDetailsHelper;

	@Mock
	UserBean userBean;

	@Test
	void testGetLatestCount_Positive()
			throws  AzureServiceException, InterruptedException, JsonProcessingException, com.ombudsman.service.casereporting.exception.AccountNotFoundException, RecentCaseNotFoundException, DashboardCaseException {
		// Arrange
		CaseOutcomeCount latestCases=new CaseOutcomeCount();
		latestCases.setTotalcount(22);
		List<String> groups = Arrays.asList("group1", "group2");
		when(userBean.getGroups()).thenReturn(groups);
		String mockoid = "123abc";
	    when(userBean.getUserObjectId()).thenReturn(mockoid);
		
		when(dashboardDataProcessDao.getAccountIds(Mockito.anyString())).thenReturn(Lists.newArrayList("12345","67890"));

		List<CaseLatestOutCome> latestOutcomeCountSQL = new ArrayList<CaseLatestOutCome>();
		List<String> accIds = Lists.newArrayList("12345","67890");
		when(caseLatestOutCome.getCurrentMonthCount()).thenReturn("CurrentMonthCount");
		when(caseLatestOutCome.getLastMonthCount()).thenReturn("LastMonthCount");
		when(caseLatestOutCome.getOutcomeCount()).thenReturn("OutcomeCount");
		when(caseLatestOutCome.getOutcomeType()).thenReturn("OutcomeType");
		when(dashboardCaseDetailsHelper.getCasesCountDetails(latestOutcomeCountSQL)).thenReturn(Lists.newArrayList(latestCases));
		latestOutcomeCountSQL.add(caseLatestOutCome);
		when(dashboardDataProcessDao.getLatestOutcomeCount(accIds)).thenReturn(latestOutcomeCountSQL);

		// Act
		CaseOutcomeCountRes result = getCaseLatestOutcomeServiceImpl.getLatestCount();

		// Assert
		assertNotNull(result.getCaseoutcomecount());
		// Add more assertions based on your method's behavior
	}

	

	@Test
	void testGetLatestCount_EmptyAccountId()
			throws  AzureServiceException, InterruptedException, JsonProcessingException, com.ombudsman.service.casereporting.exception.AccountNotFoundException, RecentCaseNotFoundException, DashboardCaseException {
		// Arrange
		List<String> groups = Arrays.asList("group1", "group2");
		CaseOutcomeCountRes result=null;
		when(userBean.getGroups()).thenReturn(groups);
		when(dashboardDataProcessDao.getAccountIds(Mockito.anyString())).thenReturn(Lists.newArrayList());

		// Act
		try {
		 result = getCaseLatestOutcomeServiceImpl.getLatestCount();
		
		}catch(AccountNotFoundException ex) {
			assertNull(result);
		}

		
	}

	@Test
	void testGetLatestCount_ExceptionThrown()
			throws  AzureServiceException, InterruptedException, JsonProcessingException, com.ombudsman.service.casereporting.exception.AccountNotFoundException, RecentCaseNotFoundException, DashboardCaseException {
		// Arrange
		List<String> groups = Arrays.asList("group1", "group2");
		CaseOutcomeCountRes result=null;
		when(userBean.getGroups()).thenReturn(groups);
		when(dashboardDataProcessDao.getAccountIds(Mockito.anyString())).thenReturn(null);
		try {
		result = getCaseLatestOutcomeServiceImpl.getLatestCount();
		}catch(AccountNotFoundException ex) {
			assertNull(result);
		}
		
	}
}
