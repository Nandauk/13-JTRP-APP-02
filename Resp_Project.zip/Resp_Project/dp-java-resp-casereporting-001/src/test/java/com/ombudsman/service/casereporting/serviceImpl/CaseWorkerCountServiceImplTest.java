package com.ombudsman.service.casereporting.serviceImpl;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

import org.assertj.core.util.Lists;
import org.json.JSONException;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ombudsman.service.casereporting.common.UserBean;
import com.ombudsman.service.casereporting.dao.ICaseReportingDataProcessDao;
import com.ombudsman.service.casereporting.dto.CaseOwnerCountProjectionDto;
import com.ombudsman.service.casereporting.dto.OpenCaseCountByStatusResDto;
import com.ombudsman.service.casereporting.dto.OpenCaseCountSummeryDto;
import com.ombudsman.service.casereporting.exception.AccountNotFoundException;
import com.ombudsman.service.casereporting.exception.AzureServiceException;
import com.ombudsman.service.casereporting.exception.DashboardCaseException;
import com.ombudsman.service.casereporting.exception.RecentCaseNotFoundException;
import com.ombudsman.service.casereporting.model.response.CaseWorkerCaseOwnerCountRes;
import com.ombudsman.service.casereporting.model.response.OpenCaseCountByStatusRes;
import com.ombudsman.service.casereporting.model.response.OpenCaseCountRes;
import com.ombudsman.service.casereporting.repository.RecentCaseRepository;
import com.ombudsman.service.casereporting.serviceimpl.CaseWorkerCountServiceImpl;

@ExtendWith(SpringExtension.class)
class CaseWorkerCountServiceImplTest {

  @Mock
  UserBean userbean;

  @Mock
  private RecentCaseRepository recentCaseRepository;

  @InjectMocks
  private CaseWorkerCountServiceImpl casewoCountServiceImpl;

  @Mock
  private ICaseReportingDataProcessDao dashboardDataProcessDao;
  @Mock
  private OpenCaseCountSummeryDto openCaseCountSummery;
  @Mock
  CaseOwnerCountProjectionDto caseOwnerCountProjectionDto;
  @Mock
  OpenCaseCountByStatusResDto openCaseCountByStatusResDto;

  @Test
  void testGetCaseOwnerCount_Positive()
      throws AzureServiceException, InterruptedException,
      JsonProcessingException, DashboardCaseException, AccountNotFoundException {
    // Arrange
    List<String> groups = Arrays.asList("group1", "group2");
    when(userbean.getGroups()).thenReturn(groups);
    String mockoid = "123abc";
    when(userbean.getUserObjectId()).thenReturn(mockoid);
    when(dashboardDataProcessDao.getAccountIds(Mockito.anyString())).thenReturn(Lists.newArrayList("12345"));
    List<CaseOwnerCountProjectionDto> caseOwnerDetails =
        new ArrayList<CaseOwnerCountProjectionDto>();
    when(caseOwnerCountProjectionDto.getCustomerid()).thenReturn("1");
    when(caseOwnerCountProjectionDto.getEmailaddress()).thenReturn("test@gmail.com");
    when(caseOwnerCountProjectionDto.getIncident_count()).thenReturn("3");
    when(caseOwnerCountProjectionDto.getOwnername()).thenReturn("Ownername");
    caseOwnerDetails.add(caseOwnerCountProjectionDto);
    when(caseOwnerCountProjectionDto.getOwnername()).thenReturn("Ownername");

    when(dashboardDataProcessDao.getCaseOwnerCountSQL(anyList())).thenReturn(caseOwnerDetails);

    // Act
    CaseWorkerCaseOwnerCountRes result = casewoCountServiceImpl.getCaseOwnerCount();

    // Assert
    assertNotNull(result);
    assertEquals("Success", result.getStatus().toString());
    assertEquals("1", result.getTotalcount());
    assertEquals(1, result.getCaseworkercountlist().size());
  }

  

  @Test
  void testGetCaseOwnerCount_ExceptionThrown()
      throws  AzureServiceException, InterruptedException,
      JsonProcessingException, DashboardCaseException, AccountNotFoundException {
    // Arrange
    List<String> groups = Arrays.asList("group1", "group2");
    when(userbean.getGroups()).thenReturn(groups);
    // Act
    CaseWorkerCaseOwnerCountRes result = null;
    try {
      result = casewoCountServiceImpl.getCaseOwnerCount();
    } catch (AccountNotFoundException ex) {
      // Assert
      assertNull(result);
    }

  }

  @Test
  void testGetOpenCaseCount_Positive()
      throws JsonProcessingException, RecentCaseNotFoundException, AccountNotFoundException {
    // Arrange
    List<String> groups = Arrays.asList("group1", "group2");
    when(userbean.getGroups()).thenReturn(groups);
    String mockoid = "123abc";
    when(userbean.getUserObjectId()).thenReturn(mockoid);
    when(dashboardDataProcessDao.getAccountIds(Mockito.anyString())).thenReturn(Lists.newArrayList("accountId1","accountId2"));

    List<OpenCaseCountByStatusResDto> openCaseCountSummeryMap = new ArrayList<>();
    when(openCaseCountByStatusResDto.getCasestagename()).thenReturn("Casestagename");
    //when(openCaseCountByStatusResDto.getStatuscode()).thenReturn("testcode");
    //when(openCaseCountByStatusResDto.getStatuscodename()).thenReturn("test");
    when(openCaseCountByStatusResDto.getTotalrecordcount()).thenReturn(2);
    when(openCaseCountByStatusResDto.getCaseprogressname()).thenReturn("testcode");
    when(openCaseCountByStatusResDto.getCaseprogresscode()).thenReturn("test");
    openCaseCountSummeryMap.add(openCaseCountByStatusResDto);
    when(dashboardDataProcessDao.getOpenCaseCount(Arrays.asList("accountId1", "accountId2")))
        .thenReturn(openCaseCountSummeryMap); 

    // Act
    OpenCaseCountByStatusRes result = casewoCountServiceImpl.getOpenCaseCount();
    // Assert
    assertNotNull(result);
    System.out.println(result.getCaseprogresscount().size());
    assertEquals("Success", result.getStatus());
    assertEquals(1, result.getCaseprogresscount().size());

  }

	/*
	 * @Test void testGetOpenCaseCount_EmptyGroups() throws JsonProcessingException,
	 * RecentCaseNotFoundException, AccountNotFoundException { // Arrange
	 * when(userbean.getGroups()).thenReturn(Collections.emptyList()); // Act
	 * OpenCaseCountByStatusRes result = casewoCountServiceImpl.getOpenCaseCount();
	 * 
	 * // Assert assertNotNull(result); assertEquals("Failure..",
	 * result.getStatus()); assertEquals("Organisation not exist in Phoenix.",
	 * result.getMessage()); }
	 */
	/*
	 * @Test void testGetOpenCaseCount_EmptyAccountId() throws
	 * JsonProcessingException, RecentCaseNotFoundException,
	 * AccountNotFoundException { // Arrange List<String> groups =
	 * Arrays.asList("group1", "group2");
	 * when(dashboardDataProcessDao.getAccountIds(Mockito.anyString())).thenReturn(
	 * Lists.newArrayList());
	 * 
	 * // Act OpenCaseCountByStatusRes result =
	 * casewoCountServiceImpl.getOpenCaseCount();
	 * 
	 * // Assert assertNotNull(result); assertEquals("Failure..",
	 * result.getStatus()); assertEquals("Organisation not exist in Phoenix.",
	 * result.getMessage()); }
	 */
  @Test
  void testGetOpenCaseCount_ExceptionThrown()
      throws JsonProcessingException, RecentCaseNotFoundException, AccountNotFoundException {
    // Arrange
    List<String> groups = Arrays.asList("group1", "group2");
    when(userbean.getGroups()).thenReturn(groups);
    when(dashboardDataProcessDao.getAccountIds(Mockito.anyString())).thenReturn(null);
    // Act
    OpenCaseCountByStatusRes result = null;
    try {
      result = casewoCountServiceImpl.getOpenCaseCount();
    } catch (AccountNotFoundException | RecentCaseNotFoundException ex) {
      // Assert
      assertNull(result);
    }
  }

  @Test
  void testGetOpenCaseCountGeneric_Positive()
      throws  AzureServiceException, InterruptedException, JSONException,
      IOException, AccountNotFoundException, DashboardCaseException {
    // Arrange
    List<String> groups = Arrays.asList("group1", "group2");
    when(userbean.getGroups()).thenReturn(groups);
    String mockoid = "123abc";
    when(userbean.getUserObjectId()).thenReturn(mockoid);
    when(openCaseCountSummery.getAwaitingactions()).thenReturn("Awaitingactions");
    when(openCaseCountSummery.getDuecasecount()).thenReturn("Duecasecount");
    when(openCaseCountSummery.getOpencasecount()).thenReturn("Opencasecount");
    when(openCaseCountSummery.getOutcomecasecount()).thenReturn("Outcomecasecount");
    when(openCaseCountSummery.getPrioritycasecount()).thenReturn("Prioritycasecoun");

    when(dashboardDataProcessDao.getAccountIds(Mockito.anyString())).thenReturn(Lists.newArrayList("1234"));
    when(dashboardDataProcessDao.getCaseCountSummery(any())).thenReturn(openCaseCountSummery);

    // Act
    OpenCaseCountRes result = casewoCountServiceImpl.getOpenCaseCountGeneric();

    // Assert
    assertNotNull(result);
    assertEquals("Success", result.getStatus());
    assertEquals("Awaitingactions", result.getTotalawaitingyourresponse());
    assertEquals("Outcomecasecount", result.getTotallatestoutcomelastweek());
    assertEquals("Opencasecount", result.getTotalopencases());
    assertEquals("Duecasecount", result.getTotaloverduecases());
    assertEquals("Prioritycasecoun", result.getTotalprioritycases());
  }

  

  @Test
  void testGetOpenCaseCountGeneric_ExceptionThrown()
      throws AzureServiceException, InterruptedException, JSONException,
      IOException, AccountNotFoundException, DashboardCaseException {
    List<String> groups = Arrays.asList("group1", "group2");
    when(userbean.getGroups()).thenReturn(groups);
    when(recentCaseRepository.getAccountId(groups.stream().collect(Collectors.joining(","))))
        .thenReturn(null);
    // Act
    OpenCaseCountRes result = null;
    try {
      result = casewoCountServiceImpl.getOpenCaseCountGeneric();
    } catch (AccountNotFoundException ex) {
      // Assert
      assertNull(result);
    }
  }

}
