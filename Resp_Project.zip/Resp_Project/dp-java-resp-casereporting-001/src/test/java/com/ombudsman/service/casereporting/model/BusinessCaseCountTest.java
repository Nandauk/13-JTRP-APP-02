package com.ombudsman.service.casereporting.model;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import java.util.ArrayList;
import java.util.List;

class BusinessCaseCountTest {

    @Test
    void testGettersAndSetters() {
        // Create an instance of BusinessCaseCount
        BusinessCaseCount businessCaseCount = new BusinessCaseCount();

        // Test 'businesscount' property
        List<GenericCount> genericCounts = new ArrayList<>();
        businessCaseCount.setBusinesscount(genericCounts);
        assertEquals(genericCounts, businessCaseCount.getBusinesscount(), "The businesscount should match the set value.");

        // Test 'casestatus' property
        businessCaseCount.setCasestatus("Open");
        assertEquals("Open", businessCaseCount.getCasestatus(), "The casestatus should match the set value.");

        // Test 'totalcount' property
        businessCaseCount.setTotalcount("100");
        assertEquals("100", businessCaseCount.getTotalcount(), "The totalcount should match the set value.");
    }
}
