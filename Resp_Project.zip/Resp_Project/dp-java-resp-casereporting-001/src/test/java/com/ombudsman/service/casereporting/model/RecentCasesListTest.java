package com.ombudsman.service.casereporting.model;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

class RecentCasesListTest {

    @Test
    void testGettersAndSetters() {
        // Create an instance of RecentCasesList
        RecentCasesList recentCasesList = new RecentCasesList();

        // Test 'incidentid' property
        recentCasesList.setIncidentid("INC12345");
        assertEquals("INC12345", recentCasesList.getIncidentid(), "The incidentid should match the set value.");

        // Test 'ticketnumber' property
        recentCasesList.setTicketnumber("TCK12345");
        assertEquals("TCK12345", recentCasesList.getTicketnumber(), "The ticketnumber should match the set value.");

        // Test 'fos_reference' property
        recentCasesList.setFos_reference("FOS45678");
        assertEquals("FOS45678", recentCasesList.getFos_reference(), "The fos_reference should match the set value.");

        // Test 'fos_dateofreferral' property
        recentCasesList.setFos_dateofreferral("2025-03-01");
        assertEquals("2025-03-01", recentCasesList.getFos_dateofreferral(), "The fos_dateofreferral should match the set value.");

        // Test 'fos_datecasefirstmovedtoinvestigation' property
        recentCasesList.setFos_datecasefirstmovedtoinvestigation("2025-03-05");
        assertEquals("2025-03-05", recentCasesList.getFos_datecasefirstmovedtoinvestigation(), "The fos_datecasefirstmovedtoinvestigation should match the set value.");

        // Test 'fos_dateofevent' property
        recentCasesList.setFos_dateofevent("2025-02-28");
        assertEquals("2025-02-28", recentCasesList.getFos_dateofevent(), "The fos_dateofevent should match the set value.");

        // Test 'fos_categorycode' property
        recentCasesList.setFos_categorycode("CATEGORY01");
        assertEquals("CATEGORY01", recentCasesList.getFos_categorycode(), "The fos_categorycode should match the set value.");

        // Test 'br_required' property
        recentCasesList.setBr_required("YES");
        assertEquals("YES", recentCasesList.getBr_required(), "The br_required should match the set value.");

        // Test 'fos_prioritycode' property
        recentCasesList.setFos_prioritycode("High");
        assertEquals("High", recentCasesList.getFos_prioritycode(), "The fos_prioritycode should match the set value.");
    }
}
