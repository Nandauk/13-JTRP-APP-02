package com.ombudsman.service.casereporting.serviceImpl;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.assertj.core.util.Lists;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.ombudsman.service.casereporting.common.UserBean;
import com.ombudsman.service.casereporting.dao.ICaseReportingDataProcessDao;
import com.ombudsman.service.casereporting.dto.ViewCaseCountProjectionDto;
import com.ombudsman.service.casereporting.exception.AccountNotFoundException;
import com.ombudsman.service.casereporting.model.response.CaseTypeCountRes;
import com.ombudsman.service.casereporting.repository.RecentCaseRepository;
import com.ombudsman.service.casereporting.serviceimpl.CaseTypeCountServiceImpl;

@ExtendWith(SpringExtension.class)
class CaseTypeCountServiceImplTest {

	@Mock
	private ICaseReportingDataProcessDao dashboardDataProcessDao;

	@Mock
	private RecentCaseRepository recentCaseRepository;
	@InjectMocks
	private CaseTypeCountServiceImpl caseTypeCountServiceImpl;
	@Mock
	UserBean userbean;
	@Mock
	ViewCaseCountProjectionDto viewCaseCountProjectionDto;

	@Test
	void testGetCaseTypeCount_Positive() throws Exception {
		// Arrange
		List<String> groups = Arrays.asList("group1", "group2");
		when(userbean.getGroups()).thenReturn(groups);
		String mockOid = "123Abc";
		when(userbean.getUserObjectId()).thenReturn(mockOid);
		when(dashboardDataProcessDao.getAccountIds(Mockito.anyString())).thenReturn(Lists.newArrayList("123","456","789"));
		List<ViewCaseCountProjectionDto> caseCountList = new ArrayList<>();
		when(viewCaseCountProjectionDto.getInvestigationcount()).thenReturn("2");
		when(viewCaseCountProjectionDto.getId()).thenReturn("12");
		when(viewCaseCountProjectionDto.getName()).thenReturn("test");
		when(viewCaseCountProjectionDto.getOmbudsmancount()).thenReturn("2");
		when(viewCaseCountProjectionDto.getTotal()).thenReturn(54);
		when(viewCaseCountProjectionDto.getViewcount()).thenReturn(4);
		when(viewCaseCountProjectionDto.getViewid()).thenReturn("2");
		caseCountList.add(viewCaseCountProjectionDto);
		when(dashboardDataProcessDao.getBusnissCountList(Arrays.asList("123", "456", "789"))).thenReturn(caseCountList);

		// Act
		CaseTypeCountRes result = caseTypeCountServiceImpl.getCaseTypeCount();

		// Assert
		assertNotNull(result);
		assertEquals(1, result.getComplainantcount().size());
		// Add more assertions based on your method's behavior
	}

	

	@Test
	void testGetCaseTypeCount_ExceptionThrown() throws Exception {
		// Arrange
		List<String> groups = Arrays.asList("group1", "group2");
		CaseTypeCountRes result = null;
		when(userbean.getGroups()).thenReturn(groups);
		when(dashboardDataProcessDao.getAccountIds(Mockito.anyString())).thenReturn(null);

		// Act
		try {
			result = caseTypeCountServiceImpl.getCaseTypeCount();
		} catch (AccountNotFoundException ex) {
			assertNull(result);
		}
	}
}