package com.ombudsman.service.casereporting.serviceimplhelper;


import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.ombudsman.service.casereporting.common.UserBean;
import com.ombudsman.service.casereporting.dto.CaseLatestOutCome;
import com.ombudsman.service.casereporting.dto.RecentCaseDto;
import com.ombudsman.service.casereporting.exception.DashboardDataParseException;
import com.ombudsman.service.casereporting.model.CaseOutcomeCount;
import com.ombudsman.service.casereporting.model.GenericCount;
import com.ombudsman.service.casereporting.model.RecentCasesList;
import com.ombudsman.service.casereporting.model.response.GenericResponse;
import com.ombudsman.service.casereporting.serviceimpl.helper.CaseReportingDetailsHelper;

import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
@ExtendWith(SpringExtension.class)
public class DashboardCaseDetailsHelperTest {

	@InjectMocks
	CaseReportingDetailsHelper testInstance;
	
	@Mock
	UserBean userbean;
	@Mock
	GenericCount genericCount;
	@Mock
	CaseLatestOutCome CaseLatestOutCome;
	@Mock
	CaseOutcomeCount CaseOutcomeCount;
	@Mock
	List<CaseLatestOutCome> mocklatestOutcomeCountSQL;
	
	  @Test
	    public void testGetCasesCountDetails() {
	        List<CaseLatestOutCome> latestOutcomeCountSQL = new ArrayList<>();
	        CaseLatestOutCome outCome = mock(CaseLatestOutCome.class);
	        when(outCome.getOutcomeType()).thenReturn("Early Access");
	        
	        
	        List<GenericCount> caseOutcomeCountVar = new ArrayList<>();
	        
	        GenericCount gen = mock(GenericCount.class);
	        when(gen.getId()).thenReturn("id1");
	        when(gen.getCount()).thenReturn("456");
	        when(gen.getEmail()).thenReturn("arun@fos.org.uk");
	        when(gen.getValue()).thenReturn("val1");
	        caseOutcomeCountVar.add(gen);
	        when(outCome.getOutcomeCount()).thenReturn("totalcount");
			List<CaseOutcomeCount> caseOutcomecountList = new ArrayList<>();
			latestOutcomeCountSQL.add(outCome);
			CaseOutcomeCount caseOutcomeCount = mock(CaseOutcomeCount.class);

			when(caseOutcomeCount.getCaseoutcomestatus()).thenReturn("Success");
			when(caseOutcomeCount.getCaseoutcomecountvar()).thenReturn(caseOutcomeCountVar);
			when(caseOutcomeCount.getTotalcount()).thenReturn(10);
			caseOutcomecountList.add(caseOutcomeCount);
			
			assertNotNull(gen.getCount());
			Integer.parseInt(gen.getCount());
	        List<CaseOutcomeCount> actualOutcomeCountList = testInstance.getCasesCountDetails(mocklatestOutcomeCountSQL);

	        assertNotNull(actualOutcomeCountList);
	        assertEquals(1, actualOutcomeCountList.size());
	    }
	  
	  
	  
	  
	  @Test
	    public void testGetRecentCases() throws Exception {
		  List<RecentCaseDto> recentCaseDto = new ArrayList<>();
		  List<RecentCasesList> recentCasesList = new ArrayList<>();
		  RecentCasesList recentcaseList = new RecentCasesList();
		  recentcaseList.setBr_required("sdfsdf");
		  recentCasesList.add(recentcaseList);
	        RecentCaseDto recentCase = mock(RecentCaseDto.class);
	        when(recentCase.getFos_datecasefirstmovedtoinvestigation()).thenReturn("2022-01-01");
	        when(recentCase.getFos_dateofevent()).thenReturn("2022-01-01");
	        when(recentCase.getFos_dateofreferral()).thenReturn("2022-01-01");
	        when(recentCase.getFos_prioritycode()).thenReturn("343vvvv");
	        when(recentCase.getFos_reference()).thenReturn("ssdsgag");
	        when(recentCase.getIncidentid()).thenReturn("sdfsf");
	        when(recentCase.getTicketnumber()).thenReturn("adfasafsdf");
	        recentCaseDto.add(recentCase);

	        List<RecentCasesList> actualRecentCases = testInstance.getRecentCases(recentCaseDto);

	        assertEquals(1, actualRecentCases.size());
	    }
	  
	  
	 
}
