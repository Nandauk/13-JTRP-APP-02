package com.ombudsman.service.casereporting.exception;


import static org.junit.jupiter.api.Assertions.assertEquals;

import java.time.LocalDateTime;
import java.util.Locale;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit.jupiter.SpringExtension;
@ExtendWith(SpringExtension.class)
public class ResponseEntityBuilderTest {
	
	@InjectMocks
	ResponseEntityBuilder responseEntityBuilder;
	@Test
    public void testBuildMethod() {
       ApiError apiError = new ApiError(LocalDateTime.now(), HttpStatus.BAD_REQUEST, "Invalid input", "Error details");

       ResponseEntity<Object> responseEntity = responseEntityBuilder.build(apiError);

        assertEquals(HttpStatus.BAD_REQUEST, responseEntity.getStatusCode());
    }
	
	
	  
}
