package com.ombudsman.service.casereporting.model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

public class accountsTest {
	@Test
	void testGettersAndSetters() {
		// Create an instance of the 'account' class
		account accountEntity = new account();

		// Test 'accountcategorycode' property
		accountEntity.setAccountcategorycode(123L);
		assertEquals(123L, accountEntity.getAccountcategorycode());

		// Test 'name' property
		accountEntity.setName("Test Account");
		assertEquals("Test Account", accountEntity.getName());

		// Test 'parentaccountid' property
		accountEntity.setParentaccountid("Parent123");
		assertEquals("Parent123", accountEntity.getParentaccountid());

		// Test 'accountid' property
		accountEntity.setAccountid("Account123");
		assertEquals("Account123", accountEntity.getAccountid());
	}
}
