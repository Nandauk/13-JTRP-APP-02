package com.ombudsman.service.casereporting.serviceImpl;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.apache.commons.collections4.CollectionUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.ombudsman.service.casereporting.common.UserBean;
import com.ombudsman.service.casereporting.dao.ICaseReportingDataProcessDao;
import com.ombudsman.service.casereporting.dto.CaseLatestOutCome;
import com.ombudsman.service.casereporting.exception.AccountNotFoundException;
import com.ombudsman.service.casereporting.exception.DashboardCaseException;
import com.ombudsman.service.casereporting.model.response.FinalCaseOutcomeCountRes;
import com.ombudsman.service.casereporting.serviceimpl.FinalOutcomeCountServiceImpl;

@ExtendWith(MockitoExtension.class)
public class FinalOutcomeCountServiceImplTest {

    @InjectMocks
    private FinalOutcomeCountServiceImpl finalOutcomeCountService;

    @Mock
    private UserBean userBean;

    @Mock
    private ICaseReportingDataProcessDao dashboardDataProcessDao;

    @BeforeEach
    public void setUp() {
        when(userBean.getUserObjectId()).thenReturn("testUserId");
        when(userBean.getCorrelationId()).thenReturn("testCorrelationId");
        when(userBean.getGroups()).thenReturn(Collections.emptyList());
    }

    @Test
    public void testGetFinalOutcomeCount_Success() throws AccountNotFoundException, DashboardCaseException {
        List<String> accountIds = Arrays.asList("account1", "account2");

        // Create mocked instances of CaseLatestOutCome
        CaseLatestOutCome outcome1 = mock(CaseLatestOutCome.class);
        when(outcome1.getOutcomeType()).thenReturn("Outcome1");
        when(outcome1.getOutcomeCount()).thenReturn("10");
        when(outcome1.getCurrentMonthCount()).thenReturn("5");
        when(outcome1.getLastMonthCount()).thenReturn("5");

        CaseLatestOutCome outcome2 = mock(CaseLatestOutCome.class);
        when(outcome2.getOutcomeType()).thenReturn("Outcome2");
        when(outcome2.getOutcomeCount()).thenReturn("20");
        when(outcome2.getCurrentMonthCount()).thenReturn("10");
        when(outcome2.getLastMonthCount()).thenReturn("10");

        List<CaseLatestOutCome> outcomes = Arrays.asList(outcome1, outcome2);

        when(dashboardDataProcessDao.getAccountIds("testUserId")).thenReturn(accountIds);
        when(dashboardDataProcessDao.getFinalOutcomeCount(accountIds)).thenReturn(outcomes);

        FinalCaseOutcomeCountRes response = finalOutcomeCountService.getFinalOutcomeCount();

        assertNotNull(response);
        assertEquals("Success", response.getStatus());
        assertFalse(response.getCaseoutcomecount().isEmpty());
        verify(dashboardDataProcessDao, times(1)).getAccountIds("testUserId");
        verify(dashboardDataProcessDao, times(1)).getFinalOutcomeCount(accountIds);
    }


    @Test
    public void testGetFinalOutcomeCount_AccountNotFound() {
        when(dashboardDataProcessDao.getAccountIds("testUserId")).thenReturn(Collections.emptyList());

        AccountNotFoundException exception = assertThrows(AccountNotFoundException.class, () ->
                finalOutcomeCountService.getFinalOutcomeCount()
        );

        assertEquals("Account not found in repository", exception.getMessage());
        verify(dashboardDataProcessDao, times(1)).getAccountIds("testUserId");
        verify(dashboardDataProcessDao, never()).getFinalOutcomeCount(anyList());
    }

    @Test
    public void testGetFinalOutcomeCount_FinalOutcomeNotFound() {
        List<String> accountIds = Arrays.asList("account1", "account2");

        when(dashboardDataProcessDao.getAccountIds("testUserId")).thenReturn(accountIds);
        when(dashboardDataProcessDao.getFinalOutcomeCount(accountIds)).thenReturn(null);

        DashboardCaseException exception = assertThrows(DashboardCaseException.class, () ->
                finalOutcomeCountService.getFinalOutcomeCount()
        );

        assertEquals("Final outcome not found", exception.getMessage());
        verify(dashboardDataProcessDao, times(1)).getAccountIds("testUserId");
        verify(dashboardDataProcessDao, times(1)).getFinalOutcomeCount(accountIds);
    }
}
