package com.ombudsman.service.casereporting.exception;

import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
@ExtendWith(SpringExtension.class)
public class DashboardDataParseExceptionTest {
	
	 @Test
	   void testConstructor() {
	        String orgName = "Test Organization";

	        DashboardDataParseException exception = new DashboardDataParseException(orgName);

	        assertEquals(orgName, exception.getMessage());
	    }

}
