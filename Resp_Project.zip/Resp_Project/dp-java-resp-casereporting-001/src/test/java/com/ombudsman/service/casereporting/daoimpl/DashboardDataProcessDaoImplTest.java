package com.ombudsman.service.casereporting.daoimpl;


import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.assertj.core.util.Lists;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.dao.DataAccessException;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import com.ombudsman.service.casereporting.dto.CaseOwnerCountProjectionDto;
import com.ombudsman.service.casereporting.dto.OpenCaseCountByStatusResDto;
import com.ombudsman.service.casereporting.dto.OpenCaseCountSummeryDto;
import com.ombudsman.service.casereporting.dto.RecentCaseDto;
import com.ombudsman.service.casereporting.dto.ViewCaseCountProjectionDto;
import com.ombudsman.service.casereporting.dto.CaseLatestOutCome;
import com.ombudsman.service.casereporting.repository.RecentCaseRepository;
import com.ombudsman.service.casereporting.dao.ICaseReportingDataProcessDao;

@ExtendWith(SpringExtension.class)
public class DashboardDataProcessDaoImplTest {

	@InjectMocks
	CaseReportingDataProcessDaoImpl testInstance;
	@Mock
	RecentCaseRepository recentCaseRepository;
	@Mock
	CaseLatestOutCome caseLatestOutCome;
	
	OpenCaseCountSummeryDto openCaseCountSummeryDto;
	
	@Mock
	CaseOwnerCountProjectionDto CaseOwnerCountProjectionDto;
	
	@Mock
	ViewCaseCountProjectionDto ViewCaseCountProjectionDto;
	
	@Mock
     List<ViewCaseCountProjectionDto> expectedCounts;
	@Mock
	List<OpenCaseCountByStatusResDto> openCaseStatus;
	@Mock
	List<RecentCaseDto> recentCase;
	
	@Mock
	OpenCaseCountSummeryDto OpenCaseCountSummeryDto;
	
	@Mock
	List<CaseLatestOutCome> outcomeCount;
	
	@Mock
	List<CaseOwnerCountProjectionDto> ownerCounts;
	
	ICaseReportingDataProcessDao IDashboardDataProcessDao;
	
	@Test
	    void testGetAccountIds() {
	        List<String> groups = Arrays.asList("group1", "group2", "group3");
	        String accountId ="Account1";
	        when(testInstance.getAccountIds(Mockito.anyString())).thenReturn(Lists.newArrayList(accountId));
	        assertNotNull(accountId);
	    }
	
	
	 @Test
	    void testGetLatestOutcomeCount() {
	        List<String> accountIds = Arrays.asList("account1", "account2", "account3");

	        List<CaseLatestOutCome> outcomeCount = new ArrayList();
	        
	        CaseLatestOutCome mockInter = mock(CaseLatestOutCome.class);
	        when(mockInter.getOutcomeCount()).thenReturn("the latedt outcome count");
	        outcomeCount.add(mockInter);
	        
	        when(testInstance.getLatestOutcomeCount(accountIds)).thenReturn(outcomeCount);

	        assertNotNull(outcomeCount);
	    }
	 
	 @Test
	    void testGetCaseOwnerCountSQL() {
	        List<String> accountIds = Arrays.asList("account1", "account2", "account3");
	        when(testInstance.getCaseOwnerCountSQL(accountIds)).thenReturn(ownerCounts);
	        assertNotNull(ownerCounts);
	    }
	 
	 @Test
	    void testGetOpenCaseCount() {
	        List<String> accountIds = Arrays.asList("account1", "account2", "account3");

	        List<OpenCaseCountByStatusResDto> openCaseCounts = testInstance.getOpenCaseCount(accountIds);

	        assertNotNull(openCaseCounts);
	    }
	 
	 @Test
	    void testGetFetchRecentCase() {
	        List<String> accountIds = Arrays.asList("account1", "account2", "account3");

	        List<RecentCaseDto> recentCases = testInstance.getFetchRecentCase(accountIds);

	        assertNotNull(recentCases);
	    }
	 
	 @Test
	    void testGetCaseCountSummery() throws DataAccessException {
	        String accountIds = "account1,account2,account3";
	        OpenCaseCountSummeryDto mockDto = mock(OpenCaseCountSummeryDto.class);
	        
	        when(mockDto.getAwaitingactions()).thenReturn("Mocked Awaiting Actions");
	        when(mockDto.getOutcomecasecount()).thenReturn("Mocked Outcome Case Count");
	        when(mockDto.getOpencasecount()).thenReturn("Mocked Outcome Case Count");
	        Mockito.when(testInstance.getCaseCountSummery(accountIds)).thenReturn(mockDto);
	        assertNotNull(mockDto);
	    }
	 
	 @Test
	    void testGetFinalOutcomeCount() throws DataAccessException {
	        List<String> accountIds = Arrays.asList("account1", "account2", "account3");
	        List<String> outcomeTypes = Arrays.asList("type1", "type2");
	        List<CaseLatestOutCome> result = new ArrayList();
	        CaseLatestOutCome mockDto = mock(CaseLatestOutCome.class);
	        when(mockDto.getOutcomeCount()).thenReturn("Mocked outcome case ount");
	        result.add(mockDto);

	        Mockito.when(testInstance.getFinalOutcomeCount(accountIds)).thenReturn(result);

	         result = testInstance.getFinalOutcomeCount(accountIds);

	        assertNotNull(result);
	    }
	 
	 @Test
	    void testGetBusnissCountList() throws DataAccessException {
	        List<String> accountIds = Arrays.asList("account1", "account2", "account3");
	        Mockito.when(recentCaseRepository.getBusnissCountList(accountIds))
	            .thenReturn(expectedCounts);

	        List<ViewCaseCountProjectionDto> result = testInstance.getBusnissCountList(accountIds);

	        assertNotNull(result);
	        assertEquals(expectedCounts, result);
	    }
	 
}
