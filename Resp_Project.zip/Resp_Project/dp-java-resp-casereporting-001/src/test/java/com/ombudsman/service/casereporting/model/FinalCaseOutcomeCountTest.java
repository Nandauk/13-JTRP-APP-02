package com.ombudsman.service.casereporting.model;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import java.util.ArrayList;
import java.util.List;

class FinalCaseOutcomeCountTest {

    @Test
    void testGettersAndSetters() {
        // Create an instance of FinalCaseOutcomeCount
        FinalCaseOutcomeCount finalCaseOutcomeCount = new FinalCaseOutcomeCount();

        // Test 'caseoutcomecountvar' property
        List<FinalOutComeCount> caseOutcomeCountList = new ArrayList<>();
        finalCaseOutcomeCount.setCaseoutcomecountvar(caseOutcomeCountList);
        assertEquals(caseOutcomeCountList, finalCaseOutcomeCount.getCaseoutcomecountvar(), "The caseoutcomecountvar should match the set value.");

        // Test 'caseoutcomestatus' property
        finalCaseOutcomeCount.setCaseoutcomestatus("Approved");
        assertEquals("Approved", finalCaseOutcomeCount.getCaseoutcomestatus(), "The caseoutcomestatus should match the set value.");

        // Test 'totalcount' property
        finalCaseOutcomeCount.setTotalcount(500);
        assertEquals(500, finalCaseOutcomeCount.getTotalcount(), "The totalcount should match the set value.");

        // Test 'currentmonthcount' property
        finalCaseOutcomeCount.setCurrentmonthcount(200);
        assertEquals(200, finalCaseOutcomeCount.getCurrentmonthcount(), "The currentmonthcount should match the set value.");

        // Test 'lastmonthcount' property
        finalCaseOutcomeCount.setLastmonthcount(300);
        assertEquals(300, finalCaseOutcomeCount.getLastmonthcount(), "The lastmonthcount should match the set value.");
    }
}
