
package com.ombudsman.service.casereporting.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.google.common.collect.Lists;
import com.ombudsman.service.casereporting.common.CommonUtil;
import com.ombudsman.service.casereporting.common.UserBean;
import com.ombudsman.service.casereporting.common.ValidateUserSession;
import com.ombudsman.service.casereporting.model.request.GetFinalOutcomeCountReq;
import com.ombudsman.service.casereporting.model.response.CaseOutcomeCountRes;
import com.ombudsman.service.casereporting.model.response.CaseTypeCountRes;
import com.ombudsman.service.casereporting.model.response.CaseWorkerCaseOwnerCountRes;
import com.ombudsman.service.casereporting.model.response.FinalCaseOutcomeCountRes;
import com.ombudsman.service.casereporting.model.response.GenericResponse;
import com.ombudsman.service.casereporting.model.response.OpenCaseCountByStatusRes;
import com.ombudsman.service.casereporting.model.response.OpenCaseCountRes;
import com.ombudsman.service.casereporting.model.response.RecentCasesRes;
import com.ombudsman.service.casereporting.service.ICaseLatestOutcomeService;
import com.ombudsman.service.casereporting.service.ICaseTypeCountService;
import com.ombudsman.service.casereporting.service.ICaseWorkerCountService;
import com.ombudsman.service.casereporting.service.IFinalOutcomeCountService;
import com.ombudsman.service.casereporting.service.ILoginService;
import com.ombudsman.service.casereporting.service.IRecentCasesService;

@ExtendWith(SpringExtension.class)
class CaseReportingControllerTest {

	@InjectMocks
	private CaseReportingController testInstance;
	@Mock
	private IFinalOutcomeCountService finalOutcomeCountService;
	@Mock
	private ICaseLatestOutcomeService getCaseLatestOutcomeService;

	@Mock
	private ICaseWorkerCountService caseWorkerCountService;

	@Mock
	private ICaseTypeCountService caseTypeCountService;

	@Mock
	private IRecentCasesService recentCasesService;

	@Mock
	private GetFinalOutcomeCountReq mMockGetFinalOutcomeCountReq;

	@Mock
	private RecentCasesRes recentCasesRes;

	@Mock
	private CaseTypeCountRes caseTypeCountRes;

	@Mock
	private OpenCaseCountRes openCaseCountRes;

	
	@Mock
	CommonUtil commonUtil;
	
	@Mock
	private CaseOutcomeCountRes caseOutcomeCountRes;

	@Mock
	ILoginService loginService;
	@Mock
	GenericResponse response;
	@Mock
	ResponseEntity<CaseOutcomeCountRes> responseEntity;
	@Mock
	CaseOutcomeCountRes caseOutCome;
	@Mock
	ResponseEntity<String> response1;
	@Mock
	ValidateUserSession mMockValidateUserSession;

	@Mock
	UserBean userbean;
	private String VAILD = "valid";

	@BeforeEach
	public void setUp() throws Exception {
		when(userbean.getRoles()).thenReturn(Lists.newArrayList("CaseWorker"));

	}

	

	@DisplayName("shouldGetFinalOutcomeCountSuccessfully")
	@Test
	void shouldGetFinalOutcomeCountSuccessfully() throws Exception {
		when(userbean.getRoles()).thenReturn(Lists.newArrayList("CaseWorker"));

		when(mMockValidateUserSession.isValidSession()).thenReturn(true);
		when(response.getStatus()).thenReturn(VAILD);
		FinalCaseOutcomeCountRes response = new FinalCaseOutcomeCountRes();
		response.setMessage("Success");

		mMockGetFinalOutcomeCountReq.setResolutionRange("resolutionDateEncrypted");

		Mockito.when(finalOutcomeCountService.getFinalOutcomeCount()).thenReturn(response);
		ResponseEntity<FinalCaseOutcomeCountRes> responseEntity = testInstance
				.getFinalOutcomeCount();

		verify(finalOutcomeCountService).getFinalOutcomeCount();
		assertNotNull(responseEntity);
		assertEquals("200 OK", responseEntity.getStatusCode().toString());

	}


	@DisplayName("getCaseOwnerCount")
	@Test
	void getCaseOwnerCountTest() throws Exception {
		when(response.getStatus()).thenReturn(VAILD);
		when(mMockValidateUserSession.isValidSession()).thenReturn(true);
		Mockito.when(userbean.getCorrelationId()).thenReturn("123456");
		CaseWorkerCaseOwnerCountRes response = new CaseWorkerCaseOwnerCountRes();
		response.setMessage("Sucess");
		assertNotNull(response);
		Mockito.when(caseWorkerCountService.getCaseOwnerCount()).thenReturn(response);
		ResponseEntity<CaseWorkerCaseOwnerCountRes> responseEntity = testInstance.getCaseOwnerCount();
		verify(caseWorkerCountService).getCaseOwnerCount();
		assertEquals("200 OK", responseEntity.getStatusCode().toString());
	}
	@DisplayName("getCaseOwnerCount")
	@Test
	void shouldNotgetCaseOwnerCountTest() throws Exception {
		when(response.getStatus()).thenReturn(VAILD);
		when(mMockValidateUserSession.isValidSession()).thenReturn(false);
		Mockito.when(userbean.getCorrelationId()).thenReturn("123456");
		CaseWorkerCaseOwnerCountRes response = new CaseWorkerCaseOwnerCountRes();
		response.setMessage("Sucess");
		assertNotNull(response);
		Mockito.when(caseWorkerCountService.getCaseOwnerCount()).thenReturn(response);
		ResponseEntity<CaseWorkerCaseOwnerCountRes> responseEntity = testInstance.getCaseOwnerCount();
	
	}

	

	@DisplayName("shouldgetLatestCountSuccessfully")
	@Test
	void ShouldGetLatestCountSuccessfully() throws Exception {
		response.setMessage("Success");
		when(response.getStatus()).thenReturn(VAILD);
		when(mMockValidateUserSession.isValidSession()).thenReturn(true);
		ResponseEntity<CaseOutcomeCountRes> response = testInstance.getLatestCount();

		assertNotNull(response);
		verify(getCaseLatestOutcomeService).getLatestCount();
		assertEquals("200 OK", response.getStatusCode().toString());
	}
	@DisplayName("ShouldNotGetLatestCountSuccessfully")
	@Test
	void ShouldNotTheGetLatestCountSuccessfully() throws Exception {
		response.setMessage("Success");
		when(response.getStatus()).thenReturn(VAILD);
		when(mMockValidateUserSession.isValidSession()).thenReturn(false);
		ResponseEntity<CaseOutcomeCountRes> response = testInstance.getLatestCount();

		assertNotNull(response);
		
	}
	@DisplayName("shouldgetLatestCountSuccessfully")
	@Test
	void ShouldNotGetLatestCountSuccessfully() throws Exception {
		response.setMessage("Success");
		when(response.getStatus()).thenReturn(VAILD);
		when(mMockValidateUserSession.isValidSession()).thenReturn(true);
		when(getCaseLatestOutcomeService.getLatestCount()).thenReturn(caseOutcomeCountRes);
		ResponseEntity<CaseOutcomeCountRes> response = testInstance.getLatestCount();

		assertNotNull(response);
		
	}

	

	@DisplayName("shouldGetCaseTypeCountSuccessfully")
	@Test
	void shouldGetCaseTypeCountSuccessfully() throws Exception {
		when(mMockValidateUserSession.isValidSession()).thenReturn(true);
		response.setMessage("Success");
		when(response.getStatus()).thenReturn(VAILD);
		Mockito.when(userbean.getCorrelationId()).thenReturn("123456");
		caseTypeCountRes.setMessage("Sucess");
		Mockito.when(caseTypeCountService.getCaseTypeCount()).thenReturn(caseTypeCountRes);
		ResponseEntity<CaseTypeCountRes> responseEntity = testInstance.getCaseTypeCount();
		verify(caseTypeCountService).getCaseTypeCount();
		assertEquals("200 OK", responseEntity.getStatusCode().toString());
		assertNotNull(caseTypeCountRes);

	}

	
	@DisplayName("shouldGetCaseCountSuccessfully")
	@Test
	void shouldGetCaseCountSuccessfully() throws Exception {
		response.setMessage("Success");
		when(mMockValidateUserSession.isValidSession()).thenReturn(true);
		when(response.getStatus()).thenReturn(VAILD);
		Mockito.when(userbean.getCorrelationId()).thenReturn("123456");
		Mockito.when(caseWorkerCountService.getOpenCaseCountGeneric()).thenReturn(openCaseCountRes);
		ResponseEntity<OpenCaseCountRes> responseEntity = testInstance.getCaseCount();
		verify(caseWorkerCountService).getOpenCaseCountGeneric();
		assertEquals("200 OK", responseEntity.getStatusCode().toString());

	}


	@DisplayName("shouldGetetRecentCaseListSuccessfully")

	@Test
	void shouldGetetRecentCaseListSuccessfully() throws Exception {
		response.setMessage("Success");
		when(mMockValidateUserSession.isValidSession()).thenReturn(true);
		when(response.getStatus()).thenReturn(VAILD);
		Mockito.when(userbean.getCorrelationId()).thenReturn("123456");
		recentCasesRes.setMessage("Sucess");
		Mockito.when(recentCasesService.getRecentCaseList()).thenReturn(recentCasesRes);
		ResponseEntity<RecentCasesRes> responseEntity = testInstance.getRecentCaseList();
		verify(recentCasesService).getRecentCaseList();
		assertEquals("200 OK", responseEntity.getStatusCode().toString());

	}


	@DisplayName("getOpenCaseCountByStatus")
	@Test
	void getOpenCaseCountByStatusTest() throws Exception {
		when(response.getStatus()).thenReturn(VAILD);
		when(mMockValidateUserSession.isValidSession()).thenReturn(true);
		Mockito.when(userbean.getCorrelationId()).thenReturn("123456");
		OpenCaseCountByStatusRes response = new OpenCaseCountByStatusRes();
		response.setMessage("Sucess");
		Mockito.when(caseWorkerCountService.getOpenCaseCount()).thenReturn(response);
		ResponseEntity<OpenCaseCountByStatusRes> responseEntity = testInstance.getOpenCaseCountByStatus();
		verify(caseWorkerCountService).getOpenCaseCount();
		assertEquals("200 OK", responseEntity.getStatusCode().toString());
		assertNotNull(response);
	}
	@DisplayName("getOpenCaseCountByStatus")
	@Test
	void shouldNotgetOpenCaseCountByStatusTest() throws Exception {
		when(response.getStatus()).thenReturn(VAILD);
		when(mMockValidateUserSession.isValidSession()).thenReturn(false);
		Mockito.when(userbean.getCorrelationId()).thenReturn("123456");
		OpenCaseCountByStatusRes response = new OpenCaseCountByStatusRes();
		response.setMessage("Sucess");
		Mockito.when(caseWorkerCountService.getOpenCaseCount()).thenReturn(response);
		ResponseEntity<OpenCaseCountByStatusRes> responseEntity = testInstance.getOpenCaseCountByStatus();
	//	verify(caseWorkerCountService).getOpenCaseCount();
		
	}


	
}