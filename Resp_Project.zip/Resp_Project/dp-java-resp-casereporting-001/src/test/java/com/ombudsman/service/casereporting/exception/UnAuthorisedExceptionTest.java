package com.ombudsman.service.casereporting.exception;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;
@ExtendWith(SpringExtension.class)
public class UnAuthorisedExceptionTest {
	@InjectMocks
	UnAuthorisedException UnAuthorisedException;
	 @Test
	   public void testConstructor() {
	        String orgName = "MyOrganization";

	        UnAuthorisedException exception = new UnAuthorisedException(orgName);

	        assertEquals(orgName, exception.getMessage());
	    }

}
