package com.ombudsman.service.casereporting.serviceImpl;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.assertj.core.util.Lists;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ombudsman.service.casereporting.common.UserBean;
import com.ombudsman.service.casereporting.dao.ICaseReportingDataProcessDao;
import com.ombudsman.service.casereporting.dto.RecentCaseDto;
import com.ombudsman.service.casereporting.exception.AccountNotFoundException;
import com.ombudsman.service.casereporting.exception.AzureServiceException;
import com.ombudsman.service.casereporting.exception.DashboardCaseException;
import com.ombudsman.service.casereporting.exception.DashboardDataParseException;
import com.ombudsman.service.casereporting.model.RecentCasesList;
import com.ombudsman.service.casereporting.model.response.RecentCasesRes;
import com.ombudsman.service.casereporting.repository.RecentCaseRepository;
import com.ombudsman.service.casereporting.serviceimpl.RecentCaseListServiceImpl;
import com.ombudsman.service.casereporting.serviceimpl.helper.CaseReportingDetailsHelper;

@ExtendWith(SpringExtension.class)
class RecentCaseListServiceImplTest {

	@Mock
	private ICaseReportingDataProcessDao dashboardDataProcessDao;

	@Mock
	private RecentCaseRepository recentCaseRepository;

	@InjectMocks
	private RecentCaseListServiceImpl recentCaseListServiceImpl;
	@Mock
	CaseReportingDetailsHelper mMockdashboardCaseDetailsHelper;

	@Mock
	RecentCaseDto recentCaseDto;

	@Mock
	UserBean userbean;

	@Test
	void testGetRecentCaseList_Positive()
			throws AzureServiceException, InterruptedException, JsonProcessingException,
			DashboardCaseException, AccountNotFoundException, DashboardDataParseException {
		// Arrange
		List<String> groups = Arrays.asList("group1", "group2");
		List<RecentCasesList> recentCaseLits = new ArrayList<>();
		RecentCasesList recentCasesList = new RecentCasesList();
		recentCasesList.setIncidentid("12334");
		recentCaseLits.add(recentCasesList);
		when(userbean.getGroups()).thenReturn(groups);
		String mockoid = "123abc";
	    when(userbean.getUserObjectId()).thenReturn(mockoid);
		when(dashboardDataProcessDao.getAccountIds(Mockito.anyString())).thenReturn(Lists.newArrayList("123","456"));

		List<RecentCaseDto> recentCases = new ArrayList<RecentCaseDto>();
		when(recentCaseDto.getFos_reference()).thenReturn("fos_reference");
		when(recentCaseDto.getFos_datecasefirstmovedtoinvestigation()).thenReturn("2000-01-09");
		when(recentCaseDto.getFos_dateofevent()).thenReturn("dateofevent");
		when(recentCaseDto.getFos_dateofreferral()).thenReturn("dateofreferral");
		when(recentCaseDto.getFos_reference()).thenReturn("332");
		when(recentCaseDto.getIncidentid()).thenReturn("3453");
		when(recentCaseDto.getTicketnumber()).thenReturn("1234");

		when(mMockdashboardCaseDetailsHelper.getRecentCases(recentCases)).thenReturn(recentCaseLits);
		recentCases.add(recentCaseDto);
		when(dashboardDataProcessDao.getFetchRecentCase(Arrays.asList("123", "456"))).thenReturn(recentCases);

		// Act
		RecentCasesRes result = recentCaseListServiceImpl.getRecentCaseList();

		// Assert
		assertNotNull(result);
		assertEquals("Success", result.getStatus());
		assertEquals(1, result.getRecentcaselist().size());
		// Add more assertions based on your method's behavior
	}

	

	@Test
	void testGetRecentCaseList_EmptyRecentCases()
			throws  AzureServiceException, InterruptedException, JsonProcessingException,
			DashboardCaseException, AccountNotFoundException, DashboardDataParseException {
		// Arrange
		List<String> groups = Arrays.asList("group1", "group2");
		when(userbean.getGroups()).thenReturn(groups);
		String mockoid = "123abc";
	    when(userbean.getUserObjectId()).thenReturn(mockoid);
		when(dashboardDataProcessDao.getAccountIds(Mockito.anyString())).thenReturn(Lists.newArrayList("123","456"));

		when(recentCaseRepository.getFetchRecentCase(Arrays.asList("123", "456")))
				.thenReturn(Collections.emptyList());

		// Act
		RecentCasesRes result = recentCaseListServiceImpl.getRecentCaseList();

		// Assert
		assertNotNull(result);
		assertEquals(0, result.getRecentcaselist().size());
	}

	@Test
	void testGetRecentCaseList_ExceptionThrown()
			throws  AzureServiceException, InterruptedException, JsonProcessingException,
			DashboardCaseException, AccountNotFoundException, DashboardDataParseException {
		// Arrange
		List<String> groups = Arrays.asList("group1", "group2");
		RecentCasesRes result = null;
		when(userbean.getGroups()).thenReturn(groups);
		when(dashboardDataProcessDao.getAccountIds(Mockito.anyString())).thenReturn(null);

		// Act
		try {
			result = recentCaseListServiceImpl.getRecentCaseList();
		} catch (AccountNotFoundException ex) {
			assertNull(result);
		}

	}
}