package com.ombudsman.service.casereporting.common;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.when;

import java.lang.reflect.Field;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.ombudsman.service.casereporting.exception.UnAuthorisedException;
import com.ombudsman.service.casereporting.model.response.GenericResponse;
import com.ombudsman.service.casereporting.service.ILoginService;

public class ValidateUserSessionTest {

    @Mock
    private CommonUtil commonUtil;

    @Mock
    private ILoginService loginService;

    @InjectMocks
    private ValidateUserSession validateUserSession;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    private void setSessionFlag(String value) throws Exception {
        Field field = CommonUtil.class.getDeclaredField("sessionFlag");
        field.setAccessible(true);
        field.set(commonUtil, value);
    }

    @Test
    void testValidSession() throws Exception {
        setSessionFlag("true");
        GenericResponse response = new GenericResponse();
        response.setStatus("valid");
        when(loginService.getSessionTokenStatus()).thenReturn(response);

        assertTrue(validateUserSession.isValidSession(), "The session should be valid when sessionFlag is true and status is valid.");
    }

    @Test
    void testInvalidSession() throws Exception {
        setSessionFlag("true");
        GenericResponse response = new GenericResponse();
        response.setStatus("invalid");
        when(loginService.getSessionTokenStatus()).thenReturn(response);

        assertThrows(UnAuthorisedException.class, () -> {
            validateUserSession.isValidSession();
        }, "An UnAuthorisedException should be thrown for an invalid session status.");
    }

    @Test
    void testSessionFlagFalse() throws Exception {
        setSessionFlag("false");

        assertFalse(validateUserSession.isValidSession(), "The session should be invalid when sessionFlag is false.");
    }

    @Test
    void testExceptionDuringValidation() throws Exception {
        setSessionFlag("true");
        when(loginService.getSessionTokenStatus()).thenThrow(new RuntimeException("Some error"));

        assertThrows(UnAuthorisedException.class, () -> {
            validateUserSession.isValidSession();
        }, "An UnAuthorisedException should be thrown when an exception occurs during session validation.");
    }

    @Test
    void testNullTokenStatus() throws Exception {
        setSessionFlag("true");
        GenericResponse response = new GenericResponse();
        response.setStatus(null);
        when(loginService.getSessionTokenStatus()).thenReturn(response);

        assertThrows(UnAuthorisedException.class, () -> {
            validateUserSession.isValidSession();
        }, "An UnAuthorisedException should be thrown when token status is null.");
    }
}
