package com.ombudsman.service.casereporting.serviceImpl;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.ombudsman.service.casereporting.common.CaseReportingWebClient;
import com.ombudsman.service.casereporting.model.response.GenericResponse;
import com.ombudsman.service.casereporting.serviceimpl.LoginServiceImpl;

import org.mockito.InjectMocks;
import org.mockito.Mock;
@ExtendWith(SpringExtension.class)
public class LoginServiceImplTest {
	
	@InjectMocks
	LoginServiceImpl testInstance;
	@Mock
	CaseReportingWebClient dashBoardWebClient;
	
	  @Test
	    public void testAddUserSessionEntry() throws Exception {
	        GenericResponse expectedResponse = new GenericResponse(); 
	        when(dashBoardWebClient.getResponseForSessionActivity("login")).thenReturn(expectedResponse);

	        GenericResponse actualResponse = testInstance.addUserSessionEntry();

	        assertEquals(expectedResponse, actualResponse);
	        verify(dashBoardWebClient, times(1)).getResponseForSessionActivity("login");
	    }

	  
	  @Test
	    public void testUpdateUserSessionEntry() throws Exception {
	        GenericResponse expectedResponse = new GenericResponse(); 
	        when(dashBoardWebClient.getResponseForSessionActivity("")).thenReturn(expectedResponse);

	        GenericResponse actualResponse = testInstance.updateUserSessionEntry();

	        assertEquals(expectedResponse, actualResponse);
	        verify(dashBoardWebClient, times(1)).getResponseForSessionActivity("");
	    }
	  
	  @Test
	    public void testLogoutUserSessionEntry() throws Exception {
	        GenericResponse expectedResponse = new GenericResponse(); 
	        when(dashBoardWebClient.getResponseForSessionActivity("logout")).thenReturn(expectedResponse);

	        GenericResponse actualResponse = testInstance.logoutForUserSession();

	        assertEquals(expectedResponse, actualResponse);
	        verify(dashBoardWebClient, times(1)).getResponseForSessionActivity("logout");
	    }
	  
	  @Test
	    public void testGetSessionTokenStatus() throws Exception {
	        GenericResponse expectedResponse = new GenericResponse(); 
	        when(dashBoardWebClient.getResponseForSessionActivity("")).thenReturn(expectedResponse);

	        GenericResponse actualResponse = testInstance.getSessionTokenStatus();

	        assertEquals(expectedResponse, actualResponse);
	        verify(dashBoardWebClient, times(1)).getResponseForSessionActivity("");
	    }
}
