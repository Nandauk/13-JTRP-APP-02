package com.ombudsman.service.casereporting;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.test.context.junit.jupiter.SpringExtension;

@ExtendWith(SpringExtension.class)
class ServletInitializerTest {
	@InjectMocks
	private ServletInitializer testInstance;
	@Mock
	private SpringApplicationBuilder mMockSpringApplicationBuilder;
	@Test
	void configure() {
		testInstance.configure(mMockSpringApplicationBuilder);
	}

}
