package com.ombudsman.service.casereporting.exception;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import jakarta.servlet.http.HttpServletRequest;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.time.LocalDateTime;
import java.util.Locale;

import javax.security.auth.login.AccountNotFoundException;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
@ExtendWith(SpringExtension.class)
public class GlobalControllerExceptionHandlerTest {
	@InjectMocks
	GlobalControllerExceptionHandler testInstance;
	@Mock
	ResponseEntity<ApiError> response;
	@Mock
	AccountNotFoundException exception;
	@Mock
	RecentCaseNotFoundException exceptionRecentCases;
	@Mock
	DashboardCaseException dashboardCaseException;
	
	
	@Mock
	HttpServletRequest request;
	@Mock
	Exception ex;
	@Mock
	MessageSource messageSource;
	private static final String RESPONDENT_1002 = "RESPONDENT_1002";
	private static final String API_ERROR_EXCEPTION_ACCOUNT_ID = "api.error.accountid";
	
	private static final Logger logger =
		      LoggerFactory.getLogger(GlobalControllerExceptionHandler.class);
	

	 @Test
	    public void testHandleSQLException() {
	        SQLDataAccessException sqlException = new SQLDataAccessException("Database error");

	        request= mock(HttpServletRequest.class);
	        GlobalControllerExceptionHandler exceptionHandler = new GlobalControllerExceptionHandler();

	        when(request.getRequestURL()).thenReturn(new StringBuffer("http://example.com"));

	        ResponseEntity<ApiError> responseEntity = exceptionHandler.handleSQLDataAccessException(sqlException);

	        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, responseEntity.getStatusCode());

	        ApiError apiError = responseEntity.getBody();
	        assertEquals("RESPONDENT_1001", apiError.getErrorCode());
	        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, apiError.getStatus());
	        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR.toString(), apiError.getErrorMessage());

	    }
	 
		/*
		 * @Test public void testHandleCaseFilterNotFoundException() {
		 * AccountNotFoundException accountNotFoundException = new
		 * AccountNotFoundException("Account not found");
		 * 
		 * messageSource=mock(MessageSource.class); request=
		 * mock(HttpServletRequest.class); GlobalControllerExceptionHandler
		 * exceptionHandler = new GlobalControllerExceptionHandler();
		 * exceptionHandler.setMessageSource(messageSource);
		 * 
		 * when(request.getRequestURL()).thenReturn(new
		 * StringBuffer("http://example.com"));
		 * 
		 * 
		 * String expectedMessage = "Account ID not found";
		 * when(messageSource.getMessage(ArgumentMatchers.any(), ArgumentMatchers.any(),
		 * ArgumentMatchers.any())) .thenReturn(expectedMessage);
		 * 
		 * ResponseEntity<ApiError> responseEntity =
		 * exceptionHandler.handleCaseFilterNotFoundException(request, ex);
		 * 
		 * assertEquals(HttpStatus.INTERNAL_SERVER_ERROR,
		 * responseEntity.getStatusCode());
		 * 
		 * ApiError apiError = responseEntity.getBody(); assertEquals(RESPONDENT_1002,
		 * apiError.getErrorCode()); assertEquals(HttpStatus.INTERNAL_SERVER_ERROR,
		 * apiError.getStatus()); //assertEquals(expectedMessage,
		 * apiError.getErrorMessage());
		 * 
		 * verify(logger, times(1)).info(Mockito.anyString(), Mockito.anyString()); }
		 */
	 
	 @Test
	    public void testhandleAccountNotFoundException() {
	        GlobalControllerExceptionHandler exceptionHandler = new GlobalControllerExceptionHandler();

	        AccountNotFoundException accountNotFoundException = new AccountNotFoundException("Account not found");
	      //  String exceptionMessage = "Account not found";
	        //when(accountNotFoundException.getMessage()).thenReturn(exceptionMessage);
	        exception= mock(AccountNotFoundException.class);
	        
	        ResponseEntity<ApiError> responseEntity = exceptionHandler.handleAccountNotFoundException(exception);

	        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, responseEntity.getStatusCode());

	        ApiError apiError = responseEntity.getBody();
	      //  assertEquals(exceptionMessage, apiError.getErrorCode());
	       // assertEquals(HttpStatus.NOT_FOUND, apiError.getStatus());
	        assertEquals(String.valueOf(HttpStatus.INTERNAL_SERVER_ERROR.value()), apiError.getErrorMessage());

	      //  verify(logger, times(1)).info(Mockito.anyString(), Mockito.anyString());
	    }
	 
	 @Test
	    public void testhandleRecentCaseNotFoundException() {
	        GlobalControllerExceptionHandler exceptionHandler = new GlobalControllerExceptionHandler();

	        RecentCaseNotFoundException accountNotFoundException = new RecentCaseNotFoundException("Account not found");
	      //  String exceptionMessage = "Account not found";
	        //when(accountNotFoundException.getMessage()).thenReturn(exceptionMessage);
	        exceptionRecentCases= mock(RecentCaseNotFoundException.class);
	        
	        ResponseEntity<ApiError> responseEntity = exceptionHandler.handleRecentCaseNotFoundException(exceptionRecentCases);

	       

	        ApiError apiError = responseEntity.getBody();
	      //  assertEquals(exceptionMessage, apiError.getErrorCode());
	       // assertEquals(HttpStatus.NOT_FOUND, apiError.getStatus());
	        assertEquals(String.valueOf(HttpStatus.NOT_FOUND.value()), apiError.getErrorMessage());

	      //  verify(logger, times(1)).info(Mockito.anyString(), Mockito.anyString());
	    }
	 @Test
	    public void testhandleRecentCaseNotFoundException1() {
	        GlobalControllerExceptionHandler exceptionHandler = new GlobalControllerExceptionHandler();
	        DashboardCaseException accountNotFoundException = new DashboardCaseException("Account not found");
	      //  String exceptionMessage = "Account not found";
	        //when(accountNotFoundException.getMessage()).thenReturn(exceptionMessage);
	        dashboardCaseException= mock(DashboardCaseException.class);
	        
	        ResponseEntity<ApiError> responseEntity = exceptionHandler.handleRecentCaseNotFoundException(dashboardCaseException);

	        assertEquals(HttpStatus.BAD_REQUEST, responseEntity.getStatusCode());

	        ApiError apiError = responseEntity.getBody();
	      //  assertEquals(exceptionMessage, apiError.getErrorCode());
	       // assertEquals(HttpStatus.NOT_FOUND, apiError.getStatus());
	        assertEquals(String.valueOf(HttpStatus.PRECONDITION_FAILED.value()), apiError.getErrorMessage());

	      //  verify(logger, times(1)).info(Mockito.anyString(), Mockito.anyString());
	    }

	 @Test
	    public void testHandleException() {
	        GlobalControllerExceptionHandler exceptionHandler = new GlobalControllerExceptionHandler();

	       // String exceptionMessage = "Internal server error";
	        //when(exception.getMessage()).thenReturn(exceptionMessage);
	        exception= mock(AccountNotFoundException.class);
	        ResponseEntity<ApiError> responseEntity = exceptionHandler.handleException(exception);

	        assertEquals(HttpStatus.BAD_REQUEST, responseEntity.getStatusCode());

	        ApiError apiError = responseEntity.getBody();
	        assertEquals("Input is Invalid", apiError.getErrorCode());
	        assertEquals(HttpStatus.PRECONDITION_FAILED, apiError.getStatus());
	        assertEquals(String.valueOf(HttpStatus.PRECONDITION_FAILED.value()), apiError.getErrorMessage());

	       // verify(logger, times(1)).info(Mockito.anyString(), ArgumentMatchers.any());
	    }
}
