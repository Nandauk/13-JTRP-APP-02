#casemanagement
#! bin/bash
az account set --subscription "b70424dd-d53a-40a3-98a4-0cf1f27c11f0"
echo whoami
# Define the file to be removed
ENVIRONMENT=dv2
configmap_file_path="/mnt/configmap_API/java-api-resp-${ENVIRONMENT}-configmap.yaml"
#Remove the file
sudo rm -f "$configmap_file_path"
#Check if the last command (rm) was successful
if [ $? -eq 0 ]; then
    echo "file removed successfully"
    #CONFIGMAP_NAME="dp-api-resp-casemanagement"
    #echo CONFIGMAP_NAME": $CONFIGMAP_NAME " >> "/mnt/configmap_API/java-api-resp-${ENVIRONMENT}-configmap.yaml"
    #ENVIRONMENT=dv2
    #sudo mkdir "/mnt/configmap_API"
    sudo touch "/mnt/configmap_API/java-api-resp-${ENVIRONMENT}-configmap.yaml"
    sudo chmod 777 "/mnt/configmap_API/java-api-resp-${ENVIRONMENT}-configmap.yaml"
    CASEUPDATE_SPN="SPN-APP-CM-CASEUPDATE-${ENVIRONMENT}"
    INT_CASEUPDATE_SPN="SPN-APP-MS-CM-CASEUPDATE-${ENVIRONMENT}"
    CASEEXP_SPN="SPN-APP-MS-CM-CEXPT-${ENVIRONMENT}"
    AD_RESP_ISSUER_URI="https://ombportalrespb2cdev.b2clogin.com/tfp/65a36538-9d84-4717-a24f-19666eb31ca6/b2c_1a_smart_hrd_poc/v2.0/"
    echo AD_RESP_ISSUER_URI": $AD_RESP_ISSUER_URI " >> "/mnt/configmap_API/java-api-resp-${ENVIRONMENT}-configmap.yaml"
    AD_RESP_B2C_JWT_SET_URI="https://ombportalrespb2cdev.b2clogin.com/ombportalrespb2cdev.onmicrosoft.com/discovery/v2.0/keys?p=b2c_1a_smart_hrd_poc"
    echo AD_RESP_B2C_JWT_SET_URI": $AD_RESP_B2C_JWT_SET_URI " >> "/mnt/configmap_API/java-api-resp-${ENVIRONMENT}-configmap.yaml"
    SERVER_PORT="8443"
    echo SERVER_PORT": $SERVER_PORT " >> "/mnt/configmap_API/java-api-resp-${ENVIRONMENT}-configmap.yaml"
    SESSION_BASE_URL="https://portal-${ENVIRONMENT}.financial-ombudsman.org.uk"
    echo SESSION_BASE_URL": $SESSION_BASE_URL " >> "/mnt/configmap_API/java-api-resp-${ENVIRONMENT}-configmap.yaml"
    SESSION_FLAG="true"
    echo SESSION_FLAG": $SESSION_FLAG " >> "/mnt/configmap_API/java-api-resp-${ENVIRONMENT}-configmap.yaml"
    CASEUPDATE_APIMURL="https://apim-${ENVIRONMENT}.financial-ombudsman.org.uk/respondentfunctions/api"
    echo CASEUPDATE_APIMURL": $CASEUPDATE_APIMURL " >> "/mnt/configmap_API/java-api-resp-${ENVIRONMENT}-configmap.yaml"
    CASEUPDATE_EVENTNAME="caseUpdate"
    echo CASEUPDATE_EVENTNAME": $CASEUPDATE_EVENTNAME " >> "/mnt/configmap_API/java-api-resp-${ENVIRONMENT}-configmap.yaml"
    NOTIFICATIONAPIURL="/ombudsmanservice/v1/notification/postnotification"
    echo NOTIFICATIONAPIURL": $NOTIFICATIONAPIURL " >> "/mnt/configmap_API/java-api-resp-${ENVIRONMENT}-configmap.yaml"
    INDIVIDUALIDAPIURL="/ombudsmanservice/v1/usermanagement/respondentadminindividualid"
    echo INDIVIDUALIDAPIURL": $INDIVIDUALIDAPIURL " >> "/mnt/configmap_API/java-api-resp-${ENVIRONMENT}-configmap.yaml"
    UPDATE_CASE_SERVICE_BUS_QUALIFIED_NAME="sb-dp-app-ext-uks-${ENVIRONMENT}-001.servicebus.windows.net"
    echo UPDATE_CASE_SERVICE_BUS_QUALIFIED_NAME": $UPDATE_CASE_SERVICE_BUS_QUALIFIED_NAME " >> "/mnt/configmap_API/java-api-resp-${ENVIRONMENT}-configmap.yaml"
    INFRA_TENANTID="3df253a5-1a74-47e7-a5e0-204525367f22"
    echo INFRA_TENANTID": $INFRA_TENANTID " >> "/mnt/configmap_API/java-api-resp-${ENVIRONMENT}-configmap.yaml"
    SB_CASEEXP_CLIENTID=$(az ad sp list --display-name $CASEEXP_SPN --query "[0].appId" --output tsv)
    echo SB_CASEEXP_CLIENTID": $SB_CASEEXP_CLIENTID " >> "/mnt/configmap_API/java-api-resp-${ENVIRONMENT}-configmap.yaml"
    # SB_CASEUPDATE_CLIENTID="88df068f-7fe1-47f7-b351-2b086ded6b34"
    # echo SB_CASEUPDATE_CLIENTID  ": $SB_CASEUPDATE_CLIENTID "
    # $SB_CASEUPDATE_CLIENTID >> "/mnt/dp-api-resp-${ENVIRONMENT}configmap.yaml"
    SB_CASEUPDATE_CLIENTID=$(az ad sp list --display-name $CASEUPDATE_SPN --query "[0].appId" --output tsv)
    echo SB_CASEUPDATE_CLIENTID": $SB_CASEUPDATE_CLIENTID" >> "/mnt/configmap_API/java-api-resp-${ENVIRONMENT}-configmap.yaml"
    SB_INT_CASEUPDATE_CLIENTID=$(az ad sp list --display-name $INT_CASEUPDATE_SPN --query "[0].appId" --output tsv)
    echo SB_INT_CASEUPDATE_CLIENTID": $SB_INT_CASEUPDATE_CLIENTID " >> "/mnt/configmap_API/java-api-resp-${ENVIRONMENT}-configmap.yaml"
    CASEUPDATE_SB_QUEUE_NAME="queue-dp-ext-input-${ENVIRONMENT}"
    echo CASEUPDATE_SB_QUEUE_NAME": $CASEUPDATE_SB_QUEUE_NAME " >> "/mnt/configmap_API/java-api-resp-${ENVIRONMENT}-configmap.yaml"
    CASE_EXPORT_SERVICE_BUS_QUALIFIED_NAME="sb-dp-app-int-uks-${ENVIRONMENT}-001.servicebus.windows.net"
    echo CASE_EXPORT_SERVICE_BUS_QUALIFIED_NAME": $CASE_EXPORT_SERVICE_BUS_QUALIFIED_NAME " >> "/mnt/configmap_API/java-api-resp-${ENVIRONMENT}-configmap.yaml"
    CASE_EXPORT_SB_QUEUE_NAME="queue-dp-int-caseexport-queue-${ENVIRONMENT}"
    echo CASE_EXPORT_SB_QUEUE_NAME": $CASE_EXPORT_SB_QUEUE_NAME " >> "/mnt/configmap_API/java-api-resp-${ENVIRONMENT}-configmap.yaml"
    CASE_EXPORT_AVAILABLE_DOWNLOAD_URL="/ombudsmanservice/v1/notification/gettypenotification"
    echo CASE_EXPORT_AVAILABLE_DOWNLOAD_URL": $SB_INT_CASEUPDATE_CLIENTID " >> "/mnt/configmap_API/java-api-resp-${ENVIRONMENT}-configmap.yaml"
    APIM_URL="https://apim-${ENVIRONMENT}.financial-ombudsman.org.uk"
    echo APIM_URL": $APIM_URL " >> "/mnt/configmap_API/java-api-resp-${ENVIRONMENT}-configmap.yaml"
    BULK_UPDATE_CASE_SERVICE_BUS_QUALIFIED_NAME="sb-dp-app-int-uks-${ENVIRONMENT}-001.servicebus.windows.net"
    echo BULK_UPDATE_CASE_SERVICE_BUS_QUALIFIED_NAME": $BULK_UPDATE_CASE_SERVICE_BUS_QUALIFIED_NAME " >> "/mnt/configmap_API/java-api-resp-${ENVIRONMENT}-configmap.yaml"
    BULK_CASEUPDATE_SB_QUEUE_NAME="queue-dp-int-caseupdate-queue-${ENVIRONMENT}"
    echo BULK_CASEUPDATE_SB_QUEUE_NAME": $SB_INT_CASEUPDATE_CLIENTID " >> "/mnt/configmap_API/java-api-resp-${ENVIRONMENT}-configmap.yaml"
    cat "/mnt/configmap_API/java-api-resp-${ENVIRONMENT}-configmap.yaml"
else
    echo "Failed to removed successfully."
    exit 1
fi    

