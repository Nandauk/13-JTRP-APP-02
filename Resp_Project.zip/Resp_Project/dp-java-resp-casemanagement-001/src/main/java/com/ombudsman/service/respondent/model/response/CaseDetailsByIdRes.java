package com.ombudsman.service.respondent.model.response;

import com.ombudsman.service.respondent.model.Case;

public class CaseDetailsByIdRes extends GenericResponse {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 4447128096932131295L;
	private transient Case casedetails;
	public Case getCasedetails() {
		return casedetails;
	}
	public void setCasedetails(Case casedetails) {
		this.casedetails = casedetails;
	}

	
}
