package com.ombudsman.service.respondent.exception;

public class CaseOutComesNotFoundException extends RuntimeException{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public CaseOutComesNotFoundException(String exceptionMsg)
	{
		super(exceptionMsg);
	}
}