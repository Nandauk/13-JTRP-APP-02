package com.ombudsman.service.respondent.model.dto;

import java.io.Serializable;

public class OrganizationDto implements Serializable {
	
	private static final long serialVersionUID = 1L;
	private String organizationName;
	private String organizationId;
	
	

	public String getOrganizationId() {
		return organizationId;
	}

	public OrganizationDto(String organizationName, String organizationId) {
		super();
		this.organizationName = organizationName;
		this.organizationId = organizationId;
	}

	public void setOrganizationId(String organizationId) {
		this.organizationId = organizationId;
	}

	public OrganizationDto(String organizationName) {	
		this.organizationName = organizationName;
	}

	public String getOrganizationName() {
		return organizationName;
	}

	public void setOrganizationName(final String organizationName) {
		this.setOrganizationName(organizationName);
	}
	

}
