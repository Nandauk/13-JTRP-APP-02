package com.ombudsman.service.respondent.exception;

public class CaseUpdateException extends RespondentsServiceExceptions {

		private static final long serialVersionUID = 1L;

		public CaseUpdateException(String message, String exceptionMessage) {
			super(message, "CASEMANAGEMENT_UPDATECASE_INVALID_APIMURL_1004", exceptionMessage);
		}
	}

