package com.ombudsman.service.respondent.serviceimpl;

import static com.ombudsman.service.respondent.common.Constants.CASE_DETAILS_NOT_FOUND;
import static com.ombudsman.service.respondent.common.Constants.CASE_PARTIES_NOT_FOUND;
import static com.ombudsman.service.respondent.common.Constants.CASE_WORKER_DETAILS_NOT_FOUND;
import static com.ombudsman.service.respondent.common.Constants.DD_MM_YYYY;
import static com.ombudsman.service.respondent.common.Constants.FAILED;
import static com.ombudsman.service.respondent.common.Constants.INCIDENTID_IS_A_VALID_FIELD;
import static com.ombudsman.service.respondent.common.Constants.INCIDENTID_IS_NOT_A_VALID_FIELD;
import static com.ombudsman.service.respondent.common.Constants.RESULT_SET_1;
import static com.ombudsman.service.respondent.common.Constants.RESULT_SET_2;
import static com.ombudsman.service.respondent.common.Constants.RESULT_SET_3;
import static com.ombudsman.service.respondent.common.Constants.RESULT_SET_4;
import static com.ombudsman.service.respondent.common.Constants.RESULT_SET_5;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ombudsman.service.respondent.common.CaseWorkerMapper;
import com.ombudsman.service.respondent.common.CommonUtil;
import com.ombudsman.service.respondent.common.ComplainantMapper;
import com.ombudsman.service.respondent.common.OrganisationComplainantMapper;
import com.ombudsman.service.respondent.common.RepresentativeMapper;
import com.ombudsman.service.respondent.common.UserBean;
import com.ombudsman.service.respondent.exception.AzureServiceException;
import com.ombudsman.service.respondent.exception.CaseDetailsNotFoundException;
import com.ombudsman.service.respondent.exception.CasePartiesNotFoundException;
import com.ombudsman.service.respondent.exception.CaseWorkerDetailsNotFoundException;
import com.ombudsman.service.respondent.exception.DateParseException;
import com.ombudsman.service.respondent.exception.SQLDataAccessException;
import com.ombudsman.service.respondent.model.Case;
import com.ombudsman.service.respondent.model.CaseWorker;
import com.ombudsman.service.respondent.model.Complainant;
import com.ombudsman.service.respondent.model.OrganisationComplainant;
import com.ombudsman.service.respondent.model.Representative;
import com.ombudsman.service.respondent.model.dto.CaseDetailDto;
import com.ombudsman.service.respondent.model.dto.CaseWorkerDto;
import com.ombudsman.service.respondent.model.dto.ComplainantDto;
import com.ombudsman.service.respondent.model.dto.OrganisationComplainantDto;
import com.ombudsman.service.respondent.model.dto.RepresentativeDto;
import com.ombudsman.service.respondent.model.request.CaseDetailsByIdReq;
import com.ombudsman.service.respondent.model.response.CaseDetailsByIdRes;
import com.ombudsman.service.respondent.model.response.CasePartiesByIdRes;
import com.ombudsman.service.respondent.model.response.CaseWorkerDetailsByIdRes;
import com.ombudsman.service.respondent.repository.dao.CaseDetailsDao;
import com.ombudsman.service.respondent.service.CaseDetailsByIdService;
import com.ombudsman.service.respondent.serviceimpl.helper.CaseServiceHelper;

@Service
public class CaseDetailsByIdServiceImpl implements CaseDetailsByIdService {

	private CommonUtil commonUtil;

	UserBean userbean;

	CaseServiceHelper caseServiceHelper;

	CaseDetailsDao caseDetailsDao;

	@Autowired
	public CaseDetailsByIdServiceImpl(UserBean userbean, CaseDetailsDao caseDetailsDao, CommonUtil commonUtil,
			CaseServiceHelper caseServiceHelper) {
		super();
		this.userbean = userbean;
		this.caseDetailsDao = caseDetailsDao;
		this.commonUtil = commonUtil;
		this.caseServiceHelper = caseServiceHelper;
	}

	private static final Logger log = LogManager.getRootLogger();
	private static final String USER_IS_NOT_TAGGED_WITH_ANY_ORGANISATION = "User is not tagged with any organisation.";

	@Override
	public CaseDetailsByIdRes getCaseDetailsById(CaseDetailsByIdReq request)
			throws AzureServiceException, IOException, SQLDataAccessException, CaseDetailsNotFoundException {

		log.debug("GetCaseDetailsById Service Method Started.CorrelationId:-{} OID:-{}", userbean.getCorrelationId(),
				userbean.getUserObjectId());
		CaseDetailsByIdRes caseDetailsByIdRes = new CaseDetailsByIdRes();
		try {

			// verification as per regex provided started
			if (StringUtils.isNotEmpty(request.getIncidentid()) && commonUtil.isValidInput(request.getIncidentid())) {

				log.info(INCIDENTID_IS_A_VALID_FIELD);
					log.info("Organisation list is not empty.CorrelationId:-{} OID:-{}", userbean.getCorrelationId(),
							userbean.getUserObjectId());
					final List<String> adAccountId = caseServiceHelper.getAccountIds(userbean.getUserObjectId());

					if (CollectionUtils.isNotEmpty(adAccountId)) {
						final List<CaseDetailDto> caseDetails = caseDetailsDao
								.getCaseDetailsById(request.getIncidentid(), adAccountId);
						if (CollectionUtils.isNotEmpty(caseDetails)) {
							Case setCaseDetails = this.setCaseDetails(caseDetails);
							caseDetailsByIdRes.setCasedetails(setCaseDetails);
							caseDetailsByIdRes.setStatus("success");
						} else {
							log.debug(CASE_DETAILS_NOT_FOUND);
							throw new CaseDetailsNotFoundException(CASE_DETAILS_NOT_FOUND);
						}
					}

			} else {
				caseDetailsByIdRes.setStatus(FAILED);
				caseDetailsByIdRes.setMessage(INCIDENTID_IS_NOT_A_VALID_FIELD);
				log.debug(INCIDENTID_IS_NOT_A_VALID_FIELD);

			}
		} catch (CaseDetailsNotFoundException ex) {
			log.error(String.format("API error::{0}".concat(ex.getMessage())));
		}

		return caseDetailsByIdRes;
	}

	@Override
	public CaseWorkerDetailsByIdRes getCaseWorkerDetailsById(CaseDetailsByIdReq request) throws AzureServiceException,
			JSONException, IOException, SQLDataAccessException, CaseWorkerDetailsNotFoundException {

		log.debug("GetCaseWorkerDetailsById Service Method Started.CorrelationId:-{}", userbean.getCorrelationId());
		CaseWorkerDetailsByIdRes caseWorkerDetailsByIdRes = new CaseWorkerDetailsByIdRes();

		// verification as per regex provided started
		if (StringUtils.isNotEmpty(request.getIncidentid()) && commonUtil.isValidInput(request.getIncidentid())) {

			log.debug(INCIDENTID_IS_A_VALID_FIELD);

				log.debug("Organisation list is not empty.CorrelationId:-{} OID:-{}", userbean.getCorrelationId(),
						userbean.getUserObjectId());

				final List<String> adAccountId = caseServiceHelper.getAccountIds(userbean.getUserObjectId());

				if (CollectionUtils.isNotEmpty(adAccountId)) {

					final List<CaseWorkerDto> caseWorkerDetails = caseDetailsDao
							.getCaseWorkerDetailsById(request.getIncidentid(), adAccountId);

					final ObjectMapper mapper = new ObjectMapper();

					final List<CaseWorker> caseWorkerDtls = caseWorkerDetails.stream()
							.map(i -> mapper.convertValue(i, CaseWorkerDto.class))
							.map(CaseWorkerMapper.INSTANCE::caseWorkerLst).collect(Collectors.toList());

					if (CollectionUtils.isNotEmpty(caseWorkerDtls))
						caseWorkerDetailsByIdRes.setCaseworker(caseWorkerDtls.get(caseWorkerDtls.size() - 1));
					else {
						log.debug(CASE_WORKER_DETAILS_NOT_FOUND);
						throw new CaseWorkerDetailsNotFoundException(CASE_WORKER_DETAILS_NOT_FOUND);
					}

				}

		} else {
			caseWorkerDetailsByIdRes.setStatus(FAILED);
			caseWorkerDetailsByIdRes.setMessage(INCIDENTID_IS_NOT_A_VALID_FIELD);
			log.debug(INCIDENTID_IS_NOT_A_VALID_FIELD);

		}

		return caseWorkerDetailsByIdRes;
	}

	private Case setCaseDetails(final List<CaseDetailDto> caseDetails) throws CaseDetailsNotFoundException {
		log.debug("setCaseDetails method started.CorrelationId:-{} OID:-{}", userbean.getCorrelationId(),
				userbean.getUserObjectId());

		final Case caseObj = new Case();
		try {

			SimpleDateFormat sdf = new SimpleDateFormat(DD_MM_YYYY);
			Calendar c = Calendar.getInstance();

			DateTimeFormatter dtf = DateTimeFormatter.ofPattern(DD_MM_YYYY);
			LocalDate now = LocalDate.now();
			String days14 = null;
			String weeks8 = null;
			LocalDate otherDate = null;
			Period period = null;

			CaseDetailDto caseItem = null;
			caseItem = caseDetails.get(0);
			caseObj.setIncidentid(caseItem.getIncidentid());
			caseObj.setTicketnumber(caseItem.getTicketnumber());
			caseObj.setFos_crn(caseItem.getFos_crn());
			caseObj.set_customerid_value(caseItem.get_customerid_value());
			caseObj.setBusinessname(caseItem.getBusinessname());
			caseObj.setFos_reference(caseItem.getFos_reference());
			caseObj.setFos_extendedreference(caseItem.getFos_extendedreference());
			caseObj.set_fos_complaintissue_value(caseItem.get_fos_complaintissue_value());
			caseObj.set_fos_complaintissue_value_txt(caseItem.get_fos_complaintissue_value_txt());
			caseObj.set_fos_productorproductfamily_value_txt(caseItem.get_fos_productorproductfamily_value_txt());
			caseObj.setBusinessname(caseItem.getBusinessname());
			caseObj.set_fos_complaintissue_value_txt(caseItem.get_fos_complaintissue_value_txt());
			caseObj.setStatuscode_txt(caseItem.getStatuscode_txt());
			caseObj.setFos_casestage_txt(caseItem.getFos_casestage_txt());
			caseObj.setFos_prioritycode_txt(caseItem.getFos_prioritycode_txt());
			caseObj.setFos_individualid(caseItem.getFos_individualid());
			caseObj.setFos_reference(caseItem.getFos_reference());
			caseObj.setFos_tradingname(caseItem.getFos_tradingname());
			caseObj.setFos_dateofconversion(caseItem.getFos_dateofconversion());
			if (caseItem.getFos_dateofreferral() != null) {
				caseObj.setFos_dateofreferral(caseItem.getFos_dateofreferral());
			}
			if (caseItem.getFos_datecasefirstmovedtoinvestigation() != null) {
				caseObj.setFos_datecasefirstmovedtoinvestigation(caseItem.getFos_datecasefirstmovedtoinvestigation());
			}
			if (caseItem.getFos_dateofevent() != null) {
				caseObj.setFos_dateofevent(caseItem.getFos_dateofevent());
			}
			if (caseItem.getFos_dateoffinalresponse() != null) {
				caseObj.setFos_dateoffinalresponse(caseItem.getFos_dateoffinalresponse());
			}

			// title
			if (caseItem.getFos_datecasefirstmovedtoinvestigation() != null) {
				caseObj.setFos_datecasefirstmovedtoinvestigation(caseItem.getFos_datecasefirstmovedtoinvestigation());
				Date dateInvest = new Date();
				try {

					dateInvest = (sdf.parse(caseItem.getFos_datecasefirstmovedtoinvestigation()));
				} catch (DateParseException e1) {
					log.debug(e1.getMessage());
				}
				c.setTime(dateInvest);
				c.add(Calendar.DATE, 14); // number of days to add
				days14 = sdf.format(c.getTime());
				caseObj.setBr_required(days14);

				// Set Case Age=
				otherDate = LocalDate.parse(caseObj.getFos_datecasefirstmovedtoinvestigation(), dtf);
				period = Period.between(otherDate, now);
				int monthsDifference = period.getMonths();
				int yearDifference = period.getYears();
				setCaseAgeBanding(caseObj, monthsDifference, yearDifference);

				// Set Dead Loack Cases
				c = Calendar.getInstance();
				c.setTime(dateInvest);
				c.add(Calendar.DATE, 56); // number of days to add
				weeks8 = sdf.format(c.getTime());
				otherDate = LocalDate.parse(weeks8, DateTimeFormatter.ofPattern(DD_MM_YYYY));
				if (now.isAfter(otherDate) && caseObj.getFos_dateoffinalresponse() == null) {
					caseObj.setDeadlockcases("True");
				} else {
					caseObj.setDeadlockcases("False"); // Set Blank
				}

			}
			caseObj.setFos_caseprogress(caseItem.getFos_caseprogress());
			caseObj.setFos_caseprogress_name(caseItem.getFos_caseprogress_name());
		} catch (Exception ex) {
			log.error("unable to map the data::{}", ex.getMessage());
		}
		log.debug("setCaseDetails method ended.CorrelationId:-{} OID:-{}", userbean.getCorrelationId(),
				userbean.getUserObjectId());
		return caseObj;

	}

	private void setCaseAgeBanding(final Case caseObj, int monthsDifference, int yearDifference) {
		if (yearDifference == 0 && monthsDifference < 3) {
			caseObj.setCaseagebanding("0-3 Months");
		} else if (yearDifference == 0 && monthsDifference < 6) {
			caseObj.setCaseagebanding("3-6 Months");
		} else if (yearDifference == 0 && monthsDifference < 9) {
			caseObj.setCaseagebanding("6-9 Months");
		} else if (yearDifference == 0 && monthsDifference < 12) {
			caseObj.setCaseagebanding("9-12 Months");
		} else if (yearDifference == 1 && monthsDifference < 3) {
			caseObj.setCaseagebanding("12-15 Months");
		} else if (yearDifference == 1 && monthsDifference < 6) {
			caseObj.setCaseagebanding("15-18 Months");
		} else {
			caseObj.setCaseagebanding("18+ Months");
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	public CasePartiesByIdRes getCasePartiesById(CaseDetailsByIdReq request) throws AzureServiceException,
			JSONException, IOException, SQLDataAccessException, CasePartiesNotFoundException {
		log.debug("GetCasePartiesById Service Method Started.CorrelationId:-{} OID:-{}", userbean.getCorrelationId(),
				userbean.getUserObjectId());

		CasePartiesByIdRes casePartiesByIdRes = new CasePartiesByIdRes();
		List<Object> complainantLstDtl = null;
		List<Object> individualRepresentativesLstDtl = null;
		List<Object> professionalRepresentativesLstDtl = null;
		List<Object> organisationComplainantLstDtl = null;
		List<Object> orgComplainantLstDtl = null;
		final ObjectMapper mapper = new ObjectMapper();
		final List<String> groupIds = userbean.getGroups();
		if (StringUtils.isNotEmpty(request.getIncidentid()) && commonUtil.isValidInput(request.getIncidentid())) {

			log.debug(INCIDENTID_IS_A_VALID_FIELD);

				log.debug("Organisation list is not empty.CorrelationId:-{} OID:-{}", userbean.getCorrelationId(),
						userbean.getUserObjectId());
				final List<String> adAccountId = caseServiceHelper.getAccountIds(userbean.getUserObjectId());

				if (CollectionUtils.isNotEmpty(adAccountId)) {

					final Map<String, Object> casePartiesDtls = Optional
							.ofNullable(caseDetailsDao.getCaseParties(request.getIncidentid(), adAccountId))
							.orElseThrow(() -> new CasePartiesNotFoundException(CASE_PARTIES_NOT_FOUND));

					if (null != casePartiesDtls.get(RESULT_SET_1)) {
						complainantLstDtl = ((List<Object>) casePartiesDtls.get(RESULT_SET_1));

						final List<Complainant> complainantsLst = complainantLstDtl.stream()
								.map(i -> mapper.convertValue(i, ComplainantDto.class))
								.map(ComplainantMapper.INSTANCE::complainantDtls).collect(Collectors.toList());

						casePartiesByIdRes.setComplainants(complainantsLst);
					}

					if (null != casePartiesDtls.get(RESULT_SET_4)) {
						individualRepresentativesLstDtl = (List<Object>) casePartiesDtls.get(RESULT_SET_4);

						final List<Representative> individualRepresentativesLst = individualRepresentativesLstDtl
								.stream().map(i -> mapper.convertValue(i, RepresentativeDto.class))
								.map(RepresentativeMapper.INSTANCE::representativeDtls).collect(Collectors.toList());

						casePartiesByIdRes.setIndividualRepresentatives(individualRepresentativesLst);
					}
					if (null != casePartiesDtls.get(RESULT_SET_5)) {
						professionalRepresentativesLstDtl = (List<Object>) casePartiesDtls.get(RESULT_SET_5);

						final List<Representative> professionalRepresentativesLst = professionalRepresentativesLstDtl
								.stream().map(i -> mapper.convertValue(i, RepresentativeDto.class))
								.map(RepresentativeMapper.INSTANCE::representativeDtls).collect(Collectors.toList());

						casePartiesByIdRes.setProfessionalRepresentatives(professionalRepresentativesLst);
					}
					if (null != casePartiesDtls.get(RESULT_SET_2)) {
						organisationComplainantLstDtl = (List<Object>) casePartiesDtls.get(RESULT_SET_2);

						final List<OrganisationComplainant> organisationComplainantLst = organisationComplainantLstDtl
								.stream().map(i -> mapper.convertValue(i, OrganisationComplainantDto.class))
								.map(OrganisationComplainantMapper.INSTANCE::organisationComplainantDtls)
								.collect(Collectors.toList());

						if (null != casePartiesDtls.get(RESULT_SET_3)) {
							orgComplainantLstDtl = ((List<Object>) casePartiesDtls.get(RESULT_SET_3));

							final List<Complainant> orgComplainantsLst = orgComplainantLstDtl.stream()
									.map(i -> mapper.convertValue(i, ComplainantDto.class))
									.map(ComplainantMapper.INSTANCE::complainantDtls).collect(Collectors.toList());

							organisationComplainantLst
									.forEach(orgComplaintDtl -> orgComplaintDtl.setMembers(orgComplainantsLst.stream()
											.filter(c -> c.getFos_organisationid()
													.equals(orgComplaintDtl.getFos_organisationid()))
											.collect(Collectors.toList())));

							casePartiesByIdRes.setOrganisationComplainant(organisationComplainantLst);
						}

					}
					if (casePartiesByIdRes.getComplainants().isEmpty()
							&& casePartiesByIdRes.getIndividualRepresentatives().isEmpty()
							&& casePartiesByIdRes.getOrganisationComplainant().isEmpty()
							&& casePartiesByIdRes.getProfessionalRepresentatives().isEmpty()) {
						casePartiesByIdRes.setMessage(CASE_PARTIES_NOT_FOUND);
						throw new CasePartiesNotFoundException(CASE_PARTIES_NOT_FOUND);
					}
				}


		} else {
			casePartiesByIdRes.setStatus(FAILED);
			casePartiesByIdRes.setMessage(INCIDENTID_IS_NOT_A_VALID_FIELD);
			log.debug(INCIDENTID_IS_NOT_A_VALID_FIELD);
		}

		return casePartiesByIdRes;
	}

}
