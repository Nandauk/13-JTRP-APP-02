package com.ombudsman.service.respondent.model.request;

import java.util.List;

import com.ombudsman.service.respondent.model.Accounts;

public class GetCaseFilterReq {

	private List<Accounts> organisationlist;

	public List<Accounts> getOrganisationlist() {
		return organisationlist;
	}

	public void setOrganisationlist(List<Accounts> organisationlist) {
		this.organisationlist = organisationlist;
	}
}
