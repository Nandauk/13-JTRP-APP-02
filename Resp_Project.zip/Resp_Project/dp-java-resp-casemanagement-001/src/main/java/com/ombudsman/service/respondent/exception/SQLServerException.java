package com.ombudsman.service.respondent.exception;

import org.springframework.dao.DataAccessException;

public class SQLServerException  extends DataAccessException {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public SQLServerException(String exceptionMsg)
	{
		super(exceptionMsg);
	}


}
