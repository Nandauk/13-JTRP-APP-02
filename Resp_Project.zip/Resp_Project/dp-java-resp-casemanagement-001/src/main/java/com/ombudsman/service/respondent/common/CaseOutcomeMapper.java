package com.ombudsman.service.respondent.common;

import org.apache.commons.lang3.StringUtils;
import org.mapstruct.BeforeMapping;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import com.ombudsman.service.respondent.model.CaseOutcome;
import com.ombudsman.service.respondent.model.dto.CaseOutcomeDto;

@Mapper(componentModel = "spring")
public interface CaseOutcomeMapper {
	CaseOutcomeMapper INSTANCE = Mappers.getMapper(CaseOutcomeMapper.class);

	public static final String MERIT = "Merit";
	public static final String MERIT_UPHOLD = "Merit: Uphold";
	public static final String MERIT_NON_UPHOLD = "Merit: Non-uphold";
	public static final String DISMISSAL = "Dismissal"; // Code fix for Bug-2041
	public static final String JURISDICTION = "jurisdiction";
	public static final String JURISDICTION_OUT = "jurisdiction: Out";
	public static final String JURISDICTION_IN = "jurisdiction: In";
	public static final String ACTIVE = "Active";
	public static final String MERIT_OPINION1 = "140000000";
	public static final String MERIT_OPINION2 = "140000001";
	public static final String SETTLEMENT_OFFER = "140000004";
	public static final String SETTLEMENT_UPHOLD = "Uphold";

	@BeforeMapping
	public default void meritOpinionMapping(CaseOutcomeDto outcomeDtoObj) {
		
		String caseStatus = null;
		if (outcomeDtoObj.getFos_meritsjurisdictiondismissal() != null) {
			switch (outcomeDtoObj.getFos_meritsjurisdictiondismissal()) {
			case MERIT_OPINION1:

				if (MERIT_OPINION1.equals(outcomeDtoObj.getFos_meritopinion())) {

					outcomeDtoObj.setFos_meritopinionname(MERIT_NON_UPHOLD);
				} else if (outcomeDtoObj.getFos_meritopinion().equals(MERIT_OPINION2)) {
					outcomeDtoObj.setFos_meritopinionname(MERIT_UPHOLD);
				} else if (StringUtils.isNotEmpty(outcomeDtoObj.getFos_meritopinionname())) {
					outcomeDtoObj.setFos_meritopinionname(MERIT);
				}
				break;
			case MERIT_OPINION2:
				if (MERIT_OPINION1.equals(outcomeDtoObj.getFos_jurisdictioninout())) {

					outcomeDtoObj.setFos_jurisdictioninoutname(JURISDICTION_IN);
				} else if (outcomeDtoObj.getFos_jurisdictioninout().equals(MERIT_OPINION2)) {
					outcomeDtoObj.setFos_jurisdictioninoutname(JURISDICTION_OUT);
				} else if (StringUtils.isNotEmpty(outcomeDtoObj.getFos_jurisdictioninoutname())) {
					outcomeDtoObj.setFos_jurisdictioninoutname(JURISDICTION);

				}
				break;

			case "140000002":

				if (outcomeDtoObj.getFos_dismissalreason() != null) {
					outcomeDtoObj.setFos_dismissalreason(DISMISSAL); // Code fix for Bug-2041
				}
				break;
			default:

			}
		}
		
		if(SETTLEMENT_OFFER.equals(outcomeDtoObj.getFos_type()))
		{
			if(outcomeDtoObj.getFos_withopinion().equals(MERIT_OPINION1))
				outcomeDtoObj.setFos_jurisdictioninoutname(SETTLEMENT_UPHOLD);
			else
				outcomeDtoObj.setFos_jurisdictioninoutname("");
		}

		caseStatus = outcomeDtoObj.getStatuscode();
		if (ACTIVE.equalsIgnoreCase(caseStatus)) {
			outcomeDtoObj.setFos_changeinoutcomename("");
		} 
	}

	@Mapping(source = "fos_case", target = "_fos_case_value")
	@Mapping(source = "fos_offeroroutcomeid", target = "fos_offeroroutcomeid")
	@Mapping(source = "fos_type", target = "fos_type")
	@Mapping(source = "fos_typename", target = "fos_type_txt")
	@Mapping(source = "fos_meritsjurisdictiondismissal", target = "fos_meritsjurisdictiondismissal")
	@Mapping(source = "fos_meritsjurisdictiondismissalname", target = "fos_meritsjurisdictiondismissal_txt")
	@Mapping(source = "fos_meritopinion", target = "fos_meritopinion")
	@Mapping(source = "fos_meritopinionname", target = "fos_meritopinion_txt")
	@Mapping(source = "fos_jurisdictioninout", target = "fos_jurisdictioninout")
	@Mapping(source = "fos_jurisdictioninoutname", target = "fos_jurisdictioninout_txt")
	@Mapping(source = "fos_dismissalreason", target = "fos_dismissalreason")
	@Mapping(source = "fos_withopinion", target = "fos_withopinion")
	@Mapping(source = "fos_changeinoutcome", target = "fos_changeinoutcome")
	@Mapping(source = "fos_changeinoutcomename", target = "fos_changeinoutcome_txt")
	@Mapping(source = "fos_settlementbandid", target = "_fos_settlementbandid_value")
	@Mapping(source = "fos_settlementbandidname", target = "_fos_settlementbandid_value_txt")
	@Mapping(source = "fos_nonmonetarysettlement", target = "fos_nonmonetarysettlement")
	@Mapping(source = "fos_troubleupsetamt", target = "fos_troubleupsetamt")
	@Mapping(source = "fos_complainantresponse", target = "fos_complainantresponse")
	@Mapping(source = "fos_complainantresponsename", target = "fos_complainantresponse_txt")
	@Mapping(source = "fos_respondentresponse", target = "fos_respondentresponse")
	@Mapping(source = "fos_respondentresponse_txt", target = "fos_respondentresponse_txt")
	@Mapping(source = "fos_outcomedispatcheddate", target = "outcomedate")
	CaseOutcome caseOutcomeLst(CaseOutcomeDto outcomeDtoObj);
}
