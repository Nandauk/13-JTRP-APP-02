package com.ombudsman.service.respondent.serviceimpl;

import java.sql.SQLException;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ombudsman.service.respondent.common.UserBean;
import com.ombudsman.service.respondent.exception.DbRecordCreationException;
import com.ombudsman.service.respondent.exception.InvalidOrganisationException;
import com.ombudsman.service.respondent.exception.MandatoryFieldMissingException;

import com.ombudsman.service.respondent.exception.UnAuthorisedException;
import com.ombudsman.service.respondent.model.request.AssignCasesReq;
import com.ombudsman.service.respondent.model.response.CaseAssignmentRes;
import com.ombudsman.service.respondent.service.CaseAssignmentService;
import com.ombudsman.service.respondent.service.repository.CaseListJdbcRepository;

@Service
public class CaseAssignmentServiceImpl implements CaseAssignmentService {

    private static final Logger log = LogManager.getLogger(CaseAssignmentServiceImpl.class);


    @Autowired
    private UserBean userBean;

    @Autowired
    private CaseListJdbcRepository caseListJdbcRepository; 
    
    private static final String MISSING_FIELD = "MISSING_FIELD";

    @Override
    public CaseAssignmentRes assignCases(AssignCasesReq request)
            throws SQLException, UnAuthorisedException, InvalidOrganisationException {
        log.debug("assignCases Service Method Started. CorrelationId: {}, OID: {}",
                userBean.getCorrelationId(), userBean.getUserObjectId());
        
        String loggedInUser = userBean.getUserObjectId();

        String userOid = request.getOid();
        List<String> caseIds = request.getCaseIds();
        
        if (StringUtils.isEmpty(userOid)) {
            throw new MandatoryFieldMissingException(MISSING_FIELD);
        }
        if (caseIds.size() == 0) {
            throw new MandatoryFieldMissingException(MISSING_FIELD);
        }
       //check for null as well

        try {
            // Retrieve incident IDs based on case numbers
            List<String> incidentIds = caseListJdbcRepository.getIncidentIdsByTicketNumbers(caseIds);
          
            
            // Validate user and cases
            boolean valid = caseListJdbcRepository.validateUserAndCases(userOid, incidentIds);
            if (!valid) {
                log.error("Cases belong to an invalid or unauthorized account. CorrelationId: {}, OID: {}",
                        userBean.getCorrelationId(), userBean.getUserObjectId());
                throw new InvalidOrganisationException("Cases belong to an invalid or unauthorised account.");
            }

            String assignedToName = caseListJdbcRepository.assignCasesToUser(incidentIds, userOid);
            
            caseListJdbcRepository.createAuditForCaseAssignment(
                    "dp-java-respondent-db-casemanagement-001", // audit_event_name
                    "cases",                                   // primary_audit_entity
                    userOid,                             // primary_audit_entity_identifier
                    assignedToName,                            // name of the user receiving the assignment
                    incidentIds,                               // list of incident IDs
                    loggedInUser,                              // user_oid (the logged-in user performing this action)
                    "caseAssignmentService"                    // created_by
                );


            log.debug("Cases successfully assigned to user: {}. CorrelationId: {}, OID: {}",
                    assignedToName, userBean.getCorrelationId(), userBean.getUserObjectId());

            // Return a success response
            return new CaseAssignmentRes("Cases assigned to " + assignedToName, "200");

        } catch (DbRecordCreationException e) {
            log.error("Database access error occurred while assigning cases. CorrelationId: {}, OID: {}",
                    userBean.getCorrelationId(), userBean.getUserObjectId(), e);
           
            throw new DbRecordCreationException("Failed to assign cases due to a database issue.");
        } finally {
            log.debug("assignCases Service Method Ended. CorrelationId: {}, OID: {}",
                    userBean.getCorrelationId(), userBean.getUserObjectId());
        }
    }
}
