package com.ombudsman.service.respondent.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class CaseFilter {
	@JsonProperty("ticketnumber")
	private String casereference; // ticketnumber - incident
	@JsonProperty("fos_crn")
	private String migratedreference; //fos_crn - incident
	@JsonProperty("_customerid_value")
	private String businessname;      //_customerid_value - incident (organisation account id)
	private String businessreference; // fos_reference, fos_extendedreference - fos_caselink
	private String complaintissue;  //fos_complaintissue - incident
	private String producttype;    // fos_productorproductfamily - incident
	private String casestage;      // fos_casestage - incident
	private String openstockstatus; // statuscode - incident
	private String enquirydate;    //fos_dateofreferral - incident
	private String professionalrep; //fos_representatives - incident
	private String conversiondate;  //fos_datecasefirstmovedtoinvestigation - incident
	private String defaultBusinessfile; //fos_datecasefirstmovedtoinvestigation - incident
	private String lastviewdate;      //fos_dispatcheddate - letter
	private String lastviewoutcome;   //fos_type - fos_offeroutcome
	private String foscaseowner;  //fos_caseworker - incident
	private String respondentcaseowner; //fos_individualid - fos_caselink
	private String caseagebanding; //fos_datecasefirstmovedtoinvestigation - incident
	private String noofefile;   // TBC
	private String noofcorrespondet; // TBC
	private String eventdate;  // fos_dateofevent - incident
	private String vulnerable; //TBC
	private String finalresponsedate; //fos_dateoffinalresponse - incident
	private String closuredate;  // fos_resolutiondate - fos_offeroutcome
	private String closureoutcome; //fos_changeinoutcome - fos_offeroutcome
	private String deadlockcases;  //fos_datecasefirstmovedtoinvestigation - incident

	public String getCasereference() {
		return casereference;
	}

	public void setCasereference(String casereference) {
		this.casereference = casereference;
	}

	public String getMigratedreference() {
		return migratedreference;
	}

	public void setMigratedreference(String migratedreference) {
		this.migratedreference = migratedreference;
	}

	public String getBusinessname() {
		return businessname;
	}

	public void setBusinessname(String businessname) {
		this.businessname = businessname;
	}

	public String getBusinessreference() {
		return businessreference;
	}

	public void setBusinessreference(String businessreference) {
		this.businessreference = businessreference;
	}

	public String getComplaintissue() {
		return complaintissue;
	}

	public void setComplaintissue(String complaintissue) {
		this.complaintissue = complaintissue;
	}

	public String getProducttype() {
		return producttype;
	}

	public void setProducttype(String producttype) {
		this.producttype = producttype;
	}

	public String getCasestage() {
		return casestage;
	}

	public void setCasestage(String casestage) {
		this.casestage = casestage;
	}

	public String getOpenstockstatus() {
		return openstockstatus;
	}

	public void setOpenstockstatus(String openstockstatus) {
		this.openstockstatus = openstockstatus;
	}

	public String getEnquirydate() {
		return enquirydate;
	}

	public void setEnquirydate(String enquirydate) {
		this.enquirydate = enquirydate;
	}

	public String getProfessionalrep() {
		return professionalrep;
	}

	public void setProfessionalrep(String professionalrep) {
		this.professionalrep = professionalrep;
	}

	public String getConversiondate() {
		return conversiondate;
	}

	public void setConversiondate(String conversiondate) {
		this.conversiondate = conversiondate;
	}

	public String getDefaultBusinessfile() {
		return defaultBusinessfile;
	}

	public void setDefaultBusinessfile(String defaultBusinessfile) {
		this.defaultBusinessfile = defaultBusinessfile;
	}

	public String getLastviewdate() {
		return lastviewdate;
	}

	public void setLastviewdate(String lastviewdate) {
		this.lastviewdate = lastviewdate;
	}

	public String getLastviewoutcome() {
		return lastviewoutcome;
	}

	public void setLastviewoutcome(String lastviewoutcome) {
		this.lastviewoutcome = lastviewoutcome;
	}

	public String getFoscaseowner() {
		return foscaseowner;
	}

	public void setFoscaseowner(String foscaseowner) {
		this.foscaseowner = foscaseowner;
	}

	public String getRespondentcaseowner() {
		return respondentcaseowner;
	}

	public void setRespondentcaseowner(String respondentcaseowner) {
		this.respondentcaseowner = respondentcaseowner;
	}

	public String getCaseagebanding() {
		return caseagebanding;
	}

	public void setCaseagebanding(String caseagebanding) {
		this.caseagebanding = caseagebanding;
	}

	public String getNoofefile() {
		return noofefile;
	}

	public void setNoofefile(String noofefile) {
		this.noofefile = noofefile;
	}

	public String getNoofcorrespondet() {
		return noofcorrespondet;
	}

	public void setNoofcorrespondet(String noofcorrespondet) {
		this.noofcorrespondet = noofcorrespondet;
	}

	public String getEventdate() {
		return eventdate;
	}

	public void setEventdate(String eventdate) {
		this.eventdate = eventdate;
	}

	public String getVulnerable() {
		return vulnerable;
	}

	public void setVulnerable(String vulnerable) {
		this.vulnerable = vulnerable;
	}

	public String getFinalresponsedate() {
		return finalresponsedate;
	}

	public void setFinalresponsedate(String finalresponsedate) {
		this.finalresponsedate = finalresponsedate;
	}

	public String getClosuredate() {
		return closuredate;
	}

	public void setClosuredate(String closuredate) {
		this.closuredate = closuredate;
	}

	public String getClosureoutcome() {
		return closureoutcome;
	}

	public void setClosureoutcome(String closureoutcome) {
		this.closureoutcome = closureoutcome;
	}

	public String getDeadlockcases() {
		return deadlockcases;
	}

	public void setDeadlockcases(String deadlockcases) {
		this.deadlockcases = deadlockcases;
	}

}
