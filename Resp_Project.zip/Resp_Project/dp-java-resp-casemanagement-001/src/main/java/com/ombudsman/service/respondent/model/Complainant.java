package com.ombudsman.service.respondent.model;

import com.ombudsman.service.respondent.model.response.GenericUser;

public class Complainant extends GenericUser {
	
	private String suffix;
	private String address1_composite;
    private String telephone1;
    private String telephone2;
    private String emailaddress1;
    private String birthdate;
    private String organisation_existInComplainant;
    private String fos_organisationid;
	    
	public String getOrganisation_existInComplainant() {
		return organisation_existInComplainant;
	}
	public void setOrganisation_existInComplainant(String organisation_existInComplainant) {
		this.organisation_existInComplainant = organisation_existInComplainant;
	}
	public String getAddress1_composite() {
		return address1_composite;
	}
	public void setAddress1_composite(String address1_composite) {
		this.address1_composite = address1_composite;
	}
	public String getTelephone1() {
		return telephone1;
	}
	public void setTelephone1(String telephone1) {
		this.telephone1 = telephone1;
	}
	public String getEmailaddress1() {
		return emailaddress1;
	}
	public void setEmailaddress1(String emailaddress1) {
		this.emailaddress1 = emailaddress1;
	}
	public String getBirthdate() {
		return birthdate;
	}
	public void setBirthdate(String birthdate) {
		this.birthdate = birthdate;
	}
	public String getSuffix() {
		return suffix;
	}
	public void setSuffix(String suffix) {
		this.suffix = suffix;
	}
	public String getTelephone2() {
		return telephone2;
	}
	public void setTelephone2(String telephone2) {
		this.telephone2 = telephone2;
	}
	public String getFos_organisationid() {
		return fos_organisationid;
	}
	public void setFos_organisationid(String fos_organisationid) {
		this.fos_organisationid = fos_organisationid;
	}


}
