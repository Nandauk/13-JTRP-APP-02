package com.ombudsman.service.respondent.model.response;

import java.util.List;


import com.ombudsman.service.respondent.model.Complainant;
import com.ombudsman.service.respondent.model.OrganisationComplainant;
import com.ombudsman.service.respondent.model.Representative;

public class CasePartiesByIdRes extends GenericResponse{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private List<Complainant> complainants;
	private List<Representative> individualRepresentatives;
	private List<Representative> professionalRepresentatives;
	private List<OrganisationComplainant> organisationComplainant;

	public List<Complainant> getComplainants() {
		return complainants;
	}
	public void setComplainants(List<Complainant> complainants) {
		this.complainants = complainants;
	}
	public List<Representative> getIndividualRepresentatives() {
		return individualRepresentatives;
	}
	public void setIndividualRepresentatives(List<Representative> individualRepresentatives) {
		this.individualRepresentatives = individualRepresentatives;
	}
	public List<OrganisationComplainant> getOrganisationComplainant() {
		return organisationComplainant;
	}
	public void setOrganisationComplainant(List<OrganisationComplainant> organisationComplainant) {
		this.organisationComplainant = organisationComplainant;
	}
	public List<Representative> getProfessionalRepresentatives() {
		return professionalRepresentatives;
	}
	public void setProfessionalRepresentatives(List<Representative> professionalRepresentatives) {
		this.professionalRepresentatives = professionalRepresentatives;
	}

}
