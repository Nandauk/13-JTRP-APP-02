package com.ombudsman.service.respondent.heathprobe;

import java.util.concurrent.atomic.AtomicBoolean;

import org.springframework.stereotype.Component;
@Component
public class RespondnetLivenessHealthHolder {

	private AtomicBoolean healthy = new AtomicBoolean(true);

	public void switchHealth() {
		healthy.set(!healthy.get());
	}

	public boolean isHealthy() {
		return healthy.get();
	}
}
