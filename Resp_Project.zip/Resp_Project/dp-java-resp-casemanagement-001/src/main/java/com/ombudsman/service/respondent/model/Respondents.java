package com.ombudsman.service.respondent.model;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public class Respondents {
		
	@NotNull
	@NotBlank
	private String yomifullname; // Name
	
	private String fos_capacity; //Capacity code
	
	private String fos_parentorganisationcapacity;
	
	private String _parentcustomerid_value;
	
	private String birthdate;
	
	private String _accountid_value;
	
	private String _parent_contactid_value;
	
	private String fos_fcaid;
	
	@NotNull
	@NotBlank
	private String emailaddress1;
	
	private String status; // Status in AD
	
	@NotNull
	@NotBlank
    private String jobtitle;
    
    private String suffix;
    
   
    private String firstname;
    
    private String middlename;
    
   
    private String lastname;
    
    private String fos_role;

	

	public String getYomifullname() {
		return yomifullname;
	}

	public void setYomifullname(String yomifullname) {
		this.yomifullname = yomifullname;
	}

	public String getFos_capacity() {
		return fos_capacity;
	}

	public void setFos_capacity(String fos_capacity) {
		this.fos_capacity = fos_capacity;
	}

	public String getFos_parentorganisationcapacity() {
		return fos_parentorganisationcapacity;
	}

	public void setFos_parentorganisationcapacity(String fos_parentorganisationcapacity) {
		this.fos_parentorganisationcapacity = fos_parentorganisationcapacity;
	}

	public String get_parentcustomerid_value() {
		return _parentcustomerid_value;
	}

	public void set_parentcustomerid_value(String _parentcustomerid_value) {
		this._parentcustomerid_value = _parentcustomerid_value;
	}

	public String getBirthdate() {
		return birthdate;
	}

	public void setBirthdate(String birthdate) {
		this.birthdate = birthdate;
	}

	public String get_accountid_value() {
		return _accountid_value;
	}

	public void set_accountid_value(String _accountid_value) {
		this._accountid_value = _accountid_value;
	}

	public String get_parent_contactid_value() {
		return _parent_contactid_value;
	}

	public void set_parent_contactid_value(String _parent_contactid_value) {
		this._parent_contactid_value = _parent_contactid_value;
	}

	public String getFos_fcaid() {
		return fos_fcaid;
	}

	public void setFos_fcaid(String fos_fcaid) {
		this.fos_fcaid = fos_fcaid;
	}

	public String getEmailaddress1() {
		return emailaddress1;
	}

	public void setEmailaddress1(String emailaddress1) {
		this.emailaddress1 = emailaddress1;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getJobtitle() {
		return jobtitle;
	}

	public void setJobtitle(String jobtitle) {
		this.jobtitle = jobtitle;
	}

	public String getSuffix() {
		return suffix;
	}

	public void setSuffix(String suffix) {
		this.suffix = suffix;
	}

	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getMiddlename() {
		return middlename;
	}

	public void setMiddlename(String middlename) {
		this.middlename = middlename;
	}

	public String getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	
	public String getFos_role() {
		return fos_role;
	}

	public void setFos_role(String fos_role) {
		this.fos_role = fos_role;
	}
}
