package com.ombudsman.service.respondent.service;

import java.io.IOException;

import javax.security.auth.login.AccountNotFoundException;

import org.json.JSONException;

import com.ombudsman.service.respondent.exception.AzureServiceException;
import com.ombudsman.service.respondent.exception.SQLDataAccessException;
import com.ombudsman.service.respondent.exception.UnAuthorisedException;
import com.ombudsman.service.respondent.model.request.CaseOutcomeByIdReq;
import com.ombudsman.service.respondent.model.response.CaseOutcomeByIdRes;

public interface CaseOutcomeByIdService {

	public CaseOutcomeByIdRes getCaseOutcomeById(CaseOutcomeByIdReq request)
			throws AzureServiceException, JSONException, IOException, SQLDataAccessException, AccountNotFoundException, UnAuthorisedException;

}
