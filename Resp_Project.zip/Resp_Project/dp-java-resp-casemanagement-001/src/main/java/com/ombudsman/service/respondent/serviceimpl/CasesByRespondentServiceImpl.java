package com.ombudsman.service.respondent.serviceimpl;

import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ombudsman.service.respondent.common.UserBean;
import com.ombudsman.service.respondent.exception.CaseListNotFoundException;
import com.ombudsman.service.respondent.exception.SQLDataAccessException;
import com.ombudsman.service.respondent.model.CaseListDto;
import com.ombudsman.service.respondent.model.request.GetCasesByRespondentReq;
import com.ombudsman.service.respondent.model.response.CasesManagementRes;
import com.ombudsman.service.respondent.repository.dao.ICaseListDao;
import com.ombudsman.service.respondent.service.ICasesByRespondentService;
import com.ombudsman.service.respondent.service.repository.CaseListJdbcRepository;
import com.ombudsman.service.respondent.serviceimpl.helper.CaseServiceHelper;

@Service
public class CasesByRespondentServiceImpl implements ICasesByRespondentService {

	private static final String RESULT_SET_1 = "#result-set-1";
	private static final String RESULT_SET_2 = "#result-set-2";
	private static final String TOTAL_CASES = "totalcases";
	private static final String PERIORITY_CASES = "prioritycases";
	private static final String BUSINESS_FILE = "businessfileoverdue";
	private static final String AWITING_ACTIONS = "awaitingactions";

	private static final String USER_IS_NOT_TAGGED_WITH_ANY_ORGANISATION = "User is not tagged with any organisation.";
	private static final String CASE_LIST_NOT_FOUND = "Case List not found";

	@Autowired
	CaseListJdbcRepository jdbcRepositoryDao;

	@Autowired
	ICaseListDao caseListDao;

	@Autowired
	UserBean userbean;
	@Autowired
	CaseServiceHelper caseServiceHelper;

	Logger LOG = LogManager.getRootLogger();

	@Override
	@SuppressWarnings("unchecked")
	public CasesManagementRes getCaseListForOrganization(GetCasesByRespondentReq organisationsReq)
			throws JSONException, IOException, SQLDataAccessException, CaseListNotFoundException {
		final List<String> groupIds = userbean.getGroups();

		LOG.debug("GetCasesByRespondent Service Method Started.CorrelationId:-{} OID:-{}, accountIDs::{}",
				userbean.getCorrelationId(), userbean.getUserObjectId(), groupIds);

		final CasesManagementRes getCasesByRespondentRes = new CasesManagementRes();

		List<Object> caseListSummery = null;
		List<Object> caseListDtl = null;

		boolean validSeachRequestAttribute = StringUtils.isEmpty(organisationsReq.getFilters().getSearchBy());
		if (!validSeachRequestAttribute) {
			validSeachRequestAttribute = organisationsReq.getFilters().getSearchBy().length() >= 3;
		}

		if (validSeachRequestAttribute) {

			LOG.debug("Organisation list is not empty.CorrelationId:-{} OID:-{}", userbean.getCorrelationId(),
					userbean.getUserObjectId());

			final Map<String, Object> getRequestData = caseServiceHelper.getRequestData(organisationsReq);
			final Map<String, Object> caseList = Optional
					.ofNullable(caseListDao.getCasesByRespondent(getRequestData, userbean.getUserObjectId()))
					.orElseThrow(() -> new CaseListNotFoundException(CASE_LIST_NOT_FOUND));
			if (null != caseList.get(RESULT_SET_1) && null != caseList.get(RESULT_SET_2)) {
				caseListSummery = (List<Object>) caseList.get(RESULT_SET_1);
				caseListDtl = (List<Object>) caseList.get(RESULT_SET_2);
			} else {
				getCasesByRespondentRes.setMessage(CASE_LIST_NOT_FOUND);
				throw new CaseListNotFoundException(CASE_LIST_NOT_FOUND);
			}
			LOG.info("getCaseListForOrganization:: caseSummery::{}:: case list details size {}", caseListSummery, caseListDtl.size());
			final Map<String, String> caseItems = (Map<String, String>) caseListSummery.get(0);
			final ObjectMapper mapper = new ObjectMapper();

			final List<CaseListDto> caseDtl = caseListDtl.stream().map(i -> mapper.convertValue(i, CaseListDto.class))
					.collect(Collectors.toList());
			getCasesByRespondentRes.setCases(caseDtl);
			getCasesByRespondentRes.setCounttotalcases(String.valueOf(caseItems.get(TOTAL_CASES)));
			getCasesByRespondentRes.setCountprioritycases(String.valueOf(caseItems.get(PERIORITY_CASES)));
			getCasesByRespondentRes.setCountawaitingresponse(String.valueOf(caseItems.get(AWITING_ACTIONS)));
			getCasesByRespondentRes.setCountoverduecases(String.valueOf(caseItems.get(BUSINESS_FILE)));

		} else {
			LOG.debug(USER_IS_NOT_TAGGED_WITH_ANY_ORGANISATION);
			getCasesByRespondentRes.setMessage(USER_IS_NOT_TAGGED_WITH_ANY_ORGANISATION);
		}

		LOG.debug("getCaseListForOrganization Service Method Ended.CorrelationId:-{} OID:-{}",
				userbean.getCorrelationId(), userbean.getUserObjectId());
		return getCasesByRespondentRes;
	}

}
