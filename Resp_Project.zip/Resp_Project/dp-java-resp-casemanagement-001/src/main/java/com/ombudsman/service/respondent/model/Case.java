package com.ombudsman.service.respondent.model;

public class Case {
	

	private String incidentid; //Primary Key
	private String ticketnumber; // Case Reference - incident
	private String fos_crn; //Migrated Reference - incident
	private String _customerid_value;      //_customerid_value - incident (organisation account id)
	private String businessname; // Business Name, _customerid_value - "_customerid_value@OData.Community.Display.V1.FormattedValue":"AXA Insurance UK Plc" 
	private String fos_reference; // Business Reference - fos_reference, fos_extendedreference - fos_caselink
	private String fos_extendedreference; //Business Reference - fos_reference, fos_extendedreference - fos_caselink
	private String _fos_complaintissue_value;  //Complaint Issue - incident
	private String _fos_complaintissue_value_txt; //fos_complaintissue_value@OData.Community.Display.V1.FormattedValue":"Breach of Confidentiality"
	private String _fos_productorproductfamily_value;    // Product Type - fos_productorproductfamily - incident
	private String _fos_productorproductfamily_value_txt; //"_fos_productorproductfamily_value@OData.Community.Display.V1.FormattedValue":"Balance Transfers"
	private String fos_casestage;      // Case Stage - incident
	private String fos_casestage_txt;      // Case Stage - fos_casestage@OData.Community.Display.V1.FormattedValue":"Investigation"
	private String statuscode; // Case Status - incident
	private String statuscode_txt; // Case Status "statuscode@OData.Community.Display.V1.FormattedValue":"Awaiting Action" - incident
	private String fos_dateofreferral;    //Enquiry Date - incident
	
	private String agecaseflag; 
	private String fos_representatives; //Professional Representative Name - incident
	private String fos_datecasefirstmovedtoinvestigation;  //Conversion Date - incident
	private String fos_dateofconversion; //Fix added DPSP-685
	private String fos_datebusinessfilereceived; //Business File Received Date - incident
	private String fos_dispatcheddate; //Last View Date - letter
	private String fos_type;   //Last View OutCome - fos_offeroutcome
	private String fos_categorycode; // Awaiting action from business - task
	private String fos_oldercasestatus; // Live 12 month case - incident
	private String _fos_caseworker_value;  //FOS case owner once allocated - incident
	private String fos_individualid; //Respondent case owner - fos_caselink
	private String caseagebanding; //Case age banding - incident
	private String noofefile;   // TBC
	private String noofcorrespondet; // TBC
	private String fos_dateofevent;  // Event Date - incident
	private String vulnerable; //TBC
	private String fos_dateoffinalresponse; //Final Response Date - incident
	private String fos_offeroutcome;  // Closure date - fos_offeroutcome
	private String fos_changeinoutcome; //Closure outcome fos_changeinoutcome - fos_offeroutcome
	private String deadlockcases;  //Dedlock Case Date - fos_datecasefirstmovedtoinvestigation - incident
	private String fos_tradingname;  // Trading Name - caselink
	private String fos_prioritycode;     // Priority Code - incident
	private String fos_prioritycode_txt;
	private String _owninguser_value;
	private String description;
	private String br_required; // 14+ Conversion Date
	private String statecode;
	private String awaitingAction;
	private String awaitingactionfilter;
	private String fos_outcomedispatcheddate;
	private String fos_resolvingoutcomeid;
	
	private String fos_caseprogress;
	private String fos_caseprogress_name;

	public String getFos_outcomedispatcheddate() {
		return fos_outcomedispatcheddate;
	}
	public void setFos_outcomedispatcheddate(String fos_outcomedispatcheddate) {
		this.fos_outcomedispatcheddate = fos_outcomedispatcheddate;
	}
	public String getAwaitingactionfilter() {
		return awaitingactionfilter;
	}
	public void setAwaitingactionfilter(final String awaitingactionfilter) {
		this.awaitingactionfilter = awaitingactionfilter;
	}
	public String getFos_resolvingoutcomeid() {
		return fos_resolvingoutcomeid;
	}
	public void setFos_resolvingoutcomeid(String fos_resolvingoutcomeid) {
		this.fos_resolvingoutcomeid = fos_resolvingoutcomeid;
	}
	public String getAwaitingAction() {
		return awaitingAction;
	}
	public void setAwaitingAction(String awaitingAction) {
		this.awaitingAction = awaitingAction;
	}
	public String getStatecode() {
		return statecode;
	}
	public void setStatecode(String statecode) {
		this.statecode = statecode;
	}
	public String getTicketnumber() {
		return ticketnumber;
	}
	public void setTicketnumber(String ticketnumber) {
		this.ticketnumber = ticketnumber;
	}
	public String getFos_crn() {
		return fos_crn;
	}
	public void setFos_crn(String fos_crn) {
		this.fos_crn = fos_crn;
	}
	public String get_customerid_value() {
		return _customerid_value;
	}
	public void set_customerid_value(String _customerid_value) {
		this._customerid_value = _customerid_value;
	}
	public String getBusinessname() {
		return businessname;
	}
	public void setBusinessname(String businessname) {
		this.businessname = businessname;
	}
	public String getFos_reference() {
		return fos_reference;
	}
	public void setFos_reference(String fos_reference) {
		this.fos_reference = fos_reference;
	}
	public String getFos_extendedreference() {
		return fos_extendedreference;
	}
	public void setFos_extendedreference(String fos_extendedreference) {
		this.fos_extendedreference = fos_extendedreference;
	}
	public String get_fos_complaintissue_value() {
		return _fos_complaintissue_value;
	}
	public void set_fos_complaintissue_value(String _fos_complaintissue_value) {
		this._fos_complaintissue_value = _fos_complaintissue_value;
	}
	public String get_fos_complaintissue_value_txt() {
		return _fos_complaintissue_value_txt;
	}
	public void set_fos_complaintissue_value_txt(String _fos_complaintissue_value_txt) {
		this._fos_complaintissue_value_txt = _fos_complaintissue_value_txt;
	}
	public String get_fos_productorproductfamily_value() {
		return _fos_productorproductfamily_value;
	}
	public void set_fos_productorproductfamily_value(String _fos_productorproductfamily_value) {
		this._fos_productorproductfamily_value = _fos_productorproductfamily_value;
	}
	public String get_fos_productorproductfamily_value_txt() {
		return _fos_productorproductfamily_value_txt;
	}
	public void set_fos_productorproductfamily_value_txt(String _fos_productorproductfamily_value_txt) {
		this._fos_productorproductfamily_value_txt = _fos_productorproductfamily_value_txt;
	}
	public String getFos_casestage() {
		return fos_casestage;
	}
	public void setFos_casestage(String fos_casestage) {
		this.fos_casestage = fos_casestage;
	}
	public String getFos_casestage_txt() {
		return fos_casestage_txt;
	}
	public void setFos_casestage_txt(String fos_casestage_txt) {
		this.fos_casestage_txt = fos_casestage_txt;
	}
	public String getStatuscode() {
		return statuscode;
	}
	public void setStatuscode(String statuscode) {
		this.statuscode = statuscode;
	}
	public String getStatuscode_txt() {
		return statuscode_txt;
	}
	public void setStatuscode_txt(String statuscode_txt) {
		this.statuscode_txt = statuscode_txt;
	}
	public String getFos_dateofreferral() {
		return fos_dateofreferral;
	}
	public void setFos_dateofreferral(String fos_dateofreferral) {
		this.fos_dateofreferral = fos_dateofreferral;
	}
	
	public String getAgecaseflag() {
		return agecaseflag;
	}
	public void setAgecaseflag(String agecaseflag) {
		this.agecaseflag = agecaseflag;
	}
	public String getFos_representatives() {
		return fos_representatives;
	}
	public void setFos_representatives(String fos_representatives) {
		this.fos_representatives = fos_representatives;
	}
	public String getFos_datecasefirstmovedtoinvestigation() {
		return fos_datecasefirstmovedtoinvestigation;
	}
	public void setFos_datecasefirstmovedtoinvestigation(String fos_datecasefirstmovedtoinvestigation) {
		this.fos_datecasefirstmovedtoinvestigation = fos_datecasefirstmovedtoinvestigation;
	}
	//DPSP-685 Fix Start
	public String getFos_dateofconversion() {
		return fos_dateofconversion;
	}
	public void setFos_dateofconversion(String fos_dateofconversion) {
		this.fos_dateofconversion = fos_dateofconversion;
	}
	// DPSP-685 Fix Ended
	public String getFos_dispatcheddate() {
		return fos_dispatcheddate;
	}
	public void setFos_dispatcheddate(String fos_dispatcheddate) {
		this.fos_dispatcheddate = fos_dispatcheddate;
	}
	public String getFos_type() {
		return fos_type;
	}
	public void setFos_type(String fos_type) {
		this.fos_type = fos_type;
	}
	public String getFos_categorycode() {
		return fos_categorycode;
	}
	public void setFos_categorycode(String fos_categorycode) {
		this.fos_categorycode = fos_categorycode;
	}
	public String getFos_oldercasestatus() {
		return fos_oldercasestatus;
	}
	public void setFos_oldercasestatus(String fos_oldercasestatus) {
		this.fos_oldercasestatus = fos_oldercasestatus;
	}
	public String get_fos_caseworker_value() {
		return _fos_caseworker_value;
	}
	public void set_fos_caseworker_value(String _fos_caseworker_value) {
		this._fos_caseworker_value = _fos_caseworker_value;
	}
	public String getFos_individualid() {
		return fos_individualid;
	}
	public void setFos_individualid(String fos_individualid) {
		this.fos_individualid = fos_individualid;
	}
	public String getNoofefile() {
		return noofefile;
	}
	public void setNoofefile(String noofefile) {
		this.noofefile = noofefile;
	}
	public String getNoofcorrespondet() {
		return noofcorrespondet;
	}
	public void setNoofcorrespondet(String noofcorrespondet) {
		this.noofcorrespondet = noofcorrespondet;
	}
	public String getFos_dateofevent() {
		return fos_dateofevent;
	}
	public void setFos_dateofevent(String fos_dateofevent) {
		this.fos_dateofevent = fos_dateofevent;
	}
	public String getVulnerable() {
		return vulnerable;
	}
	public void setVulnerable(String vulnerable) {
		this.vulnerable = vulnerable;
	}
	public String getFos_dateoffinalresponse() {
		return fos_dateoffinalresponse;
	}
	public void setFos_dateoffinalresponse(String fos_dateoffinalresponse) {
		this.fos_dateoffinalresponse = fos_dateoffinalresponse;
	}
	public String getFos_offeroutcome() {
		return fos_offeroutcome;
	}
	public void setFos_offeroutcome(String fos_offeroutcome) {
		this.fos_offeroutcome = fos_offeroutcome;
	}
	public String getFos_changeinoutcome() {
		return fos_changeinoutcome;
	}
	public void setFos_changeinoutcome(String fos_changeinoutcome) {
		this.fos_changeinoutcome = fos_changeinoutcome;
	}
	public String getIncidentid() {
		return incidentid;
	}
	public void setIncidentid(String incidentid) {
		this.incidentid = incidentid;
	}
	public String getFos_tradingname() {
		return fos_tradingname;
	}
	public void setFos_tradingname(String fos_tradingname) {
		this.fos_tradingname = fos_tradingname;
	}
	public String getCaseagebanding() {
		return caseagebanding;
	}
	public void setCaseagebanding(String caseagebanding) {
		this.caseagebanding = caseagebanding;
	}
	public String getDeadlockcases() {
		return deadlockcases;
	}
	public void setDeadlockcases(String deadlockcases) {
		this.deadlockcases = deadlockcases;
	}
	public String get_owninguser_value() {
		return _owninguser_value;
	}
	public void set_owninguser_value(String _owninguser_value) {
		this._owninguser_value = _owninguser_value;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getBr_required() {
		return br_required;
	}
	public void setBr_required(String br_required) {
		this.br_required = br_required;
	}
	public String getFos_prioritycode() {
		return fos_prioritycode;
	}
	public void setFos_prioritycode(String fos_prioritycode) {
		this.fos_prioritycode = fos_prioritycode;
	}
	public String getFos_prioritycode_txt() {
		return fos_prioritycode_txt;
	}
	public void setFos_prioritycode_txt(String fos_prioritycode_txt) {
		this.fos_prioritycode_txt = fos_prioritycode_txt;
	}
	public String getFos_datebusinessfilereceived() {
		return fos_datebusinessfilereceived;
	}
	public void setFos_datebusinessfilereceived(String fos_datebusinessfilereceived) {
		this.fos_datebusinessfilereceived = fos_datebusinessfilereceived;
	}
	
	public String getFos_caseprogress() {
		return fos_caseprogress;
	}
	public void setFos_caseprogress(String fos_caseprogress) {
		this.fos_caseprogress = fos_caseprogress;
	}
	public String getFos_caseprogress_name() {
		return fos_caseprogress_name;
	}
	public void setFos_caseprogress_name(String fos_caseprogress_name) {
		this.fos_caseprogress_name = fos_caseprogress_name;
	}
	
	
}
