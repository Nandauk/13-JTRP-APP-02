package com.ombudsman.service.respondent.model.response;

import java.util.List;
import java.util.Map;

import com.ombudsman.service.respondent.model.CaseFilterData;

public class GetCaseFilterDataRes extends GenericResponse{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String organisationid;
	private transient Map<String ,List<CaseFilterData>>  filters; 
	
	
	public Map<String, List<CaseFilterData>> getFilters() {
		return filters;
	}
	public void setFilters(Map<String, List<CaseFilterData>> filters) {
		this.filters = filters;
	}
	public String getOrganisationid() {
		return organisationid;
	}
	public void setOrganisationid(String organisationid) {
		this.organisationid = organisationid;
	}

}
