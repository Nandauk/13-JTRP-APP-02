package com.ombudsman.service.respondent.model.dto;

import java.io.Serializable;

public class OrganizationDatailsDto implements Serializable {
	
	private static final long serialVersionUID = 1L;
	private String organizationName;
	private String organizationId;
	
	

	public String getOrganizationId() {
		return organizationId;
	}


	public void setOrganizationId(String organizationId) {
		this.organizationId = organizationId;
	}

	public OrganizationDatailsDto(String organizationName) {	
		this.organizationName = organizationName;
	}

	public String getOrganizationName() {
		return organizationName;
	}

	public void setOrganizationName(final String organizationName) {
		this.setOrganizationName(organizationName);
	}
	

}
