package com.ombudsman.service.respondent.model;

import java.io.Serializable;

public class Accounts implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String accountid;

	public String getAccountid() {
		return accountid;
	}

	public void setAccountid(String accountid) {
		this.accountid = accountid;
	}
}
