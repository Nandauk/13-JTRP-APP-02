package com.ombudsman.service.respondent.service;

import javax.security.auth.login.AccountNotFoundException;

import com.ombudsman.service.respondent.exception.CaseFilterNotFoundException;
import com.ombudsman.service.respondent.exception.OrganizationNotFoundException;
import com.ombudsman.service.respondent.exception.SQLDataAccessException;
import com.ombudsman.service.respondent.model.response.GetCaseFilterDataRes;

public interface ICaseFilterService {
	
	public GetCaseFilterDataRes getCaseFilterDataForOrganisation() throws SQLDataAccessException, AccountNotFoundException, OrganizationNotFoundException, CaseFilterNotFoundException;
}
