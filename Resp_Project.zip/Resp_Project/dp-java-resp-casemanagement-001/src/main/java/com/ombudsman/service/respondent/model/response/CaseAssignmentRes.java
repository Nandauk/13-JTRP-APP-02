package com.ombudsman.service.respondent.model.response;

public class CaseAssignmentRes {
    private String message;
    private String code;
    
    public CaseAssignmentRes()
    {
    	
    }

    public CaseAssignmentRes(String message, String code) {
        this.message = message;
        this.code = code;
    }

    // Getters and Setters
    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getCode() {
        return code;
    }
    public void setCode() {
        this.code = code;
    }
}
