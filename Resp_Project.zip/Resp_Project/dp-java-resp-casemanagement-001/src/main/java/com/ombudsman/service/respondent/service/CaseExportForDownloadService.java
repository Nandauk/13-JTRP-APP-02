package com.ombudsman.service.respondent.service;

import com.ombudsman.service.respondent.model.response.CaseExportDownloadResponse;

public interface CaseExportForDownloadService {
	public CaseExportDownloadResponse getCaseExportAvailableForDownload();

}
