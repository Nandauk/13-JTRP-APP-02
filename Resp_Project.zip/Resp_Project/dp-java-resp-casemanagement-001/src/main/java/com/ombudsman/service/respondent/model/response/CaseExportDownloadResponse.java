package com.ombudsman.service.respondent.model.response;

import java.io.Serializable;
import java.util.List;

public class CaseExportDownloadResponse implements Serializable{
	
	public  List<String> listOfNotification;
	 
	public List<String> getListOfNotification() {
		return listOfNotification;
	}
 
	public void setListOfNotification(List<String> listOfNotification) {
		this.listOfNotification = listOfNotification;
	}	
	

}
