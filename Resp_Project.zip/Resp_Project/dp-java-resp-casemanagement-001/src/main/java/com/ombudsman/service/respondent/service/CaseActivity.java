package com.ombudsman.service.respondent.service;

import com.ombudsman.service.respondent.model.UpdateCase;

public interface CaseActivity {

	
	
	String activity(UpdateCase dto, String ticketnumber);

}
