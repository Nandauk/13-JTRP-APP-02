package com.ombudsman.service.respondent.serviceimpl;

import static com.ombudsman.service.respondent.common.Constants.CASE_OUTCOMES_NOT_FOUND;
import static com.ombudsman.service.respondent.common.Constants.FAILED;
import static com.ombudsman.service.respondent.common.Constants.INCIDENTID_IS_A_VALID_FIELD;
import static com.ombudsman.service.respondent.common.Constants.INCIDENTID_IS_NOT_A_VALID_FIELD;
import static com.ombudsman.service.respondent.common.Constants.SUCCESS;

import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.security.auth.login.AccountNotFoundException;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ombudsman.service.respondent.common.CaseOutcomeMapper;
import com.ombudsman.service.respondent.common.CommonUtil;
import com.ombudsman.service.respondent.common.UserBean;
import com.ombudsman.service.respondent.exception.AzureServiceException;
import com.ombudsman.service.respondent.exception.CaseOutComesNotFoundException;
import com.ombudsman.service.respondent.exception.SQLDataAccessException;
import com.ombudsman.service.respondent.exception.UnAuthorisedException;
import com.ombudsman.service.respondent.model.CaseOutcome;
import com.ombudsman.service.respondent.model.dto.CaseOutcomeDto;
import com.ombudsman.service.respondent.model.request.CaseOutcomeByIdReq;
import com.ombudsman.service.respondent.model.response.CaseOutcomeByIdRes;
import com.ombudsman.service.respondent.repository.dao.CaseDetailsDao;
import com.ombudsman.service.respondent.service.CaseOutcomeByIdService;
import com.ombudsman.service.respondent.service.repository.CaseDetailsJdbcRepository;
import com.ombudsman.service.respondent.serviceimpl.helper.CaseServiceHelper;

@Service
public class CaseOutcomeByIdServiceImpl implements CaseOutcomeByIdService {
	private CommonUtil commonUtil;

	UserBean userbean;

	CaseServiceHelper caseServiceHelper;

	CaseDetailsDao caseDetailsDao;
	CaseDetailsJdbcRepository caseDetailsJdbcRepository;

	@Autowired
	public CaseOutcomeByIdServiceImpl(UserBean userbean, CaseDetailsDao caseDetailsDao, CommonUtil commonUtil,
			CaseServiceHelper caseServiceHelper, CaseDetailsJdbcRepository caseDetailsJdbcRepository) {
		super();
		this.userbean = userbean;
		this.caseDetailsDao = caseDetailsDao;
		this.commonUtil = commonUtil;
		this.caseServiceHelper = caseServiceHelper;
		this.caseDetailsJdbcRepository = caseDetailsJdbcRepository;
	}

	String nextValue = "";

	private static final Logger log = LogManager.getRootLogger();
	private static final String RESULT_SET_1 = "#result-set-1";

	@Override
	public CaseOutcomeByIdRes getCaseOutcomeById(CaseOutcomeByIdReq request)
			throws AzureServiceException, JSONException, IOException, SQLDataAccessException, AccountNotFoundException, UnAuthorisedException {

		log.debug("GetCaseOutcomeById Service Method Started.CorrelationId:-{}", userbean.getCorrelationId(),
				userbean.getUserObjectId());
		final List<String> groupIds = userbean.getGroups();
		List<Object> outComesLstDtl = null;
		CaseOutcomeByIdRes caseOutcomeByIdRes = new CaseOutcomeByIdRes();

		// verification as per regex provided started
		if (StringUtils.isNotEmpty(request.getIncidentid()) && commonUtil.isValidInput(request.getIncidentid())) {
			log.debug(INCIDENTID_IS_A_VALID_FIELD);

					final List<String> adAccountId = caseServiceHelper.getAccountIds(userbean.getUserObjectId());

					if (CollectionUtils.isNotEmpty(adAccountId)) {

						// Account Id Authorization
						int count = caseDetailsDao.chkIncidentAuthorized(request.getIncidentid(), adAccountId);
						if (count == 1) {

							final Map<String, Object> caseOutcomeDetails = Optional
									.ofNullable(caseDetailsDao.getOfferOutcomes(request.getIncidentid()))
									.orElseThrow(() -> new CaseOutComesNotFoundException(CASE_OUTCOMES_NOT_FOUND));

							final ObjectMapper mapper = new ObjectMapper();

							if (null != caseOutcomeDetails.get(RESULT_SET_1)) {
								outComesLstDtl = ((List<Object>) caseOutcomeDetails.get(RESULT_SET_1));

								final List<CaseOutcome> caseOutcomeDtl = outComesLstDtl.stream()
										.map(i -> mapper.convertValue(i, CaseOutcomeDto.class))
										.map(CaseOutcomeMapper.INSTANCE::caseOutcomeLst).collect(Collectors.toList());

								for (CaseOutcome caseOutcome : caseOutcomeDtl) {
									caseOutcome.setOutcomedate(caseDetailsJdbcRepository.datetimeformate(caseOutcome.getOutcomedate()));
								}
								
								caseOutcomeByIdRes.setCaseoutcomes(caseOutcomeDtl);
							} else {
								caseOutcomeByIdRes.setStatus(SUCCESS);
								caseOutcomeByIdRes.setMessage(CASE_OUTCOMES_NOT_FOUND);
								log.debug(CASE_OUTCOMES_NOT_FOUND);
							}
						} else {
							log.error("Organization not found for the requested incident id ");
							throw new UnAuthorisedException("User is Not Authorised");

						}
					}

		} else {
			caseOutcomeByIdRes.setStatus(FAILED);
			caseOutcomeByIdRes.setMessage(INCIDENTID_IS_NOT_A_VALID_FIELD);
			log.debug(INCIDENTID_IS_NOT_A_VALID_FIELD);

		}

		log.debug("GetCaseOutcomeById Service Method Ended.CorrelationId:-{} OID:-{}", userbean.getCorrelationId(),
				userbean.getUserObjectId());
		return caseOutcomeByIdRes;
	}
}
