package com.ombudsman.service.respondent.model;

import org.springframework.http.HttpStatusCode;

public class ApiResponse {
	
	public boolean success ;
    public String message;
    public HttpStatusCode status;
    public Object data;
    
   
	public boolean isSuccess() {
		return success;
	}
	public void setSuccess(boolean success) {
		this.success = success;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public HttpStatusCode getStatus() {
		return status;
	}
	public void setStatus(HttpStatusCode status) {
		this.status = status;
	}
	public Object getData() {
		return data;
	}
	public void setData(Object data) {
		this.data = data;
	}
    
    
	
	
	
	

}
