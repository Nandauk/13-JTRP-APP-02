package com.ombudsman.service.respondent.exception;

public class CaseDetailsNotFoundException  extends RuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public CaseDetailsNotFoundException(String exceptionMsg)
	{
		super(exceptionMsg);
	}

}
