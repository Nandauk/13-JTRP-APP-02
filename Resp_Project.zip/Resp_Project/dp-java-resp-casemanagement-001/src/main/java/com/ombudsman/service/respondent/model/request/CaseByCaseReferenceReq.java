package com.ombudsman.service.respondent.model.request;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;

public class CaseByCaseReferenceReq {
	@Valid
	@NotNull
	@NotEmpty
	private String casefererence;

	public String getCasefererence() {
		return casefererence;
	}

	public void setCasefererence(String casefererence) {
		this.casefererence = casefererence;
	}

}
