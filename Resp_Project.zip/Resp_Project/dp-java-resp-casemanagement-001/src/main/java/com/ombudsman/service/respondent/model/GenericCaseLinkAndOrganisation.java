package com.ombudsman.service.respondent.model;

public class GenericCaseLinkAndOrganisation {
	
	private String fos_numberofemployees;
	private String fos_numberofpartners;
	private String fos_annualturnover;
	private String fos_balancesheet;
	private String fos_islinkedorpartnered;
	private String fos_annualincome;
	private String fos_annualturnover_txt;
	private String fos_netassets;
	private String fos_balancesheet_txt;
	private String fos_businesstypecode;
	private String fos_businesstypecode_txt;
	private String _fos_preferredemailaddress_value;
	private String _fos_preferredemailaddress_value_txt;
	
	public String getFos_numberofemployees() {
		return fos_numberofemployees;
	}
	public void setFos_numberofemployees(String fos_numberofemployees) {
		this.fos_numberofemployees = fos_numberofemployees;
	}
	public String getFos_numberofpartners() {
		return fos_numberofpartners;
	}
	public void setFos_numberofpartners(String fos_numberofpartners) {
		this.fos_numberofpartners = fos_numberofpartners;
	}
	public String getFos_annualturnover() {
		return fos_annualturnover;
	}
	public void setFos_annualturnover(String fos_annualturnover) {
		this.fos_annualturnover = fos_annualturnover;
	}
	public String getFos_balancesheet() {
		return fos_balancesheet;
	}
	public void setFos_balancesheet(String fos_balancesheet) {
		this.fos_balancesheet = fos_balancesheet;
	}
	public String getFos_islinkedorpartnered() {
		return fos_islinkedorpartnered;
	}
	public void setFos_islinkedorpartnered(String fos_islinkedorpartnered) {
		this.fos_islinkedorpartnered = fos_islinkedorpartnered;
	}
	public String getFos_annualincome() {
		return fos_annualincome;
	}
	public void setFos_annualincome(String fos_annualincome) {
		this.fos_annualincome = fos_annualincome;
	}
	public String getFos_annualturnover_txt() {
		return fos_annualturnover_txt;
	}
	public void setFos_annualturnover_txt(String fos_annualturnover_txt) {
		this.fos_annualturnover_txt = fos_annualturnover_txt;
	}
	public String getFos_netassets() {
		return fos_netassets;
	}
	public void setFos_netassets(String fos_netassets) {
		this.fos_netassets = fos_netassets;
	}
	public String getFos_balancesheet_txt() {
		return fos_balancesheet_txt;
	}
	public void setFos_balancesheet_txt(String fos_balancesheet_txt) {
		this.fos_balancesheet_txt = fos_balancesheet_txt;
	}
	public String getFos_businesstypecode() {
		return fos_businesstypecode;
	}
	public void setFos_businesstypecode(String fos_businesstypecode) {
		this.fos_businesstypecode = fos_businesstypecode;
	}
	public String getFos_businesstypecode_txt() {
		return fos_businesstypecode_txt;
	}
	public void setFos_businesstypecode_txt(String fos_businesstypecode_txt) {
		this.fos_businesstypecode_txt = fos_businesstypecode_txt;
	}
	public String get_fos_preferredemailaddress_value() {
		return _fos_preferredemailaddress_value;
	}
	public void set_fos_preferredemailaddress_value(String _fos_preferredemailaddress_value) {
		this._fos_preferredemailaddress_value = _fos_preferredemailaddress_value;
	}
	public String get_fos_preferredemailaddress_value_txt() {
		return _fos_preferredemailaddress_value_txt;
	}
	public void set_fos_preferredemailaddress_value_txt(String _fos_preferredemailaddress_value_txt) {
		this._fos_preferredemailaddress_value_txt = _fos_preferredemailaddress_value_txt;
	}
	

}
