package com.ombudsman.service.respondent.exception;

public class MandatoryFieldException extends Exception {
	 private static final long serialVersionUID = 1L;

	  public MandatoryFieldException(String fieldName){
			super(fieldName);
		}
}
