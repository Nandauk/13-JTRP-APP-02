package com.ombudsman.service.respondent.serviceimpl;

import java.io.IOException;
import java.sql.SQLException;
import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ombudsman.service.respondent.common.UserBean;
import com.ombudsman.service.respondent.common.WebClientData;
import com.ombudsman.service.respondent.exception.CaseManagementInvalidEventNameException;
import com.ombudsman.service.respondent.exception.OrganizationNotFoundException;
import com.ombudsman.service.respondent.exception.RecordCreationException;
import com.ombudsman.service.respondent.model.Attributes;
import com.ombudsman.service.respondent.model.CaseExport;
import com.ombudsman.service.respondent.model.UserData;
import com.ombudsman.service.respondent.model.dto.AuditMaster;
import com.ombudsman.service.respondent.model.dto.NotificationModel;
import com.ombudsman.service.respondent.model.dto.NotificationModelDto;
import com.ombudsman.service.respondent.model.dto.RequestModel;
import com.ombudsman.service.respondent.model.dto.UserEventConfiguration;
import com.ombudsman.service.respondent.model.response.GetResponseMessage;
import com.ombudsman.service.respondent.service.IExportCasesService;
import com.ombudsman.service.respondent.service.repository.AuditRepository;
import com.ombudsman.service.respondent.service.repository.RequestModelRepository;
import com.ombudsman.service.respondent.service.repository.UpdateRequestsRepository;
import com.ombudsman.service.respondent.service.repository.UserEventConfigurationRepository;

@Service
public class ExportCasesServiceImpl implements IExportCasesService {

	private static final String IN_PROGRESS = "InProgress";
	private static final String DP_JAVA_RESP_CASEMANAGEMENT_001 = "dp-java-resp-casemanagement-001";
	@Autowired
	UserBean userbean;
	@Autowired
	private MessageSource messageSource;

	@Autowired
	WebClientData webClientData;
	@Autowired
	AuditRepository auditRepository;
	@Autowired
	RequestModelRepository requestModelRepository;
	@Autowired
	UserEventConfigurationRepository userEventConfigurationRepository;

	@Autowired
	UpdateRequestsRepository updateRequestsRepository;

	Logger LOG = LogManager.getRootLogger();
	private static final String USER_IS_NOT_TAGGED_WITH_ANY_ORGANISATION = "User is not tagged with any organisation.";
	private static final String CASE_EXPORT = "caseExport";
	private static final String API_ERROR_RECORD_CREATION_FAILED = "api.error.RecordCreationFailed";

	@Override
	public GetResponseMessage getCasesExportDataByRespondent(CaseExport caseExport) throws InterruptedException,
			IOException, SQLException, NullPointerException, OrganizationNotFoundException {

		LOG.info("getCasesExportDataByRespondent Service Method Started for User Id :: {}", userbean.getUserObjectId());

		GetResponseMessage genericResponse = new GetResponseMessage();

		userData(caseExport);

		getAccountIds(userbean.getUserObjectId(), caseExport);

		// Auditing for caseExport
		if (CollectionUtils.isNotEmpty(caseExport.getAttributes().getOrganisations())) {

			UserEventConfiguration eventName = userEventConfigurationRepository.getUserEventRecord(CASE_EXPORT);
			LOG.info("UserEventName:-{}", eventName.getUserEventName());

			if (!(eventName.getUserEventName().isBlank() && eventName.getUserEventName().isEmpty())
					&& Boolean.TRUE.equals(eventName.getIsAuditRequired())) {
				postAuditEntries(caseExport, genericResponse, eventName.getUserEventName());
			}

			// Updating data in Request Entity
			RequestModel request = new RequestModel();
			String id = requestEntity(request, requestModelRepository, caseExport, eventName.getUserEventName());

			if (caseExport.getMessageId() != null) {
				// Updating data in Notification Entity through Webclient
				NotificationModel notifyModel = new NotificationModel();

				try {
					notificationEntity(request, notifyModel, id);
					LOG.debug("Data to be updated in notification table  : {}", notifyModel);
					webClientData.caseupdateNotificationWebclient(notifyModel);
					LOG.debug("save data in notification ");

				} catch (Exception e) {

					request.setRequestStatusId(4);
					request.setRequestStatusDescription("Failed for Notification ");
					requestModelRepository.save(request);
					LOG.error("Notification Creation Failed. Please Try Again. ");
					throw new RecordCreationException("Record Creation Failed. Please Try Again.",
							messageSource.getMessage(API_ERROR_RECORD_CREATION_FAILED, null, Locale.ENGLISH));
				}

				List<Object> respOfTemplate = webClientData.getTemplateId(CASE_EXPORT);
				LOG.debug("idOfTemplate : {}", respOfTemplate);

				if (CollectionUtils.isNotEmpty(respOfTemplate)) {

					@SuppressWarnings("unchecked")
					final Map<String, String> templateValue = (Map<String, String>) respOfTemplate.get(0);
					LOG.debug("templateValue : {}", templateValue);

					Integer templateId = Integer.parseInt(templateValue.get("template_id"));

					if (templateId != null) {
						LOG.debug("templateId : {}", templateId);
						caseExport.setTemplateId(templateId);
						LOG.debug("caseExport getTemplateId : {}", caseExport.getTemplateId());
						ObjectMapper mapper = new ObjectMapper();
						String valuetemp = mapper.writeValueAsString(caseExport);
						LOG.info("Request String {}", valuetemp);
						// posting caseExport Request to Service Bus
						webClientData.caseExportWebclienttoServiceBusWorker(valuetemp, genericResponse);
						postAuditEntries(caseExport, genericResponse, eventName.getUserEventName());
						LOG.info("Case Export genericResponse from SB : {}", genericResponse);
					} else {
						LOG.debug("Drupal Api of CaseExport template Id is null ");
						genericResponse.setMessage("Drupal Api of CaseExport template Id is null");
					}
				} else {
					LOG.debug("Drupal Api of CaseExport template Id is null ");
				}

			} else {
				LOG.info("RequestId id Null.");
				genericResponse.setMessage("RequestId id Null. Please try again ");
			}
		} else {
			LOG.info(USER_IS_NOT_TAGGED_WITH_ANY_ORGANISATION);

			genericResponse.setMessage(USER_IS_NOT_TAGGED_WITH_ANY_ORGANISATION);
			throw new OrganizationNotFoundException(USER_IS_NOT_TAGGED_WITH_ANY_ORGANISATION);

		}

		LOG.info("getCasesExportDataByRespondent Service Method Ended ");
		return genericResponse;
	}

	public List<String> getAccountIds(String oid, CaseExport caseExport) {
		LOG.info("getAccountIds method started::{} ", oid);
		List<String> accountId = updateRequestsRepository.getAccountId(oid);
		caseExport.getAttributes().setOrganisations(accountId);
		LOG.info("Account Id in Array format : {}", accountId);
		return accountId;
	}

	private void notificationEntity(RequestModel request, NotificationModel notifyModel, String id) {
		LOG.info("NotificationEntity Method Started ");
		try {
			LOG.info("notificationEntity method stated ");
			notifyModel.setRequest_id(id);
			LOG.info("notifyModel getRequestId {}", notifyModel.getRequest_id());
			notifyModel.setUser_oid(request.getUserOid());
			LOG.info("notificationEntity getUser_oid {}", notifyModel.getUser_oid());
			notifyModel.setRequesting_activity_name(request.getRequestingActivityName());
			LOG.info("notificationEntity getRequesting_activity_name {}", notifyModel.getRequesting_activity_name());
			notifyModel.setMessage("success");
			LOG.info("notificationEntity getMessage{}", notifyModel.getMessage());
			notifyModel.setNotification_status_id("1");
			LOG.info("notificationEntity getNotification_status_id {}", notifyModel.getNotification_status_id());
			notifyModel.setNotification_status_description("Pending");
			LOG.info("notificationEntity getNotification_status_description {}",notifyModel.getNotification_status_description());
			notifyModel.setModified_by(request.getModifiedBy());
			// UTC time
			ZonedDateTime utcTime = ZonedDateTime.now(ZoneId.of("UTC"));
			// BST timezone
			ZoneId bstzoneId = ZoneId.of("Europe/London");
			// Convert UTC time to BST , taking DST into account
			ZonedDateTime bsttime = utcTime.withZoneSameInstant(bstzoneId);
			notifyModel.setCreated_on(bsttime.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));
			LOG.info("notificationEntity getCreated_on {}", notifyModel.getCreated_on());
			notifyModel.setCreated_by(request.getCreatedBy());
			LOG.info("notificationEntity getCreatedBy {}", notifyModel.getCreated_by());
			notifyModel.setModified_on(request.getModifiedOn());
			LOG.info("notificationEntity getCreatedBy {}", notifyModel.getModified_on());

			LOG.info("notificationEntity method ended ");

		} catch (Exception e) {

			request.setRequestStatusId(4);
			request.setRequestStatusDescription("Failed for Notification ");
			requestModelRepository.save(request);
			LOG.info("Notification Creation Failed. Please Try Again. {}", e.getStackTrace());
			throw new RecordCreationException("Record Creation Failed. Please Try Again.",
					messageSource.getMessage(API_ERROR_RECORD_CREATION_FAILED, null, Locale.ENGLISH) );
		}

	}

	private String requestEntity(RequestModel request, RequestModelRepository requestModelRepository,
			CaseExport caseExport, String userEventName) {
		LOG.info("RequestEntity method started ");
		String requestId;

		try {
			LOG.info("User Oid {}", userbean.getUserObjectId());
			request.setUserOid(userbean.getUserObjectId());
			LOG.info("request getUserOid() {}", request.getUserOid());
			request.setRequestingActivityName(userEventName);
			LOG.info("request getRequestingActivityName() {}", request.getRequestingActivityName());
			request.setRequestStatusId(1);
			LOG.info("request getRequestStatusId() {}", request.getRequestStatusId());
			request.setRequestStatusDescription(IN_PROGRESS);
			LOG.info("request getRequestStatusDescription() {}", request.getRequestStatusDescription());
			request.setRequestProcessingDetails(caseExport.getAttributes().toString());
			LOG.info("request getRequestProcessingDetails() {}", request.getRequestProcessingDetails());
			OffsetDateTime offsetdatetime = OffsetDateTime.now();
			request.setRequestStartTime(offsetdatetime);
			LOG.info("request getRequestStartTime() {}", request.getRequestStartTime());
			request.setRequestProcessingCounter(0);
			LOG.info("request getRequestProcessingCounter {}", request.getRequestProcessingCounter());
			request.setCreatedBy(DP_JAVA_RESP_CASEMANAGEMENT_001);
			LOG.info(" request getCreatedBy {}", request.getCreatedBy());
			request.setCreatedOn(offsetdatetime);
			LOG.info(" request getCreatedOn() {}", request.getCreatedOn());

			requestId = requestModelRepository.save(request).getRequestId();
//			requestId = request.getRequestId();
			LOG.info("requestId {}", requestId);
			caseExport.setMessageId(requestId);
			LOG.info("RequestEntity method ended: {}", caseExport.getMessageId());

		} catch (Exception e) {
			request.setRequestStatusId(4);
			request.setRequestStatusDescription("Failed");
			requestModelRepository.save(request);
			LOG.info("Request Creation Failed. Please Try Again. {}", e.getStackTrace());
			throw new RecordCreationException("Record Creation Failed. Please Try Again.",
					messageSource.getMessage(API_ERROR_RECORD_CREATION_FAILED, null, Locale.ENGLISH));
		}

		return requestId;
	}

	private void postAuditEntries(CaseExport caseExport, GetResponseMessage genericResponse, String userEventName) {
		LOG.info("getAuditEntries method started ");
		AuditMaster audit = new AuditMaster();
		try {

			audit.setUserOID(userbean.getUserObjectId());
			OffsetDateTime offsetdatetime = OffsetDateTime.now();
			audit.setAuditEventTimestamp(offsetdatetime);
			audit.setAuditEventName(userEventName);
			audit.setCreatedBy(userbean.getName());
			audit.setPreAuditSnapshot(caseExport.toString());
			auditRepository.save(audit);
			LOG.info("GetAuditEntries method ended {}", audit);

		} catch (Exception e) {
			LOG.info("Invalid Event Name {}", e.getStackTrace());
			genericResponse.setMessage("Case Management Invalid Event Name ");
			throw new CaseManagementInvalidEventNameException("Case Management Invalid Event Name ",
					messageSource.getMessage("api.error.CaseManagementInvalidEventName", null, Locale.ENGLISH));

		}

	}

	void userData(CaseExport caseExport) {
		LOG.info("userData method started ");
		System.out.println(
				userbean.getEmail() + "" + userbean.getUserObjectId() + "   " + userbean.getRoles().iterator().next());
		UserData users = new UserData();
		users.setEmail(userbean.getEmail());
		users.setOid(userbean.getUserObjectId());
		users.setRoles(userbean.getRoles());
		users.setFullName(userbean.getName());
		Attributes attributes = caseExport.getAttributes();
		attributes.setUsers(users);
		caseExport.setAttributes(attributes);
		LOG.info("userData method ended ");
	}
}