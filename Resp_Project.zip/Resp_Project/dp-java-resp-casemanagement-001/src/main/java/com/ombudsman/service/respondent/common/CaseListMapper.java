package com.ombudsman.service.respondent.common;



import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import com.ombudsman.service.respondent.model.Case;
import com.ombudsman.service.respondent.model.CaseListDto;


@Mapper(componentModel = "spring")
public interface CaseListMapper {
	CaseListMapper INSTANCE = Mappers.getMapper( CaseListMapper.class );	

    @Mapping(source = "fos_complaintissue", target = "_fos_complaintissue_value_txt")
    @Mapping(source = "fos_complaintissuename", target = "_fos_complaintissue_value")
    @Mapping(source = "fos_productorproductfamily", target = "_fos_productorproductfamily_value")
    @Mapping(source = "fos_productorproductfamilyname", target = "_fos_productorproductfamily_value_txt")
    @Mapping(source = "customerid", target = "_customerid_value")
    @Mapping(source = "fos_casestagename", target = "fos_casestage_txt")
    @Mapping(source = "fos_caseworker", target = "_fos_caseworker_value")    
   // @Mapping(source = "fos_tradingname", target = "fos_tradingnamename")
    @Mapping(source = "awaitingaction", target = "awaitingAction")    
   Case caseListDto(CaseListDto caseList);
}