package com.ombudsman.service.respondent.serviceimpl;

import java.util.Locale;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Service;

import com.ombudsman.service.respondent.common.UserBean;
import com.ombudsman.service.respondent.common.WebClientData;
import com.ombudsman.service.respondent.exception.RecordCreationException;
import com.ombudsman.service.respondent.model.request.CaseExportDownloadReq;
import com.ombudsman.service.respondent.model.response.CaseExportDownloadResponse;
import com.ombudsman.service.respondent.service.CaseExportForDownloadService;

@Service
public class CaseExportForDownloadServiceImpl implements CaseExportForDownloadService {

	@Autowired
	UserBean userbean;

	@Autowired
	WebClientData webClientData;

	@Autowired
	private MessageSource messageSource;

	Logger LOG = LogManager.getRootLogger();
	private static final String API_ERROR_RECORD_CREATION_FAILED = "api.error.RecordCreationFailed";
	private static final String CASE_EXPORT = "caseExport";

	public CaseExportDownloadResponse getCaseExportAvailableForDownload() {
		CaseExportDownloadResponse response = new CaseExportDownloadResponse();
		CaseExportDownloadReq notificationModel = new CaseExportDownloadReq();
		notificationModel.setRequestingActivityName(CASE_EXPORT);
		notificationModel.setUserOid(userbean.getUserObjectId());

		try {
			response = webClientData.caseExportAvailableForDownload(notificationModel);
			LOG.info("get List of notification from repsponse model class : {}" , response.getListOfNotification());
		
		} catch (Exception e) {

			LOG.error("Notification Creation Failed. Please Try Again. ");
			throw new RecordCreationException("Record Creation Failed. Please Try Again.",
					messageSource.getMessage(API_ERROR_RECORD_CREATION_FAILED, null, Locale.ENGLISH));
		}

		return response;
	}

}
