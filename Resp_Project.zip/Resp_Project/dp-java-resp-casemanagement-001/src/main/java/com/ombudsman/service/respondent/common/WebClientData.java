package com.ombudsman.service.respondent.common;

import java.util.List;
import java.util.Locale;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import com.azure.identity.ClientSecretCredentialBuilder;
import com.azure.messaging.servicebus.ServiceBusClientBuilder;
import com.azure.messaging.servicebus.ServiceBusMessage;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ombudsman.service.respondent.exception.AzureServiceException;
import com.ombudsman.service.respondent.model.dto.Notification;
import com.ombudsman.service.respondent.model.dto.NotificationModel;
import com.ombudsman.service.respondent.model.request.BulkCaseUpdateRequest;
import com.ombudsman.service.respondent.model.request.CaseDetailsByIdReq;
import com.ombudsman.service.respondent.model.request.CaseExportDownloadReq;
import com.ombudsman.service.respondent.model.response.CaseExportDownloadResponse;
import com.ombudsman.service.respondent.model.response.GetResponseMessage;
import com.ombudsman.service.respondent.model.response.NotificationResponse;
import com.ombudsman.service.respondent.model.response.RespondentAdminIndividualIdRes;

import reactor.core.publisher.Mono;

@Service
public class WebClientData {

	private static final String AUTHORIZATION = "Authorization";

	private static final String BEARER = "Bearer ";

	private static final String CASE_UPDATE = "CaseUpdate";

	private static final String CASE_EXPORT = "CaseExport";

	@Autowired
	UserBean userbean;

	@Autowired
	CommonUtil commonUtil;

	@Autowired
	private MessageSource messageSource;
	@Value("${notificationApiUrl}")
	public String notificationApiUrl;

	@Value("${individualidApiUrl}")
	public String individualidApiUrl;

	@Value("${app.apim_url}")
	public String apim_url;

	@Value("${caseExportServiceBusfullyQualifiedNamespace}")
	public String caseExportServiceBusfullyQualifiedNamespace;

	@Value("${updateCaseServiceBusfullyQualifiedNamespace}")
	public String updateCaseServiceBusfullyQualifiedNamespace;

	@Value("${servicbustenantId}")
	public String servicbustenantId;

	@Value("${servicebusCaseUpdateClientId}")
	public String servicebusCaseUpdateClientId;

	@Value("${servicebusCaseUpdateSecretId}")
	public String servicebusCaseUpdateSecretId;

	@Value("${caseupdatequeueName}")
	public String caseupdatequeueName;

	// Bulk case Internal service bus details to be read by function app
	@Value("${updateCaseServiceBusIntfullyQualifiedNamespace}")
	public String updateCaseServiceBusIntfullyQualifiedNamespace;

	@Value("${servicebusCaseUpdateIntClientId}")
	public String servicebusCaseUpdateIntClientId;

	@Value("${servicebusCaseUpdateIntSecretId}")
	public String servicebusCaseUpdateIntSecretId;

	@Value("${caseupdateIntqueueName}")
	public String caseupdateIntqueueName;

	@Value("${servicbusclientId}")
	public String servicbusclientId;

	@Value("${servicbusclientSecret}")
	public String servicbusclientSecret;

	@Value("${caseExportqueueName}")
	public String caseExportqueueName;

	/*
	 * @Value("${servicbusdmclientId}") public String servicbusdmclientId;
	 * 
	 * @Value("${servicbusclientdmSecret}") public String servicbusclientdmSecret;
	 */

	Logger log = LogManager.getRootLogger();
	private static final String OMBUDSMANSERVICE_V1_USERMANAGEMENT_RESPONDENTADMININDIVIDUALID = "/ombudsmanservice/v1/usermanagement/respondentadminindividualid";
	private static String drupalTemplateApiUrl_caseExport = "/content/case_export_template";
	private static String drupalTemplateApiUrl_caseUpdate = "/content/updateCaseFail";

	@SuppressWarnings("unchecked")
	public List<Object> getTemplateId(String templateName) {

		List<Object> template = null;
		String mailjectUrl = "";
		if (CASE_UPDATE.equalsIgnoreCase(templateName))
			mailjectUrl = apim_url + drupalTemplateApiUrl_caseUpdate;
		else if (CASE_EXPORT.equalsIgnoreCase(templateName))
			mailjectUrl = apim_url + drupalTemplateApiUrl_caseExport;

		log.info(String.format("mailjectUrl from caseexport api %s", mailjectUrl));

		try {	

			template = WebClient.create().get().uri(mailjectUrl)
					.headers(httpHeaders -> httpHeaders.set(AUTHORIZATION, BEARER + userbean.getAuthToken()))
					.accept(MediaType.APPLICATION_JSON).retrieve().bodyToMono(List.class).block();

			log.info(String.format("template : %s", template));

		} catch (Exception e) {
			log.error("Error in MailjetTemplateResponse Method 100 {}", e.getMessage());
			log.error("Connectivity of MailjetTemplateResponse Webclient Failed {}", e.getMessage());
		}
		return template;

	}

	public GetResponseMessage caseExportWebclienttoServiceBusWorker(String caseExport,
			GetResponseMessage genericResponse) {
		log.info("caseExportWebclienttoServiceBusWorker Started ");
		try {

			new ServiceBusClientBuilder().fullyQualifiedNamespace(caseExportServiceBusfullyQualifiedNamespace)
					.credential(new ClientSecretCredentialBuilder().tenantId(servicbustenantId)
							.clientId(servicbusclientId).clientSecret(servicbusclientSecret).build())
					.sender().queueName(caseExportqueueName).buildClient()
					.sendMessage(new ServiceBusMessage(caseExport));

			genericResponse.setMessage("Successfully posted to SB ");

			log.info("postRequestToServiceBus Method Ended ");
		} catch (Exception e) {
			genericResponse.setMessage("Sending request to ServiceBus Failed ");
			log.info("Posting caseExport Request in ServiceBus Connectivity Failed ");

			throw new AzureServiceException(
					messageSource.getMessage("api.error.AzureServiceBusconnectivity", null, Locale.ENGLISH),
					e.getMessage());
		}
		return genericResponse;

	}

//	public void updateCaseServiceBusWebclient(UpdateCaseMessage updateCase) throws JsonProcessingException {
//		log.info("updateCaseServiceBusWebclient Started ");
//		try {
//
//			new ServiceBusClientBuilder().fullyQualifiedNamespace(updateCaseServiceBusfullyQualifiedNamespace)
//					.credential(new ClientSecretCredentialBuilder().tenantId(servicbustenantId)
//							.clientId(servicebusCaseUpdateClientId).clientSecret(servicebusCaseUpdateSecretId).build())
//					.sender().queueName(caseupdatequeueName).buildClient()
//					.sendMessage(new ServiceBusMessage(new ObjectMapper().writeValueAsString(updateCase)));
//			log.info("updateCaseServiceBusWebclient Ended ");
//
//		} catch (Exception e) {
//			log.error("Posting case update in ServiceBus Connectivity Failed ::{} ",e.getMessage());
//			throw new AzureServiceException(
//					messageSource.getMessage("api.error.AzureServiceBusconnectivity", null, Locale.ENGLISH),
//					e.getMessage(), e.getStackTrace());
//		}
//
//	}

//Bulk Case update (internal queue to be created by infra)
	public void bulkUpdateCaseServiceBusWebclient(BulkCaseUpdateRequest updateCase) throws JsonProcessingException {
		// log.info("Bulk updateCase ServiceBusWebclient Started ");
		// log.info("Bulk updateCase ServiceBusWebclient Message : {} :{} :{}
		// :{}",updateCase,updateCase.getTemplateId(),updateCase.getNumberOfCases(),updateCase.getReasonForChange());

		try {

			new ServiceBusClientBuilder().fullyQualifiedNamespace(updateCaseServiceBusIntfullyQualifiedNamespace)
					.credential(new ClientSecretCredentialBuilder().tenantId(servicbustenantId)
							.clientId(servicebusCaseUpdateIntClientId).clientSecret(servicebusCaseUpdateIntSecretId)
							.build())
					.sender().queueName(caseupdateIntqueueName).buildClient()
					.sendMessage((ServiceBusMessage) new ServiceBusMessage(
							new ObjectMapper().writeValueAsString(updateCase)));
			log.info("Bulk updateCase ServiceBusWebclient Ended ");

		} catch (Exception e) {
			log.error("Posting bulk case update in ServiceBus Connectivity Failed ::{} ", e.getMessage());
			throw new AzureServiceException(
					messageSource.getMessage("api.error.AzureServiceBusconnectivity", null, Locale.ENGLISH),
					e.getMessage());
		}

	}

	public void caseupdateNotificationWebclient(NotificationModel notification) {
		log.info("caseupdateNotificationWebclient Started ");
		NotificationResponse response = new NotificationResponse();
		try {
			String url = apim_url + notificationApiUrl;
			log.info(String.format("Notification url ::%s", url));
			response = WebClient.create().post().uri(url).header(AUTHORIZATION, BEARER + userbean.getAuthToken())
					.header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
					.body(Mono.just(notification), Notification.class).accept(MediaType.APPLICATION_JSON).retrieve()
					.bodyToMono(NotificationResponse.class).block();
			log.info(String.format("Notification Webclient Method Ended %s", response));
		} catch (Exception e) {
			log.error("Connectivity of Notification Webclient Failed {}", e.getMessage());

			throw new AzureServiceException(
					messageSource.getMessage("api.error.WebclientConnectivityFailed", null, Locale.ENGLISH),
					e.getMessage());
		}

	}

	public RespondentAdminIndividualIdRes individualidWebclient(CaseDetailsByIdReq request) {

		log.info("individualidWebclient Webclient Method Started ");
		RespondentAdminIndividualIdRes resp = new RespondentAdminIndividualIdRes();
		try {
			String url = commonUtil.SESSION_BASE_URL + OMBUDSMANSERVICE_V1_USERMANAGEMENT_RESPONDENTADMININDIVIDUALID;

			resp = WebClient.create().post().uri(url).header(AUTHORIZATION, BEARER + userbean.getAuthToken())
					.header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
					.body(Mono.just(request), RespondentAdminIndividualIdRes.class).accept(MediaType.APPLICATION_JSON)
					.retrieve().bodyToMono(RespondentAdminIndividualIdRes.class).block();
			log.info("individualidWebclient Webclient Method Ended ");
		} catch (Exception e) {
			log.error(
					"individualidWebclient :: Failed Connectivity from CaseManagement API to UserManagement API Webclient Method through Webclient ");

			throw new AzureServiceException(
					messageSource.getMessage("api.error.AzureServiceBusconnectivity", null, Locale.ENGLISH),
					e.getMessage());
		}
		return resp;

	}

	@SuppressWarnings("unchecked")
	public CaseExportDownloadResponse caseExportAvailableForDownload(CaseExportDownloadReq notification) {
		log.info("caseExportAvailableForDownload Started ");
		CaseExportDownloadResponse responseUrl;

		try {
			String url = apim_url + "/ombudsmanservice/v1/notification/caseexportfordownload";
			log.info(String.format("Notification url ::%s", url));
			responseUrl = WebClient.create().post().uri(url).header(AUTHORIZATION, BEARER + userbean.getAuthToken())
					.header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
					.body(Mono.just(notification), CaseExportDownloadReq.class).accept(MediaType.APPLICATION_JSON)
					.retrieve().bodyToMono(CaseExportDownloadResponse.class).block();
			log.info("caseExportAvailableForDownload Webclient Method Ended {}", responseUrl);
		} catch (Exception e) {
			log.error("Connectivity of caseExportAvailableForDownload Webclient Failed ");

			throw new AzureServiceException(
					messageSource.getMessage("api.error.AzureServiceBusconnectivity", null, Locale.ENGLISH),
					e.getMessage());
		}
		return responseUrl;
	}

}
