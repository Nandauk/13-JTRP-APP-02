package com.ombudsman.service.respondent.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(HttpStatus.BAD_REQUEST)
public class CaseManagementInvalidEventNameException extends RespondentsServiceExceptions {

	private static final long serialVersionUID = 1L;

	public CaseManagementInvalidEventNameException(String message, String exceptionMessage) {
		super(message, "CASEMANAGEMENT_INVALID_EVENTNAME_1004", exceptionMessage);
	}
}
