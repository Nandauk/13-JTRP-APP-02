package com.ombudsman.service.respondent.service;

import java.io.IOException;

import org.json.JSONException;

import com.ombudsman.service.respondent.exception.CaseListNotFoundException;
import com.ombudsman.service.respondent.exception.SQLDataAccessException;
import com.ombudsman.service.respondent.model.request.GetCasesByRespondentReq;
import com.ombudsman.service.respondent.model.response.CasesManagementRes;


public interface ICasesByRespondentService {
	
	public CasesManagementRes getCaseListForOrganization(GetCasesByRespondentReq getOrganisationsReq) throws JSONException, IOException, SQLDataAccessException, CaseListNotFoundException;

}
