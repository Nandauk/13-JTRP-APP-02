
package com.ombudsman.service.respondent.serviceimpl;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ombudsman.service.respondent.common.CommonUtil;
import com.ombudsman.service.respondent.common.StaticUtils;
import com.ombudsman.service.respondent.common.UserBean;
import com.ombudsman.service.respondent.common.WebClientData;
import com.ombudsman.service.respondent.exception.CaseUpdateException;
import com.ombudsman.service.respondent.exception.MandatoryFieldException;
import com.ombudsman.service.respondent.exception.OrganizationNotFoundException;
import com.ombudsman.service.respondent.model.ApiResponse;
import com.ombudsman.service.respondent.model.SharedData;
import com.ombudsman.service.respondent.model.dto.UserEventConfiguration;
import com.ombudsman.service.respondent.model.request.BulkCaseUpdateRequest;
import com.ombudsman.service.respondent.model.request.BulkCaseUpdateRequest.NumberOfCases;
import com.ombudsman.service.respondent.model.response.SpResponse;
import com.ombudsman.service.respondent.service.IUpdateFileService;
import com.ombudsman.service.respondent.service.repository.UpdateRequestsRepository;
import com.ombudsman.service.respondent.service.repository.UserEventConfigurationRepository;

@Service
public class UpdateFileService implements IUpdateFileService {
	Logger LOG = LogManager.getRootLogger();
	private static final String CASEID_IS_NULL = "CaseID is Null";

	@Autowired
	StaticUtils staticUtils;

	@Autowired
	UserBean userbean;
	
	@Autowired
	CommonUtil commonUtil;

	@Autowired
	UpdateRequestsRepository updateRequestsRepository;

	@Autowired
	WebClientData webClientData;

	@Autowired
	CaseActivityImpl caseActivityImpl;
	
	@Value("${case_update_user_event_name}")
	public String userEventName;
	
	@Autowired
	UserEventConfigurationRepository userEventConfigurationRepository;
	
	@Override
	public ApiResponse getSharedConfiguration(String url) {

		LOG.info("getSharedConfiguration method started:: {} ", url);
		ApiResponse response = new ApiResponse();
		try {
			String callresponse = staticUtils.callGetApi(url);
			if (callresponse != null && !callresponse.isEmpty() && !callresponse.isBlank()) {
				LOG.info("callresponse is not null:: {} ", callresponse);
				@SuppressWarnings("unchecked")
				List<SharedData> sharedData = new ObjectMapper().readValue(callresponse, List.class);
				if (!sharedData.isEmpty()) {
					response.setSuccess(true);
					response.setMessage("sucess");
					response.setStatus(HttpStatus.OK);
					response.setData(sharedData);
					LOG.info("Data extracted successfully from efile :: {} ", response);
					return response;
				} else {
					response.setSuccess(false);
					response.setMessage("Data extraction failed from efile");
					response.setStatus(HttpStatus.OK);
					LOG.info("Data extraction failed from efile :: {}", response);
					return response;
				}
			} else {
				response.setSuccess(false);
				response.setMessage("Getting URL from APIM failed");
				LOG.info("Getting URL from APIM failed:: {}", response);
				return response;
			}
		} catch (Exception ex) {
			response.setSuccess(false);
			response.setMessage("Error occurred in getSharedConfiguration Method ");
			LOG.info("GetSharedConfiguration Method Failed {}", response);
			return response;
		}
	}

	public List<String> getAccountIds(String oid) {
		LOG.info("getAccountIds method started::{} ",oid);
		return updateRequestsRepository.getAccountId(oid);
	}

	
	@Override
	public ApiResponse bulkupdateCase(BulkCaseUpdateRequest dto) throws OrganizationNotFoundException, MandatoryFieldException, JsonProcessingException {
		LOG.info("Bulk UpdateCase method started:: {} ", dto);
		
		ApiResponse response = new ApiResponse();
		List<NumberOfCases> caseIdList = dto.getNumberOfCases();
		LOG.info("List of caseID and comments:: {} ", caseIdList);
		List<String> caseIds =new  ArrayList<>();
		
	
	try {		
		

			final List<String> adAccountId = getAccountIds(userbean.getUserObjectId());
			dto.setUserId(userbean.getUserObjectId());
			
			//STEP 1: Authorization Check AccountID is not Null
			if (Objects.isNull(adAccountId)) {
				throw new OrganizationNotFoundException("No organisation found");
			}
			LOG.info("Account id fetched is ::{}", adAccountId);
			
			//setting Account ID in request message
			dto.setUsersAccountIds(adAccountId); 
			
			//Fetching and adding all CaseIds in a List 
			for(NumberOfCases eachCase : caseIdList ){
				if(eachCase.getCaseId() != null) {
				caseIds.add(eachCase.getCaseId());
				LOG.info("Caseid fetched from request is ::{}", eachCase.getCaseId());
				}else {
					LOG.info(CASEID_IS_NULL);
					throw new MandatoryFieldException("caseId");
				}
			}
			String caseIdsString = String.join(",", caseIds);	
			
			//STEP 2: Call to Authorization Stored procedure to check if all cases and user belong to single Organization
			final List<Object[]> orgIds = updateRequestsRepository.validateOrg(userbean.getUserObjectId(),caseIdsString);
			LOG.info("Org id fetched for IOD and CaseIds should be same ::{}", orgIds);	
			List<SpResponse> validationResults = new ArrayList<>(); 
			for (Object[] result : orgIds) 
			{ 
				SpResponse validationResult = new SpResponse((String) result[0], (String) result[1], (String) result[2]); 
				validationResults.add(validationResult); 
			}
			
			
			//Step 3: Adding record in Audit Table
			UserEventConfiguration eventName = userEventConfigurationRepository.getUserEventRecord(userEventName);
			LOG.info("UserEventName:-{}", eventName.getUserEventName());
			if (!(eventName.getUserEventName().isBlank() && eventName.getUserEventName().isEmpty())) {
				caseActivityImpl.postAuditEntries(response, eventName.getUserEventName());
			}
			
			//Step 4 : Generate UUID which will be added as PackageID in request table
			String packageId_Req = UUID.randomUUID().toString();
			dto.setPackageIdReq(packageId_Req);
			
			LOG.info("Bulk case update request ready to be sent to service bus");
			
			//Step 6 : Calling service bus(Internal Service bus Queue needed)
			LOG.info("Bulk case update message to be sent to service bus: {}",dto);
			
			webClientData.bulkUpdateCaseServiceBusWebclient(dto);

			LOG.info("sent data in service bus queue");
			
			response.setStatus(HttpStatus.OK);
			response.setSuccess(true);
			response.setMessage("Your request has been submitted to the case investigator who will review it and action as needed. A copy will be made available in the Case Files tab.");
			LOG.info("successfully getting response :{}", response);
			return response;
	
	}catch(CaseUpdateException ex) {
		throw new CaseUpdateException("Error Occurred in Case Update API. Please Try Again.","");
		
	}

	}
}
