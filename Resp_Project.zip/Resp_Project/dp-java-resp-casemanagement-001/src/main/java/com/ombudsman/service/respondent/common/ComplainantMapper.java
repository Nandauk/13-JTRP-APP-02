package com.ombudsman.service.respondent.common;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.mapstruct.BeforeMapping;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import com.ombudsman.service.respondent.model.Complainant;
import com.ombudsman.service.respondent.model.dto.ComplainantDto;

@Mapper(componentModel = "spring")
public interface ComplainantMapper {
	ComplainantMapper INSTANCE = Mappers.getMapper(ComplainantMapper.class);
	Logger LOG =  LogManager.getRootLogger();

	@BeforeMapping
	public default void bithDateMapping(ComplainantDto complainantDtoObj) {
		complainantDtoObj.setOrganisation_existInComplainant("No");
		/*complainantDtoObj.setBirthdate("08-Mar-1997");
		
		 * Date contactBirthDate = complainantDtoObj.getBirthdate(); var
		 * contactBirthDateFromateFrom = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.S");
		 * var contactBirthDateFromateTo = new SimpleDateFormat("dd-MM-yyyy"); if
		 * (contactBirthDate != null) { String uiBirthDate = null; try { uiBirthDate =
		 * contactBirthDateFromateTo.format(contactBirthDate);
		 * complainantDtoObj.setBirthdate(contactBirthDateFromateTo.parse(uiBirthDate));
		 * } catch (Exception e) { LOG.error("Exception while parsing birthDate"); }
		 * 
		 * } else { complainantDtoObj.setBirthdate(contactBirthDate); }
		 */
	}
	 
	Complainant complainantDtls(ComplainantDto complainantDtoObj);
}
