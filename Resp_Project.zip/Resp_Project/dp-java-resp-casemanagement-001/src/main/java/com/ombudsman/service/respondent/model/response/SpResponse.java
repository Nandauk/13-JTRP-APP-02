package com.ombudsman.service.respondent.model.response;

public class SpResponse {
    private String accountid;
    private String name;
    private String Scenario;
    // Constructors
   

 
    public SpResponse(String accountid, String name, String scenario) {
		super();
		this.accountid = accountid;
		this.name = name;
		Scenario = scenario;
	}



	public String getAccountid() {
		return accountid;
	}



	public void setAccountid(String accountid) {
		this.accountid = accountid;
	}



	public String getName() {
		return name;
	}



	public void setName(String name) {
		this.name = name;
	}



	public String getScenario() {
		return Scenario;
	}



	public void setScenario(String scenario) {
		Scenario = scenario;
	}
}
