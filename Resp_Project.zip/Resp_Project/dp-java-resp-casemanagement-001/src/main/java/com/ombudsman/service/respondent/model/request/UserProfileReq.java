package com.ombudsman.service.respondent.model.request;


public class UserProfileReq {
	
	private String email;
	
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
	

}
