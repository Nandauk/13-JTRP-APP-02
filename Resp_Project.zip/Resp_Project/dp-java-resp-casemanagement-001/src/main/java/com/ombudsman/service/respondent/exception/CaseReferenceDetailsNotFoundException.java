package com.ombudsman.service.respondent.exception;

public class CaseReferenceDetailsNotFoundException  extends RuntimeException {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public CaseReferenceDetailsNotFoundException(String exceptionMsg)
	{
		super(exceptionMsg);
	}


}
