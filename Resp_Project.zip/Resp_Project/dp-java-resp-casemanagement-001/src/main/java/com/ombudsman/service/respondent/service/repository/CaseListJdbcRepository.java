package com.ombudsman.service.respondent.service.repository;

import static com.ombudsman.service.respondent.common.Constants.ACCOUNT_IDS;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import javax.sql.DataSource;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Component;

import com.ombudsman.service.respondent.exception.SQLDataAccessException;
import com.ombudsman.service.respondent.exception.SQLServerException;
import com.ombudsman.service.respondent.model.dto.CaseFilterDetailsDto;
import com.ombudsman.service.respondent.model.dto.CaseOwnerCountProjectionDto;
import com.ombudsman.service.respondent.model.dto.CaseWorkerDto;
import com.ombudsman.service.respondent.model.dto.OrganizationDto;

import io.jsonwebtoken.lang.Collections;
import jakarta.transaction.Transactional;

/**
 * @author rdutta2
 *
 */
@Component
public class CaseListJdbcRepository {	
	@Autowired
	JdbcTemplate jdbcTemplate;
	@Autowired
	NamedParameterJdbcTemplate namedJdbcTemplate;
	Logger logger =  LogManager.getRootLogger();
	
	

	public void setDataSource(DataSource dataSource) {
		this.jdbcTemplate = new JdbcTemplate(dataSource);
	}
	public Map<String, Object> getOrganisationAccountIds(String reqParam) {
		final SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName("prc_getUserAccountId");
		Map<String, String> inParamMap = new HashMap<>();
		inParamMap.put("oidinput", reqParam);
		SqlParameterSource in = new MapSqlParameterSource(inParamMap);
		Map<String, Object> simpleJdbcCallResult = simpleJdbcCall.execute(in);
		logger.debug("getOrganisationAccountIds>>response from db::{}",
				simpleJdbcCallResult);
		return simpleJdbcCallResult;
	}
	
	public Map<String, Object> getAccountIds(Map<String, String> reqParam) {
		final SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName("prc_GetADAccountid");
		Map<String, String> inParamMap = new HashMap<>();
		inParamMap.put("ADAccountid", reqParam.get(ACCOUNT_IDS));
		SqlParameterSource in = new MapSqlParameterSource(inParamMap);
		Map<String, Object> simpleJdbcCallResult = simpleJdbcCall.execute(in);
		logger.debug("getCaseListDetails>>response from db::{}",
				simpleJdbcCallResult);
		return simpleJdbcCallResult;
	}
	
	
	public Map<String, Object> getCaseListDetails(Map<String, Object> reqParam) throws SQLDataAccessException{
		logger.info("getCaseListDetails method parameteres passing to Store procedure added sorted parameters::{}:", reqParam);
		final SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate)
				.withProcedureName("prc_GetCaselistDetails");
		SqlParameterSource in = new MapSqlParameterSource(reqParam);		
		return simpleJdbcCall.execute(in);

	}

	
	public List<CaseFilterDetailsDto> getCaseFilter(List<String> accountIds) throws SQLDataAccessException{
		final String sql = "SELECT distinct Filtertype as FilterType,filter_values as FilterValue,filter_ids as AccountId FROM c_caselist_filters as caseFilter where accountid IN (:ids)";

		final SqlParameterSource parameters = new MapSqlParameterSource("ids", accountIds);
		return namedJdbcTemplate.query(sql, parameters,
				(rs, rowNum) -> new CaseFilterDetailsDto(rs.getString("FilterType"), rs.getString("FilterValue"),
						rs.getString("AccountId")));	
	}
	
	public List<OrganizationDto> getFindOrganizationName(List<String> accountIds) throws SQLDataAccessException{
	  final String sql = "SELECT name as organizationName, accountid as organizationId FROM account WHERE  fos_hierarchylevel IN ('1', '2') AND (accountid IN (:ids)  OR parentaccountid IN (:ids))";
		
		final SqlParameterSource parameters = new MapSqlParameterSource("ids", accountIds);
		return namedJdbcTemplate.query(sql, parameters,
				(rs, rowNum) -> new OrganizationDto(rs.getString("organizationName"),rs.getString("organizationId")));
	}
	public List<CaseOwnerCountProjectionDto> getCaseOwnerCountSQL(String accountIds) throws SQLDataAccessException {
	    final String methodName = "getCaseOwnerCountSQL";
	    try {
	      
	        final SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate)
	                .withProcedureName("prc_getcaseowners")
	                .returningResultSet("caseOwners", (rs, rowNum) -> 
	                    new CaseOwnerCountProjectionDto(
	                        rs.getString("Incident_count"),
	                        rs.getString("OwnerName"),
	                        rs.getString("emailaddress")
	                      //  rs.getString("customerid")
	                    )
	                );

	       
	        Map<String, Object> inParamMap = new HashMap<>();
	        inParamMap.put("accountids", accountIds); 
	        SqlParameterSource in = new MapSqlParameterSource(inParamMap);

	        
	        Map<String, Object> result = simpleJdbcCall.execute(in);

	       
	        @SuppressWarnings("unchecked")
	        List<CaseOwnerCountProjectionDto> caseOwners = (List<CaseOwnerCountProjectionDto>) result.get("caseOwners");

	        return caseOwners;
	    } catch (Exception ex) {
	        throw new SQLDataAccessException("Error while calling stored procedure");
	    }
	}

	/*
	 *    CaseWorkerListById ,  AssignCases
	 */
	
	public Integer getRoleId(String role) throws SQLServerException {
	   // final String sql = "SELECT respondent_group_id FROM dp_respondent_groups WHERE group_name  =:role";
	    final String sql = "SELECT role_id FROM dp_respondent_roles WHERE role_name =:role";
	    

	    Map<String, Object> params = new HashMap<>();
	    params.put("role", role); 
	    try {
	        return namedJdbcTemplate.queryForObject(sql, params, Integer.class);
	    } catch (Exception e) {
	        logger.error("Error fetching role IDs: {}", e.getMessage());
	        throw new SQLServerException("Error fetching role IDs");
	    }
	}
	
	
	public List<Integer> getGroupId(String account_id) throws SQLServerException {
	    //final String sql = "SELECT respondent_group_id FROM dp_respondent_groups WHERE pnx_group_id =:account_id";
	    
	    final String sql = "select respondent_group_id  from dp_respondent_groups "
	    + "where ((pnx_group_id in (select parentaccountid from account where accountid=:account_id)) or (pnx_group_id in (:account_id)))" ;

	    Map<String, Object> params = new HashMap<>();
	    params.put("account_id", account_id); 
	    try {
	         List<Integer> groupIds = namedJdbcTemplate.queryForList(sql, params, Integer.class);
	         
	         return groupIds;
	    } catch (Exception e) {
	        logger.error("Error fetching account Id: {}", e.getMessage());
	        throw new SQLServerException("Error fetching account ID");
	    }
	}
	
	
	
    public List<CaseWorkerDto> getCaseworkersByRoleIdsAndGroup(List<Integer> roleIds, List<Integer> groupId,String aduserid) throws SQLServerException {
        final String sql = "SELECT oid, full_name, email FROM dp_user_dprespondent " +
                           "WHERE user_ad_status = 'Enable' " + "AND invited_status = 'Accepted' " +
                           "AND oid IN (SELECT ad_user_id FROM dp_user_group_role_respondent " +
                           "WHERE id_role IN (:roleIds) AND id_group IN (:groupId)) "
                           + "AND oid != :aduserid";

        Map<String, Object> params = new HashMap<>();
        params.put("roleIds", roleIds);
        params.put("groupId", groupId);
        params.put("aduserid", aduserid);

        try {
            return namedJdbcTemplate.query(sql, params, (rs, rowNum) -> {
                CaseWorkerDto dto = new CaseWorkerDto();
                dto.setOId(rs.getString("oid"));
                dto.setFullname(rs.getString("full_name"));
                dto.setInternalemailaddress(rs.getString("email"));
                return dto;
            });
        } catch (Exception e) {
            logger.error("Error fetching caseworker details for groupId {}: {}", groupId, e.getMessage());
            throw new SQLServerException("Error fetching caseworker details");
        }
    }

    
    public Map<String, Object> getAccountIdsAndRolesByOid(String oidinput) throws SQLServerException {
        final String procedureName = "prc_getUserAccountIdUserrole"; // new SP name
        final SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate)
                                                .withProcedureName(procedureName);
        
        Map<String, Object> inParamMap = new HashMap<>();
        inParamMap.put("oidinput", oidinput); 

        SqlParameterSource in = new MapSqlParameterSource(inParamMap);
        
        try {
            Map<String, Object> result = simpleJdbcCall.execute(in);
            logger.debug("getAccountIdsAndRolesByOid>>response from db::{}", result);
            return result;
        } catch (Exception e) {
            logger.error("Error executing stored procedure {}: {}", procedureName, e.getMessage());
            throw new SQLServerException("Error executing stored procedure ");
        }
    }
   
    
    
    public boolean validateUserAndCases(String userOid, List<String> caseIds) throws SQLServerException {
        final String procedureName = "prc_oidIncActValidation_bol"; 
        final SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate)
                                                .withProcedureName(procedureName);

        String incidentid = String.join(",", caseIds);

        Map<String, Object> inParamMap = new HashMap<>();
        inParamMap.put("oidinput", userOid);
        inParamMap.put("incidentid", incidentid); 

        SqlParameterSource in = new MapSqlParameterSource(inParamMap);

        try {
            Map<String, Object> result = simpleJdbcCall.execute(in);

            @SuppressWarnings("unchecked")
            List<Map<String, Object>> resultSet = (List<Map<String, Object>>) result.get("#result-set-1");

            if (resultSet == null || resultSet.isEmpty()) {
                logger.error("Stored procedure {} did not return any results", procedureName);
                return false;
            }

           
            for (Map<String, Object> row : resultSet) {
                Object accountIdResultObj = row.get("accountid_results");

                if (accountIdResultObj instanceof Number) {
                    int accountIdResult = ((Number) accountIdResultObj).intValue();
                    if (accountIdResult == 1) {
                        logger.debug("Valid case found in response: {}", result);
                        return true;
                    }
                } else {
                    logger.error("Unexpected type for accountid_results: {}", 
                                 accountIdResultObj != null ? accountIdResultObj.getClass().getName() : "null");
                }
            }

            logger.debug("No valid cases found in response: {}", result);
            return false;

        } catch (Exception e) {
            logger.error("Error executing stored procedure {}: {}", procedureName, e.getMessage(), e);
            throw new SQLServerException("Error executing stored procedure");
        }
    }


    
    public String assignCasesToUser(List<String> caseIds, String oid) {
        // 1) Fetch already assigned incident IDs in one shot
        final String FIND_EXISTING_CASES_SQL =
            "SELECT incidentid FROM DP_Assign_Cases_To_Users WHERE incidentid IN (:caseIds)";
        Map<String, Object> params = new HashMap<>();
        params.put("caseIds", caseIds);
        
        List<String> existingCaseList = namedJdbcTemplate.queryForList(FIND_EXISTING_CASES_SQL, params, String.class);
         
        Set<String> existingCaseSet = new HashSet<>(existingCaseList);

        // Separate new ones vs. already assigned
        List<String> toUpdate = new ArrayList<>();
        List<String> toInsert = new ArrayList<>();
        for (String caseId : caseIds) {
            if (existingCaseSet.contains(caseId)) {
                toUpdate.add(caseId);
            } else {
                toInsert.add(caseId);
            }
        }

        // 2) Update existing assignments
        if (!toUpdate.isEmpty()) {
            final String UPDATE_SQL = "UPDATE DP_Assign_Cases_To_Users SET userid=? WHERE incidentid=?";
            List<Object[]> updateBatch = toUpdate.stream()
                    .map(caseId -> new Object[] { oid, caseId })
                    .collect(Collectors.toList());
            jdbcTemplate.batchUpdate(UPDATE_SQL, updateBatch);
        }

        // 3) Insert new assignments
        if (!toInsert.isEmpty()) {
            final String INSERT_SQL = "INSERT INTO DP_Assign_Cases_To_Users (incidentid, userid) VALUES (?, ?)";
            List<Object[]> insertBatch = toInsert.stream()
                    .map(caseId -> new Object[] { caseId, oid })
                    .collect(Collectors.toList());
            jdbcTemplate.batchUpdate(INSERT_SQL, insertBatch);
        }

        // 4) Return the user’s full name
        final String sql = "SELECT full_name FROM dp_user_dprespondent WHERE oid = :oid ";
        Map<String, Object> params_name = new HashMap<>();
        params_name.put("oid", oid);
        return namedJdbcTemplate.queryForObject(sql, params_name, String.class);
    }

   
    public List<String> getIncidentIdsByTicketNumbers(List<String> ticketNumbers) {
        String sql = "SELECT incidentid FROM incident WHERE ticketnumber IN (:ticketNumbers)";

        Map<String, Object> params = new HashMap<>();
        params.put("ticketNumbers", ticketNumbers);

        List<String> incidentIds = namedJdbcTemplate.queryForList(sql, params, String.class);

        return incidentIds;
    }
    

    @Transactional
    public void createAuditForCaseAssignment(
            String auditEventName,
            String primaryAuditEntity,
            String primaryAuditEntityIdentifier,
            String assignedToName,
            List<String> incidentIds,
            String userOid,   
            String createdBy   
    ) {
        
        String preAuditSnapshot = findLastPostSnapshot(auditEventName);

        
        String postAuditSnapshot = assignedToName + " - " + String.join(", ", incidentIds);

       
        insertAuditEvent(
            userOid,
            auditEventName,
            primaryAuditEntity,
            primaryAuditEntityIdentifier,
            preAuditSnapshot,
            postAuditSnapshot,
            createdBy
        );
    }

 
    private String findLastPostSnapshot(String eventName) {
        String sql = "SELECT TOP 1 post_audit_snapshot "
                   + "FROM dp_audit_event "
                   + "WHERE audit_event_name = :eventName "
                   + "ORDER BY audit_event_timestamp DESC";
        
        Map<String, Object> params = new HashMap<>();
        params.put("eventName", eventName);

        List<String> snapshots = namedJdbcTemplate.queryForList(sql, params, String.class);

        return snapshots.isEmpty() ? null : snapshots.get(0);
    }

   
    private void insertAuditEvent(
        String userOid,
        String auditEventName,
        String primaryAuditEntity,
        String primaryAuditEntityIdentifier,
        String preAuditSnapshot,
        String postAuditSnapshot,
        String createdBy
    ) {
        
        String sql = "INSERT INTO dp_audit_event ("
                   + "  user_oid, "
        		   + "audit_event_timestamp,"
                   + "  audit_event_name, "
                   + "  primary_audit_entity, "
                   + "  primary_audit_entity_identifier, "
                   + "  pre_audit_snapshot, "
                   + "  post_audit_snapshot, "
                   + "  created_by, "
                   + "  modified_by "
                   + ") VALUES ("
                   + "  :userOid, "
                   + "  CURRENT_TIMESTAMP,"
                   + "  :auditEventName, "
                   + "  :primaryAuditEntity, "
                   + "  :primaryAuditEntityIdentifier, "
                   + "  :preAuditSnapshot, "
                   + "  :postAuditSnapshot, "
                   + "  :createdBy, "
                   + "  :userOid "
                   + ")";

        Map<String, Object> params = new HashMap<>();
        params.put("userOid", userOid);
        params.put("auditEventName", auditEventName);
        params.put("primaryAuditEntity", primaryAuditEntity);
        params.put("primaryAuditEntityIdentifier", primaryAuditEntityIdentifier);
        params.put("preAuditSnapshot", preAuditSnapshot);
        params.put("postAuditSnapshot", postAuditSnapshot);
        params.put("createdBy", createdBy);

        namedJdbcTemplate.update(sql, params);
    }


}
