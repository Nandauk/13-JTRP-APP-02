package com.ombudsman.service.respondent.exception;

public class RespondentsServiceExceptions extends RuntimeException {

	private static final long serialVersionUID = 1L;
	private final String code;
	private final String message;
	private final String exceptionMessage;

	public RespondentsServiceExceptions(String message, String code, String exceptionMessage) {
		super(message);

		this.code = code;
		this.message = message;
		this.exceptionMessage = exceptionMessage;

	}

	public String getCode() {
		return code;
	}

	@Override
	public String getMessage() {
		return message;
	}

	public String getExceptionMessage() {
		return exceptionMessage;
	}

}
