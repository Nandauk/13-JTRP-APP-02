package com.ombudsman.service.respondent.common;

import java.util.Locale;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.MessageSource;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import com.ombudsman.service.respondent.exception.CaseUpdateException;

@Service
public class StaticUtils {

	Logger LOG = LogManager.getRootLogger();

	@Value("${case_update_apim_baseurl}")
	public String baseurl;
	

	@Autowired
	UserBean userbean;
	@Autowired
	private MessageSource messageSource;

	public String callGetApi(String url) {
		LOG.info("callGetApi method started :: {} ", url);
		try {
			return WebClient.builder().build().get().uri(url).headers(httpHeaders -> {
				httpHeaders.set("Authorization", "Bearer " + userbean.getAuthToken());
			}).accept(MediaType.APPLICATION_JSON).retrieve().bodyToMono(String.class).block();
		} catch (Exception e) {
			LOG.error("Data sending failed from caseUpdate while posting to APIM");
			throw new CaseUpdateException(
					"Data sending failed from caseUpdate while posting to APIM. Please Try Again.",
					messageSource.getMessage("api.error.postingurlfailed", null, Locale.ENGLISH));
		}

	}

	public String getUrl(String getSharedConfigurationUrl) {
		LOG.info(" GetUrl method started :: {} ", getSharedConfigurationUrl);
		try {
			String url = baseurl + getSharedConfigurationUrl ;
			LOG.info("Case update :: getUrl methode ended :: getting url from apim  :: {} ", url);
			return url;
		
		} catch (Exception e) {
			LOG.error("Error in  getUrl while fetching URL from APIM ");
			throw new CaseUpdateException("Error in  getUrl while fetching URL from APIM. Please Try Again.",
					messageSource.getMessage("api.error.fetchingurlfailed", null, Locale.ENGLISH));
		}

	}

}
