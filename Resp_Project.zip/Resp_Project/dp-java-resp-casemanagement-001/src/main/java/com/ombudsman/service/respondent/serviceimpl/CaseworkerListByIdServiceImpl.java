package com.ombudsman.service.respondent.serviceimpl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.security.auth.login.AccountNotFoundException;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ombudsman.service.respondent.common.UserBean;
import com.ombudsman.service.respondent.exception.InvalidOrganisationException;
import com.ombudsman.service.respondent.exception.MandatoryFieldMissingException;
import com.ombudsman.service.respondent.exception.OrganisationIdMissingException;
import com.ombudsman.service.respondent.exception.SQLDataAccessException;
import com.ombudsman.service.respondent.exception.SQLServerException;
import com.ombudsman.service.respondent.exception.UnAuthorisedException;
import com.ombudsman.service.respondent.model.dto.CaseWorkerDto;
import com.ombudsman.service.respondent.model.request.CaseworkerReq;
import com.ombudsman.service.respondent.model.response.CaseworkerListByIdRes;
import com.ombudsman.service.respondent.model.response.CaseworkerListByIdRes.Caseworker;
import com.ombudsman.service.respondent.service.CaseworkerListByIdService;
import com.ombudsman.service.respondent.service.repository.CaseListJdbcRepository;

import static com.ombudsman.service.respondent.common.Constants.*;

import java.util.Collections;

@Service
public class CaseworkerListByIdServiceImpl implements CaseworkerListByIdService {

    private static final Logger log = LogManager.getLogger(CaseworkerListByIdServiceImpl.class);

    private static final String UNAUTHORIZED = "USER_UNAUTHORIZED"; 
    private static final String MISSING_FIELD = "MISSING_FIELD";

	private static final String CASEWORKERS_FETCHED_SUCCESSFULLY = "CASEWORKERS_FETCHED_SUCCESSFULLY";

	private static final String USER_UNAUTHORIZED = null;

    @Autowired
    private UserBean userBean;

    @Autowired
    private CaseListJdbcRepository caseListJdbcRepository;

    @Override
    public CaseworkerListByIdRes getCaseworkers(CaseworkerReq request)
            throws SQLDataAccessException, AccountNotFoundException, UnAuthorisedException, InvalidOrganisationException {
        log.debug("getCaseworkers Service Method Started. CorrelationId: {}, OID: {}",
                userBean.getCorrelationId(), userBean.getUserObjectId());

        String accountId = request.getAccountid();

        validateAndAuthorize(accountId);

        try {

            Integer caseworkerRoleId = caseListJdbcRepository.getRoleId("CaseWorker");
            Integer supervisorRoleId = caseListJdbcRepository.getRoleId("Supervisor");
            //Integer Resp_Supervisor_ID = caseListJdbcRepository.getRoleId("Resp-supervisor");
            
            List<Integer> groupId = caseListJdbcRepository.getGroupId(accountId);

            List<Integer> roleIds = new ArrayList<>();
            roleIds.add(supervisorRoleId);
            roleIds.add(caseworkerRoleId);
            //roleIDs.add(Resp_Supervisor_ID);

            log.debug("Fetched Role IDs: {}", logFormat(String.valueOf(roleIds)));
            log.debug("Fetched Group ID: {}", logFormat(String.valueOf(groupId)));

            List<CaseWorkerDto> caseworkers = caseListJdbcRepository.getCaseworkersByRoleIdsAndGroup(roleIds, groupId,userBean.getUserObjectId());

            CaseworkerListByIdRes response = new CaseworkerListByIdRes();
            
            List<Caseworker> caseworkerList = caseworkers.stream()
            		 .map(dto -> new CaseworkerListByIdRes.Caseworker(
                            dto.getFullname(),
                            dto.getInternalemailaddress(),
                            dto.getOId()
                    ))
                    .collect(Collectors.toList());
            
      
            response.setCaseworkerList(caseworkerList);
            response.setStatus(SUCCESS); 
            response.setMessage(CASEWORKERS_FETCHED_SUCCESSFULLY); 
            log.debug("Found {} caseworkers for accountId: {}", logFormat(String.valueOf(caseworkerList.size())), logFormat(accountId));

            return response;

        } catch (SQLServerException e) {
            log.error("Database error occurred while fetching caseworker data for accountId: {}", accountId, e);
            throw new SQLServerException("Record creation failed");
        }
    }

    private void validateAndAuthorize(String accountId)
            throws AccountNotFoundException, UnAuthorisedException, InvalidOrganisationException {
        if (StringUtils.isEmpty(accountId)) {
            // accountId is required
            throw new OrganisationIdMissingException("Organisation Id is missing");
        }

        try {
            // 1: Fetch OID from JWT (userBean)
            String userOidFromJWT = userBean.getUserObjectId();
            if (StringUtils.isEmpty(userOidFromJWT)) {
                // If we can't get a user OID, user is not authorized
                throw new MandatoryFieldMissingException(MISSING_FIELD);
            }

            // 2: Call the SP to get account IDs and roles
            Map<String, Object> spResult = caseListJdbcRepository.getAccountIdsAndRolesByOid(userOidFromJWT);

            // Extract the result set from the stored procedure response
            @SuppressWarnings("unchecked")
            List<Map<String, Object>> resultSet = (List<Map<String, Object>>) spResult.get("#result-set-1");

            if (resultSet == null || resultSet.isEmpty()) {
                throw new MandatoryFieldMissingException(MISSING_FIELD);
            }

            List<String> spAccountIds = resultSet.stream()
                    .map(map -> (String) map.get("accountid"))
                    .filter(StringUtils::isNotEmpty)
                    .collect(Collectors.toList());

            List<String> spRoles = resultSet.stream()
                    .map(map -> (String) map.get("ad_group_name"))
                    .filter(StringUtils::isNotEmpty)
                    .collect(Collectors.toList());
            
          

            if (spAccountIds == null || spAccountIds.isEmpty() || spRoles == null || spRoles.isEmpty()) {
               
                throw new MandatoryFieldMissingException(UNAUTHORIZED);
            }

           
            if (spAccountIds.stream().noneMatch(id -> id.equalsIgnoreCase(accountId))) {
                throw new InvalidOrganisationException(USER_UNAUTHORIZED);
            }

           if(!(spRoles.stream().anyMatch(role -> role.toLowerCase().contains("supervisor"))))
           {
           	throw new InvalidOrganisationException(USER_UNAUTHORIZED);
           }

        } catch (SQLServerException e) {
            log.error("Error during authorization: {}", e.getMessage());
            throw new SQLServerException("Authorization Failed due to internal error.");
        }
    }
    private  String logFormat(String original) {
		String clean = original.replace('\n', '_').replace('\r', '_');
		StringBuilder sb = new StringBuilder(clean);
		return sb.toString();
	}

}
