package com.ombudsman.service.respondent.model;

import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.Test;

class CaseTest {

    @Test
    void testCaseModelGettersAndSetters() {
        Case c = new Case();

        // incidentid
        c.setIncidentid("INC123");
        assertEquals("INC123", c.getIncidentid());

        // ticketnumber
        c.setTicketnumber("TICK-999");
        assertEquals("TICK-999", c.getTicketnumber());

        // fos_crn
        c.setFos_crn("CRN-123");
        assertEquals("CRN-123", c.getFos_crn());

        // _customerid_value
        c.set_customerid_value("CUST-ABC");
        assertEquals("CUST-ABC", c.get_customerid_value());

        // businessname
        c.setBusinessname("AXA Insurance UK Plc");
        assertEquals("AXA Insurance UK Plc", c.getBusinessname());

        // fos_reference
        c.setFos_reference("REF-123");
        assertEquals("REF-123", c.getFos_reference());

        // fos_extendedreference
        c.setFos_extendedreference("EXT-ABC");
        assertEquals("EXT-ABC", c.getFos_extendedreference());

        // _fos_complaintissue_value
        c.set_fos_complaintissue_value("IssueVal");
        assertEquals("IssueVal", c.get_fos_complaintissue_value());

        // _fos_complaintissue_value_txt
        c.set_fos_complaintissue_value_txt("Breach of Confidentiality");
        assertEquals("Breach of Confidentiality", c.get_fos_complaintissue_value_txt());

        // _fos_productorproductfamily_value
        c.set_fos_productorproductfamily_value("ProductVal");
        assertEquals("ProductVal", c.get_fos_productorproductfamily_value());

        // _fos_productorproductfamily_value_txt
        c.set_fos_productorproductfamily_value_txt("Balance Transfers");
        assertEquals("Balance Transfers", c.get_fos_productorproductfamily_value_txt());

        // fos_casestage
        c.setFos_casestage("Investigation");
        assertEquals("Investigation", c.getFos_casestage());

        // fos_casestage_txt
        c.setFos_casestage_txt("Investigation Stage");
        assertEquals("Investigation Stage", c.getFos_casestage_txt());

        // statuscode
        c.setStatuscode("AwaitingAction");
        assertEquals("AwaitingAction", c.getStatuscode());

        // statuscode_txt
        c.setStatuscode_txt("Awaiting Action");
        assertEquals("Awaiting Action", c.getStatuscode_txt());

        // fos_dateofreferral
        c.setFos_dateofreferral("2023-10-12");
        assertEquals("2023-10-12", c.getFos_dateofreferral());

        // agecaseflag
        c.setAgecaseflag("Yes");
        assertEquals("Yes", c.getAgecaseflag());

        // fos_representatives
        c.setFos_representatives("RepName123");
        assertEquals("RepName123", c.getFos_representatives());

        // fos_datecasefirstmovedtoinvestigation
        c.setFos_datecasefirstmovedtoinvestigation("2023-09-10");
        assertEquals("2023-09-10", c.getFos_datecasefirstmovedtoinvestigation());

        // fos_dateofconversion
        c.setFos_dateofconversion("2023-09-11");
        assertEquals("2023-09-11", c.getFos_dateofconversion());

        // fos_datebusinessfilereceived
        c.setFos_datebusinessfilereceived("2023-09-12");
        assertEquals("2023-09-12", c.getFos_datebusinessfilereceived());

        // fos_dispatcheddate
        c.setFos_dispatcheddate("2023-09-13");
        assertEquals("2023-09-13", c.getFos_dispatcheddate());

        // fos_type
        c.setFos_type("Type123");
        assertEquals("Type123", c.getFos_type());

        // fos_categorycode
        c.setFos_categorycode("Cat-XYZ");
        assertEquals("Cat-XYZ", c.getFos_categorycode());

        // fos_oldercasestatus
        c.setFos_oldercasestatus("12 months old");
        assertEquals("12 months old", c.getFos_oldercasestatus());

        // _fos_caseworker_value
        c.set_fos_caseworker_value("Worker-001");
        assertEquals("Worker-001", c.get_fos_caseworker_value());

        // fos_individualid
        c.setFos_individualid("IND-777");
        assertEquals("IND-777", c.getFos_individualid());

        // caseagebanding
        c.setCaseagebanding("6-12 months");
        assertEquals("6-12 months", c.getCaseagebanding());

        // noofefile
        c.setNoofefile("2");
        assertEquals("2", c.getNoofefile());

        // noofcorrespondet
        c.setNoofcorrespondet("5");
        assertEquals("5", c.getNoofcorrespondet());

        // fos_dateofevent
        c.setFos_dateofevent("2023-01-01");
        assertEquals("2023-01-01", c.getFos_dateofevent());

        // vulnerable
        c.setVulnerable("Yes");
        assertEquals("Yes", c.getVulnerable());

        // fos_dateoffinalresponse
        c.setFos_dateoffinalresponse("2023-01-15");
        assertEquals("2023-01-15", c.getFos_dateoffinalresponse());

        // fos_offeroutcome
        c.setFos_offeroutcome("Outcome 123");
        assertEquals("Outcome 123", c.getFos_offeroutcome());

        // fos_changeinoutcome
        c.setFos_changeinoutcome("Changed outcome text");
        assertEquals("Changed outcome text", c.getFos_changeinoutcome());

        // deadlockcases
        c.setDeadlockcases("Deadlock date info");
        assertEquals("Deadlock date info", c.getDeadlockcases());

        // fos_tradingname
        c.setFos_tradingname("TradeName Inc.");
        assertEquals("TradeName Inc.", c.getFos_tradingname());

        // fos_prioritycode
        c.setFos_prioritycode("High");
        assertEquals("High", c.getFos_prioritycode());

        // fos_prioritycode_txt
        c.setFos_prioritycode_txt("High Priority");
        assertEquals("High Priority", c.getFos_prioritycode_txt());

        // _owninguser_value
        c.set_owninguser_value("owner-ABC");
        assertEquals("owner-ABC", c.get_owninguser_value());

        // description
        c.setDescription("Test Description");
        assertEquals("Test Description", c.getDescription());

        // br_required
        c.setBr_required("Yes");
        assertEquals("Yes", c.getBr_required());

        // statecode
        c.setStatecode("Active");
        assertEquals("Active", c.getStatecode());

        // awaitingAction
        c.setAwaitingAction("No");
        assertEquals("No", c.getAwaitingAction());

        // awaitingactionfilter
        c.setAwaitingactionfilter("Filter-ABC");
        assertEquals("Filter-ABC", c.getAwaitingactionfilter());

        // fos_outcomedispatcheddate
        c.setFos_outcomedispatcheddate("2023-11-01");
        assertEquals("2023-11-01", c.getFos_outcomedispatcheddate());

        // fos_resolvingoutcomeid
        c.setFos_resolvingoutcomeid("RES-999");
        assertEquals("RES-999", c.getFos_resolvingoutcomeid());

        // fos_caseprogress
        c.setFos_caseprogress("Case in progress");
        assertEquals("Case in progress", c.getFos_caseprogress());

        // fos_caseprogress_name
        c.setFos_caseprogress_name("Progress Name");
        assertEquals("Progress Name", c.getFos_caseprogress_name());
    }
}
