package com.ombudsman.service.respondent.model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

class RespondentsTest {

    @Test
    void testGettersAndSetters() {
        Respondents resp = new Respondents();

        resp.setYomifullname("John Doe");
        assertEquals("John Doe", resp.getYomifullname());

        resp.setFos_capacity("CapacityCode");
        assertEquals("CapacityCode", resp.getFos_capacity());

        resp.setFos_parentorganisationcapacity("ParentOrgCapacity");
        assertEquals("ParentOrgCapacity", resp.getFos_parentorganisationcapacity());

        resp.set_parentcustomerid_value("ParentCustVal");
        assertEquals("ParentCustVal", resp.get_parentcustomerid_value());

        resp.setBirthdate("2000-01-01");
        assertEquals("2000-01-01", resp.getBirthdate());

        resp.set_accountid_value("ACC-123");
        assertEquals("ACC-123", resp.get_accountid_value());

        resp.set_parent_contactid_value("ContactVal");
        assertEquals("ContactVal", resp.get_parent_contactid_value());

        resp.setFos_fcaid("FCA-999");
        assertEquals("FCA-999", resp.getFos_fcaid());

        resp.setEmailaddress1("test@example.com");
        assertEquals("test@example.com", resp.getEmailaddress1());

        resp.setStatus("Active");
        assertEquals("Active", resp.getStatus());

        resp.setJobtitle("Manager");
        assertEquals("Manager", resp.getJobtitle());

        resp.setSuffix("Jr.");
        assertEquals("Jr.", resp.getSuffix());

        resp.setFirstname("John");
        assertEquals("John", resp.getFirstname());

        resp.setMiddlename("M.");
        assertEquals("M.", resp.getMiddlename());

        resp.setLastname("Doe");
        assertEquals("Doe", resp.getLastname());

        resp.setFos_role("FOS Role");
        assertEquals("FOS Role", resp.getFos_role());
    }
}
