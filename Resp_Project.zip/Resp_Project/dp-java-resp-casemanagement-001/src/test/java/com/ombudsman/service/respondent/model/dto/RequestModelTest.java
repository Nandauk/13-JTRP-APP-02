package com.ombudsman.service.respondent.model.dto;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import java.time.OffsetDateTime;

import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(SpringExtension.class)
public class RequestModelTest {
	@InjectMocks
    private RequestModel requestModel;

    @BeforeEach
    public void setUp() {
        requestModel = new RequestModel();
    }

    @Test
    public void testGetterAndSetter() {
        // Set values
        String requestId = "REQ123";
        String userOid = "USER123";
        String requestingActivityName = "Activity Name";
        Integer requestStatusId = 1;
        String requestStatusDescription = "Request Status Description";
        String requestProcessingDetails = "Processing Details";
        OffsetDateTime requestStartTime = OffsetDateTime.now().minusDays(1);
        OffsetDateTime requestFinishTime = OffsetDateTime.now();
        Integer requestProcessingCounter = 5;
        OffsetDateTime createdOn = OffsetDateTime.now().minusMonths(1);
        String createdBy = "Admin";
        String modifiedOn = OffsetDateTime.now().toString();
        String modifiedBy = "User123";

        requestModel.setRequestId(requestId);
        requestModel.setUserOid(userOid);
        requestModel.setRequestingActivityName(requestingActivityName);
        requestModel.setRequestStatusId(requestStatusId);
        requestModel.setRequestStatusDescription(requestStatusDescription);
        requestModel.setRequestProcessingDetails(requestProcessingDetails);
        requestModel.setRequestStartTime(requestStartTime);
        requestModel.setRequestFinishTime(requestFinishTime);
        requestModel.setRequestProcessingCounter(requestProcessingCounter);
        requestModel.setCreatedOn(createdOn);
        requestModel.setCreatedBy(createdBy);
        requestModel.setModifiedOn(modifiedOn);
        requestModel.setModifiedBy(modifiedBy);

        // Assert values
        assertEquals(requestId, requestModel.getRequestId());
        assertEquals(userOid, requestModel.getUserOid());
        assertEquals(requestingActivityName, requestModel.getRequestingActivityName());
        assertEquals(requestStatusId, requestModel.getRequestStatusId());
        assertEquals(requestStatusDescription, requestModel.getRequestStatusDescription());
        assertEquals(requestProcessingDetails, requestModel.getRequestProcessingDetails());
        assertEquals(requestStartTime, requestModel.getRequestStartTime());
        assertEquals(requestFinishTime, requestModel.getRequestFinishTime());
        assertEquals(requestProcessingCounter, requestModel.getRequestProcessingCounter());
        assertEquals(createdOn, requestModel.getCreatedOn());
        assertEquals(createdBy, requestModel.getCreatedBy());
        assertEquals(modifiedOn, requestModel.getModifiedOn());
        assertEquals(modifiedBy, requestModel.getModifiedBy());
    }
}
