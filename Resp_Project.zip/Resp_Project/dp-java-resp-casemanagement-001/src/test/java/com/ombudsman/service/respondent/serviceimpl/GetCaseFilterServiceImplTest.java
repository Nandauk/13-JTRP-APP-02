package com.ombudsman.service.respondent.serviceimpl;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.security.auth.login.AccountNotFoundException;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.ombudsman.service.respondent.common.UserBean;
import com.ombudsman.service.respondent.exception.CaseFilterNotFoundException;
import com.ombudsman.service.respondent.exception.OrganizationNotFoundException;
import com.ombudsman.service.respondent.exception.SQLDataAccessException;
import com.ombudsman.service.respondent.model.dto.CaseFilterDetailsDto;
import com.ombudsman.service.respondent.model.response.GetCaseFilterDataRes;
import com.ombudsman.service.respondent.repository.dao.ICaseListDao;

@ExtendWith(SpringExtension.class)

class GetCaseFilterServiceImplTest {

	@InjectMocks
	private CaseFilterServiceImpl getCaseFilterServiceImpl;

	
	@Mock
	private UserBean userBean;

	@Mock
	private ICaseListDao mMockCaseFilterDao;

	@Mock
	List<CaseFilterDetailsDto> caseFilterDetailsDtos;

	private static List<String> groupIds = new ArrayList<>();

	@BeforeEach
	void setUp() {
		groupIds.add("groupId1");
		groupIds.add("groupId2");
		when(userBean.getGroups()).thenReturn(groupIds);

	}

	@Test
	@DisplayName("getCaseFilter_Success")
	void testGetCaseFilterDataForOrganisation_Success()
			throws SQLDataAccessException, AccountNotFoundException, OrganizationNotFoundException, CaseFilterNotFoundException {
		// Arrange
		when(userBean.getGroups()).thenReturn(groupIds);
		caseFilterDetailsDtos = Collections.singletonList(new CaseFilterDetailsDto("accountId", "filterValue", "filterType"));
		when(mMockCaseFilterDao.getCaseFilter("oid")).thenReturn(caseFilterDetailsDtos);
		// Act
		GetCaseFilterDataRes result = getCaseFilterServiceImpl.getCaseFilterDataForOrganisation();
		// Assert
		assertEquals("Success", result.getStatus());
		//assertEquals(1, result.getFilters().size());
		//assertEquals(caseFilterDetailsDtos.size(), result.getFilters().get("accountid").size());
		//assertEquals("filterValue", result.getFilters().get("accountid").get(0).getValue());
	}

	@Test
	@DisplayName("getCaseFilter_CaseFilterNotFoundException")
	void testGetCaseFilterDataForOrganisation_CaseFilterNotFoundException()
			throws SQLDataAccessException, AccountNotFoundException, OrganizationNotFoundException, CaseFilterNotFoundException {
		// Arrange
		Mockito.when(userBean.getGroups()).thenReturn(groupIds);
		Mockito.when(mMockCaseFilterDao.getCaseFilter("oid")).thenReturn(null);
		// Act
		GetCaseFilterDataRes result = getCaseFilterServiceImpl.getCaseFilterDataForOrganisation();
		// Assert
		//assertEquals("Failure", result.getStatus());
		//assertEquals("Case Filter not found", result.getMessage());
	}
}
