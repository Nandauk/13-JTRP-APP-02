package com.ombudsman.service.respondent.serviceimpl.helper;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import static org.mockito.Mockito.when;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import com.ombudsman.service.respondent.exception.SQLDataAccessException;
import com.ombudsman.service.respondent.model.CaseFilterData;
import com.ombudsman.service.respondent.model.Filters;
import com.ombudsman.service.respondent.model.request.GetCasesByRespondentReq;
import com.ombudsman.service.respondent.service.repository.CaseListJdbcRepository;
import static com.ombudsman.service.respondent.common.Constants.PAGE_SIZE;
import static com.ombudsman.service.respondent.common.Constants.PAGE_COUNT;
import static com.ombudsman.service.respondent.common.Constants.TRADE_NAME;

@ExtendWith(SpringExtension.class)
public class CaseServiceHelperTest {
	
	@Mock
	CaseListJdbcRepository caseListJdbcRepositoryMock;
	@Mock
	GetCasesByRespondentReq mockGetCasesByRespondentReq;
	@Mock
	Filters mockfilters;
	
	@InjectMocks
	CaseServiceHelper mMockCaseServiceHelper;
	
	@Test
	@DisplayName("GetAccountIds")
	void testGetAccountIds()  throws SQLDataAccessException {
		//prepare mock data
		Map<String, Object> accountIdsMap = new HashMap<>();
		String oid = "123";
		List<Object> obj = new ArrayList<>();
		
		Map<String,String> dd1 = new HashMap<>();
		dd1.put("accountid", "account1");
		Map<String,String> dd2 = new HashMap<>();
		dd2.put("accountid", "account2");
		
		obj.add(dd1);
		obj.add(dd2);
		
		accountIdsMap.put("#result-set-1", obj);
		
		//Mock CaseListJdbcRepository behavior
		when(caseListJdbcRepositoryMock.getOrganisationAccountIds(oid)).thenReturn(accountIdsMap);
		
		//Call the method under test
		List<String> actualAccountIds = mMockCaseServiceHelper.getAccountIds(oid);
		
		// Expected result
		List<String> expectedAccountIds = new ArrayList<>();
		expectedAccountIds.add("account1");
		expectedAccountIds.add("account2");
		
		assertEquals(expectedAccountIds,actualAccountIds);
		
		}
	@Test
	void testgetRequestData() {
		int pagesize = 10;
		int pagecount = 2;
		String fromdate = "04/06/1980";
		String todate = "31/12/2024";
		String tradingname ="trade1";
		List<CaseFilterData> caseData = new ArrayList<>();
		caseData.add(new CaseFilterData("id1","data1"));
		Map<String, Object> data = new HashMap<>();
		data.put(PAGE_SIZE, pagesize);
		data.put(PAGE_COUNT, pagecount);
		data.put(TRADE_NAME, tradingname);
		when(mockGetCasesByRespondentReq.getFilters()).thenReturn(mockfilters);
		when(mockfilters.getPagesize()).thenReturn(pagesize);
		when(mockfilters.getPage()).thenReturn(pagecount);
		Map<String,Object> actualData = mMockCaseServiceHelper.getRequestData(mockGetCasesByRespondentReq);
		assertNotNull(actualData);
		assertNotEquals(data,actualData);
		
	}
	
}


