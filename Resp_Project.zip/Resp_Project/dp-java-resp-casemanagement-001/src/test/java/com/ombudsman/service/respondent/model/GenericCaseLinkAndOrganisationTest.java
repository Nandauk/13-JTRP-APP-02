package com.ombudsman.service.respondent.model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

class GenericCaseLinkAndOrganisationTest {

    @Test
    void testGettersAndSetters() {
        GenericCaseLinkAndOrganisation obj = new GenericCaseLinkAndOrganisation();

        obj.setFos_numberofemployees("100");
        assertEquals("100", obj.getFos_numberofemployees());

        obj.setFos_numberofpartners("5");
        assertEquals("5", obj.getFos_numberofpartners());

        obj.setFos_annualturnover("1M");
        assertEquals("1M", obj.getFos_annualturnover());

        obj.setFos_balancesheet("BalanceSheetVal");
        assertEquals("BalanceSheetVal", obj.getFos_balancesheet());

        obj.setFos_islinkedorpartnered("Yes");
        assertEquals("Yes", obj.getFos_islinkedorpartnered());

        obj.setFos_annualincome("500K");
        assertEquals("500K", obj.getFos_annualincome());

        obj.setFos_annualturnover_txt("1 Million");
        assertEquals("1 Million", obj.getFos_annualturnover_txt());

        obj.setFos_netassets("200K");
        assertEquals("200K", obj.getFos_netassets());

        obj.setFos_balancesheet_txt("BalanceSheet Text");
        assertEquals("BalanceSheet Text", obj.getFos_balancesheet_txt());

        obj.setFos_businesstypecode("BusinessType");
        assertEquals("BusinessType", obj.getFos_businesstypecode());

        obj.setFos_businesstypecode_txt("Business Type Text");
        assertEquals("Business Type Text", obj.getFos_businesstypecode_txt());

        obj.set_fos_preferredemailaddress_value("EmailVal");
        assertEquals("EmailVal", obj.get_fos_preferredemailaddress_value());

        obj.set_fos_preferredemailaddress_value_txt("Email Display");
        assertEquals("Email Display", obj.get_fos_preferredemailaddress_value_txt());
    }
}
