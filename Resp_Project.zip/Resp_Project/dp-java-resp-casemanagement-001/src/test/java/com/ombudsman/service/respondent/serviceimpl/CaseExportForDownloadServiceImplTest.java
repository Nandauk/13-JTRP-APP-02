package com.ombudsman.service.respondent.serviceimpl;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import javax.security.auth.login.AccountNotFoundException;

import org.json.JSONException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.context.MessageSource;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.ombudsman.service.respondent.common.UserBean;
import com.ombudsman.service.respondent.common.WebClientData;
import com.ombudsman.service.respondent.exception.AzureServiceException;
import com.ombudsman.service.respondent.exception.RecordCreationException;
import com.ombudsman.service.respondent.exception.SQLDataAccessException;
import com.ombudsman.service.respondent.exception.UnAuthorisedException;
import com.ombudsman.service.respondent.model.request.CaseExportDownloadReq;
import com.ombudsman.service.respondent.model.response.CaseExportDownloadResponse;


@ExtendWith(SpringExtension.class)
class CaseExportForDownloadServiceImplTest {

	private static final String CASE_REFERENCE_IS_AN_INVALID_FIELD = "Case Reference is an invalid field";

	private static final String USER_IS_NOT_TAGGED_WITH_ANY_ORGANISATION = "User is not tagged with any organisation.";

	@InjectMocks
	private CaseExportForDownloadServiceImpl caseExportForDownloadServiceImpl;

	@Mock
	private CaseExportDownloadResponse mMockCaseExportDownloadResponse;

	@Mock
	private MessageSource messageSource;

	@Mock
	WebClientData webClientData;

	@Mock
	CaseExportDownloadReq mMockCaseExportDownloadReq;

	@Mock
	UserBean userbean;

	private static List<String> groupIds = new ArrayList<>();
	private static final String COMMA = ",";

	@BeforeEach
	void setUp() {
		groupIds.add("groupId1");
		groupIds.add("groupId2");
		when(mMockCaseExportDownloadReq.getRequestingActivityName()).thenReturn("downloadexport");
		when(mMockCaseExportDownloadReq.getUserOid()).thenReturn("downloadexportoid");
		when(messageSource.getMessage("api.error.RecordCreationFailed", null, Locale.ENGLISH)).thenReturn("Notification Creation Failed. Please Try Again.");
		when(mMockCaseExportDownloadResponse.getListOfNotification()).thenReturn(groupIds);

	}

	@DisplayName("caseexportForDownlaodSuccessfully")
	@Test
	void caseexportForDownlaodSuccessfully() throws AzureServiceException, JSONException, IOException,
			SQLDataAccessException, AccountNotFoundException, UnAuthorisedException {

		when(webClientData.caseExportAvailableForDownload(mMockCaseExportDownloadReq))
				.thenReturn(mMockCaseExportDownloadResponse);

		try {
			caseExportForDownloadServiceImpl.getCaseExportAvailableForDownload();
		
		} catch (Exception e) {
			assertEquals("Record Creation Failed. Please Try Again.",e.getMessage());
		}

	}
}
