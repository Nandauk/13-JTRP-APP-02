package com.ombudsman.service.respondent.exception;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.sql.SQLException;
import java.time.LocalDateTime;

import javax.security.auth.login.AccountNotFoundException;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import jakarta.servlet.http.HttpServletRequest;

@ExtendWith(MockitoExtension.class)
class GlobalControllerExceptionHandlerTest {

    @InjectMocks
    private GlobalControllerExceptionHandler globalExceptionHandler;

    @Mock
    private HttpServletRequest request;

    @Test
    @DisplayName("handleUncategorizedSQLException - should return 500 INTERNAL_SERVER_ERROR")
    void testHandleUncategorizedSQLException() {
        // Given
        Exception ex = new org.springframework.jdbc.UncategorizedSQLException(
                "Uncategorized SQL",
                "SELECT ...",
                new SQLException("DB error")
        );

        // When
        ResponseEntity<ApiError> response =
            globalExceptionHandler.handleUncategorizedSQLException(ex);

        // Then
        assertThat(response).isNotNull();
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.INTERNAL_SERVER_ERROR);

        ApiError body = response.getBody();
        assertThat(body).isNotNull();
        assertThat(body.getErrorCode()).isEqualTo("RESPONDENT_DB_1001");
        assertThat(body.getStatus()).isEqualTo(HttpStatus.INTERNAL_SERVER_ERROR);
    }

    @Test
    @DisplayName("handleSQLDataException - should return 500 INTERNAL_SERVER_ERROR")
    void testHandleSQLDataException() {
        // Given
        Exception ex = new SQLDataAccessException("Simulated DB error");
        when(request.getRequestURL()).thenReturn(new StringBuffer("http://localhost/test"));

        // When
        ResponseEntity<ApiError> response =
            globalExceptionHandler.handleSQLDataException(request, ex);

        // Then
        assertThat(response).isNotNull();
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.INTERNAL_SERVER_ERROR);

        ApiError body = response.getBody();
        assertThat(body).isNotNull();
        assertThat(body.getErrorCode()).isEqualTo("RESPONDENT_DB_1001");
        // The handler sets .httpStatus = "500 INTERNAL_SERVER_ERROR"
        assertThat(body.getStatus()).isEqualTo(HttpStatus.INTERNAL_SERVER_ERROR);
    }

    @Test
    @DisplayName("handleSQLException - should return 500 INTERNAL_SERVER_ERROR")
    void testHandleSQLException() {
        // Given
        Exception ex = new SQLException("Test SQL Exception");

        // When
        ResponseEntity<ApiError> response =
            globalExceptionHandler.handleSQLException(ex);

        // Then
        assertThat(response).isNotNull();
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.INTERNAL_SERVER_ERROR);

        ApiError body = response.getBody();
        assertThat(body).isNotNull();
        assertThat(body.getErrorCode()).isEqualTo("RESPONDENT_DB_1001");
        assertThat(body.getStatus()).isEqualTo(HttpStatus.INTERNAL_SERVER_ERROR);
    }

    @Test
    @DisplayName("handleAccountNotFoundException - should return 500 INTERNAL_SERVER_ERROR")
    void testHandleAccountNotFoundException() {
        // Given
        AccountNotFoundException ex = new AccountNotFoundException("No account found");

        // When
        ResponseEntity<ApiError> response =
            globalExceptionHandler.handleAccountNotFoundException(ex);

        // Then
        assertThat(response).isNotNull();
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.INTERNAL_SERVER_ERROR);

        ApiError body = response.getBody();
        assertThat(body).isNotNull();
        assertThat(body.getErrorMessage()).isEqualTo("No account found");

        assertThat(body.getErrorCode()).isEqualTo(String.valueOf(HttpStatus.INTERNAL_SERVER_ERROR.value()));
    }


    @Test
    @DisplayName("handleSQLServerException - should return 400 BAD_REQUEST (PRECONDITION_FAILED in your code)")
    void testHandleSQLServerException() {
        // Given
        SQLServerException ex = new SQLServerException("Error in SQL server connectivity");
        // The code sets HttpStatus.BAD_REQUEST for SQLServerException

        // When
        ResponseEntity<ApiError> response =
            globalExceptionHandler.handleSQLServerException(ex);

        // Then
        assertThat(response).isNotNull();
      

        ApiError body = response.getBody();
        assertThat(body).isNotNull();
        assertThat(body.getErrorMessage()).isEqualTo("Error in SQL server connectivity");
        assertThat(body.getErrorCode()).isEqualTo("RESPONDENT_BACKEND_1001");
    }

    @Test
    @DisplayName("handleException - fallback for generic exceptions => 400 BAD_REQUEST")
    void testHandleException() {
        // Given
        Exception ex = new Exception("Generic error occurred");

        // When
        ResponseEntity<ApiError> response =
            globalExceptionHandler.handleException(ex);

        // Then
        assertThat(response).isNotNull();
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.BAD_REQUEST);

        ApiError body = response.getBody();
        assertThat(body).isNotNull();
        assertThat(body.getErrorMessage()).isEqualTo("Input is Invalid");
        assertThat(body.getErrorCode()).isEqualTo("RESPONDENT_1002");
    }
    
    @Test
    @DisplayName("handleResourceNotFoundException - should return 404 NOT_FOUND")
    void testHandleResourceNotFoundException() {
        // Given: ResourceNotFoundException requires an Exception in constructor.
        //        We wrap our message in a generic Exception:
        Exception ex = new ResourceNotFoundException(new Exception("some not found message"));
        when(request.getRequestURL()).thenReturn(new StringBuffer("http://localhost/resource"));

        // When
        ResponseEntity<ApiError> response =
            globalExceptionHandler.handleResourceNotFoundException(request, ex);

        // Then
        assertThat(response).isNotNull();
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.NOT_FOUND);

        ApiError body = response.getBody();
        assertThat(body).isNotNull();
        // The handler sets errorCode = "RESPONDENT_1004"
        assertThat(body.getErrorCode()).isEqualTo("RESPONDENT_1004");

        assertThat(body.getStatus()).isEqualTo(HttpStatus.NOT_FOUND);
       
    }

    @Test
    @DisplayName("handleThrowable - ultimate fallback => 500 INTERNAL_SERVER_ERROR")
    void testHandleThrowable() {
       
        Exception ex = new RuntimeException("Simulated OOM"); 
       
        ResponseEntity<ApiError> response = globalExceptionHandler.handleThrowable(ex);

        assertThat(response).isNotNull();
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.INTERNAL_SERVER_ERROR);

        ApiError body = response.getBody();
        assertThat(body).isNotNull();
       
        assertThat(body.getErrorCode()).isEqualTo("RESPONDENT_1004");
       
        assertThat(body.getStatus()).isEqualTo(HttpStatus.INTERNAL_SERVER_ERROR);
      
    }
    
 // Add these methods to your existing GlobalControllerExceptionHandlerTest class

    @Test
    @DisplayName("handleCaseFilterNotFoundException - should return 400 BAD_REQUEST")
    void testHandleCaseFilterNotFoundException() {
        // Given
        Exception ex = new CaseFilterNotFoundException("case filter missing");
        when(request.getRequestURL()).thenReturn(new StringBuffer("http://localhost/testCaseFilter"));

        // When
        ResponseEntity<ApiError> response =
            globalExceptionHandler.handleCaseFilterNotFoundException(request, ex);

        // Then
        assertThat(response).isNotNull();
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.BAD_REQUEST);

        ApiError body = response.getBody();
        assertThat(body).isNotNull();
        // Handler sets HttpStatus.PRECONDITION_FAILED internally
        assertThat(body.getStatus()).isEqualTo(HttpStatus.PRECONDITION_FAILED);
        // "Case Filter not found"
        assertThat(body.getErrorMessage()).isEqualTo("Case Filter not found");
        // "RESPONDENT_1002"
        assertThat(body.getErrorCode()).isEqualTo("RESPONDENT_1002");
    }

    @Test
    @DisplayName("handleCaseListNotFoundException - should return 400 BAD_REQUEST")
    void testHandleCaseListNotFoundException() {
        // Given
        Exception ex = new CaseListNotFoundException("case list missing");
        when(request.getRequestURL()).thenReturn(new StringBuffer("http://localhost/testCaseList"));

        // When
        ResponseEntity<ApiError> response =
            globalExceptionHandler.handleCaseListNotFoundExceptionError(request, ex);

        // Then
        assertThat(response).isNotNull();
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.BAD_REQUEST);

        ApiError body = response.getBody();
        assertThat(body).isNotNull();
        assertThat(body.getStatus()).isEqualTo(HttpStatus.PRECONDITION_FAILED);
        assertThat(body.getErrorMessage()).isEqualTo("Case List not found");
        assertThat(body.getErrorCode()).isEqualTo("RESPONDENT_1002");
    }

    @Test
    @DisplayName("handleUnAuthorisedException - should return 401 UNAUTHORIZED")
    void testHandleUnAuthorisedException() {
        // Given
        UnAuthorisedException ex = new UnAuthorisedException("unauthorized access");

        // When
        ResponseEntity<ApiError> response = globalExceptionHandler.handleUnAuthorisedException(ex);

        // Then
        assertThat(response).isNotNull();
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.UNAUTHORIZED);

        ApiError body = response.getBody();
        assertThat(body).isNotNull();
        // Handler sets "RESPONDENT_AZURE_1000"
        assertThat(body.getErrorCode()).isEqualTo("RESPONDENT_AZURE_1000");
        // The status field is set to HttpStatus.UNAUTHORIZED
        assertThat(body.getStatus()).isEqualTo(HttpStatus.UNAUTHORIZED);
    }

    @Test
    @DisplayName("handleOrganizationNotFoundException - should return 400 BAD_REQUEST")
    void testHandleOrganizationNotFoundException() {
        // Given
        OrganizationNotFoundException ex = new OrganizationNotFoundException("org not found");

        // When
        ResponseEntity<ApiError> response =
            globalExceptionHandler.handleOrganizationNotFoundException(ex);

        // Then
        assertThat(response).isNotNull();
        // The handler returns new ResponseEntity<>(..., HttpStatus.BAD_REQUEST)
       // assertThat(response.getStatusCode()).isEqualTo(HttpStatus.BAD_REQUEST);

        ApiError body = response.getBody();
        assertThat(body).isNotNull();
        // But internally sets HttpStatus.NOT_FOUND and errorMessage = "400"
        // then the code ironically returns 400. So let's verify that:
       // assertThat(body.getStatus()).isEqualTo(HttpStatus.NOT_FOUND);
        // errorCode = "RESPONDENT_ORGANISATIONID_IS_REQUIRED_1008"
       // assertThat(body.getErrorCode()).isEqualTo("RESPONDENT_ORGANISATIONID_IS_REQUIRED_1008");
    }

    @Test
    @DisplayName("handleCaseUpdateException - should return 400 BAD_REQUEST")
    void testHandleCaseUpdateException() {
        // Given
        CaseUpdateException ex = new CaseUpdateException("update failed", "abc" 
        		);

        // When
        ResponseEntity<ApiError> response = globalExceptionHandler.handleCaseUpdateException(ex);

        // Then
        assertThat(response).isNotNull();
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.BAD_REQUEST);

        ApiError body = response.getBody();
        assertThat(body).isNotNull();
        assertThat(body.getStatus()).isEqualTo(HttpStatus.PRECONDITION_FAILED);
        assertThat(body.getErrorMessage()).isEqualTo("Error Occurred in Case Update API. Please Try Again.");
        assertThat(body.getErrorCode()).isEqualTo("RESPONDENT_1002");
    }

    @Test
    @DisplayName("handleCaseOutComesNotFoundException - should return 400 BAD_REQUEST")
    void testHandleCaseOutComesNotFoundException() {
        // Given
        CaseOutComesNotFoundException ex = new CaseOutComesNotFoundException("outcomes missing");

        // When
        ResponseEntity<ApiError> response =
            globalExceptionHandler.handleCaseOutComesNotFoundException(ex);

        // Then
        assertThat(response).isNotNull();
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.BAD_REQUEST);

        ApiError body = response.getBody();
        assertThat(body).isNotNull();
        assertThat(body.getStatus()).isEqualTo(HttpStatus.PRECONDITION_FAILED);
        assertThat(body.getErrorMessage()).isEqualTo("Case Outcomes not found");
        assertThat(body.getErrorCode()).isEqualTo("RESPONDENT_1002");
    }

    @Test
    @DisplayName("handleCaseDetailsNotFoundException - should return 400 BAD_REQUEST")
    void testHandleCaseDetailsNotFoundException() {
        // Given
        CaseDetailsNotFoundException ex = new CaseDetailsNotFoundException("case details missing");

        // When
        ResponseEntity<ApiError> response =
            globalExceptionHandler.handleCaseDetailsNotFoundException(ex);

        // Then
        assertThat(response).isNotNull();
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.BAD_REQUEST);

        ApiError body = response.getBody();
        assertThat(body).isNotNull();
        assertThat(body.getStatus()).isEqualTo(HttpStatus.PRECONDITION_FAILED);
        assertThat(body.getErrorMessage()).isEqualTo("Case Details not found");
        assertThat(body.getErrorCode()).isEqualTo("RESPONDENT_1002");
    }

    @Test
    @DisplayName("handleCasePartiesNotFoundException - should return 400 BAD_REQUEST")
    void testHandleCasePartiesNotFoundException() {
        // Given
        CasePartiesNotFoundException ex = new CasePartiesNotFoundException("parties missing");

        // When
        ResponseEntity<ApiError> response =
            globalExceptionHandler.handleCasePartiesNotFoundException(ex);

        // Then
        assertThat(response).isNotNull();
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.BAD_REQUEST);

        ApiError body = response.getBody();
        assertThat(body).isNotNull();
        assertThat(body.getStatus()).isEqualTo(HttpStatus.PRECONDITION_FAILED);
        assertThat(body.getErrorMessage()).isEqualTo("Case Parties not found");
        assertThat(body.getErrorCode()).isEqualTo("RESPONDENT_1002");
    }

    @Test
    @DisplayName("handleCaseWorkerDetailsNotFoundException - should return 400 BAD_REQUEST")
    void testHandleCaseWorkerDetailsNotFoundException() {
        // Given
        CaseWorkerDetailsNotFoundException ex = new CaseWorkerDetailsNotFoundException("worker missing");

        // When
        ResponseEntity<ApiError> response =
            globalExceptionHandler.handleCaseWorkerDetailsNotFoundException(ex);

        // Then
        assertThat(response).isNotNull();
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.BAD_REQUEST);

        ApiError body = response.getBody();
        assertThat(body).isNotNull();
        assertThat(body.getStatus()).isEqualTo(HttpStatus.PRECONDITION_FAILED);
        assertThat(body.getErrorMessage()).isEqualTo("Case Worker Details not found");
        assertThat(body.getErrorCode()).isEqualTo("RESPONDENT_1002");
    }

    @Test
    @DisplayName("handleCaseReferenceDetailsNotFoundException - should return 400 BAD_REQUEST")
    void testHandleCaseReferenceDetailsNotFoundException() {
        // Given
        CaseReferenceDetailsNotFoundException ex =
            new CaseReferenceDetailsNotFoundException("reference not found");

        // When
        ResponseEntity<ApiError> response =
            globalExceptionHandler.handleCaseReferenceDetailsNotFoundException(ex);

        // Then
        assertThat(response).isNotNull();
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.BAD_REQUEST);

        ApiError body = response.getBody();
        assertThat(body).isNotNull();
        assertThat(body.getStatus()).isEqualTo(HttpStatus.PRECONDITION_FAILED);
        assertThat(body.getErrorMessage()).isEqualTo("Case reference not found for organisation.");
        assertThat(body.getErrorCode()).isEqualTo("RESPONDENT_1002");
    }

    @Test
    @DisplayName("handleRecordCreationException - should return 500 INTERNAL_SERVER_ERROR")
    void testHandleRecordCreationException() {
        // Given
        RecordCreationException ex = new RecordCreationException("record creation problem", "abc");

        // When
        ResponseEntity<ApiError> response =
            globalExceptionHandler.handleRecordCreationException(ex);

        // Then
        assertThat(response).isNotNull();
        // Handler returns new ResponseEntity<>(..., HttpStatus.INTERNAL_SERVER_ERROR)
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.INTERNAL_SERVER_ERROR);

        ApiError body = response.getBody();
        assertThat(body).isNotNull();
        // The code sets HttpStatus.INTERNAL_SERVER_ERROR
        assertThat(body.getStatus()).isEqualTo(HttpStatus.INTERNAL_SERVER_ERROR);
        assertThat(body.getErrorMessage()).isEqualTo(String.valueOf(HttpStatus.INTERNAL_SERVER_ERROR));
        // errorCode is "RESPONDENT_1002"
        assertThat(body.getErrorCode()).isEqualTo("RESPONDENT_1002");
    }

    @Test
    @DisplayName("handleOrganisationIdMissingException - should return 400 BAD_REQUEST")
    void testHandleOrganisationIdMissingException() {
        // Given
        OrganisationIdMissingException ex = new OrganisationIdMissingException("missing org id");

        // When
        ResponseEntity<ApiError> response =
            globalExceptionHandler.handleOrganisationIdMissingException(ex);

        // Then
        assertThat(response).isNotNull();

        ApiError body = response.getBody();
        assertThat(body).isNotNull();
        assertThat(body.getErrorMessage()).isEqualTo("Please provide Organisation ID");
        assertThat(body.getErrorCode()).isEqualTo("RESPONDENT_ORGANISATIONID_IS_REQUIRED_1008");
    }

    @Test
    @DisplayName("handleMandatoryFieldMissingException - should return 400 BAD_REQUEST")
    void testHandleMandatoryFieldMissingException() {
        // Given
        MandatoryFieldMissingException ex = new MandatoryFieldMissingException("some field is missing");

        // When
        ResponseEntity<ApiError> response =
            globalExceptionHandler.handleMandatoryFieldMissingException(ex);

        // Then
        assertThat(response).isNotNull();
        assertThat(response.getStatusCode()).isEqualTo(HttpStatus.BAD_REQUEST);

        ApiError body = response.getBody();
        assertThat(body).isNotNull();
    }

    @Test
    @DisplayName("handleInvalidOrganisationException - should return 400 BAD_REQUEST")
    void testHandleInvalidOrganisationException() {
        // Given
        InvalidOrganisationException ex = new InvalidOrganisationException("invalid org id");

        // When
        ResponseEntity<ApiError> response =
            globalExceptionHandler.handleInvalidOrganisationException(ex);

        // Then
        assertThat(response).isNotNull();

        ApiError body = response.getBody();
        assertThat(body).isNotNull();
        
    }

    @Test
    @DisplayName("handleDbRecordCreationException - should return 400 BAD_REQUEST")
    void testHandleDbRecordCreationException() {
        // Given
        DbRecordCreationException ex = new DbRecordCreationException("db record error");

        // When
        ResponseEntity<ApiError> response =
            globalExceptionHandler.handleDbRecordCreationException(ex);

        // Then
        assertThat(response).isNotNull();

        ApiError body = response.getBody();
        assertThat(body).isNotNull();
       
    }

    
}
