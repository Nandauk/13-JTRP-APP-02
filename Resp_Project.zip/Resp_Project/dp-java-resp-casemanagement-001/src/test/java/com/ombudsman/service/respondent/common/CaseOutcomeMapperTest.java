package com.ombudsman.service.respondent.common;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

import org.junit.jupiter.api.Test;
import org.mapstruct.factory.Mappers;
import com.ombudsman.service.respondent.common.CaseOutcomeMapper;
import com.ombudsman.service.respondent.model.CaseOutcome;
import com.ombudsman.service.respondent.model.dto.CaseOutcomeDto;


public class CaseOutcomeMapperTest   {

    private CaseOutcomeMapper mapper = Mappers.getMapper(CaseOutcomeMapper.class);

//    @Test
//    void testMeritOpinionMapping() {
//        CaseOutcomeDto outcomeDto = new CaseOutcomeDto();
//        outcomeDto.setFos_meritsjurisdictiondismissal(CaseOutcomeMapper.MERIT_OPINION1);
//        outcomeDto.setFos_meritopinion(CaseOutcomeMapper.MERIT_OPINION1);
//        outcomeDto.setStatuscode(CaseOutcomeMapper.ACTIVE);
//        
//        mapper.meritOpinionMapping(outcomeDto);
//
//        assertEquals(CaseOutcomeMapper.MERIT_NON_UPHOLD, outcomeDto.getFos_meritopinionname());
//        assertEquals("", outcomeDto.getFos_changeinoutcomename());
//    }
//
//    @Test
//    void testMeritOpinionMapping_withSettlementOffer() {
//        CaseOutcomeDto outcomeDto = new CaseOutcomeDto();
//        outcomeDto.setFos_type(CaseOutcomeMapper.SETTLEMENT_OFFER);
//        outcomeDto.setFos_withopinion(CaseOutcomeMapper.MERIT_OPINION1);
//        
//        mapper.meritOpinionMapping(outcomeDto);
//
//        assertEquals(CaseOutcomeMapper.SETTLEMENT_UPHOLD, outcomeDto.getFos_jurisdictioninoutname());
//    }
//
//    @Test
//    void testCaseOutcomeMapping() {
//        CaseOutcomeDto outcomeDto = new CaseOutcomeDto();
//        outcomeDto.setFos_case("caseId");
//        outcomeDto.setFos_offeroroutcomeid("offerOrOutcomeId");
//        outcomeDto.setFos_type("type");
//        outcomeDto.setFos_typename("typeName");
//        // Add other fields similarly
//
//        CaseOutcome caseOutcome = mapper.caseOutcomeLst(outcomeDto);
//
//        assertEquals("caseId", caseOutcome.get_fos_case_value());
//        assertEquals("offerOrOutcomeId", caseOutcome.getFos_offeroroutcomeid());
//        assertEquals("type", caseOutcome.getFos_type());
//        assertEquals("typeName", caseOutcome.getFos_type_txt());
//        // Add other assertions similarly
//    }
}
