package com.ombudsman.service.respondent.serviceimpl;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.json.JSONException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.ombudsman.service.respondent.common.CommonUtil;
import com.ombudsman.service.respondent.common.UserBean;
import com.ombudsman.service.respondent.exception.AzureServiceException;
import com.ombudsman.service.respondent.exception.CaseDetailsNotFoundException;
import com.ombudsman.service.respondent.exception.CasePartiesNotFoundException;
import com.ombudsman.service.respondent.exception.SQLDataAccessException;
import com.ombudsman.service.respondent.model.Case;
import com.ombudsman.service.respondent.model.CaseWorker;
import com.ombudsman.service.respondent.model.dto.CaseWorkerDto;
import com.ombudsman.service.respondent.model.dto.CaseDetailDto;
import com.ombudsman.service.respondent.model.request.CaseDetailsByIdReq;
import com.ombudsman.service.respondent.model.response.CaseDetailsByIdRes;
import com.ombudsman.service.respondent.model.response.CasePartiesByIdRes;
import com.ombudsman.service.respondent.model.response.CaseWorkerDetailsByIdRes;
import com.ombudsman.service.respondent.repository.dao.CaseDetailsDao;
import com.ombudsman.service.respondent.serviceimpl.helper.CaseServiceHelper;

@ExtendWith(SpringExtension.class)
public class CaseDetailsByIdServiceImplTest {

	private static final String INCIDENT_ID_IS_AN_INVALID_FIELD = "IncidentID is  an invalid field";

	private static final String USER_IS_NOT_TAGGED_WITH_ANY_ORGANISATION = "User is not tagged with any organisation.";

	@InjectMocks
	private CaseDetailsByIdServiceImpl caseDetailsByIdServiceImpl;

	@Mock
	private CommonUtil mMockCommonUtil;

	@Mock
	UserBean userbean;

	@Mock
	CaseDetailsByIdRes mMockresponse;

	@Mock
	List<CaseWorker> mMockcaseWorkerDtls;

	@Mock
	CaseWorkerDto mMockCaseWorkerDto;

	@Mock
	Map<String, Object> casePartiesDtls;

	@Mock
	CasePartiesByIdRes mMockCasePartiesByIdRes;

	@Mock
	CaseServiceHelper mMockCaseServiceHelper;

	@Mock
	CaseWorkerDetailsByIdRes mMockCaseWorkerDetailsByIdRes;

	@Mock
	CaseWorker mMockCaseWorker;

	@Mock
	CaseDetailsDao mMockCaseDetailsDao;

	@Mock
	CaseDetailsByIdReq mMockCaseDetailsByIdReq;

	@Mock
	Case mMockCase;

	private static List<String> groupIds = new ArrayList<>();
	private static final String COMMA = ",";
	private static final String CASE_PARTIES_NOT_FOUND = "Case Parties not found";
	private static final String INCIDENT_ID_IS_NOT_A_VALID_FIELD = "IncidentID is not a valid field";
	private static final String FAILED = "Failed";

	@BeforeEach
	void setUp() {
		groupIds.add("groupId1");
		groupIds.add("groupId2");
		when(userbean.getGroups()).thenReturn(groupIds);
		final String accIds = "acctId1,acctId2";
		final List<String> accountIds = Stream.of(accIds.split(COMMA)).collect(Collectors.toList());

		when(mMockCaseDetailsByIdReq.getIncidentid()).thenReturn("PNX-123");
		when(mMockCommonUtil.isValidInput("PNX-123")).thenReturn(true);
		when(mMockCaseServiceHelper.getAccountIds("oid")).thenReturn(accountIds);
		//when(userbean.getGroups()).thenReturn(List.of("groupId1", "groupId2"));

		mMockCase.set_customerid_value("");
		mMockCase.setBusinessname("PNX-123");
		mMockCase.setTicketnumber("PNX-123");
		mMockCase.setIncidentid("PNX-123");
		mMockresponse.setMessage("Success");
		mMockresponse.setCasedetails(mMockCase);
		mMockCaseWorkerDto.setFullname("Fullname");
		mMockCaseWorkerDto.setTitle("title");
		mMockCaseWorkerDto.setTicketnumber("PNX-123");
		mMockCaseDetailsByIdReq.setIncidentid("testing");
		// Initialize valid and invalid requests

	}

	@DisplayName("shouldGetCaseDetailsByIdSuccessfully")
	@Test
	void shouldGetCaseDetailsByIdSuccessfully()
			throws AzureServiceException, IOException, SQLDataAccessException, CaseDetailsNotFoundException {

		final String accIds = "acctId1,acctId2";
		final List<String> accountIds = Stream.of(accIds.split(COMMA)).collect(Collectors.toList());
		final List<CaseDetailDto> caseDetailData = new ArrayList<CaseDetailDto>();
		final CaseDetailDto testCaseDetailDto = new CaseDetailDto();
		testCaseDetailDto.setIncidentid("testIncident123");
		caseDetailData.add(testCaseDetailDto);

		when(mMockCaseDetailsByIdReq.getIncidentid()).thenReturn("test@123");
		when(mMockCommonUtil.isValidInput("Test@1234")).thenReturn(true);
		when(mMockCaseServiceHelper.getAccountIds("oid")).thenReturn(accountIds);
		when(mMockCaseDetailsDao.getCaseDetailsById("test@123", accountIds)).thenReturn(caseDetailData);

		CaseDetailsByIdRes result = caseDetailsByIdServiceImpl.getCaseDetailsById(mMockCaseDetailsByIdReq);
		//		IncidentID is  an invalid field
		assertNotNull(result);
		//assertNotNull(result.getCasedetails().getIncidentid());
	}

	@DisplayName("GetCaseDetailsByIdSuccessfully")
	@Test
	void GetCaseDetailsByIdSuccessfully()
			throws AzureServiceException, IOException, SQLDataAccessException, CaseDetailsNotFoundException {

		final String accIds = "acctId1,acctId2";
		final List<String> accountIds = Stream.of(accIds.split(COMMA)).collect(Collectors.toList());
		final List<CaseDetailDto> caseDetailData = new ArrayList<CaseDetailDto>();
		final CaseDetailDto testCaseDetailDto = new CaseDetailDto();
		testCaseDetailDto.setIncidentid("PNX-123");
		caseDetailData.add(testCaseDetailDto);
		when(mMockCase.getBusinessname()).thenReturn("lloyds");
		when(mMockCase.getTicketnumber()).thenReturn("PNX-123");
		when(mMockCase.getIncidentid()).thenReturn("PNX-123");

		when(mMockCaseServiceHelper.getAccountIds("oid")).thenReturn(accountIds);
		when(mMockCaseDetailsDao.getCaseDetailsById("PNX-123", accountIds)).thenReturn(caseDetailData);

		CaseDetailsByIdRes result = caseDetailsByIdServiceImpl.getCaseDetailsById(mMockCaseDetailsByIdReq);

		assertNotNull(result);

	}

	@DisplayName("GetCaseDetailsData_failed")
	@Test
	void GetCaseDetailsDataFailed()
			throws AzureServiceException, IOException, SQLDataAccessException, CaseDetailsNotFoundException {

		final String accIds = "";
		final List<String> accountIds = Stream.of(accIds.split(COMMA)).collect(Collectors.toList());

		when(mMockresponse.getCasedetails()).thenReturn(null);

		when(mMockCaseServiceHelper.getAccountIds("oid")).thenReturn(accountIds);

		CaseDetailsByIdRes result = caseDetailsByIdServiceImpl.getCaseDetailsById(mMockCaseDetailsByIdReq);

		assertNotNull(result);

	}


	@DisplayName("GetCaseWorkerSPAccountId_Failed")
	@Test
	void GetCaseWorkerSPAccountIdFailed()
			throws AzureServiceException, IOException, SQLDataAccessException, CaseDetailsNotFoundException {

		final String accIds = "acctId1,acctId2";
		final List<String> accountIds = Stream.of(accIds.split(COMMA)).collect(Collectors.toList());
		final List<CaseWorkerDto> caseDetailData = new ArrayList<CaseWorkerDto>();
		CaseWorkerDto testCaseDetailDto = new CaseWorkerDto();
		testCaseDetailDto.setTicketnumber("PNX-123");
		caseDetailData.add(testCaseDetailDto);

		when(mMockCaseServiceHelper.getAccountIds("oid")).thenReturn(null);
		when(mMockCaseDetailsDao.getCaseWorkerDetailsById("PNX-123", accountIds)).thenReturn(caseDetailData);
		CaseWorkerDetailsByIdRes result = caseDetailsByIdServiceImpl.getCaseWorkerDetailsById(mMockCaseDetailsByIdReq);

		assertNotNull(result);

	}

	@DisplayName("GetCaseWorkerMapper_Failed")
	@Test
	void GetCaseWorkerMapperFailed()
			throws AzureServiceException, IOException, SQLDataAccessException, CaseDetailsNotFoundException {

		final String accIds = "acctId1,acctId2";
		final List<String> accountIds = Stream.of(accIds.split(COMMA)).collect(Collectors.toList());
		final List<CaseWorkerDto> caseDetailData = new ArrayList<CaseWorkerDto>();
		CaseWorkerDto testCaseDetailDto = new CaseWorkerDto();
		testCaseDetailDto.setTicketnumber("PNX-123");
		caseDetailData.add(testCaseDetailDto);

		when(mMockCaseServiceHelper.getAccountIds("oid")).thenReturn(null);
		when(mMockCaseDetailsDao.getCaseWorkerDetailsById("PNX-123", accountIds)).thenReturn(caseDetailData);

		CaseWorkerDetailsByIdRes result = caseDetailsByIdServiceImpl.getCaseWorkerDetailsById(mMockCaseDetailsByIdReq);

		assertNotNull(result);

	}

	@DisplayName("GetCasePartiesById_Failed")
	@Test
	void GetCasePartiesByIdFailed()
			throws AzureServiceException, IOException, SQLDataAccessException, CaseDetailsNotFoundException {

		final String accIds = "acctId1,acctId2";
		final List<String> accountIds = Stream.of(accIds.split(COMMA)).collect(Collectors.toList());

		when(mMockCaseServiceHelper.getAccountIds("oid")).thenReturn(accountIds);

		try {
			CasePartiesByIdRes result = caseDetailsByIdServiceImpl.getCasePartiesById(mMockCaseDetailsByIdReq);
			assertNotNull(result);
		} catch (Exception e) {
			// TODO: handle exception
		}


	}

	@DisplayName("GetCasePartiesIncidentId_Failed")
	@Test
	void GetCasePartiesIncidentIdFailed()
			throws AzureServiceException, IOException, SQLDataAccessException, CaseDetailsNotFoundException {
		String RESULT_SET_1 = "#result-set-1";
		final String accIds = "acctId1,acctId2";
		final List<String> accountIds = Stream.of(accIds.split(COMMA)).collect(Collectors.toList());

		when(mMockCaseDetailsDao.getCaseParties("PNX-123", accountIds)).thenReturn(casePartiesDtls);
		when(casePartiesDtls.get(RESULT_SET_1)).thenReturn(RESULT_SET_1);
		when(mMockCaseDetailsByIdReq.getIncidentid()).thenReturn(null);
		try {
			CasePartiesByIdRes result = caseDetailsByIdServiceImpl.getCasePartiesById(mMockCaseDetailsByIdReq);
			assertNotNull(result);
			assertEquals(INCIDENT_ID_IS_AN_INVALID_FIELD, result.getMessage());
		} catch (Exception e) {
			// TODO: handle exception
		}


	}
	@DisplayName("GetCaseDetailsById_NullIncidentId")
	@Test
	void getCaseDetailsById_NullIncidentId()
			throws AzureServiceException, IOException, SQLDataAccessException, CaseDetailsNotFoundException {

		when(mMockCaseDetailsByIdReq.getIncidentid()).thenReturn(null);

		CaseDetailsByIdRes result = caseDetailsByIdServiceImpl.getCaseDetailsById(mMockCaseDetailsByIdReq);

		assertEquals(INCIDENT_ID_IS_AN_INVALID_FIELD, result.getMessage());
		assertNotNull(result);
	}

	@DisplayName("GetCaseDetailsById_EmptyIncidentId")
	@Test
	void getCaseDetailsById_EmptyIncidentId()
			throws AzureServiceException, IOException, SQLDataAccessException, CaseDetailsNotFoundException {

		when(mMockCaseDetailsByIdReq.getIncidentid()).thenReturn("");

		CaseDetailsByIdRes result = caseDetailsByIdServiceImpl.getCaseDetailsById(mMockCaseDetailsByIdReq);

		assertEquals(INCIDENT_ID_IS_AN_INVALID_FIELD, result.getMessage());
		assertNotNull(result);
	}
	@DisplayName("GetCaseDetailsById_InvalidInput")
	@Test
	void getCaseDetailsById_InvalidInput()
			throws AzureServiceException, IOException, SQLDataAccessException, CaseDetailsNotFoundException {

		when(mMockCaseDetailsByIdReq.getIncidentid()).thenReturn("invalidID");
		when(mMockCommonUtil.isValidInput("invalidID")).thenReturn(false);

		CaseDetailsByIdRes result = caseDetailsByIdServiceImpl.getCaseDetailsById(mMockCaseDetailsByIdReq);

		assertEquals(INCIDENT_ID_IS_AN_INVALID_FIELD, result.getMessage());
		assertNotNull(result);
	}

	@Test
	public void testSetCaseDetails() throws Exception {
		// Prepare test data
		List<CaseDetailDto> caseDetails = new ArrayList<>();
		CaseDetailDto caseDetail = new CaseDetailDto();
		caseDetail.setIncidentid("incidentId");
		caseDetail.setTicketnumber("ticketNumber");
		caseDetail.setFos_crn("fosCrn");
		caseDetail.set_customerid_value("customerIdValue");
		caseDetail.setBusinessname("businessName");
		caseDetail.setFos_reference("fosReference");
		caseDetail.setFos_extendedreference("fosExtendedReference");
		caseDetail.set_fos_complaintissue_value("fosComplaintIssueValue");
		caseDetail.set_fos_complaintissue_value_txt("fosComplaintIssueValueTxt");
		caseDetail.set_fos_productorproductfamily_value_txt("fosProductOrProductFamilyValueTxt");
		caseDetail.setStatuscode_txt("statusCodeTxt");
		caseDetail.setFos_caseprogress_name("fosCaseProgressName");
		caseDetail.setFos_casestage_txt("fosCaseStageTxt");
		caseDetail.setFos_prioritycode_txt("fosPriorityCodeTxt");
		caseDetail.setFos_individualid("fosIndividualId");
		caseDetail.setFos_tradingname("fosTradingName");
		caseDetail.setFos_dateofconversion("04/16/2025 05:00:00 PM");
		caseDetail.setFos_dateofreferral("04/16/2025 05:00:00 PM");
		caseDetail.setFos_datecasefirstmovedtoinvestigation("04/16/2025 05:00:00 PM");
		caseDetail.setFos_dateofevent("04/16/2025 05:00:00 PM");
		caseDetail.setFos_dateoffinalresponse("04/16/2025 05:00:00 PM");
		caseDetails.add(caseDetail);

		// Mock userbean
		when(userbean.getCorrelationId()).thenReturn("correlationId");
		when(userbean.getUserObjectId()).thenReturn("userObjectId");

		// Use reflection to access the private method
		Method method = CaseDetailsByIdServiceImpl.class.getDeclaredMethod("setCaseDetails", List.class);
		method.setAccessible(true);

		// Invoke the private method
		Case result = (Case) method.invoke(caseDetailsByIdServiceImpl, caseDetails);

		// Verify the output
		assertNotNull(result);
		assertEquals("incidentId", result.getIncidentid());
		assertEquals("ticketNumber", result.getTicketnumber());
		assertEquals("fosCrn", result.getFos_crn());
		assertEquals("customerIdValue", result.get_customerid_value());
		assertEquals("businessName", result.getBusinessname());
		assertEquals("fosReference", result.getFos_reference());
		assertEquals("fosExtendedReference", result.getFos_extendedreference());
		assertEquals("fosComplaintIssueValue", result.get_fos_complaintissue_value());
		assertEquals("fosComplaintIssueValueTxt", result.get_fos_complaintissue_value_txt());
		assertEquals("fosProductOrProductFamilyValueTxt", result.get_fos_productorproductfamily_value_txt());
		assertEquals("statusCodeTxt", result.getStatuscode_txt());
		assertEquals("fosCaseProgressName", result.getFos_caseprogress_name());
		assertEquals("fosCaseStageTxt", result.getFos_casestage_txt());
		assertEquals("fosPriorityCodeTxt", result.getFos_prioritycode_txt());
		assertEquals("fosIndividualId", result.getFos_individualid());
		assertEquals("fosTradingName", result.getFos_tradingname());
		assertEquals("04/16/2025 05:00:00 PM", result.getFos_dateofconversion());
		assertEquals("04/16/2025 05:00:00 PM", result.getFos_dateofreferral());
		assertEquals("04/16/2025 05:00:00 PM", result.getFos_datecasefirstmovedtoinvestigation());
		assertEquals("04/16/2025 05:00:00 PM", result.getFos_dateofevent());
		assertEquals("04/16/2025 05:00:00 PM", result.getFos_dateoffinalresponse());

		// Additional checks for calculated fields
		assertNotNull(result.getBr_required());
		assertNotNull(result.getDeadlockcases());
	}
	@SuppressWarnings("unchecked")
	void testGetCasePartiesById_success() throws AzureServiceException, JSONException, IOException, SQLDataAccessException, CasePartiesNotFoundException {
		Map<String, Object> casePartiesDtls = new HashMap<>();
		casePartiesDtls.put("RESULT_SET_1", List.of(new Object()));
		casePartiesDtls.put("RESULT_SET_2", List.of(new Object()));

		when(mMockCaseDetailsDao.getCaseParties("PNX-123", List.of("accountId1", "accountId2"))).thenReturn(casePartiesDtls);

		CasePartiesByIdRes response = caseDetailsByIdServiceImpl.getCasePartiesById(mMockCaseDetailsByIdReq);
		assertEquals("Success", response.getMessage());
	}

	@Test
	void testGetCasePartiesById_invalidIncidentId() throws AzureServiceException, JSONException, IOException, SQLDataAccessException, CasePartiesNotFoundException {
	    when(mMockCaseDetailsByIdReq.getIncidentid()).thenReturn("");

	    CasePartiesByIdRes response = caseDetailsByIdServiceImpl.getCasePartiesById(mMockCaseDetailsByIdReq);
	    assertEquals("IncidentID is  an invalid field", response.getMessage());
	}


	





}
