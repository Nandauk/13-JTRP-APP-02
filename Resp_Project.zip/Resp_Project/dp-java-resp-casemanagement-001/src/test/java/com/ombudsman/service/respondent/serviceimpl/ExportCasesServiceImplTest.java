package com.ombudsman.service.respondent.serviceimpl;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.sql.SQLException;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.context.MessageSource;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.google.common.collect.Lists;
import com.ombudsman.service.respondent.common.UserBean;
import com.ombudsman.service.respondent.common.WebClientData;
import com.ombudsman.service.respondent.exception.OrganizationNotFoundException;
import com.ombudsman.service.respondent.model.Attributes;
import com.ombudsman.service.respondent.model.CaseExport;
import com.ombudsman.service.respondent.model.UserData;
import com.ombudsman.service.respondent.model.dto.AuditMaster;
import com.ombudsman.service.respondent.model.dto.NotificationModel;
import com.ombudsman.service.respondent.model.dto.RequestModel;
import com.ombudsman.service.respondent.model.dto.UserEventConfiguration;
import com.ombudsman.service.respondent.model.response.GetResponseMessage;
import com.ombudsman.service.respondent.service.IExportCasesService;
import com.ombudsman.service.respondent.service.repository.AuditRepository;
import com.ombudsman.service.respondent.service.repository.RequestModelRepository;
import com.ombudsman.service.respondent.service.repository.UpdateRequestsRepository;
import com.ombudsman.service.respondent.service.repository.UserEventConfigurationRepository;

@ExtendWith(SpringExtension.class)
class ExportCasesServiceImplTest {

	@Mock
	private UserBean userBean;
	@Mock
	MessageSource messageSource;
	@InjectMocks
	ExportCasesServiceImpl testInstance;
	@Mock
	NotificationModel mMockNotificationModel;
	@Mock
	IExportCasesService mMockExportCasesService;
	@Mock
	CaseExport mMockCaseExport;
	@Mock
	AuditRepository mMockAuditRepository;

	@Mock
	UserEventConfigurationRepository mMockUserEventConfigurationRepository;
	@Mock
	UserEventConfiguration mMockUserEventConfiguration;
	@Mock
	UpdateRequestsRepository mMockUpdateRequestsRepository;
	@Mock
	RequestModelRepository mMockRequestModelRepository;
	@Mock
	Attributes mMockAttributes;
	@Mock
	AuditMaster mMockAuditMaster;
	@Mock
	RequestModel mMockRequestModel;
	@Mock
	WebClientData mMockWebClientData;
	@Mock
	private UserData mMockUserData;
	private static List<String> groupIds = new ArrayList<>();

	@BeforeEach
	void setUp() {
		when(userBean.getGroups()).thenReturn(groupIds);
		when(userBean.getEmail()).thenReturn("test@gmail.com");
		when(userBean.getRoles()).thenReturn(Lists.newArrayList("Respondent Admin"));
		when(userBean.getUserObjectId()).thenReturn("8d3374fb-d44d-465e-8d05-ab1ea7f952e3");
		mMockAttributes.setOpencasesonly("true");
		mMockAttributes.setOrganisations(groupIds);
		mMockCaseExport.setTemplateId(7123);
		mMockCaseExport.setMessageId("Success");
		when(mMockCaseExport.getAttributes()).thenReturn(mMockAttributes);
		when(mMockAttributes.getUsers()).thenReturn(mMockUserData);
		when(mMockCaseExport.getAttributes().getOrganisations()).thenReturn(
				Lists.newArrayList("88590577-9eee-45a2-8bc3-ee94f9dc4b2a", "fcf82002-2240-40ef-82d8-57b222a8224e"));
		mMockUserEventConfiguration = new UserEventConfiguration();
		mMockUserEventConfiguration.setIsAuditRequired(true);
		mMockUserEventConfiguration.setIsNotificationNeeded(true);
		mMockUserEventConfiguration.setUserEventName("caseExport");
		mMockRequestModel = new RequestModel();
		mMockRequestModel.setRequestId("req1d");
		mMockRequestModel.setCreatedBy("exportapi");
		OffsetDateTime offsetdatetime = OffsetDateTime.now();
		mMockRequestModel.setCreatedOn(offsetdatetime);
		mMockRequestModel.setRequestingActivityName("Export");
		mMockRequestModel.setRequestStatusId(2);
		mMockRequestModel.setRequestStatusDescription("Status");
		mMockRequestModel.setUserOid("oid");
		mMockNotificationModel.setRequest_id("req1d");
		mMockNotificationModel.setNotification_status_id("2");
		mMockNotificationModel.setNotification_status_description("ReadyForDelivery");
		mMockNotificationModel.setRequesting_activity_name("export");
		mMockNotificationModel.setUser_oid("useroid");
		mMockNotificationModel.setFile_download_url("url");
	}

	@Test
	@DisplayName("getCasesExportRequestIdTest")
	void test_GetExportCasesbyRespondent_Failed() throws InterruptedException, IOException, SQLException,
			NullPointerException, OrganizationNotFoundException {
		GetResponseMessage actualResponse = new GetResponseMessage();
		when(mMockUserEventConfigurationRepository.getUserEventRecord("caseExport"))
				.thenReturn(mMockUserEventConfiguration);
		when(mMockUpdateRequestsRepository.getAccountId("fca14")).thenReturn(groupIds);
		try {
			actualResponse = testInstance.getCasesExportDataByRespondent(mMockCaseExport);
		} catch (Exception e) {
			assertNotNull(e.getMessage());
		}

	}

	@Test
	@DisplayName("getCasesExportOrganisationTest")
	void test_GetExportCasesbyRespondentOrganisation_Failed() throws InterruptedException, IOException, SQLException,
			NullPointerException, OrganizationNotFoundException {

		when(mMockUserEventConfigurationRepository.getUserEventRecord("caseExport"))
				.thenReturn(mMockUserEventConfiguration);
		when(mMockCaseExport.getAttributes().getOrganisations()).thenReturn(null);

		try {
			testInstance.getCasesExportDataByRespondent(mMockCaseExport);
		} catch (OrganizationNotFoundException e) {
			assertEquals("User is not tagged with any organisation.", e.getMessage());
		}

	}

//	@Test
//	@DisplayName("getExportCasesbyRespondentTest")
//	void test_GetExportCasesbyRespondent() throws InterruptedException, IOException, SQLException, NullPointerException,
//			OrganizationNotFoundException {
//
//		when(mMockRequestModelRepository.save(mMockRequestModel)).thenReturn(new RequestModel());
//		when(mMockRequestModelRepository.save(mMockRequestModel).getRequestId()).thenReturn(Mockito.any());
//
////		when(mMockRequestModel.getRequestId()).thenReturn("req1d");
//		when(mMockUserEventConfigurationRepository.getUserEventRecord("caseExport"))
//				.thenReturn(mMockUserEventConfiguration);
//
//		try {
//			testInstance.getCasesExportDataByRespondent(mMockCaseExport);
//		} catch (OrganizationNotFoundException e) {
//			assertEquals("User is not tagged with any organisation.", e.getMessage());
//		}
//
//	}

}
