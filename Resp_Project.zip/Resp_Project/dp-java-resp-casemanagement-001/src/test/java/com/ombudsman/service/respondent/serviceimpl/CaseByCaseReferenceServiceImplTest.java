package com.ombudsman.service.respondent.serviceimpl;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.security.auth.login.AccountNotFoundException;

import org.json.JSONException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.google.common.collect.Lists;
import com.ombudsman.service.respondent.common.CommonUtil;
import com.ombudsman.service.respondent.common.UserBean;
import com.ombudsman.service.respondent.exception.AzureServiceException;
import com.ombudsman.service.respondent.exception.SQLDataAccessException;
import com.ombudsman.service.respondent.exception.UnAuthorisedException;
import com.ombudsman.service.respondent.model.dto.CaseByCaseReferenceDto;
import com.ombudsman.service.respondent.model.request.CaseByCaseReferenceReq;
import com.ombudsman.service.respondent.model.response.CaseByCaseReferenceRes;
import com.ombudsman.service.respondent.repository.dao.CaseDetailsDao;
import com.ombudsman.service.respondent.serviceimpl.helper.CaseServiceHelper;

@ExtendWith(SpringExtension.class)
 class CaseByCaseReferenceServiceImplTest {
	
	private static final String CASE_REFERENCE_IS_AN_INVALID_FIELD = "Case Reference is an invalid field";

	private static final String USER_IS_NOT_TAGGED_WITH_ANY_ORGANISATION = "User is not tagged with any organisation.";

	@InjectMocks
	private CaseByCaseReferenceServiceImpl caseByCaseReferenceServiceImpl;
	
	@Mock
	private CaseServiceHelper mMockCaseServiceHelper;
	
	@Mock
	private CaseByCaseReferenceReq mMockCaseByCaseReferenceReq;
	
	@Mock
	private CommonUtil mMockCommonUtil;
	
	@Mock
	private CaseDetailsDao mMockcaseDetailsDao;
	
	@Mock
	UserBean userbean;

	private static List<String> groupIds = new ArrayList<>();
	private static final String COMMA = ",";

	@BeforeEach
	void setUp() {
		groupIds.add("groupId1");
		groupIds.add("groupId2");
		when(userbean.getGroups()).thenReturn(groupIds);
		when(mMockCommonUtil.isValidInput("Test@1234")).thenReturn(true);

	}
	
	@DisplayName("shouldGetCaseIncidentidByCaseReferenceSuccessfully")
	@Test
	void shouldGetCaseIncidentidByCaseReferenceSuccessfully()
			throws AzureServiceException, JSONException, IOException, SQLDataAccessException, AccountNotFoundException, UnAuthorisedException {
	
		final String accIds = "acctId1,acctId2";
		final List<String> accountIds = Stream.of(accIds.split(COMMA)).collect(Collectors.toList());
		final List<CaseByCaseReferenceDto> caseByCaseReferenceData = new ArrayList<CaseByCaseReferenceDto>();
		final CaseByCaseReferenceDto testCaseByCaseReferenceDto = new CaseByCaseReferenceDto("incident123");
		caseByCaseReferenceData.add(testCaseByCaseReferenceDto);
		
		when(mMockCaseServiceHelper.getAccountIds("oid")).thenReturn(Lists.newArrayList("acctId1","acctId2"));
		when(mMockcaseDetailsDao.getCaseIncidentidByCaseReference("Test@1234",accountIds)).thenReturn(caseByCaseReferenceData);
		when(mMockCaseByCaseReferenceReq.getCasefererence()).thenReturn("Test@1234");
		CaseByCaseReferenceRes result = caseByCaseReferenceServiceImpl.getCaseIncidentidByCaseReference(mMockCaseByCaseReferenceReq);
		// Assert
		assertNotNull(result);
		assertEquals(1, caseByCaseReferenceData.size());
		assertNotNull(caseByCaseReferenceData.get(0).getIncidentId());
		// verify
		//verify(mMockcaseDetailsDao).getCaseIncidentidByCaseReference(mMockCaseByCaseReferenceReq.getCasefererence(),accountIds);
		//verify(userbean).getGroups();
		
	}
	
	@DisplayName("getCaseReferenceisanInvalidField")
	@Test
	void getCaseReferenceisanInvalidField()
			throws AzureServiceException, JSONException, IOException, SQLDataAccessException, AccountNotFoundException, UnAuthorisedException {
	
		final String accIds = "acctId1,acctId2";
		final List<String> accountIds = Stream.of(accIds.split(COMMA)).collect(Collectors.toList());
		final List<CaseByCaseReferenceDto> caseByCaseReferenceData = new ArrayList<CaseByCaseReferenceDto>();
		final CaseByCaseReferenceDto testCaseByCaseReferenceDto = new CaseByCaseReferenceDto("incident123");
		caseByCaseReferenceData.add(testCaseByCaseReferenceDto);
		
		when(mMockCaseServiceHelper.getAccountIds("oid")).thenReturn(Lists.newArrayList("acctId1","acctId2"));
		CaseByCaseReferenceRes result = caseByCaseReferenceServiceImpl.getCaseIncidentidByCaseReference(mMockCaseByCaseReferenceReq);
		// Assert
		assertNotNull(result);
		assertEquals(CASE_REFERENCE_IS_AN_INVALID_FIELD, result.getMessage());

	}
	
}
