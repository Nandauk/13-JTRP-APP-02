package com.ombudsman.service.respondent.repository;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

import java.util.*;
import javax.sql.DataSource;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;

import com.ombudsman.service.respondent.exception.SQLDataAccessException;
import com.ombudsman.service.respondent.exception.SQLServerException;
import com.ombudsman.service.respondent.model.dto.CaseFilterDetailsDto;
import com.ombudsman.service.respondent.model.dto.CaseWorkerDto;
import com.ombudsman.service.respondent.model.dto.OrganizationDto;
import com.ombudsman.service.respondent.service.repository.CaseListJdbcRepository;

@ExtendWith(MockitoExtension.class)
class CaseListJdbcRepositoryTest {

    @Mock
    private JdbcTemplate jdbcTemplate;

    @Mock
    private NamedParameterJdbcTemplate namedJdbcTemplate;

    @InjectMocks
    private CaseListJdbcRepository caseListJdbcRepository;

    @BeforeEach
    void setUp() {
      
    }

    @Test
    @DisplayName("setDataSource - verifies no exception")
    void testSetDataSource() {
        DataSource ds = org.mockito.Mockito.mock(DataSource.class);
        caseListJdbcRepository.setDataSource(ds);
    }

    // 1) getOrganisationAccountIds(..)
  

    // 2) getAccountIds(..)
    

    // 3) getCaseListDetails(..)
   

    // 4) getCaseFilter(..)
    @Test
    @DisplayName("getCaseFilter - returns List<CaseFilterDetailsDto>")
    void testGetCaseFilter() throws SQLDataAccessException {
        List<String> accountIds = Arrays.asList("ACC1", "ACC2");

      
        when(namedJdbcTemplate.query(
            anyString(),
            ArgumentMatchers.<SqlParameterSource>any(),
            ArgumentMatchers.<org.springframework.jdbc.core.RowMapper<CaseFilterDetailsDto>>any()
        )).thenReturn(Collections.singletonList(
            new CaseFilterDetailsDto("FilterType", "FilterValue", "ACC-999")
        ));

        List<CaseFilterDetailsDto> result = caseListJdbcRepository.getCaseFilter(accountIds);

        assertThat(result).hasSize(1);
        assertThat(result.get(0).getFilterType()).isEqualTo("FilterType");
        assertThat(result.get(0).getFilterValue()).isEqualTo("FilterValue");
        assertThat(result.get(0).getAccountId()).isEqualTo("ACC-999");
    }

    // 5) getFindOrganizationName(..)
    @Test
    @DisplayName("getFindOrganizationName - returns List<OrganizationDto>")
    void testGetFindOrganizationName() throws SQLDataAccessException {
        List<String> accountIds = Arrays.asList("ACC1", "ACC2");

        // specify RowMapper<OrganizationDto> 
        when(namedJdbcTemplate.query(
            anyString(),
            ArgumentMatchers.<SqlParameterSource>any(),
            ArgumentMatchers.<org.springframework.jdbc.core.RowMapper<OrganizationDto>>any()
        )).thenReturn(Collections.singletonList(new OrganizationDto("OrgName", "OrgId")));

        List<OrganizationDto> result = caseListJdbcRepository.getFindOrganizationName(accountIds);
        assertThat(result).hasSize(1);
        OrganizationDto org = result.get(0);
        assertThat(org.getOrganizationName()).isEqualTo("OrgName");
        assertThat(org.getOrganizationId()).isEqualTo("OrgId");
    }

    // 6) getRoleId(..)
    @Test
    @DisplayName("getRoleId - returns integer")
    void testGetRoleId_success() throws SQLServerException {
        when(namedJdbcTemplate.queryForObject(
            anyString(),
            ArgumentMatchers.<Map<String,Object>>any(),
            eq(Integer.class))
        ).thenReturn(29);

        int result = caseListJdbcRepository.getRoleId("caseworker");
        assertThat(result).isEqualTo(29);
    }

    @Test
    @DisplayName("getRoleId - throws SQLServerException")
    void testGetRoleId_error() {
        when(namedJdbcTemplate.queryForObject(
            anyString(),
            ArgumentMatchers.<Map<String,Object>>any(),
            eq(Integer.class))
        ).thenThrow(new RuntimeException("DB error"));

        assertThrows(SQLServerException.class, () -> {
            caseListJdbcRepository.getRoleId("caseworker");
        });
    }

    // 7) getGroupId(..)
    @Test
    @DisplayName("getGroupId - returns integer")
    void testGetGroupId_success() throws SQLServerException {
        when(namedJdbcTemplate.queryForList(
            anyString(),
            ArgumentMatchers.<Map<String,Object>>any(),
            eq(Integer.class))
        ).thenReturn(Arrays.asList(261));

        List<Integer> result = caseListJdbcRepository.getGroupId("ACC-999");
        assertThat(result).isEqualTo(Arrays.asList(261));
    }

    @Test
    @DisplayName("getGroupId - throws SQLServerException")
    void testGetGroupId_error() {
        when(namedJdbcTemplate.queryForList(
            anyString(),
            ArgumentMatchers.<Map<String,Object>>any(),
            eq(List.class))
        ).thenThrow(new RuntimeException("DB error"));

        assertThrows(SQLServerException.class, () -> {
            caseListJdbcRepository.getGroupId("");
        });
    }

    // 8) getCaseworkersByRoleIdsAndGroup(..)
    @Test
    @DisplayName("getCaseworkersByRoleIdsAndGroup - returns List<CaseWorkerDto>")
    void testGetCaseworkersByRoleIdsAndGroup() throws SQLServerException {
        when(namedJdbcTemplate.query(
            anyString(),
            ArgumentMatchers.<Map<String,Object>>any(),
            ArgumentMatchers.<org.springframework.jdbc.core.RowMapper<CaseWorkerDto>>any()
        )).thenReturn(Collections.singletonList(
            buildCaseWorkerDto("OID-123","John Doe","john@example.com")
        ));

        List<Integer> roleIds = Arrays.asList(29, 40);
        List<Integer> groupId = Arrays.asList(261, 261);
        String userOid="12345";

        List<CaseWorkerDto> result = caseListJdbcRepository.getCaseworkersByRoleIdsAndGroup(roleIds, groupId,userOid);
        assertThat(result).hasSize(1);
        CaseWorkerDto dto = result.get(0);
        assertThat(dto.getOId()).isEqualTo("OID-123");
        assertThat(dto.getFullname()).isEqualTo("John Doe");
        assertThat(dto.getInternalemailaddress()).isEqualTo("john@example.com");
    }

    @Test
    @DisplayName("getCaseworkersByRoleIdsAndGroup - throws SQLServerException on error")
    void testGetCaseworkersByRoleIdsAndGroup_error() {
        when(namedJdbcTemplate.query(
            anyString(),
            ArgumentMatchers.<Map<String,Object>>any(),
            ArgumentMatchers.<org.springframework.jdbc.core.RowMapper<CaseWorkerDto>>any()
        )).thenThrow(new RuntimeException("DB error"));

        assertThrows(SQLServerException.class, () -> {
            caseListJdbcRepository.getCaseworkersByRoleIdsAndGroup(Arrays.asList(29), Arrays.asList(261),"12345");
        });
    }

    // 9) getAccountIdsAndRolesByOid(..)
   

    @Test
    @DisplayName("getAccountIdsAndRolesByOid - throws SQLServerException")
    void testGetAccountIdsAndRolesByOid_error() {
        when(jdbcTemplate.getDataSource()).thenThrow(new RuntimeException("DB error"));

        assertThrows(SQLServerException.class, () -> {
            caseListJdbcRepository.getAccountIdsAndRolesByOid("OID-888");
        });
    }

    // 10) validateUserAndCases(..)
   

    // 11) assignCasesToUser(..)
    @Test
    @DisplayName("assignCasesToUser - updates/inserts and returns user full_name")
    void testAssignCasesToUser() {
        // 1) existing incident
        when(namedJdbcTemplate.queryForList(
            anyString(),
            ArgumentMatchers.<Map<String,Object>>any(),
            eq(String.class))
        ).thenReturn(Arrays.asList("INC-2"));

        // 2) user name
        when(namedJdbcTemplate.queryForObject(
            anyString(),
            ArgumentMatchers.<Map<String,Object>>any(),
            eq(String.class))
        ).thenReturn("John Doe");

        // We'll ignore batchUpdate calls

        String fullName = caseListJdbcRepository.assignCasesToUser(
            Arrays.asList("INC-1","INC-2","INC-3"), "OID-123"
        );
        assertThat(fullName).isEqualTo("John Doe");
    }

    // 12) getIncidentIdsByTicketNumbers(..)
    @Test
    @DisplayName("getIncidentIdsByTicketNumbers - returns list of incidentIDs")
    void testGetIncidentIdsByTicketNumbers() {
        List<String> tickets = Arrays.asList("TICK-1","TICK-2");
        when(namedJdbcTemplate.queryForList(
            anyString(),
            ArgumentMatchers.<Map<String,Object>>any(),
            eq(String.class))
        ).thenReturn(Arrays.asList("INC-1","INC-2"));

        List<String> result = caseListJdbcRepository.getIncidentIdsByTicketNumbers(tickets);
        assertThat(result).containsExactly("INC-1","INC-2");
    }

    // 13) createAuditForCaseAssignment(..)
    @Test
    @DisplayName("createAuditForCaseAssignment - calls findLastPostSnapshot & insertAuditEvent")
    void testCreateAuditForCaseAssignment() {
        // findLastPostSnapshot calls queryForList
        when(namedJdbcTemplate.queryForList(
            anyString(),
            ArgumentMatchers.<Map<String,Object>>any(),
            eq(String.class))
        ).thenReturn(Collections.singletonList("oldSnapshotVal"));


        caseListJdbcRepository.createAuditForCaseAssignment(
            "auditEventName",
            "primaryEntity",
            "ID-ABC",
            "assignedToName",
            Arrays.asList("INC1","INC2"),
            "userOidVal",
            "createdByVal"
        );
       
    }

    // Helper
    private CaseWorkerDto buildCaseWorkerDto(String oid, String name, String email) {
        CaseWorkerDto dto = new CaseWorkerDto();
        dto.setOId(oid);
        dto.setFullname(name);
        dto.setInternalemailaddress(email);
        return dto;
    }
}
