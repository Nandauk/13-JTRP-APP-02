package com.ombudsman.service.respondent.model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

class CaseOutcomeTest {

    @Test
    void testGettersAndSetters() {
        CaseOutcome outcome = new CaseOutcome();

        outcome.set_fos_case_value("CASE-VAL");
        assertEquals("CASE-VAL", outcome.get_fos_case_value());

        outcome.setFos_offeroroutcomeid("OUTCOMEID-123");
        assertEquals("OUTCOMEID-123", outcome.getFos_offeroroutcomeid());

        outcome.setFos_type("Type123");
        assertEquals("Type123", outcome.getFos_type());

        outcome.setFos_type_txt("Type Display");
        assertEquals("Type Display", outcome.getFos_type_txt());

        outcome.setFos_meritsjurisdictiondismissal("DismissalVal");
        assertEquals("DismissalVal", outcome.getFos_meritsjurisdictiondismissal());

        outcome.setFos_meritsjurisdictiondismissal_txt("Dismissal Text");
        assertEquals("Dismissal Text", outcome.getFos_meritsjurisdictiondismissal_txt());

        outcome.setFos_meritopinion("Merit Opinion");
        assertEquals("Merit Opinion", outcome.getFos_meritopinion());

        outcome.setFos_meritopinion_txt("Merit Opinion Text");
        assertEquals("Merit Opinion Text", outcome.getFos_meritopinion_txt());

        outcome.setFos_jurisdictioninout("InOutVal");
        assertEquals("InOutVal", outcome.getFos_jurisdictioninout());

        outcome.setFos_jurisdictioninout_txt("InOut Text");
        assertEquals("InOut Text", outcome.getFos_jurisdictioninout_txt());

        outcome.setFos_dismissalreason("Dismissal Reason");
        assertEquals("Dismissal Reason", outcome.getFos_dismissalreason());

        outcome.setFos_withopinion("With Opinion");
        assertEquals("With Opinion", outcome.getFos_withopinion());

        outcome.setFos_changeinoutcome("ChangeInOutcomeVal");
        assertEquals("ChangeInOutcomeVal", outcome.getFos_changeinoutcome());

        outcome.setFos_changeinoutcome_txt("ChangeInOutcome Text");
        assertEquals("ChangeInOutcome Text", outcome.getFos_changeinoutcome_txt());

        outcome.set_fos_settlementbandid_value("SET-BAND-ID");
        assertEquals("SET-BAND-ID", outcome.get_fos_settlementbandid_value());

        outcome.set_fos_settlementbandid_value_txt("Settlement Band Text");
        assertEquals("Settlement Band Text", outcome.get_fos_settlementbandid_value_txt());

        outcome.setFos_nonmonetarysettlement("Non Monetary");
        assertEquals("Non Monetary", outcome.getFos_nonmonetarysettlement());

        outcome.setFos_troubleupsetamt("1000");
        assertEquals("1000", outcome.getFos_troubleupsetamt());

        outcome.setFos_complainantresponse("Complainant Resp");
        assertEquals("Complainant Resp", outcome.getFos_complainantresponse());

        outcome.setFos_complainantresponse_txt("Complainant Resp Text");
        assertEquals("Complainant Resp Text", outcome.getFos_complainantresponse_txt());

        outcome.setFos_respondentresponse("Respondent Resp");
        assertEquals("Respondent Resp", outcome.getFos_respondentresponse());

        outcome.setFos_respondentresponse_txt("Respondent Resp Text");
        assertEquals("Respondent Resp Text", outcome.getFos_respondentresponse_txt());

        outcome.setOutcomedate("2023-10-10");
        assertEquals("2023-10-10", outcome.getOutcomedate());
    }
}
