package com.ombudsman.service.respondent.serviceimpl;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.ombudsman.service.respondent.common.CaseManagementWebClient;
import com.ombudsman.service.respondent.model.response.GenericResponse;

@ExtendWith(SpringExtension.class)
class LoginServiceImplTest {
	
	@InjectMocks
	private LoginServiceImpl testInstance;
	@Mock
	private GenericResponse mMockGenericResponse;
	
	@Mock
	CaseManagementWebClient caseManagementWebClient;
	
	@Test
	void addUserSessionEntry_Test() throws Exception {
		GenericResponse response = new GenericResponse();
		response.setMessage("Valid");
		when(caseManagementWebClient.getResponseForSessionActivity("Login")).thenReturn(mMockGenericResponse);		
		
		assertEquals(null, testInstance.addUserSessionEntry());
		
	}
	
	@Test
	void logoutForUserSession_Test() throws Exception {
		GenericResponse response = new GenericResponse();
		response.setMessage("Valid");
		when(caseManagementWebClient.getResponseForSessionActivity("Login")).thenReturn(mMockGenericResponse);		
		
		assertEquals(null, testInstance.logoutForUserSession());
		
	}
	
	@Test
	void getSessionTokenStatus_Test() throws Exception {
		GenericResponse response = new GenericResponse();
		response.setMessage("Valid");
		when(caseManagementWebClient.getResponseForSessionActivity("Login")).thenReturn(mMockGenericResponse);		
		
		assertEquals(null, testInstance.getSessionTokenStatus());
		
	}

}
