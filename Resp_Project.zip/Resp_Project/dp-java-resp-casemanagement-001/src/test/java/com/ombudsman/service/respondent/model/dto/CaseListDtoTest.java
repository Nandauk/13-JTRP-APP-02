package com.ombudsman.service.respondent.model.dto;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.ombudsman.service.respondent.model.CaseListDto;

@ExtendWith(SpringExtension.class)
public class CaseListDtoTest {
	
	@InjectMocks
	CaseListDto mMockCaseListDto;
	
	@Test
	public void testGetterAndSetter() {
		
		//Set values
		mMockCaseListDto.setAgecaseflag("yes");
		mMockCaseListDto.setAwaitingaction("awaitingaction");
		mMockCaseListDto.setAwaitingactionfilter("Awaitingactionfilter");
		mMockCaseListDto.setBr_required("2023-10-15 23:04:01.1234567");
		mMockCaseListDto.setBusinessname("Businessname");
		mMockCaseListDto.setCaseagebanding("caseagebanding");
		mMockCaseListDto.setCaseagebandingid("123");
		mMockCaseListDto.setCustomerid("cust123");
		mMockCaseListDto.setDeadlockcases("dead123");
		mMockCaseListDto.setDescription("Desc");
		mMockCaseListDto.setFos_caselinkid("caselink123");
		mMockCaseListDto.setFos_caseprogress("caseprogress");
		mMockCaseListDto.setFos_caseprogress_name("caseprogressname");
		mMockCaseListDto.setFos_casestage("casestage");
		mMockCaseListDto.setFos_casestagename("casestagename");
		mMockCaseListDto.setFos_caseworker("caseworker");
		mMockCaseListDto.setFos_changeinoutcome("changout123");
		mMockCaseListDto.setFos_changeinoutcomename("changename");
		mMockCaseListDto.setFos_complaintissue("compissue");
		mMockCaseListDto.setFos_complaintissuename("compissuename");
		mMockCaseListDto.setFos_crn("crn123");

		mMockCaseListDto.setFos_datebusinessfilereceived("2023-10-15 23:04:01.1234567");
		mMockCaseListDto.setFos_datecasefirstmovedtoinvestigation("2023-10-15 23:04:01.1234567");
		mMockCaseListDto.setFos_dateofconversion("2023-10-15 23:04:01.1234567");
		mMockCaseListDto.setFos_dateofevent("2023-10-15 23:04:01.1234567");
		mMockCaseListDto.setFos_dateoffinalresponse("2023-10-15 23:04:01.1234567");
		mMockCaseListDto.setFos_dateofreferral("2023-10-15 23:04:01.1234567");
		mMockCaseListDto.setFos_dispatcheddate("2023-10-15 23:04:01.1234567");
		mMockCaseListDto.setFos_extendedreference("extdref");
		mMockCaseListDto.setFos_individualid("ind123");
		mMockCaseListDto.setFos_individualidname("indname");
		mMockCaseListDto.setFos_offeroutcome("2023-10-15 23:04:01.1234567");
		mMockCaseListDto.setFos_oldercasestatus("ocs");
		mMockCaseListDto.setFos_outcomedispatcheddate("2023-10-15 23:04:01.1234567");
		mMockCaseListDto.setFos_prioritycode("p1");
		mMockCaseListDto.setFos_prioritycodename("pname");
		mMockCaseListDto.setFos_productorproductfamily("pfamily");
		mMockCaseListDto.setFos_productorproductfamilyname("pname");
		mMockCaseListDto.setFos_reference("ref");
		mMockCaseListDto.setFos_representatives("rep");
		mMockCaseListDto.setFos_resolvingoutcomeid("rid");
		mMockCaseListDto.setFos_tradingname("tname");
		mMockCaseListDto.setFos_tradingnamename("tname1");
		mMockCaseListDto.setFos_type("ftype");
		mMockCaseListDto.setFos_typename("ftypename");
		mMockCaseListDto.setIncidentid("123");
		mMockCaseListDto.setNoofcorrespondet("1");
		mMockCaseListDto.setNoofefile("1");
		mMockCaseListDto.setOwninguser("user");
		mMockCaseListDto.setStatecode("123");
		mMockCaseListDto.setStatuscode("1234");
		mMockCaseListDto.setStatuscodename("sname");
		mMockCaseListDto.setTicketnumber("123");
		mMockCaseListDto.setVulnerable("123");
		
		//Get values and assert
		
		assertEquals("yes", mMockCaseListDto.getAgecaseflag());
		assertEquals("awaitingaction", mMockCaseListDto.getAwaitingaction());
		assertEquals("Awaitingactionfilter", mMockCaseListDto.getAwaitingactionfilter());
		assertEquals("10/15/2023 11:04:01 PM", mMockCaseListDto.getBr_required());
		assertEquals("Businessname", mMockCaseListDto.getBusinessname());
		assertEquals("caseagebanding", mMockCaseListDto.getCaseagebanding());
		assertEquals("123", mMockCaseListDto.getCaseagebandingid());
		assertEquals("cust123", mMockCaseListDto.getCustomerid());
		assertEquals("dead123", mMockCaseListDto.getDeadlockcases());
		assertEquals("Desc", mMockCaseListDto.getDescription());
		assertEquals("caselink123", mMockCaseListDto.getFos_caselinkid());
		assertEquals("caseprogress" , mMockCaseListDto.getFos_caseprogress());
		assertEquals("caseprogressname", mMockCaseListDto.getFos_caseprogress_name());
		assertEquals("casestage",mMockCaseListDto.getFos_casestage());
		assertEquals("casestagename", mMockCaseListDto.getFos_casestagename());
		assertEquals("caseworker",mMockCaseListDto.getFos_caseworker());
		assertEquals("changout123", mMockCaseListDto.getFos_changeinoutcome());
		assertEquals("changename" , mMockCaseListDto.getFos_changeinoutcomename());
		assertEquals("compissue" , mMockCaseListDto.getFos_complaintissue());
		assertEquals("compissuename", mMockCaseListDto.getFos_complaintissuename());
		assertEquals("crn123" , mMockCaseListDto.getFos_crn());

		assertEquals("10/15/2023 11:04:01 PM",mMockCaseListDto.getFos_datebusinessfilereceived());
		assertEquals("10/15/2023 11:04:01 PM" , mMockCaseListDto.getFos_datecasefirstmovedtoinvestigation());
		assertEquals("10/15/2023 11:04:01 PM", mMockCaseListDto.getFos_dateofconversion());
		assertEquals("10/15/2023 11:04:01 PM" , mMockCaseListDto.getFos_dateofevent());
		assertEquals("10/15/2023 11:04:01 PM" , mMockCaseListDto.getFos_dateoffinalresponse());
		assertEquals("10/15/2023 11:04:01 PM" , mMockCaseListDto.getFos_dateofreferral());
		assertEquals("2023-10-15 23:04:01.1234567", mMockCaseListDto.getFos_dispatcheddate());

		assertEquals("extdref", mMockCaseListDto.getFos_extendedreference());
		assertEquals("ind123", mMockCaseListDto.getFos_individualid());
		assertEquals("indname", mMockCaseListDto.getFos_individualidname());
		assertEquals("10/15/2023 11:04:01 PM", mMockCaseListDto.getFos_offeroutcome());
		assertEquals("ocs", mMockCaseListDto.getFos_oldercasestatus());
		assertEquals("10/15/2023 11:04:01 PM", mMockCaseListDto.getFos_outcomedispatcheddate());
		assertEquals("p1", mMockCaseListDto.getFos_prioritycode());
		assertEquals("pname", mMockCaseListDto.getFos_prioritycodename());
		assertEquals("pfamily", mMockCaseListDto.getFos_productorproductfamily());
		assertEquals("pname", mMockCaseListDto.getFos_productorproductfamilyname());
		assertEquals("ref", mMockCaseListDto.getFos_reference());
		assertEquals("rep", mMockCaseListDto.getFos_representatives());
		assertEquals("rid", mMockCaseListDto.getFos_resolvingoutcomeid());
		assertEquals("tname", mMockCaseListDto.getFos_tradingname());
		assertEquals("tname1", mMockCaseListDto.getFos_tradingnamename());
		assertEquals("ftype", mMockCaseListDto.getFos_type());
		assertEquals("ftypename", mMockCaseListDto.getFos_typename());
		assertEquals("123", mMockCaseListDto.getIncidentid());
		assertEquals("1", mMockCaseListDto.getNoofcorrespondet());
		assertEquals("1", mMockCaseListDto.getNoofefile());
		assertEquals("user", mMockCaseListDto.getOwninguser());
		assertEquals("123", mMockCaseListDto.getStatecode());
		assertEquals("1234", mMockCaseListDto.getStatuscode());
		assertEquals("sname", mMockCaseListDto.getStatuscodename());
		assertEquals("123", mMockCaseListDto.getTicketnumber());
		assertEquals("123", mMockCaseListDto.getVulnerable());		
	}

}
