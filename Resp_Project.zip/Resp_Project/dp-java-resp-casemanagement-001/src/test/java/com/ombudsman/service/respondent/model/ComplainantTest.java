package com.ombudsman.service.respondent.model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

class ComplainantTest {

    @Test
    void testGettersAndSetters() {
        Complainant compl = new Complainant();

        compl.setSuffix("Jr.");
        assertEquals("Jr.", compl.getSuffix());

        compl.setAddress1_composite("123 Main St, City, Country");
        assertEquals("123 Main St, City, Country", compl.getAddress1_composite());

        compl.setTelephone1("555-1111");
        assertEquals("555-1111", compl.getTelephone1());

        compl.setTelephone2("555-2222");
        assertEquals("555-2222", compl.getTelephone2());

        compl.setEmailaddress1("complainant@example.com");
        assertEquals("complainant@example.com", compl.getEmailaddress1());

        compl.setBirthdate("1990-01-01");
        assertEquals("1990-01-01", compl.getBirthdate());

        compl.setOrganisation_existInComplainant("true");
        assertEquals("true", compl.getOrganisation_existInComplainant());

        compl.setFos_organisationid("ORG-999");
        assertEquals("ORG-999", compl.getFos_organisationid());
    }
}
