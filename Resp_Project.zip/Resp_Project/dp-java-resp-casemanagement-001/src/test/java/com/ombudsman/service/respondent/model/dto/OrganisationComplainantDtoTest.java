package com.ombudsman.service.respondent.model.dto;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import static org.junit.jupiter.api.Assertions.*;
@ExtendWith(SpringExtension.class)
public class OrganisationComplainantDtoTest {
	@InjectMocks
	private OrganisationComplainantDto organisationComplainantDto;

	@BeforeEach
	public void setUp() {
		organisationComplainantDto = new OrganisationComplainantDto();
	}

	@Test
	public void testGetterAndSetter() {
		// Set values
		organisationComplainantDto.setBusinesstypecode("BUS123");
		organisationComplainantDto.setAddress1_line1("123 Main St");
		organisationComplainantDto.setAddress1_line2("Suite 4B");
		organisationComplainantDto.setAddress1_line3("Building 7");
		organisationComplainantDto.setAddress1_county("Springfield");
		organisationComplainantDto.setAddress1_postalcode("12345");
		organisationComplainantDto.setRcount("10");
		organisationComplainantDto.setFos_businesstypecode_txt("Business Type");
		organisationComplainantDto.setName("John Doe Inc.");

		// Assert values
		assertEquals("BUS123", organisationComplainantDto.getBusinesstypecode());
		assertEquals("123 Main St", organisationComplainantDto.getAddress1_line1());
		assertEquals("Suite 4B", organisationComplainantDto.getAddress1_line2());
		assertEquals("Building 7", organisationComplainantDto.getAddress1_line3());
		assertEquals("Springfield", organisationComplainantDto.getAddress1_county());
		assertEquals("12345", organisationComplainantDto.getAddress1_postalcode());
		assertEquals("10", organisationComplainantDto.getRcount());
		assertEquals("Business Type", organisationComplainantDto.getFos_businesstypecode_txt());
		assertEquals("John Doe Inc.", organisationComplainantDto.getName());
	}
}
