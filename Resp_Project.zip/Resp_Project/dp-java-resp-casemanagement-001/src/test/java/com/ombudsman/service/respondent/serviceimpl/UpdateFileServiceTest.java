package com.ombudsman.service.respondent.serviceimpl;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpStatus;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.Lists;
import com.ombudsman.service.respondent.common.CommonUtil;
import com.ombudsman.service.respondent.common.StaticUtils;
import com.ombudsman.service.respondent.common.UserBean;
import com.ombudsman.service.respondent.common.WebClientData;
import com.ombudsman.service.respondent.exception.CaseUpdateException;
import com.ombudsman.service.respondent.exception.MandatoryFieldException;
import com.ombudsman.service.respondent.exception.OrganizationNotFoundException;
import com.ombudsman.service.respondent.model.ApiResponse;
import com.ombudsman.service.respondent.model.IncidentInfo;
import com.ombudsman.service.respondent.model.SharedData;
import com.ombudsman.service.respondent.model.SharedDataItem;
import com.ombudsman.service.respondent.model.UpdateCase;
import com.ombudsman.service.respondent.model.UpdateCaseMessage;
import com.ombudsman.service.respondent.model.dto.UserEventConfiguration;
import com.ombudsman.service.respondent.model.request.BulkCaseUpdateRequest;
import com.ombudsman.service.respondent.model.request.BulkCaseUpdateRequest.NumberOfCases;
import com.ombudsman.service.respondent.model.request.CaseDetailsByIdReq;
import com.ombudsman.service.respondent.model.response.RespondentAdminIndividualIdRes;
import com.ombudsman.service.respondent.service.repository.UpdateRequestsRepository;
import com.ombudsman.service.respondent.service.repository.UserEventConfigurationRepository;

@ExtendWith(SpringExtension.class)
@TestPropertySource(properties = { "case_update_user_event_name=mockEventName" })
public class UpdateFileServiceTest {

	@InjectMocks
	UpdateFileService updateFileService;
	
	@Mock
	CaseDetailsByIdReq mMockCaseDetailsByIdReq;

	@Mock
	StaticUtils staticUtils;

	@Mock
	CommonUtil commonUtils;
	
	@Mock
	UserBean userbean;
	@Mock
	UpdateCase mMockdto;

	@Mock
	UpdateRequestsRepository updateRequestsRepository;
	
	@Mock
	UserEventConfigurationRepository userEventConfigurationRepository;

	@Mock
	WebClientData webClientData;
	@Mock
	private ObjectMapper objectMapper;
	@Mock
	RespondentAdminIndividualIdRes mMockRespondentAdminIndividualIdRes;

	@Mock
	UpdateCaseMessage mMockupdateCaseMessage;
	@Mock
	CaseActivityImpl caseActivityImpl;

	@Mock
	private MessageSource messageSource;
	@Mock
	IncidentInfo info;

	private static List<String> accountId = new ArrayList<>();
	private static List<String> groupIds = new ArrayList<>();

	@BeforeEach
	void setUp() {
		MockitoAnnotations.initMocks(this);
		groupIds.add("groupId1");
		groupIds.add("groupId2");
		Mockito.when(userbean.getGroups()).thenReturn(groupIds);
		accountId.add("accountId");
		accountId.add("accountId2");
		Mockito.when(mMockRespondentAdminIndividualIdRes.getContactId()).thenReturn("true");
		when(messageSource.getMessage("api.error.caseUpdatefailed", null, Locale.ENGLISH)).thenReturn("Error Occurred in Case Update API. Please Try Again.");


	}

	@DisplayName("getSharedConfiguration_Positive")
	@Test
	public void getSharedConfigurationTest() throws Exception {

		ApiResponse response = new ApiResponse();

		String callResponse = "{\"fore\" : \"mockFore\", \"documentCodes\" : [{\"name\" : \"doc\" , \"code\" : \"123\"}] , \"originatorCodes\" :[{\"name\" : \"orig\" , \"code\" : \"123\"}] , \"reasonForChangeCodes\" : [{\"name\" : \"orig\" , \"code\" : \"123\"}]}";
		String url = "http://Mock.com";

		SharedDataItem Item1 = new SharedDataItem();
		Item1.setCode("mock_code");
		Item1.setName("mock_name");
		SharedDataItem Item2 = new SharedDataItem();
		Item2.setCode("mock_code");
		Item2.setName("mock_name");

		List<SharedDataItem> lst = new ArrayList<SharedDataItem>();
		lst.add(Item1);
		lst.add(Item2);

		SharedData shareData = new SharedData();
		shareData.setFore("mockFore");
		shareData.setDocumentCodes(lst);
		shareData.setOriginatorCodes(lst);
		shareData.setReasonForChangeCodes(lst);

		List<SharedData> mockShareData = new ArrayList<SharedData>();
		mockShareData.add(shareData);

		Mockito.when(staticUtils.callGetApi(Mockito.any())).thenReturn("http://www.mock.com?mock=value");
		ObjectMapper mockObjectMapper = Mockito.mock(ObjectMapper.class);
		// List<SharedData> readValue = new ObjectMapper().readValue(callResponse,
		// List.class);
		// Mockito.when(new ObjectMapper().readValue("Callresponse", List.class
		// )).thenReturn(mockShareData);

		// response = updateFileService.getSharedConfiguration(url);

		// assertEquals("success",response.getMessage());
		// assertEquals(200,response.getStatus());

	}

	// Passed
	@DisplayName("getSharedConfigurationTest_When_Call_Reponse_null")
	@Test
	public void getSharedConfigurationTest_reponseNull() throws Exception {
		ApiResponse response = new ApiResponse();
		String callResponse = null;
		String url = "http://Mock.com";

		Mockito.when(staticUtils.callGetApi(url)).thenReturn(callResponse);
		response = updateFileService.getSharedConfiguration(url);
		assertNotNull(response);
		assertEquals("Getting URL from APIM failed", response.getMessage());
		// assertEquals(200,response.getStatus());

	}

	// Passed
	@DisplayName("getSharedConfigurationTest_Exception")
	@Test
	public void getSharedConfigurationTest_Exception() throws Exception {
		ApiResponse response = new ApiResponse();
		String callResponse = "{\"fore\" : \"mockFore\", \"documentCodes\" : [{\"name\" : \"doc\" , \"code\" : \"123\"}] , \"originatorCodes\" :[{\"name\" : \"orig\" , \"code\" : \"123\"}] , \"reasonForChangeCodes\" : [{\"name\" : \"orig\" , \"code\" : \"123\"}]}";
		String url = "http://Mock.com";

		Mockito.when(staticUtils.callGetApi(url)).thenThrow();

		response = updateFileService.getSharedConfiguration(url);
		assertNotNull(response);
		assertEquals("Error occurred in getSharedConfiguration Method ", response.getMessage());
		// assertEquals(200,response.getStatus());

	}

//	@DisplayName("updateCase_Positive")
//	@Test
//	public void updateCase_Positive() {
//
//		UpdateCase dto = new UpdateCase();
//		dto.setCaseId("Case1");
//		dto.setComments("Mock comments");
//		dto.setDetails("Mock details");
//		dto.setReasonForChange(1L);
//
//		List<String> acc = new ArrayList<String>();
//		acc.add("Acc1");
//		acc.add("Acc2");
//
//		ApiResponse response = new ApiResponse();
//		response = null;
//
//		Mockito.when(updateFileService.getAccountIds("oid"))
//				.thenReturn(Lists.newArrayList("account1", "account2"));
//		Mockito.when(updateRequestsRepository.getIncident(Mockito.any(), Mockito.any())).thenReturn(info);
//
//		response = updateFileService.updateCase(dto);
//
//		assertNotNull(response);
//		// assertEquals(response.getStatus(),HttpStatus.OK);
//
//	}
	
	@Test
	public void bulkupdateCase() throws JsonProcessingException, OrganizationNotFoundException, MandatoryFieldException {

		BulkCaseUpdateRequest dto = new BulkCaseUpdateRequest();
		dto.setPackageIdReq("pck123");
		dto.setDetails("Mock details");
		dto.setReasonForChange(14000L);
		
		NumberOfCases caseAndCom = new NumberOfCases();
		caseAndCom.setCaseId("12");
		caseAndCom.setComment("Comment1");
		
		List<NumberOfCases> acc = new ArrayList<NumberOfCases>();
		acc.add(caseAndCom);

		dto.setNumberOfCases(acc);
		ApiResponse response = new ApiResponse();
		response = null;
		UserEventConfiguration eventName = new UserEventConfiguration();
		eventName.setUserEventName("MockValue");
		Mockito.when(userEventConfigurationRepository.getUserEventRecord(updateFileService.userEventName)).thenReturn(eventName);
		
		response = updateFileService.bulkupdateCase(dto);

		assertNotNull(response);
		// assertEquals(response.getStatus(),HttpStatus.OK);

	}

//	@DisplayName("updateCase_Negative")
//	@Test
//	public void updateCase_Negative() {
//
//		UpdateCase dto = new UpdateCase();
//		dto.setCaseId("Case1");
//		dto.setComments("Mock comments");
//		dto.setDetails("Mock details");
//		dto.setReasonForChange(1L);
//
//		List<String> acc = new ArrayList<String>();
//		acc.add("Acc1");
//		acc.add("Acc2");
//
//		ApiResponse response = new ApiResponse();
//		response = null;
//
//		Mockito.when(updateFileService.getAccountIds("oid"))
//				.thenReturn(Lists.newArrayList("account1", "account2"));
//		Mockito.when(updateRequestsRepository.getIncident(Mockito.any(), Mockito.any())).thenReturn(info);
//
//		response = updateFileService.updateCase(dto);
//
//		assertNotNull(response);
//		assertEquals(response.getStatus(), HttpStatus.UNAUTHORIZED);
//
//	}

//	@DisplayName("updateCase_Exception")
//	@Test
//	public void updateCase_Exception() {
//
//		UpdateCase dto = new UpdateCase();
//		ApiResponse response = new ApiResponse();
//		response = null;
//
//		Mockito.when(updateFileService.getAccountIds("oid")).thenReturn(Lists.newArrayList("account1", "account2"));
//		Mockito.when(updateRequestsRepository.getIncident(Mockito.any(), Mockito.any())).thenReturn(info);
//		try {
//			response = updateFileService.updateCase(dto);
//		} catch (CaseUpdateException ex) {
//			assertNull(response);
//		}
//
//	}
//
//	@DisplayName("updateCase_AccountIdNull")
//	@Test
//	public void updateCase_AccountIdNull() {
//		UpdateCase dto = new UpdateCase();
//		dto.setPackageId("PckId");
//		dto.setContactId("ContactId");
//		dto.setDetails("casedetails");
//		dto.setDigitalPortalUserEmailAddress("Dpadmin");
//		dto.setIsRespondent("true");
//		dto.setDigitalPortalUserName("Dpusername");
//		dto.setCaseId("Case1");
//		dto.setComments("Mock comments");
//		dto.setDetails("Mock details");
//		dto.setReasonForChange(1L);
//		List<String> acc = new ArrayList<String>();
//		acc.add("Acc1");
//		acc.add("Acc2");
//		ApiResponse response = new ApiResponse();
//		response = null;
//
//		Mockito.when(updateFileService.getAccountIds("oid")).thenReturn(Lists.newArrayList());
//		Mockito.when(updateRequestsRepository.getIncident(Mockito.any(), Mockito.any())).thenReturn(info);
//		response = updateFileService.updateCase(dto);
//		assertNotNull(response);
//		assertEquals(response.getStatus(), HttpStatus.UNAUTHORIZED);
//
//	}
//
//	@DisplayName("updateCase_dtoIDEmpty")
//	@Test
//	public void updateCase_dtoIDEmpty() {
//		UpdateCase dto = new UpdateCase();
//		dto.setCaseId("");
//		dto.setComments("Mock comments");
//		dto.setDetails("Mock details");
//		dto.setReasonForChange(1L);
//		List<String> acc = new ArrayList<String>();
//		acc.add("Acc1");
//		acc.add("Acc2");
//		ApiResponse response = new ApiResponse();
//		response = null;
//
//		Mockito.when(updateFileService.getAccountIds("oid"))
//				.thenReturn(Lists.newArrayList("account1", "account2"));
//		Mockito.when(updateRequestsRepository.getIncident(Mockito.any(), Mockito.any())).thenReturn(info);
//		response = updateFileService.updateCase(dto);
//		assertNotNull(response);
//		assertEquals(response.isSuccess(), false);
//	}
//
//	@DisplayName("ErrorInupdateCaseAPI_Failed")
//	@Test
//	public void ErrorInupdateCaseAPIFailed() throws JsonMappingException, JsonProcessingException {
//
//		mMockdto.setCaseId("PNX-123");
//		mMockdto.setComments("Mock comments");
//		mMockdto.setDetails("Mock details");
//		mMockdto.setReasonForChange(1L);
//		List<String> acc = new ArrayList<String>();
//		acc.add("Acc1");
//		acc.add("Acc2");
//		ApiResponse response = new ApiResponse();
//		response = null;
//		List<SharedData> sharedData = new ArrayList<>();
//		sharedData.add(new SharedData());
//		ObjectMapper mapper = Mockito.mock(ObjectMapper.class);
//		String callResponse = null;
//		Mockito.when(mapper.readValue(callResponse, List.class)).thenReturn(sharedData);
//		Mockito.when(updateFileService.getAccountIds("oid"))
//				.thenReturn(Lists.newArrayList("account1", "account2"));
//		Mockito.when(caseActivityImpl.activity(mMockdto,info.getTicketnumber())).thenReturn(callResponse);
//		Mockito.when(updateRequestsRepository.getIncident(Mockito.any(), Mockito.any())).thenReturn(info);
//		Mockito.when(info.getIncidentid()).thenReturn(1);
//		Mockito.when(mMockdto.getCaseId()).thenReturn("PNX-123");
////		Mockito.when(mMockRespondentAdminIndividualIdRes.getIsAdminUser()).thenReturn("true");
//		mMockRespondentAdminIndividualIdRes.setIsAdminUser("true");
////		mMockRespondentAdminIndividualIdRes.setContactId("true");
//		Mockito.when(webClientData.individualidWebclient(mMockCaseDetailsByIdReq)).thenReturn(mMockRespondentAdminIndividualIdRes);
//
//		try {
//		response = updateFileService.updateCase(mMockdto);
//
//		}catch (Exception e) {
//			assertEquals("Error Occurred in Case Update API. Please Try Again.",e.getMessage());
//		}
//	}

}
