package com.ombudsman.service.communication.controller;

import java.io.IOException;
import java.text.ParseException;
import java.time.LocalDateTime;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.ombudsman.service.communication.common.CommonUtil;
import com.ombudsman.service.communication.common.KeyVaultConfiguration;
import com.ombudsman.service.communication.common.UserBean;
import com.ombudsman.service.communication.common.ValidateUserSession;
import com.ombudsman.service.communication.exception.UnAuthorisedException;
import com.ombudsman.service.communication.model.request.SinchApiRequest;
import com.ombudsman.service.communication.model.request.UserRequestBody;
import com.ombudsman.service.communication.model.response.EmailNotificationResponse;
import com.ombudsman.service.communication.model.response.GenericResponse;
import com.ombudsman.service.communication.model.response.GetZenDeskJwtToken;
import com.ombudsman.service.communication.model.response.GetZenDeskUrlWebForm;
import com.ombudsman.service.communication.serviceimpl.CommunicationServiceImpl;

import jakarta.validation.Valid;

@RestController
public class CommunicationServiceController {

	Logger LOG = LogManager.getRootLogger();

	@Autowired
	CommunicationServiceImpl sendEmailService;

	static final String SEESIONMNGMTLOG = "Session management API respnse status:: {} ";

	@Autowired
	UserBean userbean;
	
	@Autowired
	private KeyVaultConfiguration keyVaultConfiguration;

	@Autowired
	CommonUtil commonUtil;
	
	@Autowired
	ValidateUserSession validateUserSession;

	
	
	@PostMapping(path = "/compcommunicationservice/v1/communicationservice/sendinviteemail")
	public ResponseEntity<EmailNotificationResponse> sendInviteEmail(@Valid @RequestBody UserRequestBody request)
			throws Exception {

 		LOG.info("SendInviteEmail Method Started.CorrelationId:-{} OID:-{}", userbean.getCorrelationId(),
				userbean.getUserObjectId());

		EmailNotificationResponse result = new EmailNotificationResponse();
		if (validateUserSession.isValidSession()) {
			result = sendEmailService.sendInviteEmail(request);
	
			LOG.info("SendInviteEmail Method ended.CorrelationId:-{} OID:-{}", userbean.getCorrelationId(),
					userbean.getUserObjectId());
	
			return new ResponseEntity<>(result, HttpStatus.OK);
		}
		return new ResponseEntity<>(result, HttpStatus.UNAUTHORIZED);

	}
	
	@PostMapping(path = "/compcommunicationservice/v1/communicationservice/sendemailtoUser")
	public ResponseEntity<EmailNotificationResponse> sendEmailtoUser(@Valid @RequestBody UserRequestBody request)
			throws Exception {

 		LOG.info("SendInviteEmail Method Started.CorrelationId:-{} OID:-{}", userbean.getCorrelationId(),
				userbean.getUserObjectId());

		EmailNotificationResponse result = new EmailNotificationResponse();
		if (keyVaultConfiguration.xApiKey != null
				&& keyVaultConfiguration.xApiKey.equalsIgnoreCase(userbean.getApiKey())) {
			result = sendEmailService.sendInviteEmail(request);
	
			LOG.info("SendInviteEmail Method ended.CorrelationId:-{} OID:-{}", userbean.getCorrelationId(),
					userbean.getUserObjectId());
	
			return new ResponseEntity<>(result, HttpStatus.OK);
		}
		return new ResponseEntity<>(result, HttpStatus.UNAUTHORIZED);

	}
	
	@PostMapping(path = "/compcommunicationservice/v1/communicationservice/sendsms")
	public ResponseEntity<EmailNotificationResponse> sendSMSController(@Valid @RequestBody SinchApiRequest smsRequest)
			throws Exception {

 		LOG.info("Send SMS controller Method Started.CorrelationId:-{} OID:-{}", userbean.getCorrelationId(),
				userbean.getUserObjectId());

 		EmailNotificationResponse result = new EmailNotificationResponse();
 		if (keyVaultConfiguration.xApiKey != null
				&& keyVaultConfiguration.xApiKey.equalsIgnoreCase(userbean.getApiKey())) {
		
			result = sendEmailService.sendSms(smsRequest);
	
			LOG.info("Send SMS controller Method ended.CorrelationId:-{} OID:-{}", userbean.getCorrelationId(),
					userbean.getUserObjectId());
 		
			return new ResponseEntity<>(result, result.getHttpStatus());
 		}
	
 			return new ResponseEntity<>(result, HttpStatus.UNAUTHORIZED);

	}

	
	@GetMapping(value = "/compcommunicationservice/v1/communicationservice/getzendeskjwttoken")
	public ResponseEntity<GetZenDeskJwtToken> getZenDeskJwtToken() throws IOException, UnAuthorisedException {
		LOG.info("getJwtToken Controller Method Started.CorrelationId:-{} OID:-{}", userbean.getCorrelationId(),
				userbean.getUserObjectId());

		GetZenDeskJwtToken result = new GetZenDeskJwtToken();
			if (validateUserSession.isValidSession()) {
			String token = commonUtil.getZendeskJwtToken();
			result.setJwttoken(token);
	
			LOG.info("getJwtToken Controller Method Ended.CorrelationId:-{} OID:-{}", userbean.getCorrelationId(),
					userbean.getUserObjectId());
			return new ResponseEntity<>(result, HttpStatus.OK);
		}
	return new ResponseEntity<>(result, HttpStatus.UNAUTHORIZED);

	}

	
	@GetMapping(value = "/compcommunicationservice/v1/communicationservice/getzendeskurlwebform")
	public ResponseEntity<GetZenDeskUrlWebForm> getZenDeskUrlWebForm()
			throws JSONException, ParseException, IOException, UnAuthorisedException {
		LOG.info("getZenDeskUrlWebForm Controller Method Started.CorrelationId:-{} OID:-{}",
				userbean.getCorrelationId(), userbean.getUserObjectId());
		GetZenDeskUrlWebForm result = new GetZenDeskUrlWebForm();
		if (validateUserSession.isValidSession()) {
			result  = commonUtil.getZendeskUrlWebForm();

			LOG.info("getZenDeskUrlWebForm Controller Method Ended.CorrelationId:-{} OID:-{}", userbean.getCorrelationId(),
					userbean.getUserObjectId());
			return new ResponseEntity<>(result, HttpStatus.OK);
	}
		return new ResponseEntity<>(result, HttpStatus.UNAUTHORIZED);
	}
	
	@GetMapping(value = "/ombudsmanservice/v1/healthcheck")
	public ResponseEntity<GenericResponse> getHealthCheck() {
		final GenericResponse result = new GenericResponse();
		result.setMessage(LocalDateTime.now().toString());
		result.setStatus("Available");
		return new ResponseEntity<>(result, HttpStatus.OK);
	}
	
	@GetMapping(value = "/compcommunicationservice/v1/communicationservice/liveness")
	public ResponseEntity<GenericResponse> getLiveHealthCheck() {
		final GenericResponse result = new GenericResponse();
		result.setMessage(LocalDateTime.now().toString());
		LOG.info(String.format("liveness started with current time: %s", LocalDateTime.now()));		
		result.setStatus("Available");
		return new ResponseEntity<>(result, HttpStatus.OK);
	}
	@GetMapping(value = "/compcommunicationservice/v1/communicationservice/readiness")
	public ResponseEntity<GenericResponse> getRedinessHealthCheck() {
		final GenericResponse result = new GenericResponse();
		result.setMessage(LocalDateTime.now().toString());
		LOG.info(String.format("readiness started with current time: %s", LocalDateTime.now()));	
		result.setStatus("Available");
		return new ResponseEntity<>(result, HttpStatus.OK);
	}

}
