package com.ombudsman.service.communication.model.request;

import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonProperty;


public class MailjetRequest {
	
	@JsonProperty("Messages")
	private List<Message> Messages;
	
	
	
	public List<Message> getMessages() {
		return Messages;
	}


	public void setMessages(List<Message> messages) {
		this.Messages = messages;
	}

	public static class Message{
	
	@JsonProperty("From")
	private EmailAddress From; //Write OBJ before objects name

	@JsonProperty("To")
	private List<EmailAddress> To;

	@JsonProperty("TemplateID")
	int TemplateID;
	
	@JsonProperty("TemplateName")
	String TemplateName;

	@JsonProperty("TemplateLanguage")
	boolean TemplateLanguage;

	@JsonProperty("Variables")
	private Map<String,Object> Variables;


	public String getTemplateName() {
		return TemplateName;
	}

	public void setTemplateName(String templateName) {
		this.TemplateName = templateName;
	}

	public EmailAddress getFrom() {
		return From;
	}

	public void setFrom(EmailAddress from) {
		this.From = from;
	}

	public List<EmailAddress> getTo() {
		return To;
	}

	public void setTo(List<EmailAddress> to) {
		this.To = to;
	}

	public int getTemplateID() {
		return TemplateID;
	}

	public void setTemplateID(int templateID) {
		this.TemplateID = templateID;
	}

	public boolean isTemplateLanguage() {
		return TemplateLanguage;
	}

	public void setTemplateLanguage(boolean templateLanguage) {
		this.TemplateLanguage = templateLanguage;
	}

	public Map<String, Object> getVariables() {
		return Variables;
	}

	public void setVariables(Map<String, Object> variables) {
		this.Variables = variables;
	}
	
	
	}
	
	public static class EmailAddress {
		@JsonProperty("Email")
		private String Email;
		
		@JsonProperty("Name")
		private String Name;

		public String getEmail() {
			return Email;
		}

		public void setEmail(String email) {
			this.Email = email;
		}

		public String getName() {
			return Name;
		}

		public void setName(String name) {
			this.Name = name;
		}
		
		
	}
}