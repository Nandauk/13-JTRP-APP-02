package com.ombudsman.service.communication.common;

import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.context.annotation.RequestScope;

import com.ombudsman.service.communication.model.request.UserProfileReq;
 
@Configuration
@RequestScope
public class UserBean extends UserProfileReq {
	private String userObjectId;
	private String authToken;
	private String correlationId;
	private String name;
	private List<String> roles;
	private long exp;
	private List<String> groups;
	private String apiKey;

	public String getApiKey() {
		return apiKey;
	}
	public void setApiKey(String apiKey) {
		this.apiKey = apiKey;
	}


	public List<String> getRoles() {
		return roles;
	}
 
	public void setRoles(List<String> roles) {
		this.roles = roles;
	}
	public List<String> getGroups() {
		return groups;
	}
 
	public void setGroups(final List<String> groups) {
		this.groups = groups;
	}
 
	@Value("${spring.security.oauth2.client.provider.azure-b2c.jwk-set-uri}")
	private String jwkUri;
 
	public String getUserObjectId() {
		return userObjectId;
	}
 
	public void setUserObjectId(String userObjectId) {
		this.userObjectId = userObjectId;
	}
 
	public String getAuthToken() {
		return authToken;
	}
 
	public void setAuthToken(String authToken) {
		this.authToken = authToken;
	}
 
	public String getCorrelationId() {
		return correlationId;
	}
 
	public void setCorrelationId(String correlationId) {
		this.correlationId = correlationId;
	}
 
	public String getName() {
		return name;
	}
 
	public void setName(String name) {
		this.name = name;
	}
 
	public long getExp() {
		return exp;
	}
 
	public void setExp(long exp) {
		this.exp = exp;
	}
 
	public String getJwkUri()
	{
		return jwkUri;
	}
}