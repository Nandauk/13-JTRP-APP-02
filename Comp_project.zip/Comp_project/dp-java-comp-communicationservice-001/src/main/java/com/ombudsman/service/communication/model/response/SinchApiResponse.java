package com.ombudsman.service.communication.model.response;

import java.util.List;

public class SinchApiResponse {
	
	private String id;
	private List<String> to;
	private String from;
	private boolean canceled;
	private String body;
	private String type;
	private String created_at;
	private String modified_at;
	private String delivery_report;
	private String expire_at;
	private boolean flash_message;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public List<String> getTo() {
		return to;
	}
	public void setTo(List<String> to) {
		this.to = to;
	}
	public String getFrom() {
		return from;
	}
	public void setFrom(String from) {
		this.from = from;
	}
	public boolean isCanceled() {
		return canceled;
	}
	public void setCanceled(boolean canceled) {
		this.canceled = canceled;
	}
	public String getBody() {
		return body;
	}
	public void setBody(String body) {
		this.body = body;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getCreated_at() {
		return created_at;
	}
	public void setCreated_at(String created_at) {
		this.created_at = created_at;
	}
	public String getModified_at() {
		return modified_at;
	}
	public void setModified_at(String modified_at) {
		this.modified_at = modified_at;
	}
	public String getDelivery_report() {
		return delivery_report;
	}
	public void setDelivery_report(String delivery_report) {
		this.delivery_report = delivery_report;
	}
	public String getExpire_at() {
		return expire_at;
	}
	public void setExpire_at(String expire_at) {
		this.expire_at = expire_at;
	}
	public boolean isFlash_message() {
		return flash_message;
	}
	public void setFlash_message(boolean flash_message) {
		this.flash_message = flash_message;
	}
	
	

}
