package com.ombudsman.service.communication.service;

import com.ombudsman.service.communication.model.response.GenericResponse;

public interface ILoginService {	
	GenericResponse getSessionTokenStatus() throws Exception;

}
