package com.ombudsman.service.communication.serviceimpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.ombudsman.service.communication.common.CommonUtil;
import com.ombudsman.service.communication.exception.InputValidationException;
import com.ombudsman.service.communication.model.request.MailjetRequest;
import com.ombudsman.service.communication.model.request.MailjetRequest.EmailAddress;
import com.ombudsman.service.communication.model.request.MailjetRequest.Message;
import com.ombudsman.service.communication.model.request.UserRequestBody;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

@Service
public class RequestBodyHelper {

	@Autowired
	CommonUtil commonUtil;
	
	private static final String REQUEST_INVALID = "Request Body format is incorrect!!";
	
	Logger LOG = LogManager.getRootLogger();
	private static final boolean TRUE = true;
	
	public MailjetRequest contructSendEmailBody(UserRequestBody inviteRequest){
		LOG.info("contructSendEmailBody method started ");
		
		if(!validateInviteRequest(inviteRequest)) 
			throw new InputValidationException(REQUEST_INVALID, "COMPLAINANT_USER_1000", null, null);
		MailjetRequest mailjetRequest = new MailjetRequest();
		
		EmailAddress toEmailAddress = new EmailAddress(); 
		toEmailAddress.setEmail(inviteRequest.getEmailId());
		toEmailAddress.setName(inviteRequest.getFullName());
		List<EmailAddress> to = new ArrayList<>(); 
		to.add(toEmailAddress);
		
		Message message = new Message();
		message.setTemplateID(inviteRequest.getTemplateID());
		message.setTemplateName(inviteRequest.getTemplateName());  
		LOG.info("-----TemplateID and templateName set Inside helper method successfully----");
		message.setTemplateLanguage(TRUE);
		message.setTo(to);
		
		EmailAddress fromEmailAddress = new EmailAddress();
		fromEmailAddress.setEmail(commonUtil.MAILJET_FROM_EMAIL);
		fromEmailAddress.setName(commonUtil.MAILJET_SERVER_NAME);
		message.setFrom(fromEmailAddress);

		message.setVariables(inviteRequest.getVariables());
		
		List<Message> sendmessage = new ArrayList<>();
		sendmessage.add(message);
		mailjetRequest.setMessages(sendmessage);
		
		LOG.info("contructSendEmailBody method ended ");
		return mailjetRequest;
			
	}
	
public boolean validateInviteRequest(UserRequestBody inviteRequest) {
//	&& commonUtil.isValidWithCharAndNumberInput(StringUtils.trim(inviteRequest.getFullName())) 

		return (commonUtil.isValidEmailInput(inviteRequest.getEmailId())
				&& commonUtil.isValidNumeric(String.valueOf(inviteRequest.getTemplateID()))
				&& commonUtil.isValidNameInput(inviteRequest.getTemplateName()));	
	
    }

}
	
