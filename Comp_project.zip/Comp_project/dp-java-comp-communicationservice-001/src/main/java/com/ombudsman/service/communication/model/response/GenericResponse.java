package com.ombudsman.service.communication.model.response;

import java.io.Serializable;

public class GenericResponse implements Serializable{

	private static final long serialVersionUID = 1L;
	String status;
	String message;
	
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	
}