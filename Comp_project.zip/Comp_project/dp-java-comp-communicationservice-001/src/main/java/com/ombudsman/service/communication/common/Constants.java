package com.ombudsman.service.communication.common;

public class Constants {
	
	public static final String MSG_FAILURE="Failure";
	public static final String MSG_SUCCESS="Success";
	public static final String VALID = "valid";
	
	private Constants() {
	      //not called
	   }
	

}
