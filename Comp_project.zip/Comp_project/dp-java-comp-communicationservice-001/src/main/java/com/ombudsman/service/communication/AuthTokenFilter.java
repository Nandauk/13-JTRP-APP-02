package com.ombudsman.service.communication;

import java.io.IOException;
import java.net.URL;
import java.security.interfaces.RSAPublicKey;
import java.util.concurrent.TimeUnit;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.util.StringUtils;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;
import org.springframework.web.filter.OncePerRequestFilter;

import com.auth0.jwk.Jwk;
import com.auth0.jwk.JwkProvider;
import com.auth0.jwk.UrlJwkProvider;
import com.auth0.jwt.JWT;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.interfaces.DecodedJWT;
import com.auth0.jwt.interfaces.JWTVerifier;
import com.google.common.cache.Cache;
import com.google.common.cache.CacheBuilder;
import com.ombudsman.service.communication.common.UserBean;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletContext;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebFilter;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;


@WebFilter(filterName = "AuthTokenFilter", urlPatterns = { "/compcommunicationservice/*" })
public class AuthTokenFilter extends OncePerRequestFilter {

	@Autowired
	UserBean userbean;
	
	final Logger LOG = LogManager.getRootLogger();
	private static final String API_KEY_HEADER = "X-API-KEY";
	private static final String JWK_CACHE = "jwkCacheCaseCommunication";
	
	private static Cache<String, Jwk> jwkCache = CacheBuilder.newBuilder().maximumSize(1).expireAfterAccess(14, TimeUnit.HOURS).build();
 
	public void put(String key, Jwk value) {
		jwkCache.put(key, value);
	}
 
	public Jwk get(String key) {
        return jwkCache.getIfPresent(key);
    }
 
	public void invalidate(String key) {
		jwkCache.invalidate(key);
	}
	
	

	@Override
	protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
			throws ServletException, IOException {

		String apiKey = request.getHeader(API_KEY_HEADER);
		LOG.info(String.format("api type:: %s ", apiKey));
	
		ServletContext servletContext = request.getServletContext();
		WebApplicationContext webApplicationContext = WebApplicationContextUtils
				.getWebApplicationContext(servletContext);
		if (webApplicationContext != null) {			
			userbean = webApplicationContext.getBean(UserBean.class);			
		}
		if (null != apiKey) {			
			userbean.setApiKey(apiKey);			
			filterChain.doFilter(request, response);
		}

		else {
			final String requestTokenHeader = request.getHeader("Authorization");
			
			final String correlationId = request.getHeader("Correlation-Id");
			if (!StringUtils.hasText(requestTokenHeader)) {
				filterChain.doFilter(request, response);
				return;
			}
			String jwtToken = null;
			Jwk jwk = null;
			
			userbean.setCorrelationId(correlationId);

			LOG.debug("AuthTokenFilter class started.CorrelationId:-{} OID:-{}", userbean.getCorrelationId(),
					userbean.getUserObjectId());
			if (requestTokenHeader.startsWith("Bearer ")) {
				jwtToken = requestTokenHeader.substring(7);
				try {
					DecodedJWT jwt = JWT.decode(jwtToken);

					LOG.info(String.format("JWK_CACHE:%s",get(JWK_CACHE)));
					
					if (null == get(JWK_CACHE)) {

						JwkProvider provider = new UrlJwkProvider(new URL(userbean.getJwkUri()));

						jwk = provider.get(jwt.getKeyId());

						jwkCache.put(JWK_CACHE, jwk);

	 
					} else {

						jwk = get(JWK_CACHE);

					}
					
					//JwkProvider provider = new UrlJwkProvider(new URL(userbean.getJwkUri()));

					//Jwk jwk = provider.get(jwt.getKeyId());

					Algorithm algorithm = Algorithm.RSA256((RSAPublicKey) jwk.getPublicKey(), null);

					JWTVerifier verifier = JWT.require(algorithm).build();

					verifier.verify(jwtToken);

					String oid = jwt.getClaim("oid").asString();
					String email = jwt.getClaim("email").asString();
					
					long exp = jwt.getExpiresAt().getTime();
					String name = jwt.getClaim("name").asString();
					if (email != null && email.length() > 0) {
						LOG.debug("Email not null from token.CorrelationId:-{} OID:-{}", userbean.getCorrelationId(),
								userbean.getUserObjectId());

						userbean.setEmail(email);
					}
					//String tokenUti = jwt.getClaim("uti").asString();

					userbean.setUserObjectId(oid);
					userbean.setAuthToken(jwtToken);					
					userbean.setExp(exp);
					userbean.setName(name);
					LOG.debug("AuthTokenFilter class ended.Token Extracted Successfully.CorrelationId:-{} OID:-{}",
							userbean.getCorrelationId(), userbean.getUserObjectId());

					filterChain.doFilter(request, response);
				} catch (Exception e) {

					LOG.debug("Unable to Decode the JWT Token");
					response.sendError(HttpServletResponse.SC_UNAUTHORIZED, "Error: Unauthorized");
				}
			} else {
				LOG.debug("401:-JWT Token does not begin with Bearer String");

				response.sendError(HttpServletResponse.SC_UNAUTHORIZED, "Error: Unauthorized");
			}
		}

	}

	@Bean
	public UserBean userBean() {
		return new UserBean();
	}

}