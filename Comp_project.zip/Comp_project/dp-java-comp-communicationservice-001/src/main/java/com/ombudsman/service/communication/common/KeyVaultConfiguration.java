package com.ombudsman.service.communication.common;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;

@Configuration
@Component
public class KeyVaultConfiguration {


	@Value("${ExternalApiCompAPIkey}")      
    public String xApiKey;
	@Value("${zenDeskId}") 
	String zenDeskId;
	@Value("${zenDeskSecretKeyChatWizard}")
	String zenDeskSecretKeyChatWizard;
	@Value("${zenDeskSecretKeyWebForm}") 
	String zenDeskSecretKeyWebForm;
	@Value("${zendesk-subdomain-complainant}")
	String zendeskSubDomain;
	@Value("${zendesk-subdomain-jwt}")
	String zendeskSubDomainJwt;	

	
}
