package com.ombudsman.service.communication.serviceimpl;

import java.io.UnsupportedEncodingException;
import java.text.ParseException;
import java.time.OffsetDateTime;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.WebClient;

import com.google.gson.Gson;
import com.ombudsman.service.communication.common.CommonUtil;
import com.ombudsman.service.communication.common.UserBean;
import com.ombudsman.service.communication.exception.MailJetServiceException;
import com.ombudsman.service.communication.exception.SinchServiceException;
import com.ombudsman.service.communication.model.dto.AuditMaster;
import com.ombudsman.service.communication.model.request.MailjetRequest;
import com.ombudsman.service.communication.model.request.SinchApiRequest;
import com.ombudsman.service.communication.model.request.UserRequestBody;
import com.ombudsman.service.communication.model.response.EmailNotificationResponse;
import com.ombudsman.service.communication.model.response.MailjetResponseBody;
import com.ombudsman.service.communication.model.response.SinchApiResponse;
import com.ombudsman.service.communication.service.AuditRepository;
import com.ombudsman.service.communication.service.CommunicationService;

import jakarta.validation.Valid;
import reactor.core.publisher.Mono;

@Service
public class CommunicationServiceImpl implements CommunicationService {
	
	@Autowired
	CommonUtil commonUtil;
	
	@Autowired
	UserBean userbean;
	
	@Autowired
	AuditRepository audit;
	
	@Autowired
	RequestBodyHelper helper;
	
	private static String EMAIL_SEND = "Email Send";
	private static String SMS_SENT = "Sms Sent";
	private static String COM_SERVICE = "Communication Service";
	private static String NO_OID = "NoOid_WelcomeMail";
	private String statusOut ;
	private SinchApiResponse response;
	
	
	Logger LOG = LogManager.getRootLogger();

public EmailNotificationResponse sendInviteEmail(UserRequestBody req) throws UnsupportedEncodingException, JSONException, ParseException, MailJetServiceException {
		
		MailjetRequest mailjetRequest = helper.contructSendEmailBody(req);
		EmailNotificationResponse result = new EmailNotificationResponse();
		LOG.info("Mailjet Send request method started");
		Gson gson = new Gson();
		String jsonRquest = gson.toJson(mailjetRequest);
		MailjetResponseBody responseBody = new MailjetResponseBody() ;
		LOG.info("Requset data----{}" + jsonRquest);	
		
		try {
			responseBody = WebClient.create()
					  .post().uri(commonUtil.mailjetApimUrl)
					  .body(BodyInserters.fromValue(jsonRquest)).accept(MediaType.APPLICATION_JSON).retrieve().bodyToMono(MailjetResponseBody.class).block();
						

			String jsonResponse = gson.toJson(responseBody);
			LOG.info("Requset received after hitting mailjet API----{}" + jsonResponse);
			String userOid = userbean.getUserObjectId();
			if(userbean.getUserObjectId()==null) {
				userOid = NO_OID;
			}
			
			if(responseBody!=null) {
				
				String messageUUID = responseBody.getMessages().get(0).getTo().get(0).getMessageUUID();
				String templateName = mailjetRequest.getMessages().get(0).getTemplateName();
				OffsetDateTime offsetdatetime = OffsetDateTime.now();
				AuditMaster auditDetails = new AuditMaster();
				auditDetails.setUserOID(userOid);
				auditDetails.setAuditEventTimestamp(offsetdatetime);
				auditDetails.setAuditEventName(EMAIL_SEND);
				auditDetails.setPrimaryAuditEntityIdentifier(messageUUID);
				auditDetails.setPrimaryAuditEntity(templateName);
				auditDetails.setPreAuditSnapshot(jsonRquest);
				auditDetails.setPostAuditSnapshot(jsonResponse);
				auditDetails.setCreatedOn(offsetdatetime);
				auditDetails.setCreatedBy(COM_SERVICE);
				
				audit.save(auditDetails);
				
				LOG.info("Data saved in Audit table successfully");
				String status = responseBody.getMessages().get(0).getStatus();
				LOG.info("Status of response from Mailjet API : {}", status);
				statusOut=status;
				result.setMessage("Mail sent successfully");
				result.setStatus(status);
			}else {
				LOG.info("No response retrieved from Mailjet API : {}");
			}
			
		}catch(Exception ex) {
			result.setMessage("Mail could not be sent");
			result.setStatus(statusOut);
			LOG.error("Mailjet Webclient call failed " + ex);
			throw new MailJetServiceException("Mailjet Webclient call failed :");
	
		}
		
		return result;

	}


	@Override
	public EmailNotificationResponse sendSms(@Valid SinchApiRequest smsRequest) throws SinchServiceException {
		
		EmailNotificationResponse result = new EmailNotificationResponse();
//			String url = "https://EU.sms.api.sinch.com/xms/v1";
//			url +=String.format("/%s/batches", "FOS_2fa");
//			LOG.info("Full URL  : {}", url);
//			Mono<SinchApiResponse> responseMono =   WebClient.create().post().uri(url)
//					.header(HttpHeaders.AUTHORIZATION,"Bearer "+"02f17482e69749c8b49032a594117772")   
//					.header(HttpHeaders.CONTENT_TYPE,"application/json")
//					.bodyValue(smsRequest).retrieve().bodyToMono(SinchApiResponse.class);
		    smsRequest.setFrom(commonUtil.sinchFrom);
		    Gson gson = new Gson();	
			String jsonRquest = gson.toJson(smsRequest);
			LOG.info("Request received : {}", jsonRquest);

			LOG.info("Sinch apim URL  : {}", commonUtil.sinchUrl);
		
			try {
	
					
				 response = 	WebClient.create()
				  .post().uri(commonUtil.sinchUrl)
				  .bodyValue(smsRequest).accept(MediaType.APPLICATION_JSON).retrieve().bodyToMono(SinchApiResponse.class).block();
				  
				
				String jsonResponse = gson.toJson(response);
				
				LOG.info("Response received from Sinch is : {}", jsonResponse);
				
				if(response!=null && response.getId()!=null) {
				result.setStatus("Success");
				result.setMessage("SMS sent successfully");
				result.setHttpStatus(HttpStatus.OK);
				}

				
				//Adding response in Audit table
				if(response!=null) {
					
					OffsetDateTime offsetdatetime = OffsetDateTime.now();
					AuditMaster auditDetails = new AuditMaster();
					auditDetails.setUserOID("X-API-KEY used");
					auditDetails.setAuditEventTimestamp(offsetdatetime);
					auditDetails.setAuditEventName(SMS_SENT);
					auditDetails.setPrimaryAuditEntityIdentifier(response.getId());
					auditDetails.setPrimaryAuditEntity(response.getId());
					auditDetails.setPreAuditSnapshot(jsonRquest);
					auditDetails.setPostAuditSnapshot(jsonResponse);
					auditDetails.setCreatedOn(offsetdatetime);
					auditDetails.setCreatedBy(COM_SERVICE);
					
					audit.save(auditDetails);
					
					LOG.info("Data saved in Audit table successfully");
				}
			}catch(Exception e) {
				result.setMessage(e.getMessage());
				result.setStatus("Failed");
				result.setHttpStatus(HttpStatus.EXPECTATION_FAILED);
				LOG.error("SINCH sms api  call failed " + e.getMessage());
				throw new SinchServiceException(e.getMessage());
			}
				
				return result;

		
	}

}
