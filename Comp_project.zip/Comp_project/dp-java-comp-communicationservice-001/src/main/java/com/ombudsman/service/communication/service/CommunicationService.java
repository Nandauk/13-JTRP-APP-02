package com.ombudsman.service.communication.service;

import java.io.UnsupportedEncodingException;
import java.text.ParseException;

import org.json.JSONException;


import com.ombudsman.service.communication.exception.MailJetServiceException;
import com.ombudsman.service.communication.exception.SinchServiceException;
import com.ombudsman.service.communication.model.request.SinchApiRequest;
import com.ombudsman.service.communication.model.request.UserRequestBody;
import com.ombudsman.service.communication.model.response.EmailNotificationResponse;


import jakarta.validation.Valid;

public interface CommunicationService {
	
	public EmailNotificationResponse sendInviteEmail(@Valid UserRequestBody reqt) throws UnsupportedEncodingException, JSONException, ParseException, MailJetServiceException;

	public EmailNotificationResponse sendSms(@Valid SinchApiRequest smsRequest)throws SinchServiceException ;

}
