package com.ombudsman.service.communication.exception;

import java.time.LocalDateTime;
import java.util.Locale;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.HttpMediaTypeNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;
import org.springframework.web.servlet.NoHandlerFoundException;

import com.ombudsman.service.communication.common.UserBean;

import jakarta.validation.ConstraintViolationException;

@RestController
@ControllerAdvice
public class GobalExceptionHandler {

	private static final String API_ERROR_MESSAGENOTREADABLE = "api.error.messagenotreadable";



	private static final String API_ERROR_EXCEPTIONMSG = "api.error.exceptionmsg";



	private static final String COMPLAINANT_1002 = "COMPLAINANT_1002";



	private static final String ERROR_IN_OID_CUSTOM_ERROR_MESSAGE = "Error Code:- {} OID:-{} Error Description:-{} Stack Trace:-{} CorrelationId:-{}";



	@Autowired
	UserBean userbean;

	

	@Autowired
	private MessageSource messageSource;
	
	Logger LOG =  LogManager.getRootLogger();

	@ExceptionHandler({HttpMessageNotReadableException.class})
	public ResponseEntity<Object> handleHttpMessageNotReadableException(HttpMessageNotReadableException ex) {

		ApiError err = new ApiError(LocalDateTime.now(), HttpStatus.BAD_REQUEST,
				messageSource.getMessage(API_ERROR_MESSAGENOTREADABLE, null, Locale.ENGLISH) ,COMPLAINANT_1002);
		
		LOG.error(ERROR_IN_OID_CUSTOM_ERROR_MESSAGE, COMPLAINANT_1002,
				userbean.getUserObjectId(),ex.getMessage(),ex.getStackTrace(),userbean.getCorrelationId());

		return ResponseEntityBuilder.build(err);
	}

	// handleMethodArgumentsNotValid: triggers when @Valid fails

	@ExceptionHandler({MethodArgumentNotValidException.class})
	public ResponseEntity<Object> handleMethodArgumentNotValidException(MethodArgumentNotValidException ex) {


		String message = messageSource.getMessage(API_ERROR_EXCEPTIONMSG, null, Locale.ENGLISH);
		ApiError err = new ApiError(LocalDateTime.now(), HttpStatus.BAD_REQUEST, message,COMPLAINANT_1002
				);

		LOG.error(ERROR_IN_OID_CUSTOM_ERROR_MESSAGE, COMPLAINANT_1002,
				userbean.getUserObjectId(), ex.getMessage(),ex.getStackTrace(),userbean.getCorrelationId());

		return ResponseEntityBuilder.build(err);
	}

	// handleMissingServletRequestParameter: triggers when there are missing
	// parameters

	@ExceptionHandler({MissingServletRequestParameterException.class})
	public ResponseEntity<Object> handleMissingServletRequestParameterException(MissingServletRequestParameterException ex) {


		ApiError err = new ApiError(LocalDateTime.now(), HttpStatus.BAD_REQUEST, messageSource.getMessage(API_ERROR_MESSAGENOTREADABLE, null, Locale.ENGLISH),
				COMPLAINANT_1002);
		
		LOG.error(ERROR_IN_OID_CUSTOM_ERROR_MESSAGE, COMPLAINANT_1002,
				userbean.getUserObjectId(), ex.getMessage(),ex.getStackTrace(),userbean.getCorrelationId());

		
		return ResponseEntityBuilder.build(err);
	}

	// handleMethodArgumentsTypeMismatch: triggers when a parameter's type does not
	// match

	@ExceptionHandler({MethodArgumentTypeMismatchException.class})
	public ResponseEntity<Object> handleMethodArgumentTypeMismatchException(MethodArgumentTypeMismatchException ex) {


		String message = messageSource.getMessage(API_ERROR_EXCEPTIONMSG, null, Locale.ENGLISH);
		ApiError err = new ApiError(LocalDateTime.now(), HttpStatus.BAD_REQUEST,message, COMPLAINANT_1002
				);
		
		
		LOG.error(ERROR_IN_OID_CUSTOM_ERROR_MESSAGE, COMPLAINANT_1002,
				userbean.getUserObjectId(), ex.getMessage(),ex.getStackTrace(),userbean.getCorrelationId());

		
		return ResponseEntityBuilder.build(err);

	}

	
	@ExceptionHandler({InterruptedException.class})
	public ResponseEntity<Object> handleInterruptedException(InterruptedException ex) {

		String message = messageSource.getMessage(API_ERROR_EXCEPTIONMSG, null, Locale.ENGLISH);
		ApiError err = new ApiError(LocalDateTime.now(), HttpStatus.BAD_REQUEST,message, COMPLAINANT_1002
				);

		LOG.error(ERROR_IN_OID_CUSTOM_ERROR_MESSAGE, COMPLAINANT_1002,
				userbean.getUserObjectId(), ex.getMessage(),ex.getStackTrace(),userbean.getCorrelationId());

		
		return new ResponseEntity<>(err, HttpStatus.BAD_REQUEST);

	}

	// handleConstraintViolationException: triggers when @Validates fails
	
	@ExceptionHandler({ConstraintViolationException.class})
	public ResponseEntity<Object> handleConstraintViolationException(ConstraintViolationException ex) {


		String message = messageSource.getMessage(API_ERROR_EXCEPTIONMSG, null, Locale.ENGLISH);
		ApiError err = new ApiError(LocalDateTime.now(), HttpStatus.BAD_REQUEST,message, COMPLAINANT_1002
				);
		LOG.error(ERROR_IN_OID_CUSTOM_ERROR_MESSAGE, COMPLAINANT_1002,
				userbean.getUserObjectId(),ex.getMessage(),ex.getStackTrace(),userbean.getCorrelationId());
		return new ResponseEntity<>(err, HttpStatus.BAD_REQUEST);		

	}

	// handleResourceNotFoundException: triggers when there is not resource with the
	// specified ID in BDD
	
	@ExceptionHandler({ResourceNotFoundException.class})
	public ResponseEntity<Object> handleResourceNotFoundException(ResourceNotFoundException ex) {

		String message = messageSource.getMessage(API_ERROR_EXCEPTIONMSG, null, Locale.ENGLISH);
		ApiError err = new ApiError(LocalDateTime.now(), HttpStatus.NOT_FOUND,
				message, "COMPLAINANT_1004");
		
		LOG.error(ERROR_IN_OID_CUSTOM_ERROR_MESSAGE, COMPLAINANT_1002,
				userbean.getUserObjectId(), ex.getMessage(),ex.getStackTrace(),userbean.getCorrelationId());

		return new ResponseEntity<>(err, HttpStatus.NOT_FOUND);

	}

	// handleNoHandlerFoundException: triggers when the handler method is invalid
	
	@ExceptionHandler({NoHandlerFoundException.class})
	public ResponseEntity<Object> handleNoHandlerFoundException(NoHandlerFoundException ex) {


		ApiError err = new ApiError(LocalDateTime.now(), HttpStatus.BAD_REQUEST, "", null);
		
		LOG.error(ERROR_IN_OID_CUSTOM_ERROR_MESSAGE, COMPLAINANT_1002,
				userbean.getUserObjectId(), ex.getMessage(),ex.getStackTrace(),userbean.getCorrelationId());

		
		return ResponseEntityBuilder.build(err);

	}

	
	@ExceptionHandler({RespondentsServiceExceptions.class})
	public ResponseEntity<Object> handleRespondentsServiceExceptions(RespondentsServiceExceptions respondentsServiceExceptions) {

		ApiError err = new ApiError(LocalDateTime.now(), HttpStatus.BAD_REQUEST, null,null
				);

		LOG.error(ERROR_IN_OID_CUSTOM_ERROR_MESSAGE, respondentsServiceExceptions.getCode(),
				userbean.getUserObjectId(), respondentsServiceExceptions.getExceptionMessage(),respondentsServiceExceptions.getStackTrace(),userbean.getCorrelationId());

		
		return new ResponseEntity<>(err, HttpStatus.BAD_REQUEST);

	}
	
	
	@ExceptionHandler({InputValidationException.class})
	public ResponseEntity<ApiError> handleInputValidationException(InputValidationException ex) {

		ApiError err = new ApiError(LocalDateTime.now(), HttpStatus.BAD_REQUEST,null, null
				);
		LOG.error(ERROR_IN_OID_CUSTOM_ERROR_MESSAGE, ex.getLocalizedMessage(),
				userbean.getUserObjectId(), ex.getMessage(),ex.getStackTrace(),userbean.getCorrelationId());
		return new ResponseEntity<>(err, HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler({Exception.class})
	public ResponseEntity<ApiError> handleException(Exception ex) {

		String message = messageSource.getMessage(API_ERROR_EXCEPTIONMSG, null, Locale.ENGLISH);
		ApiError err = new ApiError(LocalDateTime.now(), HttpStatus.BAD_REQUEST,
				message,"COMPLAINANT_1004");
		
		LOG.error(ERROR_IN_OID_CUSTOM_ERROR_MESSAGE, "COMPLAINANT_1004",
				userbean.getUserObjectId(), ex.getMessage(),ex.getStackTrace(),userbean.getCorrelationId());
		
		return new ResponseEntity<>(err, HttpStatus.BAD_REQUEST);
	}
	
	@ExceptionHandler({MailJetServiceException.class})
	public ResponseEntity<ApiError> handleMailJetServiceException(MailJetServiceException ex){		
		LOG.info("SQLException complete errors::{}", ex.getMessage());
		ApiError err = new ApiError(LocalDateTime.now(), HttpStatus.INTERNAL_SERVER_ERROR, 
				HttpStatusCode.valueOf(HttpStatus.INTERNAL_SERVER_ERROR.value()).toString(),"COMPLAINANT_1004");
		return new ResponseEntity<>(err, HttpStatus.INTERNAL_SERVER_ERROR);
		
	}
	@ExceptionHandler({Throwable.class})
	public ResponseEntity<ApiError> handleThrowable(Throwable e) {

		ApiError err = new ApiError(LocalDateTime.now(), HttpStatus.INTERNAL_SERVER_ERROR,
				String.valueOf(HttpStatus.INTERNAL_SERVER_ERROR.value()), "COMPLAINANT_1004");
		LOG.info("Error while executing SP :: {}", e.getMessage());
		return new ResponseEntity<>(err, HttpStatus.INTERNAL_SERVER_ERROR);
	}
	@ExceptionHandler({SinchServiceException.class})
	public ResponseEntity<ApiError> handleSinchServiceException(SinchServiceException ex){
		
		
		ApiError err = new ApiError(LocalDateTime.now(), HttpStatus.BAD_GATEWAY,null,
				"COMPLAINANT_1004");

		LOG.error("Sinch external API exception occured", "COMPLAINANT_1004",
				userbean.getUserObjectId(), ex.getMessage(),ex.getStackTrace(),userbean.getCorrelationId());

		
		return new ResponseEntity<>(err, HttpStatus.INTERNAL_SERVER_ERROR);
	}


	
}
