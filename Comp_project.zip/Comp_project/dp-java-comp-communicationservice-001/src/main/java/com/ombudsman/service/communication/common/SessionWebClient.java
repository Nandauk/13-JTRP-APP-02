package com.ombudsman.service.communication.common;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.MediaType;
import org.springframework.web.reactive.function.client.WebClient;
import com.ombudsman.service.communication.model.response.GenericResponse;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

@Configuration
public class SessionWebClient {

	UserBean userbean;
	CommonUtil commonUtil;
	Logger log = LogManager.getRootLogger();
	
	private static String sessionApiUrl = "/compsessionmanagement/compsessionmanagement/v1/sessionservice/verifyUserSession";
	
	@Autowired
	public SessionWebClient(UserBean userbean, CommonUtil commonUtil) {
		super();
		this.userbean = userbean;
		this.commonUtil = commonUtil;
	}
	

	public GenericResponse getResponseForSessionActivity() {
		final String sessionApiBaseUrl = commonUtil.sessionBaseUrl;
		var response = new GenericResponse();
		try {
			response = WebClient.create().get().uri(sessionApiBaseUrl + sessionApiUrl).headers(httpHeaders -> {
			httpHeaders.set("Authorization", "Bearer " + userbean.getAuthToken());
		}).accept(MediaType.APPLICATION_JSON).retrieve().bodyToMono(GenericResponse.class).block();
	} catch (Exception e) {
		log.error("Exception occured while calling Session API: {} ", e.getMessage());
	}
	return response;
		
	}

}
