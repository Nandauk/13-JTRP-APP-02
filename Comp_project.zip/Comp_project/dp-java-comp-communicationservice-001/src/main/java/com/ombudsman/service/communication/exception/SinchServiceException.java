package com.ombudsman.service.communication.exception;

public class SinchServiceException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	

	public SinchServiceException(String message) {
		super(message);
	}
	
}
