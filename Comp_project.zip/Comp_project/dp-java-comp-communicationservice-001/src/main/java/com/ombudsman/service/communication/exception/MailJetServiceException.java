package com.ombudsman.service.communication.exception;

public class MailJetServiceException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	

	public MailJetServiceException(String message) {
		super(message);
	}
	
}
