package com.ombudsman.service.communication;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.oauth2.jose.jws.SignatureAlgorithm;
import org.springframework.security.oauth2.jwt.JwtDecoder;
import org.springframework.security.oauth2.jwt.NimbusJwtDecoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.www.BasicAuthenticationFilter;

@Configuration
@EnableWebSecurity
@EnableMethodSecurity
public class AadOAuth2ResourceServerSecurityConfig {
	
    @Value("${spring.security.oauth2.client.provider.azure-b2c.jwk-set-uri}")
    private String jwkSetUri;

    
    @Bean
    protected SecurityFilterChain configure(HttpSecurity http) throws Exception {
    	
    	
    	http.csrf(csrf -> csrf.ignoringRequestMatchers(  "/compcommunicationservice/v1/communicationservice/sendemailtoUser",
                "/compcommunicationservice/v1/communicationservice/sendsms","/compcommunicationservice/v1/communicationservice/liveness",
                "/compcommunicationservice/v1/communicationservice/readiness"))
				.authorizeHttpRequests(
						auth -> auth.requestMatchers(AUTH_WHITELIST).permitAll().requestMatchers("/**").authenticated())
	        .oauth2ResourceServer(oauth2->oauth2.jwt(jwt->jwt.decoder(jwtDecoder())));
	 
		  http.addFilterBefore(new AuthTokenFilter(), BasicAuthenticationFilter.class);
		
		return http.build();
    	
    	
	}

  
 
    @Bean
    public JwtDecoder jwtDecoder() {
        return NimbusJwtDecoder.withJwkSetUri(this.jwkSetUri).jwsAlgorithm(SignatureAlgorithm.RS256).build();
    }
    
//    @Bean
//	JwtDecoder jwtDecoder() {
//		NimbusJwtDecoder jwtDecoder = (NimbusJwtDecoder) JwtDecoders.fromIssuerLocation(jwkSetUri);
//
//		OAuth2TokenValidator<org.springframework.security.oauth2.jwt.Jwt> withIssuer = JwtValidators
//				.createDefaultWithIssuer(jwkSetUri);
//
//		OAuth2TokenValidator<org.springframework.security.oauth2.jwt.Jwt> withAudience = JwtValidators.createDefault();
//
//		OAuth2TokenValidator<org.springframework.security.oauth2.jwt.Jwt> validator = new DelegatingOAuth2TokenValidator<>(
//				withIssuer, withAudience);
//
//		jwtDecoder.setJwtValidator(validator);
//
//		return jwtDecoder;
//	}/compcommunicationservice/compcommunicationservice/v1/communicationservice/sendsms
    
    
    private static final String[] AUTH_WHITELIST = {
            // -- Swagger UI v2
            "/v2/api-docs",
            "/swagger-resources",
            "/swagger-resources/**",
            "/configuration/ui",
            "/configuration/security",
            "/swagger-ui.html",
            "/webjars/**",
            // -- Swagger UI v3 (OpenAPI)
            "/v3/api-docs/**",
            "/swagger-ui/**",
            "/compcommunicationservice/v1/communicationservice/sendemailtoUser",
            "/compcommunicationservice/v1/communicationservice/sendsms",
            "/compcommunicationservice/v1/communicationservice/liveness",
            "/compcommunicationservice/v1/communicationservice/readiness"
            // other public endpoints of your API may be appended to this array
           
    }; 
    
    @Bean
	public AuthTokenFilter authenticationJwtTokenFilter() {
		return new AuthTokenFilter();
	} 
    
    
    
    
}