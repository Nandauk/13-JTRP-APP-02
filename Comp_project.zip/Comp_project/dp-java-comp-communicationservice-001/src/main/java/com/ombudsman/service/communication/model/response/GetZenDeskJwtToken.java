package com.ombudsman.service.communication.model.response;

public class GetZenDeskJwtToken {
    private String jwttoken;

    public String getJwttoken() {
        return jwttoken;
    }

    public void setJwttoken(String jwttoken) {
        this.jwttoken = jwttoken;
    }
}
