package com.ombudsman.service.communication.model.request.test;

import static org.junit.jupiter.api.Assertions.*;

import java.time.OffsetDateTime;
import java.time.ZoneOffset;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.ombudsman.service.communication.model.dto.AuditMaster;

class AuditMasterTest {

    private AuditMaster auditMaster;
    private OffsetDateTime now;

    @BeforeEach
    void setUp() {
        auditMaster = new AuditMaster();
        now = OffsetDateTime.now(ZoneOffset.UTC);
    }

    @Test
    void testGetSetComplainantAuditRecordId() {
        Integer expectedId = 123;
        auditMaster.setComplainant_audit_record_id(expectedId);
        Integer actualId = auditMaster.getComplainant_audit_record_id();
        assertEquals(expectedId, actualId, "Complainant audit record ID should match the set value");
    }

    @Test
    void testGetSetUserOID() {
        String expectedUserOID = "user-1234-oid";
        auditMaster.setUserOID(expectedUserOID);
        assertEquals(expectedUserOID, auditMaster.getUserOID());
    }

    @Test
    void testGetSetAuditEventTimestamp() {
        auditMaster.setAuditEventTimestamp(now);
        assertEquals(now, auditMaster.getAuditEventTimestamp());
    }

    @Test
    void testGetSetAuditEventName() {
        String name = "CREATE_EVENT";
        auditMaster.setAuditEventName(name);
        assertEquals(name, auditMaster.getAuditEventName());
    }

    @Test
    void testGetSetPrimaryAuditEntity() {
        String entity = "Customer";
        auditMaster.setPrimaryAuditEntity(entity);
        assertEquals(entity, auditMaster.getPrimaryAuditEntity());
    }

    @Test
    void testGetSetPrimaryAuditEntityIdentifier() {
        String identifier = "cust-123";
        auditMaster.setPrimaryAuditEntityIdentifier(identifier);
        assertEquals(identifier, auditMaster.getPrimaryAuditEntityIdentifier());
    }

    @Test
    void testGetSetPreAuditSnapshot() {
        String preSnapshot = "{\"name\":\"John\"}";
        auditMaster.setPreAuditSnapshot(preSnapshot);
        assertEquals(preSnapshot, auditMaster.getPreAuditSnapshot());
    }

    @Test
    void testGetSetPostAuditSnapshot() {
        String postSnapshot = "{\"name\":\"John Updated\"}";
        auditMaster.setPostAuditSnapshot(postSnapshot);
        assertEquals(postSnapshot, auditMaster.getPostAuditSnapshot());
    }

    @Test
    void testGetSetCreatedBy() {
        String createdBy = "admin";
        auditMaster.setCreatedBy(createdBy);
        assertEquals(createdBy, auditMaster.getCreatedBy());
    }

    @Test
    void testGetSetCreatedOn() {
        auditMaster.setCreatedOn(now);
        assertEquals(now, auditMaster.getCreatedOn());
    }

    @Test
    void testGetSetModifiedOn() {
        auditMaster.setModifiedOn(now);
        assertEquals(now, auditMaster.getModifiedOn());
    }

    @Test
    void testGetSetModifiedBy() {
        String modifiedBy = "editor";
        auditMaster.setModifiedBy(modifiedBy);
        assertEquals(modifiedBy, auditMaster.getModifiedBy());
    }
}