package com.ombudsman.service.communication.controller.test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.time.LocalDateTime;

import org.json.JSONException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.ombudsman.service.communication.common.CommonUtil;
import com.ombudsman.service.communication.common.KeyVaultConfiguration;
import com.ombudsman.service.communication.common.UserBean;
import com.ombudsman.service.communication.common.ValidateUserSession;
import com.ombudsman.service.communication.controller.CommunicationServiceController;
import com.ombudsman.service.communication.exception.UnAuthorisedException;
import com.ombudsman.service.communication.model.request.SinchApiRequest;
import com.ombudsman.service.communication.model.request.UserRequestBody;
import com.ombudsman.service.communication.model.response.EmailNotificationResponse;
import com.ombudsman.service.communication.model.response.GenericResponse;
import com.ombudsman.service.communication.model.response.GetZenDeskJwtToken;
import com.ombudsman.service.communication.model.response.GetZenDeskUrlWebForm;
import com.ombudsman.service.communication.serviceimpl.CommunicationServiceImpl;

@ExtendWith(MockitoExtension.class)
class CommunicationServiceControllerTest {

    @Mock
    private CommunicationServiceImpl sendEmailService;

    @Mock
    private UserBean userbean;

    @Mock
    private KeyVaultConfiguration keyVaultConfiguration;

    @Mock
    private CommonUtil commonUtil;

    @Mock
    private ValidateUserSession validateUserSession;

    @InjectMocks
    private CommunicationServiceController controller;

    private UserRequestBody userRequest;
    private SinchApiRequest sinchApiRequest;

    @BeforeEach
    void setup() throws Exception {
        // Set the xApiKey field directly since Mockito can't mock fields
        java.lang.reflect.Field xApiKeyField = KeyVaultConfiguration.class.getDeclaredField("xApiKey");
        xApiKeyField.setAccessible(true);
        xApiKeyField.set(keyVaultConfiguration, "validKey");

        // Other setup...
    }
    @Test
    void sendEmailtoUser_validApiKey_shouldReturnOkAndResponse1() throws Exception {
       // when(keyVaultConfiguration.xApiKey).thenReturn("validKey");
        when(userbean.getApiKey()).thenReturn("VALIDKEY");
        when(userbean.getCorrelationId()).thenReturn("corrId");
        when(userbean.getUserObjectId()).thenReturn("oid");

        EmailNotificationResponse mockResponse = new EmailNotificationResponse();
        when(sendEmailService.sendInviteEmail(any())).thenReturn(mockResponse);

        ResponseEntity<EmailNotificationResponse> response = controller.sendEmailtoUser(userRequest);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(mockResponse, response.getBody());
    }
    @Test
    void sendInviteEmail_validSession_shouldReturnOkAndResponse() throws Exception {
        when(validateUserSession.isValidSession()).thenReturn(true);
        when(userbean.getCorrelationId()).thenReturn("corrId");
        when(userbean.getUserObjectId()).thenReturn("oid");
        EmailNotificationResponse mockResponse = new EmailNotificationResponse();
        when(sendEmailService.sendInviteEmail(any())).thenReturn(mockResponse);

        ResponseEntity<EmailNotificationResponse> response = controller.sendInviteEmail(userRequest);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(mockResponse, response.getBody());
    }

    @Test
    void sendInviteEmail_invalidSession_shouldReturnUnauthorized() throws Exception {
        when(validateUserSession.isValidSession()).thenReturn(false);

        ResponseEntity<EmailNotificationResponse> response = controller.sendInviteEmail(userRequest);

        assertEquals(HttpStatus.UNAUTHORIZED, response.getStatusCode());
    }

    @Test
    void sendEmailtoUser_validApiKey_shouldReturnOkAndResponse() throws Exception {
        //when(keyVaultConfiguration.xApiKey).thenReturn("validKey");
        when(userbean.getApiKey()).thenReturn("VALIDKEY"); // case insensitive check
        when(userbean.getCorrelationId()).thenReturn("corrId");
        when(userbean.getUserObjectId()).thenReturn("oid");

        EmailNotificationResponse mockResponse = new EmailNotificationResponse();
        when(sendEmailService.sendInviteEmail(any())).thenReturn(mockResponse);

        ResponseEntity<EmailNotificationResponse> response = controller.sendEmailtoUser(userRequest);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(mockResponse, response.getBody());
    }

    @Test
    void sendEmailtoUser_invalidApiKey_shouldReturnUnauthorized() throws Exception {
        //when(keyVaultConfiguration.xApiKey).thenReturn("validKey");
        when(userbean.getApiKey()).thenReturn("invalidKey");

        ResponseEntity<EmailNotificationResponse> response = controller.sendEmailtoUser(userRequest);

        assertEquals(HttpStatus.UNAUTHORIZED, response.getStatusCode());
    }

    @Test
    void sendSMSController_validApiKey_shouldReturnResponseFromService() throws Exception {
        //when(keyVaultConfiguration.xApiKey).thenReturn("validKey");
        when(userbean.getApiKey()).thenReturn("VALIDKEY");
        when(userbean.getCorrelationId()).thenReturn("corrId");
        when(userbean.getUserObjectId()).thenReturn("oid");

        EmailNotificationResponse mockResponse = new EmailNotificationResponse();
        mockResponse.setHttpStatus(HttpStatus.ACCEPTED);
        when(sendEmailService.sendSms(any())).thenReturn(mockResponse);

        ResponseEntity<EmailNotificationResponse> response = controller.sendSMSController(sinchApiRequest);

        assertEquals(HttpStatus.ACCEPTED, response.getStatusCode());
        assertEquals(mockResponse, response.getBody());
    }

    @Test
    void sendSMSController_invalidApiKey_shouldReturnUnauthorized() throws Exception {
       // when(keyVaultConfiguration.xApiKey).thenReturn("validKey");
        when(userbean.getApiKey()).thenReturn("invalidKey");

        ResponseEntity<EmailNotificationResponse> response = controller.sendSMSController(sinchApiRequest);

        assertEquals(HttpStatus.UNAUTHORIZED, response.getStatusCode());
    }

    @Test
    void getZenDeskJwtToken_validSession_shouldReturnToken() throws IOException, UnAuthorisedException {
        when(validateUserSession.isValidSession()).thenReturn(true);
        when(userbean.getCorrelationId()).thenReturn("corrId");
        when(userbean.getUserObjectId()).thenReturn("oid");
        when(commonUtil.getZendeskJwtToken()).thenReturn("jwtToken");

        ResponseEntity<GetZenDeskJwtToken> response = controller.getZenDeskJwtToken();

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("jwtToken", response.getBody().getJwttoken());
    }

    @Test
    void getZenDeskJwtToken_invalidSession_shouldReturnUnauthorized() throws IOException, UnAuthorisedException {
        when(validateUserSession.isValidSession()).thenReturn(false);

        ResponseEntity<GetZenDeskJwtToken> response = controller.getZenDeskJwtToken();

        assertEquals(HttpStatus.UNAUTHORIZED, response.getStatusCode());
    }

    @Test
    void getZenDeskUrlWebForm_validSession_shouldReturnUrlWebForm()
            throws JSONException, IOException, UnAuthorisedException, java.text.ParseException {
        when(validateUserSession.isValidSession()).thenReturn(true);
        when(userbean.getCorrelationId()).thenReturn("corrId");
        when(userbean.getUserObjectId()).thenReturn("oid");

        GetZenDeskUrlWebForm mockForm = new GetZenDeskUrlWebForm();
        when(commonUtil.getZendeskUrlWebForm()).thenReturn(mockForm);

        ResponseEntity<GetZenDeskUrlWebForm> response = controller.getZenDeskUrlWebForm();

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(mockForm, response.getBody());
    }

    @Test
    void getZenDeskUrlWebForm_invalidSession_shouldReturnUnauthorized()
            throws JSONException, IOException, UnAuthorisedException, java.text.ParseException {
        when(validateUserSession.isValidSession()).thenReturn(false);

        ResponseEntity<GetZenDeskUrlWebForm> response = controller.getZenDeskUrlWebForm();

        assertEquals(HttpStatus.UNAUTHORIZED, response.getStatusCode());
    }

    @Test
    void getHealthCheck_shouldReturnAvailableStatus() {
        ResponseEntity<GenericResponse> response = controller.getHealthCheck();

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("Available", response.getBody().getStatus());
        // The message is a timestamp string; check it is not null or empty
        assert(response.getBody().getMessage() != null && !response.getBody().getMessage().isEmpty());
    }

    @Test
    void getLiveHealthCheck_shouldReturnAvailableStatus() {
        ResponseEntity<GenericResponse> response = controller.getLiveHealthCheck();

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("Available", response.getBody().getStatus());
        assert(response.getBody().getMessage() != null && !response.getBody().getMessage().isEmpty());
    }

    @Test
    void getRedinessHealthCheck_shouldReturnAvailableStatus() {
        ResponseEntity<GenericResponse> response = controller.getRedinessHealthCheck();

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("Available", response.getBody().getStatus());
        assert(response.getBody().getMessage() != null && !response.getBody().getMessage().isEmpty());
    }
}