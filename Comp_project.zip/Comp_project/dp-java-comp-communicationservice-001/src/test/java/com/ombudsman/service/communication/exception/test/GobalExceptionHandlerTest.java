package com.ombudsman.service.communication.exception.test;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;
import static org.springframework.http.HttpStatus.*;

import java.time.LocalDateTime;
import java.util.Locale;

import org.apache.logging.log4j.Logger;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.*;
import org.springframework.context.MessageSource;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.HttpMediaTypeNotSupportedException;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;
import org.springframework.web.servlet.NoHandlerFoundException;

import com.ombudsman.service.communication.common.UserBean;
import com.ombudsman.service.communication.exception.ApiError;
import com.ombudsman.service.communication.exception.GobalExceptionHandler;
import com.ombudsman.service.communication.exception.InputValidationException;
import com.ombudsman.service.communication.exception.MailJetServiceException;
import com.ombudsman.service.communication.exception.ResourceNotFoundException;
import com.ombudsman.service.communication.exception.RespondentsServiceExceptions;
import com.ombudsman.service.communication.exception.SinchServiceException;

import jakarta.validation.ConstraintViolationException;

// Unit tests for GobalExceptionHandler
public class GobalExceptionHandlerTest {
    
    @InjectMocks
    private GobalExceptionHandler exceptionHandler;

    @Mock
    private UserBean userbean;

    @Mock
    private MessageSource messageSource;

    @Mock
    private Logger LOG;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
        // Inject the mock logger (since LogManager.getRootLogger() can't be mocked easily)
       // exceptionHandler.LOG = LOG;
        
        // Mock UserBean methods
        when(userbean.getUserObjectId()).thenReturn("userObjectId123");
        when(userbean.getCorrelationId()).thenReturn("correlationId456");
        
        // Mock MessageSource to return supplied key in English locale for simplicity
        when(messageSource.getMessage(anyString(), any(), eq(Locale.ENGLISH))).thenAnswer(invocation -> invocation.getArgument(0));
    }
    
    // Utility to assert ApiError contents
    private void assertApiError(ApiError err, LocalDateTime time, org.springframework.http.HttpStatus status, String message, String code) {
        assertNotNull(err);
        assertNotNull(err.getTimestamp());
        assertEquals(status, err.getStatus());
        assertEquals(message, err.getErrorMessage());
        assertEquals(code, err.getErrorCode());
    }
    
    @Test
    public void testHandleHttpMessageNotReadableException() {
        HttpMessageNotReadableException ex = mock(HttpMessageNotReadableException.class);
        when(ex.getMessage()).thenReturn("Message not readable");
        when(ex.getStackTrace()).thenReturn(new StackTraceElement[0]);
        
        ResponseEntity<Object> response = exceptionHandler.handleHttpMessageNotReadableException(ex);
        assertEquals(BAD_REQUEST, response.getStatusCode());
        ApiError err = (ApiError) response.getBody();
        assertApiError(err, null, BAD_REQUEST, "api.error.messagenotreadable", "COMPLAINANT_1002");
        
        verify(LOG).error(anyString(), any(), any(), any(), any(), any());
    }
    
    @Test
    public void testHandleMethodArgumentNotValidException() {
        MethodArgumentNotValidException ex = mock(MethodArgumentNotValidException.class);
        when(ex.getMessage()).thenReturn("Argument not valid");
        when(ex.getStackTrace()).thenReturn(new StackTraceElement[0]);
        
        ResponseEntity<Object> response = exceptionHandler.handleMethodArgumentNotValidException(ex);
        assertEquals(BAD_REQUEST, response.getStatusCode());
        ApiError err = (ApiError) response.getBody();
        assertApiError(err, null, BAD_REQUEST, "api.error.exceptionmsg", "COMPLAINANT_1002");
        
        verify(LOG).error(anyString(), any(), any(), any(), any(), any());
    }
    
    @Test
    public void testHandleMissingServletRequestParameterException() {
        MissingServletRequestParameterException ex = new MissingServletRequestParameterException("param", "type");
        ResponseEntity<Object> response = exceptionHandler.handleMissingServletRequestParameterException(ex);
        assertEquals(BAD_REQUEST, response.getStatusCode());
        ApiError err = (ApiError) response.getBody();
        assertApiError(err, null, BAD_REQUEST, "api.error.messagenotreadable", "COMPLAINANT_1002");
        
        verify(LOG).error(anyString(), any(), any(), any(), any(), any());
    }

    @Test
    public void testHandleMethodArgumentTypeMismatchException() {
        MethodArgumentTypeMismatchException ex = mock(MethodArgumentTypeMismatchException.class);
        when(ex.getMessage()).thenReturn("Type mismatch");
        when(ex.getStackTrace()).thenReturn(new StackTraceElement[0]);
        
        ResponseEntity<Object> response = exceptionHandler.handleMethodArgumentTypeMismatchException(ex);
        assertEquals(BAD_REQUEST, response.getStatusCode());
        ApiError err = (ApiError) response.getBody();
        assertApiError(err, null, BAD_REQUEST, "api.error.exceptionmsg", "COMPLAINANT_1002");
        
        verify(LOG).error(anyString(), any(), any(), any(), any(), any());
    }
    
    @Test
    public void testHandleInterruptedException() {
        InterruptedException ex = new InterruptedException("Interrupted");
        ResponseEntity<Object> response = exceptionHandler.handleInterruptedException(ex);
        assertEquals(BAD_REQUEST, response.getStatusCode());
        ApiError err = (ApiError) response.getBody();
        assertApiError(err, null, BAD_REQUEST, "api.error.exceptionmsg", "COMPLAINANT_1002");
        
        verify(LOG).error(anyString(), any(), any(), any(), any(), any());
    }
    
    @Test
    public void testHandleConstraintViolationException() {
        ConstraintViolationException ex = mock(ConstraintViolationException.class);
        when(ex.getMessage()).thenReturn("Constraint violated");
        when(ex.getStackTrace()).thenReturn(new StackTraceElement[0]);
        
        ResponseEntity<Object> response = exceptionHandler.handleConstraintViolationException(ex);
        assertEquals(BAD_REQUEST, response.getStatusCode());
        ApiError err = (ApiError) response.getBody();
        assertApiError(err, null, BAD_REQUEST, "api.error.exceptionmsg", "COMPLAINANT_1002");
        
        verify(LOG).error(anyString(), any(), any(), any(), any(), any());
    }
    
    @Test
    public void testHandleResourceNotFoundException() {
        ResourceNotFoundException ex = mock(ResourceNotFoundException.class);
        when(ex.getMessage()).thenReturn("Not found");
        when(ex.getStackTrace()).thenReturn(new StackTraceElement[0]);

        ResponseEntity<Object> response = exceptionHandler.handleResourceNotFoundException(ex);
        assertEquals(NOT_FOUND, response.getStatusCode());
        ApiError err = (ApiError) response.getBody();
        assertApiError(err, null, NOT_FOUND, "api.error.exceptionmsg", "COMPLAINANT_1004");
        
        verify(LOG).error(anyString(), any(), any(), any(), any(), any());
    }
    
    @Test
    public void testHandleNoHandlerFoundException() {
        NoHandlerFoundException ex = mock(NoHandlerFoundException.class);
        when(ex.getMessage()).thenReturn("No handler found");
        when(ex.getStackTrace()).thenReturn(new StackTraceElement[0]);
        
        ResponseEntity<Object> response = exceptionHandler.handleNoHandlerFoundException(ex);
        assertEquals(BAD_REQUEST, response.getStatusCode());
        ApiError err = (ApiError) response.getBody();
        assertNotNull(err);
        assertEquals(BAD_REQUEST, err.getStatus());
        assertEquals("", err.getErrorMessage());
        assertNull(err.getErrorCode());
        
        verify(LOG).error(anyString(), any(), any(), any(), any(), any());
    }
    
    @Test
    public void testHandleRespondentsServiceExceptions() {
        RespondentsServiceExceptions ex = mock(RespondentsServiceExceptions.class);
        when(ex.getCode()).thenReturn("CODE123");
        when(ex.getExceptionMessage()).thenReturn("Respondent exception");
        when(ex.getStackTrace()).thenReturn(new StackTraceElement[0]);

        ResponseEntity<Object> response = exceptionHandler.handleRespondentsServiceExceptions(ex);
        assertEquals(BAD_REQUEST, response.getStatusCode());
        ApiError err = (ApiError) response.getBody();
        assertNotNull(err);
        assertEquals(BAD_REQUEST, err.getStatus());
        assertNull(err.getErrorMessage());
        assertNull(err.getErrorCode());
        
        verify(LOG).error(anyString(), eq("CODE123"), any(), eq("Respondent exception"), any(), any());
    }
    
    @Test
    public void testHandleInputValidationException() {
        InputValidationException ex = mock(InputValidationException.class);
        when(ex.getMessage()).thenReturn("Input validation failed");
        when(ex.getLocalizedMessage()).thenReturn("Localized message");
        when(ex.getStackTrace()).thenReturn(new StackTraceElement[0]);
        
        ResponseEntity<ApiError> response = exceptionHandler.handleInputValidationException(ex);
        assertEquals(BAD_REQUEST, response.getStatusCode());
        ApiError err = response.getBody();
        assertNotNull(err);
        assertEquals(BAD_REQUEST, err.getStatus());
        assertNull(err.getErrorMessage());
        assertNull(err.getErrorCode());
        
        verify(LOG).error(anyString(), any(), any(), any(), any(), any());
    }
    
    @Test
    public void testHandleException() {
        Exception ex = mock(Exception.class);
        when(ex.getMessage()).thenReturn("General exception");
        when(ex.getStackTrace()).thenReturn(new StackTraceElement[0]);

        ResponseEntity<ApiError> response = exceptionHandler.handleException(ex);
        assertEquals(BAD_REQUEST, response.getStatusCode());
        ApiError err = response.getBody();
        assertApiError(err, null, BAD_REQUEST, "api.error.exceptionmsg", "COMPLAINANT_1004");
        
        verify(LOG).error(anyString(), eq("COMPLAINANT_1004"), any(), eq("General exception"), any(), any());
    }
    
    @Test
    public void testHandleMailJetServiceException() {
        MailJetServiceException ex = mock(MailJetServiceException.class);
        when(ex.getMessage()).thenReturn("MailJet failure");
        
        ResponseEntity<ApiError> response = exceptionHandler.handleMailJetServiceException(ex);
        assertEquals(org.springframework.http.HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
        ApiError err = response.getBody();
        assertNotNull(err);
        assertEquals(INTERNAL_SERVER_ERROR, err.getStatus());
        assertEquals(String.valueOf(INTERNAL_SERVER_ERROR), err.getErrorMessage());
        assertEquals("COMPLAINANT_1004", err.getErrorCode());
    }
    
    @Test
    public void testHandleThrowable() {
        Throwable t = mock(Throwable.class);
        when(t.getMessage()).thenReturn("Throwable error");
        
        ResponseEntity<ApiError> response = exceptionHandler.handleThrowable(t);
        assertEquals(INTERNAL_SERVER_ERROR, response.getStatusCode());
        ApiError err = response.getBody();
        assertNotNull(err);
        assertEquals(INTERNAL_SERVER_ERROR, err.getStatus());
        assertEquals(String.valueOf(INTERNAL_SERVER_ERROR.value()), err.getErrorMessage());
        assertEquals("COMPLAINANT_1004", err.getErrorCode());
    }
//    
    @Test
    public void testHandleSinchServiceException() {
        SinchServiceException ex = mock(SinchServiceException.class);
        when(ex.getMessage()).thenReturn("Sinch service failed");
        when(ex.getStackTrace()).thenReturn(new StackTraceElement[0]);
        
        ResponseEntity<ApiError> response = exceptionHandler.handleSinchServiceException(ex);
        // The method returns INTERNAL_SERVER_ERROR status, but ApiError status is BAD_GATEWAY
        assertEquals(INTERNAL_SERVER_ERROR, response.getStatusCode());
        ApiError err = response.getBody();
        assertNotNull(err);
        assertEquals(BAD_GATEWAY, err.getStatus());
        assertNull(err.getErrorMessage());
        assertEquals("COMPLAINANT_1004", err.getErrorCode());
        
        verify(LOG).error(anyString(), eq("COMPLAINANT_1004"), any(), eq("Sinch service failed"), any(), any());
    }

}