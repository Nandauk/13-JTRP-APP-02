package com.ombudsman.service.communication.model.request.test;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.ombudsman.service.communication.model.request.SinchApiRequest;

class SinchApiRequestTest {

    private SinchApiRequest sinchApiRequest;

    @BeforeEach
    void setUp() {
        sinchApiRequest = new SinchApiRequest();
    }

    @Test
    void testGetSetFrom() {
        String from = "senderNumber";
        sinchApiRequest.setFrom(from);
        assertEquals(from, sinchApiRequest.getFrom());
    }

    @Test
    void testGetSetTo() {
        List<String> toList = Arrays.asList("recipient1", "recipient2");
        sinchApiRequest.setTo(toList);
        assertEquals(toList, sinchApiRequest.getTo());

        // Test with empty list
        List<String> emptyList = Collections.emptyList();
        sinchApiRequest.setTo(emptyList);
        assertEquals(emptyList, sinchApiRequest.getTo());

        // Test with null
        sinchApiRequest.setTo(null);
        assertNull(sinchApiRequest.getTo());
    }

    @Test
    void testGetSetBody() {
        String body = "Test message body";
        sinchApiRequest.setBody(body);
        assertEquals(body, sinchApiRequest.getBody());
    }
}