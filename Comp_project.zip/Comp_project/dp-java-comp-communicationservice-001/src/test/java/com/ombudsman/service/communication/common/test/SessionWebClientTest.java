package com.ombudsman.service.communication.common.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.mockito.Mockito.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.util.ReflectionTestUtils;


import com.ombudsman.service.communication.common.CommonUtil;
import com.ombudsman.service.communication.common.SessionWebClient;
import com.ombudsman.service.communication.common.UserBean;
import com.ombudsman.service.communication.model.response.GenericResponse;


@ExtendWith(SpringExtension.class)
public class SessionWebClientTest {

	 
	 @BeforeEach
	 void setup() {
		 MockitoAnnotations.openMocks(this);
	 }
	
	@DisplayName("getResponseForSessionActivityTest")
	@Test
	public void  getResponseForSessionActivityTest() {

		CommonUtil commonUtilMock = mock(CommonUtil.class);
        UserBean userbeanMock = mock(UserBean.class);
        SessionWebClient sessionWebClientTest= new SessionWebClient(userbeanMock, commonUtilMock);
        GenericResponse actualResponse = null;
      
        ReflectionTestUtils.setField(commonUtilMock, "sessionBaseUrl" , "http://localhost:8080");
		
        when(userbeanMock.getAuthToken()).thenReturn("testAuthToken");
        when(userbeanMock.getUserObjectId()).thenReturn("testUserObjectId");

         actualResponse = sessionWebClientTest.getResponseForSessionActivity();

      //  assertNull(actualResponse);
		
	}
}
