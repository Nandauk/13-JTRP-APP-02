package com.ombudsman.service.communication.exception.test;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.ombudsman.service.communication.exception.UnAuthorisedException;

@ExtendWith(SpringExtension.class)
public class UnAuthorisedExceptionTest {
	@InjectMocks
	UnAuthorisedException unAuthorisedException;
	
	@Test
    void testUnAuthorisedException() {
        Exception exception = new UnAuthorisedException("msg");

        Assertions.assertThrows(UnAuthorisedException.class, () -> {
            throw exception;
        });
    }
}
