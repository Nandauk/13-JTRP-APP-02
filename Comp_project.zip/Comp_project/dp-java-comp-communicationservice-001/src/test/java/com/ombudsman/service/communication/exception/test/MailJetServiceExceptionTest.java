package com.ombudsman.service.communication.exception.test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.ombudsman.service.communication.exception.MailJetServiceException;

@ExtendWith(SpringExtension.class)
public class MailJetServiceExceptionTest {

	@Test
    public void testMailJetServiceException() {
        String message = "Test message";
        
        MailJetServiceException exception = new MailJetServiceException(message);

        assertEquals(message, exception.getMessage());
           }
	
}
