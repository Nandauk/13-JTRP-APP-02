package com.ombudsman.service.communication.model.response.test;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.ombudsman.service.communication.model.response.MailjetResponseBody;

class MailjetResponseBodyTest {

    private MailjetResponseBody mailjetResponseBody;
    private MailjetResponseBody.Message message;
    private MailjetResponseBody.Recipient recipient;

    @BeforeEach
    void setUp() {
        mailjetResponseBody = new MailjetResponseBody();

        recipient = new MailjetResponseBody.Recipient();
        recipient.setEmail("test@example.com");
        recipient.setMessageUUID("uuid-123");
        recipient.setMessageID(456L);
        recipient.setMessageHref("http://message.href");

        message = new MailjetResponseBody.Message();
        message.setStatus("sent");
        message.setCustomID("custom-001");
        message.setTo(Collections.singletonList(recipient));
        message.setCc(Collections.emptyList());
        message.setBcc(Collections.emptyList());
    }

    @Test
    void testGetSetMessages() {
        List<MailjetResponseBody.Message> messages = Arrays.asList(message);
        mailjetResponseBody.setMessages(messages);
        assertEquals(messages, mailjetResponseBody.getMessages());
    }

    @Test
    void testMessageGettersAndSetters() {
        MailjetResponseBody.Message msg = new MailjetResponseBody.Message();

        msg.setStatus("delivered");
        assertEquals("delivered", msg.getStatus());

        msg.setCustomID("custom-002");
        assertEquals("custom-002", msg.getCustomID());

        List<MailjetResponseBody.Recipient> toList = Arrays.asList(recipient);
        msg.setTo(toList);
        assertEquals(toList, msg.getTo());

        List<MailjetResponseBody.Recipient> ccList = Collections.singletonList(recipient);
        msg.setCc(ccList);
        assertEquals(ccList, msg.getCc());

        List<MailjetResponseBody.Recipient> bccList = Collections.singletonList(recipient);
        msg.setBcc(bccList);
        assertEquals(bccList, msg.getBcc());
    }

    @Test
    void testRecipientGettersAndSetters() {
        MailjetResponseBody.Recipient rec = new MailjetResponseBody.Recipient();

        rec.setEmail("email@example.com");
        assertEquals("email@example.com", rec.getEmail());

        rec.setMessageUUID("uuid-456");
        assertEquals("uuid-456", rec.getMessageUUID());

        rec.setMessageID(789L);
        assertEquals(789L, rec.getMessageID());

        rec.setMessageHref("http://example.com/message/789");
        assertEquals("http://example.com/message/789", rec.getMessageHref());
    }

    @Test
    void testMailjetResponseBodyToString() {
        mailjetResponseBody.setMessages(Collections.singletonList(message));
        String str = mailjetResponseBody.toString();
        assertTrue(str.contains("Message"));
        assertTrue(str.contains("sent"));
    }

    @Test
    void testMessageToString() {
        String str = message.toString();
        assertTrue(str.contains("Status: " + message.getStatus()));
        assertTrue(str.contains("CustomID: " + message.getCustomID()));
        assertTrue(str.contains("TO : " + message.getTo()));
    }

    @Test
    void testRecipientToString() {
        String str = recipient.toString();
        assertTrue(str.contains("email: " + recipient.getEmail()));
        assertTrue(str.contains("messageUUID: " + recipient.getMessageUUID()));
        assertTrue(str.contains("messageID : " + recipient.getMessageID()));
        assertTrue(str.contains("messageHref : " + recipient.getMessageHref()));
    }
}