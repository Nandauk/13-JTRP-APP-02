package com.ombudsman.service.communication.model.request.test;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.ombudsman.service.communication.model.request.UserProfileReq;

public class UserProfileReqTest {

    private UserProfileReq userProfileReq;

    @BeforeEach
    public void setUp() {
        userProfileReq = new UserProfileReq();
    }

    @Test
    public void testSetAndGetEmail_HarderValue() {
        String testEmail = "complex.email+test-123@subdomain.example-domain.co.uk";
        userProfileReq.setEmail(testEmail);
        String retrievedEmail = userProfileReq.getEmail();
        assertEquals(testEmail, retrievedEmail, "The email getter should return the value set by the setter");
    }
}