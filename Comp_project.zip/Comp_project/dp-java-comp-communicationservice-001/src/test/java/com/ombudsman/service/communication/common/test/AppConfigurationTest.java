package com.ombudsman.service.communication.common.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.springframework.context.support.ReloadableResourceBundleMessageSource;
import org.springframework.context.MessageSource;
import com.ombudsman.service.communication.common.AppConfiguration;

public class AppConfigurationTest {
	@InjectMocks
	@Spy
	AppConfiguration testInstance;
	
	@Mock
	MessageSource mMockMessageSource;
	
	@Mock
	ReloadableResourceBundleMessageSource ReloadableResourceBundleMessageSource;
	
	

    @Test
    public void testMessageSourceConfiguration() {
       
    	AppConfiguration appConfiguration = new AppConfiguration();

        MessageSource messageSource = appConfiguration.messageSource();

        assertNotNull(messageSource);
        assertEquals(ReloadableResourceBundleMessageSource.class, messageSource.getClass());
    }

}