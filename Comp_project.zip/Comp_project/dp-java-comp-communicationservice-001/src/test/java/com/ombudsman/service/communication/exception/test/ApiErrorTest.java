package com.ombudsman.service.communication.exception.test;

import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDateTime;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpStatus;

import com.ombudsman.service.communication.exception.ApiError;

public class ApiErrorTest {
    
    private LocalDateTime timestamp;
    private HttpStatus status;
    private String errorMessage;
    private String errorCode;
    private ApiError apiError;
    
    @BeforeEach
    public void setUp() {
        timestamp = LocalDateTime.of(2024, 6, 15, 10, 30, 25);
        status = HttpStatus.BAD_REQUEST;
        errorMessage = "Invalid request parameter";
        errorCode = "400_BAD_REQUEST";
        apiError = new ApiError(timestamp, status, errorMessage, errorCode);
    }
    
    @Test
    public void testConstructorAndGetters() {
        assertEquals(timestamp, apiError.getTimestamp());
        assertEquals(status, apiError.getStatus());
        assertEquals(errorMessage, apiError.getErrorMessage());
        assertEquals(errorCode, apiError.getErrorCode());
    }
    
    @Test
    public void testSetters() {
        LocalDateTime newTimestamp = LocalDateTime.of(2024, 7, 1, 12, 0, 0);
        HttpStatus newStatus = HttpStatus.INTERNAL_SERVER_ERROR;
        String newErrorMessage = "Server error";
        String newErrorCode = "500_SERVER_ERROR";
        
        apiError.setTimestamp(newTimestamp);
        apiError.setStatus(newStatus);
        apiError.setErrorMessage(newErrorMessage);
        apiError.setErrorCode(newErrorCode);
        
        assertEquals(newTimestamp, apiError.getTimestamp());
        assertEquals(newStatus, apiError.getStatus());
        assertEquals(newErrorMessage, apiError.getErrorMessage());
        assertEquals(newErrorCode, apiError.getErrorCode());
    }
}