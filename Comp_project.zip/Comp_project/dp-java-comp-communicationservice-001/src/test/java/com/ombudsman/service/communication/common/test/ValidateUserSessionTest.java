package com.ombudsman.service.communication.common.test;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.when;

import java.lang.reflect.Field;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.ombudsman.service.communication.common.CommonUtil;
import com.ombudsman.service.communication.common.SessionWebClient;
import com.ombudsman.service.communication.common.ValidateUserSession;
import com.ombudsman.service.communication.exception.UnAuthorisedException;
import com.ombudsman.service.communication.model.response.GenericResponse;



public class ValidateUserSessionTest {
    
    @Mock
    private CommonUtil commonUtil;
    
    @Mock
	SessionWebClient manageUserWebClient;
    
    @InjectMocks
    private ValidateUserSession validateUserSession;
    
    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }
    
    private void setSessionFlag(String value) throws Exception {
        Field field = CommonUtil.class.getDeclaredField("sessionFlag");
        field.setAccessible(true);
        field.set(commonUtil, value);
    }
    
    @Test
    void testValidSession() throws Exception {
        setSessionFlag("true");
        GenericResponse response = new GenericResponse();
        response.setStatus("valid");
        when(manageUserWebClient.getResponseForSessionActivity()).thenReturn(response);
        
        assertTrue(validateUserSession.isValidSession());
    }
    
    @Test
    void testSessionFlagFalse() throws Exception {
        setSessionFlag("false");
        
        assertFalse(validateUserSession.isValidSession());
    }
    
    @Test
    void testExceptionDuringValidation() throws Exception {
        setSessionFlag("true");
        when(manageUserWebClient.getResponseForSessionActivity()).thenThrow(new RuntimeException("Some error"));
        
        assertThrows(UnAuthorisedException.class, () -> {
            validateUserSession.isValidSession();
        });
    }
    
    @Test
    void testNullTokenStatus() throws Exception {
        setSessionFlag("true");
        GenericResponse response = new GenericResponse();
        response.setStatus(null);
        when(manageUserWebClient.getResponseForSessionActivity()).thenReturn(response);
        
        assertThrows(UnAuthorisedException.class, () -> {
            validateUserSession.isValidSession();
        });
    }
}
