package com.ombudsman.service.communication.common.test;

import static org.junit.Assert.assertThrows;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

import java.lang.reflect.Field;
import java.util.Collections;

import com.ombudsman.service.communication.common.CommonUtil;
import com.ombudsman.service.communication.exception.MailJetServiceException;
import com.ombudsman.service.communication.exception.SinchServiceException;
import com.ombudsman.service.communication.model.dto.AuditMaster;
import com.ombudsman.service.communication.model.request.MailjetRequest;
import com.ombudsman.service.communication.model.request.SinchApiRequest;
import com.ombudsman.service.communication.model.request.UserRequestBody;
import com.ombudsman.service.communication.model.response.EmailNotificationResponse;
import com.ombudsman.service.communication.model.response.MailjetResponseBody;
import com.ombudsman.service.communication.model.response.SinchApiResponse;
import com.ombudsman.service.communication.service.AuditRepository;
import com.ombudsman.service.communication.serviceimpl.CommunicationServiceImpl;
import com.ombudsman.service.communication.serviceimpl.RequestBodyHelper;
import com.ombudsman.service.communication.common.UserBean;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import org.mockito.*;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.MockedStatic;

import org.springframework.http.HttpStatus;
import org.springframework.web.reactive.function.client.WebClient;

import reactor.core.publisher.Mono;
import org.springframework.http.MediaType;

@ExtendWith(MockitoExtension.class)
class CommunicationServiceImplTest {

    @InjectMocks
    private CommunicationServiceImpl communicationService;

    @Mock
    private AuditRepository audit;

    @Mock
    private UserBean userbean;

    @Mock
    private RequestBodyHelper helper;

    @Mock
    private AuditRepository auditRepository;

    @Mock
    private RequestBodyHelper requestBodyHelper;
    private CommonUtil commonUtil;

    // Mockito mocks for WebClient fluent chain
    @Mock
    private WebClient webClient;

    @Mock
    private WebClient.RequestBodyUriSpec requestBodyUriSpec;

    @SuppressWarnings("rawtypes")
    @Mock
    private WebClient.RequestBodySpec requestBodySpec;

    @SuppressWarnings("rawtypes")
    @Mock
    private WebClient.RequestHeadersSpec requestHeadersSpec;

    @Mock
    private WebClient.ResponseSpec responseSpec;

    @Captor
    ArgumentCaptor<AuditMaster> auditMasterCaptor;

    @BeforeEach
    void setUp() throws Exception {
        commonUtil = new CommonUtil();
        commonUtil.sinchUrl = "https://fake-sinch-api-url.com/sendSms";
        commonUtil.sinchFrom = "TestSender";

        Field commonUtilField = CommunicationServiceImpl.class.getDeclaredField("commonUtil");
        commonUtilField.setAccessible(true);
        commonUtilField.set(communicationService, commonUtil);
    }

    @Test
    void testSendSms_Success() throws SinchServiceException {
        // Arrange
        SinchApiRequest smsRequest = new SinchApiRequest();

        SinchApiResponse sinchResponse = new SinchApiResponse();
        sinchResponse.setId("fakeResponseId123");

        try (MockedStatic<WebClient> webClientStaticMock = Mockito.mockStatic(WebClient.class)) {
            webClientStaticMock.when(WebClient::create).thenReturn(webClient);

            when(webClient.post()).thenReturn(requestBodyUriSpec);
            when(requestBodyUriSpec.uri(anyString())).thenReturn(requestBodySpec);
            when(requestBodySpec.bodyValue(any())).thenReturn(requestHeadersSpec);
            when(requestHeadersSpec.accept(any())).thenReturn(requestHeadersSpec);
            when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
            when(responseSpec.bodyToMono(SinchApiResponse.class)).thenReturn(Mono.just(sinchResponse));

            //doNothing().when(audit).save(any(AuditMaster.class));

            // Act
            EmailNotificationResponse result = communicationService.sendSms(smsRequest);

            // Assert
            assertNotNull(result);
            assertEquals("Success", result.getStatus());
            assertEquals("SMS sent successfully", result.getMessage());
            assertEquals(HttpStatus.OK, result.getHttpStatus());
            assertEquals("TestSender", smsRequest.getFrom());

            verify(audit).save(auditMasterCaptor.capture());
            AuditMaster savedAudit = auditMasterCaptor.getValue();
            assertEquals("Sms Sent", savedAudit.getAuditEventName());
            assertEquals("fakeResponseId123", savedAudit.getPrimaryAuditEntityIdentifier());
            assertEquals("fakeResponseId123", savedAudit.getPrimaryAuditEntity());
            assertEquals("Communication Service", savedAudit.getCreatedBy());
            assertNotNull(savedAudit.getAuditEventTimestamp());
            assertNotNull(savedAudit.getCreatedOn());
        }
    }

    @Test
    void testSendSms_WebClientThrowsException_ShouldThrowSinchServiceException() {
        SinchApiRequest smsRequest = new SinchApiRequest();

        try (MockedStatic<WebClient> webClientStaticMock = Mockito.mockStatic(WebClient.class)) {
            webClientStaticMock.when(WebClient::create).thenReturn(webClient);

            when(webClient.post()).thenReturn(requestBodyUriSpec);
            when(requestBodyUriSpec.uri(anyString())).thenReturn(requestBodySpec);
            when(requestBodySpec.bodyValue(any())).thenReturn(requestHeadersSpec);
            when(requestHeadersSpec.accept(any())).thenReturn(requestHeadersSpec);
            when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
            // Simulate exception on Mono retrieval
            when(responseSpec.bodyToMono(SinchApiResponse.class)).thenThrow(new RuntimeException("Simulated WebClient failure"));

            SinchServiceException thrownEx = assertThrows(SinchServiceException.class,
                    () -> communicationService.sendSms(smsRequest));
            assertTrue(thrownEx.getMessage().contains("Simulated WebClient failure"));
        }
    }
 
}