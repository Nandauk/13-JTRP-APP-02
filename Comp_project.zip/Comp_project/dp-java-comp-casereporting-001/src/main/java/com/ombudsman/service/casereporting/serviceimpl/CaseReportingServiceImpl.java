package com.ombudsman.service.casereporting.serviceimpl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ombudsman.service.casereporting.dao.CaseReportingDao;
import com.ombudsman.service.casereporting.exception.UnAuthorisedException;
import com.ombudsman.service.casereporting.model.request.ComplainantRequest;
import com.ombudsman.service.casereporting.model.response.ComplainantStatistics;
import com.ombudsman.service.casereporting.model.response.ComplaintDetails;
import com.ombudsman.service.casereporting.model.response.ComplaintResponse;
import com.ombudsman.service.casereporting.service.CaseReportingService;

@Service
public class CaseReportingServiceImpl implements CaseReportingService {

	@Autowired
	private CaseReportingDao caseReportingDao;
	
	Logger log = LogManager.getRootLogger();
	private static final String RESULT_SET_1 = "#result-set-1";
	private static final String RESULT_SET_2 = "#result-set-2";
	
	@Override
	public ComplaintResponse getComplainantCaseListByUser(ComplainantRequest requestKey, String userOid,List<String> roles)
			throws UnAuthorisedException {
		ComplaintResponse response = new ComplaintResponse();
			ComplaintDetails info = null;

		if (caseReportingDao.isUserExist(userOid) == 1) {
			
			Map<String, Object> listOfComplaintsMap = caseReportingDao
					  .getComplainantStatisticsByUserId(requestKey,UUID.fromString(userOid),
					  roles.get(0));			
			
			List<Map<String, Object>> resultSet = (List<Map<String, Object>>) listOfComplaintsMap.get(RESULT_SET_1);
			if (resultSet != null) {
				ComplainantStatistics complainantStatistics = new ComplainantStatistics();
				for (Map<String, Object> row : resultSet) {
					complainantStatistics.setTotalNoOfComplaints((Integer) row.get("totalcases"));
					complainantStatistics.setCaseNeedAttention((Integer) row.get("noofcaseNeedAttention"));
					complainantStatistics.setTotalNoOfRepresenting((Integer) row.get("noofcaseRepresenting"));
				}
				response.setStatistics(complainantStatistics);
			}

			log.info("RESULT_SET_1:{}", RESULT_SET_1);
			if (null != listOfComplaintsMap.get(RESULT_SET_2)) {
				List<Map<String, Object>> details = (List<Map<String, Object>>) listOfComplaintsMap.get(RESULT_SET_2);
				List<ComplaintDetails> infoList =  new ArrayList<ComplaintDetails>();
				log.info(String.format("RESULT_SET_2 size: %s", details.size()));

				for (Map<String, Object> row : details) {
					info = new ComplaintDetails();
					info.setCaseReference((String)row.get("caseReference"));
					info.setCaseProgressName((String)row.get("caseProgressName"));
					info.setForProduct((String)row.get("forProduct"));
					info.setRaisedAgainst((String)row.get("raisedAgainst"));
					info.setIncidentId((String)row.get("incidentid"));
					infoList.add(info);
				}
				response.setComplaintDetails(infoList);
			}
			log.info("RESULT_SET_2:{}", RESULT_SET_2);

		}

		else {
			throw new UnAuthorisedException("User Not Authorised");
		}

		response.setMessage("Success");
		response.setStatus("200");
		return response;
	}

}
