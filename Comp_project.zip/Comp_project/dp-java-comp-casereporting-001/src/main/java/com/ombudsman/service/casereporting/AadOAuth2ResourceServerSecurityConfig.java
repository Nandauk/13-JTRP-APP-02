//package com.ombudsman.service.casereporting;
//
//import java.util.Arrays;
//
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
//import org.springframework.security.config.annotation.web.builders.HttpSecurity;
//import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
//import org.springframework.security.web.SecurityFilterChain;
//import org.springframework.web.cors.CorsConfiguration;
//import org.springframework.web.cors.CorsConfigurationSource;
//import org.springframework.web.cors.UrlBasedCorsConfigurationSource;
//
//import com.azure.spring.cloud.autoconfigure.implementation.aad.security.AadResourceServerHttpSecurityConfigurer;
//
//@Configuration
//@EnableWebSecurity
//@EnableMethodSecurity(prePostEnabled = true)
//public class AadOAuth2ResourceServerSecurityConfig {
//
//	private static final String STRING = "*";
//
//	@Bean
//	SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
//
//		http.apply(AadResourceServerHttpSecurityConfigurer.aadResourceServer()).configure(
//				http.authorizeHttpRequests(authorizeRequests -> authorizeRequests.requestMatchers(AUTH_WHITELIST)
//						.permitAll().requestMatchers("/actuator/health", "/switch", "/ready", "/readyswitch","/ombudsmanservice/v1/casereporting/healthcheck")
//						.permitAll().requestMatchers("/**").authenticated()));
//		return http.build();
//
//	}
//
//	@Bean
//	public CorsConfigurationSource corsConfigurationSource() {
//		CorsConfiguration configuration = new CorsConfiguration();
//		configuration.setAllowedOrigins(Arrays.asList(STRING));
//		configuration.addAllowedHeader(STRING);
//		configuration.addAllowedMethod(STRING);
//		UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
//		source.registerCorsConfiguration("/**", configuration);
//
//		return source;
//	}
//
//	private static final String[] AUTH_WHITELIST = {
//			// -- Swagger UI v2
//			"/v2/api-docs", "/swagger-resources", "/swagger-resources/**", "/configuration/ui",
//			"/configuration/security", "/swagger-ui.html", "/webjars/**",
//			// -- Swagger UI v3 (OpenAPI)
//			"/v3/api-docs/**", "/swagger-ui/**"
//			// other public endpoints of your API may be appended to this array
//	};
//
//	@Bean
//	public AuthTokenFilter authenticationJwtTokenFilter() {
//		return new AuthTokenFilter();
//	}
//
//}


//package com.ombudsman.service.complainant;
//
//
//
//import java.util.Arrays;
//import org.springframework.beans.factory.annotation.Value;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
//import org.springframework.security.config.annotation.web.builders.HttpSecurity;
//import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
//import org.springframework.security.web.SecurityFilterChain;
//import org.springframework.web.cors.CorsConfiguration;
//import org.springframework.web.cors.CorsConfigurationSource;
//import org.springframework.web.cors.UrlBasedCorsConfigurationSource;
//import org.springframework.security.config.annotation.web.configurers.oauth2.server.resource.OAuth2ResourceServerConfigurer;
//import org.springframework.security.oauth2.core.DelegatingOAuth2TokenValidator;
//import org.springframework.security.oauth2.core.OAuth2TokenValidator;
//import org.springframework.security.oauth2.jwt.JwtDecoder;
//import org.springframework.security.oauth2.jwt.JwtDecoders;
//import org.springframework.security.oauth2.jwt.JwtValidators;
//import org.springframework.security.oauth2.jwt.NimbusJwtDecoder;
//
//@Configuration
//
//@EnableWebSecurity
//
//@EnableMethodSecurity(prePostEnabled = true)
//public class AadOAuth2ResourceServerSecurityConfig {
//
//	@Value("${spring.security.oauth2.resourceserver.jwt.issuer-uri}")
//	private String issuerUri;
//
//	@Bean
//	public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
//		http.authorizeHttpRequests(
//				authorize -> authorize.requestMatchers(AUTH_WHITELIST).permitAll().anyRequest().authenticated())
//				.oauth2ResourceServer(OAuth2ResourceServerConfigurer::jwt);
//		return http.build();
//	}
//
//	@Bean
//	JwtDecoder jwtDecoder() {
//		NimbusJwtDecoder jwtDecoder = (NimbusJwtDecoder) JwtDecoders.fromIssuerLocation(issuerUri);
//
//		OAuth2TokenValidator<org.springframework.security.oauth2.jwt.Jwt> withIssuer = JwtValidators
//				.createDefaultWithIssuer(issuerUri);
//
//		OAuth2TokenValidator<org.springframework.security.oauth2.jwt.Jwt> withAudience = JwtValidators.createDefault();
//
//		OAuth2TokenValidator<org.springframework.security.oauth2.jwt.Jwt> validator = new DelegatingOAuth2TokenValidator<>(
//				withIssuer, withAudience);
//
//		jwtDecoder.setJwtValidator(validator);
//
//		return jwtDecoder;
//	}
//
//	@Bean
//	public CorsConfigurationSource corsConfigurationSource() {
//		CorsConfiguration configuration = new CorsConfiguration();
//		configuration.setAllowedOrigins(Arrays.asList("*"));
//		configuration.addAllowedHeader("*");
//		configuration.addAllowedMethod("*");
//		UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
//		source.registerCorsConfiguration("/**", configuration);
//
//		return source;
//	}
//
//
//    private static final String[] AUTH_WHITELIST = {
//            // -- Swagger UI v2
//            "/v2/api-docs",
//            "/swagger-resources",
//            "/swagger-resources/**",
//            "/configuration/ui",
//            "/configuration/security",
//            "/swagger-ui.html",
//            "/webjars/**",
//            // -- Swagger UI v3 (OpenAPI)
//            "/v3/api-docs/**",
//            "/swagger-ui/**",
//            // other public endpoints of your API may be appended to this array
//           
//    }; 
//
//	@Bean
//	public AuthTokenFilter authenticationJwtTokenFilter() {
//		return new AuthTokenFilter();
//	}
//
//}

package com.ombudsman.service.casereporting;

import java.util.Arrays;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.oauth2.core.DelegatingOAuth2TokenValidator;
import org.springframework.security.oauth2.core.OAuth2TokenValidator;
import org.springframework.security.oauth2.jwt.JwtDecoder;
import org.springframework.security.oauth2.jwt.JwtDecoders;
import org.springframework.security.oauth2.jwt.JwtValidators;
import org.springframework.security.oauth2.jwt.NimbusJwtDecoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.www.BasicAuthenticationFilter;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

@Configuration
@EnableWebSecurity
@EnableMethodSecurity(prePostEnabled = true)
public class AadOAuth2ResourceServerSecurityConfig {

	@Value("${spring.security.oauth2.resourceserver.jwt.issuer-uri}")
	private String issuerUri;

	 @Bean
	    protected SecurityFilterChain configure(HttpSecurity http) throws Exception {
	    	
		 http.authorizeHttpRequests(
					authorize -> authorize.requestMatchers(AUTH_WHITELIST).permitAll()
					.requestMatchers("/compcasereporting/v1/casereportservice/liveness","/compcasereporting/v1/casereportservice/readiness")
					.permitAll().anyRequest().authenticated())
	        .oauth2ResourceServer(oauth2->oauth2.jwt(jwt->jwt.decoder(jwtDecoder())));

		  http.addFilterBefore(new AuthTokenFilter(), BasicAuthenticationFilter.class);
	      return http.build();
	    	
	    	
	    }

	@Bean
	JwtDecoder jwtDecoder() {
		NimbusJwtDecoder jwtDecoder = (NimbusJwtDecoder) JwtDecoders.fromIssuerLocation(issuerUri);

		OAuth2TokenValidator<org.springframework.security.oauth2.jwt.Jwt> withIssuer = JwtValidators
				.createDefaultWithIssuer(issuerUri);

		OAuth2TokenValidator<org.springframework.security.oauth2.jwt.Jwt> withAudience = JwtValidators.createDefault();

		OAuth2TokenValidator<org.springframework.security.oauth2.jwt.Jwt> validator = new DelegatingOAuth2TokenValidator<>(
				withIssuer, withAudience);

		jwtDecoder.setJwtValidator(validator);

		return jwtDecoder;
	}

	@Bean
	public CorsConfigurationSource corsConfigurationSource() {
		CorsConfiguration configuration = new CorsConfiguration();
		configuration.setAllowedOrigins(Arrays.asList("*"));
		configuration.addAllowedHeader("*");
		configuration.addAllowedMethod("*");
		UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
		source.registerCorsConfiguration("/**", configuration);

		return source;
	}


    private static final String[] AUTH_WHITELIST = {
            // -- Swagger UI v2
            "/v2/api-docs",
			"/swagger-resources", "/swagger-resources/**", "/configuration/ui", "/configuration/security",
			"/swagger-ui.html", "/webjars/**",
			// -- Swagger UI v3 (OpenAPI)
			"/v3/api-docs/**", "/swagger-ui/**", "/compcasereporting/v1/casereportservice/liveness",
			"/compcasereporting/v1/casereportservice/readiness"
			// other public endpoints of your API may be appended to this array

    }; 

	@Bean
	public AuthTokenFilter authenticationJwtTokenFilter() {
		return new AuthTokenFilter();
	}

    
    
}