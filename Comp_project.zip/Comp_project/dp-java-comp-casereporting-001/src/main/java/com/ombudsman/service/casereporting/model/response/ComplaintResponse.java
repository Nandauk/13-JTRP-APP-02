package com.ombudsman.service.casereporting.model.response;

import java.util.List;

import com.ombudsman.service.casereporting.model.ComplaintLists;

public class ComplaintResponse extends GenericResponse{
	
	 private ComplainantStatistics statistics;
	
	private List<ComplaintDetails> complaintDetails;
	
	
	
	public List<ComplaintDetails> getComplaintDetails() {
		return complaintDetails;
	}
	public void setComplaintDetails(List<ComplaintDetails> complaintDetails) {
		this.complaintDetails = complaintDetails;
	}
	public ComplainantStatistics getStatistics() {
		return statistics;
	}
	public void setStatistics(ComplainantStatistics statistics) {
		this.statistics = statistics;
	}
	
	
}
