package com.ombudsman.service.casereporting.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.ombudsman.service.casereporting.model.ComplaintLists;
import com.ombudsman.service.casereporting.model.request.ComplainantRequest;

public interface CaseReportRepository extends JpaRepository<ComplaintLists, String>{

	@Query(value = "SELECT CASE WHEN COUNT(*) > 0 THEN 1 ELSE 0 END FROM dp_user_dpcomplainant where oid=:userOid", nativeQuery = true)
	int isUserExist(String userOid);

	@Query(value = "SELECT role_name FROM dp_complainant_roles where ad_user_id=:userOid", nativeQuery = true)
	String getRoleIdByUserId(String userOid);
	
}
