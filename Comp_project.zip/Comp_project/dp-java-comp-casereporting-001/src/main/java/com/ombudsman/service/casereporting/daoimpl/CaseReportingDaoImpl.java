package com.ombudsman.service.casereporting.daoimpl;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Repository;

import com.ombudsman.service.casereporting.dao.CaseReportingDao;
import com.ombudsman.service.casereporting.model.ComplaintLists;
import com.ombudsman.service.casereporting.model.request.ComplainantRequest;
import com.ombudsman.service.casereporting.model.response.ComplainantStatistics;
import com.ombudsman.service.casereporting.model.response.ComplaintDetails;
import com.ombudsman.service.casereporting.model.response.ComplaintResponse;
import com.ombudsman.service.casereporting.repository.CaseReportingRepository;
import com.ombudsman.service.casereporting.repository.CaseReportRepository;
@Repository
public class CaseReportingDaoImpl implements CaseReportingDao{

	@Autowired
    private JdbcTemplate jdbcTemplate;
	@Autowired
    private CaseReportingRepository caseReportingRepository;
	@Autowired
	private CaseReportRepository CaseReportRepository;

	 @Override
	    public Map<String, Object> getComplainantStatisticsByUserId(ComplainantRequest requestKey,UUID inputoid,String userRole) {
	        Map<String, Object> reqParam = new HashMap<>();
	        
	        reqParam.put("inputoid", inputoid.toString());
	        reqParam.put("input_role", userRole);
	        reqParam.put("caseNeedsAttention", requestKey.getCaseNeedsAttention());
	        reqParam.put("casesRepresenting", requestKey.getCasesRepresenting());
	        reqParam.put("searchBy", requestKey.getSearchby());
	        
	        return caseReportingRepository.getComplainantStatisticsByUserId(reqParam);
	    }

	@Override
	public int isUserExist(String userOid) {
		return CaseReportRepository.isUserExist(userOid);
	}

	@Override
	public String getRoleIdByUserId(String userOid) {
		return CaseReportRepository.getRoleIdByUserId(userOid);
	}
}
