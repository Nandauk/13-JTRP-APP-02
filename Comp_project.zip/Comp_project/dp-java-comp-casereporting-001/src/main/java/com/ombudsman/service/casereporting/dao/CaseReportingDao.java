package com.ombudsman.service.casereporting.dao;

import java.util.Map;
import java.util.UUID;

import com.ombudsman.service.casereporting.model.ComplaintLists;
import com.ombudsman.service.casereporting.model.request.ComplainantRequest;
import com.ombudsman.service.casereporting.model.response.ComplaintResponse;

public interface CaseReportingDao {


	Map<String, Object> getComplainantStatisticsByUserId(ComplainantRequest requestKey, UUID fromString, String userRole);


	int isUserExist(String userOid);


	String getRoleIdByUserId(String userOid);

}
