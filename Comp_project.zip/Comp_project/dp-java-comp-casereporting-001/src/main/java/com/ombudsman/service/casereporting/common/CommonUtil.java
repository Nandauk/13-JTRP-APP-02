/**
 * 
 */
package com.ombudsman.service.casereporting.common;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

@Configuration
public class CommonUtil {


	
	
	@Value("${app.session_flag}")
	public String sessionFlag;

		
	@Value("${app.session_base_url}")
	public String sessionBaseUrl;


	public String getSessionFlag() {
		return sessionFlag;
	}


	public void setSessionFlag(String sessionFlag) {
		this.sessionFlag = sessionFlag;
	}


	public String getSessionBaseUrl() {
		return sessionBaseUrl;
	}


	public void setSessionBaseUrl(String sessionBaseUrl) {
		this.sessionBaseUrl = sessionBaseUrl;
	}
	
	

}
