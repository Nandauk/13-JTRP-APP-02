package com.ombudsman.service.casereporting.exception;

import java.time.LocalDateTime;

import javax.security.auth.login.AccountNotFoundException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.reactive.result.method.annotation.ResponseEntityExceptionHandler;

@RestController
@ControllerAdvice

public class GlobalControllerExceptionHandler extends ResponseEntityExceptionHandler {

	private static final String RESPONDENT_1004 = "RESPONDENT_1004";
	@Autowired
	private MessageSource messageSource;
	private static final String API_ERROR_EXCEPTION_ACCOUNT_ID = "api.error.accountid";

	private static final Logger LOG = LogManager.getRootLogger();

	private static final String RESPONDENT_1002 = "RESPONDENT_1002";

	@ExceptionHandler({ SQLDataAccessException.class })
	public ResponseEntity<ApiError> handleSQLDataAccessException(SQLDataAccessException ex) {
		LOG.info("SQLException Occured:: URL= {}, complete errors::{}", ex.getMessage());
		ApiError err = new ApiError(LocalDateTime.now(), HttpStatus.INTERNAL_SERVER_ERROR,
				HttpStatusCode.valueOf(HttpStatus.INTERNAL_SERVER_ERROR.value()).toString(), "RESPONDENT_1001");
		return new ResponseEntity<>(err, HttpStatus.INTERNAL_SERVER_ERROR);
	}


	@ExceptionHandler({AccountNotFoundException.class})
	public ResponseEntity<ApiError> handleAccountNotFoundException(AccountNotFoundException exception) {
		LOG.info("Account not found for the account ids= {}", exception.getMessage());
		ApiError err = new ApiError(LocalDateTime.now(), HttpStatus.INTERNAL_SERVER_ERROR,String.valueOf(HttpStatus.INTERNAL_SERVER_ERROR.value()).toString(), "No account found");
		return new ResponseEntity<>(err, HttpStatus.INTERNAL_SERVER_ERROR);
	}

	@ExceptionHandler({ RecentCaseNotFoundException.class })
	public ResponseEntity<ApiError> handleRecentCaseNotFoundException(RecentCaseNotFoundException exception) {
		LOG.info("Organzation not found for the account ids= {}", exception.getMessage());
		ApiError err = new ApiError(LocalDateTime.now(), HttpStatus.NOT_FOUND,
				String.valueOf(HttpStatus.NOT_FOUND.value()),RESPONDENT_1004);
		return new ResponseEntity<>(err, HttpStatus.BAD_REQUEST);

	}

	@ExceptionHandler({ DashboardCaseException.class })
	public ResponseEntity<ApiError> handleRecentCaseNotFoundException(DashboardCaseException exception) {
		LOG.info("Account not found for the account ids= {}", exception.getMessage());
		ApiError err = new ApiError(LocalDateTime.now(), HttpStatus.PRECONDITION_FAILED,
				String.valueOf(HttpStatus.PRECONDITION_FAILED.value()), RESPONDENT_1004);
		return new ResponseEntity<>(err, HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler({ Exception.class })
	protected ResponseEntity<ApiError> handleException(Exception e) {

		ApiError err = new ApiError(LocalDateTime.now(), HttpStatus.PRECONDITION_FAILED,
				String.valueOf(HttpStatus.PRECONDITION_FAILED.value()), "Input is Invalid");
		LOG.info("Account not found for the account ids= {}", e.getMessage());
		return new ResponseEntity<>(err, HttpStatus.BAD_REQUEST);
	}

}
