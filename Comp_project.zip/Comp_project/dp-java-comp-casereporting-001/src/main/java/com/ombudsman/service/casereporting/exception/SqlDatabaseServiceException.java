package com.ombudsman.service.casereporting.exception;

public class SqlDatabaseServiceException extends RespondentsServiceExceptions {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public SqlDatabaseServiceException(String message,String exceptionMessage ) {
		super(message, "COMPLAINANT_BACKEND_1001",exceptionMessage);
	}
	

}
