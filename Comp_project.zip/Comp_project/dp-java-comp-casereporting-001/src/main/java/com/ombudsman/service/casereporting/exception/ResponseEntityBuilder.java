package com.ombudsman.service.casereporting.exception;

import org.springframework.http.ResponseEntity;

public class ResponseEntityBuilder {

	private ResponseEntityBuilder() {
		super();
	}

	public static ResponseEntity<Object> build(ApiError apiError) {
		return new ResponseEntity<>(apiError, apiError.getStatus());
	}

}
