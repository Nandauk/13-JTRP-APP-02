package com.ombudsman.service.casereporting.repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Map;
import java.util.UUID;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Component;
import com.ombudsman.service.casereporting.dao.CaseReportingDao;
import com.ombudsman.service.casereporting.model.ComplaintLists;
import com.ombudsman.service.casereporting.model.request.ComplainantRequest;
import com.ombudsman.service.casereporting.model.response.ComplainantStatistics;
import com.ombudsman.service.casereporting.model.response.ComplaintDetails;
import com.ombudsman.service.casereporting.model.response.ComplaintResponse;
import com.ombudsman.service.casereporting.repository.CaseReportingRepository;

import com.ombudsman.service.casereporting.exception.SQLDataAccessException;

@Component
public class CaseReportingRepository {
	
	@Autowired
    private JdbcTemplate jdbcTemplate;

    @Autowired
    private NamedParameterJdbcTemplate namedJdbcTemplate;

	Logger log = LogManager.getRootLogger();
	
	
	 public Map<String, Object> getComplainantStatisticsByUserId(Map<String, Object> reqParam) throws SQLDataAccessException {
	        
	        
	        final SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate)
	            .withProcedureName("prc_GetComplainantStatisticsByUserId");
	        SqlParameterSource in = new MapSqlParameterSource(reqParam);
	        log.debug(String.format("getComplainantStatisticsByUserId method parameters passing to Store procedure for multiple complainant :-{}", reqParam));
	        return simpleJdbcCall.execute(in);
	    }


	

}
