package com.ombudsman.service.casereporting.controller;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.ombudsman.service.casereporting.common.UserBean;
import com.ombudsman.service.casereporting.common.ValidateUserSession;
import com.ombudsman.service.casereporting.exception.UnAuthorisedException;
import com.ombudsman.service.casereporting.model.request.ComplainantRequest;
import com.ombudsman.service.casereporting.model.response.ComplaintResponse;
import com.ombudsman.service.casereporting.model.response.GenericResponse;
import com.ombudsman.service.casereporting.service.CaseReportingService;

@RestController
public class CaseReportingController {
	private static final Logger LOG = LogManager.getRootLogger();
	private String successMsg = "Success";
	private String successCode = "200";
	@Autowired
	private CaseReportingService caseReportingService;
	@Autowired
	ValidateUserSession validateUserSession;
	@Autowired
	UserBean userbean;
	private static final String INDIVIDUAL_COMPLAINANT = "Individual Complainant";
	private static final String ORGANISATION_COMPLAINANT = "Organisation Complainant";
		
	@PostMapping(value = "/compcasereporting/v1/casereportservice/getComplainantCases")
	public ResponseEntity<ComplaintResponse> getComplainantCaseListByUser(@RequestBody ComplainantRequest requestKey) throws UnAuthorisedException{
		
		LOG.debug("Complaint getComplainantCases Controller Method Started.CorrelationId:-{} OID:-{}",
				userbean.getCorrelationId(), userbean.getUserObjectId());

		ComplaintResponse result = null;
		
		if (validateUserSession.isValidSession() && (userbean.getRoles().contains(INDIVIDUAL_COMPLAINANT)
				|| userbean.getRoles().contains(ORGANISATION_COMPLAINANT))) {
		result=caseReportingService.getComplainantCaseListByUser(requestKey,userbean.getUserObjectId(),userbean.getRoles());
		if(result != null) {
			result.setStatus(successCode);
			result.setMessage(successMsg);
		}
		
		LOG.debug("Complaint getComplainantCases Controller Method Ended.CorrelationId:-{} OID:-{}",
				userbean.getCorrelationId(), userbean.getUserObjectId());
		
		return new ResponseEntity<>(result, HttpStatus.OK);
		}
		return new ResponseEntity<>(result, HttpStatus.UNAUTHORIZED);
	}
	
	@GetMapping(value = "/compcasereporting/v1/casereportservice/liveness")
	public ResponseEntity<GenericResponse> getLiveHealthCheck() {
		final GenericResponse result = new GenericResponse();
		result.setMessage(LocalDateTime.now().toString());
		LOG.info(String.format("liveness started with current time: %s", LocalDateTime.now()));		
		result.setStatus("Available");
		return new ResponseEntity<>(result, HttpStatus.OK);
	}
	@GetMapping(value = "/compcasereporting/v1/casereportservice/readiness")
	public ResponseEntity<GenericResponse> getRedinessHealthCheck() {
		final GenericResponse result = new GenericResponse();
		result.setMessage(LocalDateTime.now().toString());
		LOG.info(String.format("readiness started with current time: %s", LocalDateTime.now()));	
		result.setStatus("Available");
		return new ResponseEntity<>(result, HttpStatus.OK);
	}


	
}
