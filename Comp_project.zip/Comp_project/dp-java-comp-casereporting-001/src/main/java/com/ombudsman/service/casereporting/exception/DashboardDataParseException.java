package com.ombudsman.service.casereporting.exception;

public class DashboardDataParseException extends Exception {
	private static final long serialVersionUID = 1L;

	public DashboardDataParseException(String orgName) {
		super(orgName);
	}

}
