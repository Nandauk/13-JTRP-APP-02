package com.ombudsman.service.casereporting.service;

import com.ombudsman.service.casereporting.model.response.GenericResponse;

public interface ILoginService {	
	public GenericResponse addUserSessionEntry() throws Exception;


	GenericResponse updateUserSessionEntry() throws Exception;


	GenericResponse logoutForUserSession() throws Exception;
	GenericResponse getSessionTokenStatus() throws Exception;

}
