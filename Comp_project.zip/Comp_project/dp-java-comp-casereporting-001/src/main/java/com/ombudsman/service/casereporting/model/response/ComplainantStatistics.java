package com.ombudsman.service.casereporting.model.response;

public class ComplainantStatistics {

	private int totalNoOfComplaints;
    private int caseNeedAttention;
    private int totalNoOfRepresenting;
	public int getTotalNoOfComplaints() {
		return totalNoOfComplaints;
	}
	public void setTotalNoOfComplaints(int totalNoOfComplaints) {
		this.totalNoOfComplaints = totalNoOfComplaints;
	}
	public int getCaseNeedAttention() {
		return caseNeedAttention;
	}
	public void setCaseNeedAttention(int caseNeedAttention) {
		this.caseNeedAttention = caseNeedAttention;
	}
	public int getTotalNoOfRepresenting() {
		return totalNoOfRepresenting;
	}
	public void setTotalNoOfRepresenting(int totalNoOfRepresenting) {
		this.totalNoOfRepresenting = totalNoOfRepresenting;
	}
    
    
}
