package com.ombudsman.service.casereporting.model;

import com.ombudsman.service.casereporting.model.response.GenericResponse;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.transaction.Transactional;

@Entity
@Table(name = "incident")
@Transactional
public class ComplaintLists extends GenericResponse {
	
	@Id
	@Column(name = "incidentid")
	private String incidentid;
	@Column(name = "ticketnumber")
	private String caseReference;
	public String getIncidentid() {
		return incidentid;
	}
	public void setIncidentid(String incidentid) {
		this.incidentid = incidentid;
	}
	private String caseProgressName;
	private String forProduct;
	private String raisedAgainst;
	public String getCaseReference() {
		return caseReference;
	}
	public void setCaseReference(String caseReference) {
		this.caseReference = caseReference;
	}
	public String getCaseProgressName() {
		return caseProgressName;
	}
	public void setCaseProgressName(String caseProgressName) {
		this.caseProgressName = caseProgressName;
	}
	public String getForProduct() {
		return forProduct;
	}
	public void setForProduct(String forProduct) {
		this.forProduct = forProduct;
	}
	public String getRaisedAgainst() {
		return raisedAgainst;
	}
	public void setRaisedAgainst(String raisedAgainst) {
		this.raisedAgainst = raisedAgainst;
	}
	
	
}
