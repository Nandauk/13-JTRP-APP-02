package com.ombudsman.service.casereporting.model.response;

import java.io.Serializable;

public class ComplaintDetails implements Serializable {
	
	    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
		private String caseReference;
	    private String caseProgressName;
	    private String forProduct;
	    private String raisedAgainst;
	    private String incidentId;
	    
	    
	   
		public String getIncidentId() {
			return incidentId;
		}
		public void setIncidentId(String incidentId) {
			this.incidentId = incidentId;
		}
		public String getCaseReference() {
			return caseReference;
		}
		public void setCaseReference(String caseReference) {
			this.caseReference = caseReference;
		}
		public String getCaseProgressName() {
			return caseProgressName;
		}
		public void setCaseProgressName(String caseProgressName) {
			this.caseProgressName = caseProgressName;
		}
		public String getForProduct() {
			return forProduct;
		}
		public void setForProduct(String forProduct) {
			this.forProduct = forProduct;
		}
		public String getRaisedAgainst() {
			return raisedAgainst;
		}
		public void setRaisedAgainst(String raisedAgainst) {
			this.raisedAgainst = raisedAgainst;
		}
		
		public static long getSerialversionuid() {
			return serialVersionUID;
		}
		
	    
	    

}
