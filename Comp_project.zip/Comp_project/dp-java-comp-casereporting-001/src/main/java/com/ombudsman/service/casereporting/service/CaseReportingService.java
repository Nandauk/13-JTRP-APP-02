package com.ombudsman.service.casereporting.service;

import java.util.List;
import java.util.Map;

import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;

import com.ombudsman.service.casereporting.exception.UnAuthorisedException;
import com.ombudsman.service.casereporting.model.ComplaintLists;
import com.ombudsman.service.casereporting.model.request.ComplainantRequest;
import com.ombudsman.service.casereporting.model.response.ComplaintResponse;

public interface CaseReportingService {


	ComplaintResponse getComplainantCaseListByUser(ComplainantRequest requestKey,String userOid, List<String> list) throws UnAuthorisedException;
	
	
}
