package com.ombudsman.service.casereporting.model.request;

public class ComplainantRequest {
	private String caseNeedsAttention;
	private String casesRepresenting;
	private String searchby;
	
	public String getSearchby() {
		return searchby;
	}
	public void setSearchby(String searchby) {
		this.searchby = searchby;
	}
	public String getCaseNeedsAttention() {
		return caseNeedsAttention;
	}
	public void setCaseNeedsAttention(String caseNeedsAttention) {
		this.caseNeedsAttention = caseNeedsAttention;
	}
	public String getCasesRepresenting() {
		return casesRepresenting;
	}
	public void setCasesRepresenting(String casesRepresenting) {
		this.casesRepresenting = casesRepresenting;
	}
	

}
