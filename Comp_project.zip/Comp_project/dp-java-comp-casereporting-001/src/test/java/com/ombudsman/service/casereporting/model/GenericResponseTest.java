package com.ombudsman.service.casereporting.model;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import com.ombudsman.service.casereporting.model.response.GenericResponse;


@ExtendWith(SpringExtension.class)
public class GenericResponseTest {
	
	@InjectMocks
	private GenericResponse genericResponse;
	
	@BeforeEach
	public void setUp() {
		genericResponse=new GenericResponse();
	}
	@Test
	public void responsetest() {
		String status ="200";
		String message= "Success";
		genericResponse.setStatus(status);
		genericResponse.setMessage(message);
		
		assertEquals(status,genericResponse.getStatus());
		assertEquals(message,genericResponse.getMessage());
	}

}
