package com.ombudsman.service.casereporting.serviceimpl;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.ombudsman.service.casereporting.controller.CaseReportingController;
import com.ombudsman.service.casereporting.dao.CaseReportingDao;
import com.ombudsman.service.casereporting.exception.UnAuthorisedException;
import com.ombudsman.service.casereporting.model.request.ComplainantRequest;
import com.ombudsman.service.casereporting.model.response.ComplaintResponse;
import com.ombudsman.service.casereporting.model.response.GenericResponse;


@ExtendWith(SpringExtension.class)
public class CaseReportingServiceImplTest {

	@InjectMocks
	CaseReportingServiceImpl caseReportingServiceImpl;
	@Mock
	private CaseReportingDao caseReportingDao;
	
	@Test
	public void testGetComplaintCaseByUser_Success() throws UnAuthorisedException {
		ComplainantRequest request = new ComplainantRequest();
		String userOid="4ac7cdae-cd4e-4d21-8dd4-5063df90de74";
		List<String> roles=List.of("individual");
		Map<String,Object> resultSet1Row=Map.of("totalcases",5,"noofcaseNeedAttention",2,"noofcaseRepresenting",1);
		
		Map<String,Object> resultSet2Row=Map.of("caseReference","PNx-123","caseProgressName","UnderInvertigation","forProduct","Product insurance","raisedAgainst","Com insurance","incidentid","INC456");
		
		Map<String,Object> dataMap=new HashMap<>();
		
		dataMap.put("#result-set-1", List.of(resultSet1Row));
		dataMap.put("#result-set-2", List.of(resultSet2Row));
		
		Mockito.when(caseReportingDao.isUserExist(userOid)).thenReturn(1);
		Mockito.when(caseReportingDao.getComplainantStatisticsByUserId(Mockito.any(), Mockito.any(), Mockito.any())).thenReturn(dataMap);
		
		ComplaintResponse response= caseReportingServiceImpl.getComplainantCaseListByUser(request, userOid, roles);
		
		assertEquals("200",response.getStatus());
		assertEquals("Success",response.getMessage());
		assertNotNull(response.getStatistics());
		assertEquals(5,response.getStatistics().getTotalNoOfComplaints());
	}
	
	@Test
	public void testgetComplaintCaseByUser_Unauthorised() {
		ComplainantRequest request = new ComplainantRequest();
		String userOid="4ac7cdae-cd4e-4d21-8dd4-5063df90de74";
		List<String> roles=List.of("individual");
		
		Mockito.when(caseReportingDao.isUserExist(userOid)).thenReturn(0);
		
		assertThrows(UnAuthorisedException.class, ()-> caseReportingServiceImpl.getComplainantCaseListByUser(request, userOid, roles));
	}
}
