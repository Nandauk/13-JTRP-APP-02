package com.ombudsman.service.casereporting.model;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.ombudsman.service.casereporting.model.request.ComplainantRequest;


@ExtendWith(SpringExtension.class)
public class ComplainantRequestTest {

	@InjectMocks
	private ComplainantRequest complainantRequest;
	
	@BeforeEach
	public void setUp() {
		complainantRequest=new ComplainantRequest();
	}
	
	@Test
	public void testTotalNoOfCase() {
		String num="#";
		complainantRequest.setCaseNeedsAttention(num);
		assertEquals(num,complainantRequest.getCaseNeedsAttention());
	}
	@Test
	public void caserepresenting() {
		String num="#";
		complainantRequest.setCasesRepresenting(num);
		assertEquals(num,complainantRequest.getCasesRepresenting());
	}
	@Test
	public void testSearchBy() {
		String num="#";
		complainantRequest.setSearchby(num);
		assertEquals(num,complainantRequest.getSearchby());
	}
}
