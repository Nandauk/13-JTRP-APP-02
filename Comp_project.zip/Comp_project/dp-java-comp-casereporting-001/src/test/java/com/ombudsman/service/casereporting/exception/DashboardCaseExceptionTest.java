package com.ombudsman.service.casereporting.exception;


import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;

@ExtendWith(SpringExtension.class)
public class DashboardCaseExceptionTest {

	 @Test
	    public void testConstructor() {
	        String orgName = "Test Organization";

	        DashboardCaseException exception = new DashboardCaseException(orgName);

	        assertEquals(orgName, exception.getMessage());
	    }
}
