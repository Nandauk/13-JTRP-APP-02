package com.ombudsman.service.casereporting.daoimpl;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.ombudsman.service.casereporting.model.request.ComplainantRequest;
import com.ombudsman.service.casereporting.repository.CaseReportRepository;
import com.ombudsman.service.casereporting.repository.CaseReportingRepository;


@ExtendWith(SpringExtension.class)
public class CaseReportingDaoImplTest {
	@InjectMocks
	CaseReportingDaoImpl testInstance;
	@Mock
    private JdbcTemplate jdbcTemplate;
	@Mock
    private CaseReportingRepository caseReportingRepository;
	@Mock
	private CaseReportRepository caseReportRepository;
	
	@BeforeEach
	public void setUp() {
		MockitoAnnotations.openMocks(this);
	}
	
	@Test
	public void testGetComplaintStatByUserId() {
		UUID inputid=UUID.randomUUID();
		String userRole="admin";
		ComplainantRequest mockRequest=mock(ComplainantRequest.class);
		when(mockRequest.getCaseNeedsAttention()).thenReturn("yes");
		when(mockRequest.getCasesRepresenting()).thenReturn("#");
        when(mockRequest.getSearchby()).thenReturn("bank");
        Map<String,Object> expectedmap=new HashMap<>();
        expectedmap.put("total", 5);
        when(caseReportingRepository.getComplainantStatisticsByUserId(Mockito.anyMap())).thenReturn(expectedmap);
        
        Map<String,Object> result=testInstance.getComplainantStatisticsByUserId(mockRequest, inputid, userRole);
        
        assertEquals(expectedmap,result);
        verify(caseReportingRepository).getComplainantStatisticsByUserId(Mockito.anyMap());
        
	}

	@Test
	public void testisuserExist() {
		
		String userid="user123";
		when(caseReportRepository.isUserExist(userid)).thenReturn(1);
		int result = testInstance.isUserExist(userid);
		assertEquals(1,result);
		verify(caseReportRepository).isUserExist(userid);
		
	}
	
	@Test
	public void testGetroleIdByUserId() {
		
		String userid="user12345";
		when(caseReportRepository.getRoleIdByUserId(userid)).thenReturn("private individual");
		String role=testInstance.getRoleIdByUserId(userid);
		assertEquals("private individual",role);
		verify(caseReportRepository).getRoleIdByUserId(userid);
	}
     
	
}
