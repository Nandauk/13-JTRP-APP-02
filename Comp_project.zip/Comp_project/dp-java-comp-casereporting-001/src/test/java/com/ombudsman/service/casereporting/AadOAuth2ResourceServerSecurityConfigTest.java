//package com.ombudsman.service.casereporting;
//
//import static org.junit.jupiter.api.Assertions.assertNotNull;
//
//import org.junit.jupiter.api.Test;
//import org.junit.jupiter.api.extension.ExtendWith;
//import org.mockito.InjectMocks;
//import org.mockito.Mock;
//import org.springframework.security.config.annotation.web.builders.HttpSecurity;
//import org.springframework.test.context.junit.jupiter.SpringExtension;
//import org.springframework.web.context.WebApplicationContext;
//import org.springframework.web.cors.CorsConfiguration;
//@ExtendWith(SpringExtension.class)
// class AadOAuth2ResourceServerSecurityConfigTest {
//	
//	@InjectMocks
//	private AadOAuth2ResourceServerSecurityConfig testInstance;
//	@Mock
//    private WebApplicationContext context;
//	@Mock
//	HttpSecurity mMockHttpSecurity;
//	@Mock
//	CorsConfiguration mMockCorsConfiguration;
//	@Mock
//	AuthTokenFilter mMockTokenFilter;
//
//
//	
//	/**@Test
//	void test() throws Exception {
//		//HttpSecurity http = context.getBean(SecurityFilterChain.class).
//		
//		//when(mMockHttpSecurity.authorizeHttpRequests()).thenReturn(mMockAuthorizationManagerRequestMatcherRegistry);
//		testInstance.filterChain(mMockHttpSecurity);
//	}*/
//	@Test
//	void testCorsConfigurationSource(){
//		testInstance.corsConfigurationSource();
//		assertNotNull(mMockCorsConfiguration);
//		
//	}
//	@Test
//	void shouldTestauthenticationJwtTokenFilter() {
//		testInstance.authenticationJwtTokenFilter();
//		assertNotNull(mMockTokenFilter);
//
//	}
//
//}
