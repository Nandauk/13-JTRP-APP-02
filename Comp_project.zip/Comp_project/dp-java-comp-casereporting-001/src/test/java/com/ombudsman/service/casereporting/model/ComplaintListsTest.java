package com.ombudsman.service.casereporting.model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.springframework.test.context.junit.jupiter.SpringExtension;


@ExtendWith(SpringExtension.class)
public class ComplaintListsTest {

	@InjectMocks
	private ComplaintLists complaintLists;
	
	@BeforeEach
	public void setUp() {
		complaintLists=new ComplaintLists();
	}
	@Test
	public void testInscidentNumber() {
		String incidentNum="2344sdfs";
		complaintLists.setIncidentid(incidentNum);
		assertEquals(incidentNum,complaintLists.getIncidentid());
	}
	@Test
	public void testticketNumber() {
		String incidentNum="PNX-219";
		complaintLists.setCaseReference(incidentNum);
		assertEquals(incidentNum,complaintLists.getCaseReference());
	}
	@Test
	public void testcaseProgress() {
		String incidentNum="Under investiogation";
		complaintLists.setCaseProgressName(incidentNum);
		assertEquals(incidentNum,complaintLists.getCaseProgressName());
	}
	@Test
	public void testforProduct() {
		String incidentNum="Nank insurance";
		complaintLists.setForProduct(incidentNum);
		assertEquals(incidentNum,complaintLists.getForProduct());
	}
	@Test
	public void testRaisedAgainst() {
		String incidentNum="Bank";
		complaintLists.setRaisedAgainst(incidentNum);
		assertEquals(incidentNum,complaintLists.getRaisedAgainst());
	}
}
