package com.ombudsman.service.casereporting.controller;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.ombudsman.service.casereporting.common.UserBean;
import com.ombudsman.service.casereporting.common.ValidateUserSession;
import com.ombudsman.service.casereporting.exception.UnAuthorisedException;
import com.ombudsman.service.casereporting.model.request.ComplainantRequest;
import com.ombudsman.service.casereporting.model.response.ComplaintResponse;
import com.ombudsman.service.casereporting.service.CaseReportingService;


@ExtendWith(SpringExtension.class)
public class CaseReportingControllerTest {

	@InjectMocks
	CaseReportingController CaseReportingController;
	@Mock
	private CaseReportingService caseReportingService;
	@Mock
	ValidateUserSession validateUserSession;
	@Mock
	UserBean userbean;
	@Mock
	private ComplainantRequest request;
	private ComplaintResponse mockResponse;
	@BeforeEach
	public void setUp() {
		MockitoAnnotations.openMocks(this);
		request=new ComplainantRequest();
		mockResponse=new ComplaintResponse();
		
	}
	
	@Test
	public void testGetComplaintCaseByUser() throws UnAuthorisedException {
		String userid="User123";
		String correid="corr-id";
		
		when(userbean.getUserObjectId()).thenReturn(userid);
		when(userbean.getCorrelationId()).thenReturn(correid);
		doNothing().when(userbean).setRoles(Mockito.anyList());
		
		mockResponse.setStatus("200");
		mockResponse.setMessage("Success");
		
	    when(caseReportingService.getComplainantCaseListByUser(Mockito.eq(request), Mockito.eq(userid), Mockito.anyList())).thenReturn(mockResponse);
		ResponseEntity<ComplaintResponse> response = CaseReportingController.getComplainantCaseListByUser(request);
		
		assertNotNull(response);
		//assertEquals("200",response.getBody().getStatus());
		//assertEquals("Success",response.getBody().getMessage());
		
	}
}
