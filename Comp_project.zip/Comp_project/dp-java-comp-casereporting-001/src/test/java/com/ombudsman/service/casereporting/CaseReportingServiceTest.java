package com.ombudsman.service.casereporting;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;

import com.microsoft.applicationinsights.attach.ApplicationInsights;

class CaseReportingServiceTest {
	@InjectMocks
	private CaseReportingApplication testInstance;
	@Mock
	private ApplicationInsights applicationInsights;


	@Test
	void testAttachToApplicationInsights() {
		
	}

}
