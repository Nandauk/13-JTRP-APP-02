package com.ombudsman.service.casereporting.common;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.springframework.context.MessageSource;
import org.springframework.context.support.ReloadableResourceBundleMessageSource;
import org.springframework.test.context.junit.jupiter.SpringExtension;

@ExtendWith(SpringExtension.class)
public class AppConfigTest {

	@InjectMocks
	@Spy
	AppConfiguration testInstance;
	@Mock
	MessageSource mMockMessageSource;
	@Mock
	ReloadableResourceBundleMessageSource ReloadableResourceBundleMessageSource;
	
	

    @Test
    public void testMessageSourceConfiguration() {
        AppConfiguration appConfiguration = new AppConfiguration();

        MessageSource messageSource = appConfiguration.messageSource();

        assertNotNull(messageSource);
        assertEquals(ReloadableResourceBundleMessageSource.class, messageSource.getClass());
    }
}
