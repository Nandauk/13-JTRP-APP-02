package com.ombudsman.service.casereporting.exception;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.test.context.junit.jupiter.SpringExtension;
@ExtendWith(SpringExtension.class)
public class RespondentNumberFormatExceptionTest {
	
	
	 @Test
	   public void testResourceNotFoundException() {
	        String orgName = "Test organization";
	        
	        RespondentNumberFormatException exception = new RespondentNumberFormatException(orgName);

	        assertEquals(orgName, exception.getMessage());
	    }

}
