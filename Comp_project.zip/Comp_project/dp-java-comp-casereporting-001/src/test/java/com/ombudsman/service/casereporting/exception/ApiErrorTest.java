package com.ombudsman.service.casereporting.exception;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.time.LocalDateTime;

import org.mockito.InjectMocks;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.test.context.junit.jupiter.SpringExtension;

@ExtendWith(SpringExtension.class)
public class ApiErrorTest {
	
	
	 @Test
	    public void testApiErrorConstructor() {
	        LocalDateTime timestamp = LocalDateTime.of(2023, 1, 5, 10, 30, 0);
	        HttpStatus status = HttpStatus.BAD_REQUEST;
	        String errorCode = "ERR123";
	        String errorMessage = "Invalid input";

	        ApiError apiError = new ApiError(timestamp, status, errorMessage, errorCode);

	        assertEquals(timestamp, apiError.getTimestamp());
	        assertEquals(status, apiError.getStatus());
	        assertEquals(errorCode, apiError.getErrorCode());
	        assertEquals(errorMessage, apiError.getErrorMessage());
	    }

	
	 @Test
	    public void testApiErrorSettersAndGetters() {
	        ApiError apiError = new ApiError(null, null, null, null);

	        LocalDateTime timestamp = LocalDateTime.of(2023, 1, 5, 10, 30, 0);
	        HttpStatus status = HttpStatus.INTERNAL_SERVER_ERROR;
	        String errorCode = "ERR500";
	        String errorMessage = "Internal server error";

	        apiError.setTimestamp(timestamp);
	        apiError.setStatus(status);
	        apiError.setErrorCode(errorCode);
	        apiError.setErrorMessage(errorMessage);

	        assertEquals(timestamp, apiError.getTimestamp());
	        assertEquals(status, apiError.getStatus());
	        assertEquals(errorCode, apiError.getErrorCode());
	        assertEquals(errorMessage, apiError.getErrorMessage());
	    }

}
