package com.ombudsman.service.casereporting.model;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import com.ombudsman.service.casereporting.model.response.ComplainantStatistics;


@ExtendWith(SpringExtension.class)
public class ComplainantStatisticsTest {
	
	@InjectMocks
	private ComplainantStatistics ComplainantStatistics;
	
	@BeforeEach
	public void setUp() {
		ComplainantStatistics=new ComplainantStatistics();
	}
	
	@Test
	public void testTotalNoOfCase() {
		int num=5;
		ComplainantStatistics.setTotalNoOfComplaints(num);
		assertEquals(num,ComplainantStatistics.getTotalNoOfComplaints());
	}
	@Test
	public void testcaseneedattendtion() {
		int num=2;
		ComplainantStatistics.setCaseNeedAttention(num);
		assertEquals(num,ComplainantStatistics.getCaseNeedAttention());
	}
	@Test
	public void testcaserepresent() {
		int num=1;
		ComplainantStatistics.setTotalNoOfRepresenting(num);
		assertEquals(num,ComplainantStatistics.getTotalNoOfRepresenting());
	}

}
