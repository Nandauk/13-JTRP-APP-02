package com.ombudsman.service.casereporting.common;

import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.web.reactive.function.client.WebClient;

@ExtendWith(SpringExtension.class)
class CaseReportingWebClientTest {
	@Mock
	UserBean mMockUserbean;

	@Mock
	CommonUtil mMockCommonUtil;
	@Mock
	WebClient mMockWebclient;

	@Mock
	private WebClient.RequestBodyUriSpec headerSpec;


	@InjectMocks
	private CaseReportingWebClient testInstance;

	@Test
	void shouldGetResponseForSessionActivity() throws Exception {
		try {
			mMockCommonUtil.sessionBaseUrl = "https://portal-dev.financial-ombudsman.org.uk/test";		
			when(mMockUserbean.getUserObjectId()).thenReturn("obj");
			when(mMockUserbean.getAuthToken()).thenReturn("token");
			
			testInstance.getResponseForSessionActivity("login");
			// verify(mMockUserbean).getUserObjectId();
		} catch (Exception ex) {		

		}

	}

}
