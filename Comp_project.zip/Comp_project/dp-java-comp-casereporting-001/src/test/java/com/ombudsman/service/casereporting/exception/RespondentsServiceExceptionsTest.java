package com.ombudsman.service.casereporting.exception;



import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;
@ExtendWith(SpringExtension.class)
public class RespondentsServiceExceptionsTest {
	
	
	 @Test
	    public void testConstructor() {
	        String message = "Test exception";
	        String code = "123";
	        String exceptionMessage = "Test exception message";
	        StackTraceElement[] stackTraceElements = new StackTraceElement[0];

	        RespondentsServiceExceptions exception = new RespondentsServiceExceptions(message, code, exceptionMessage);

	        assertEquals(message, exception.getMessage());
	        assertEquals(code, exception.getCode());
	        assertEquals(exceptionMessage, exception.getExceptionMessage());
	    }

}
