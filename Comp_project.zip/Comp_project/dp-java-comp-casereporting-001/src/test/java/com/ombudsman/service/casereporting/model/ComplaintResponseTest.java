package com.ombudsman.service.casereporting.model;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.List;

import org.assertj.core.util.Arrays;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import com.ombudsman.service.casereporting.model.response.ComplainantStatistics;
import com.ombudsman.service.casereporting.model.response.ComplaintDetails;
import com.ombudsman.service.casereporting.model.response.ComplaintResponse;


@ExtendWith(SpringExtension.class)
public class ComplaintResponseTest {
	@InjectMocks
	private ComplaintResponse complaintResponse;
	
	@Mock
	 private ComplainantStatistics statistics;
	@Mock
		private List<ComplaintDetails> complaintDetails;
	@Mock
	private ComplaintDetails details1;
		
		@BeforeEach
		public void setUp() {
			complaintResponse=new ComplaintResponse();
			details1=new ComplaintDetails();
			complaintDetails.add(details1);
		}
		
		@Test
		public void testcomplaintStat() {
			
			complaintResponse.setStatistics(statistics);
			assertEquals(statistics,complaintResponse.getStatistics());
			
		}
		
		@Test
		public void testComplaintDetails() {
			details1=new ComplaintDetails();
			complaintDetails.add(details1);
			complaintResponse.setComplaintDetails(complaintDetails);
			assertEquals(complaintDetails,complaintResponse.getComplaintDetails());
			
		}

}
