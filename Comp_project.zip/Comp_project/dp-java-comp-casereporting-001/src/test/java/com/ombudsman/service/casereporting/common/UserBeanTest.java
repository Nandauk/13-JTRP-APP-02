package com.ombudsman.service.casereporting.common;

import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.test.context.junit.jupiter.SpringExtension;

@ExtendWith(SpringExtension.class)
class UserBeanTest {

	@Value("${spring.security.oauth2.resourceserver.jwt.jwk-set-uri}")
	private String jwkUri;

	@InjectMocks
	private UserBean testInstance;

	@Test
	void testUserBeanProperties() {
		// UserBean userBean = new UserBean();
		testInstance.setUserObjectId("user123");
		testInstance.setAuthToken("token123");
		testInstance.setCorrelationId("correlation123");
		testInstance.setName("John Doe");
		testInstance.setGroups(List.of("group1", "group2"));
		testInstance.setExp(1234567890L);
		testInstance.getJwkUri();
		// when()

		String authToken = testInstance.getAuthToken();
		String userObject = testInstance.getUserObjectId();
		String corecationId = testInstance.getCorrelationId();
		String name = testInstance.getName();
		List<String> groups = testInstance.getGroups();
		long exp = testInstance.getExp();

		assertNotNull(authToken);
		assertNotNull(userObject);
		assertNotNull(corecationId);
		assertNotNull(name);
		assertNotNull(groups);

	}

}
