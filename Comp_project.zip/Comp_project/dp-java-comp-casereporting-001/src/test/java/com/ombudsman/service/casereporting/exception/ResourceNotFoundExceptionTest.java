package com.ombudsman.service.casereporting.exception;

import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;
@ExtendWith(SpringExtension.class)
public class ResourceNotFoundExceptionTest {
	
	
	 @Test
	   public void testResourceNotFoundException() {
	        String orgName = "Test organization";
	        
	        ResourceNotFoundException exception = new ResourceNotFoundException(orgName);

	        assertEquals(orgName, exception.getMessage());
	    }

}
