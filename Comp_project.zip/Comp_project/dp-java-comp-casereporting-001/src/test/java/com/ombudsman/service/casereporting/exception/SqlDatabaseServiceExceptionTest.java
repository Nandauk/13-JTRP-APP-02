package com.ombudsman.service.casereporting.exception;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit.jupiter.SpringExtension;
@ExtendWith(SpringExtension.class)
public class SqlDatabaseServiceExceptionTest {
	
	
	  @Test
	    public void testConstructor() {
	        String message = "Test message";
	        String exceptionMessage = "Exception details";
	        StackTraceElement[] stackTraceElements = new StackTraceElement[0];
	        

	        SqlDatabaseServiceException exception = new SqlDatabaseServiceException(message, exceptionMessage);

	        assertEquals(message, exception.getMessage());
	        assertEquals("COMPLAINANT_BACKEND_1001", exception.getCode());
	        assertEquals(exceptionMessage, exception.getExceptionMessage());
	      //  assertEquals(stackTraceElements, exception.getStackTrace());
	    }

}
