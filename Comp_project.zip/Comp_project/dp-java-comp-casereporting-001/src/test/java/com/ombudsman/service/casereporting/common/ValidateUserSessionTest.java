package com.ombudsman.service.casereporting.common;

import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.ombudsman.service.casereporting.model.response.GenericResponse;
import com.ombudsman.service.casereporting.service.ILoginService;

@ExtendWith(SpringExtension.class)
public class ValidateUserSessionTest {
	public static final String VALID="valid";
	@InjectMocks
	public ValidateUserSession testInstance;
	@Mock
	CommonUtil commonUtil;
	@Mock
	ILoginService mMockILoginService;
	@Mock
	GenericResponse mMockGenericResponse;
	

    @Test
    public void testIsValidSession_ValidSession() throws Exception {
      // when(commonUtil.sessionFlag).thenReturn("true");
    	//commonUtil.sessionFlag="true";
    	Boolean flag= testInstance.isValidSession();
    	when(mMockILoginService.getSessionTokenStatus()).thenReturn(mMockGenericResponse);
    	when(mMockGenericResponse.getStatus()).thenReturn(VALID);
       
        //Mockito.verify(mockLoginService, Mockito.times(1)).getSessionTokenStatus();
       // Mockito.verify(mockResponse, Mockito.times(1)).getStatus();
    }

    
}
