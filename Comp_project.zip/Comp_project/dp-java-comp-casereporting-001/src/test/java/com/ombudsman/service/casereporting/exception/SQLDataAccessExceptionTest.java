package com.ombudsman.service.casereporting.exception;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.time.LocalDateTime;
import java.util.Locale;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit.jupiter.SpringExtension;
@ExtendWith(SpringExtension.class)
public class SQLDataAccessExceptionTest {

	 @Test
	    public void testConstructor() {
	        String orgName = "My Organization";

	        SQLDataAccessException exception = new SQLDataAccessException(orgName);

	        assertEquals(orgName, exception.getMessage());
	    }
}
