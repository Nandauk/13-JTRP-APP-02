package com.ombudsman.service.job.sessionscheduler.daoimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ombudsman.service.job.sessionscheduler.common.dto.SessionActivity;
import com.ombudsman.service.job.sessionscheduler.common.dto.SessionHistory;
import com.ombudsman.service.job.sessionscheduler.dao.SessionSchedularDao;
import com.ombudsman.service.job.sessionscheduler.repository.SessionActivityRepository;
import com.ombudsman.service.job.sessionscheduler.repository.SessionHistoryRepository;


@Repository
public class SessionSchedularDaoImpl implements SessionSchedularDao {

	SessionActivityRepository sessionActivityRepository;

	SessionHistoryRepository sessionHistoryRepository;
	
	@Autowired
	public SessionSchedularDaoImpl(SessionActivityRepository sessionActivityRepository, SessionHistoryRepository sessionHistoryRepository) {
		super();
		this.sessionActivityRepository = sessionActivityRepository;
		this.sessionHistoryRepository = sessionHistoryRepository;
	}
	
	@Override
	public void deleteRecordsbyTime() {

		sessionActivityRepository.deleteRecordsbyTime();

	}


	@Override
	public void deleteInvalidatedRecords() {
		sessionActivityRepository.deleteInvalidatedRecords();

	}

	@Override
	public List<SessionActivity> getInvalidSessionsforInactiveTime() {
		return sessionActivityRepository.getInvalidSessionsforInactiveTime();
	}

	@Override
	public void saveAllRecords(List<SessionHistory> records) {
		sessionHistoryRepository.saveAll(records);

	}



}