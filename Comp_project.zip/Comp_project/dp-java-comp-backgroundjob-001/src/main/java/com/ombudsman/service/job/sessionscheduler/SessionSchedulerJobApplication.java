package com.ombudsman.service.job.sessionscheduler;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;

import com.ombudsman.service.job.sessionscheduler.common.dto.SessionActivity;
import com.ombudsman.service.job.sessionscheduler.common.dto.SessionHistory;
import com.ombudsman.service.job.sessionscheduler.services.SessionSchedulerService;

@SpringBootApplication
@EnableScheduling
@EnableAsync
public class SessionSchedulerJobApplication {

	private static final String INVALID = "invalid";

	private static final String DP_JAVA_COMP_BACKGROUNDJOB_001 = "dp-java-comp-backgroundjob-001";

	SessionSchedulerService sessionSchedulerService;

	private static final Logger LOG = LogManager.getRootLogger();

	public static void main(String[] args) {

		SpringApplication.run(SessionSchedulerJobApplication.class, args);

	}

	@Autowired
	public SessionSchedulerJobApplication(SessionSchedulerService sessionSchedulerService) {
		super();
		this.sessionSchedulerService = sessionSchedulerService;

	}
	
//	 Every 2 hours - records will be deleted after 20 minutes
//	cron = "${sqlInvalidateRecords_Scheduler_cron}", zone = "UTC"
	@Scheduled(cron = "${sqlInvalidateRecords_Scheduler_cron}", zone = "Europe/London")
	public void invalidaterecords() {
		LOG.info("invalidaterecords Scheduler started at CRON Time :: %s ",Instant.now());

//		// Invalidate sessions > Inactivetime and status-Valid
		List<SessionActivity> invalidatedRec = sessionSchedulerService.getInvalidSessionsforInactiveTime();
		
		for(SessionActivity lastInactiveTimeLog : invalidatedRec ) {
			LOG.info("Last Activity date and time of User  {}", lastInactiveTimeLog.getLastActivityTime());
			LOG.info("Current date and time {}",Instant.now());
			LOG.info("For OID {}",lastInactiveTimeLog.getOid());
			
		}
		// Put these into Invalid Session record table
		List<SessionHistory> listOfsessionHistoryRecords = new ArrayList<>();

		for (SessionActivity rec : invalidatedRec) {
			SessionHistory sessionHistoryRecord = new SessionHistory();
			Instant lastActivityTime = rec.getLastActivityTime();
			Long sessionId = rec.getSessionId();
//			token_issue_datetime
			sessionHistoryRecord.setSessionId(sessionId);
			sessionHistoryRecord.setOid(rec.getOid());
			sessionHistoryRecord.setLastActivityTime(lastActivityTime);
			sessionHistoryRecord.setCreatedOn(Instant.now());
			sessionHistoryRecord.setSessionToken(rec.getSessionToken());
			sessionHistoryRecord.setTokenStatus(INVALID);
			sessionHistoryRecord.setCreatedBy(DP_JAVA_COMP_BACKGROUNDJOB_001);
			sessionHistoryRecord.setUserAgent("UserAgent");
			sessionHistoryRecord.setIpAddress("IPAddress");
			sessionHistoryRecord.setRemark("Invalidated via webjob");
			sessionHistoryRecord.setTokenExpiryDatetime(rec.getTokenExpiryDatetime());
			sessionHistoryRecord.setTokenUti(rec.getTokenUti());

			listOfsessionHistoryRecords.add(sessionHistoryRecord);

		}
		sessionSchedulerService.saveAllRecords(listOfsessionHistoryRecords);
		for(SessionHistory historylog : listOfsessionHistoryRecords) {
			LOG.info("Saving records in history {} Current date and time {}", historylog.getLastActivityTime(), Instant.now());
			
		}

		// Delete these records from SessionActivity Table
		sessionSchedulerService.deleteInvalidatedRecords();

		LOG.info("invalidaterecords Scheduler stopped");
	}


}
