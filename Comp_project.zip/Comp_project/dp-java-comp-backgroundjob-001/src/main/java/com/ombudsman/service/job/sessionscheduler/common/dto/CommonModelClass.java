package com.ombudsman.service.job.sessionscheduler.common.dto;

import java.time.Instant;
import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.MappedSuperclass;


@MappedSuperclass
public class CommonModelClass {
	
	@Column(name = "oid")
	private String oid;
	
	@Column(name = "modified_on")
	private Instant modifiedOn ;
	
	@Column(name = "modified_by")
	private String modifiedBy ;

	@Column(name = "created_by")
	private String createdBy ;
	 
	@Column(name = "user_agent")
	private String userAgent ;
	
	@Column(name = "token_status")  
	private String tokenStatus ;
	
	@Column(name = "token_uti")   
	private String tokenUti ;
	
	@Column(name = "created_on")
	private Instant createdOn ;
	
	@Column(name = "token")
	private String sessionToken ;
	
	@Column(name = "last_activity_datetime")
	private Instant lastActivityTime ;

	@Column(name = "token_issue_datetime")
	private LocalDateTime tokenExpiryDatetime;
	
	@Column(name = "user_ip_address")
	private String ipAddress;

	public String getOid() {
		return oid;
	}

	public void setOid(String oid) {
		this.oid = oid;
	}

	public Instant getModifiedOn() {
		return modifiedOn;
	}

	public void setModifiedOn(Instant modifiedOn) {
		this.modifiedOn = modifiedOn;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getUserAgent() {
		return userAgent;
	}

	public void setUserAgent(String userAgent) {
		this.userAgent = userAgent;
	}

	public String getTokenStatus() {
		return tokenStatus;
	}

	public void setTokenStatus(String tokenStatus) {
		this.tokenStatus = tokenStatus;
	}

	public String getTokenUti() {
		return tokenUti;
	}

	public void setTokenUti(String tokenUti) {
		this.tokenUti = tokenUti;
	}

	public Instant getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Instant createdOn) {
		this.createdOn = createdOn;
	}

	public String getSessionToken() {
		return sessionToken;
	}

	public void setSessionToken(String sessionToken) {
		this.sessionToken = sessionToken;
	}

	public Instant getLastActivityTime() {
		return lastActivityTime;
	}

	public void setLastActivityTime(Instant lastActivityTime) {
		this.lastActivityTime = lastActivityTime;
	}

	public LocalDateTime getTokenExpiryDatetime() {
		return tokenExpiryDatetime;
	}

	public void setTokenExpiryDatetime(LocalDateTime tokenExpiryDatetime) {
		this.tokenExpiryDatetime = tokenExpiryDatetime;
	}

	public String getIpAddress() {
		return ipAddress;
	}

	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}

	

}
