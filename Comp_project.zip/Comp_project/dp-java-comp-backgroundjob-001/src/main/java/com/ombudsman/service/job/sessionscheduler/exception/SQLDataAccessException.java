package com.ombudsman.service.job.sessionscheduler.exception;

import java.sql.SQLException;

public class SQLDataAccessException extends SQLException {
	/**
   * 
   */
  private static final long serialVersionUID = 1L;

  public SQLDataAccessException(String orgName){
		super(orgName);
	}
}
