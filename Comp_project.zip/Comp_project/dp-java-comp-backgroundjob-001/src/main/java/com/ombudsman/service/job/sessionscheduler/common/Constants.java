package com.ombudsman.service.job.sessionscheduler.common;

public class Constants {
	public static final String OFF="OFF";
	public static final String MSG_SUCCESS="Success";
	public static final String DATE_FORMAT="yyyy-MM-dd'T'HH:mm:ss'Z'";
	public static final String DP_USER="DP_USER";
	public static final int NEXT_JOB_TIME=15;
	private Constants() {
	      //not called
	   }

}
