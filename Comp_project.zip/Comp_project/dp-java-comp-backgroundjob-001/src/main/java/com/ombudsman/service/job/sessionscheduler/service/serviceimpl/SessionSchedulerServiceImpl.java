package com.ombudsman.service.job.sessionscheduler.service.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ombudsman.service.job.sessionscheduler.common.dto.SessionActivity;
import com.ombudsman.service.job.sessionscheduler.common.dto.SessionHistory;
import com.ombudsman.service.job.sessionscheduler.dao.SessionSchedularDao;
import com.ombudsman.service.job.sessionscheduler.repository.SessionActivityRepository;
import com.ombudsman.service.job.sessionscheduler.repository.SessionHistoryRepository;
import com.ombudsman.service.job.sessionscheduler.services.SessionSchedulerService;

@Service
public class SessionSchedulerServiceImpl implements SessionSchedulerService {
	
	SessionSchedularDao sessionSchedularDao;

	SessionActivityRepository sessionActivityRepository;

	SessionHistoryRepository sessionHistoryRepository;
	
	@Autowired
	public SessionSchedulerServiceImpl(SessionSchedularDao sessionSchedularDao, SessionActivityRepository sessionActivityRepository,SessionHistoryRepository sessionHistoryRepository) {
		super();
		this.sessionSchedularDao = sessionSchedularDao;
		this.sessionActivityRepository = sessionActivityRepository;
		this.sessionHistoryRepository = sessionHistoryRepository;
	}

	@Override
	public void deleteRecordsbyTime() {

		sessionSchedularDao.deleteRecordsbyTime();

	}


	@Override
	public void deleteInvalidatedRecords() {
		sessionSchedularDao.deleteInvalidatedRecords();

	}

	@Override
	public List<SessionActivity> getInvalidSessionsforInactiveTime() {
		return sessionSchedularDao.getInvalidSessionsforInactiveTime();
	}

	@Override
	public void saveAllRecords(List<SessionHistory> records) {
		sessionSchedularDao.saveAllRecords(records);

	}

}
