package com.ombudsman.service.job.sessionscheduler.common.dto;

import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "dp_complainant_user_session_history")
public class SessionHistory extends CommonModelClass implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "invalid_user_token_id")
	private Long invalidUserTokenId;

	@Column(name = "user_session_id")
	private Long sessionId;


	@Column(name = "invalidation_remark")
	private String remark;

	public Long getInvalidUserTokenId() {
		return invalidUserTokenId;
	}

	public void setInvalidUserTokenId(Long invalidUserTokenId) {
		this.invalidUserTokenId = invalidUserTokenId;
	}

	public Long getSessionId() {
		return sessionId;
	}

	public void setSessionId(Long sessionId) {
		this.sessionId = sessionId;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

}
