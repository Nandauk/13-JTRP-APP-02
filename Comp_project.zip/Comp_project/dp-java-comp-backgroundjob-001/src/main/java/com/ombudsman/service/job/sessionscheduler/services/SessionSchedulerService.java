package com.ombudsman.service.job.sessionscheduler.services;

import java.util.List;

import com.ombudsman.service.job.sessionscheduler.common.dto.SessionActivity;
import com.ombudsman.service.job.sessionscheduler.common.dto.SessionHistory;

public interface SessionSchedulerService {

	public void deleteRecordsbyTime();
	public void deleteInvalidatedRecords();
	public List<SessionActivity> getInvalidSessionsforInactiveTime();
	public void saveAllRecords(List<SessionHistory> records);
}
