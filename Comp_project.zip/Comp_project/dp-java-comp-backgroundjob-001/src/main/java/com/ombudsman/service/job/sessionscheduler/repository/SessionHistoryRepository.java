package com.ombudsman.service.job.sessionscheduler.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.ombudsman.service.job.sessionscheduler.common.dto.SessionHistory;

@Repository
public interface SessionHistoryRepository extends JpaRepository<SessionHistory, String>{
	@Query(value="SELECT oid FROM dp_complainant_user_session_history WHERE token_uti=:uti",nativeQuery = true)
    String findByUti(@Param("uti") String tokenUti);

}
