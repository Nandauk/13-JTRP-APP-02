package com.ombudsman.service.job.sessionscheduler.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.ombudsman.service.job.sessionscheduler.common.dto.SessionActivity;

@Repository
public interface SessionActivityRepository extends JpaRepository<SessionActivity, String>{

	@Transactional
	@Modifying
	@Query(value="DELETE FROM dp_complainant_user_session WHERE last_activity_datetime < DATEADD(MONTH, -6, GETDATE())",nativeQuery = true)
	void deleteRecordsbyTime();
	
	@Query(value="SELECT * FROM dp_complainant_user_session WHERE token_status='valid' and DATEADD(MINUTE, 20, last_activity_datetime) <= GETDATE()",nativeQuery = true)
	List<SessionActivity> getInvalidSessionsforInactiveTime();
	
	@Transactional
	@Modifying
	@Query(value="DELETE FROM dp_complainant_user_session WHERE token_status='valid' and DATEADD(MINUTE, 20, last_activity_datetime) <= GETDATE()",nativeQuery = true)
	void deleteInvalidatedRecords();	
}
