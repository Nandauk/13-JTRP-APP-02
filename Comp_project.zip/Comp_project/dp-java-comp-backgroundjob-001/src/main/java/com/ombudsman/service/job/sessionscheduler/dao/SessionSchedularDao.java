package com.ombudsman.service.job.sessionscheduler.dao;

import java.util.List;

import com.ombudsman.service.job.sessionscheduler.common.dto.SessionActivity;
import com.ombudsman.service.job.sessionscheduler.common.dto.SessionHistory;

public interface SessionSchedularDao {

	void deleteRecordsbyTime();

	void deleteInvalidatedRecords();

	List<SessionActivity> getInvalidSessionsforInactiveTime();

	void saveAllRecords(List<SessionHistory> records);

	
}
