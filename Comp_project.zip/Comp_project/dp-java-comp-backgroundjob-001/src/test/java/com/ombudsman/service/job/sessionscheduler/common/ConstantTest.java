package com.ombudsman.service.job.sessionscheduler.common;

import static org.junit.Assert.assertEquals;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.springframework.test.context.junit.jupiter.SpringExtension;

@ExtendWith(SpringExtension.class)
 class ConstantTest {
	
	@InjectMocks
    private Constants testIntance;
	  @Test
	    void testConstantsValues() {
	        assertEquals("OFF", testIntance.OFF);
	        assertEquals("Success", testIntance.MSG_SUCCESS);
	        assertEquals("yyyy-MM-dd'T'HH:mm:ss'Z'", testIntance.DATE_FORMAT);
	        assertEquals("DP_USER", testIntance.DP_USER);
	        assertEquals(15, testIntance.NEXT_JOB_TIME);
	    }

	   

}
