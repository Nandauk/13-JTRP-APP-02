package com.ombudsman.service.job.sessionscheduler.common.dto;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.time.Instant;
import java.time.LocalDateTime;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class SessionActivityTest {

    private SessionActivity sessionActivity;

    @BeforeEach
    void setUp() {
        sessionActivity = new SessionActivity();
    }

    @Test
    void testSetAndGetSessionId() {
        Long sessionId = 123L;
        sessionActivity.setSessionId(sessionId);
        assertEquals(sessionId, sessionActivity.getSessionId());
    }

    @Test
    void testSetAndGetOid() {
        String oid = "test-oid";
        sessionActivity.setOid(oid);
        assertEquals(oid, sessionActivity.getOid());
    }

    @Test
    void testSetAndGetSessionToken() {
        String token = "session-token";
        sessionActivity.setSessionToken(token);
        assertEquals(token, sessionActivity.getSessionToken());
    }

    @Test
    void testSetAndGetLastActivityTime() {
        Instant time = Instant.now();
        sessionActivity.setLastActivityTime(time);
        assertEquals(time, sessionActivity.getLastActivityTime());
    }

    @Test
    void testSetAndGetCreatedOn() {
        Instant time = Instant.now();
        sessionActivity.setCreatedOn(time);
        assertEquals(time, sessionActivity.getCreatedOn());
    }

    @Test
    void testSetAndGetTokenStatus() {
        String status = "active";
        sessionActivity.setTokenStatus(status);
        assertEquals(status, sessionActivity.getTokenStatus());
    }

    @Test
    void testSetAndGetTokenUti() {
        String uti = "token-uti";
        sessionActivity.setTokenUti(uti);
        assertEquals(uti, sessionActivity.getTokenUti());
    }

    @Test
    void testSetAndGetCreatedBy() {
        String creator = "creator";
        sessionActivity.setCreatedBy(creator);
        assertEquals(creator, sessionActivity.getCreatedBy());
    }

    @Test
    void testSetAndGetUserAgent() {
        String userAgent = "user-agent";
        sessionActivity.setUserAgent(userAgent);
        assertEquals(userAgent, sessionActivity.getUserAgent());
    }

    @Test
    void testSetAndGetIpAddress() {
        String ipAddress = "192.168.1.1";
        sessionActivity.setIpAddress(ipAddress);
        assertEquals(ipAddress, sessionActivity.getIpAddress());
    }

    @Test
    void testSetAndGetRemark() {
        String remark = "remark";
        sessionActivity.setRemark(remark);
        assertEquals(remark, sessionActivity.getRemark());
    }

    @Test
    void testSetAndGetTokenExpiryDatetime() {
        LocalDateTime expiryDatetime = LocalDateTime.now();
        sessionActivity.setTokenExpiryDatetime(expiryDatetime);
        assertEquals(expiryDatetime, sessionActivity.getTokenExpiryDatetime());
    }

    @Test
    void testSetAndGetModifiedOn() {
        Instant modifiedOn = Instant.now();
        sessionActivity.setModifiedOn(modifiedOn);
        assertEquals(modifiedOn, sessionActivity.getModifiedOn());
    }

    @Test
    void testSetAndGetModifiedBy() {
        String modifiedBy = "modifier";
        sessionActivity.setModifiedBy(modifiedBy);
        assertEquals(modifiedBy, sessionActivity.getModifiedBy());
    }
}
