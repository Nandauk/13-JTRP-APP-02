package com.ombudsman.service.job.sessionscheduler;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.ombudsman.service.job.sessionscheduler.common.dto.SessionActivity;
import com.ombudsman.service.job.sessionscheduler.common.dto.SessionHistory;
import com.ombudsman.service.job.sessionscheduler.exception.ComplainantServiceExceptions;
import com.ombudsman.service.job.sessionscheduler.services.SessionSchedulerService;

@ExtendWith(SpringExtension.class)
class SessionSchedulerJobApplicationTest {

	@InjectMocks
	private SessionSchedulerJobApplication testInstance;

	@Mock
	SessionSchedulerService sessionSchedulerService;

	@Test
	void testSessionSchedulerJobApplication() {
		SessionActivity activity = new SessionActivity();
		List<SessionHistory> listOfsessionHistoryRecords = new ArrayList<>();
		List<SessionActivity> abc = new ArrayList<>();
		activity.setOid("oid123");
		abc.add(activity);

		when(sessionSchedulerService.getInvalidSessionsforInactiveTime()).thenReturn(abc);
		testInstance.invalidaterecords();
	}

}
