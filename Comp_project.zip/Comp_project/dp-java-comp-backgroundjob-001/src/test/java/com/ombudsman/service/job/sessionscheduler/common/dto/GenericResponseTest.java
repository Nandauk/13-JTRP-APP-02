package com.ombudsman.service.job.sessionscheduler.common.dto;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.ombudsman.service.job.sessionscheduler.model.response.GenericResponse;

public class GenericResponseTest {
	private GenericResponse response;

	@BeforeEach
	void setUp() {
		response = new GenericResponse();
	}

	@Test
	void testSetAndGetGenericResponse() {
		String value = "Succcess";
		response.setStatus(value);
		assertEquals(value, response.getStatus());
	}
	
	@Test
	void testSetAndGetGenericResponseMessage() {
		String value = "Succcess";
		response.setMessage(value);
		assertEquals(value, response.getMessage());
	}
}
