package com.ombudsman.service.job.sessionscheduler.exception;

import static org.junit.Assert.assertEquals;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.test.context.junit.jupiter.SpringExtension;

@ExtendWith(SpringExtension.class)
class SQLDataAccessExceptionTest {
	@Test
	void testSQLDataAccessExceptionConstructor() {
		String orgName = "TestOrg";

		SQLDataAccessException exception = new SQLDataAccessException(orgName);

		assertEquals("TestOrg", exception.getMessage());
	}
}
