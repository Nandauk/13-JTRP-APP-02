package com.ombudsman.service.job.sessionscheduler.dto;
import static org.junit.Assert.assertEquals;

import java.time.OffsetDateTime;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.MockitoAnnotations;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.ombudsman.service.job.sessionscheduler.model.AuditEvent;

@ExtendWith(SpringExtension.class)
 class AuditEventTest {

	@InjectMocks
    private AuditEvent testInstance;
	 @BeforeEach
	    void setUp() {
	        MockitoAnnotations.openMocks(this);	       
	    }	


    @Test
     void testGettersAndSetters() {
    	testInstance.setAuditRecordID(1);       

    	testInstance.setUserOID("TestUserOID");
        assertEquals("TestUserOID", testInstance.getUserOID());

        OffsetDateTime now = OffsetDateTime.now();
        testInstance.setAuditEventTimestamp(now);
        assertEquals(now, testInstance.getAuditEventTimestamp());

        testInstance.setAuditEventName("TestEventName");
        assertEquals("TestEventName", testInstance.getAuditEventName());

        testInstance.setPrimaryAuditEntity("TestEntity");
        assertEquals("TestEntity", testInstance.getPrimaryAuditEntity());

        testInstance.setPrimaryAuditEntityIdentifier("TestIdentifier");
        assertEquals("TestIdentifier", testInstance.getPrimaryAuditEntityIdentifier());

        testInstance.setPreAuditSnapshot("PreSnapshot");
        assertEquals("PreSnapshot", testInstance.getPreAuditSnapshot());

        testInstance.setPostAuditSnapshot("PostSnapshot");
        assertEquals("PostSnapshot", testInstance.getPostAuditSnapshot());

        testInstance.setCreatedBy("TestUser");
        assertEquals("TestUser", testInstance.getCreatedBy());

        testInstance.setModifiedBy("TestUser");
        assertEquals("TestUser", testInstance.getModifiedBy());
    }
    
}

