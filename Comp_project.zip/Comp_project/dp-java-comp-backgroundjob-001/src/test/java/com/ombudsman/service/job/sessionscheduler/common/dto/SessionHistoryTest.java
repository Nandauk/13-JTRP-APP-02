package com.ombudsman.service.job.sessionscheduler.common.dto;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.time.Instant;
import java.time.LocalDateTime;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class SessionHistoryTest {

    private SessionHistory sessionHistory;

    @BeforeEach
    void setUp() {
        sessionHistory = new SessionHistory();
    }

    @Test
    void testSetAndGetInvalidUserTokenId() {
        Long id = 1L;
        sessionHistory.setInvalidUserTokenId(id);
        assertEquals(id, sessionHistory.getInvalidUserTokenId());
    }

    @Test
    void testSetAndGetSessionId() {
        Long sessionId = 123L;
        sessionHistory.setSessionId(sessionId);
        assertEquals(sessionId, sessionHistory.getSessionId());
    }

    @Test
    void testSetAndGetOid() {
        String oid = "test-oid";
        sessionHistory.setOid(oid);
        assertEquals(oid, sessionHistory.getOid());
    }

    @Test
    void testSetAndGetSessionToken() {
        String token = "session-token";
        sessionHistory.setSessionToken(token);
        assertEquals(token, sessionHistory.getSessionToken());
    }

    @Test
    void testSetAndGetLastActivityTime() {
        Instant time = Instant.now();
        sessionHistory.setLastActivityTime(time);
        assertEquals(time, sessionHistory.getLastActivityTime());
    }

    @Test
    void testSetAndGetCreatedOn() {
        Instant time = Instant.now();
        sessionHistory.setCreatedOn(time);
        assertEquals(time, sessionHistory.getCreatedOn());
    }

    @Test
    void testSetAndGetTokenStatus() {
        String status = "active";
        sessionHistory.setTokenStatus(status);
        assertEquals(status, sessionHistory.getTokenStatus());
    }

    @Test
    void testSetAndGetTokenUti() {
        String uti = "token-uti";
        sessionHistory.setTokenUti(uti);
        assertEquals(uti, sessionHistory.getTokenUti());
    }

    @Test
    void testSetAndGetCreatedBy() {
        String creator = "creator";
        sessionHistory.setCreatedBy(creator);
        assertEquals(creator, sessionHistory.getCreatedBy());
    }

    @Test
    void testSetAndGetUserAgent() {
        String userAgent = "user-agent";
        sessionHistory.setUserAgent(userAgent);
        assertEquals(userAgent, sessionHistory.getUserAgent());
    }

    @Test
    void testSetAndGetIpAddress() {
        String ipAddress = "192.168.1.1";
        sessionHistory.setIpAddress(ipAddress);
        assertEquals(ipAddress, sessionHistory.getIpAddress());
    }

    @Test
    void testSetAndGetRemark() {
        String remark = "remark";
        sessionHistory.setRemark(remark);
        assertEquals(remark, sessionHistory.getRemark());
    }

    @Test
    void testSetAndGetTokenExpiryDatetime() {
        LocalDateTime expiryDatetime = LocalDateTime.now();
        sessionHistory.setTokenExpiryDatetime(expiryDatetime);
        assertEquals(expiryDatetime, sessionHistory.getTokenExpiryDatetime());
    }

    @Test
    void testSetAndGetModifiedOn() {
        Instant modifiedOn = Instant.now();
        sessionHistory.setModifiedOn(modifiedOn);
        assertEquals(modifiedOn, sessionHistory.getModifiedOn());
    }

    @Test
    void testSetAndGetModifiedBy() {
        String modifiedBy = "modifier";
        sessionHistory.setModifiedBy(modifiedBy);
        assertEquals(modifiedBy, sessionHistory.getModifiedBy());
    }
}
