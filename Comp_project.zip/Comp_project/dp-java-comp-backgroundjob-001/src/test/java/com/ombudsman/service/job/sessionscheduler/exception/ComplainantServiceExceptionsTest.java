package com.ombudsman.service.job.sessionscheduler.exception;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.test.context.junit.jupiter.SpringExtension;

@ExtendWith(SpringExtension.class)
public class ComplainantServiceExceptionsTest {

	
	@Test
	void testComplainantServiceConstructor() {
		String message = "Test message";
		String code = "TEST_CODE";
		String exceptionMessage = "Test exception message";
		StackTraceElement[] stackTrace = new StackTraceElement[0];

		ComplainantServiceExceptions serviceExceptions = new ComplainantServiceExceptions(message, code, exceptionMessage, stackTrace);
		assertNotNull(serviceExceptions.getStackTraceMessage());
		assertEquals(message, serviceExceptions.getMessage());
		assertEquals(code, serviceExceptions.getCode());
		assertEquals(exceptionMessage, serviceExceptions.getExceptionMessage());
		assertArrayEquals(stackTrace, serviceExceptions.getStackTraceMessage());
	}
}
