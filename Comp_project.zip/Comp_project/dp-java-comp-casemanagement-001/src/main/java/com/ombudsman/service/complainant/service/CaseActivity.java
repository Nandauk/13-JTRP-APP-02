package com.ombudsman.service.complainant.service;

import com.ombudsman.service.complainant.model.CaseWithdraw;

public interface CaseActivity {

	
	
	String activity(CaseWithdraw dto, String ticketnumber);

}
