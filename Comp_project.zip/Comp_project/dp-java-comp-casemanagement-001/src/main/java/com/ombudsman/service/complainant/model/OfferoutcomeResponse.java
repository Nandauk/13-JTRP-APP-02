package com.ombudsman.service.complainant.model;

import java.time.OffsetDateTime;
import java.util.UUID;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "dp_complainant_offeroutcome_response")
public class OfferoutcomeResponse {
	
	@Id
	@Column(name = "offeroutcomeId")
	private UUID offeroutcomeId;
	@Column(name ="request_datetime")
	private OffsetDateTime 	requestDatetime;
	@Column(name = "phoenix_respone")
	private String phoenixRespone;
	@Column(name = "created_on")
	private OffsetDateTime createdOn; 
	@Column(name = "created_by")
	private String createdBy;
	@Column(name = "modified_on")
	private OffsetDateTime modifiedOn;
	@Column(name = "modified_by")
	private String modifiedBy;
	@Column(name = "user_comments")
	private String userComments;
	
	public String getUserComments() {
		return userComments;
	}
	public void setUserComments(String userComments) {
		this.userComments = userComments;
	}
	public UUID getOfferoutcomeId() {
		return offeroutcomeId;
	}
	public void setOfferoutcomeId(UUID offeroutcomeId) {
		this.offeroutcomeId = offeroutcomeId;
	}
	public OffsetDateTime getRequestDatetime() {
		return requestDatetime;
	}
	public void setRequestDatetime(OffsetDateTime requestDatetime) {
		this.requestDatetime = requestDatetime;
	}
	public String getPhoenixRespone() {
		return phoenixRespone;
	}
	public void setPhoenixRespone(String phoenixRespone) {
		this.phoenixRespone = phoenixRespone;
	}
	public OffsetDateTime getCreatedOn() {
		return createdOn;
	}
	public void setCreatedOn(OffsetDateTime createdOn) {
		this.createdOn = createdOn;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public OffsetDateTime getModifiedOn() {
		return modifiedOn;
	}
	public void setModifiedOn(OffsetDateTime modifiedOn) {
		this.modifiedOn = modifiedOn;
	}
	public String getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	
	
	
	
	

}
