package com.ombudsman.service.complainant.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(HttpStatus.BAD_REQUEST)
public class CaseManagementInvalidEventNameException extends ComplainantServiceException {

	private static final long serialVersionUID = 1L;

	public CaseManagementInvalidEventNameException(String message, String exceptionMessage, StackTraceElement[] stackTrace) {
		super(message, "CASEMANAGEMENT_INVALID_EVENTNAME_1004", exceptionMessage);
	}
}
