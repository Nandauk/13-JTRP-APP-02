package com.ombudsman.service.complainant.service.repository;

import java.time.OffsetDateTime;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.ombudsman.service.complainant.model.dto.RequestModel;

import jakarta.transaction.Transactional;


@Repository
public interface RequestModelRepository extends JpaRepository<RequestModel, String> {
	
	@Query(value = "SELECT TOP 1 request_id FROM dp_user_request where user_oid = :UserOid and created_on = :offsetDateTime", nativeQuery = true)
	String getRequestId(@Param("UserOid") String UserOid, @Param("offsetDateTime") OffsetDateTime offsetDateTime);

}
