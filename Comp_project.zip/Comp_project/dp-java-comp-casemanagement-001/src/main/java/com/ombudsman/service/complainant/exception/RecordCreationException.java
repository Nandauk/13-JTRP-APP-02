package com.ombudsman.service.complainant.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(HttpStatus.BAD_REQUEST)
public class RecordCreationException extends ComplainantServiceException {

	private static final long serialVersionUID = 1L;

	public RecordCreationException(String message, String exceptionMessage) {
		super(message, "COMPLAINANT_RECORD_CREATION_FAILED_1005", exceptionMessage);
	}
}
