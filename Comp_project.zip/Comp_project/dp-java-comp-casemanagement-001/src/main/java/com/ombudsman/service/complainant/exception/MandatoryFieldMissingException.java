package com.ombudsman.service.complainant.exception;

public class MandatoryFieldMissingException  extends RuntimeException {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public MandatoryFieldMissingException(String exceptionMsg)
	{
		super(exceptionMsg);
	}


}
