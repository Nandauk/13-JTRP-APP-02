package com.ombudsman.service.complainant.service;

import javax.security.auth.login.AccountNotFoundException;

import com.ombudsman.service.complainant.exception.InvalidOrganisationException;
import com.ombudsman.service.complainant.exception.SQLDataAccessException;
import com.ombudsman.service.complainant.model.request.CaseCountReq;
import com.ombudsman.service.complainant.model.response.CaseCountRes;

public interface CaseCountService {
    CaseCountRes getCaseCount()
            throws SQLDataAccessException, AccountNotFoundException, InvalidOrganisationException;
}
