package com.ombudsman.service.complainant.service;

import java.io.IOException;
import java.util.Optional;

import javax.security.auth.login.AccountNotFoundException;

import org.json.JSONException;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ombudsman.service.complainant.common.UserBean;
import com.ombudsman.service.complainant.exception.AzureServiceException;
import com.ombudsman.service.complainant.exception.SQLDataAccessException;
import com.ombudsman.service.complainant.exception.UnAuthorisedException;
import com.ombudsman.service.complainant.model.Incident;
import com.ombudsman.service.complainant.model.OfferOutcome;
import com.ombudsman.service.complainant.model.RequestProcessingDetails;
import com.ombudsman.service.complainant.model.dto.RequestModel;
import com.ombudsman.service.complainant.model.request.CaseOutcomeByIdReq;
import com.ombudsman.service.complainant.model.response.CaseOutcomeByIdRes;

public interface CaseOutcomeByIdService {

	public CaseOutcomeByIdRes getCaseOutcomeById(CaseOutcomeByIdReq request)
			throws AzureServiceException, JSONException, IOException, SQLDataAccessException, AccountNotFoundException, UnAuthorisedException;
	public Optional<OfferOutcome> findOfferOutcomeById(String id);
	public Optional<Incident> findIncidentInfoById( String incidentId);
	Integer saveRecordnotificationEntity(RequestModel request, String ticketnumber,
			String reasonForChange);
	public String saveRecordForRequestEntity( UserBean userBean,RequestProcessingDetails requestProcessingDetails)throws JsonProcessingException;
	public Optional<RequestModel> findById(String Id);

}
