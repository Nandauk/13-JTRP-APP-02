package com.ombudsman.service.complainant.exception;


public class PhoenixServiceException extends ComplainantServiceException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public PhoenixServiceException(String message, String exceptionMessage) {
		super(message, "PHOENIX_ERROR", exceptionMessage);
	}

}
