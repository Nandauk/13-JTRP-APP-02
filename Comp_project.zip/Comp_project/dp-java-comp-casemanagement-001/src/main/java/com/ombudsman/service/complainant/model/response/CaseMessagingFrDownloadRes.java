package com.ombudsman.service.complainant.model.response;


import java.util.List;

import com.ombudsman.service.complainant.model.CaseConversationDetail;
public class CaseMessagingFrDownloadRes extends GenericResponse {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	List<CaseConversationDetail> messageDetails;

	public List<CaseConversationDetail> getMessageDetails() {
		return messageDetails;
	}

	public void setMessageDetails(List<CaseConversationDetail> messageDetails) {
		this.messageDetails = messageDetails;
	}

}
