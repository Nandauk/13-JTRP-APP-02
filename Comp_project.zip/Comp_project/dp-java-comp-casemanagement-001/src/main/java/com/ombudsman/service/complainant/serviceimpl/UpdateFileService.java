
package com.ombudsman.service.complainant.serviceimpl;

import java.io.UnsupportedEncodingException;
import java.text.ParseException;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.apache.commons.text.StringEscapeUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.util.HtmlUtils;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ombudsman.service.complainant.common.CommonUtil;
import com.ombudsman.service.complainant.common.Constants;
import com.ombudsman.service.complainant.common.UserBean;
import com.ombudsman.service.complainant.common.ValidateUserSession;
import com.ombudsman.service.complainant.common.WebClientData;
import com.ombudsman.service.complainant.exception.UnAuthorisedException;
import com.ombudsman.service.complainant.model.ApiResponse;
import com.ombudsman.service.complainant.model.CaseWithdraw;
import com.ombudsman.service.complainant.model.EfileMessage;
import com.ombudsman.service.complainant.model.IncidentInfo;
import com.ombudsman.service.complainant.model.OwnerDetails;
import com.ombudsman.service.complainant.model.PortalActivityRequest;
import com.ombudsman.service.complainant.model.PortalActivityRequest.FosPortalActivityParty;
import com.ombudsman.service.complainant.model.UserRequestBody;
import com.ombudsman.service.complainant.model.dto.Notification;
import com.ombudsman.service.complainant.model.dto.RequestModel;
import com.ombudsman.service.complainant.model.dto.UpdateCaseDto;
import com.ombudsman.service.complainant.model.request.SinchApiRequest;
import com.ombudsman.service.complainant.repository.dao.CaseDetailsDao;
import com.ombudsman.service.complainant.service.IUpdateFileService;
import com.ombudsman.service.complainant.service.repository.UpdateRequestsRepository;
import com.ombudsman.service.complainant.service.repository.UserEventConfigurationRepository;

@Service
public class UpdateFileService implements IUpdateFileService {

	Logger LOG = LogManager.getRootLogger();

	@Autowired
	CommonUtil commonUtil;

	@Autowired
	UserBean userbean;

	@Autowired
	UpdateRequestsRepository updateRequestsRepository;
	@Autowired
	CaseDetailsDao caseDetailsDao;

	@Autowired
	WebClientData webClientData;

	@Autowired
	Constants constant;

	@Autowired
	PhoenixProcessorImpl phoenixProcessorImpl;

	@Autowired
	CaseActivityImpl caseActivityImpl;

	@Autowired
	UserEventConfigurationRepository userEventConfigurationRepository;

	@Autowired
	ValidateUserSession validateSession;

	EfileMessage efileMessage = new EfileMessage();
	UserRequestBody emailDetails = new UserRequestBody();
	Map<String, Object> variables = new HashMap<>();
	ObjectMapper objectMapper = new ObjectMapper();
	ApiResponse response = new ApiResponse();
	Notification notifyModel = new Notification();
	RequestModel request = new RequestModel();
	SinchApiRequest sinchReq = new SinchApiRequest();

	private String id = "";
	private String fullName = "";
	private String email = "";
	private String ticketNumber = "";
	private IncidentInfo info;
	private Integer templateID = 0; // 6591060;6724496
	private String userOid = "";
	private final Integer reasonForChangeNum = 140000007;
	private final String subject = "Withdraw Case";
	private final Integer categoryCode = 140000007;
	private String failureSMSText = "";
	private String readable = "";
	private String individualId = "";
	private String caselink = "";
	private String contactId = "";

	@Override
	public ApiResponse updateCase(CaseWithdraw dto) throws UnsupportedEncodingException, JSONException, ParseException,
			JsonProcessingException, UnAuthorisedException {
		LOG.info("Withdraw Case  method started:: {} ", dto);

		userOid = userbean.getUserObjectId();
		LOG.info("User OID: {}", userOid);

		// Checking if CaseID belongs to user
		if (dto.getCaseId() != null) {
			List<Object[]> result = updateRequestsRepository.checkOidAndCaseId(userOid, dto.getCaseId(),userbean.getRoles().get(0));
			for (Object[] row : result) {
				individualId = (String) row[0];
				caselink = (String) row[1];
				LOG.info("ContactID and caseID are linked  {} {} ", individualId, caselink);
			}
			if (caselink.isEmpty() || individualId.isBlank()) {
				LOG.info("CaseID and User are not linked, case does not belong to user ");
				response.setMessage("CaseID and User are not linked, case does not belong to user.");
				response.setSuccess(false);
				response.setStatus(HttpStatus.BAD_REQUEST);
				return response;
			}
		}

		String comm_preference = updateRequestsRepository.getCommunicationPreference(userOid);
		String mobileNumber = updateRequestsRepository.getMobileNumber(userOid);
		LOG.info("Communication preference and mobile number {} {} ", comm_preference, mobileNumber);
		try {
			List<Object[]> results = updateRequestsRepository.getUserEmailName(userOid);

			for (Object[] row : results) {
				fullName = (String) row[0];
				email = (String) row[1];
				contactId = (String) row[2];
				LOG.info("Full name and email {} {} {} ", fullName, email, contactId);
			}

			List<String> roles = userbean.getRoles();
			for (String role : roles) {
				LOG.info(String.format("jwt role   :-%s", role));
				if (role.contains("Organisation Complainant")) {
					LOG.info("role Organisation Complainant ");
					String adAccountId = updateRequestsRepository.getparentcustomerid(contactId);
					LOG.info(String.format("adAccountId*******************: %s", adAccountId));
					efileMessage.setUsersAccountIds(new String[] { adAccountId });
					break;
				} else {
					efileMessage.setUsersAccountIds(null);
				}
			}

			LOG.info("Webclient call to get templateID from drupal api");
			templateID = webClientData.getTemplateId(Constants.drupalEndpoint);

			if (dto.getCaseId().isEmpty() || dto.getCaseId().isBlank()) {
				LOG.info("Caseid is null,please provide case id ");
				response.setMessage("Caseid is null,please provide case id ");
				response.setSuccess(false);
				response.setStatus(HttpStatus.BAD_REQUEST);
				return response;
			}

			LOG.info("Caseid fetched from request is ::{}", dto.getCaseId());

			// checking if present in Incident table
			info = updateRequestsRepository.getIncident(dto.getCaseId());
			LOG.info("Get count of incident id from Incident table::{}", info.getIncidentid());
			if (info.getIncidentid() != null && info.getIncidentid() != 1) {
				LOG.info("get count form incident table is not 1::{}", info.getIncidentid());
				response.setMessage("User not tagged to any organisation");
				response.setStatus(HttpStatus.UNAUTHORIZED);
				response.setSuccess(false);
				LOG.info("Organization not found for the requested incident id :{}", response);
				return response;
			}

			ticketNumber = info.getTicketnumber();
			String message = ticketNumber + " : Notification record added";
			LOG.info("Message to add in notificatiion table : {}", message);
			// Adding record in audit request notification
			id = caseActivityImpl.activity(dto, message);
			LOG.info("PakcageID / requestID is : {}", id);

			// Add record in case update table
			UpdateCaseDto req = new UpdateCaseDto();
			req.setCase_id(dto.getCaseId());
			req.setComments(HtmlUtils.htmlUnescape(dto.getComments()));
			req.setDetails(dto.getDetails());
			req.setReason_for_change(reasonForChangeNum);
			req.setCreated(OffsetDateTime.now());
			req.setPackage_id(id);// request id
			req.setUser_id(userbean.getUserObjectId());
			req.setStatus("Pending");
			updateRequestsRepository.save(req);

			LOG.info("Inserted record in  CaseUpdate table succuessfully  :{}", req);

			LOG.info("******Portal activity creation code started***** ");

			failureSMSText = Constants.FAILURESMSTEXT + "(" + webClientData.signInUrl + ")";

			readable = StringEscapeUtils.unescapeJava(failureSMSText);

			LOG.info("Unescaped message: {}", readable);

			PortalActivityRequest portalActivityRequestBody = new PortalActivityRequest();

			// STEP 5 : Sql query to get ContactID, phnxemailId, phnxUsername and check
			// accountstatus as active

			portalActivityRequestBody.setRegardingObjectIdIncidentFosPortal(Constants.INCIDENT + dto.getCaseId() + ")");
			portalActivityRequestBody.setDescription(HtmlUtils.htmlUnescape(dto.getComments()));
			portalActivityRequestBody.setActivityId(id);
			portalActivityRequestBody.setFosPackageId(id);
			portalActivityRequestBody.setFosReasonForChange(reasonForChangeNum);
			portalActivityRequestBody.setFosOtherReasonForChange(dto.getDetails());
			portalActivityRequestBody.setFosDpUserEmailAddress(email);
			portalActivityRequestBody.setFosDpUserFullName(fullName);

			// (subject and category code) are based on reason for change
//				List<Object[]> result = Optional
//						.ofNullable(updateRequestsRepository.getSubCategoryCode(dto.getReasonForChange())).orElseThrow();
//				for(Object[] row : result) {
//					portalActivityRequestBody.setFosCategoryCode((Long) row[1]);
//					portalActivityRequestBody.setSubject((String) row[0]);
//				}

			portalActivityRequestBody.setFosCategoryCode(categoryCode);
			portalActivityRequestBody.setSubject(subject);

			// Is always false for respondent
			portalActivityRequestBody.setFosBusinessResponse(false);// Ask arun what it should be in complainant
			portalActivityRequestBody.setFosCapacity(140000001); // Static values : Respondent = 140000000, Complainant
																	// = 140000001

			// To and From fields
			List<FosPortalActivityParty> toAndFrom = new ArrayList<>();
			FosPortalActivityParty toAttribute = new FosPortalActivityParty();
			FosPortalActivityParty fromAttribute = new FosPortalActivityParty();

			fromAttribute.setType(Constants.ACTIVITYPARTY);
			fromAttribute.setPartyIdContact(Constants.CONTACTS + contactId); // contactID from contact table

			fromAttribute.setParticipationTypeMask(1);
			toAndFrom.add(fromAttribute);

			// Step 6 : Record Creation in Phoenix CRM Using Phoenix API

			ObjectMapper objectMapper = new ObjectMapper();
			// String accessToken = phoenixProcessorImpl.getConnectionWithD365();

			OwnerDetails ownerDetails = new OwnerDetails();
			List<Object[]> value = Optional.ofNullable(updateRequestsRepository.getOwnerDetails(dto.getCaseId()))
					.orElseThrow();
			for (Object[] row : value) {
				ownerDetails.setOwnerid((String) row[0]);
				ownerDetails.setOwningteam((String) row[1]);
				ownerDetails.setOwninguser((String) row[2]);
			}

			String getOwnerTable = phoenixProcessorImpl.getOwnerValue(ownerDetails.getOwningteam(),
					ownerDetails.getOwninguser());
			portalActivityRequestBody
					.setOwnerId(getOwnerTable + updateRequestsRepository.getOwnerId(dto.getCaseId()) + ")");

			// String toValue = phoenixProcessorImpl.getToValue(accessToken,
			// ownerDetails.getOwnerid(),ownerDetails.getOwningteam(),
			// ownerDetails.getOwninguser());
			String toValue = phoenixProcessorImpl.getToValue(ownerDetails.getOwnerid(), ownerDetails.getOwningteam(),
					ownerDetails.getOwninguser());

			toAttribute.setType(Constants.ACTIVITYPARTY);
			toAttribute.setParticipationTypeMask(2);

			if (ownerDetails.getOwningteam() != null && !ownerDetails.getOwningteam().isEmpty()) {
				toAttribute.setPartyIdQueue(toValue);
			} else if (ownerDetails.getOwninguser() != null && !ownerDetails.getOwninguser().isEmpty()) {
				toAttribute.setPartyIdSystemUser(toValue);
			}

			toAndFrom.add(toAttribute);
			portalActivityRequestBody.setFosPortalActivityParties(toAndFrom);

			String jsonString = objectMapper.writeValueAsString(portalActivityRequestBody);
			LOG.info("Json Rquest String for recrod creation in Portal table : {} ", jsonString);

			// int recordCreationResponse =
			// phoenixProcessorImpl.createRecordPhnx(accessToken,"fos_portals",jsonString);

			int recordCreationResponse = phoenixProcessorImpl.createRecordPhnx(Constants.PORTAL_ENTITY_PHNX,
					jsonString);

			if (recordCreationResponse == 204) {

				// Update SATAUS in caseUpdate table to Success
				updateRequestsRepository.updateCaseTable(Constants.SUCCESS, id);

				// String successMessage = ticketNumber+" : Case Withdraw successfull";
				// Update Notification table as Success
				// updateRequestsRepository.updateNotificationTable(2,successMessage,id);

				// Create Efile messge

				efileMessage.setCaseId(dto.getCaseId());
				efileMessage.setComments(HtmlUtils.htmlUnescape(dto.getComments()));
				efileMessage.setFromContactId(contactId);
				efileMessage.setDetails(dto.getDetails());
				efileMessage.setDigitalPortalUserEmailAddress(email);
				efileMessage.setDigitalPortalUserName(fullName);
				efileMessage.setPortalType(Constants.type);
				efileMessage.setPackageId(id);
				efileMessage.setReasonForChange(reasonForChangeNum);

				String efile = objectMapper.writeValueAsString(efileMessage);
				LOG.info("Efile Message sent to external bus {}", efile);

				// Send Message to external Queue for Efile to read and create PDF
				webClientData.updateCaseServiceBusWebclient(efileMessage);

				LOG.info("Efile Message sent Successfully to external bus {}", efile);

				response.setMessage("Message sent to efile");
				response.setSuccess(true);
				response.setData(efile);
				response.setStatus(HttpStatus.OK);

				LOG.error("Efile message ready to be sent in service bus {}", efileMessage);

			} else {

				LOG.error("Inside Else block , as Phoenix Odata api did not give 204 ");

				// Update Notification status as ReadyForDelviery
				String failureMessage = ticketNumber + " : Case Withdraw failed";
				caseActivityImpl.createNotificationRecord(request, notifyModel, id, failureMessage, userOid);
				// updateRequestsRepository.updateNotificationTable(3,failureMessage,id);

				// Update SATAUS in caseUpdate table to Failure
				updateRequestsRepository.updateCaseTable(Constants.FAILED, id);

				// Send email Notification for Failure to update

				// String reasonForChangeText =
				// updateRequestsRepository.getReasonForChangeText(dto.getReasonForChange());
				
				if (validateSession.isValidSession() == false) {
					if (mobileNumber != null && "phone".equalsIgnoreCase(comm_preference)) {

						List<String> toNumbers = new ArrayList<>();
						toNumbers.add(mobileNumber);
						sinchReq.setTo(toNumbers);
						sinchReq.setBody(failureSMSText);
						webClientData.communicationSmsApiCall(sinchReq);

					} else if ("email".equalsIgnoreCase(comm_preference)) {

						variables.put("portal_User", caseDetailsDao.fetchfullname(email));
						variables.put("sign_In", webClientData.signInUrl);
						emailDetails.setEmailId(email);
						emailDetails.setFullName(fullName);
						emailDetails.setTemplateID(templateID);
						emailDetails.setTemplateName(Constants.templateName);
						emailDetails.setVariables(variables);

						String emailjsonString = objectMapper.writeValueAsString(emailDetails);

						LOG.info("Email body to be sent to webclient call {}", emailjsonString);

						webClientData.communcationEmailApiCall(emailDetails);
						LOG.info("Failure email for case withraw  sent successfully through webclient call {}",
								emailjsonString);
					}
				}

				LOG.info("Record not created in portal table ");

				response.setMessage("Portal activity could not be created, response fail from OData Api");
				response.setSuccess(false);
				response.setStatus(HttpStatus.PRECONDITION_FAILED);
			}

		} catch (Exception e) {

			LOG.error("Inside Exception block , Exception in Withdraw case method {}", e.getMessage());

			String exceptionMessage = ticketNumber + " : Case Withdraw failed, exception occured";
			caseActivityImpl.createNotificationRecord(request, notifyModel, id, exceptionMessage, userOid);

			// Update STATUS in caseUpdate table to Failure
			updateRequestsRepository.updateCaseTable(Constants.FAILED, id);

			// Send email Notification for Failure to caseWithdraw
			// String reasonForChangeText =
			// updateRequestsRepository.getReasonForChangeText(dto.getReasonForChange());
			if (validateSession.isValidSession() == false) {
				if (mobileNumber != null && comm_preference.equalsIgnoreCase("phone")) {

					List<String> toNumbers = new ArrayList<>();
					toNumbers.add(mobileNumber);
					sinchReq.setTo(toNumbers);
					sinchReq.setBody(failureSMSText);
					webClientData.communicationSmsApiCall(sinchReq);

				} else {
					
					
					variables.put("portal_User", caseDetailsDao.fetchfullname(email));
					variables.put("sign_In", webClientData.signInUrl);
					emailDetails.setEmailId(email);
					emailDetails.setFullName(fullName);
					emailDetails.setTemplateID(templateID);
					emailDetails.setTemplateName(Constants.templateName);
					emailDetails.setVariables(variables);

					webClientData.communcationEmailApiCall(emailDetails);

					String emailjsonString = objectMapper.writeValueAsString(emailDetails);
					LOG.info("Email body to be sent to webclient call {}", emailjsonString);

					webClientData.communcationEmailApiCall(emailDetails);
					LOG.info("email sent successfully through webclient call {}", emailjsonString);
				}
			}
			LOG.info("Record not created in portal table ");

			response.setMessage("Portal activity could not be created due to exception");
			response.setSuccess(false);
			response.setStatus(HttpStatus.BAD_REQUEST);

		}
		LOG.info("Response being sent to Controller from method : {}", response.toString());
		return response;

	}

}
