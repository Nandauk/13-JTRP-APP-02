package com.ombudsman.service.complainant.model;

public class CaseConversationDetail {
	
	private String messageOriginator;
	private String message;
	private String createdOn;
	public CaseConversationDetail(String messageOriginator, String message, String createdOn) {
		super();
		this.messageOriginator = messageOriginator;
		this.message = message;
		this.createdOn = createdOn;
	}
	public String getMessageOriginator() {
		return messageOriginator;
	}
	public void setMessageOriginator(String messageOriginator) {
		this.messageOriginator = messageOriginator;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getCreatedOn() {
		return createdOn;
	}
	public void setCreatedOn(String createdOn) {
		this.createdOn = createdOn;
	}
	

}
