package com.ombudsman.service.complainant.service.repository;


import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Component;

import com.ombudsman.service.complainant.exception.CaseOutComesNotFoundException;
import com.ombudsman.service.complainant.exception.SQLDataAccessException;
import com.ombudsman.service.complainant.model.CaseConversationDetail;
import com.ombudsman.service.complainant.model.dto.CaseByCaseReferenceDto;

@Component
public class CaseDetailsJdbcRepository {
	@Autowired
	JdbcTemplate jdbcTemplate;
	@Autowired
	NamedParameterJdbcTemplate namedJdbcTemplate;
	private static final Logger LOG = LoggerFactory.getLogger(CaseDetailsJdbcRepository.class);
	
	public void setDataSource(DataSource dataSource) {
		this.jdbcTemplate = new JdbcTemplate(dataSource);
	}
	
	public String fetchfullname(final String emailAdress) {
		String sql = "SELECT firstname FROM contact WHERE emailaddress1 = ?";
		List<String> result = jdbcTemplate.query(sql, (rs, rowNum) -> rs.getString("firstname"), emailAdress);

		return result.isEmpty() ? null : result.get(0);
	}
	
	public Map<String, Object> getOfferOutcomes(Map<String, Object> reqParam) throws SQLDataAccessException{
		final SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate)
				.withProcedureName("prc_dp_getcaseoutcome");
		SqlParameterSource in = new MapSqlParameterSource(reqParam);
		LOG.debug("getCaseListDetails method parameteres passing to Store procedure::{}:", reqParam);
		return simpleJdbcCall.execute(in);

	}
	
	public List<Object> chkIncidentAuthorized(Map<String, Object> reqParam) throws SQLDataAccessException{
		  final String sql = "Select COUNT(fos_case) as count  from caselink caselinktable INNER JOIN dbo.contact contacttable ON (CASE WHEN :roleid = 'Organisation Complainant' THEN  caselinktable.fos_organisationid ELSE caselinktable.fos_individualid END)=(CASE WHEN :roleid = 'Organisation Complainant' THEN  contacttable.parentcustomerid ELSE contacttable.contactid END) INNER JOIN dp_user_dpcomplainant usertable ON usertable.pnxuuid = contacttable.contactid Where usertable.oid =:oid AND caselinktable.fos_case =:caseid";
			
			final SqlParameterSource parameters = new MapSqlParameterSource(reqParam);
			return namedJdbcTemplate.query(sql, parameters,
					(rs, rowNum) -> rs.getInt("count"));
		}
	
	public Integer getCaseCount(Map<String, Object> reqParam) throws SQLDataAccessException{
		  final String sql = "select count(*) from incident where incidentid in (select distinct fos_case from caselink where fos_individualid = (select pnxuuid from dp_user_dpcomplainant where oid= :userOid))";
			
			final SqlParameterSource parameters = new MapSqlParameterSource(reqParam);
			return namedJdbcTemplate.queryForObject(sql,parameters, Integer.class);
		}
	
	public Map<String, Object> getCaseDetailsById(Map<String, Object> reqParam) throws SQLDataAccessException{
		final SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate)
				.withProcedureName("prc_GetCasedetailsComplainant");
		SqlParameterSource in = new MapSqlParameterSource(reqParam);
		LOG.debug("getCaseListDetails method parameteres passing to Store procedure::{}:", reqParam);
		return simpleJdbcCall.execute(in);

	}
	
	public Map<String, Object> getCaseCountFrUser(Map<String, Object> reqParam) throws SQLDataAccessException{
		final SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate)
				.withProcedureName("prc_GetComplainantStatistics_summary");
		SqlParameterSource in = new MapSqlParameterSource(reqParam);
		LOG.info("getCaseListDetails method parameteres passing to Store procedure::{}:", reqParam);
		return simpleJdbcCall.execute(in);

	}

	public String getCaseIncidentId(Map<String, Object> reqParam) throws SQLDataAccessException{
		  final String sql = "select incidentid from incident where incidentid in (select distinct fos_case from caselink where fos_individualid = (select pnxuuid from dp_user_dpcomplainant where oid= :userOid))";
			
			final SqlParameterSource parameters = new MapSqlParameterSource(reqParam);
			return namedJdbcTemplate.queryForObject(sql,parameters, String.class);
		}
	
	
		public String getCaseStatus(String incidentid, String oid) throws SQLDataAccessException {
			final String sql = "select TOP 1 status from dp_complainant_case_updates where case_id =? and reason_for_change = '140000007' ORDER BY created DESC";
			List<String> result = jdbcTemplate.query(sql, (rs, rowNum) -> rs.getString("status"), incidentid);
			return result.isEmpty() ? null : result.get(0);
		}

	public String fetchContactIdByOid(String oid) {
	    String sql = "SELECT pnxuuid FROM dp_user_dpcomplainant WHERE oid = ?";
	    List<String> result = jdbcTemplate.query(sql, (rs, rowNum) -> rs.getString("pnxuuid"), oid);	   
	    return result.isEmpty() ? null : result.get(0);
	}

    public String fetchAccountIdByContactId(String contactId) {
	    String sql = "SELECT parentcustomerid FROM contact WHERE contactid = ?";
	    List<String> result = jdbcTemplate.query(sql, (rs, rowNum) -> rs.getString("parentcustomerid"), contactId);

	   
	    return result.isEmpty() ? null : result.get(0);
	}
    
	public Map<String, Object> getCaseOwnerDetails(Map<String, Object> reqParam) throws SQLDataAccessException{
		final SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate)
				.withProcedureName("prc_GetCaseownerComplainant");
		SqlParameterSource in = new MapSqlParameterSource(reqParam);
		LOG.debug("getCaseOwnerDetails method parameteres passing to Store procedure::{}:", reqParam);
		return simpleJdbcCall.execute(in);

	}
	
	public List<CaseConversationDetail> getCaseMessagingDetail(String incidentId) throws SQLDataAccessException
	{
		  final String sql = "SELECT CASE WHEN fos_directionname = 'Outgoing' THEN 'Financial ombudsman service' ELSE full_name END AS messageOriginator,createdon as createdOn,description as message FROM	(SELECT dpuc.first_name, dpuc.last_name, dpuc.full_name, all_inc.* FROM (SELECT activityid AS DigitalMessageId,fos_directionname, [description] , regardingobjectid, createdon, messagesentbydpuseradname, messagesentbydpuseradoid  FROM  dbo.fosdigitalmessages fdm WHERE regardingobjectid = :incidentId UNION SELECT temp_digitalmessageprocessingid  AS DigitalMessageId,fos_directionname ,[description] , regardingobjectid ,createdon, messagesentbydpuseradname, messagesentbydpuseradoid FROM dbo.dp_phx_digitalmessagesprocessing dpm WHERE  dpm.processingstatus in ('In_progress','Failed') AND regardingobjectid = :incidentId ) all_inc LEFT JOIN dbo.dp_user_dpcomplainant dpuc ON dpuc.oid = all_inc.messagesentbydpuseradoid)  message_data";
			
			final SqlParameterSource parameters = new MapSqlParameterSource("incidentId", incidentId);
			return namedJdbcTemplate.query(sql, parameters,
					(rs, rowNum) -> new CaseConversationDetail(rs.getString("messageOriginator"),rs.getString("message"),rs.getString("createdOn")));
	}
	
	public List<CaseByCaseReferenceDto> getCaseIncidentidByCaseReference(Map<String, Object> reqParam) throws SQLDataAccessException{
		  final String sql = "SELECT incidentid FROM   incident WHERE  ticketnumber = :ticket  AND statecode  IN (0,1)  AND (fos_suppressedfordigitalportal NOT IN ('140000002', '140000001')  OR fos_suppressedfordigitalportal IS NULL)";
			
			final SqlParameterSource parameters = new MapSqlParameterSource(reqParam);
			return namedJdbcTemplate.query(sql, parameters,
					(rs, rowNum) -> new CaseByCaseReferenceDto(rs.getString("incidentid")));
		}
	
	public String datetimeformate(String date) {
		LOG.info("start date time formate method");
		if (date != null) {
			LOG.info("date is not null:-{}",date);
			try {
				LocalDateTime localDateTime = LocalDateTime.parse(date,DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSSSSSS"));
				String format = localDateTime.format(DateTimeFormatter.ofPattern("MM/dd/yyyy hh:mm:ss a"));
				LOG.info("after formate change:-{}",format);
				return format;
			} catch (Exception e) {
				LOG.error("after formate change:-{}",date);
				throw new CaseOutComesNotFoundException("Datetime convertion error");
			}
		} else {
			LOG.debug("date is null:-{}",date);
			return null;
		}
	}


}
