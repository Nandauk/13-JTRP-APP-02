package com.ombudsman.service.complainant.serviceimpl;

import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Service;

import com.ombudsman.service.complainant.common.Constants;
import com.ombudsman.service.complainant.common.UserBean;
import com.ombudsman.service.complainant.common.WebClientData;
import com.ombudsman.service.complainant.exception.CaseManagementInvalidEventNameException;
import com.ombudsman.service.complainant.exception.RecordCreationException;
import com.ombudsman.service.complainant.model.ApiResponse;
import com.ombudsman.service.complainant.model.CaseWithdraw;
import com.ombudsman.service.complainant.model.dto.AuditMaster;
import com.ombudsman.service.complainant.model.dto.Notification;
import com.ombudsman.service.complainant.model.dto.NotificationModel;
import com.ombudsman.service.complainant.model.dto.RequestModel;
import com.ombudsman.service.complainant.model.dto.UserEventConfiguration;
import com.ombudsman.service.complainant.service.CaseActivity;
import com.ombudsman.service.complainant.service.repository.AuditRepository;
import com.ombudsman.service.complainant.service.repository.NotificationRepository;
import com.ombudsman.service.complainant.service.repository.RequestModelRepository;
import com.ombudsman.service.complainant.service.repository.UserEventConfigurationRepository;

@Service
public class CaseActivityImpl implements CaseActivity {

	private static final String API_ERROR_RECORD_CREATION_FAILED = "api.error.RecordCreationFailed";

	private static final Logger LOG = LoggerFactory.getLogger(CaseActivityImpl.class);

	@Autowired
	UserBean userbean;

	@Autowired
	AuditRepository auditMasterRepository;

	@Autowired
	private MessageSource messageSource;
	
	@Autowired
	private Constants constant;

	@Autowired
	UserEventConfigurationRepository userEventConfigurationRepository;

	@Autowired
	RequestModelRepository requestModelRepository;
	
	@Autowired
	NotificationRepository notificationRepository;

	@Autowired
	WebClientData webClientData;


	@Override
	public String activity(CaseWithdraw dto, String message) {
		ApiResponse response = new ApiResponse();

		UserEventConfiguration eventName = userEventConfigurationRepository.getUserEventRecord(Constants.userEventName);
		LOG.info("UserEventName:-{}", eventName.getUserEventName());

		if (!(eventName.getUserEventName().isBlank() && eventName.getUserEventName().isEmpty())) {
			postAuditEntries(response, eventName.getUserEventName());
		}

		// Updating data in Request Entity
		RequestModel request = new RequestModel();
		String id = requestEntity(request, requestModelRepository, dto, eventName.getUserEventName());
		LOG.info("Id from Request entity from CaseWithdraw : {}", id);

//		if (id != null) {
//			// Updating data in Notification Entity through Webclient
//			Notification notifyModel = new Notification();
//
//			try {
//				notificationEntity(request, notifyModel, id, message);
//				//webClientData.caseupdateNotificationWebclient(notifyModel);
//				LOG.info("caseupdateNotificationWebclient successfully");
//
//			} catch (Exception e) {
//
//				request.setRequestStatusId(4);
//				request.setRequestId(id);
//				request.setRequestStatusDescription("Failed for Notification ");
//				requestModelRepository.save(request);
//				throw new RecordCreationException("Record Creation Failed. Please Try Again.", "");
//			}
//		}
		return id;
	}

	public void postAuditEntries(ApiResponse genericResponse, String userEventName) {
		LOG.info("getAuditEntries method started ");
		AuditMaster audit = new AuditMaster();
		try {

			audit.setUserOID(userbean.getUserObjectId());
			OffsetDateTime offsetdatetime = OffsetDateTime.now();
			audit.setAuditEventTimestamp(offsetdatetime);
			audit.setAuditEventName(userEventName);
			audit.setCreatedBy(userbean.getName());
			auditMasterRepository.save(audit);
			LOG.info("getAuditEntries method ended {}", audit);

		} catch (Exception e) {
			genericResponse.setMessage("Case Management Invalid Event Name ");
			throw new CaseManagementInvalidEventNameException("Case Management Invalid Event Name ",
					messageSource.getMessage("api.error.CaseManagementInvalidEventName", null, Locale.ENGLISH), null);

		}

	}

	private String requestEntity(RequestModel request, RequestModelRepository requestModelRepository,
			CaseWithdraw updatecase, String userEventName) {
		LOG.info("RequestEntity method started ");
		String requestId;

		try {
			request.setUserOid(userbean.getUserObjectId());
			request.setRequestingActivityName(userEventName);
			request.setRequestStatusId(1);
			request.setRequestStatusDescription("InProgress");
			request.setRequestProcessingDetails(updatecase.getComments().toString());
			OffsetDateTime offsetdatetime = OffsetDateTime.now();
			request.setRequestStartTime(offsetdatetime);
			request.setRequestProcessingCounter(0);
			request.setCreatedBy("dp-java-comp-casemanagement-001");
			request.setCreatedOn(offsetdatetime);

			requestModelRepository.save(request);
			requestId = request.getRequestId();
			LOG.info("RequestEntity method ended {}", requestId);

		} catch (Exception e) {
			request.setRequestStatusId(4);
			request.setRequestStatusDescription("Failed");
			throw new RecordCreationException("Record Creation Failed. Please Try Again. ", "");
		}

		return requestId;
	}

	public void createNotificationRecord(RequestModel request, Notification notifyModel, String requestId,
			String ticketNumber,String oid) {
		//oid
		try {
			LOG.info("notificationEntity method started ");
			notifyModel.setRequestId(requestId);
			notifyModel.setUserOid(oid);
			notifyModel.setNotificationStatusId("3");
			notifyModel.setRequestingActivityName(Constants.userEventName);
			notifyModel.setMessage(ticketNumber);
			notifyModel.setModifiedBy(request.getModifiedBy());
			LocalDateTime createdOn = getutcTime();
			LOG.info("UTC time added {}",createdOn);
			notifyModel.setCreated_on(createdOn);
			notifyModel.setCreatedBy("dp-java-comp-casemanagement-001");
			notifyModel.setModifiedOn(request.getModifiedOn());
			notificationRepository.save(notifyModel);
			LOG.info("notificationEntity method ended ");
		} catch (Exception e) {
			notifyModel.setNotificationStatusId("4");
			LOG.info("Exception meaage : {}",e.getMessage());
			throw new RecordCreationException("Record Creation Failed. Please Try Again.", "");
		}

	}
	
	private LocalDateTime getutcTime()
	{
		ZonedDateTime utcTime=ZonedDateTime.now(ZoneOffset.UTC);
		LocalDateTime createdon=utcTime.toLocalDateTime();
		return createdon;
	}

}
