package com.ombudsman.service.complainant.service.repository;

import org.springframework.stereotype.Repository;

import com.ombudsman.service.complainant.model.dto.CaseIllustrationDto;

import jakarta.transaction.Transactional;

import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

@Repository
public interface CaseIllustrationRepository extends JpaRepository<CaseIllustrationDto, UUID>{
	
	@Query(value = "SELECT * FROM dp_complainant_case_illustration_details where incidentid = :incidentId", nativeQuery = true)
	CaseIllustrationDto getCaseIllustrationByIncidentId(@Param("incidentId") String incidentId);
	
    @Transactional
	@Modifying
	@Query(value = "update dp_complainant_case_illustration_details set previous_stage_code= :prevStageCode,current_stage_code= :currStageCode,furthest_stage_code= :furthStageCode where incidentid = :incidentId", nativeQuery = true)
	void updateCaseIllustrationByIncidentId(@Param("prevStageCode") String prevStageCode,@Param("currStageCode") String currStageCode,@Param("furthStageCode") String furthStageCode,@Param("incidentId") UUID incidentId);

}
