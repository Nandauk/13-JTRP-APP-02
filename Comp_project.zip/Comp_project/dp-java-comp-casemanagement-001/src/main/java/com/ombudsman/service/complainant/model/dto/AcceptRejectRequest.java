package com.ombudsman.service.complainant.model.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;



public class AcceptRejectRequest {
	
	@NotNull
	@NotBlank
	@JsonProperty("fos_offeroroutcomeid")
	private String fosOfferoroutcomeId;
	@NotNull
	@NotBlank
	@JsonProperty("incidentid")
	private String incidentId;
	@NotNull
	@NotBlank
	private String flag;// value should be Accepted/Rejected
	/* private String ticketNumber; */
	private String comment;
	private String outcomeDate;

	/*
	 * private String email; private String Name; private String accountId; private
	 * String packageId;
	 */
	public String getFosOfferoroutcomeId() {
		return fosOfferoroutcomeId;
	}
	public void setFosOfferoroutcomeId(String fosOfferoroutcomeId) {
		this.fosOfferoroutcomeId = fosOfferoroutcomeId;
	}
	public String getIncidentId() {
		return incidentId;
	}
	public void setIncidentId(String incidentId) {
		this.incidentId = incidentId;
	}
	public String getFlag() {
		return flag;
	}
	public void setFlag(String flag) {
		this.flag = flag;
	}

	/*
	 * public String getTicketNumber() { return ticketNumber; } public void
	 * setTicketNumber(String ticketNumber) { this.ticketNumber = ticketNumber; }
	 */
	public String getComment() {
		return comment;
	}
	public void setComment(String comment) {
		this.comment = comment;
	}
	/*
	 * public String getEmail() { return email; } public void setEmail(String email)
	 * { this.email = email; } public String getName() { return Name; } public void
	 * setName(String name) { Name = name; } public String getAccountId() { return
	 * accountId; } public void setAccountId(String accountId) { this.accountId =
	 * accountId; } public String getPackageId() { return packageId; } public void
	 * setPackageId(String packageId) { this.packageId = packageId; }
	 */
	public String getOutcomeDate() {
		return outcomeDate;
	}
	public void setOutcomeDate(String outcomeDate) {
		this.outcomeDate = outcomeDate;
	}
	


}
