package com.ombudsman.service.complainant.exception;

import java.time.LocalDateTime;

import org.springframework.http.HttpStatus;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonPropertyOrder({ "respondents", "timeStamp", "message", "status", "errors" })
public class ApiError {

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd-MM-yyyy hh:mm:ss")
	private LocalDateTime timestamp;

	private HttpStatus status;
	private String errorMessage;
	private String errorCode;
	private int httpCode;
	

	public ApiError(LocalDateTime timestamp, HttpStatus status, String errorMessage, String errorCode) {
		super();
		this.timestamp = timestamp;
		this.status = status;
		this.errorMessage = errorMessage;
		this.errorCode = errorCode;
		
	}

	public ApiError(LocalDateTime now, int httpcode, String errorMessage2, String errorCode2) {
        super();
        this.timestamp = now;
        this.httpCode = httpcode;
        this.errorMessage = errorMessage2;
        this.errorCode = errorCode2;

    }

	public LocalDateTime getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(LocalDateTime timestamp) {
		this.timestamp = timestamp;
	}

	public HttpStatus getStatus() {
		return status;
	}

	public void setStatus(HttpStatus status) {
		this.status = status;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	
	public int getHttpCode() { 
		return httpCode; 
	}
	


}
