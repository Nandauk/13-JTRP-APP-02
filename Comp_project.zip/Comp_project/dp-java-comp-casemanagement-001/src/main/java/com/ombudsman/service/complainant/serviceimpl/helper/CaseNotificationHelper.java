package com.ombudsman.service.complainant.serviceimpl.helper;

import java.time.OffsetDateTime;
import java.util.UUID;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ombudsman.service.complainant.exception.RecordCreationException;
import com.ombudsman.service.complainant.model.OfferoutcomeResponse;
import com.ombudsman.service.complainant.model.dto.OfferoutcomeUpdateRequestObj;
import com.ombudsman.service.complainant.service.repository.NotificationRepository;
import com.ombudsman.service.complainant.service.repository.OfferoutcomeRepository;
import com.ombudsman.service.complainant.service.repository.OfferoutcomeResponseRepository;

@Service
public class CaseNotificationHelper {
	Logger LOG = LogManager.getRootLogger();
	@Autowired
	OfferoutcomeRepository offeroutcomeRepository;
	
	@Autowired
	NotificationRepository notificationRepository;
	@Autowired
	OfferoutcomeResponseRepository offeroutcomeResponseRepository;
	
	
	

public void updateOfferoutcome(String offeroutcomeId,OfferoutcomeUpdateRequestObj offeroutcomeUpdateRequestObj) {
	LOG.info(" updateOfferoutcome method called from Accept/Reject");
	String complainantResponseName="";
	if(offeroutcomeUpdateRequestObj.getFosComplainantresponse() == 140000001)
	{
		complainantResponseName = "Accepted";
	}else if(offeroutcomeUpdateRequestObj.getFosComplainantresponse() == 140000002)
	{
		complainantResponseName = "Rejected";	
	}
	offeroutcomeRepository.updateFosComplainantresponseByFosOfferoroutcomeid(offeroutcomeUpdateRequestObj.getFosComplainantresponse(),
			UUID.fromString(offeroutcomeId),complainantResponseName);
	
}

public void insertOfferoutcomeResponseRecord(String offeroutcomeId, String response, String date ,String createdOrModifiedBy,String userComment) {
	LOG.info("insertOfferoutcomeResponseRecord method called for  Request Model Accept/Reject");
	OfferoutcomeResponse offeroutcomeResponse=new OfferoutcomeResponse();
	try {
		OffsetDateTime offsetdatetime = OffsetDateTime.now();
		//OffsetDateTime responseOffsetdatetime=OffsetDateTime.parse(date);
	offeroutcomeResponse.setOfferoutcomeId(UUID.fromString(offeroutcomeId));
	offeroutcomeResponse.setPhoenixRespone(response);
	offeroutcomeResponse.setRequestDatetime(offsetdatetime);
	offeroutcomeResponse.setCreatedOn(offsetdatetime);
	offeroutcomeResponse.setCreatedBy(createdOrModifiedBy);
	offeroutcomeResponse.setModifiedOn(offsetdatetime);
	offeroutcomeResponse.setModifiedBy(createdOrModifiedBy);
	offeroutcomeResponse.setUserComments(userComment);
	offeroutcomeResponseRepository.save(offeroutcomeResponse);
	
}
	 catch (Exception e) {
			
			LOG.info("Request Creation Failed for OfferoutcomeResponse . Please Try Again:-{}", e.getMessage());
			throw new RecordCreationException("Record Creation Failed for OfferoutcomeResponse entity Please Try Again.",e.getMessage());
			
		}

}

}
