package com.ombudsman.service.complainant.model.dto;

import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import com.ombudsman.service.complainant.model.RequestProcessingDetails;

@Mapper
public interface RequestProcessingDetailsMapper {

    RequestProcessingDetailsMapper INSTANCE = Mappers.getMapper(RequestProcessingDetailsMapper.class);

    RequestProcessingDetails toRequestProcessingDetails(AcceptRejectRequest source);

    AcceptRejectRequest fromRequestProcessingDetails(RequestProcessingDetails target);
}