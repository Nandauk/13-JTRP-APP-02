package com.ombudsman.service.complainant.controller;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.text.ParseException;
import java.time.LocalDateTime;

import javax.security.auth.login.AccountNotFoundException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.azure.json.implementation.jackson.core.JsonProcessingException;
import com.ombudsman.service.complainant.common.CaseManagementWebClient;
import com.ombudsman.service.complainant.common.CommonUtil;
import com.ombudsman.service.complainant.common.UserBean;
import com.ombudsman.service.complainant.common.ValidateUserSession;
import com.ombudsman.service.complainant.exception.CaseDetailsNotFoundException;
import com.ombudsman.service.complainant.exception.InputValidationException;
import com.ombudsman.service.complainant.exception.InvalidOrganisationException;
import com.ombudsman.service.complainant.exception.MailJetServiceException;
import com.ombudsman.service.complainant.exception.MandatoryFieldException;
import com.ombudsman.service.complainant.exception.OrganizationNotFoundException;
import com.ombudsman.service.complainant.exception.SQLDataAccessException;
import com.ombudsman.service.complainant.exception.UnAuthorisedException;

import com.ombudsman.service.complainant.model.ApiResponse;
import com.ombudsman.service.complainant.model.CaseWithdraw;
import com.ombudsman.service.complainant.model.dto.AcceptRejectRequest;
import com.ombudsman.service.complainant.model.request.CaseByCaseReferenceReq;
import com.ombudsman.service.complainant.model.request.CaseDetailsByIdReq;
import com.ombudsman.service.complainant.model.request.CaseFileFrDownloadReq;
import com.ombudsman.service.complainant.model.request.CaseOutcomeByIdReq;
import com.ombudsman.service.complainant.model.response.CaseByCaseReferenceRes;
import com.ombudsman.service.complainant.model.response.CaseCountRes;
import com.ombudsman.service.complainant.model.response.CaseDetailsByIdRes;
import com.ombudsman.service.complainant.model.response.CaseDocumentFrDownloadRes;
import com.ombudsman.service.complainant.model.response.CaseMessagingFrDownloadRes;
import com.ombudsman.service.complainant.model.response.CaseOutcomeByIdRes;
import com.ombudsman.service.complainant.model.response.CaseOwnerRes;
import com.ombudsman.service.complainant.model.response.CaseSummaryRes;
import com.ombudsman.service.complainant.model.response.GenericResponse;
import com.ombudsman.service.complainant.service.CaseByCaseReferenceService;
import com.ombudsman.service.complainant.service.CaseCountService;
import com.ombudsman.service.complainant.service.CaseDetailDownloadService;
import com.ombudsman.service.complainant.service.CaseDetailsByIdService;
import com.ombudsman.service.complainant.service.CaseOutcomeByIdService;
import com.ombudsman.service.complainant.service.CaseSummaryService;
import com.ombudsman.service.complainant.service.IUpdateFileService;
import com.ombudsman.service.complainant.serviceimpl.helper.AcceptRejectHelper;

import jakarta.validation.Valid;

@RestController
public class CaseManagementController {



	private static final String INDIVIDUAL_COMPLAINANT = "Individual Complainant";
	private static final String ORGANISATION_COMPLAINANT = "Organisation Complainant";

	Logger appLogger = LogManager.getRootLogger();

	@Autowired
	CaseOutcomeByIdService caseOutcomeByIdService;



	@Autowired
	CommonUtil commonUtil;

	@Autowired
	UserBean userbean;

	@Autowired
	private IUpdateFileService updateFileService;

	@Autowired
	ValidateUserSession validateUserSession;

	@Autowired
	CaseManagementWebClient caseManagementWebClient;

	@Autowired
	CaseDetailsByIdService caseDetailsByIdService;

	@Autowired
	CaseCountService caseCountService;

	@Autowired
	CaseDetailDownloadService caseDetailDownloadService;

	@Autowired
	CaseSummaryService caseSummaryService;

	@Autowired
	AcceptRejectHelper acceptRejectHelper;

	@Autowired
	CaseByCaseReferenceService caseByCaseReferenceService;

	@GetMapping(path = "/compcasemanagement/v1/caseservice/getCaseCount")
	public @ResponseBody ResponseEntity<CaseCountRes> getCaseCount() throws SQLDataAccessException,
			UnAuthorisedException, IOException, AccountNotFoundException, InvalidOrganisationException {
		appLogger.info("CaseManagement Casepreference Controller Method Started.CorrelationId:-{} OID:-{}",
				userbean.getCorrelationId(), userbean.getUserObjectId());

		CaseCountRes response = null;
		if (validateUserSession.isValidSession() && (userbean.getRoles().contains(INDIVIDUAL_COMPLAINANT)
				|| userbean.getRoles().contains(ORGANISATION_COMPLAINANT))) {
			response = caseCountService.getCaseCount();
			appLogger.info("End of CaseManagement Casepreference Controller Method.CorrelationId:-{} OID:-{}",
					userbean.getCorrelationId(), userbean.getUserObjectId());
			return new ResponseEntity<>(response, HttpStatus.OK);
		}
		return new ResponseEntity<>(response, HttpStatus.UNAUTHORIZED);

	}

	@PostMapping("/compcasemanagement/v1/caseservice/getCaseDetails")
	public ResponseEntity<CaseDetailsByIdRes> getCaseDetailsById(@Valid @RequestBody CaseDetailsByIdReq request)
			throws SQLDataAccessException, UnAuthorisedException, IOException {

		appLogger.info("CaseManagement Casedetails Controller Method Started.CorrelationId:-{} OID:-{}",
				userbean.getCorrelationId(), userbean.getUserObjectId());
		CaseDetailsByIdRes response = null;
		if (validateUserSession.isValidSession() && (userbean.getRoles().contains(INDIVIDUAL_COMPLAINANT)
				|| userbean.getRoles().contains(ORGANISATION_COMPLAINANT))) {
			userbean.setUserObjectId(userbean.getUserObjectId());

			response = caseDetailsByIdService.getCaseDetailsById(request);

			appLogger.info("End of CaseManagement Casedetails Controller Method.CorrelationId:-{} OID:-{}",
					userbean.getCorrelationId(), userbean.getUserObjectId());
			return new ResponseEntity<>(response, HttpStatus.OK);
		}
		return new ResponseEntity<>(response, HttpStatus.UNAUTHORIZED);
	}

	@PostMapping(value = "/compcasemanagement/v1/caseservice/getCaseOutcome")
	public ResponseEntity<CaseOutcomeByIdRes> getCaseOutcomeById(@Valid @RequestBody CaseOutcomeByIdReq request)
			throws SQLDataAccessException, AccountNotFoundException, UnAuthorisedException, IOException {

		appLogger.info("CaseManagement Caseoutcomes Controller Method Started.CorrelationId:-{} OID:-{}",
				userbean.getCorrelationId(), userbean.getUserObjectId());
		CaseOutcomeByIdRes response = null;
		if (validateUserSession.isValidSession() && (userbean.getRoles().contains(INDIVIDUAL_COMPLAINANT)
				|| userbean.getRoles().contains(ORGANISATION_COMPLAINANT))) {
			response = caseOutcomeByIdService.getCaseOutcomeById(request);

			appLogger.info("End of CaseManagement Caseoutcomes Controller Method.CorrelationId:-{} OID:-{}",
					userbean.getCorrelationId(), userbean.getUserObjectId());
			return new ResponseEntity<>(response, HttpStatus.OK);
		}
		return new ResponseEntity<>(response, HttpStatus.UNAUTHORIZED);
	}

	@PostMapping(value = "/compcasemanagement/v1/caseservice/getCaseOwner")
	public ResponseEntity<CaseOwnerRes> getCaseOwner(@Valid @RequestBody CaseDetailsByIdReq request)
			throws SQLDataAccessException, UnAuthorisedException, IOException {

		appLogger.info("CaseManagement Caseworker Controller Method Started.CorrelationId:-{} OID:-{}",
				userbean.getCorrelationId(), userbean.getUserObjectId());

		CaseOwnerRes response = null;
		if (validateUserSession.isValidSession() && (userbean.getRoles().contains(INDIVIDUAL_COMPLAINANT)
				|| userbean.getRoles().contains(ORGANISATION_COMPLAINANT))) {
			response = caseDetailsByIdService.getCaseOwnerDetails(request);
			appLogger.info("End of CaseManagement Caseworker Controller Method.CorrelationId:-{} OID:-{}",
					userbean.getCorrelationId(), userbean.getUserObjectId());
			return new ResponseEntity<>(response, HttpStatus.OK);
		}
		return new ResponseEntity<>(response, HttpStatus.UNAUTHORIZED);
	}

//Casewithdraw 
	@PostMapping("/compcasemanagement/v1/caseservice/casewithdraw")
	public ResponseEntity<ApiResponse> caseWithdraw(@RequestBody CaseWithdraw dto)
			throws UnAuthorisedException, OrganizationNotFoundException, MandatoryFieldException,
			JsonProcessingException, UnsupportedEncodingException, JSONException, ParseException,
			com.fasterxml.jackson.core.JsonProcessingException {
		appLogger.info("Complaiant case Withraw/Update Controller Method Started.CorrelationId:-{} OID:-{}",
				userbean.getCorrelationId(), userbean.getUserObjectId());
		ApiResponse response = null;
		if (validateUserSession.isValidSession() && (userbean.getRoles().contains(INDIVIDUAL_COMPLAINANT)
				|| userbean.getRoles().contains(ORGANISATION_COMPLAINANT))) {
			response = updateFileService.updateCase(dto);
			appLogger.info("End of Complaiant case Withraw/Update Controller Method.CorrelationId:-{} OID:-{}",
					userbean.getCorrelationId(), userbean.getUserObjectId());
			return new ResponseEntity<>(response, HttpStatus.OK);
		}
		return new ResponseEntity<>(response, HttpStatus.UNAUTHORIZED);
	}

	@PostMapping(value = "/compcasemanagement/v1/caseservice/acceptReject")
	public ResponseEntity<GenericResponse> handleAcceptOrReject(@Valid @RequestBody AcceptRejectRequest request)
			throws SQLDataAccessException, AccountNotFoundException, UnAuthorisedException, IOException,
			InputValidationException, JSONException, ParseException, MailJetServiceException {

		appLogger.info(
				"CaseManagement Caseoutcomes Controller handleAcceptOrReject Method Started.CorrelationId:-{} OID:-{}",
				userbean.getCorrelationId(), userbean.getUserObjectId());

		GenericResponse response = null;

		if (validateUserSession.isValidSession() && (userbean.getRoles().contains(INDIVIDUAL_COMPLAINANT)
				|| userbean.getRoles().contains(ORGANISATION_COMPLAINANT))) {

			response = acceptRejectHelper.handleRequest(request);

			appLogger.info("End of Complaiant case handleAcceptOrReject Controller Method.:-{} OID:-{} response:-{}",
					userbean.getCorrelationId(), userbean.getUserObjectId(), response);
			return new ResponseEntity<>(response, HttpStatus.OK);

		}

		return new ResponseEntity<>(response, HttpStatus.UNAUTHORIZED);
	}

	@PostMapping("/compcasemanagement/v1/caseservice/getSummaryDetailsForDownload")
	public ResponseEntity<CaseSummaryRes> getSummaryDetailsForDownload(@Valid @RequestBody CaseDetailsByIdReq request)
			throws SQLDataAccessException, UnAuthorisedException, IOException, CaseDetailsNotFoundException {

		appLogger.info("CaseManagement Casedetails Controller Method Started.CorrelationId:-{} OID:-{}",
				userbean.getCorrelationId(), userbean.getUserObjectId());
		CaseSummaryRes response = null;
		if (validateUserSession.isValidSession() && (userbean.getRoles().contains(INDIVIDUAL_COMPLAINANT)
				|| userbean.getRoles().contains(ORGANISATION_COMPLAINANT))) {
			// userbean.setUserObjectId("0ef03faa-6246-4c8d-97d1-3af31d9f9d5b");

			response = caseSummaryService.getCaseSummary(request);

			appLogger.info("End of CaseManagement Casedetails Controller Method.CorrelationId:-{} OID:-{}",
					userbean.getCorrelationId(), userbean.getUserObjectId());
			return new ResponseEntity<>(response, HttpStatus.OK);
		}
		return new ResponseEntity<>(response, HttpStatus.UNAUTHORIZED);
	}

	@PostMapping(value = "/compcasemanagement/v1/caseservice/getCaseOutcomeForDownload")
	public ResponseEntity<CaseOutcomeByIdRes> getCaseOutcomeForDownload(@Valid @RequestBody CaseOutcomeByIdReq request)
			throws SQLDataAccessException, AccountNotFoundException, UnAuthorisedException, IOException {

		appLogger.info("CaseManagement Caseoutcomes Controller Method Started.CorrelationId:-{} OID:-{}",
				userbean.getCorrelationId(), userbean.getUserObjectId());
		CaseOutcomeByIdRes response = null;
		if (validateUserSession.isValidSession() && (userbean.getRoles().contains(INDIVIDUAL_COMPLAINANT)
				|| userbean.getRoles().contains(ORGANISATION_COMPLAINANT))) {
			// userbean.setUserObjectId("0ef03faa-6246-4c8d-97d1-3af31d9f9d5b");
			response = caseOutcomeByIdService.getCaseOutcomeById(request);

			appLogger.info("End of CaseManagement Caseoutcomes Controller Method.CorrelationId:-{} OID:-{}",
					userbean.getCorrelationId(), userbean.getUserObjectId());
			return new ResponseEntity<>(response, HttpStatus.OK);
		}
		return new ResponseEntity<>(response, HttpStatus.UNAUTHORIZED);
	}

	@PostMapping(value = "/compcasemanagement/v1/caseservice/getCaseDocumentDetailsForDownload")
	public ResponseEntity<CaseDocumentFrDownloadRes> getCaseDocumentDetailsForDownload(
			@Valid @RequestBody CaseFileFrDownloadReq request)
			throws SQLDataAccessException, AccountNotFoundException, UnAuthorisedException, IOException {

		appLogger.info("CaseManagement Controller Method Started.CorrelationId:-{} OID:-{}",
				userbean.getCorrelationId(), userbean.getUserObjectId());
		CaseDocumentFrDownloadRes response = null;
		if (validateUserSession.isValidSession() && (userbean.getRoles().contains(INDIVIDUAL_COMPLAINANT)
				|| userbean.getRoles().contains(ORGANISATION_COMPLAINANT))) {
			// userbean.setUserObjectId("0ef03faa-6246-4c8d-97d1-3af31d9f9d5b");
			response = caseDetailDownloadService.getCaseDocumentDetailsFrDownload(request);

			appLogger.info("End of CaseManagement Caseoutcomes Controller Method.CorrelationId:-{} OID:-{}",
					userbean.getCorrelationId(), userbean.getUserObjectId());
			return new ResponseEntity<>(response, HttpStatus.OK);
		}
		return new ResponseEntity<>(response, HttpStatus.UNAUTHORIZED);
	}

	@PostMapping(value = "/compcasemanagement/v1/caseservice/getConversationMessageDetailsForDownload")
	public ResponseEntity<CaseMessagingFrDownloadRes> getConversationMessageDetailsForDownload(
			@Valid @RequestBody CaseDetailsByIdReq request)
			throws SQLDataAccessException, AccountNotFoundException, UnAuthorisedException, IOException {

		appLogger.info("CaseManagement Controller Method Started.CorrelationId:-{} OID:-{}",
				userbean.getCorrelationId(), userbean.getUserObjectId());
		CaseMessagingFrDownloadRes response = null;
		if (validateUserSession.isValidSession() && (userbean.getRoles().contains(INDIVIDUAL_COMPLAINANT)
				|| userbean.getRoles().contains(ORGANISATION_COMPLAINANT))) {
			// userbean.setUserObjectId("0ef03faa-6246-4c8d-97d1-3af31d9f9d5b");
			response = caseDetailDownloadService.getCaseConversationDetailsFrDownload(request);

			appLogger.info("End of CaseManagement Caseoutcomes Controller Method.CorrelationId:-{} OID:-{}",
					userbean.getCorrelationId(), userbean.getUserObjectId());
			return new ResponseEntity<>(response, HttpStatus.OK);
		}
		return new ResponseEntity<>(response, HttpStatus.UNAUTHORIZED);
	}

	@PostMapping(path = "/compcasemanagement/v1/caseservice/casepreference")
	public @ResponseBody ResponseEntity<CaseByCaseReferenceRes> getCaseByCasePreference(
			@Valid @RequestBody CaseByCaseReferenceReq request)
			throws SQLDataAccessException, UnAuthorisedException, IOException {
		appLogger.info("CaseManagement Casepreference Controller Method Started.CorrelationId:-{} OID:-{}",
				userbean.getCorrelationId(), userbean.getUserObjectId());

		CaseByCaseReferenceRes response = null;
		if (validateUserSession.isValidSession() && (userbean.getRoles().contains(INDIVIDUAL_COMPLAINANT)
				|| userbean.getRoles().contains(ORGANISATION_COMPLAINANT))) {
			response = caseByCaseReferenceService.getCaseIncidentidByCaseReference(request);
			appLogger.info("End of CaseManagement Casepreference Controller Method.CorrelationId:-{} OID:-{}",
					userbean.getCorrelationId(), userbean.getUserObjectId());
			return new ResponseEntity<>(response, HttpStatus.OK);
		}
		return new ResponseEntity<>(response, HttpStatus.UNAUTHORIZED);

	}

	@GetMapping(value = "/compcasemanagement/v1/caseservice/liveness")
	public ResponseEntity<GenericResponse> getLiveHealthCheck() {
		final GenericResponse result = new GenericResponse();
		result.setMessage(LocalDateTime.now().toString());
		appLogger.info(String.format("liveness started with current time: %s", LocalDateTime.now()));
		result.setStatus("Available");
		return new ResponseEntity<>(result, HttpStatus.OK);
	}

	@GetMapping(value = "/compcasemanagement/v1/caseservice/readiness")
	public ResponseEntity<GenericResponse> getRedinessHealthCheck() {
		final GenericResponse result = new GenericResponse();
		result.setMessage(LocalDateTime.now().toString());
		appLogger.info(String.format("readiness started with current time: %s", LocalDateTime.now()));
		result.setStatus("Available");
		return new ResponseEntity<>(result, HttpStatus.OK);
	}

	@GetMapping(value = "/ombudsmanservice/v1/healthcheck")
	public ResponseEntity<GenericResponse> getHealthCheck() {
		final GenericResponse result = new GenericResponse();
		result.setMessage(LocalDateTime.now().toString());
		result.setStatus("Available");
		return new ResponseEntity<>(result, HttpStatus.OK);
	}

}
