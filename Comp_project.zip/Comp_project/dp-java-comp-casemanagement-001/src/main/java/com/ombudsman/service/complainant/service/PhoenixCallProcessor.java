package com.ombudsman.service.complainant.service;

public interface PhoenixCallProcessor {
	
	
	public int updateRecordPhnx(String entity, String jsonBody);
	public String getToValue(String ownerId, String owningTeam, String owningUser);
	public String getRecordFromQueue( String entityName, String recordIdentifier) ;
	public String getRecordFromSystemUser(String entityName, String recordIdentifier);
	public int createRecordPhnx(String entity, String jsonBody);
	public String getOwnerValue(String owningteam, String owninguser);
	
}
