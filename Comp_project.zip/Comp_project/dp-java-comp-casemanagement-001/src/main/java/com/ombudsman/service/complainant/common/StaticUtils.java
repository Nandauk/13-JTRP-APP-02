package com.ombudsman.service.complainant.common;

import java.util.Locale;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.MediaType;
import org.springframework.web.reactive.function.client.WebClient;

import com.ombudsman.service.complainant.model.dto.GetCaseFileRequestDto;
import com.ombudsman.service.complainant.model.request.CaseFileFrDownloadReq;
import com.ombudsman.service.complainant.exception.DocumentException;

import reactor.core.publisher.Mono;


@Configuration
public class StaticUtils {
	
	@Autowired
	private MessageSource messageSource;
	

	@Value("${EFILE_APIM_URL}")
	public String baseurl;

	@Autowired
	UserBean userbean;
	
	Logger log = LogManager.getRootLogger();
	
	public  String callPostApi1(String url,CaseFileFrDownloadReq caseFileReq)  {
		log.info("callGetApi1 method started  ");
		try {
			String posturl = WebClient.create().post().uri(url)
					//.header(url, Authorization, Bearer + userbean.getAuthToken())
					.body(Mono.just(caseFileReq), CaseFileFrDownloadReq.class)
					.accept(MediaType.APPLICATION_JSON).retrieve()
					.bodyToMono(String.class).block();
			
			log.info("callGetApi1 method :: post the url to apim ");
			
			return posturl;
		} catch (Exception ex) {
			log.error("response for the extenal service {}",ex.getMessage());
			log.error("Data sending failed from getListOfFiles while posting to APIM");
			throw new DocumentException("Data sending failed from casedownload while posting to APIM. Please Try Again. "+ ex.getMessage() ,
					ex.getMessage(), ex.getStackTrace());
		}
	}

	
		public String getUrl(String getUrl) {
			log.info(" GetUrl method started ");
			try {
				
				String url = baseurl + getUrl ;
				log.info("Case download :: getUrl methode ended :: getting url from apim   ");
				return url;
			} catch (Exception e) {
				log.error("Error in  getUrl while fetching URL from APIM ");
				throw new DocumentException("Error in  getUrl while fetching URL from APIM. Please Try Again.",
						messageSource.getMessage("api.error.fetchingurlfailed", null, Locale.ENGLISH), null);
			}


		}

		

		



}
