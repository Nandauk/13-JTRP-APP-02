package com.ombudsman.service.complainant.exception;

public class CaseOutComesNotFoundException extends RuntimeException{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public CaseOutComesNotFoundException(String exceptionMsg)
	{
		super(exceptionMsg);
	}
}