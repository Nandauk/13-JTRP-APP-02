package com.ombudsman.service.complainant.model.response;

import java.util.List;

import com.ombudsman.service.complainant.model.CaseDetail;
import com.ombudsman.service.complainant.model.CaseIllustration;

public class CaseDetailsByIdRes extends GenericResponse {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 4447128096932131295L;
	private transient CaseDetail casedetails;
	private List<CasePartiesDetail> caseParties;
	private CaseIllustration caseIllustrationDtls;
	private String caseWithdrawStatus;
	
	
	public String getCaseWithdrawStatus() {
		return caseWithdrawStatus;
	}
	public void setCaseWithdrawStatus(String caseWithdrawStatus) {
		this.caseWithdrawStatus = caseWithdrawStatus;
	}
	public CaseDetail getCasedetails() {
		return casedetails;
	}
	public void setCasedetails(CaseDetail casedetails) {
		this.casedetails = casedetails;
	}
	public List<CasePartiesDetail> getCaseParties() {
		return caseParties;
	}
	public void setCaseParties(List<CasePartiesDetail> caseParties) {
		this.caseParties = caseParties;
	}
	public CaseIllustration getCaseIllustrationDtls() {
		return caseIllustrationDtls;
	}
	public void setCaseIllustrationDtls(CaseIllustration caseIllustrationDtls) {
		this.caseIllustrationDtls = caseIllustrationDtls;
	}

	
}
