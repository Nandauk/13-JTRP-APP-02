package com.ombudsman.service.complainant.model.dto;

public class CasePartyDto {

	private String incidentid;
	private String fos_role;
	private String partyRole;
	private String partyName;
	public String getIncidentid() {
		return incidentid;
	}
	public void setIncidentid(String incidentid) {
		this.incidentid = incidentid;
	}
	public String getFos_role() {
		return fos_role;
	}
	public void setFos_role(String fos_role) {
		this.fos_role = fos_role;
	}
	public String getPartyRole() {
		return partyRole;
	}
	public void setPartyRole(String partyRole) {
		this.partyRole = partyRole;
	}
	public String getPartyName() {
		return partyName;
	}
	public void setPartyName(String partyName) {
		this.partyName = partyName;
	}
	
}
