package com.ombudsman.service.complainant.model;

import java.util.List;

public class SystemUserResponse {
	

	private List<SystemUserData> value;

    // Getters and setters
    public List<SystemUserData> getValue() {
        return value;
    }

    public void setValue(List<SystemUserData> value) {
        this.value = value;
    }

    @Override
    public String toString() {
        return "Response{" +
                "value=" + value +
                '}';
    }

}
