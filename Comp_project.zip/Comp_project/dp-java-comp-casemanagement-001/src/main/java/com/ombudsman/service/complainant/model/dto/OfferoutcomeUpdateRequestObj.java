package com.ombudsman.service.complainant.model.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

public class OfferoutcomeUpdateRequestObj {
	
	@JsonProperty("fos_complainantresponse")
	private int fosComplainantresponse;
	


	public int getFosComplainantresponse() {
		return fosComplainantresponse;
	}


	public void setFosComplainantresponse(int fosComplainantresponse) {
		this.fosComplainantresponse = fosComplainantresponse;
	}



	

}
