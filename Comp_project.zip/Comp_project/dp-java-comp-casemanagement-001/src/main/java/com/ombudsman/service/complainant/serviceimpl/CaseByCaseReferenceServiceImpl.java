package com.ombudsman.service.complainant.serviceimpl;

import static com.ombudsman.service.complainant.common.Constants.CASE_REFERENCE_IS_A_VALID_FIELD;
import static com.ombudsman.service.complainant.common.Constants.CASE_REFERENCE_IS_NOT_A_VALID_FIELD;
import static com.ombudsman.service.complainant.common.Constants.CASE_REFERENCE_NOT_FOUND_FOR_ORGANISATION;
import static com.ombudsman.service.complainant.common.Constants.FAILED;
import static com.ombudsman.service.complainant.common.Constants.SUCCESS;

import java.io.IOException;
import java.util.List;
import java.util.Optional;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nimbusds.oauth2.sdk.util.CollectionUtils;
import com.ombudsman.service.complainant.common.CommonUtil;
import com.ombudsman.service.complainant.common.UserBean;
import com.ombudsman.service.complainant.exception.AzureServiceException;
import com.ombudsman.service.complainant.exception.CaseReferenceDetailsNotFoundException;
import com.ombudsman.service.complainant.exception.SQLDataAccessException;
import com.ombudsman.service.complainant.exception.UnAuthorisedException;
import com.ombudsman.service.complainant.model.dto.CaseByCaseReferenceDto;
import com.ombudsman.service.complainant.model.request.CaseByCaseReferenceReq;
import com.ombudsman.service.complainant.model.response.CaseByCaseReferenceRes;
import com.ombudsman.service.complainant.repository.dao.CaseDetailsDao;
import com.ombudsman.service.complainant.service.CaseByCaseReferenceService;

@Service
public class CaseByCaseReferenceServiceImpl implements CaseByCaseReferenceService {

	private CommonUtil commonUtil;

	UserBean userbean;
	
	CaseDetailsDao caseDetailsDao;
	
	@Autowired
	public CaseByCaseReferenceServiceImpl(UserBean userbean, CaseDetailsDao caseDetailsDao,
			CommonUtil commonUtil) {
		super();
		this.userbean = userbean;
		this.caseDetailsDao = caseDetailsDao;
		this.commonUtil = commonUtil;
	}
	private static final Logger log =  LogManager.getRootLogger();

	@Override
	public CaseByCaseReferenceRes getCaseIncidentidByCaseReference(CaseByCaseReferenceReq request)
			throws AzureServiceException, JSONException, IOException, SQLDataAccessException, CaseReferenceDetailsNotFoundException, UnAuthorisedException {

		log.debug("GetCaseIncidentidByCaseReference Service Method Started.CorrelationId:-{} OID:-{}",
				userbean.getCorrelationId(), userbean.getUserObjectId());
		CaseByCaseReferenceRes response = new CaseByCaseReferenceRes();
		final String methodName = "getCaseIncidentidByCaseReference";
		
		// verification as per regex provided started
		if (StringUtils.isNotEmpty(request.getCasefererence()) && commonUtil.isValidInput(request.getCasefererence())) {
			log.debug(CASE_REFERENCE_IS_A_VALID_FIELD);
				

						final List<CaseByCaseReferenceDto> caseByCaseReferenceData = Optional.ofNullable(request.getCasefererence())
								.map(i -> caseDetailsDao.getCaseIncidentidByCaseReference(request.getCasefererence()))
								.orElseThrow(() -> new CaseReferenceDetailsNotFoundException(CASE_REFERENCE_NOT_FOUND_FOR_ORGANISATION));

						if (CollectionUtils.isNotEmpty(caseByCaseReferenceData)) {
							final String incidentId = caseByCaseReferenceData.get(caseByCaseReferenceData.size() - 1)
									.getIncidentId();
														
							int count = caseDetailsDao.chkIncidentAuthorized(userbean.getUserObjectId(), incidentId,userbean.getRoles().get(0));
							
							if (count >= 1) {
							response.setIncidentid(incidentId);
							response.setStatus(SUCCESS);
							response.setMessage("OK");
							}
							else
							{
								log.info("CaseID and User are not linked, case does not belong to user ");
								response.setMessage("Case does not belong to user.");
								response.setStatus(FAILED);
							}
							 
						}
						 else {
							log.debug(CASE_REFERENCE_NOT_FOUND_FOR_ORGANISATION);
							throw new CaseReferenceDetailsNotFoundException(CASE_REFERENCE_NOT_FOUND_FOR_ORGANISATION);
						}

					//}			
		}else {
				response.setStatus(FAILED);
				response.setMessage(CASE_REFERENCE_IS_NOT_A_VALID_FIELD);
				log.debug(CASE_REFERENCE_IS_NOT_A_VALID_FIELD);
			}
		log.debug("GetCaseIncidentidByCaseReference Service Method Ended.CorrelationId:-{} OID:-{}",
				userbean.getCorrelationId(), userbean.getUserObjectId());
		return response;
	}
}
