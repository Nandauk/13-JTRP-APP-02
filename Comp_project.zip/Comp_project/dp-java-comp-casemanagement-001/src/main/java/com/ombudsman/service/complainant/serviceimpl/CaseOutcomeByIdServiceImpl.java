package com.ombudsman.service.complainant.serviceimpl;

import static com.ombudsman.service.complainant.common.Constants.CASE_OUTCOMES_NOT_FOUND;
import static com.ombudsman.service.complainant.common.Constants.FAILED;
import static com.ombudsman.service.complainant.common.Constants.INCIDENTID_IS_A_VALID_FIELD;
import static com.ombudsman.service.complainant.common.Constants.INCIDENTID_IS_NOT_A_VALID_FIELD;
import static com.ombudsman.service.complainant.common.Constants.SUCCESS;

import java.io.IOException;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.security.auth.login.AccountNotFoundException;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ombudsman.service.complainant.common.CaseOutcomeMapper;
import com.ombudsman.service.complainant.common.CommonUtil;
import com.ombudsman.service.complainant.common.Constants;
import com.ombudsman.service.complainant.common.UserBean;
import com.ombudsman.service.complainant.exception.AzureServiceException;
import com.ombudsman.service.complainant.exception.CaseOutComesNotFoundException;
import com.ombudsman.service.complainant.exception.RecordCreationException;
import com.ombudsman.service.complainant.exception.SQLDataAccessException;
import com.ombudsman.service.complainant.exception.UnAuthorisedException;
import com.ombudsman.service.complainant.model.CaseOutcome;
import com.ombudsman.service.complainant.model.Incident;
import com.ombudsman.service.complainant.model.OfferOutcome;
import com.ombudsman.service.complainant.model.RequestProcessingDetails;
import com.ombudsman.service.complainant.model.dto.CaseOutcomeDto;
import com.ombudsman.service.complainant.model.dto.Notification;
import com.ombudsman.service.complainant.model.dto.RequestModel;
import com.ombudsman.service.complainant.model.request.CaseOutcomeByIdReq;
import com.ombudsman.service.complainant.model.response.CaseOutcomeByIdRes;
import com.ombudsman.service.complainant.repository.dao.CaseDetailsDao;
import com.ombudsman.service.complainant.service.CaseOutcomeByIdService;
import com.ombudsman.service.complainant.service.repository.CaseDetailsJdbcRepository;
import com.ombudsman.service.complainant.service.repository.IncidentRepository;
import com.ombudsman.service.complainant.service.repository.NotificationRepository;
import com.ombudsman.service.complainant.service.repository.OfferoutcomeRepository;
import com.ombudsman.service.complainant.service.repository.RequestModelRepository;

@Service
public class CaseOutcomeByIdServiceImpl implements CaseOutcomeByIdService {
	private static final String requestingActivityName="outComeCase";
	private CommonUtil commonUtil;

	UserBean userbean;

	CaseDetailsDao caseDetailsDao;

	OfferoutcomeRepository offeroutcomeRepository;
	
	RequestModelRepository requestModelRepository;
	IncidentRepository incidentRepository;
	NotificationRepository notificationRepository;
	CaseDetailsJdbcRepository caseDetailsJdbcRepository;


	@Autowired
	public CaseOutcomeByIdServiceImpl(CommonUtil commonUtil, UserBean userbean,
			CaseDetailsDao caseDetailsDao, OfferoutcomeRepository offeroutcomeRepository,
			RequestModelRepository requestModelRepository, IncidentRepository incidentRepository,
			NotificationRepository notificationRepository,CaseDetailsJdbcRepository caseDetailsJdbcRepository) {
		super();
		this.commonUtil = commonUtil;
		this.userbean = userbean;
		this.caseDetailsDao = caseDetailsDao;
		this.offeroutcomeRepository = offeroutcomeRepository;
		this.requestModelRepository = requestModelRepository;
		this.incidentRepository = incidentRepository;
		this.notificationRepository=notificationRepository;
        this.caseDetailsJdbcRepository=caseDetailsJdbcRepository;
	}

	String nextValue = "";

	private static final Logger log = LogManager.getRootLogger();
	private static final String RESULT_SET_1 = "#result-set-1";
	

	@Override
	public CaseOutcomeByIdRes getCaseOutcomeById(CaseOutcomeByIdReq request)
			throws AzureServiceException, JSONException, IOException, SQLDataAccessException, AccountNotFoundException, UnAuthorisedException {

		log.debug("GetCaseOutcomeById Service Method Started.CorrelationId:-{}", userbean.getCorrelationId(),
				userbean.getUserObjectId());
		final List<String> groupIds = userbean.getGroups();
		List<Object> outComesLstDtl = null;
		CaseOutcomeByIdRes caseOutcomeByIdRes = new CaseOutcomeByIdRes();

		// verification as per regex provided started
		if (StringUtils.isNotEmpty(request.getIncidentid()) && commonUtil.isValidInput(request.getIncidentid())) {
			log.debug(INCIDENTID_IS_A_VALID_FIELD);

			int count = caseDetailsDao.chkIncidentAuthorized(userbean.getUserObjectId(), request.getIncidentid(),userbean.getRoles().get(0));
			
			if (count >= 1) {

							final Map<String, Object> caseOutcomeDetails = Optional
									.ofNullable(caseDetailsDao.getOfferOutcomes(request.getIncidentid()))
									.orElseThrow(() -> new CaseOutComesNotFoundException(CASE_OUTCOMES_NOT_FOUND));

							final ObjectMapper mapper = new ObjectMapper();

							if (null != caseOutcomeDetails.get(RESULT_SET_1)) {
								outComesLstDtl = ((List<Object>) caseOutcomeDetails.get(RESULT_SET_1));

								final List<CaseOutcome> caseOutcomeDtl = outComesLstDtl.stream()
										.map(i -> mapper.convertValue(i, CaseOutcomeDto.class))
										.map(CaseOutcomeMapper.INSTANCE::caseOutcomeLst).collect(Collectors.toList());
								
								for (CaseOutcome caseOutcome : caseOutcomeDtl) {
									caseOutcome.setOutcomedate(caseDetailsJdbcRepository.datetimeformate(caseOutcome.getOutcomedate()));
								}
								if(!outComesLstDtl.isEmpty())
								{
									final List<CaseOutcomeDto> outComesLstDtlFrLatest = outComesLstDtl.stream().map(i -> mapper.convertValue(i, CaseOutcomeDto.class))
											.collect(Collectors.toList());
									CaseOutcomeDto latestoutcome = outComesLstDtlFrLatest.get(0);
									if(null == latestoutcome.getMessage_code())
									{
										caseOutcomeByIdRes.setMessageCode("no_outcome");
									}else
									{
									caseOutcomeByIdRes.setMessageCode(latestoutcome.getMessage_code());
									}
									caseOutcomeByIdRes.setFosresponsetobereceivedby(caseDetailsJdbcRepository.datetimeformate(latestoutcome.getDuedate()));
								}

								
								caseOutcomeByIdRes.setMessage("SUCCESS");
								caseOutcomeByIdRes.setStatus("OK");
								caseOutcomeByIdRes.setCaseoutcomes(caseOutcomeDtl);
							} else {
								caseOutcomeByIdRes.setStatus(SUCCESS);
								caseOutcomeByIdRes.setMessage(CASE_OUTCOMES_NOT_FOUND);
								log.debug(CASE_OUTCOMES_NOT_FOUND);
							}
			}
			else
			{
				log.info("CaseID and User are not linked, case does not belong to user ");
				caseOutcomeByIdRes.setMessage("Case does not belong to user.");
				caseOutcomeByIdRes.setStatus(FAILED);
			}

		} else {
			caseOutcomeByIdRes.setStatus(FAILED);
			caseOutcomeByIdRes.setMessage(INCIDENTID_IS_NOT_A_VALID_FIELD);
			log.debug(INCIDENTID_IS_NOT_A_VALID_FIELD);

		}

		log.debug("GetCaseOutcomeById Service Method Ended.CorrelationId:-{} OID:-{}", userbean.getCorrelationId(),
				userbean.getUserObjectId());
		return caseOutcomeByIdRes;
	}
	
	
	public Optional<OfferOutcome> findOfferOutcomeById(String id){
		return offeroutcomeRepository.findById(id);
		
		
		
	}
	
	
	public String  saveRecordForRequestEntity( UserBean userBean,RequestProcessingDetails requestProcessingDetails) throws JsonProcessingException {
		log.info("RequestEntity method started ");
		String requestId = null;
		RequestModel request=new  RequestModel();
		
		ObjectMapper mapper = new ObjectMapper();
		String details = mapper.writeValueAsString(requestProcessingDetails);
		try {

			

			request.setUserOid(userBean.getUserObjectId());
			request.setRequestingActivityName(requestingActivityName);
			request.setRequestStatusId(1);
			request.setRequestStatusDescription(Constants.IN_PROGRESS);
			request.setRequestProcessingDetails(details);
			OffsetDateTime offsetdatetime = OffsetDateTime.now();
			request.setRequestStartTime(offsetdatetime);
			request.setRequestProcessingCounter(0);
			request.setCreatedBy("dp-java-comp-casemanagement-001");
			request.setCreatedOn(offsetdatetime);

			requestId=requestModelRepository.save(request).getRequestId();
			
			
			log.info("RequestEntity method ended and reqestID is ");

		} catch (Exception e) {
			request.setRequestStatusId(4);
			request.setRequestStatusDescription("Failed");
			log.info("Request Creation Failed. Please Try Again. {}", e.getMessage());
			throw new RecordCreationException("Record Creation Failed for Request entity Please Try Again.",e.getMessage());
			
		}

		return requestId;
	
	}
	
	
	public Optional<Incident> findIncidentInfoById( String incidentId){
		log.info("findById method started for  Request Model Accept/Reject :: ");
		
		return incidentRepository.findById(incidentId);	
		
		
		
	}
	
	public Integer saveRecordnotificationEntity(RequestModel request, String ticketnumber, String reasonForChange) {
		Notification notifyModel = new Notification();
		Integer notificationId = 0;
		ZonedDateTime utcTime=ZonedDateTime.now(ZoneOffset.UTC);
		LocalDateTime createdon=utcTime.toLocalDateTime();
		
		try {
			log.info("notificationEntity method started ");
			notifyModel.setRequestId(request.getRequestId().toString());
			notifyModel.setUserOid(request.getUserOid());
			notifyModel.setRequestingActivityName(requestingActivityName);
			
			notifyModel.setCreated_on(createdon);
			notifyModel.setNotificationStatusId("3");
			notifyModel.setMessage(ticketnumber+"-"+reasonForChange);
			notifyModel.setCreatedBy(request.getCreatedBy());
			notifyModel.setModifiedOn(request.getModifiedOn());
			notifyModel.setModifiedBy(request.getModifiedBy());

			notificationId = notificationRepository.save(notifyModel).getNotificationid();
			log.info("Record successfully created in Notification table !! ");

		} catch (Exception e) {
			notifyModel.setNotificationStatusId("4");
			log.info("saving data in Notification Failed. {}", e.getMessage());
			throw new RecordCreationException("Record Creation Failed. Please Try Again.", e.getMessage());
		}
		return notificationId;

	}

	public Optional<RequestModel> findById(String Id) {
		log.info("findById method started for  Request Model Accept/Reject :: ");
		return requestModelRepository.findById(Id);
		
		
	}
	
}
