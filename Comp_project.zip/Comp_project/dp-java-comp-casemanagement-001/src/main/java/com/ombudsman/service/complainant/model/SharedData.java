package com.ombudsman.service.complainant.model;

import java.util.List;

public class SharedData {
	 public String fore ;
     public List<SharedDataItem> documentCodes ;
     public List<SharedDataItem> originatorCodes ;
     public List<SharedDataItem> reasonForChangeCodes ;
	public String getFore() {
		return fore;
	}
	public void setFore(String fore) {
		this.fore = fore;
	}
	public List<SharedDataItem> getDocumentCodes() {
		return documentCodes;
	}
	public void setDocumentCodes(List<SharedDataItem> documentCodes) {
		this.documentCodes = documentCodes;
	}
	public List<SharedDataItem> getOriginatorCodes() {
		return originatorCodes;
	}
	public void setOriginatorCodes(List<SharedDataItem> originatorCodes) {
		this.originatorCodes = originatorCodes;
	}
	public List<SharedDataItem> getReasonForChangeCodes() {
		return reasonForChangeCodes;
	}
	public void setReasonForChangeCodes(List<SharedDataItem> reasonForChangeCodes) {
		this.reasonForChangeCodes = reasonForChangeCodes;
	}
     
     
}
