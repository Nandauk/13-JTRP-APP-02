package com.ombudsman.service.complainant.serviceimpl;

import static com.ombudsman.service.complainant.common.Constants.CASEID_REQUIRED;
import static com.ombudsman.service.complainant.common.Constants.Get_List_Of_Files_Url;

import java.io.IOException;
import java.util.List;

import javax.security.auth.login.AccountNotFoundException;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.ombudsman.service.complainant.common.StaticUtils;
import com.ombudsman.service.complainant.common.UserBean;
import com.ombudsman.service.complainant.exception.SQLDataAccessException;
import com.ombudsman.service.complainant.exception.UnAuthorisedException;
import com.ombudsman.service.complainant.model.CaseConversationDetail;
import com.ombudsman.service.complainant.model.request.CaseDetailsByIdReq;
import com.ombudsman.service.complainant.model.request.CaseFileFrDownloadReq;
import com.ombudsman.service.complainant.model.response.CaseDocumentFrDownloadRes;
import com.ombudsman.service.complainant.model.response.CaseMessagingFrDownloadRes;
import com.ombudsman.service.complainant.repository.dao.CaseDetailsDao;
import com.ombudsman.service.complainant.service.CaseDetailDownloadService;

@Service
public class CaseDetailDownloadServiceImpl implements CaseDetailDownloadService {

	@Autowired
	StaticUtils staticUtils;
	private static final Logger log = LogManager.getRootLogger();

	@Autowired
	CaseDetailsDao caseDetailsDao;

	@Autowired
	UserBean userbean;

	@Override
	public CaseDocumentFrDownloadRes getCaseDocumentDetailsFrDownload(CaseFileFrDownloadReq request)
			throws SQLDataAccessException, AccountNotFoundException, UnAuthorisedException, IOException {

		CaseDocumentFrDownloadRes response = new CaseDocumentFrDownloadRes();
		if (request.getCaseId().isBlank() || request.getCaseId().isEmpty()) {
			response.setMessage(CASEID_REQUIRED);
			return response;
		}

		int count = caseDetailsDao.chkIncidentAuthorized(userbean.getUserObjectId(), request.getCaseId(),userbean.getRoles().get(0));
		
		if (count >= 1) {
			ObjectMapper mapper = new ObjectMapper();
			String url = staticUtils.getUrl(Get_List_Of_Files_Url);
			log.info(String.format("fetching url from apim succesfully for getListOfFiles :-%s", url));
			request.setPortalType("Complainant");
			String eFileresponse = staticUtils.callPostApi1(url, request);

			log.info("posting url to apim succesfully :: getListOfFiles method ");
			if (eFileresponse == null) {
				response.setFiles(null);
				response.setMessage("No Data Fetched from EFile");
				response.setStatus("OK");
				return response;
			}

			log.info("Responsefrom efile {}", logFormat(String.valueOf(eFileresponse)));
			response = mapper.registerModule(new JavaTimeModule()).readValue(eFileresponse,
					CaseDocumentFrDownloadRes.class);
			// response.setCaseDocuments(readValue);
			response.setStatus(eFileresponse);
			response.setMessage("Success");
			response.setStatus("OK");
			return response;
		} else {
			log.info("CaseID and User are not linked, case does not belong to user ");
			response.setMessage("Case does not belong to user.");
			response.setStatus("FAILED");
			return response;
		}

	}

	@Override
	public CaseMessagingFrDownloadRes getCaseConversationDetailsFrDownload(CaseDetailsByIdReq request)
			throws SQLDataAccessException, AccountNotFoundException, UnAuthorisedException, IOException {

		CaseMessagingFrDownloadRes response = new CaseMessagingFrDownloadRes();
		if (request.getIncidentid().isBlank() || request.getIncidentid().isEmpty()) {
			response.setMessage(CASEID_REQUIRED);
			return response;
		}

		List<CaseConversationDetail> messagingDetailResponse = caseDetailsDao
				.getCaseMessagingDetail(request.getIncidentid());

		if (CollectionUtils.isNotEmpty(messagingDetailResponse)) {
			response.setStatus("OK");
			response.setMessage("SUCCESS");
			response.setMessageDetails(messagingDetailResponse);
		} else {
			response.setStatus("OK");
			response.setMessage("No record found for this case");
		}

		return response;
	}

	private String logFormat(String original) {
		String clean = original.replace('\n', '_').replace('\r', '_');
		StringBuilder sb = new StringBuilder(clean);
		return sb.toString();
	}

}
