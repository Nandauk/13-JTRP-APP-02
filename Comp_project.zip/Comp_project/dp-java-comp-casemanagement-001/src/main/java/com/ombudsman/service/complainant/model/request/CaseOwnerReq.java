package com.ombudsman.service.complainant.model.request;
import jakarta.validation.constraints.NotNull;


public class CaseOwnerReq {

    @NotNull(message = "Account ID is required.")
    private String accountid;

    // Getters and Setters
    public String getAccountid() {
        return accountid;
    }

    public void setAccountid(String accountid) {
        this.accountid = accountid;
    }
}