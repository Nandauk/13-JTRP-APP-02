package com.ombudsman.service.complainant.model.dto;

import java.time.OffsetDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.transaction.Transactional;

@Entity
@Table(name = "dp_user_event_configuration")
@Transactional
public class UserEventConfiguration {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private int id; // NOT NULL
	@Column(name = "user_event_name")
	private String userEventName; // NOT NULL
	@Column(name = "is_audit_required")
	private Boolean isAuditRequired; // NOT NULL
	@Column(name = "is_user_request_needed")
	private Boolean isUserRequestNeeded;
	@Column(name = "is_notification_needed")
	private Boolean isNotificationNeeded;
	@Column(name = "created_on")
	private OffsetDateTime createdOn; // notnull
	@Column(name = "created_by")
	private String createdBy; // notnull
	@Column(name = "modified_on")
	private OffsetDateTime modifiedOn;
	@Column(name = "modified_by")
	private String modifiedBy;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getUserEventName() {
		return userEventName;
	}

	public void setUserEventName(String userEventName) {
		this.userEventName = userEventName;
	}

	public Boolean getIsAuditRequired() {
		return isAuditRequired;
	}

	public void setIsAuditRequired(Boolean isAuditRequired) {
		this.isAuditRequired = isAuditRequired;
	}

	public Boolean getIsUserRequestNeeded() {
		return isUserRequestNeeded;
	}

	public void setIsUserRequestNeeded(Boolean isUserRequestNeeded) {
		this.isUserRequestNeeded = isUserRequestNeeded;
	}

	public Boolean getIsNotificationNeeded() {
		return isNotificationNeeded;
	}

	public void setIsNotificationNeeded(Boolean isNotificationNeeded) {
		this.isNotificationNeeded = isNotificationNeeded;
	}

	public OffsetDateTime getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(OffsetDateTime createdOn) {
		this.createdOn = createdOn;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public OffsetDateTime getModifiedOn() {
		return modifiedOn;
	}

	public void setModifiedOn(OffsetDateTime modifiedOn) {
		this.modifiedOn = modifiedOn;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

}
