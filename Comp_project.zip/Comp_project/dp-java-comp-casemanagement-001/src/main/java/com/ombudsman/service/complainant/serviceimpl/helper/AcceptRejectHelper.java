package com.ombudsman.service.complainant.serviceimpl.helper;

import static com.ombudsman.service.complainant.common.Constants.FAILED;

import java.io.UnsupportedEncodingException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ombudsman.service.complainant.common.CaseManagementWebClient;
import com.ombudsman.service.complainant.common.Constants;
import com.ombudsman.service.complainant.common.UserBean;
import com.ombudsman.service.complainant.common.ValidateUserSession;
import com.ombudsman.service.complainant.common.WebClientData;
import com.ombudsman.service.complainant.exception.InputValidationException;
import com.ombudsman.service.complainant.exception.MailJetServiceException;
import com.ombudsman.service.complainant.exception.UnAuthorisedException;
import com.ombudsman.service.complainant.model.EfileMessage;
import com.ombudsman.service.complainant.model.Incident;
import com.ombudsman.service.complainant.model.RequestProcessingDetails;
import com.ombudsman.service.complainant.model.UpdateOfferOutcomeObject;
import com.ombudsman.service.complainant.model.UpdateOfferOutcomeObject.FosPortalActivityParty;
import com.ombudsman.service.complainant.model.UserRequestBody;
import com.ombudsman.service.complainant.model.dto.AcceptRejectRequest;
import com.ombudsman.service.complainant.model.dto.OfferoutcomeUpdateRequestObj;
import com.ombudsman.service.complainant.model.dto.RequestModel;
import com.ombudsman.service.complainant.model.request.SinchApiRequest;
import com.ombudsman.service.complainant.model.response.GenericResponse;
import com.ombudsman.service.complainant.repository.dao.CaseDetailsDao;
import com.ombudsman.service.complainant.service.CaseCountService;
import com.ombudsman.service.complainant.service.CaseDetailsByIdService;
import com.ombudsman.service.complainant.service.CaseOutcomeByIdService;
import com.ombudsman.service.complainant.service.PhoenixCallProcessor;
import com.ombudsman.service.complainant.service.repository.CaseDetailsJdbcRepository;
import com.ombudsman.service.complainant.service.repository.UpdateRequestsRepository;


@Service
public class AcceptRejectHelper {
	Logger LOG = LogManager.getRootLogger();
	private static int SUCCESSCODE = 204;
	private static String LATEST_OUTCOME = "Update-Latest-OfferOutcome";
	private static String ACCEPT_OUTCOME = "Accept Outcome";
	private static String REJECT_OUTCOME = "Reject Outcome";
	private static String RESPOND_OUTCOME = "Respond to an Outcome";
	private static int REASON_FOR_CHANGE_ACCEPT = 140000008;
	private static int REASON_FOR_CHANGE_REJECT = 140000009;
	private static int CATEGORY = 140000016;
	private static String FAILURE = "Failure";
	private  Integer templateID =0 ;
	private static final String ORGANISATION_COMPLAINANT = "Organisation Complainant";

	@Autowired
	CaseOutcomeByIdService caseOutcomeByIdService;

	@Autowired
	UserBean userbean;

	@Autowired
	CaseManagementWebClient caseManagementWebClient;

	@Autowired
	CaseDetailsByIdService caseDetailsByIdService;

	@Autowired
	CaseCountService caseCountService;

	@Autowired
	PhoenixCallProcessor phoenixCallProcessor;
	@Autowired
	CaseNotificationHelper caseNotificationHelper;
	@Autowired
	WebClientData webClientData;
	@Autowired
	CaseDetailsDao caseDetailsDao;

	@Autowired
	UpdateRequestsRepository updateRequestsRepository;

	@Autowired
	CaseDetailsJdbcRepository caseDetailsJdbcRepository;
	
	@Autowired
	ValidateUserSession validateUserSession;

	public GenericResponse handleRequest(AcceptRejectRequest request) throws InputValidationException,
			UnsupportedEncodingException, JSONException, ParseException, MailJetServiceException, UnAuthorisedException {
		 LOG.info("accept/reject handleRequest  method started: {} ",request);
		GenericResponse response = new GenericResponse();
		ObjectMapper objectMapper = new ObjectMapper();
		Optional<Incident> incidentObj = Optional.ofNullable(new Incident());
		Optional<RequestModel> requestObj = Optional.ofNullable(new RequestModel());
		String requestId = null;
		EfileMessage efileMessage = new EfileMessage();
		UpdateOfferOutcomeObject updateOfferOutcomeObject = new UpdateOfferOutcomeObject();
		Map<String, Object> variables = new HashMap<>();
		UserRequestBody emailDetails = new UserRequestBody();
		  SinchApiRequest sinchReq = new SinchApiRequest();
          String userPreference="";
          String mobileNumber="";
          
          
          
          String  failureSMSText=Constants.FAILURESMSTEXT+"("+webClientData.signInUrl+")";
          try {
        
			RequestProcessingDetails details = new RequestProcessingDetails();
			//Added user authorization
			int count = caseDetailsDao.chkIncidentAuthorized(userbean.getUserObjectId(), request.getIncidentId(),userbean.getRoles().get(0));
			
			if (count >= 1) {
				LOG.info("ContactID and caseID are linked");
			}
			else
			{
				LOG.info("CaseID and User are not linked, case does not belong to user ");
				response.setMessage("Case does not belong to user.");
				response.setStatus(FAILED);
				return response;
			}
			details.setComment(request.getComment());
			details.setIncidentId(request.getIncidentId());
			details.setOfferoutcomeId(request.getFosOfferoroutcomeId());
			 userPreference = updateRequestsRepository.getCommunicationPreference(userbean.getUserObjectId());
             mobileNumber = updateRequestsRepository.getMobileNumber(userbean.getUserObjectId());
            LOG.info("Communication preference and mobile number for handlerequest method {} {} ",userPreference,mobileNumber);
            
            LOG.info("Webclient call to get templateID from drupal api");
            templateID = webClientData.getTemplateId(Constants.drupalEndpoint);
            
			String conatctId = caseDetailsJdbcRepository.fetchContactIdByOid(userbean.getUserObjectId());

			LOG.info("fetchContactIdByOid method ended for contactId Accept/Reject:-{}", conatctId);

			// adding record in request entity
			requestId = caseOutcomeByIdService.saveRecordForRequestEntity(userbean, details);
			LOG.info("saveRecordForRequestEntity method ended for  Request Model Accept/Reject:-{}", requestId);

			// getting record from request entity
			requestObj = caseOutcomeByIdService.findById(requestId);
			LOG.info("findById method ended for  Request Model Accept/Reject:-{}", requestObj.get().getRequestId());

			// fetching record from incident entity
			incidentObj = caseOutcomeByIdService.findIncidentInfoById(request.getIncidentId());
			LOG.info("findIncidentInfoById method ended for  Incident Model Accept/Reject:-{}",
					incidentObj.get().getCustomerid());

			List<String> roles = userbean.getRoles();
			for (String role : roles) {
				LOG.info(String.format("jwt role for accept/reject api call   :-%s", role));
				if (role.contains(ORGANISATION_COMPLAINANT)) {
					LOG.info("role Organisation Complainant ");
					String adAccountId = caseDetailsJdbcRepository.fetchAccountIdByContactId(conatctId);
					LOG.info(String.format("adAccountId*******************: %s", adAccountId));
					efileMessage.setUsersAccountIds(new String[] {adAccountId});
				}else {
					efileMessage.setUsersAccountIds(null);
				}
			}
			updateOfferOutcomeObject
					.setRegardingObjectIdIncidentFosPortal(Constants.INCIDENT + request.getIncidentId() + ")");
			String getOwnerTable = phoenixCallProcessor.getOwnerValue(incidentObj.get().getOwningteam(),
					incidentObj.get().getOwninguser());
			updateOfferOutcomeObject.setOwnerId(getOwnerTable + incidentObj.get().getOwnerid() + ")");
			updateOfferOutcomeObject.setDescription(request.getComment());
			updateOfferOutcomeObject.setActivityId(requestId);
			updateOfferOutcomeObject.setFosPackageId(requestId);
			updateOfferOutcomeObject.setFosDpUserEmailAddress(userbean.getEmail());
			updateOfferOutcomeObject.setFosDpUserFullName(userbean.getName()); // Is always false for respondent
			updateOfferOutcomeObject.setFosBusinessResponse(false);
			updateOfferOutcomeObject.setFosCapacity(140000001);
			updateOfferOutcomeObject.setSubject(RESPOND_OUTCOME);
			updateOfferOutcomeObject.setFosCategoryCode(CATEGORY);
			updateOfferOutcomeObject
					.setFosOfferoutcomeid(Constants.FOS_OFFEROROUTCOMEID + request.getFosOfferoroutcomeId() + ")");

			// mapping update requset obj for Update a record at Phoenix side
			OfferoutcomeUpdateRequestObj offeroutcomeUpdateRequestObj = new OfferoutcomeUpdateRequestObj();
			if (request.getFlag().equalsIgnoreCase(Constants.ACCEPTED)) {
				offeroutcomeUpdateRequestObj.setFosComplainantresponse(140000001);
				updateOfferOutcomeObject.setFosOtherReasonForChange(ACCEPT_OUTCOME);
				updateOfferOutcomeObject.setFosReasonForChange(REASON_FOR_CHANGE_ACCEPT);
			} else {
				offeroutcomeUpdateRequestObj.setFosComplainantresponse(140000002);
				updateOfferOutcomeObject.setFosOtherReasonForChange(REJECT_OUTCOME);
				updateOfferOutcomeObject.setFosReasonForChange(REASON_FOR_CHANGE_REJECT);
			}

			List<FosPortalActivityParty> toAndFrom = new ArrayList<>();
			FosPortalActivityParty toAttribute = new FosPortalActivityParty();
			FosPortalActivityParty fromAttribute = new FosPortalActivityParty();

			fromAttribute.setType(Constants.ACTIVITYPARTY);
			fromAttribute.setPartyIdContact(Constants.CONTACTS + conatctId);

			fromAttribute.setParticipationTypeMask(1);
			toAndFrom.add(fromAttribute);
			LOG.info("started getToValue method to get system user from phoenix");
			String toValue = phoenixCallProcessor.getToValue(incidentObj.get().getOwnerid(),
					incidentObj.get().getOwningteam(), incidentObj.get().getOwninguser());
			LOG.info("ended  getToValue method to get system user from phoenix:-{}", toValue);
			toAttribute.setType(Constants.ACTIVITYPARTY);
			toAttribute.setParticipationTypeMask(2);
			toAttribute.setPartyIdSystemUser(toValue);
			toAndFrom.add(toAttribute);
			updateOfferOutcomeObject.setFosPortalActivityParties(toAndFrom);

			String jsonString = objectMapper.writeValueAsString(updateOfferOutcomeObject);
			String jsonStringUpdateOutcome = objectMapper.writeValueAsString(offeroutcomeUpdateRequestObj);
			LOG.info("Json Rquest String for recrod creation in Portal table:-{}", jsonString);

			int recordCreationResponse = phoenixCallProcessor.createRecordPhnx(Constants.PORTAL_ENTITY_PHNX,
					jsonString);

			LOG.info("Response received from Phoneix for portalActivity:-{}", recordCreationResponse);

			  variables.put("portal_User",userbean.getName());
              variables.put("sign_In",webClientData.signInUrl);

			if (recordCreationResponse == SUCCESSCODE) {
				LOG.info("Json Rquest String for recrod update  in offeroutcome table:-{}", jsonStringUpdateOutcome);
				int recordUpdationResponse = phoenixCallProcessor.updateRecordPhnx(request.getFosOfferoroutcomeId(),
						jsonStringUpdateOutcome);
				LOG.info("Response received from Phoneix for updateOfferoutcome:-{}", recordUpdationResponse);
				caseNotificationHelper.insertOfferoutcomeResponseRecord(request.getFosOfferoroutcomeId(),
						Constants.SUCCESS, request.getOutcomeDate(), LATEST_OUTCOME, request.getComment());
				if (recordUpdationResponse == SUCCESSCODE) {
					caseNotificationHelper.updateOfferoutcome(request.getFosOfferoroutcomeId(),
							offeroutcomeUpdateRequestObj);
				}
				efileMessage.setCaseId(request.getIncidentId());
				efileMessage.setComments(request.getComment());
				efileMessage.setDetails("");
				efileMessage.setDigitalPortalUserEmailAddress(userbean.getEmail());
				efileMessage.setDigitalPortalUserName(userbean.getName());
				efileMessage.setFromContactId(conatctId);
				efileMessage.setReasonForChange(updateOfferOutcomeObject.getFosReasonForChange());
				efileMessage.setPortalType("Complainant");
				efileMessage.setPackageId(requestId);
				LOG.info("Efile Message sent to external bus for accept/reject {}", efileMessage);

				// Send Message to external Queue for Efile to read and create PDF
				webClientData.updateOfferoutcomeServiceBusWebclient(efileMessage);

				LOG.error("Efile message ready to be sent in service bus for handleAccept/Reject:-{}", efileMessage);
				response.setMessage("Success");
				response.setStatus("200");
			}

			else {
				LOG.info("Record not created in portal table ");
				
				LOG.info("inside else statement for record not created in portal table");
				String failedMsg = incidentObj.get().getTicketnumber()
						+ " : Exception occured, Accept/Reject Request failed";
				caseNotificationHelper.insertOfferoutcomeResponseRecord(request.getFosOfferoroutcomeId(), FAILURE,
						request.getOutcomeDate(), LATEST_OUTCOME, request.getComment());
				// adding record in notification entity Notification
				caseOutcomeByIdService.saveRecordnotificationEntity(requestObj.get(),
						incidentObj.get().getTicketnumber(), failedMsg);
				//Code added to verify user session
				if (!validateUserSession.isValidSession()) {
					if (mobileNumber != null && "phone".equalsIgnoreCase(userPreference)) {
						LOG.info("found mobile number inside if statement");
						List<String> toNumbers = new ArrayList<>();
						toNumbers.add(mobileNumber);
						sinchReq.setTo(toNumbers);
						sinchReq.setBody(failureSMSText);
						webClientData.communicationSmsApiCall(sinchReq);
						
					} else if ("email".equalsIgnoreCase(userPreference)) {
						variables.put("portal_User", caseDetailsDao.fetchfullname(userbean.getEmail()));
						variables.put("sign_In", webClientData.signInUrl);						
						emailDetails.setTemplateID(templateID);						
						emailDetails.setVariables(variables);
						// Send email Notification for Failure
						emailDetails.setEmailId(userbean.getEmail());
						emailDetails.setFullName(userbean.getName());						
						emailDetails.setTemplateName(LATEST_OUTCOME);						

						webClientData.communcationEmailApiCall(emailDetails);
					}
				}
				response.setMessage("Portal Activity is not created");
				response.setStatus(String.valueOf(recordCreationResponse));

			}

		} catch (Exception e) {
			LOG.info("inside else statement for record not created in portal table");
			String exceptionMsg = incidentObj.get().getTicketnumber()
					+ " : Exception occured, Accept/Reject Request failed";
			// adding record in notification entity Notification
			caseOutcomeByIdService.saveRecordnotificationEntity(requestObj.get(), incidentObj.get().getTicketnumber(),
					exceptionMsg);

			caseNotificationHelper.insertOfferoutcomeResponseRecord(request.getFosOfferoroutcomeId(), FAILURE,
					request.getOutcomeDate(), LATEST_OUTCOME, request.getComment());
			// Send email Notification for Failure
			if (!validateUserSession.isValidSession()) {
				if (mobileNumber != null && "phone".equalsIgnoreCase(userPreference)) {

					List<String> toNumbers = new ArrayList<>();
					toNumbers.add(mobileNumber);
					sinchReq.setTo(toNumbers);
					sinchReq.setBody(failureSMSText);
					webClientData.communicationSmsApiCall(sinchReq);

				} else if ("email".equalsIgnoreCase(userPreference)) {
					variables.put("portal_User", caseDetailsDao.fetchfullname(userbean.getEmail()));
					variables.put("sign_In", webClientData.signInUrl);						
					emailDetails.setTemplateID(templateID);						
					emailDetails.setVariables(variables);
					emailDetails.setEmailId(userbean.getEmail());
					emailDetails.setFullName(userbean.getName());					
					emailDetails.setTemplateName(LATEST_OUTCOME);				

					webClientData.communcationEmailApiCall(emailDetails);
				}
			}
			LOG.info("Email sent successfully for failed accept/reject scenario");
			response.setMessage(e.getMessage());
			response.setStatus("500");

		}

		return response;
	}
	
	
	

}