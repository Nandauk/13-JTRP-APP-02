package com.ombudsman.service.complainant.exception;

public class ComplainantServiceException extends RuntimeException {

	private static final long serialVersionUID = 1L;
	private final String code;
	private final String message;
	private final String exceptionMessage;

	public ComplainantServiceException(String message, String code, String exceptionMessage) {
		super(message);

		this.code = code;
		this.message = message;
		this.exceptionMessage = exceptionMessage;

	}

	public String getCode() {
		return code;
	}

	@Override
	public String getMessage() {
		return message;
	}

	public String getExceptionMessage() {
		return exceptionMessage;
	}

}
