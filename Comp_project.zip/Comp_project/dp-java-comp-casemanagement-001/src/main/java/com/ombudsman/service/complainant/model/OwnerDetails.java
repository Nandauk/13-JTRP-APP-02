package com.ombudsman.service.complainant.model;

public class OwnerDetails {

	private String ownerid;
	private String owningteam;
	private String owninguser;
	
	public String getOwnerid() {
		return ownerid;
	}
	public void setOwnerid(String ownerid) {
		this.ownerid = ownerid;
	}
	public String getOwningteam() {
		return owningteam;
	}
	public void setOwningteam(String owningteam) {
		this.owningteam = owningteam;
	}
	public String getOwninguser() {
		return owninguser;
	}
	public void setOwninguser(String owninguser) {
		this.owninguser = owninguser;
	}
}
