package com.ombudsman.service.complainant.exception;

public class AzureServiceException extends ComplainantServiceException {

	private static final long serialVersionUID = 1L;

	public AzureServiceException(String message, String exceptionMessage) {
		super(message, "COMPLAINANT_AZURE_1000", exceptionMessage);
	}

}
