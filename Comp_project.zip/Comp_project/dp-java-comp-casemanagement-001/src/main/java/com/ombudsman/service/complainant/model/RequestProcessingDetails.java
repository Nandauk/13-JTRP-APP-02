package com.ombudsman.service.complainant.model;

import com.google.gson.annotations.SerializedName;

public class RequestProcessingDetails {
	@SerializedName("incidentId")
	private String incidentId;
	@SerializedName("offeroutcomeId")
	private String offeroutcomeId;
	@SerializedName("comment")
	private String comment;
	public String getIncidentId() {
		return incidentId;
	}
	public void setIncidentId(String incidentId) {
		this.incidentId = incidentId;
	}
	public String getOfferoutcomeId() {
		return offeroutcomeId;
	}
	public void setOfferoutcomeId(String offeroutcomeId) {
		this.offeroutcomeId = offeroutcomeId;
	}
	public String getComment() {
		return comment;
	}
	public void setComment(String comment) {
		this.comment = comment;
	}
	
	
	

}
