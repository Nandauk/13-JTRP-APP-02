package com.ombudsman.service.complainant.repository.daoimpl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ombudsman.service.complainant.exception.SQLDataAccessException;
import com.ombudsman.service.complainant.model.CaseConversationDetail;
import com.ombudsman.service.complainant.model.dto.CaseByCaseReferenceDto;
import com.ombudsman.service.complainant.repository.dao.CaseDetailsDao;
import com.ombudsman.service.complainant.service.repository.CaseDetailsJdbcRepository;

@Component
public class CaseDetailsDaoImpl implements CaseDetailsDao{
	Logger log = LogManager.getRootLogger();
	private static final String ACCOUNT_IDS = "acctId";
	private static final String INCIDENT = "incident";
	private static final String TICKET = "ticket";
	
	@Autowired 
	CaseDetailsJdbcRepository caseDetailsJdbcRepository;
	
	

	@Override
	public String fetchfullname(String emailAddress) {
		return caseDetailsJdbcRepository.fetchfullname(emailAddress);
	}
	@Override
	public Map<String, Object> getCaseDetailsById(String incidentId,String userOid,String role) throws SQLDataAccessException
	{
		Map<String, Object> paramReq = new HashMap<>();
		paramReq.put("Incidentids", incidentId);
		paramReq.put("inputoid", userOid);
		paramReq.put("role", role);

		return caseDetailsJdbcRepository.getCaseDetailsById(paramReq);
	}
	
	private Map<String, Object> setReqParam( String incidentId,List<String> accIds) {	
		Map<String, Object> paramReq = new HashMap<>();
		paramReq.put(INCIDENT, incidentId);
		paramReq.put(ACCOUNT_IDS, accIds);
		return paramReq;
	}
	
	@Override
	public  Map<String, Object> getOfferOutcomes(String incidentId) throws SQLDataAccessException
	{
		Map<String, Object> paramReq = new HashMap<>();
		paramReq.put("Incidentids", incidentId);
		
		 Map<String, Object> caseOutcomes = null;
		 caseOutcomes =  caseDetailsJdbcRepository.getOfferOutcomes(paramReq);
		 return caseOutcomes;
	}
	

	@Override
	public Integer getCaseCount(String userOid) throws SQLDataAccessException {
		Map<String, Object> paramReq = new HashMap<>();
		paramReq.put("userOid", userOid); 
		return caseDetailsJdbcRepository.getCaseCount(paramReq);
	}
	
	@Override
	public Map<String, Object> getCaseCountFrUser(String userOid,String usrRole) throws SQLDataAccessException {
		Map<String, Object> paramReq = new HashMap<>();
		paramReq.put("inputoid", userOid); 
		paramReq.put("input_role", usrRole); 
		return caseDetailsJdbcRepository.getCaseCountFrUser(paramReq);
	}
	
	@Override
	public String getCaseIncidentId(String userOid) throws SQLDataAccessException {
		Map<String, Object> paramReq = new HashMap<>();
		paramReq.put("userOid", userOid); 
		return caseDetailsJdbcRepository.getCaseIncidentId(paramReq);
	}
	
	@Override
	public String getCaseStatus(String incidentId,String oid) throws SQLDataAccessException {
		return caseDetailsJdbcRepository.getCaseStatus(incidentId,oid);
	}
	
	
	@Override
	public  Map<String, Object> getCaseOwnerDetails(String incidentId) throws SQLDataAccessException
	{
		Map<String, Object> paramReq = new HashMap<>();
		paramReq.put("Incidentids", incidentId);
		
		 Map<String, Object> caseOutcomes = null;
		 caseOutcomes =  caseDetailsJdbcRepository.getCaseOwnerDetails(paramReq);
		 return caseOutcomes;
	}

	@Override
	public List<CaseConversationDetail> getCaseMessagingDetail(String incidentId) throws SQLDataAccessException {
		 
		return caseDetailsJdbcRepository.getCaseMessagingDetail(incidentId);
	}
	
	public List<CaseByCaseReferenceDto> getCaseIncidentidByCaseReference(String ticketId) throws SQLDataAccessException
	{
		Map<String, Object> paramReq = new HashMap<>();
		paramReq.put(TICKET, ticketId);
		return caseDetailsJdbcRepository.getCaseIncidentidByCaseReference(paramReq);
	}
	
	@Override
	public  Integer chkIncidentAuthorized(String oid, String caseId, String roleid) throws SQLDataAccessException
	{
		Map<String, Object> paramReq = new HashMap<>();
		paramReq.put("oid", oid);
		paramReq.put("caseid", caseId);
		paramReq.put("roleid", roleid);
		List<Object> countLst = caseDetailsJdbcRepository.chkIncidentAuthorized(paramReq);
		return (Integer)countLst.get(0);
	}

}
