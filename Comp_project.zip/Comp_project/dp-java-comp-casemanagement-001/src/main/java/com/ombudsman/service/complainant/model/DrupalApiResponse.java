package com.ombudsman.service.complainant.model;

public class DrupalApiResponse {
	
	private String templateName;
	private String categories;
	private String templateId;
	
	public String getTemplateName() {
		return templateName;
	}
	public void setTemplateName(String templateName) {
		this.templateName = templateName;
	}
	public String getCategories() {
		return categories;
	}
	public void setCategories(String categories) {
		this.categories = categories;
	}
	public String getTemplateId() {
		return templateId;
	}
	public void setTemplateId(String templateId) {
		this.templateId = templateId;
	}
	
	@Override
	public String toString() {
		return "DrupalApiResponse [templateName=" + templateName + ", categories=" + categories + ", templateId="
				+ templateId + "]";
	}
	
	

}
