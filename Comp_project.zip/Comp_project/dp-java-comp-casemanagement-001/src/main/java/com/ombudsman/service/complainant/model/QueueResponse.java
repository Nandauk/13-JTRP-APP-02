package com.ombudsman.service.complainant.model;

import java.util.List;


public class QueueResponse {
	
	
	 private List<QueueData> value;


	    // Getters and setters
	    public List<QueueData> getValue() {
	        return value;
	    }

	    public void setValue(List<QueueData> value) {
	        this.value = value;
	    }

	    @Override
	    public String toString() {
	        return "Response{" +
	                "value=" + value +
	                '}';
	    }
	}


