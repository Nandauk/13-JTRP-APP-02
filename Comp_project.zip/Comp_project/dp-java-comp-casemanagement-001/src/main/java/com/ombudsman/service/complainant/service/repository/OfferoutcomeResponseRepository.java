package com.ombudsman.service.complainant.service.repository;

import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ombudsman.service.complainant.model.OfferoutcomeResponse;

public interface OfferoutcomeResponseRepository extends JpaRepository<OfferoutcomeResponse, UUID> {
	
	

}
