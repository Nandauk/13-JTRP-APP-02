package com.ombudsman.service.complainant.service.repository;

import java.util.List;

import org.springframework.dao.DataAccessException;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.ombudsman.service.complainant.model.IncidentInfo;
import com.ombudsman.service.complainant.model.OwnerDetails;
import com.ombudsman.service.complainant.model.SubjectAndCatCode;
import com.ombudsman.service.complainant.model.dto.UpdateCaseDto;

@Transactional
@Repository
public interface UpdateRequestsRepository extends JpaRepository<UpdateCaseDto, Integer> {
	
	@Query(value = "EXEC prc_getUserAccountId ?", nativeQuery = true)
	List<String> getAccountId(@Param("accountids") String accountids) ;
	
	
	//SP for authorization
	@Query(value = "exec dbo.prc_oidIncActValidation :userOid,:caseIds", nativeQuery = true)
	List<Object[]> validateOrg(@Param("userOid") String userOid,@Param("caseIds") String caseIds) ;
	
	@Query(value = "SELECT COUNT(incidentid) as incidentid,ticketnumber  FROM incident WHERE incidentid =:incidentid  GROUP BY ticketnumber", nativeQuery = true)// return count 
		IncidentInfo getIncident(@Param("incidentid") String incidentid);
	
	//Complainant case withdraw
		@Query(value = "SELECT ownerid FROM incident WHERE incidentid =:incidentid", nativeQuery = true)// return count 
		String getOwnerId(@Param("incidentid") String incidentid);
		

		@Query(value = "select c.fullname,c.emailaddress1,c.contactid from contact c JOIN dp_user_dpcomplainant dp ON dp.pnxuuid = c.contactid where dp.oid =:oid", nativeQuery = true) 
		List<Object[]> getUserEmailName(@Param("oid") String oid);
		
		@Query(value = "Select subject, category_code from dp_reason_for_change_subcat_map where reason_for_change_code =:reasonForChange", nativeQuery = true)// return count 
		List<Object[]> getSubCategoryCode (@Param("reasonForChange") int reasonForChange);

		@Query(value = "Select pnxuuid from dp_user_dpcomplainant where email =:email AND full_name =:fullName and oid =:oid", nativeQuery = true)// return count 
		String getContactId(@Param("email") String email, @Param("fullName")String fullName, @Param("oid") String oid);
		
		@Query(value = "SELECT ownerid,owningteam,owninguser FROM [dbo].[incident] WHERE  incidentid =:incidentid", nativeQuery = true)// return count 
		List<Object[]> getOwnerDetails(@Param("incidentid") String incidentid);
		
		
		@Modifying
		@Query(value = "UPDATE [dbo].[dp_complainant_case_updates] SET status =:status WHERE package_id =:id ", nativeQuery = true)// return count 
		public void updateCaseTable(@Param("status") String status,@Param("id") String id);
		
		
		@Modifying
		@Query(value = "UPDATE [dbo].[dp_complainant_user_notification] SET notification_status_id =:statusID , message =:message WHERE request_id =:requestId ", nativeQuery = true)// return count 
		public void updateNotificationTable(@Param("statusID") int statusId,@Param("message") String message, @Param("requestId") String requestId);

		@Query(value = "SELECT reason_for_change_text FROM [dbo].[dp_reason_for_change_subcat_map] WHERE reason_for_change_code =:reasonForChange", nativeQuery = true)// return count 
		String getReasonForChangeText(@Param("reasonForChange") int reasonForChange);

		@Query(value = "SELECT parentcustomerid FROM [dbo].[contact] where contactid=:contact", nativeQuery = true)
		String getparentcustomerid(@Param("contact") String contact);
		
		@Query(value = "Select communication_preference from [dbo].[dp_user_dpcomplainant] where oid =:oid" , nativeQuery = true)
		String getCommunicationPreference(@Param("oid") String oid);
		
		@Query(value = "select mobile_number  from [dbo].[dp_user_dpcomplainant] where oid =:oid" , nativeQuery = true)
		String getMobileNumber(@Param("oid") String oid);
		
		@Query(value =  "Select fos_individualid,fos_case  from caselink caselinktable INNER JOIN dbo.contact contacttable ON (CASE WHEN :roleid = 'Organisation Complainant' THEN  caselinktable.fos_organisationid ELSE caselinktable.fos_individualid END)=(CASE WHEN :roleid = 'Organisation Complainant' THEN  contacttable.parentcustomerid ELSE contacttable.contactid END) INNER JOIN dp_user_dpcomplainant usertable ON usertable.pnxuuid = contacttable.contactid Where usertable.oid =:oid AND caselinktable.fos_case =:caseid", nativeQuery = true)
		List<Object[]> checkOidAndCaseId(@Param("oid") String oid, @Param("caseid") String caseid, @Param("roleid") String roleid);
}