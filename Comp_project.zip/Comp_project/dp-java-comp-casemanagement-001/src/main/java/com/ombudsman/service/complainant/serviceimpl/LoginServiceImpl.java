package com.ombudsman.service.complainant.serviceimpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ombudsman.service.complainant.common.CaseManagementWebClient;
import com.ombudsman.service.complainant.common.CommonUtil;
import com.ombudsman.service.complainant.model.response.GenericResponse;
import com.ombudsman.service.complainant.service.ILoginService;

@Service
public class LoginServiceImpl implements ILoginService {
	
	@Autowired
	CommonUtil commonUtil;

	@Autowired
	CaseManagementWebClient caseManagementWebClient;


	@Override
	public GenericResponse addUserSessionEntry() {
		final String sessionType="login";
		return caseManagementWebClient.getResponseForSessionActivity(sessionType);		
	}

	@Override
	public GenericResponse logoutForUserSession() {
		final String sessionType="logout";
		return caseManagementWebClient.getResponseForSessionActivity(sessionType);		
	}

	@Override
	public GenericResponse getSessionTokenStatus() {
		final String sessionType="";		
		return caseManagementWebClient.getResponseForSessionActivity(sessionType);
	}
	
	

}
