package com.ombudsman.service.complainant.exception;

public class OrganisationIdMissingException extends RuntimeException {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public OrganisationIdMissingException(String exceptionMsg)
	{
		super(exceptionMsg);
	}


}
