package com.ombudsman.service.complainant.model;

public class CaseWorker {
	
	private String ticketnumber;
	private String fos_casestagename;
	private String fos_caseworker;
	private String owninguser;
	private String fullname;
	private String email;
	private String phone;

	public String getTicketnumber() {
		return ticketnumber;
	}
	public void setTicketnumber(String ticketnumber) {
		this.ticketnumber = ticketnumber;
	}
	public String getFos_casestagename() {
		return fos_casestagename;
	}
	public void setFos_casestagename(String fos_casestagename) {
		this.fos_casestagename = fos_casestagename;
	}
	public String getFos_caseworker() {
		return fos_caseworker;
	}
	public void setFos_caseworker(String fos_caseworker) {
		this.fos_caseworker = fos_caseworker;
	}
	public String getOwninguser() {
		return owninguser;
	}
	public void setOwninguser(String owninguser) {
		this.owninguser = owninguser;
	}
	public String getFullname() {
		return fullname;
	}
	public void setFullname(String fullname) {
		this.fullname = fullname;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	
	
}
