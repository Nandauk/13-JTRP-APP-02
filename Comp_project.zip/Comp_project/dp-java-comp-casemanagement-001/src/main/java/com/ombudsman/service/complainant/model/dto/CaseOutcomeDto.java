package com.ombudsman.service.complainant.model.dto;

public class CaseOutcomeDto {

	private String fos_case;
	private String fos_offeroroutcomeid;
	private String fos_type;
	private String fos_typename;
	private String fos_meritsjurisdictiondismissal;
	private String fos_meritsjurisdictiondismissalname;
	private String fos_meritopinion;
	private String fos_meritopinionname;
	private String fos_jurisdictioninout;
	private String fos_jurisdictioninoutname;
	private String fos_dismissalreason;
	private String fos_withopinion;
	private String fos_changeinoutcome;
	private String fos_changeinoutcomename;
	private String fos_settlementbandid;
	private String fos_settlementbandidname;
	private String fos_nonmonetarysettlement;
	private String fos_troubleupsetamt;
	private String fos_complainantresponse;
	private String fos_complainantresponsename;
	private String fos_respondentresponse;
	private String fos_respondentresponse_txt;
	private String fos_outcomedispatcheddate;
	private String statuscode;
	private String fos_jurisdiction;
	private String fos_jurisdictionreason;
	private String fos_outcomedispatchedby;
	private String fos_outcomedispatched;
	private String fos_settlementamount;
	private String fos_senttocomplainant;
	private String fos_othercomplaintbody;
	private String fos_senttorespondent;
	private String statecode;
	private String duedate;
	private String message_code;
	private String user_comments;
	private String acceptReject;
	
	public String getFos_offeroroutcomeid() {
		return fos_offeroroutcomeid;
	}
	public void setFos_offeroroutcomeid(String fos_offeroroutcomeid) {
		this.fos_offeroroutcomeid = fos_offeroroutcomeid;
	}
	public String getFos_type() {
		return fos_type;
	}
	public void setFos_type(String fos_type) {
		this.fos_type = fos_type;
	}
	public String getFos_meritsjurisdictiondismissal() {
		return fos_meritsjurisdictiondismissal;
	}
	public void setFos_meritsjurisdictiondismissal(String fos_meritsjurisdictiondismissal) {
		this.fos_meritsjurisdictiondismissal = fos_meritsjurisdictiondismissal;
	}
	public String getFos_meritopinion() {
		return fos_meritopinion;
	}
	public void setFos_meritopinion(String fos_meritopinion) {
		this.fos_meritopinion = fos_meritopinion;
	}
	public String getFos_jurisdictioninout() {
		return fos_jurisdictioninout;
	}
	public void setFos_jurisdictioninout(String fos_jurisdictioninout) {
		this.fos_jurisdictioninout = fos_jurisdictioninout;
	}
	public String getFos_dismissalreason() {
		return fos_dismissalreason;
	}
	public void setFos_dismissalreason(String fos_dismissalreason) {
		this.fos_dismissalreason = fos_dismissalreason;
	}
	public String getFos_withopinion() {
		return fos_withopinion;
	}
	public void setFos_withopinion(String fos_withopinion) {
		this.fos_withopinion = fos_withopinion;
	}
	public String getFos_changeinoutcome() {
		return fos_changeinoutcome;
	}
	public void setFos_changeinoutcome(String fos_changeinoutcome) {
		this.fos_changeinoutcome = fos_changeinoutcome;
	}
	public String getFos_settlementbandid() {
		return fos_settlementbandid;
	}
	public void setFos_settlementbandid(String fos_settlementbandid) {
		this.fos_settlementbandid = fos_settlementbandid;
	}
	public String getFos_settlementbandidname() {
		return fos_settlementbandidname;
	}
	public void setFos_settlementbandidname(String fos_settlementbandidname) {
		this.fos_settlementbandidname = fos_settlementbandidname;
	}
	public String getFos_nonmonetarysettlement() {
		return fos_nonmonetarysettlement;
	}
	public void setFos_nonmonetarysettlement(String fos_nonmonetarysettlement) {
		this.fos_nonmonetarysettlement = fos_nonmonetarysettlement;
	}
	public String getFos_troubleupsetamt() {
		return fos_troubleupsetamt;
	}
	public void setFos_troubleupsetamt(String fos_troubleupsetamt) {
		this.fos_troubleupsetamt = fos_troubleupsetamt;
	}
	public String getFos_complainantresponse() {
		return fos_complainantresponse;
	}
	public void setFos_complainantresponse(String fos_complainantresponse) {
		this.fos_complainantresponse = fos_complainantresponse;
	}
	public String getFos_respondentresponse() {
		return fos_respondentresponse;
	}
	public void setFos_respondentresponse(String fos_respondentresponse) {
		this.fos_respondentresponse = fos_respondentresponse;
	}
	public String getFos_respondentresponse_txt() {
		return fos_respondentresponse_txt;
	}
	public void setFos_respondentresponse_txt(String fos_respondentresponse_txt) {
		this.fos_respondentresponse_txt = fos_respondentresponse_txt;
	}
	public String getStatuscode() {
		return statuscode;
	}
	public void setStatuscode(String statuscode) {
		this.statuscode = statuscode;
	}
	public String getFos_case() {
		return fos_case;
	}
	public void setFos_case(String fos_case) {
		this.fos_case = fos_case;
	}
	public String getFos_typename() {
		return fos_typename;
	}
	public void setFos_typename(String fos_typename) {
		this.fos_typename = fos_typename;
	}
	public String getFos_meritsjurisdictiondismissalname() {
		return fos_meritsjurisdictiondismissalname;
	}
	public void setFos_meritsjurisdictiondismissalname(String fos_meritsjurisdictiondismissalname) {
		this.fos_meritsjurisdictiondismissalname = fos_meritsjurisdictiondismissalname;
	}
	public String getFos_meritopinionname() {
		return fos_meritopinionname;
	}
	public void setFos_meritopinionname(String fos_meritopinionname) {
		this.fos_meritopinionname = fos_meritopinionname;
	}
	public String getFos_jurisdictioninoutname() {
		return fos_jurisdictioninoutname;
	}
	public void setFos_jurisdictioninoutname(String fos_jurisdictioninoutname) {
		this.fos_jurisdictioninoutname = fos_jurisdictioninoutname;
	}
	public String getFos_changeinoutcomename() {
		return fos_changeinoutcomename;
	}
	public void setFos_changeinoutcomename(String fos_changeinoutcomename) {
		this.fos_changeinoutcomename = fos_changeinoutcomename;
	}
	public String getFos_complainantresponsename() {
		return fos_complainantresponsename;
	}
	public void setFos_complainantresponsename(String fos_complainantresponsename) {
		this.fos_complainantresponsename = fos_complainantresponsename;
	}
	public String getFos_outcomedispatcheddate() {
		return fos_outcomedispatcheddate;
	}
	public void setFos_outcomedispatcheddate(String fos_outcomedispatcheddate) {
		this.fos_outcomedispatcheddate = fos_outcomedispatcheddate;
	}
	public String getFos_jurisdiction() {
		return fos_jurisdiction;
	}
	public void setFos_jurisdiction(String fos_jurisdiction) {
		this.fos_jurisdiction = fos_jurisdiction;
	}
	public String getFos_jurisdictionreason() {
		return fos_jurisdictionreason;
	}
	public void setFos_jurisdictionreason(String fos_jurisdictionreason) {
		this.fos_jurisdictionreason = fos_jurisdictionreason;
	}
	public String getFos_outcomedispatchedby() {
		return fos_outcomedispatchedby;
	}
	public void setFos_outcomedispatchedby(String fos_outcomedispatchedby) {
		this.fos_outcomedispatchedby = fos_outcomedispatchedby;
	}
	public String getFos_outcomedispatched() {
		return fos_outcomedispatched;
	}
	public void setFos_outcomedispatched(String fos_outcomedispatched) {
		this.fos_outcomedispatched = fos_outcomedispatched;
	}
	public String getFos_settlementamount() {
		return fos_settlementamount;
	}
	public void setFos_settlementamount(String fos_settlementamount) {
		this.fos_settlementamount = fos_settlementamount;
	}
	public String getFos_senttocomplainant() {
		return fos_senttocomplainant;
	}
	public void setFos_senttocomplainant(String fos_senttocomplainant) {
		this.fos_senttocomplainant = fos_senttocomplainant;
	}
	public String getFos_othercomplaintbody() {
		return fos_othercomplaintbody;
	}
	public void setFos_othercomplaintbody(String fos_othercomplaintbody) {
		this.fos_othercomplaintbody = fos_othercomplaintbody;
	}
	public String getFos_senttorespondent() {
		return fos_senttorespondent;
	}
	public void setFos_senttorespondent(String fos_senttorespondent) {
		this.fos_senttorespondent = fos_senttorespondent;
	}
	public String getStatecode() {
		return statecode;
	}
	public void setStatecode(String statecode) {
		this.statecode = statecode;
	}
	public String getDuedate() {
		return duedate;
	}
	public void setDuedate(String duedate) {
		this.duedate = duedate;
	}
	public String getMessage_code() {
		return message_code;
	}
	public void setMessage_code(String message_code) {
		this.message_code = message_code;
	}
	public String getUser_comments() {
		return user_comments;
	}
	public void setUser_comments(String user_comments) {
		this.user_comments = user_comments;
	}
	public String getAcceptReject() {
		return acceptReject;
	}
	public void setAcceptReject(String acceptReject) {
		this.acceptReject = acceptReject;
	}
	
}
