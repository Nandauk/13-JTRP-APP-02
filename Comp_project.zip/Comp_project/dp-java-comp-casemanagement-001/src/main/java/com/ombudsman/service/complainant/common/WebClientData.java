package com.ombudsman.service.complainant.common;

import java.util.List;
import java.util.Locale;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import com.azure.identity.ClientSecretCredentialBuilder;
import com.azure.json.implementation.jackson.core.JsonProcessingException;
import com.azure.messaging.servicebus.ServiceBusClientBuilder;
import com.azure.messaging.servicebus.ServiceBusMessage;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ombudsman.service.complainant.exception.AzureServiceException;
import com.ombudsman.service.complainant.model.DrupalApiResponse;
import com.ombudsman.service.complainant.model.EfileMessage;
import com.ombudsman.service.complainant.model.EmailNotificationResponse;
import com.ombudsman.service.complainant.model.UserRequestBody;
import com.ombudsman.service.complainant.model.dto.Notification;
import com.ombudsman.service.complainant.model.dto.NotificationModel;
import com.ombudsman.service.complainant.model.request.SinchApiRequest;
import com.ombudsman.service.complainant.model.response.GetResponseMessage;
import com.ombudsman.service.complainant.model.response.NotificationResponse;

import reactor.core.publisher.Mono;

@Service
public class WebClientData {

	private static final String AUTHORIZATION = "Authorization";

	private static final String BEARER = "Bearer ";

	private static final String API_KEY = "X-API-KEY";

	private static final String CASE_EXPORT = "CaseExport";

	@Autowired
	UserBean userbean;

	@Autowired
	CommonUtil commonUtil;
//	
//	@Autowired
//	KeyVaultConfiguration keyvault;

	@Autowired
	private MessageSource messageSource;
	@Value("${notificationApiUrl}")
	public String notificationApiUrl;
	
	@Value("${communicationApiUrl}")
	public String commApi;
	
	@Value("${sendSmsApiUrl}")
	public String sendSms;

	@Value("${app.apim_url}")
	public String apim_url;
	
	@Value("${signInUrl}")
	public String signInUrl;

	//--Case withdraw
	@Value("${updateCaseServiceBusfullyQualifiedNamespace}")
	public String updateCaseServiceBusfullyQualifiedNamespace;

	@Value("${servicbustenantId}")
	public String servicbustenantId;
	
	@Value("${caseupdatequeueName}")
	public String caseupdatequeueName;

	@Value("${servicebusCaseUpdateClientId}")
	public String servicebusCaseUpdateClientId;
	
	@Value("${servicebusCaseUpdateSecretId}")
	public String servicebusCaseUpdateSecretId;
	
		//------------

//	@Value("${servicbusclientSecret}")
//	public String servicbusclientSecret;
	
//	@Value("${caseExportServiceBusfullyQualifiedNamespace}")
//	public String caseExportServiceBusfullyQualifiedNamespace;

//	@Value("${servicbusclientId}")
//	public String servicbusclientId;


//	@Value("${caseExportqueueName}")
//	public String caseExportqueueName;
	
	//---
	
	@Value("${APIM_HOST}")
	public String apimHost;

	

	Logger log = LogManager.getRootLogger();
//	private static String drupalTemplateApiUrl_caseExport = "/content/case_export_template";
//	private static String drupalTemplateApiUrl_caseUpdate = "/content/updateCaseFail";

	@SuppressWarnings("unchecked")
	public Integer getTemplateId(String drupalEndpoint) {

		
		String drupaltUrl = "";
		drupaltUrl = apim_url + drupalEndpoint;

		log.info(String.format("Drupal url for "+ drupalEndpoint+ " api %s", drupaltUrl));

		try {	

			List<DrupalApiResponse> responseList = WebClient.create().get().uri(drupaltUrl)
					.headers(httpHeaders -> httpHeaders.set(AUTHORIZATION, BEARER + userbean.getAuthToken()))
					.accept(MediaType.APPLICATION_JSON).retrieve().bodyToFlux(DrupalApiResponse.class).collectList().block();
			
			if(responseList !=null && !responseList.isEmpty()) {
				String templateID = responseList.get(0).getTemplateId();
				Integer templateIDInt = Integer.parseInt(templateID);
				log.info(String.format("TemplateID fetched from Webclient call to drupal is  %s", templateID));
				return templateIDInt;

			}

		} catch (Exception e) {
			log.error(String.format("Drupal Webclient call failed %s", e.getMessage()));
		}
		
		log.error("Response from drupal Api was null or emplty");
		return null;
		
	}

//	public GetResponseMessage caseExportWebclienttoServiceBusWorker(String caseExport,
//			GetResponseMessage genericResponse) {
//		log.info("caseExportWebclienttoServiceBusWorker Started ");
//		try {
//
//			new ServiceBusClientBuilder().fullyQualifiedNamespace(caseExportServiceBusfullyQualifiedNamespace)
//					.credential(new ClientSecretCredentialBuilder().tenantId(servicbustenantId)
//							.clientId(servicbusclientId).clientSecret(servicbusclientSecret).build())
//					.sender().queueName(caseExportqueueName).buildClient()
//					.sendMessage(new ServiceBusMessage(caseExport));
//
//			genericResponse.setMessage("Successfully posted to SB ");
//
//			log.info("postRequestToServiceBus Method Ended ");
//		} catch (Exception e) {
//			genericResponse.setMessage("Sending request to ServiceBus Failed");
//			log.info("Posting caseExport Request in ServiceBus Connectivity Failed ");
//
//			throw new AzureServiceException(
//					messageSource.getMessage("api.error.AzureServiceBusconnectivity", null, Locale.ENGLISH),
//					e.getMessage());
//		}
//		return genericResponse;
//
//	}

	
	public void updateCaseServiceBusWebclient(EfileMessage updateCase) throws JsonProcessingException {
		log.info("updateCaseServiceBusWebclient Started ");
		try {

			new ServiceBusClientBuilder().fullyQualifiedNamespace(updateCaseServiceBusfullyQualifiedNamespace)
					.credential(new ClientSecretCredentialBuilder().tenantId(servicbustenantId)
							.clientId(servicebusCaseUpdateClientId).clientSecret(servicebusCaseUpdateSecretId).build())
					.sender().queueName(caseupdatequeueName).buildClient()
					.sendMessage(new ServiceBusMessage(new ObjectMapper().writeValueAsString(updateCase)));
			log.info("updateCaseServiceBusWebclient Ended");

		} catch (Exception e) {
			log.error(String.format("Posting case withdraw in ServiceBus Connectivity Failed %s",e.getMessage()));
			throw new AzureServiceException(
					messageSource.getMessage("api.error.AzureServiceBusconnectivity", null, Locale.ENGLISH),
					e.getMessage());
		}

	}
	


	public void caseupdateNotificationWebclient(NotificationModel notification) {
		log.info("caseupdateNotificationWebclient Started");
		NotificationResponse response = new NotificationResponse();
		try {
			String url = apim_url + notificationApiUrl;
			log.info(String.format("Notification url :: %s", url));
			response = WebClient.create().post().uri(url)
					.header(AUTHORIZATION, BEARER + userbean.getAuthToken())
					.header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
					.body(Mono.just(notification), Notification.class).accept(MediaType.APPLICATION_JSON).retrieve()
					.bodyToMono(NotificationResponse.class).block();
			log.info(String.format("Notification Webclient Method Ended %s",response));
		} catch (Exception e) {
			log.info(String.format("Connectivity of Notification Webclient Failed %s",e.getMessage()));

			throw new AzureServiceException(
					messageSource.getMessage("api.error.WebclientConnectivityFailed ", null, Locale.ENGLISH),
					e.getMessage());
		}

	}
	
	public void communcationEmailApiCall(UserRequestBody emailRequest) {
		log.info("communcation EmailApi webclient call Started");
		EmailNotificationResponse response = new EmailNotificationResponse();
		try {
			String url = apim_url + commApi;
			log.info(String.format("Communication url :: %s", url));
			response = WebClient.create().post().uri(url)
					.header(AUTHORIZATION, BEARER + userbean.getAuthToken())
					.header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
					.body(Mono.just(emailRequest), UserRequestBody.class).accept(MediaType.APPLICATION_JSON).retrieve()
					.bodyToMono(EmailNotificationResponse.class).block();
			log.info(String.format("Communication Webclient Method Ended %s",response));
		} catch (Exception e) {
			log.info(String.format("Connectivity of communication Webclient Failed %s",e.getMessage()));

		}

	}
	
	public void communicationSmsApiCall(SinchApiRequest sinchReq) {
		log.info("communcation Send SMS webclient call Started");
		
		EmailNotificationResponse response = new EmailNotificationResponse();
		try {
			String url = apim_url + sendSms;
			log.info(String.format("Communication SendSMS apim url :: %s", url));
			response = WebClient.create().post().uri(url)
					.header(API_KEY, commonUtil.xApiKey)
					.header(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
					.body(Mono.just(sinchReq), SinchApiRequest.class).accept(MediaType.APPLICATION_JSON).retrieve()
					.bodyToMono(EmailNotificationResponse.class).block();
			log.info(String.format("Communication Webclient Method call to Sendsms Ended %s",response.toString()));
		} catch (Exception e) {
			log.info(String.format("Connectivity of communication Webclient Sendsms call  Failed %s",e.getMessage()));

		}

	}


	public void updateOfferoutcomeServiceBusWebclient(EfileMessage efileMessage) throws JsonProcessingException {
		log.info("updateCaseServiceBusWebclient Started");
		try {
			String writeValueAsString = new ObjectMapper().writeValueAsString(efileMessage);
			log.info(String.format("updateOfferoutcome ServiceBusWebclient Started with message %s",writeValueAsString));

			new ServiceBusClientBuilder().fullyQualifiedNamespace(updateCaseServiceBusfullyQualifiedNamespace)
			.credential(new ClientSecretCredentialBuilder().tenantId(servicbustenantId)
					.clientId(servicebusCaseUpdateClientId).clientSecret(servicebusCaseUpdateSecretId).build())
			.sender().queueName(caseupdatequeueName).buildClient()
			.sendMessage(new ServiceBusMessage(new ObjectMapper().writeValueAsString(efileMessage)));
			log.info(String.format("updateOfferOutcomeServiceBusWebclient Ended %s",writeValueAsString));

		} catch (Exception e) {
			log.error(String.format("Posting offeroutcome update in ServiceBus Connectivity Failed %s", e.getMessage()));
			throw new AzureServiceException(
					messageSource.getMessage("api.error.AzureServiceBusconnectivity", null, Locale.ENGLISH),
					e.getMessage());
			
		}

	}
}
