
package com.ombudsman.service.complainant.exception;

import org.springframework.dao.DataAccessException;

public class DbRecordCreationException extends DataAccessException {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public DbRecordCreationException(String exceptionMsg)
	{
		super(exceptionMsg);
	}


}
