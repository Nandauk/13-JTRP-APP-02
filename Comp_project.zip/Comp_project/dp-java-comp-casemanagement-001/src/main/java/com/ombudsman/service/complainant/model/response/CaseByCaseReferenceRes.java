package com.ombudsman.service.complainant.model.response;

public class CaseByCaseReferenceRes extends GenericResponse{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String incidentid;
	
	public String getIncidentid() {
		return incidentid;
	}
	public void setIncidentid(String incidentid) {
		this.incidentid = incidentid;
	}
}
