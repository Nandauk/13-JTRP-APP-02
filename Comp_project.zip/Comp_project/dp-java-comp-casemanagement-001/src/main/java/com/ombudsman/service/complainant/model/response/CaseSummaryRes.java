package com.ombudsman.service.complainant.model.response;

import java.util.List;

import com.ombudsman.service.complainant.model.CaseDetail;
import com.ombudsman.service.complainant.model.CaseWorker;

public class CaseSummaryRes extends GenericResponse {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 4447128096932131295L;
	private transient CaseDetail casedetails;
	private List<CasePartiesDetail> caseParties;
	private CaseWorker caseWorkerDtls;
	public CaseDetail getCasedetails() {
		return casedetails;
	}
	public void setCasedetails(CaseDetail casedetails) {
		this.casedetails = casedetails;
	}
	public List<CasePartiesDetail> getCaseParties() {
		return caseParties;
	}
	public void setCaseParties(List<CasePartiesDetail> caseParties) {
		this.caseParties = caseParties;
	}
	public CaseWorker getCaseWorkerDtls() {
		return caseWorkerDtls;
	}
	public void setCaseWorkerDtls(CaseWorker caseWorkerDtls) {
		this.caseWorkerDtls = caseWorkerDtls;
	}
}