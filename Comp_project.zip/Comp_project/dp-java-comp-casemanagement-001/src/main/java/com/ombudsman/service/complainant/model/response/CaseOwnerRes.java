package com.ombudsman.service.complainant.model.response;

import com.ombudsman.service.complainant.model.CaseWorker;

public class CaseOwnerRes extends GenericResponse{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String caseStage;
	private CaseWorker caseWorker;
	public String getCaseStage() {
		return caseStage;
	}
	public void setCaseStage(String caseStage) {
		this.caseStage = caseStage;
	}
	public CaseWorker getCaseWorker() {
		return caseWorker;
	}
	public void setCaseWorker(CaseWorker caseWorker) {
		this.caseWorker = caseWorker;
	}

	
}
