package com.ombudsman.service.complainant.model;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonFormat.Shape;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "incident")
public class Incident {

	private Long statecode;
	private Long statuscode;
	@Id
	private String incidentid;
	private Long fos_oldercasestatus;
	private Long fos_casestage;
	private Long fos_changeinoutcome;

	private Long fos_consumerpronouncode;
	private Long fos_furtheststage;
	private Long fos_hearingrequestapprovedcode;
	private Long fos_hearingrequestedbycode;
	private Long fos_howwasthiscaseresolved;
	private Long fos_prioritycode;
	private Long fos_saleschannel;
	private Long fos_salestype;
	private Long fos_suppressedfordigitalportal;
	
	@JsonFormat(shape = Shape.NUMBER)
	private Boolean fos_isapproximatedateofevent;
	@JsonFormat(shape = Shape.NUMBER)
	private Boolean fos_ishearingheld;
	@JsonFormat(shape = Shape.NUMBER)
	private Boolean fos_ishearingrequested;
	
	private String fos_caseworker;
	private String fos_complaintissue;
	private String fos_productorproductfamily;
	private String fos_resolvingoutcomeid;
	private String owningbusinessunit;
	private String owningteam;
	private String owninguser;
	private String ownerid;
	private String customerid;
	private String description;
	private String fos_complaintissuename;
	private String fos_crn;
	private String fos_casestagename;
	private String fos_prioritycodename;
	private String fos_furtherstagename;
	private String customeridname;
	private String fos_datebusinessfilereceived;
	private String fos_datecasefirstmovedtoinvestigation;
	private String fos_datemovedintocurrentstage;
	private String fos_dateofcomplainttobusiness;
	private String fos_dateofconversion;
	private String fos_dateofevent;
	private String fos_dateoffinalresponse;
	private String fos_dateofhearing;
	private String fos_dateofreferral;
	private String fos_dateofsrc;
	private String fos_extendedreference;
	private String fos_productorproductfamilyname;
	private String fos_productreference;
	private String fos_representatives;
	private String caseage;
	private String fos_respondentearlyconsentdate;
	private String fos_respondentname;
	private String fos_responsedateofbusiness;
	private String ticketnumber;
	private String title;
	private String fos_suppressedfordigitalportalname;
	private String fos_businessdateofcomplaint;
	private Long versionnumber;
	private String modifiedon;
	private String createdby;
	private String modifiedby;
	private String createdon;
	private String statuscodename;
	private String incrementaldataloadjobauditid;

	public String getIncrementaldataloadjobauditid() {
		return incrementaldataloadjobauditid;
	}

	public void setIncrementaldataloadjobauditid(String incrementaldataloadjobauditid) {
		this.incrementaldataloadjobauditid = incrementaldataloadjobauditid;
	}

	public String getStatuscodename() {
		return statuscodename;
	}

	public void setStatuscodename(String statuscodename) {
		this.statuscodename = statuscodename;
	}

	public Long getStatecode() {
		return statecode;
	}

	public void setStatecode(Long statecode) {
		this.statecode = statecode;
	}

	public Long getStatuscode() {
		return statuscode;
	}

	public void setStatuscode(Long statuscode) {
		this.statuscode = statuscode;
	}

	public String getIncidentid() {
		return incidentid;
	}

	public void setIncidentid(String incidentid) {
		this.incidentid = incidentid;
	}

	public Long getFos_oldercasestatus() {
		return fos_oldercasestatus;
	}

	public void setFos_oldercasestatus(Long fos_oldercasestatus) {
		this.fos_oldercasestatus = fos_oldercasestatus;
	}

	public Long getFos_casestage() {
		return fos_casestage;
	}

	public void setFos_casestage(Long fos_casestage) {
		this.fos_casestage = fos_casestage;
	}

	public Long getFos_changeinoutcome() {
		return fos_changeinoutcome;
	}

	public void setFos_changeinoutcome(Long fos_changeinoutcome) {
		this.fos_changeinoutcome = fos_changeinoutcome;
	}

	public Long getFos_consumerpronouncode() {
		return fos_consumerpronouncode;
	}

	public void setFos_consumerpronouncode(Long fos_consumerpronouncode) {
		this.fos_consumerpronouncode = fos_consumerpronouncode;
	}

	public Long getFos_furtheststage() {
		return fos_furtheststage;
	}

	public void setFos_furtheststage(Long fos_furtheststage) {
		this.fos_furtheststage = fos_furtheststage;
	}

	public Long getFos_hearingrequestapprovedcode() {
		return fos_hearingrequestapprovedcode;
	}

	public void setFos_hearingrequestapprovedcode(Long fos_hearingrequestapprovedcode) {
		this.fos_hearingrequestapprovedcode = fos_hearingrequestapprovedcode;
	}

	public Long getFos_hearingrequestedbycode() {
		return fos_hearingrequestedbycode;
	}

	public void setFos_hearingrequestedbycode(Long fos_hearingrequestedbycode) {
		this.fos_hearingrequestedbycode = fos_hearingrequestedbycode;
	}

	public Long getFos_howwasthiscaseresolved() {
		return fos_howwasthiscaseresolved;
	}

	public void setFos_howwasthiscaseresolved(Long fos_howwasthiscaseresolved) {
		this.fos_howwasthiscaseresolved = fos_howwasthiscaseresolved;
	}

	public Long getFos_prioritycode() {
		return fos_prioritycode;
	}

	public void setFos_prioritycode(Long fos_prioritycode) {
		this.fos_prioritycode = fos_prioritycode;
	}

	public Long getFos_saleschannel() {
		return fos_saleschannel;
	}

	public void setFos_saleschannel(Long fos_saleschannel) {
		this.fos_saleschannel = fos_saleschannel;
	}

	public Long getFos_salestype() {
		return fos_salestype;
	}

	public void setFos_salestype(Long fos_salestype) {
		this.fos_salestype = fos_salestype;
	}

	public Long getFos_suppressedfordigitalportal() {
		return fos_suppressedfordigitalportal;
	}

	public void setFos_suppressedfordigitalportal(Long fos_suppressedfordigitalportal) {
		this.fos_suppressedfordigitalportal = fos_suppressedfordigitalportal;
	}

	public Boolean getFos_isapproximatedateofevent() {
		return fos_isapproximatedateofevent;
	}

	public void setFos_isapproximatedateofevent(Boolean fos_isapproximatedateofevent) {
		this.fos_isapproximatedateofevent = fos_isapproximatedateofevent;
	}

	public Boolean getFos_ishearingheld() {
		return fos_ishearingheld;
	}

	public void setFos_ishearingheld(Boolean fos_ishearingheld) {
		this.fos_ishearingheld = fos_ishearingheld;
	}

	public Boolean getFos_ishearingrequested() {
		return fos_ishearingrequested;
	}

	public void setFos_ishearingrequested(Boolean fos_ishearingrequested) {
		this.fos_ishearingrequested = fos_ishearingrequested;
	}

	public String getFos_caseworker() {
		return fos_caseworker;
	}

	public void setFos_caseworker(String fos_caseworker) {
		this.fos_caseworker = fos_caseworker;
	}

	public String getFos_complaintissue() {
		return fos_complaintissue;
	}

	public void setFos_complaintissue(String fos_complaintissue) {
		this.fos_complaintissue = fos_complaintissue;
	}

	public String getFos_productorproductfamily() {
		return fos_productorproductfamily;
	}

	public void setFos_productorproductfamily(String fos_productorproductfamily) {
		this.fos_productorproductfamily = fos_productorproductfamily;
	}

	public String getFos_resolvingoutcomeid() {
		return fos_resolvingoutcomeid;
	}

	public void setFos_resolvingoutcomeid(String fos_resolvingoutcomeid) {
		this.fos_resolvingoutcomeid = fos_resolvingoutcomeid;
	}

	public String getOwningbusinessunit() {
		return owningbusinessunit;
	}

	public void setOwningbusinessunit(String owningbusinessunit) {
		this.owningbusinessunit = owningbusinessunit;
	}

	public String getOwningteam() {
		return owningteam;
	}

	public void setOwningteam(String owningteam) {
		this.owningteam = owningteam;
	}

	public String getOwninguser() {
		return owninguser;
	}

	public void setOwninguser(String owninguser) {
		this.owninguser = owninguser;
	}

	public String getOwnerid() {
		return ownerid;
	}

	public void setOwnerid(String ownerid) {
		this.ownerid = ownerid;
	}

	public String getCustomerid() {
		return customerid;
	}

	public void setCustomerid(String customerid) {
		this.customerid = customerid;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getFos_complaintissuename() {
		return fos_complaintissuename;
	}

	public void setFos_complaintissuename(String fos_complaintissuename) {
		this.fos_complaintissuename = fos_complaintissuename;
	}

	public String getFos_crn() {
		return fos_crn;
	}

	public void setFos_crn(String fos_crn) {
		this.fos_crn = fos_crn;
	}

	public String getFos_casestagename() {
		return fos_casestagename;
	}

	public void setFos_casestagename(String fos_casestagename) {
		this.fos_casestagename = fos_casestagename;
	}

	public String getFos_prioritycodename() {
		return fos_prioritycodename;
	}

	public void setFos_prioritycodename(String fos_prioritycodename) {
		this.fos_prioritycodename = fos_prioritycodename;
	}

	public String getFos_furtherstagename() {
		return fos_furtherstagename;
	}

	public void setFos_furtherstagename(String fos_furtherstagename) {
		this.fos_furtherstagename = fos_furtherstagename;
	}

	public String getCustomeridname() {
		return customeridname;
	}

	public void setCustomeridname(String customeridname) {
		this.customeridname = customeridname;
	}

	public String getFos_datebusinessfilereceived() {
		return fos_datebusinessfilereceived;
	}

	public void setFos_datebusinessfilereceived(String fos_datebusinessfilereceived) {
		this.fos_datebusinessfilereceived = fos_datebusinessfilereceived;
	}

	public String getFos_datecasefirstmovedtoinvestigation() {
		return fos_datecasefirstmovedtoinvestigation;
	}

	public void setFos_datecasefirstmovedtoinvestigation(String fos_datecasefirstmovedtoinvestigation) {
		this.fos_datecasefirstmovedtoinvestigation = fos_datecasefirstmovedtoinvestigation;
	}

	public String getFos_datemovedintocurrentstage() {
		return fos_datemovedintocurrentstage;
	}

	public void setFos_datemovedintocurrentstage(String fos_datemovedintocurrentstage) {
		this.fos_datemovedintocurrentstage = fos_datemovedintocurrentstage;
	}

	public String getFos_dateofcomplainttobusiness() {
		return fos_dateofcomplainttobusiness;
	}

	public void setFos_dateofcomplainttobusiness(String fos_dateofcomplainttobusiness) {
		this.fos_dateofcomplainttobusiness = fos_dateofcomplainttobusiness;
	}

	public String getFos_dateofconversion() {
		return fos_dateofconversion;
	}

	public void setFos_dateofconversion(String fos_dateofconversion) {
		this.fos_dateofconversion = fos_dateofconversion;
	}

	public String getFos_dateofevent() {
		return fos_dateofevent;
	}

	public void setFos_dateofevent(String fos_dateofevent) {
		this.fos_dateofevent = fos_dateofevent;
	}

	public String getFos_dateoffinalresponse() {
		return fos_dateoffinalresponse;
	}

	public void setFos_dateoffinalresponse(String fos_dateoffinalresponse) {
		this.fos_dateoffinalresponse = fos_dateoffinalresponse;
	}

	public String getFos_dateofhearing() {
		return fos_dateofhearing;
	}

	public void setFos_dateofhearing(String fos_dateofhearing) {
		this.fos_dateofhearing = fos_dateofhearing;
	}

	public String getFos_dateofreferral() {
		return fos_dateofreferral;
	}

	public void setFos_dateofreferral(String fos_dateofreferral) {
		this.fos_dateofreferral = fos_dateofreferral;
	}

	public String getFos_dateofsrc() {
		return fos_dateofsrc;
	}

	public void setFos_dateofsrc(String fos_dateofsrc) {
		this.fos_dateofsrc = fos_dateofsrc;
	}

	public String getFos_extendedreference() {
		return fos_extendedreference;
	}

	public void setFos_extendedreference(String fos_extendedreference) {
		this.fos_extendedreference = fos_extendedreference;
	}

	public String getFos_productorproductfamilyname() {
		return fos_productorproductfamilyname;
	}

	public void setFos_productorproductfamilyname(String fos_productorproductfamilyname) {
		this.fos_productorproductfamilyname = fos_productorproductfamilyname;
	}

	public String getFos_productreference() {
		return fos_productreference;
	}

	public void setFos_productreference(String fos_productreference) {
		this.fos_productreference = fos_productreference;
	}

	public String getFos_representatives() {
		return fos_representatives;
	}

	public void setFos_representatives(String fos_representatives) {
		this.fos_representatives = fos_representatives;
	}

	public String getCaseage() {
		return caseage;
	}

	public void setCaseage(String caseage) {
		this.caseage = caseage;
	}

	public String getFos_respondentearlyconsentdate() {
		return fos_respondentearlyconsentdate;
	}

	public void setFos_respondentearlyconsentdate(String fos_respondentearlyconsentdate) {
		this.fos_respondentearlyconsentdate = fos_respondentearlyconsentdate;
	}

	public String getFos_respondentname() {
		return fos_respondentname;
	}

	public void setFos_respondentname(String fos_respondentname) {
		this.fos_respondentname = fos_respondentname;
	}

	public String getFos_responsedateofbusiness() {
		return fos_responsedateofbusiness;
	}

	public void setFos_responsedateofbusiness(String fos_responsedateofbusiness) {
		this.fos_responsedateofbusiness = fos_responsedateofbusiness;
	}

	public String getTicketnumber() {
		return ticketnumber;
	}

	public void setTicketnumber(String ticketnumber) {
		this.ticketnumber = ticketnumber;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getFos_suppressedfordigitalportalname() {
		return fos_suppressedfordigitalportalname;
	}

	public void setFos_suppressedfordigitalportalname(String fos_suppressedfordigitalportalname) {
		this.fos_suppressedfordigitalportalname = fos_suppressedfordigitalportalname;
	}

	public Long getVersionnumber() {
		return versionnumber;
	}

	public void setVersionnumber(Long versionnumber) {
		this.versionnumber = versionnumber;
	}

	public String getFos_businessdateofcomplaint() {
		return fos_businessdateofcomplaint;
	}

	public void setFos_businessdateofcomplaint(String fos_businessdateofcomplaint) {
		this.fos_businessdateofcomplaint = fos_businessdateofcomplaint;
	}

	public String getModifiedon() {
		return modifiedon;
	}

	public void setModifiedon(String modifiedon) {
		this.modifiedon = modifiedon;
	}

	public String getCreatedby() {
		return createdby;
	}

	public void setCreatedby(String createdby) {
		this.createdby = createdby;
	}

	public String getModifiedby() {
		return modifiedby;
	}

	public void setModifiedby(String modifiedby) {
		this.modifiedby = modifiedby;
	}

	public String getCreatedon() {
		return createdon;
	}

	public void setCreatedon(String createdon) {
		this.createdon = createdon;
	}

	public LocalDateTime getModifiedonSorting() {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss'Z'");
		return LocalDateTime.parse(modifiedon, formatter);
	}

}
