package com.ombudsman.service.complainant.model;

import java.util.List;

 import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;

@Valid
public class Organisation {
	
	
	private String name;
	
	private String fos_fcareference;
	
	private String fos_hierarchylevel; //Group, Main Level, Trading Name, Other Name
	
	private String legalentityname;

	private String accountnumber; //phoenixid

	@NotNull
	@NotBlank
	private String accountid; //Organisation
	
	private String _parentaccountid_value; // Parent Organisation
	
	private String accountcategorycode; // Capacity
	
	private String businesstypecode; // Organisation Type (based on Capacity)
	
	private String fos_approvalstatus; //Approval Status
	
	@Valid
	@NotNull
	@NotEmpty
	private List<Respondents> respondents;


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getFos_fcareference() {
		return fos_fcareference;
	}


	public void setFos_fcareference(String fos_fcareference) {
		this.fos_fcareference = fos_fcareference;
	}


	public String getFos_hierarchylevel() {
		return fos_hierarchylevel;
	}


	public void setFos_hierarchylevel(String fos_hierarchylevel) {
		this.fos_hierarchylevel = fos_hierarchylevel;
	}


	public String getLegalentityname() {
		return legalentityname;
	}


	public void setLegalentityname(String legalentityname) {
		this.legalentityname = legalentityname;
	}


	public String getAccountnumber() {
		return accountnumber;
	}


	public void setAccountnumber(String accountnumber) {
		this.accountnumber = accountnumber;
	}


	public String getAccountid() {
		return accountid;
	}


	public void setAccountid(String accountid) {
		this.accountid = accountid;
	}


	public String get_parentaccountid_value() {
		return _parentaccountid_value;
	}


	public void set_parentaccountid_value(String _parentaccountid_value) {
		this._parentaccountid_value = _parentaccountid_value;
	}


	public String getAccountcategorycode() {
		return accountcategorycode;
	}


	public void setAccountcategorycode(String accountcategorycode) {
		this.accountcategorycode = accountcategorycode;
	}


	public String getBusinesstypecode() {
		return businesstypecode;
	}


	public void setBusinesstypecode(String businesstypecode) {
		this.businesstypecode = businesstypecode;
	}


	public List<Respondents> getRespondents() {
		return respondents;
	}


	public void setRespondents(List<Respondents> respondents) {
		this.respondents = respondents;
	}


	public String getFos_approvalstatus() {
		return fos_approvalstatus;
	}


	public void setFos_approvalstatus(String fos_approvalstatus) {
		this.fos_approvalstatus = fos_approvalstatus;
	}



}
