package com.ombudsman.service.complainant.model.request;


import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public class CaseOutcomeByIdReq {
	
	@NotNull
	@NotBlank
	private String incidentid;

	public String getIncidentid() {
		return incidentid;
	}

	public void setIncidentid(String incidentid) {
		this.incidentid = incidentid;
	}

}
