package com.ombudsman.service.complainant.model;


public class EfileMessage {

	private String caseId;
	private String comments;
	private String details;
	private int reasonForChange;
	private String packageId;
    private String[] usersAccountIds;
    private String digitalPortalUserName ;
	private String digitalPortalUserEmailAddress ;
	private String fromContactId ;
	private String PortalType;
	
	
	
	public int getReasonForChange() {
		return reasonForChange;
	}
	public void setReasonForChange(int reasonForChange) {
		this.reasonForChange = reasonForChange;
	}

	public String getPortalType() {
		return PortalType;
	}
	public void setPortalType(String portalType) {
		PortalType = portalType;
	}
	public String getDigitalPortalUserName() {
		return digitalPortalUserName;
	}
	public void setDigitalPortalUserName(String digitalPortalUserName) {
		this.digitalPortalUserName = digitalPortalUserName;
	}
	public String getDigitalPortalUserEmailAddress() {
		return digitalPortalUserEmailAddress;
	}
	public void setDigitalPortalUserEmailAddress(String digitalPortalUserEmailAddress) {
		this.digitalPortalUserEmailAddress = digitalPortalUserEmailAddress;
	}

	public String getPackageId() {
		return packageId;
	}
	public void setPackageId(String packageId) {
		this.packageId = packageId;
	}

	public String[] getUsersAccountIds() {
		return usersAccountIds;
	}
	public void setUsersAccountIds(String[] usersAccountIds) {
		this.usersAccountIds = usersAccountIds;
	}
	public String getCaseId() {
		return caseId;
	}
	public void setCaseId(String caseId) {
		this.caseId = caseId;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	public String getDetails() {
		return details;
	}
	public void setDetails(String details) {
		this.details = details;
	}
	public String getFromContactId() {
		return fromContactId;
	}
	public void setFromContactId(String fromContactId) {
		this.fromContactId = fromContactId;
	}

	
}
