package com.ombudsman.service.complainant.service;

import java.io.IOException;

import org.json.JSONException;

import com.ombudsman.service.complainant.exception.AzureServiceException;
import com.ombudsman.service.complainant.exception.CaseReferenceDetailsNotFoundException;
import com.ombudsman.service.complainant.exception.SQLDataAccessException;
import com.ombudsman.service.complainant.exception.UnAuthorisedException;
import com.ombudsman.service.complainant.model.request.CaseByCaseReferenceReq;
import com.ombudsman.service.complainant.model.response.CaseByCaseReferenceRes;

public interface CaseByCaseReferenceService {
	
	public CaseByCaseReferenceRes getCaseIncidentidByCaseReference(CaseByCaseReferenceReq request) throws AzureServiceException, JSONException, IOException, SQLDataAccessException, CaseReferenceDetailsNotFoundException, UnAuthorisedException;

}
