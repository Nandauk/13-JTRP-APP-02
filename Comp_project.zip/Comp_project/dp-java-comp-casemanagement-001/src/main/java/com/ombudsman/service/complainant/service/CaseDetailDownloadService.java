package com.ombudsman.service.complainant.service;

import java.io.IOException;

import javax.security.auth.login.AccountNotFoundException;

import com.ombudsman.service.complainant.exception.SQLDataAccessException;
import com.ombudsman.service.complainant.exception.UnAuthorisedException;
import com.ombudsman.service.complainant.model.request.CaseDetailsByIdReq;
import com.ombudsman.service.complainant.model.request.CaseFileFrDownloadReq;
import com.ombudsman.service.complainant.model.response.CaseDocumentFrDownloadRes;
import com.ombudsman.service.complainant.model.response.CaseMessagingFrDownloadRes;

public interface CaseDetailDownloadService {
	
	public  CaseDocumentFrDownloadRes getCaseDocumentDetailsFrDownload(CaseFileFrDownloadReq request) throws SQLDataAccessException, AccountNotFoundException, UnAuthorisedException, IOException;
	
	public  CaseMessagingFrDownloadRes getCaseConversationDetailsFrDownload(CaseDetailsByIdReq request) throws SQLDataAccessException, AccountNotFoundException, UnAuthorisedException, IOException;

}
