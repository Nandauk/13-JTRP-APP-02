package com.ombudsman.service.complainant.serviceimpl.helper;

import java.io.IOException;
import java.util.Optional;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Service;

import com.google.gson.Gson;
import com.ombudsman.service.complainant.common.Constants;
import com.ombudsman.service.complainant.common.WebClientData;
import com.ombudsman.service.complainant.exception.PhoenixServiceException;
import com.ombudsman.service.complainant.model.QueueData;
import com.ombudsman.service.complainant.model.QueueResponse;
import com.ombudsman.service.complainant.model.SystemUserData;
import com.ombudsman.service.complainant.model.SystemUserResponse;
import com.ombudsman.service.complainant.service.PhoenixCallProcessor;

import io.netty.util.internal.StringUtil;
import okhttp3.HttpUrl;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
@Service
public class PhoenixCallProcessorImpl implements PhoenixCallProcessor {
	private static final String SYSTEMUSER = "/systemusers(";
	private static final String TEAMUSER = "/teams(";
WebClientData webClientData;
	
public PhoenixCallProcessorImpl(WebClientData webClientData) {
	this.webClientData = webClientData;
}

Logger LOG = LogManager.getRootLogger();
	
	
	public int updateRecordPhnx(String offeroutcomeId, String jsonBody) {
		Response response=null;
		try {

			LOG.info("Entering to updateRecordPhnx method");

			OkHttpClient client = new OkHttpClient();

			MediaType mediaType = MediaType.parse("application/json; charset=utf-8");

			HttpUrl httpUrl = new HttpUrl.Builder().scheme("https")
					.host(webClientData.apimHost).addPathSegment("phoenixapimp")
					.addPathSegment(Constants.ENTITY_NAME+"("+offeroutcomeId+")").build();

			RequestBody body = RequestBody.create(jsonBody, mediaType);

			Request request = new Request.Builder().url(httpUrl).addHeader("Content-Type", "application/json")
					.addHeader("OData-MaxVersion", "4.0").addHeader("OData-Version", "4.0")
					//.addHeader("Authorization", "Bearer " + accessToken)
					.patch(body).build();

			response = Optional.ofNullable(client.newCall(request).execute()).orElseThrow(
					() -> new PhoenixServiceException("Phoenix exception occured", "No Response from ODATA api"));

			LOG.info("Response Code:-{}", response.code());
			String responseBody = response.body().string();
			LOG.info("Response Body:-{}", responseBody);

			LOG.info("updateRecordPhnx Method Sucess");

		} catch (Exception e) {
			LOG.info("getting exception in update offeroutcome record at Phoenix side:-{}",e.getMessage());

		}
		return response.code();
	}

	@Override
	public String getToValue(String ownerId, String owningTeam, String owningUser) {

		if (!StringUtil.isNullOrEmpty(owningUser)) {
			LOG.info("Owning user value is not empty, thus it is USER:-{}", owningUser);
			String entityName = "systemusers";
			String systemuserid = getRecordFromSystemUser(entityName, ownerId);
			return "/systemusers/" + systemuserid;

		} else if (!StringUtil.isNullOrEmpty(owningTeam)) {
			LOG.info("Owning team value is not empty, thus it is TEAM:-{}", owningTeam);
			String recordIdentifier = "<ombudsman Investigators and adjudicators general>";
			String entityName = "queues";
			String queueid = getRecordFromQueue(entityName, recordIdentifier);
			return "/queues/" + queueid;
		}

		return "";
	}


	@Override	
	public String getRecordFromQueue( String entityName, String recordIdentifier) {
		Response response = null;
		try {
			LOG.info("Entering getRecordFromQueue method");

			OkHttpClient client = new OkHttpClient();

			HttpUrl httpUrl = new HttpUrl.Builder().scheme("https").host(webClientData.apimHost)
					.addPathSegment("phoenixapimp").addPathSegment(entityName)
					.addQueryParameter("$filter", "name eq '" + recordIdentifier + "'").build();

			Request request = new Request.Builder().url(httpUrl)
					//.addHeader("Authorization", "Bearer " + accessToken)
					.addHeader("OData-Version", "4.0").addHeader("OData-MaxVersion", "4.0").get().build();

			LOG.info("Request URL: {}", httpUrl);
			LOG.info("Request Headers: {}", request.headers().toString());

			response = Optional.ofNullable(client.newCall(request).execute()).orElseThrow(
					() -> new PhoenixServiceException("Phoenix exception occured", "No Response from ODATA api"));

			LOG.info("Response Code from Queue: {}", response.code());
			String responseBody = response.body().string();
			LOG.info("Response Body Of Queue: {}", responseBody);

			String jsonString = responseBody;

			Gson gson = new Gson();
			QueueResponse mapResponse = gson.fromJson(jsonString, QueueResponse.class);
			String queueId = "";
			for (QueueData valueData : mapResponse.getValue()) {
				if (!StringUtil.isNullOrEmpty(valueData.getQueueid())) {
					queueId = valueData.getQueueid();
				} else {
					LOG.info("Queue ID is either null or Emplty {}");
				}
			}

			return queueId;

		} catch (Exception e) {
			if (response != null && response.body() != null) {
				try {
					LOG.info("Response body: {}", response.body().string());
				} catch (IOException ioe) {
					LOG.info("Error reading response body: {}", ioe.getMessage());
				}
			}
			LOG.info("Phoenix connection failed {}", e.getMessage());
			throw new PhoenixServiceException(
					"Unable to fetch record from Queue table", e.getMessage());
		}

	}

	
		@Override
		public String getRecordFromSystemUser(String entityName, String recordIdentifier) {
			
		Response response = null;
		try {
			LOG.info("Entering getRecordFromSystemUser method");

			OkHttpClient client = new OkHttpClient();

			HttpUrl httpUrl = new HttpUrl.Builder().scheme("https").host(webClientData.apimHost)
					.addPathSegment("phoenixapimp").addPathSegment(entityName)
					.addQueryParameter("$filter", "systemuserid eq '" + recordIdentifier + "'").build();

			Request request = new Request.Builder().url(httpUrl)
					//.addHeader("Authorization", "Bearer " + accessToken)
					.addHeader("OData-Version", "4.0").addHeader("OData-MaxVersion", "4.0").get().build();

			LOG.info("Request URL:-{}", httpUrl);
			LOG.info("Request Headers:-{}", request.headers().toString());

			response = Optional.ofNullable(client.newCall(request).execute()).orElseThrow(
					() -> new PhoenixServiceException("Phoenix exception occured", "No Response from ODATA api"));

			LOG.info("Response Code from System User:-{}", response.code());
			String responseBody = response.body().string();
			LOG.info("Response Body Of System User:-{}", responseBody);

			String jsonString = responseBody;

			Gson gson = new Gson();
			SystemUserResponse mapResponse = gson.fromJson(jsonString, SystemUserResponse.class);
			String systemUserID = "";
			for (SystemUserData valueData : mapResponse.getValue()) {
				if (!StringUtil.isNullOrEmpty(valueData.getSystemuserid())) {
					systemUserID = valueData.getSystemuserid();
				} else {
					LOG.info("SystemUserID ID is either null or Emplty");
				}
			}
			return systemUserID;

		} catch (Exception e) {
			if (response != null && response.body() != null) {
				try {
					LOG.info("Response body:-{}", response.body().string());
				} catch (IOException ioe) {
					LOG.info("Error reading response body:-{}", ioe.getMessage());
				}
			}
			LOG.info("Phoenix connection failed:-{}", e.getMessage());
			throw new PhoenixServiceException(
					"Unable to fetch record from System Users table", e.getMessage());
		}

	}
		
		@Override
		public int createRecordPhnx(String entity, String jsonBody) {
			Response response;
			try {

				LOG.info("Entering to createRecordPhnx method");

				OkHttpClient client = new OkHttpClient();

				MediaType mediaType = MediaType.parse("application/json; charset=utf-8");

				HttpUrl httpUrl = new HttpUrl.Builder().scheme("https")
						.host(webClientData.apimHost).addPathSegment("phoenixapimp")
						.addPathSegment(entity).build();

				RequestBody body = RequestBody.create(jsonBody, mediaType);

				Request request = new Request.Builder().url(httpUrl).addHeader("Content-Type", "application/json")
						.addHeader("OData-MaxVersion", "4.0").addHeader("OData-Version", "4.0")
						//.addHeader("Authorization", "Bearer " + accessToken)
						.post(body).build();

				response = Optional.ofNullable(client.newCall(request).execute()).orElseThrow(
						() -> new PhoenixServiceException("Phoenix exception occured", "No Response from ODATA api"));

				LOG.info("Response Code:-{}", response.code());
				String responseBody = response.body().string();
				LOG.info("Response Body:-{}", responseBody);

				LOG.info("createRecordPhnx Method Sucess");
				return (response.code());

			} catch (Exception e) {
				throw new PhoenixServiceException("Phoenix exception occured", e.getMessage());

			}

		}
		public String getOwnerValue(String owningTeam, String owningUser) {
			if (!StringUtil.isNullOrEmpty(owningUser)) { 
				LOG.info("Owning user value is not empty, thus it is USER : {}", owningUser); 
				return SYSTEMUSER;
			} else if (!StringUtil.isNullOrEmpty(owningTeam)) { 
				LOG.info("Owning team value is not empty, thus it is TEAM : {}", owningTeam);
				return TEAMUSER;
			}
			return "";
		}


}
