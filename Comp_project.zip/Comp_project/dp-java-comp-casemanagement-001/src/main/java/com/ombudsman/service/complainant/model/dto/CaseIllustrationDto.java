package com.ombudsman.service.complainant.model.dto;

import java.math.BigInteger;
import java.time.OffsetDateTime;
import java.util.UUID;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.transaction.Transactional;

@Entity
@Table(name = "dp_complainant_case_illustration_details")
@Transactional
public class CaseIllustrationDto {

	@Id
	@Column(name = "incidentid")
	private UUID incidentid; // notnull
	@Column(name = "previous_stage_code")
	private String previousStageCode; // notnull
	@Column(name = "current_stage_code")
	private String currentStageCode; // notnull
	@Column(name = "furthest_stage_code")
	private String furthestStageCode; // notnull
	@Column(name = "created_on")
	private OffsetDateTime createdOn;
	@Column(name = "created_by")
	private String createdBy; // notnull
	@Column(name = "modified_on")
	private OffsetDateTime modifiedOn;
	@Column(name = "modified_by")
	private String modifiedBy;

	public UUID getIncidentid() {
		return incidentid;
	}
	public void setIncidentid(UUID incidentid) {
		this.incidentid = incidentid;
	}
	public String getPreviousStageCode() {
		return previousStageCode;
	}
	public void setPreviousStageCode(String previousStageCode) {
		this.previousStageCode = previousStageCode;
	}
	public String getCurrentStageCode() {
		return currentStageCode;
	}
	public void setCurrentStageCode(String currentStageCode) {
		this.currentStageCode = currentStageCode;
	}
	public String getFurthestStageCode() {
		return furthestStageCode;
	}
	public void setFurthestStageCode(String furthestStageCode) {
		this.furthestStageCode = furthestStageCode;
	}
	public OffsetDateTime getCreatedOn() {
		return createdOn;
	}
	public void setCreatedOn(OffsetDateTime createdOn) {
		this.createdOn = createdOn;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public OffsetDateTime getModifiedOn() {
		return modifiedOn;
	}
	public void setModifiedOn(OffsetDateTime modifiedOn) {
		this.modifiedOn = modifiedOn;
	}
	public String getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
}
