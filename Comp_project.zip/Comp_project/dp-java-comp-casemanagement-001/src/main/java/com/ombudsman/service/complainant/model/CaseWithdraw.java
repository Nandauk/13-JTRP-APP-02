package com.ombudsman.service.complainant.model;

public class CaseWithdraw  {
	private String caseId;
	private String comments;
	private String details;
	private String reasonForChange;
	private String packageId;
    private String[] usersAccountIds;
    private String digitalPortalUserName ;
	private String digitalPortalUserEmailAddress ;
	private String contactId ;
	private String isRespondent;
	
	
	public String getReasonForChange() {
		return reasonForChange;
	}
	public void setReasonForChange(String reasonForChange) {
		this.reasonForChange = reasonForChange;
	}
	public String getDigitalPortalUserName() {
		return digitalPortalUserName;
	}
	public void setDigitalPortalUserName(String digitalPortalUserName) {
		this.digitalPortalUserName = digitalPortalUserName;
	}
	public String getDigitalPortalUserEmailAddress() {
		return digitalPortalUserEmailAddress;
	}
	public void setDigitalPortalUserEmailAddress(String digitalPortalUserEmailAddress) {
		this.digitalPortalUserEmailAddress = digitalPortalUserEmailAddress;
	}
	public String getContactId() {
		return contactId;
	}
	public void setContactId(String contactId) {
		this.contactId = contactId;
	}
	public String getIsRespondent() {
		return isRespondent;
	}
	public void setIsRespondent(String isRespondent) {
		this.isRespondent = isRespondent;
	}
	public String getPackageId() {
		return packageId;
	}
	public void setPackageId(String packageId) {
		this.packageId = packageId;
	}
	public String[] getUsersAccountIds() {
		return usersAccountIds;
	}
	public void setUsersAccountIds(String[] usersAccountIds) {
		this.usersAccountIds = usersAccountIds;
	}
	public String getCaseId() {
		return caseId;
	}
	public void setCaseId(String caseId) {
		this.caseId = caseId;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	public String getDetails() {
		return details;
	}
	public void setDetails(String details) {
		this.details = details;
	}
	
    
}
