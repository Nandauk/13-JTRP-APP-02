package com.ombudsman.service.complainant.model.response;

public class CasePartiesDetail {

	public CasePartiesDetail(String partyName, String partyRole) {
		super();
		this.partyName = partyName;
		this.partyRole = partyRole;
	}
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String partyName;
	private String partyRole;
	public String getPartyName() {
		return partyName;
	}
	public void setPartyName(String partyName) {
		this.partyName = partyName;
	}
	public String getPartyRole() {
		return partyRole;
	}
	public void setPartyRole(String partyRole) {
		this.partyRole = partyRole;
	}
	
}
