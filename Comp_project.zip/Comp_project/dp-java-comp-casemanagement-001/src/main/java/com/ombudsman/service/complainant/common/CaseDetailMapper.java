package com.ombudsman.service.complainant.common;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.mapstruct.BeforeMapping;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import com.ombudsman.service.complainant.exception.CaseDetailsNotFoundException;
import com.ombudsman.service.complainant.model.CaseDetail;
import com.ombudsman.service.complainant.model.dto.CaseDetailDto;

@Mapper(componentModel = "spring")
public interface CaseDetailMapper {
	CaseDetailMapper INSTANCE = Mappers.getMapper(CaseDetailMapper.class);
	Logger LOG =  LogManager.getRootLogger();
	@BeforeMapping
	public default void datetimeformatMapper(CaseDetailDto caseDetailObj) {
		if(null != caseDetailObj.getFos_dateofreferral())
		{
			caseDetailObj.setFos_dateofreferral(datetimeformate(caseDetailObj.getFos_dateofreferral()));
		}
		
		if(null != caseDetailObj.getFos_dateofconversion())
		{
			caseDetailObj.setFos_dateofconversion(datetimeformate(caseDetailObj.getFos_dateofconversion()));
		}
		
	}
	
	private String datetimeformate(String date) {
		
		if (date != null) {
			LOG.info("date is not null:-{}",date);
			try {
				LocalDateTime localDateTime = LocalDateTime.parse(date,DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSSSSSS"));
				String format = localDateTime.format(DateTimeFormatter.ofPattern("MM/dd/yyyy hh:mm:ss a"));
				LOG.info("after formate change:-{}",format);
				return format;
			} catch (Exception e) {
				LOG.error("after formate change:-{}",date);
				throw new CaseDetailsNotFoundException("Datetime convertion error");
			}
		} else {
			LOG.debug("date is null:-{}",date);
			return null;
		}
	}
	 
	CaseDetail caseDetailsLst(CaseDetailDto caseDetailObj);
}
