package com.ombudsman.service.complainant.service;

import java.io.UnsupportedEncodingException;
import java.text.ParseException;

import org.json.JSONException;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ombudsman.service.complainant.exception.UnAuthorisedException;
import com.ombudsman.service.complainant.model.ApiResponse;
import com.ombudsman.service.complainant.model.CaseWithdraw;



public interface IUpdateFileService {
	

	ApiResponse updateCase(CaseWithdraw dto) throws UnsupportedEncodingException, JSONException, ParseException, JsonProcessingException,UnAuthorisedException;
	
	
	
}
