package com.ombudsman.service.complainant.service;

import java.io.IOException;

import org.json.JSONException;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ombudsman.service.complainant.exception.AzureServiceException;
import com.ombudsman.service.complainant.exception.CaseDetailsNotFoundException;
import com.ombudsman.service.complainant.exception.CaseOwnerDetailsNotFound;
import com.ombudsman.service.complainant.exception.SQLDataAccessException;
import com.ombudsman.service.complainant.model.request.CaseDetailsByIdReq;
import com.ombudsman.service.complainant.model.response.CaseDetailsByIdRes;
import com.ombudsman.service.complainant.model.response.CaseOwnerRes;


public interface CaseDetailsByIdService {
	
	public CaseDetailsByIdRes getCaseDetailsById(CaseDetailsByIdReq request) throws AzureServiceException, JsonProcessingException,IOException, SQLDataAccessException, CaseDetailsNotFoundException;
	
	public CaseOwnerRes getCaseOwnerDetails(CaseDetailsByIdReq request) throws AzureServiceException, JSONException, IOException, SQLDataAccessException, CaseOwnerDetailsNotFound;

}
