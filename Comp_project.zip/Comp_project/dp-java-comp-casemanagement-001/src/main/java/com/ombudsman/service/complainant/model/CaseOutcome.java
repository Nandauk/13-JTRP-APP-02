package com.ombudsman.service.complainant.model;

public class CaseOutcome {
	
	private String _fos_case_value;
	private String fos_offeroroutcomeid;
	private String fos_type;
	private String fos_type_txt;
	private String fos_meritsjurisdictiondismissal;
	private String fos_meritsjurisdictiondismissal_txt;
	private String fos_meritopinion;
	private String fos_meritopinion_txt;
	private String fos_jurisdictioninout;
	private String fos_jurisdictioninout_txt;
	private String fos_dismissalreason;
	private String fos_withopinion;
	private String fos_changeinoutcome;
	private String fos_changeinoutcome_txt;
	private String _fos_settlementbandid_value;
	private String _fos_settlementbandid_value_txt;
	private String fos_nonmonetarysettlement;
	private String fos_troubleupsetamt;
	private String fos_complainantresponse;
	private String fos_complainantresponse_txt;
	private String fos_respondentresponse;
	private String fos_respondentresponse_txt;
	private String outcomedate;
	private String user_comments;
	private String  acceptReject;
	
	public String get_fos_case_value() {
		return _fos_case_value;
	}
	public void set_fos_case_value(String _fos_case_value) {
		this._fos_case_value = _fos_case_value;
	}
	public String getFos_offeroroutcomeid() {
		return fos_offeroroutcomeid;
	}
	public void setFos_offeroroutcomeid(String fos_offeroroutcomeid) {
		this.fos_offeroroutcomeid = fos_offeroroutcomeid;
	}
	public String getFos_type() {
		return fos_type;
	}
	public void setFos_type(String fos_type) {
		this.fos_type = fos_type;
	}
	public String getFos_meritopinion() {
		return fos_meritopinion;
	}
	public void setFos_meritopinion(String fos_meritopinion) {
		this.fos_meritopinion = fos_meritopinion;
	}
	public String getFos_jurisdictioninout() {
		return fos_jurisdictioninout;
	}
	public void setFos_jurisdictioninout(String fos_jurisdictioninout) {
		this.fos_jurisdictioninout = fos_jurisdictioninout;
	}
	public String getFos_dismissalreason() {
		return fos_dismissalreason;
	}
	public void setFos_dismissalreason(String fos_dismissalreason) {
		this.fos_dismissalreason = fos_dismissalreason;
	}
	public String getFos_withopinion() {
		return fos_withopinion;
	}
	public void setFos_withopinion(String fos_withopinion) {
		this.fos_withopinion = fos_withopinion;
	}
	public String getFos_changeinoutcome() {
		return fos_changeinoutcome;
	}
	public void setFos_changeinoutcome(String fos_changeinoutcome) {
		this.fos_changeinoutcome = fos_changeinoutcome;
	}
	public String get_fos_settlementbandid_value() {
		return _fos_settlementbandid_value;
	}
	public void set_fos_settlementbandid_value(String _fos_settlementbandid_value) {
		this._fos_settlementbandid_value = _fos_settlementbandid_value;
	}
	public String get_fos_settlementbandid_value_txt() {
		return _fos_settlementbandid_value_txt;
	}
	public void set_fos_settlementbandid_value_txt(String _fos_settlementbandid_value_txt) {
		this._fos_settlementbandid_value_txt = _fos_settlementbandid_value_txt;
	}
	public String getFos_nonmonetarysettlement() {
		return fos_nonmonetarysettlement;
	}
	public void setFos_nonmonetarysettlement(String fos_nonmonetarysettlement) {
		this.fos_nonmonetarysettlement = fos_nonmonetarysettlement;
	}
	public String getFos_troubleupsetamt() {
		return fos_troubleupsetamt;
	}
	public void setFos_troubleupsetamt(String fos_troubleupsetamt) {
		this.fos_troubleupsetamt = fos_troubleupsetamt;
	}
	public String getFos_complainantresponse() {
		return fos_complainantresponse;
	}
	public void setFos_complainantresponse(String fos_complainantresponse) {
		this.fos_complainantresponse = fos_complainantresponse;
	}
	public String getFos_complainantresponse_txt() {
		return fos_complainantresponse_txt;
	}
	public void setFos_complainantresponse_txt(String fos_complainantresponse_txt) {
		this.fos_complainantresponse_txt = fos_complainantresponse_txt;
	}
	public String getFos_respondentresponse() {
		return fos_respondentresponse;
	}
	public void setFos_respondentresponse(String fos_respondentresponse) {
		this.fos_respondentresponse = fos_respondentresponse;
	}
	public String getFos_respondentresponse_txt() {
		return fos_respondentresponse_txt;
	}
	public void setFos_respondentresponse_txt(String fos_respondentresponse_txt) {
		this.fos_respondentresponse_txt = fos_respondentresponse_txt;
	}
	public String getOutcomedate() {
		return outcomedate;
	}
	public void setOutcomedate(String outcomedate) {
		this.outcomedate = outcomedate;
	}
	public String getFos_type_txt() {
		return fos_type_txt;
	}
	public void setFos_type_txt(String fos_type_txt) {
		this.fos_type_txt = fos_type_txt;
	}
	public String getFos_meritsjurisdictiondismissal() {
		return fos_meritsjurisdictiondismissal;
	}
	public void setFos_meritsjurisdictiondismissal(String fos_meritsjurisdictiondismissal) {
		this.fos_meritsjurisdictiondismissal = fos_meritsjurisdictiondismissal;
	}
	public String getFos_meritsjurisdictiondismissal_txt() {
		return fos_meritsjurisdictiondismissal_txt;
	}
	public void setFos_meritsjurisdictiondismissal_txt(String fos_meritsjurisdictiondismissal_txt) {
		this.fos_meritsjurisdictiondismissal_txt = fos_meritsjurisdictiondismissal_txt;
	}
	public String getFos_meritopinion_txt() {
		return fos_meritopinion_txt;
	}
	public void setFos_meritopinion_txt(String fos_meritopinion_txt) {
		this.fos_meritopinion_txt = fos_meritopinion_txt;
	}
	public String getFos_jurisdictioninout_txt() {
		return fos_jurisdictioninout_txt;
	}
	public void setFos_jurisdictioninout_txt(String fos_jurisdictioninout_txt) {
		this.fos_jurisdictioninout_txt = fos_jurisdictioninout_txt;
	}
	public String getFos_changeinoutcome_txt() {
		return fos_changeinoutcome_txt;
	}
	public void setFos_changeinoutcome_txt(String fos_changeinoutcome_txt) {
		this.fos_changeinoutcome_txt = fos_changeinoutcome_txt;
	}
	public String getUser_comments() {
		return user_comments;
	}
	public void setUser_comments(String user_comments) {
		this.user_comments = user_comments;
	}
	public String getAcceptReject() {
		return acceptReject;
	}
	public void setAcceptReject(String acceptReject) {
		this.acceptReject = acceptReject;
	}
	

}
