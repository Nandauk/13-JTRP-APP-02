package com.ombudsman.service.complainant.model.response;

import java.util.List;

import com.ombudsman.service.complainant.model.CaseDocumentDetail;

public class CaseDocumentFrDownloadRes  extends GenericResponse{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private CaseDocumentDetail[] files;

	public CaseDocumentDetail[] getFiles() {
		return files;
	}

	public void setFiles(CaseDocumentDetail[] files) {
		this.files = files;
	}




}
