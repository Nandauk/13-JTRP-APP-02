package com.ombudsman.service.complainant.model.dto;

import java.io.Serializable;

public class CaseDetailDto implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	
	private String incidentid; //Primary Key
	private String title;
	private String ticketnumber;
	private String fos_crn; //Migrated Reference - incident
	private String fos_complaintissue;
	private String fos_complaintissuename;
	private String fos_productorproductfamily;
	private String fos_productorproductfamilyname;
	private String fos_casestage;
	private String fos_casestagename;
	private String statuscode;
	private String statuscodename;
	private String caseage;
	private String fos_representatives;
	private String fos_datecasefirstmovedtoinvestigation;
	private String fos_datebusinessfilereceived;
	private String fos_prioritycode;
	private String fos_prioritycodename;
	private String statecode;
	private String fos_caseprogress;
	private String fos_caseprogress_name;
	private String customerid;
	private String customeridname;
	private String fos_dateofconversion;
	private String fos_dateofreferral;
	private String ownerid;
	private String contactid;
	public String getIncidentid() {
		return incidentid;
	}
	public void setIncidentid(String incidentid) {
		this.incidentid = incidentid;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getTicketnumber() {
		return ticketnumber;
	}
	public void setTicketnumber(String ticketnumber) {
		this.ticketnumber = ticketnumber;
	}
	public String getFos_crn() {
		return fos_crn;
	}
	public void setFos_crn(String fos_crn) {
		this.fos_crn = fos_crn;
	}
	public String getFos_complaintissue() {
		return fos_complaintissue;
	}
	public void setFos_complaintissue(String fos_complaintissue) {
		this.fos_complaintissue = fos_complaintissue;
	}
	public String getFos_complaintissuename() {
		return fos_complaintissuename;
	}
	public void setFos_complaintissuename(String fos_complaintissuename) {
		this.fos_complaintissuename = fos_complaintissuename;
	}
	public String getFos_productorproductfamily() {
		return fos_productorproductfamily;
	}
	public void setFos_productorproductfamily(String fos_productorproductfamily) {
		this.fos_productorproductfamily = fos_productorproductfamily;
	}
	public String getFos_productorproductfamilyname() {
		return fos_productorproductfamilyname;
	}
	public void setFos_productorproductfamilyname(String fos_productorproductfamilyname) {
		this.fos_productorproductfamilyname = fos_productorproductfamilyname;
	}
	public String getFos_casestage() {
		return fos_casestage;
	}
	public void setFos_casestage(String fos_casestage) {
		this.fos_casestage = fos_casestage;
	}
	public String getFos_casestagename() {
		return fos_casestagename;
	}
	public void setFos_casestagename(String fos_casestagename) {
		this.fos_casestagename = fos_casestagename;
	}
	public String getStatuscode() {
		return statuscode;
	}
	public void setStatuscode(String statuscode) {
		this.statuscode = statuscode;
	}
	public String getStatuscodename() {
		return statuscodename;
	}
	public void setStatuscodename(String statuscodename) {
		this.statuscodename = statuscodename;
	}
	public String getCaseage() {
		return caseage;
	}
	public void setCaseage(String caseage) {
		this.caseage = caseage;
	}
	public String getFos_representatives() {
		return fos_representatives;
	}
	public void setFos_representatives(String fos_representatives) {
		this.fos_representatives = fos_representatives;
	}
	public String getFos_datecasefirstmovedtoinvestigation() {
		return fos_datecasefirstmovedtoinvestigation;
	}
	public void setFos_datecasefirstmovedtoinvestigation(String fos_datecasefirstmovedtoinvestigation) {
		this.fos_datecasefirstmovedtoinvestigation = fos_datecasefirstmovedtoinvestigation;
	}
	public String getFos_datebusinessfilereceived() {
		return fos_datebusinessfilereceived;
	}
	public void setFos_datebusinessfilereceived(String fos_datebusinessfilereceived) {
		this.fos_datebusinessfilereceived = fos_datebusinessfilereceived;
	}
	public String getFos_prioritycode() {
		return fos_prioritycode;
	}
	public void setFos_prioritycode(String fos_prioritycode) {
		this.fos_prioritycode = fos_prioritycode;
	}
	public String getFos_prioritycodename() {
		return fos_prioritycodename;
	}
	public void setFos_prioritycodename(String fos_prioritycodename) {
		this.fos_prioritycodename = fos_prioritycodename;
	}
	public String getStatecode() {
		return statecode;
	}
	public void setStatecode(String statecode) {
		this.statecode = statecode;
	}
	public String getFos_caseprogress() {
		return fos_caseprogress;
	}
	public void setFos_caseprogress(String fos_caseprogress) {
		this.fos_caseprogress = fos_caseprogress;
	}
	public String getFos_caseprogress_name() {
		return fos_caseprogress_name;
	}
	public void setFos_caseprogress_name(String fos_caseprogress_name) {
		this.fos_caseprogress_name = fos_caseprogress_name;
	}
	public String getCustomeridname() {
		return customeridname;
	}
	public void setCustomeridname(String customeridname) {
		this.customeridname = customeridname;
	}
	public String getFos_dateofconversion() {
		return fos_dateofconversion;
	}
	public void setFos_dateofconversion(String fos_dateofconversion) {
		this.fos_dateofconversion = fos_dateofconversion;
	}
	public String getFos_dateofreferral() {
		return fos_dateofreferral;
	}
	public void setFos_dateofreferral(String fos_dateofreferral) {
		this.fos_dateofreferral = fos_dateofreferral;
	}
	public String getCustomerid() {
		return customerid;
	}
	public void setCustomerid(String customerid) {
		this.customerid = customerid;
	}
	public String getOwnerid() {
		return ownerid;
	}
	public void setOwnerid(String ownerid) {
		this.ownerid = ownerid;
	}
	public String getContactid() {
		return contactid;
	}
	public void setContactid(String contactid) {
		this.contactid = contactid;
	}

	

}
