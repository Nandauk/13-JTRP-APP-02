package com.ombudsman.service.complainant.serviceimpl;

import static com.ombudsman.service.complainant.common.Constants.INCIDENTID_IS_A_VALID_FIELD;

import java.util.List;
import java.util.Map;

import javax.security.auth.login.AccountNotFoundException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ombudsman.service.complainant.common.UserBean;
import com.ombudsman.service.complainant.exception.InvalidOrganisationException;
import com.ombudsman.service.complainant.exception.SQLDataAccessException;
import com.ombudsman.service.complainant.model.response.CaseCountRes;
import com.ombudsman.service.complainant.repository.dao.CaseDetailsDao;
import com.ombudsman.service.complainant.service.CaseCountService;
@Service
public class CaseCountServiceimpl implements CaseCountService{
	
	private static final Logger log = LogManager.getRootLogger();
	
	private static final String RESULT_SET_1 = "#result-set-1";

	UserBean userbean;
	
	CaseDetailsDao caseDetailsDao;

	@Autowired
	public CaseCountServiceimpl(UserBean userbean, CaseDetailsDao caseDetailsDao) {
		super();
		this.userbean = userbean;
		this.caseDetailsDao = caseDetailsDao;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public CaseCountRes getCaseCount()
            throws SQLDataAccessException, AccountNotFoundException, InvalidOrganisationException
            {
		        log.debug("getCaseCount Service Method Started.CorrelationId:-{}", userbean.getCorrelationId());
				CaseCountRes response = new CaseCountRes();
				List<Object> caseCountRes = null;
					log.debug(INCIDENTID_IS_A_VALID_FIELD);

						log.debug("Organisation list is not empty.CorrelationId:-{} OID:-{}", userbean.getCorrelationId(),
								userbean.getUserObjectId());

						log.info("user oid :::::::: {}",userbean.getUserObjectId());
						
						Map<String, Object> caseCountDtl = caseDetailsDao
									.getCaseCountFrUser(userbean.getUserObjectId(),userbean.getRoles().get(0));
						
						if (null != caseCountDtl.get(RESULT_SET_1) && null != caseCountDtl.get(RESULT_SET_1)) {
							caseCountRes = (List<Object>) caseCountDtl.get(RESULT_SET_1);

						}

							if (null !=(caseCountRes) &&  !caseCountRes.isEmpty())
							{
								final Map<String, String> caseCount = (Map<String, String>) caseCountRes.get(0);
								response.setNumberOfCases(String.valueOf(caseCount.get("totalcases")));
								response.setIncidentId(String.valueOf(caseCount.get("caseReference")));
								response.setMessage("SUCCESS");
								response.setStatus("OK");
								
								if(response.getNumberOfCases().compareTo("0")==0)
								{
									response.setMessage("No Cases Tagged to the User");
									response.setStatus("OK");
								}
							}
							else
							{
								response.setMessage("No Cases Tagged to the User");
								response.setStatus("OK");
							}

				return response;
            }

}
