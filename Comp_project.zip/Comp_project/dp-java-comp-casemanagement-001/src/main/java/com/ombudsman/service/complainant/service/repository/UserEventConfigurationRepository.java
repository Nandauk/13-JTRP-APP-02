package com.ombudsman.service.complainant.service.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.ombudsman.service.complainant.model.dto.UserEventConfiguration;

@Repository
public interface UserEventConfigurationRepository extends JpaRepository<UserEventConfiguration, Integer> {


	@Query(value = "SELECT * FROM dp_complainant_user_event_configuration WHERE user_event_name=:user_event_name", nativeQuery = true)
	UserEventConfiguration getUserEventRecord(@Param("user_event_name") String userEventName);

}
