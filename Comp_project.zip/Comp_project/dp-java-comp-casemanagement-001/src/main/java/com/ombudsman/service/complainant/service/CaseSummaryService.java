package com.ombudsman.service.complainant.service;

import java.io.IOException;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ombudsman.service.complainant.exception.AzureServiceException;
import com.ombudsman.service.complainant.exception.CaseDetailsNotFoundException;
import com.ombudsman.service.complainant.exception.SQLDataAccessException;
import com.ombudsman.service.complainant.model.request.CaseDetailsByIdReq;
import com.ombudsman.service.complainant.model.response.CaseSummaryRes;

public interface CaseSummaryService {
	
	public CaseSummaryRes getCaseSummary(CaseDetailsByIdReq request) throws AzureServiceException, JsonProcessingException,IOException, SQLDataAccessException, CaseDetailsNotFoundException;
	
}
