/**
 * 
 */
package com.ombudsman.service.complainant.common;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Service;



@Configuration
@Service
public class CommonUtil {

	
	@Autowired
	UserBean userbean;

	
	@Value("${app.resp_admin_custom_msg_body}")
	public String RESP_ADMIN_CUSTOM_MSG_BODY;

	@Value("${app.session_base_url}")
	public String SESSION_BASE_URL;
	
	@Value("${app.session_flag}")
	public String sessionFlag;
	
	@Value("${xApiKey}")
	public String xApiKey;

	//code fix for Bug-4795 start
	@Value("${app.resp_help_link_body}")
	public String RESP_HELP_LINK_BODY;
	@Value("${app.resp_invitation_body}")
	public String RESP_INVITATION_BODY;
	//code fix for Bug-4795 end
	

	


	
	public  boolean isValidEmailInput(String input) {
		String regex = "^[a-zA-Z0-9-@.+]+$";
		Pattern pattern = Pattern.compile(regex);
		Matcher matcher = pattern.matcher(input);
		return matcher.matches();
	}
	
	public boolean isValidInput(String input) {
		String regex = "^[a-zA-Z0-9-]+$";
		Pattern pattern = Pattern.compile(regex);
		Matcher matcher = pattern.matcher(input);
		return matcher.matches();
	}
	public boolean isValidNameInput(String input) {
		String regex = "^[a-zA-Z_-]+$";
		Pattern pattern = Pattern.compile(regex);
		Matcher matcher = pattern.matcher(input);
		return matcher.matches();
	}
	
}
