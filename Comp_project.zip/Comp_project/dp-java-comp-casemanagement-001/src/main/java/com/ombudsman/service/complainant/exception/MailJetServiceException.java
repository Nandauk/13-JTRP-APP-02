package com.ombudsman.service.complainant.exception;

public class MailJetServiceException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	

	public MailJetServiceException(String message) {
		super(message);
	}
	

}
