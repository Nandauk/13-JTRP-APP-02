package com.ombudsman.service.complainant.service;

import com.ombudsman.service.complainant.model.response.GenericResponse;

public interface ILoginService {	
	public GenericResponse addUserSessionEntry();
	GenericResponse logoutForUserSession() ;
	GenericResponse getSessionTokenStatus() ;

}
