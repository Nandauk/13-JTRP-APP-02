package com.ombudsman.service.complainant.model;

import java.math.BigDecimal;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.transaction.Transactional;

@Entity
@Table(name = "offeroutcome")
@Transactional
public class OfferOutcome {
	
	@Id
	@GeneratedValue(strategy = GenerationType.UUID)
	@Column(name = "fos_offeroroutcomeid")
	private String fosofferoroutcomeId;
	@Column(name = "statecode")
	private Long stateCode; // notnull
	@Column(name = "statuscode")
	private Long statusCode; // notnull
	@Column(name = "fos_caseresolution")
	private Long fosCaseresolution; // notnull
	@Column(name = "fos_changeinoutcome")
	private Long fosChangeinoutcome; // notnull
	@Column(name = "fos_complainantresponse")
	private Long fosComplainantresponse;
	@Column(name = "fosConsumerdutyoutcome")
	private Long fos_consumerdutyoutcome;
	@Column(name = "fos_decisioncausedby")
	private Long fosDecisioncausedby; // notnull
	@Column(name = "fos_dismissalreason")
	private Long fosDismissalreason; // notnull
	@Column(name = "fos_dispatchstatuscode")
	private Long fosDispatchstatuscode; // notnull
	@Column(name = "fos_howwasthiscaseresolved")
	private Long fosHowwasthiscaseresolved; // notnull
	@Column(name = "fos_jurisdictioninout")
	private Long fosJurisdictioninout; // notnull
	@Column(name = "fos_jurisdictionreason")
	private Long fosJurisdictionreason;
	@Column(name = "fos_meritopinion")
	private Long fosMeritopinion;
	@Column(name = "fos_meritsjurisdictiondismissal")
	private Long fosMeritsjurisdictiondismissal; // notnull
	@Column(name = "fos_respondentresponse")
	private Long fosRespondentresponse; // notnull
	
	@Column(name = "fos_type")
	private Long fosType; // notnull
	@Column(name = "fos_wherehavewereferredthecomplaintto")
	private Long fosWherehavewereferredthecomplaintto; // notnull
	@Column(name = "fos_withdrawalreason")
	private Long fosWithdrawalreason; // notnull
	@Column(name = "fos_withopinion")
	private Long fosWithopinion; // notnull
	@Column(name = "fos_jurisdiction")
	private Boolean fosJurisdiction;
	@Column(name = "fos_outcomedispatched")
	private Boolean fosOutcomedispatched;
	@Column(name = "fos_provisionaldecision")
	private Boolean fosProvisionaldecision; // notnull
	@Column(name = "fos_senttocomplainant")
	private Boolean fosSenttocomplainant; // notnull
	@Column(name = "fos_senttorespondent")
	private Boolean fosSenttorespondent; // notnull
	@Column(name = "fos_case")
	private String fosCase; // notnull
	@Column(name = "fos_outcomedispatchedby")
	private String fosOutcomedispatchedby; // notnull
	@Column(name = "fos_settlementbandid")
	private String fosSettlementbandId;
	@Column(name = "fos_settlementamount")
	private BigDecimal fosSettlementamount;
	@Column(name = "fos_troubleupsetamt")
	private BigDecimal fosTroubleupsetamt; // notnull
	@Column(name = "fos_changeinoutcomename")
	private String fosChangeinoutcomename; // notnull


	@Column(name = "fos_complainantresponsename")
	private String fosComplainantresponsename; // notnull
	@Column(name = "fos_meritsjurisdictiondismissalname")
	private String fosMeritsjurisdictiondismissalname; // notnull
	@Column(name = "fos_decisionreferencenumber")
	private String fosDecisionreferencenumber; // notnull
	@Column(name = "fos_nonmonetarysettlement")
	private String fosNonmonetarysettlement; // notnull
	@Column(name = "fos_offerdate")
	private String fosOfferdate;
	@Column(name = "fos_othercomplaintbody")
	private String fosOthercomplaintbody;
	@Column(name = "fos_outcomedispatcheddate")
	private String fosOutcomedispatcheddate; // notnull
	@Column(name = "fos_resolutiondate")
	private String fosResolutiondate; // notnull
	@Column(name = "fos_settlementbandidname")
	private String fosSettlementbandidname; // notnull
	@Column(name = "fos_jurisdictioninoutname")
	private Integer fosJurisdictioninoutname; // notnull
	@Column(name = "fos_meritopinionname")
	private String fosMeritopinionname; // notnull
	@Column(name = "fos_typename")
	private String fosTypename;
	@Column(name = "versionnumber")
	private Long versionNumber;
	@Column(name = "incrementaldataloadjobauditid")
	private String incrementaldataloadjobauditId; // notnull
	@Column(name = "dprecordcreatedon")
	private String dpRecordcreatedon; // notnull

	@Column(name = "dprecordmodifiedon")
	private String dpRecordmodifiedon;
	@Column(name = "fos_respondentresponse_txt")
	private String fosRespondentresponse_txt;
	@Column(name = "modifiedbyloadon")
	private String modifiedbyLoadon; // notnull
	
	
	@Column(name = "created_on")
	private String createdOn; // notnull
	@Column(name = "created_by")
	private String createdBy; // notnull
	@Column(name = "modified_on")
	private String modifiedOn;
	@Column(name = "modified_by")
	private String modifiedBy;
	public String getFosofferoroutcomeId() {
		return fosofferoroutcomeId;
	}
	public void setFosofferoroutcomeId(String fosofferoroutcomeId) {
		this.fosofferoroutcomeId = fosofferoroutcomeId;
	}
	public Long getStateCode() {
		return stateCode;
	}
	public void setStateCode(Long stateCode) {
		this.stateCode = stateCode;
	}
	public Long getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(Long statusCode) {
		this.statusCode = statusCode;
	}
	public Long getFosCaseresolution() {
		return fosCaseresolution;
	}
	public void setFosCaseresolution(Long fosCaseresolution) {
		this.fosCaseresolution = fosCaseresolution;
	}
	public Long getFosChangeinoutcome() {
		return fosChangeinoutcome;
	}
	public void setFosChangeinoutcome(Long fosChangeinoutcome) {
		this.fosChangeinoutcome = fosChangeinoutcome;
	}
	public Long getFosComplainantresponse() {
		return fosComplainantresponse;
	}
	public void setFosComplainantresponse(Long fosComplainantresponse) {
		this.fosComplainantresponse = fosComplainantresponse;
	}
	public Long getFos_consumerdutyoutcome() {
		return fos_consumerdutyoutcome;
	}
	public void setFos_consumerdutyoutcome(Long fos_consumerdutyoutcome) {
		this.fos_consumerdutyoutcome = fos_consumerdutyoutcome;
	}
	public Long getFosDecisioncausedby() {
		return fosDecisioncausedby;
	}
	public void setFosDecisioncausedby(Long fosDecisioncausedby) {
		this.fosDecisioncausedby = fosDecisioncausedby;
	}
	public Long getFosDismissalreason() {
		return fosDismissalreason;
	}
	public void setFosDismissalreason(Long fosDismissalreason) {
		this.fosDismissalreason = fosDismissalreason;
	}
	public Long getFosDispatchstatuscode() {
		return fosDispatchstatuscode;
	}
	public void setFosDispatchstatuscode(Long fosDispatchstatuscode) {
		this.fosDispatchstatuscode = fosDispatchstatuscode;
	}
	public Long getFosHowwasthiscaseresolved() {
		return fosHowwasthiscaseresolved;
	}
	public void setFosHowwasthiscaseresolved(Long fosHowwasthiscaseresolved) {
		this.fosHowwasthiscaseresolved = fosHowwasthiscaseresolved;
	}
	public Long getFosJurisdictioninout() {
		return fosJurisdictioninout;
	}
	public void setFosJurisdictioninout(Long fosJurisdictioninout) {
		this.fosJurisdictioninout = fosJurisdictioninout;
	}
	public Long getFosJurisdictionreason() {
		return fosJurisdictionreason;
	}
	public void setFosJurisdictionreason(Long fosJurisdictionreason) {
		this.fosJurisdictionreason = fosJurisdictionreason;
	}
	public Long getFosMeritopinion() {
		return fosMeritopinion;
	}
	public void setFosMeritopinion(Long fosMeritopinion) {
		this.fosMeritopinion = fosMeritopinion;
	}
	public Long getFosMeritsjurisdictiondismissal() {
		return fosMeritsjurisdictiondismissal;
	}
	public void setFosMeritsjurisdictiondismissal(Long fosMeritsjurisdictiondismissal) {
		this.fosMeritsjurisdictiondismissal = fosMeritsjurisdictiondismissal;
	}
	public Long getFosRespondentresponse() {
		return fosRespondentresponse;
	}
	public void setFosRespondentresponse(Long fosRespondentresponse) {
		this.fosRespondentresponse = fosRespondentresponse;
	}
	public Long getFosType() {
		return fosType;
	}
	public void setFosType(Long fosType) {
		this.fosType = fosType;
	}
	public Long getFosWherehavewereferredthecomplaintto() {
		return fosWherehavewereferredthecomplaintto;
	}
	public void setFosWherehavewereferredthecomplaintto(Long fosWherehavewereferredthecomplaintto) {
		this.fosWherehavewereferredthecomplaintto = fosWherehavewereferredthecomplaintto;
	}
	public Long getFosWithdrawalreason() {
		return fosWithdrawalreason;
	}
	public void setFosWithdrawalreason(Long fosWithdrawalreason) {
		this.fosWithdrawalreason = fosWithdrawalreason;
	}
	public Long getFosWithopinion() {
		return fosWithopinion;
	}
	public void setFosWithopinion(Long fosWithopinion) {
		this.fosWithopinion = fosWithopinion;
	}
	public Boolean getFosJurisdiction() {
		return fosJurisdiction;
	}
	public void setFosJurisdiction(Boolean fosJurisdiction) {
		this.fosJurisdiction = fosJurisdiction;
	}
	public Boolean getFosOutcomedispatched() {
		return fosOutcomedispatched;
	}
	public void setFosOutcomedispatched(Boolean fosOutcomedispatched) {
		this.fosOutcomedispatched = fosOutcomedispatched;
	}
	public Boolean getFosProvisionaldecision() {
		return fosProvisionaldecision;
	}
	public void setFosProvisionaldecision(Boolean fosProvisionaldecision) {
		this.fosProvisionaldecision = fosProvisionaldecision;
	}
	public Boolean getFosSenttocomplainant() {
		return fosSenttocomplainant;
	}
	public void setFosSenttocomplainant(Boolean fosSenttocomplainant) {
		this.fosSenttocomplainant = fosSenttocomplainant;
	}
	public Boolean getFosSenttorespondent() {
		return fosSenttorespondent;
	}
	public void setFosSenttorespondent(Boolean fosSenttorespondent) {
		this.fosSenttorespondent = fosSenttorespondent;
	}
	public String getFosCase() {
		return fosCase;
	}
	public void setFosCase(String fosCase) {
		this.fosCase = fosCase;
	}
	public String getFosOutcomedispatchedby() {
		return fosOutcomedispatchedby;
	}
	public void setFosOutcomedispatchedby(String fosOutcomedispatchedby) {
		this.fosOutcomedispatchedby = fosOutcomedispatchedby;
	}
	public String getFosSettlementbandId() {
		return fosSettlementbandId;
	}
	public void setFosSettlementbandId(String fosSettlementbandId) {
		this.fosSettlementbandId = fosSettlementbandId;
	}
	public BigDecimal getFosSettlementamount() {
		return fosSettlementamount;
	}
	public void setFosSettlementamount(BigDecimal fosSettlementamount) {
		this.fosSettlementamount = fosSettlementamount;
	}
	public BigDecimal getFosTroubleupsetamt() {
		return fosTroubleupsetamt;
	}
	public void setFosTroubleupsetamt(BigDecimal fosTroubleupsetamt) {
		this.fosTroubleupsetamt = fosTroubleupsetamt;
	}
	public String getFosChangeinoutcomename() {
		return fosChangeinoutcomename;
	}
	public void setFosChangeinoutcomename(String fosChangeinoutcomename) {
		this.fosChangeinoutcomename = fosChangeinoutcomename;
	}
	public String getFosComplainantresponsename() {
		return fosComplainantresponsename;
	}
	public void setFosComplainantresponsename(String fosComplainantresponsename) {
		this.fosComplainantresponsename = fosComplainantresponsename;
	}
	public String getFosMeritsjurisdictiondismissalname() {
		return fosMeritsjurisdictiondismissalname;
	}
	public void setFosMeritsjurisdictiondismissalname(String fosMeritsjurisdictiondismissalname) {
		this.fosMeritsjurisdictiondismissalname = fosMeritsjurisdictiondismissalname;
	}
	public String getFosDecisionreferencenumber() {
		return fosDecisionreferencenumber;
	}
	public void setFosDecisionreferencenumber(String fosDecisionreferencenumber) {
		this.fosDecisionreferencenumber = fosDecisionreferencenumber;
	}
	public String getFosNonmonetarysettlement() {
		return fosNonmonetarysettlement;
	}
	public void setFosNonmonetarysettlement(String fosNonmonetarysettlement) {
		this.fosNonmonetarysettlement = fosNonmonetarysettlement;
	}
	public String getFosOfferdate() {
		return fosOfferdate;
	}
	public void setFosOfferdate(String fosOfferdate) {
		this.fosOfferdate = fosOfferdate;
	}
	public String getFosOthercomplaintbody() {
		return fosOthercomplaintbody;
	}
	public void setFosOthercomplaintbody(String fosOthercomplaintbody) {
		this.fosOthercomplaintbody = fosOthercomplaintbody;
	}
	public String getFosOutcomedispatcheddate() {
		return fosOutcomedispatcheddate;
	}
	public void setFosOutcomedispatcheddate(String fosOutcomedispatcheddate) {
		this.fosOutcomedispatcheddate = fosOutcomedispatcheddate;
	}
	public String getFosResolutiondate() {
		return fosResolutiondate;
	}
	public void setFosResolutiondate(String fosResolutiondate) {
		this.fosResolutiondate = fosResolutiondate;
	}
	public String getFosSettlementbandidname() {
		return fosSettlementbandidname;
	}
	public void setFosSettlementbandidname(String fosSettlementbandidname) {
		this.fosSettlementbandidname = fosSettlementbandidname;
	}
	public Integer getFosJurisdictioninoutname() {
		return fosJurisdictioninoutname;
	}
	public void setFosJurisdictioninoutname(Integer fosJurisdictioninoutname) {
		this.fosJurisdictioninoutname = fosJurisdictioninoutname;
	}
	public String getFosMeritopinionname() {
		return fosMeritopinionname;
	}
	public void setFosMeritopinionname(String fosMeritopinionname) {
		this.fosMeritopinionname = fosMeritopinionname;
	}
	public String getFosTypename() {
		return fosTypename;
	}
	public void setFosTypename(String fosTypename) {
		this.fosTypename = fosTypename;
	}
	public Long getVersionNumber() {
		return versionNumber;
	}
	public void setVersionNumber(Long versionNumber) {
		this.versionNumber = versionNumber;
	}
	public String getIncrementaldataloadjobauditId() {
		return incrementaldataloadjobauditId;
	}
	public void setIncrementaldataloadjobauditId(String incrementaldataloadjobauditId) {
		this.incrementaldataloadjobauditId = incrementaldataloadjobauditId;
	}
	public String getDpRecordcreatedon() {
		return dpRecordcreatedon;
	}
	public void setDpRecordcreatedon(String dpRecordcreatedon) {
		this.dpRecordcreatedon = dpRecordcreatedon;
	}
	public String getDpRecordmodifiedon() {
		return dpRecordmodifiedon;
	}
	public void setDpRecordmodifiedon(String dpRecordmodifiedon) {
		this.dpRecordmodifiedon = dpRecordmodifiedon;
	}
	public String getFosRespondentresponse_txt() {
		return fosRespondentresponse_txt;
	}
	public void setFosRespondentresponse_txt(String fosRespondentresponse_txt) {
		this.fosRespondentresponse_txt = fosRespondentresponse_txt;
	}
	public String getModifiedbyLoadon() {
		return modifiedbyLoadon;
	}
	public void setModifiedbyLoadon(String modifiedbyLoadon) {
		this.modifiedbyLoadon = modifiedbyLoadon;
	}
	public String getCreatedOn() {
		return createdOn;
	}
	public void setCreatedOn(String createdOn) {
		this.createdOn = createdOn;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public String getModifiedOn() {
		return modifiedOn;
	}
	public void setModifiedOn(String modifiedOn) {
		this.modifiedOn = modifiedOn;
	}
	public String getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	
	
	
	

}
