package com.ombudsman.service.complainant.common;


import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import java.time.temporal.ChronoField;

import com.fasterxml.jackson.core.JacksonException;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.deser.std.StdDeserializer;

public class CustomLocalDateTimeDeserializer extends StdDeserializer<LocalDateTime> {

	private static final DateTimeFormatter formatter=new DateTimeFormatterBuilder()
			.appendPattern("yyyy-MM-dd'T'HH:mm:ss")
			.optionalStart()
			.appendFraction(ChronoField.NANO_OF_SECOND, 0, 9, true)
			.optionalEnd()
			.toFormatter();


	public CustomLocalDateTimeDeserializer()
	{
		this(null);
	}

	public CustomLocalDateTimeDeserializer(Class<?> vc) {
		super(vc);
	}

	@Override
	public LocalDateTime deserialize(JsonParser p, DeserializationContext ctxt) throws IOException, JacksonException {
		String date=p.getText();
		if(date==null|| date.trim().isEmpty())
		{
			return null;
		}
		try {
			return LocalDateTime.parse(date,formatter);
		}
		catch (Exception e) {
			throw new IOException("Failed to parsedate");
		}
	}
}

