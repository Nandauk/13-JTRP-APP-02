package com.ombudsman.service.complainant.model.response;

import java.util.List;

import com.ombudsman.service.complainant.model.CaseOutcome;

public class CaseOutcomeByIdRes extends GenericResponse{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String messageCode;
	private String fosresponsetobereceivedby;
	private transient List<CaseOutcome> caseoutcomes;
	
	public List<CaseOutcome> getCaseoutcomes() {
		return caseoutcomes;
	}
	public void setCaseoutcomes(List<CaseOutcome> caseoutcomes) {
		this.caseoutcomes = caseoutcomes;
	}
	public String getMessageCode() {
		return messageCode;
	}
	public void setMessageCode(String messageCode) {
		this.messageCode = messageCode;
	}
	public String getFosresponsetobereceivedby() {
		return fosresponsetobereceivedby;
	}
	public void setFosresponsetobereceivedby(String fosresponsetobereceivedby) {
		this.fosresponsetobereceivedby = fosresponsetobereceivedby;
	}

}
