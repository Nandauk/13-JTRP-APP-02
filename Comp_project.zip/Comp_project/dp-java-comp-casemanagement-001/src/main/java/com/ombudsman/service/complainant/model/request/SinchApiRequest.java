package com.ombudsman.service.complainant.model.request;

import java.util.List;

public class SinchApiRequest {

	private List<String>to;
	private String body;
	
	public List<String> getTo() {
		return to;
	}
	public void setTo(List<String> to) {
		this.to = to;
	}
	public String getBody() {
		return body;
	}
	public void setBody(String body) {
		this.body = body;
	}
	
	
}
