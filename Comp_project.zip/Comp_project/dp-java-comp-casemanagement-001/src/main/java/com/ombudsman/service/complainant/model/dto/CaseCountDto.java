package com.ombudsman.service.complainant.model.dto;

public class CaseCountDto {

	public int caseCount;

	public int getCaseCount() {
		return caseCount;
	}

	public void setCaseCount(int caseCount) {
		this.caseCount = caseCount;
	}

	public CaseCountDto(int caseCount) {
		super();
		this.caseCount = caseCount;
	}
}
