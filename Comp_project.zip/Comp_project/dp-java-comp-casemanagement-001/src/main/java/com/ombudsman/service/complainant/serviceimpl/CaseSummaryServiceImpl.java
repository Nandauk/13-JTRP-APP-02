package com.ombudsman.service.complainant.serviceimpl;

import static com.ombudsman.service.complainant.common.Constants.CASE_DETAILS_NOT_FOUND;
import static com.ombudsman.service.complainant.common.Constants.FAILED;
import static com.ombudsman.service.complainant.common.Constants.INCIDENTID_IS_A_VALID_FIELD;
import static com.ombudsman.service.complainant.common.Constants.INCIDENTID_IS_NOT_A_VALID_FIELD;

import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ombudsman.service.complainant.common.CommonUtil;
import com.ombudsman.service.complainant.common.UserBean;
import com.ombudsman.service.complainant.exception.AzureServiceException;
import com.ombudsman.service.complainant.exception.CaseDetailsNotFoundException;
import com.ombudsman.service.complainant.exception.SQLDataAccessException;
import com.ombudsman.service.complainant.model.CaseDetail;
import com.ombudsman.service.complainant.model.CaseWorker;
import com.ombudsman.service.complainant.model.dto.CasePartyDto;
import com.ombudsman.service.complainant.model.request.CaseDetailsByIdReq;
import com.ombudsman.service.complainant.model.response.CasePartiesDetail;
import com.ombudsman.service.complainant.model.response.CaseSummaryRes;
import com.ombudsman.service.complainant.repository.dao.CaseDetailsDao;
import com.ombudsman.service.complainant.service.CaseSummaryService;

@Service
public class CaseSummaryServiceImpl implements CaseSummaryService{
	private CommonUtil commonUtil;

	UserBean userbean;

	CaseDetailsDao caseDetailsDao;

	@Autowired
	public CaseSummaryServiceImpl(UserBean userbean, CaseDetailsDao caseDetailsDao, CommonUtil commonUtil) {
		super();
		this.userbean = userbean;
		this.caseDetailsDao = caseDetailsDao;
		this.commonUtil = commonUtil;
	}

	private static final Logger log = LogManager.getRootLogger();
	private static final String USER_IS_NOT_TAGGED_WITH_ANY_ORGANISATION = "User is not tagged with any organisation.";
	private static final String RESULT_SET_1 = "#result-set-1";
	private static final String RESULT_SET_2 = "#result-set-2";

	@Override
	public CaseSummaryRes getCaseSummary(CaseDetailsByIdReq request) throws AzureServiceException,
			JsonProcessingException, IOException, SQLDataAccessException, CaseDetailsNotFoundException {

		log.debug("GetCaseDetailsById Service Method Started.CorrelationId:-{} OID:-{}", userbean.getCorrelationId(),
				userbean.getUserObjectId());
		CaseSummaryRes caseSummaryRes = new CaseSummaryRes();
		List<Object> caseDetail = null;
		List<Object> casePartyDetail = null;
		List<Object> caseOwner = null;

		try {

			// verification as per regex provided started
			if (StringUtils.isNotEmpty(request.getIncidentid()) && commonUtil.isValidInput(request.getIncidentid())) {

				log.info(INCIDENTID_IS_A_VALID_FIELD);
				log.info("Organisation list is not empty.CorrelationId:-{} OID:-{}", userbean.getCorrelationId(),
						userbean.getUserObjectId());

					final Map<String, Object> caseDetails = caseDetailsDao.getCaseDetailsById(request.getIncidentid(),userbean.getUserObjectId(),userbean.getRoles().get(0));
					log.info("Value of case Details" + caseDetails);
					caseDetail = (List<Object>) caseDetails.get(RESULT_SET_1);
					casePartyDetail = (List<Object>) caseDetails.get(RESULT_SET_2);

					final ObjectMapper mapper = new ObjectMapper();
					final List<CaseDetail> caseDtl = caseDetail.stream()
							.map(i -> mapper.convertValue(i, CaseDetail.class)).collect(Collectors.toList());

					if (CollectionUtils.isNotEmpty(caseDtl)) {
						
						final List<CasePartyDto> casePartyDtlsDto = casePartyDetail.stream()
								.map(i -> mapper.convertValue(i, CasePartyDto.class)).collect(Collectors.toList());

						List<CasePartiesDetail> partyDetails = casePartyDtlsDto.stream()
								.map(p -> new CasePartiesDetail(p.getPartyName(), p.getPartyRole())).collect(Collectors.toList());
						
						final Map<String, Object> caseWorkerDetails = caseDetailsDao
								.getCaseOwnerDetails(request.getIncidentid());

						caseOwner = (List<Object>) caseWorkerDetails.get(RESULT_SET_1);

						final List<CaseWorker> caseWorkerDtl = caseOwner.stream()
								.map(i -> mapper.convertValue(i, CaseWorker.class)).collect(Collectors.toList());
	
						caseSummaryRes.setMessage("SUCCESS");
						caseSummaryRes.setStatus("OK");
						caseSummaryRes.setCasedetails(caseDtl.get(0));
						caseSummaryRes.setCaseParties(partyDetails);
						if (CollectionUtils.isNotEmpty(caseWorkerDtl)) {
							caseSummaryRes.setCaseWorkerDtls(caseWorkerDtl.get(0));
						}
						
					} else {
						log.debug(CASE_DETAILS_NOT_FOUND);
						throw new CaseDetailsNotFoundException(CASE_DETAILS_NOT_FOUND);
					}

			} else {
				caseSummaryRes.setStatus(FAILED);
				caseSummaryRes.setMessage(INCIDENTID_IS_NOT_A_VALID_FIELD);
				log.debug(INCIDENTID_IS_NOT_A_VALID_FIELD);

			}
		} catch (SQLDataAccessException ex) {
			log.error(String.format("API error::{0}".concat(ex.getMessage())));
		}

		return caseSummaryRes;
	}

}
