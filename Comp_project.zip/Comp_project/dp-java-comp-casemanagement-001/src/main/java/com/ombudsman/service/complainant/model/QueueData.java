package com.ombudsman.service.complainant.model;

public class QueueData {
	

	    private String queueid;


	    private String description;
	    private String name;
	    private String _ownerid_value;

	    // Getters and setters
	    public String getQueueid() {
	        return queueid;
	    }

	    public void setQueueid(String queueid) {
	        this.queueid = queueid;
	    }

	    public String getDescription() {
	        return description;
	    }

	    public void setDescription(String description) {
	        this.description = description;
	    }

	    public String getName() {
	        return name;
	    }

	    public void setName(String name) {
	        this.name = name;
	    }

	    public String getOwneridValue() {
	        return _ownerid_value;
	    }

	    public void setOwneridValue(String _ownerid_value) {
	        this._ownerid_value = _ownerid_value;
	    }

	    @Override
	    public String toString() {
	        return "Queue{" +
	                "queueid='" + queueid + '\'' +
	                ", description='" + description + '\'' +
	                ", name='" + name + '\'' +
	                ", owneridValue='" + _ownerid_value + '\'' +
	                '}';
	    }

	}

