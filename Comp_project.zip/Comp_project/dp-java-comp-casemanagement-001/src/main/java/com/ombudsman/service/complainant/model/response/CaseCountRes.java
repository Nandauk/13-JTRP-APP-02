package com.ombudsman.service.complainant.model.response;

public class CaseCountRes  extends GenericResponse{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String numberOfCases;
	private String incidentId;

	public String getNumberOfCases() {
		return numberOfCases;
	}

	public void setNumberOfCases(String numberOfCases) {
		this.numberOfCases = numberOfCases;
	}

	public String getIncidentId() {
		return incidentId;
	}

	public void setIncidentId(String incidentId) {
		this.incidentId = incidentId;
	}
	
}
