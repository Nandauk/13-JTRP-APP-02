package com.ombudsman.service.complainant.exception;

public class CaseOwnerDetailsNotFound extends RuntimeException{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public CaseOwnerDetailsNotFound(String exceptionMsg)
	{
		super(exceptionMsg);
	}

}
