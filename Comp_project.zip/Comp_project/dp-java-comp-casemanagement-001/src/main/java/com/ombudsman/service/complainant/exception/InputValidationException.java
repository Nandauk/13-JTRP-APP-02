package com.ombudsman.service.complainant.exception;

public class InputValidationException  extends ComplainantServiceException {
 	private static final long serialVersionUID = 1L;
 	
 	public InputValidationException(String message, String code, String exceptionMessage) {
		super(message, "Complainant_USER_1000", exceptionMessage);
	}
}
