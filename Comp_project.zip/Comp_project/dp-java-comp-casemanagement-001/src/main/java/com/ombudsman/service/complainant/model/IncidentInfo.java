package com.ombudsman.service.complainant.model;

import java.io.Serializable;

public interface IncidentInfo extends Serializable {

	public Integer getIncidentid();
	public String getTicketnumber();
	
	
}
