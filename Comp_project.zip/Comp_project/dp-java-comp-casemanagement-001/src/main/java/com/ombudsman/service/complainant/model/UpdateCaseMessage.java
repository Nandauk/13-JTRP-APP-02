package com.ombudsman.service.complainant.model;

public class UpdateCaseMessage {
	private String isRespondent;
	private String contactId;
	private String digitalPortalUserName;
	private String digitalPortalUserEmailAddress;
	private String caseId;
	private String comments;
	private String details;
	private Long reasonForChange;
	private String userId;
	private String packageId;
	private String[] usersAccountIds;
	
	

	

	public String[] getUsersAccountIds() {
		return usersAccountIds;
	}

	public void setUsersAccountIds(String[] usersAccountIds) {
		this.usersAccountIds = usersAccountIds;
	}

	public Long getReasonForChange() {
		return reasonForChange;
	}

	public void setReasonForChange(Long reasonForChange) {
		this.reasonForChange = reasonForChange;
	}

	public String getIsRespondent() {
		return isRespondent;
	}

	public void setIsRespondent(String isRespondent) {
		this.isRespondent = isRespondent;
	}

	public String getContactId() {
		return contactId;
	}

	public void setContactId(String contactId) {
		this.contactId = contactId;
	}

	public String getDigitalPortalUserName() {
		return digitalPortalUserName;
	}

	public void setDigitalPortalUserName(String digitalPortalUserName) {
		this.digitalPortalUserName = digitalPortalUserName;
	}

	public String getDigitalPortalUserEmailAddress() {
		return digitalPortalUserEmailAddress;
	}

	public void setDigitalPortalUserEmailAddress(String digitalPortalUserEmailAddress) {
		this.digitalPortalUserEmailAddress = digitalPortalUserEmailAddress;
	}

	public String getCaseId() {
		return caseId;
	}

	public void setCaseId(String caseId) {
		this.caseId = caseId;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public String getDetails() {
		return details;
	}

	public void setDetails(String details) {
		this.details = details;
	}


	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getPackageId() {
		return packageId;
	}

	public void setPackageId(String packageId) {
		this.packageId = packageId;
	}

}
