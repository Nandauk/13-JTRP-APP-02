package com.ombudsman.service.complainant.service.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ombudsman.service.complainant.model.Incident;

public interface IncidentRepository extends JpaRepository<Incident, String> {
	
		
}
