package com.ombudsman.service.complainant.service.repository;

import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.ombudsman.service.complainant.model.OfferOutcome;

public interface OfferoutcomeRepository extends JpaRepository<OfferOutcome, String> { 
	
	@Modifying
	@Transactional
	@Query(value = "Update offeroutcome set fos_complainantresponse=:fosComplainantresponse,fos_complainantresponsename=:complainantResponseName where fos_offeroroutcomeid=:fosOfferoroutcomeid", nativeQuery = true)
	void updateFosComplainantresponseByFosOfferoroutcomeid(@Param("fosComplainantresponse") Integer fosComplainantresponse,  @Param("fosOfferoroutcomeid") UUID fosOfferoroutcomeid,@Param("complainantResponseName") String complainantResponseName);

	
	
	

}
