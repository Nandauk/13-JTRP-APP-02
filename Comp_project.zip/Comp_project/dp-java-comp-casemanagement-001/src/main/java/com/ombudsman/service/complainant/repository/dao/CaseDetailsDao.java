package com.ombudsman.service.complainant.repository.dao;

import java.util.List;
import java.util.Map;

import com.ombudsman.service.complainant.exception.SQLDataAccessException;
import com.ombudsman.service.complainant.model.CaseConversationDetail;
import com.ombudsman.service.complainant.model.dto.CaseByCaseReferenceDto;
import com.ombudsman.service.complainant.model.dto.CaseDetailDto;
import com.ombudsman.service.complainant.model.dto.CaseOutcomeDto;
import com.ombudsman.service.complainant.model.dto.CaseWorkerDto;

public interface CaseDetailsDao {

	Map<String, Object> getCaseDetailsById(String incidentId, String userOid,String role) throws SQLDataAccessException;

	Map<String, Object> getOfferOutcomes(String incidentId) throws SQLDataAccessException;
	
	Integer getCaseCount(String userOid) throws SQLDataAccessException;

	String getCaseIncidentId(String userOid) throws SQLDataAccessException;
	
	Map<String, Object> getCaseOwnerDetails(String incidentId) throws SQLDataAccessException;
	
	List<CaseConversationDetail> getCaseMessagingDetail(String incidentId) throws SQLDataAccessException;

	Map<String, Object> getCaseCountFrUser(String userOid, String usrRole) throws SQLDataAccessException;
	
	List<CaseByCaseReferenceDto> getCaseIncidentidByCaseReference(String ticketId)
			throws SQLDataAccessException;

	Integer chkIncidentAuthorized(String oid, String caseId,String roleid) throws SQLDataAccessException;
	
	public String fetchfullname(String emailAddress) ;
	
	public String getCaseStatus(String incidentId,String oid) throws SQLDataAccessException;

}
