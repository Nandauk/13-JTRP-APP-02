package com.ombudsman.service.complainant.model;

public class CaseIllustration {
	
	private String previousStageCode;
	private String currentStageCode;
	private String furthestStageCode;
	public String getPreviousStageCode() {
		return previousStageCode;
	}
	public void setPreviousStageCode(String previousStageCode) {
		this.previousStageCode = previousStageCode;
	}
	public String getCurrentStageCode() {
		return currentStageCode;
	}
	public void setCurrentStageCode(String currentStageCode) {
		this.currentStageCode = currentStageCode;
	}
	public String getFurthestStageCode() {
		return furthestStageCode;
	}
	public void setFurthestStageCode(String furthestStageCode) {
		this.furthestStageCode = furthestStageCode;
	}

}
