package com.ombudsman.service.complainant.exception;

public class CaseReferenceDetailsNotFoundException  extends RuntimeException {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public CaseReferenceDetailsNotFoundException(String exceptionMsg)
	{
		super(exceptionMsg);
	}


}
