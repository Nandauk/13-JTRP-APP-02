package com.ombudsman.service.complainant.serviceimpl;

import static com.ombudsman.service.complainant.common.Constants.CASE_DETAILS_NOT_FOUND;
import static com.ombudsman.service.complainant.common.Constants.CASE_OWNER_DETAILS_NOT_FOUND;
import static com.ombudsman.service.complainant.common.Constants.FAILED;
import static com.ombudsman.service.complainant.common.Constants.INCIDENTID_IS_A_VALID_FIELD;
import static com.ombudsman.service.complainant.common.Constants.INCIDENTID_IS_NOT_A_VALID_FIELD;

import java.io.IOException;
import java.time.OffsetDateTime;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Collectors;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ombudsman.service.complainant.common.CaseDetailMapper;
import com.ombudsman.service.complainant.common.CommonUtil;
import com.ombudsman.service.complainant.common.UserBean;
import com.ombudsman.service.complainant.exception.AzureServiceException;
import com.ombudsman.service.complainant.exception.CaseDetailsNotFoundException;
import com.ombudsman.service.complainant.exception.CaseOwnerDetailsNotFound;
import com.ombudsman.service.complainant.exception.SQLDataAccessException;
import com.ombudsman.service.complainant.model.CaseDetail;
import com.ombudsman.service.complainant.model.CaseIllustration;
import com.ombudsman.service.complainant.model.CaseWorker;
import com.ombudsman.service.complainant.model.dto.CaseDetailDto;
import com.ombudsman.service.complainant.model.dto.CaseIllustrationDto;
import com.ombudsman.service.complainant.model.dto.CasePartyDto;
import com.ombudsman.service.complainant.model.request.CaseDetailsByIdReq;
import com.ombudsman.service.complainant.model.response.CaseDetailsByIdRes;
import com.ombudsman.service.complainant.model.response.CaseOwnerRes;
import com.ombudsman.service.complainant.model.response.CasePartiesDetail;
import com.ombudsman.service.complainant.repository.dao.CaseDetailsDao;
import com.ombudsman.service.complainant.service.CaseDetailsByIdService;
import com.ombudsman.service.complainant.service.repository.CaseIllustrationRepository;

@Service
public class CaseDetailsByIdServiceImpl implements CaseDetailsByIdService {

	private CommonUtil commonUtil;

	UserBean userbean;

	CaseDetailsDao caseDetailsDao;

	@Autowired
	CaseIllustrationRepository caseIllustrationRepository;
	@Autowired
	public CaseDetailsByIdServiceImpl(UserBean userbean, CaseDetailsDao caseDetailsDao, CommonUtil commonUtil) {
		super();
		this.userbean = userbean;
		this.caseDetailsDao = caseDetailsDao;
		this.commonUtil = commonUtil;
	}

	private static final Logger log = LogManager.getRootLogger();
	private static final String RESULT_SET_1 = "#result-set-1";
	private static final String RESULT_SET_2 = "#result-set-2";

	@Override
	public CaseDetailsByIdRes getCaseDetailsById(CaseDetailsByIdReq request)
			throws AzureServiceException, IOException, SQLDataAccessException, CaseDetailsNotFoundException {

		log.debug("GetCaseDetailsById Service Method Started.CorrelationId:-{} OID:-{}", userbean.getCorrelationId(),
				userbean.getUserObjectId());
		CaseDetailsByIdRes caseDetailsByIdRes = new CaseDetailsByIdRes();
		List<Object> caseDetail = null;
		List<Object> casePartyDetail = null;

		try {

			// verification as per regex provided started
			if (StringUtils.isNotEmpty(request.getIncidentid()) && commonUtil.isValidInput(request.getIncidentid())) {

				log.info(INCIDENTID_IS_A_VALID_FIELD);
				log.info("Organisation list is not empty.CorrelationId:-{} OID:-{}", userbean.getCorrelationId(),
						userbean.getUserObjectId());

					final Map<String, Object> caseDetails = caseDetailsDao.getCaseDetailsById(request.getIncidentid(),userbean.getUserObjectId(),userbean.getRoles().get(0));
					log.info("Value of case Details" + caseDetails);
					caseDetail = (List<Object>) caseDetails.get(RESULT_SET_1);
					casePartyDetail = (List<Object>) caseDetails.get(RESULT_SET_2);

					final ObjectMapper mapper = new ObjectMapper();
					final List<CaseDetail> caseDtl = caseDetail.stream()
							.map(i -> mapper.convertValue(i, CaseDetailDto.class))
							.map(CaseDetailMapper.INSTANCE::caseDetailsLst).collect(Collectors.toList());

					if (CollectionUtils.isNotEmpty(caseDtl)) {
						
						final List<CasePartyDto> casePartyDtlsDto = casePartyDetail.stream()
								.map(i -> mapper.convertValue(i, CasePartyDto.class)).collect(Collectors.toList());

						List<CasePartiesDetail> partyDetails = casePartyDtlsDto.stream()
								.map(p -> new CasePartiesDetail(p.getPartyName(), p.getPartyRole())).collect(Collectors.toList());
						
						//Setting Case illustration Stage
						CaseIllustration caseIllustrationDtls = getCaseIllustrationStageDtls(caseDtl.get(0));
						
						String caseStatus = caseDetailsDao.getCaseStatus(request.getIncidentid(),userbean.getUserObjectId());
						
						
						caseDetailsByIdRes.setMessage("SUCCESS");
						caseDetailsByIdRes.setStatus("OK");
						caseDetailsByIdRes.setCasedetails(caseDtl.get(0));
						caseDetailsByIdRes.setCaseParties(partyDetails);
						caseDetailsByIdRes.setCaseIllustrationDtls(caseIllustrationDtls);
						caseDetailsByIdRes.setCaseWithdrawStatus(caseStatus);
					} else {
						log.debug(CASE_DETAILS_NOT_FOUND);
						throw new CaseDetailsNotFoundException(CASE_DETAILS_NOT_FOUND);
					}
					 
				//}

			} else {
				caseDetailsByIdRes.setStatus(FAILED);
				caseDetailsByIdRes.setMessage(INCIDENTID_IS_NOT_A_VALID_FIELD);
				log.debug(INCIDENTID_IS_NOT_A_VALID_FIELD);

			}
		} catch (SQLDataAccessException ex) {
			log.error(String.format("API error::{0}".concat(ex.getMessage())));
		}

		return caseDetailsByIdRes;
	}

	private CaseIllustration getCaseIllustrationStageDtls(CaseDetail caseDetail){
		CaseIllustrationDto caseIllustrationDto;
		CaseIllustration illustrationDtl = new CaseIllustration();
		caseIllustrationDto = caseIllustrationRepository.getCaseIllustrationByIncidentId(caseDetail.getIncidentid());

		if (caseIllustrationDto == null) {
			if (caseDetail.getFos_caseprogress() != null) {
				caseIllustrationDto = new CaseIllustrationDto();
				caseIllustrationDto.setIncidentid(UUID.fromString(caseDetail.getIncidentid()));
				caseIllustrationDto.setCurrentStageCode(caseDetail.getFos_caseprogress());
				caseIllustrationDto.setFurthestStageCode(caseDetail.getFos_caseprogress());
				caseIllustrationDto.setCreatedBy("CaseManagement");
				caseIllustrationDto.setCreatedOn(OffsetDateTime.now());
				caseIllustrationRepository.save(caseIllustrationDto);

				illustrationDtl.setPreviousStageCode(caseIllustrationDto.getPreviousStageCode());
				illustrationDtl.setCurrentStageCode(caseIllustrationDto.getCurrentStageCode());
				illustrationDtl.setFurthestStageCode(caseIllustrationDto.getFurthestStageCode());
			}
		} else {

			if (caseDetail.getFos_caseprogress() != null
					&& (caseDetail.getFos_caseprogress().compareTo(caseIllustrationDto.getCurrentStageCode()) != 0)) {
				if (Long.valueOf(caseIllustrationDto.getCurrentStageCode()).compareTo(140000017L) < 0) {
					// To handle existing Illustration stage scenario
					if (!(caseDetail.getFos_caseprogress().equals("140000007")
							&& caseIllustrationDto.getCurrentStageCode().equals("140000006"))) {
						caseIllustrationDto.setPreviousStageCode(caseIllustrationDto.getCurrentStageCode());
					}

					// To Handle Unidirection Flow
					if ((null != caseIllustrationDto.getFurthestStageCode() && caseDetail.getFos_caseprogress()
							.compareTo(caseIllustrationDto.getFurthestStageCode()) > 0)
							|| (caseDetail.getFos_caseprogress().equals("140000004")
									&& caseIllustrationDto.getCurrentStageCode().equals("140000005"))) {
						caseIllustrationDto.setFurthestStageCode(caseDetail.getFos_caseprogress());
					}

					caseIllustrationDto.setCurrentStageCode(caseDetail.getFos_caseprogress());
				} else {
					caseIllustrationDto.setCurrentStageCode(caseDetail.getFos_caseprogress());
					caseIllustrationDto.setFurthestStageCode(caseDetail.getFos_caseprogress());
				}
				caseIllustrationRepository.updateCaseIllustrationByIncidentId(
						caseIllustrationDto.getPreviousStageCode(), caseIllustrationDto.getCurrentStageCode(),
						caseIllustrationDto.getFurthestStageCode(), UUID.fromString(caseDetail.getIncidentid()));

				illustrationDtl.setPreviousStageCode(caseIllustrationDto.getPreviousStageCode());
				illustrationDtl.setCurrentStageCode(caseIllustrationDto.getCurrentStageCode());
				illustrationDtl.setFurthestStageCode(caseIllustrationDto.getFurthestStageCode());
			}else
			{
				illustrationDtl.setPreviousStageCode(caseIllustrationDto.getPreviousStageCode());
				illustrationDtl.setCurrentStageCode(caseIllustrationDto.getCurrentStageCode());
				illustrationDtl.setFurthestStageCode(caseIllustrationDto.getFurthestStageCode());
			}
		}

		return illustrationDtl;
	}
	
	@Override
	public CaseOwnerRes getCaseOwnerDetails(CaseDetailsByIdReq request)
			throws AzureServiceException, JSONException, IOException, SQLDataAccessException, CaseOwnerDetailsNotFound
			{
		log.info("getCaseOwnerDetails Service Method Started.CorrelationId:-{} OID:-{}", userbean.getCorrelationId(),
				userbean.getUserObjectId());
		var caseOwnerResponse = new CaseOwnerRes();
		List<Object> caseOwner = null;

		String incidentId = request.getIncidentid();//cryptoUtil.decode(request.getIncidentid(), DECRYPTIONSTRING);
		if (StringUtils.isNotEmpty(incidentId) && commonUtil.isValidInput(incidentId)) {

			log.debug(INCIDENTID_IS_A_VALID_FIELD);

				log.debug("Organisation list is not empty.CorrelationId:-{} OID:-{}", userbean.getCorrelationId(),
						userbean.getUserObjectId());

				int count = caseDetailsDao.chkIncidentAuthorized(userbean.getUserObjectId(), request.getIncidentid(),userbean.getRoles().get(0));
				
				if (count >= 1) {

					final Map<String, Object> caseWorkerDetails = caseDetailsDao
							.getCaseOwnerDetails(request.getIncidentid());

					final ObjectMapper mapper = new ObjectMapper();

					caseOwner = (List<Object>) caseWorkerDetails.get(RESULT_SET_1);

					final List<CaseWorker> caseWorkerDtl = caseOwner.stream()
							.map(i -> mapper.convertValue(i, CaseWorker.class)).collect(Collectors.toList());


					if (CollectionUtils.isNotEmpty(caseWorkerDtl)) {
						caseOwnerResponse.setMessage("SUCCESS");
						caseOwnerResponse.setStatus("OK");
						caseOwnerResponse.setCaseWorker(caseWorkerDtl.get(0));
					} else {
						log.debug(CASE_OWNER_DETAILS_NOT_FOUND);
						throw new CaseOwnerDetailsNotFound(CASE_OWNER_DETAILS_NOT_FOUND);
					}
				}
					else
					{
						log.info("CaseID and User are not linked, case does not belong to user ");
						caseOwnerResponse.setMessage("Case does not belong to user.");
						caseOwnerResponse.setStatus(FAILED);
					}
					 
				}else {
					caseOwnerResponse.setStatus(FAILED);
					caseOwnerResponse.setMessage(INCIDENTID_IS_NOT_A_VALID_FIELD);
					log.debug(INCIDENTID_IS_NOT_A_VALID_FIELD);

				}


		

		return caseOwnerResponse;

	}

}
