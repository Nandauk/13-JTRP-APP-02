package com.ombudsman.service.complainant.exception;

public class InvalidOrganisationException  extends RuntimeException {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public InvalidOrganisationException(String exceptionMsg)
	{
		super(exceptionMsg);
	}


}
