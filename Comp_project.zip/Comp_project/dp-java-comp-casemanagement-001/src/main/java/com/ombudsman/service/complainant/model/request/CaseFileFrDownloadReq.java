package com.ombudsman.service.complainant.model.request;

import jakarta.persistence.Id;
import jakarta.validation.Valid;

public class CaseFileFrDownloadReq {

	@Id
	@Valid
	private String caseId;
	private String portalType;
	private String orgId;
	public String getCaseId() {
		return caseId;
	}
	public void setCaseId(String caseId) {
		this.caseId = caseId;
	}
	public String getPortalType() {
		return portalType;
	}
	public void setPortalType(String portalType) {
		this.portalType = portalType;
	}
	public String getOrgId() {
		return orgId;
	}
	public void setOrgId(String orgId) {
		this.orgId = orgId;
	}
	

	


}
