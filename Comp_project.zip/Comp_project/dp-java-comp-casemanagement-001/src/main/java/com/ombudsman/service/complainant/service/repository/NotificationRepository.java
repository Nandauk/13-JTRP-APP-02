package com.ombudsman.service.complainant.service.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.ombudsman.service.complainant.model.dto.Notification;

@Repository
public interface NotificationRepository  extends JpaRepository<Notification, Long> {


	@Modifying
	@Query(value = "update dp_complainant_user_notification set notification_status_id =:notificationStatusId  WHERE request_id =:requestId", nativeQuery = true)
	String updateNotificationById( @Param("notificationStatusId") String notificationStatusId, @Param("requestId") String requestId);

	

}
