package com.ombudsman.service.complainant.service.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.ombudsman.service.complainant.model.dto.AuditMaster;

@Repository
public interface AuditRepository extends JpaRepository<AuditMaster, Integer> {


	@Query(value = "SELECT audit_record_id FROM dp_complainant_audit_event where audit_event_name = :eventname", nativeQuery = true)
	Integer getAuditEntityId(@Param("eventname") String eventname);
	
	@Query(value = "EXEC prc_GetADAccountid ?", nativeQuery = true)
	List<String> getAccountId(@Param("accountids") String accountids);
	

}
