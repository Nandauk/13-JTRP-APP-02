package com.ombudsman.service.complainant.common;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;

import com.ombudsman.service.complainant.model.response.GenericResponse;
@Component
public class CaseManagementWebClient {
	
	@Autowired
	UserBean userbean;
	@Autowired
	CommonUtil commonUtil;
	private static String sessionApiUrl = "/compsessionmanagement/compsessionmanagement/v1/sessionservice/verifyUserSession";
	Logger LOG = LogManager.getRootLogger();	
	
	public GenericResponse getResponseForSessionActivity(final String sessionType) {
		final String sessionApiBaseUrl=commonUtil.SESSION_BASE_URL;
		LOG.info("Session api base Url :{}",sessionApiBaseUrl);		
		LOG.info("session type  :{}",sessionType);		
		return WebClient.create().get().uri(sessionApiBaseUrl + sessionApiUrl).headers(httpHeaders -> {
			httpHeaders.set("Authorization", "Bearer "+userbean.getAuthToken());
			httpHeaders.set("SessionType", sessionType);
		}).accept(MediaType.APPLICATION_JSON).retrieve().bodyToMono(GenericResponse.class).block();
	}

}
