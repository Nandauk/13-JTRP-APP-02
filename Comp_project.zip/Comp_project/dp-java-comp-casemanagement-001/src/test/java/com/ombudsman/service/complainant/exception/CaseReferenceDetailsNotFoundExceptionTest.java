package com.ombudsman.service.complainant.exception;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

class CaseReferenceDetailsNotFoundExceptionTest {	
	
	@Test
	void testExceptionMessage() {

	String message = "Case Reference Details Not Found";

	CaseReferenceDetailsNotFoundException ex = new CaseReferenceDetailsNotFoundException(message);
	assertEquals(message, ex.getMessage());

}}
