package com.ombudsman.service.complainant.model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.time.LocalDateTime;

import org.junit.jupiter.api.Test;

class CaseDocumentDetailTest {
	
	@Test
	void testCaseDocumentDetailGettersAndSetters() {
		String documentId="Test Document Id";
		String fileName = "Test File Name";
		String originator = "Test Originator";
		LocalDateTime createdOn = LocalDateTime.now();
		String documentType = "Test Document Name";
		String sizeOfFile = "25MB";
		String fileType = "PDF";
		String fileComments = "Test Comments";
		
		CaseDocumentDetail caseDoc = new CaseDocumentDetail();
		caseDoc.setDocumentId(documentId);
		caseDoc.setFileName(fileName);
		caseDoc.setOriginator(originator);
		caseDoc.setCreatedOn(createdOn);
		caseDoc.setDocumentType(documentType);
		caseDoc.setSizeOfFile(sizeOfFile);
		caseDoc.setFileType(fileType);
		caseDoc.setFileComments(fileComments);
		
		assertEquals(documentId, caseDoc.getDocumentId());
		assertEquals(fileName, caseDoc.getFileName());
		assertEquals(originator, caseDoc.getOriginator());
		assertEquals(createdOn, caseDoc.getCreatedOn());
		assertEquals(documentType, caseDoc.getDocumentType());
		assertEquals(sizeOfFile, caseDoc.getSizeOfFile());
		assertEquals(fileType, caseDoc.getFileType());
		assertEquals(fileComments, caseDoc.getFileComments());
	}

}
