package com.ombudsman.service.complainant.model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

class SystemUserDataTest {
	@Test
	void testGettersAndSetters() {
		String systemuserid = "Test System User";
		String ownerid = "Test Owner Id";

		SystemUserData sysUser = new SystemUserData();
		sysUser.setSystemuserid(systemuserid);
		sysUser.setOwnerid(ownerid);

		assertEquals(systemuserid, sysUser.getSystemuserid());
		assertEquals(ownerid, sysUser.getOwnerid());
	}

}
