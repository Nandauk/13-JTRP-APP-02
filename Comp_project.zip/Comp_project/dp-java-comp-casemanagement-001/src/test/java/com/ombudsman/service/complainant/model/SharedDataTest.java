package com.ombudsman.service.complainant.model;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertSame;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;

import com.ombudsman.service.complainant.model.SharedData;
import com.ombudsman.service.complainant.model.SharedDataItem;

class SharedDataTest {

    @Test
    void testGettersAndSetters() {
        SharedData sd = new SharedData();

        sd.setFore("FORE");
        assertEquals("FORE", sd.getFore());

        List<SharedDataItem> docCodes = new ArrayList<>();
        sd.setDocumentCodes(docCodes);
        assertSame(docCodes, sd.getDocumentCodes());

        List<SharedDataItem> originatorCodes = new ArrayList<>();
        sd.setOriginatorCodes(originatorCodes);
        assertSame(originatorCodes, sd.getOriginatorCodes());

        List<SharedDataItem> reasonCodes = new ArrayList<>();
        sd.setReasonForChangeCodes(reasonCodes);
        assertSame(reasonCodes, sd.getReasonForChangeCodes());
    }
}
