package com.ombudsman.service.complainant.exception;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

class MandatoryFieldMissingExceptionTest {	
	
	@Test
	void testExceptionMessage() {

	String message = "Mandatory Field Missing exception";

	MandatoryFieldException ex = new MandatoryFieldException(message);
	assertEquals(message, ex.getMessage());

}

}
