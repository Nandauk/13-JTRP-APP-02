package com.ombudsman.service.complainant.model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.Test;

class UserDataTest {
	@Test
	void testGettersAndSetters() {
		String oid = "Test User Id";
		String fullName = "Test User";
		String email = "test@gmail.com";
		List<String> roles = new ArrayList<>(Arrays.asList("xyz", "abc"));

		UserData userData = new UserData();
		userData.setOid(oid);
		userData.setFullName(fullName);
		userData.setEmail(email);
		userData.setRoles(roles);

		assertEquals(oid, userData.getOid());
		assertEquals(fullName, userData.getFullName());
		assertEquals(email, userData.getEmail());
		assertEquals(roles, userData.getRoles());

	}

}
