package com.ombudsman.service.complainant.model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

class CaseConversationDetailTest {

	@Test
	void testConstructorAndGetters() {
		String messageOriginator = "Test User";
		String message = "Test message";
		String createdOn = "17-06-2025";

		CaseConversationDetail detail = new CaseConversationDetail(messageOriginator, message, createdOn);

		assertEquals(messageOriginator, detail.getMessageOriginator());
		assertEquals(message, detail.getMessage());
		assertEquals(createdOn, detail.getCreatedOn());

	}

	@Test
	void testSetters() {
		CaseConversationDetail c = new CaseConversationDetail("", "", "");
		c.setMessage("Hi");
		c.setMessageOriginator("Test User");
		c.setCreatedOn("17-06-2025");

		assertEquals("Hi", c.getMessage());
		assertEquals("Test User", c.getMessageOriginator());
		assertEquals("17-06-2025", c.getCreatedOn());

	}

}
