package com.ombudsman.service.complainant.model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

public class EfileMessageTest {

	@Test
	void testGettersAndSetters() {

		String caseId = "Case123";
		String comments = "Test Comments";
		String details = "Test Details";
		int reasonForChange = 12;
		String packageId = "Test Package";
		String[] usersAccountIds = { "Account1", "Account2" };
		String digitalPortalUserName = "Portal User";
		String digitalPortalUserEmailAddress = "Portal User Email";
		String fromContactId = "Test Contact";
		String PortalType = "Complainant";

		EfileMessage message = new EfileMessage();
		message.setCaseId(caseId);
		message.setComments(comments);
		message.setDetails(details);
		message.setReasonForChange(reasonForChange);
		message.setPackageId(packageId);
		message.setUsersAccountIds(usersAccountIds);
		message.setDigitalPortalUserName(digitalPortalUserName);
		message.setDigitalPortalUserEmailAddress(digitalPortalUserEmailAddress);
		message.setFromContactId(fromContactId);
		message.setPortalType(PortalType);

		assertEquals(caseId, message.getCaseId());
		assertEquals(comments, message.getComments());
		assertEquals(details, message.getDetails());
		assertEquals(reasonForChange, message.getReasonForChange());
		assertEquals(packageId, message.getPackageId());
		assertEquals(usersAccountIds, message.getUsersAccountIds());
		assertEquals(digitalPortalUserName, message.getDigitalPortalUserName());
		assertEquals(digitalPortalUserEmailAddress, message.getDigitalPortalUserEmailAddress());
		assertEquals(fromContactId, message.getFromContactId());
		assertEquals(PortalType, message.getPortalType());

		assertEquals(caseId, message.getCaseId());

	}
}
