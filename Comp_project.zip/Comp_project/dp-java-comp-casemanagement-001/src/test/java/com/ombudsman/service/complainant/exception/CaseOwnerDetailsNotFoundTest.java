package com.ombudsman.service.complainant.exception;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

class CaseOwnerDetailsNotFoundTest {
	
	@Test
	void testExceptionMessage() {

		String message = "Case Owner Details Not Found";

		CaseOwnerDetailsNotFound ex = new CaseOwnerDetailsNotFound(message);
		assertEquals(message, ex.getMessage());

	}

}
