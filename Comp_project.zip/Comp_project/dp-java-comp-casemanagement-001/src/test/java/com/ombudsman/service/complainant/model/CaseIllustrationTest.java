package com.ombudsman.service.complainant.model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

class CaseIllustrationTest {
	@Test
	void testGettersAndSetters() {
		String previousStageCode = "Previous Stage";
		String currentStageCode = "Current Stage";
		String furthestStageCode = "Furthest Stage";

		CaseIllustration caseIllus = new CaseIllustration();
		caseIllus.setPreviousStageCode(previousStageCode);
		caseIllus.setCurrentStageCode(currentStageCode);
		caseIllus.setFurthestStageCode(furthestStageCode);

		assertEquals(previousStageCode, caseIllus.getPreviousStageCode());
		assertEquals(currentStageCode, caseIllus.getCurrentStageCode());
		assertEquals(furthestStageCode, caseIllus.getFurthestStageCode());
	}
}
