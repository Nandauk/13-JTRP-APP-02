package com.ombudsman.service.complainant.model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.time.OffsetDateTime;
import java.util.UUID;

import org.junit.jupiter.api.Test;


class OfferoutcomeResponseTest {

	@Test
	void testGettersAndSetters() {
		UUID offeroutcomeId = UUID.fromString("a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11");
		OffsetDateTime requestDatetime = OffsetDateTime.parse("2025-06-18T22:52:15.962090600+02:00");
		String phoenixRespone = "Phoenix Response";
		OffsetDateTime createdOn = OffsetDateTime.parse("2025-06-18T22:52:15.962090600+02:00");
		String createdBy = "Test User";
		OffsetDateTime modifiedOn = OffsetDateTime.parse("2025-06-18T22:52:15.962090600+02:00");
		;
		String modifiedBy = "Test USer Modify";
		String userComments = "Test Comments";

		OfferoutcomeResponse offerResponse = new OfferoutcomeResponse();
		offerResponse.setOfferoutcomeId(offeroutcomeId);
		offerResponse.setRequestDatetime(requestDatetime);
		offerResponse.setPhoenixRespone(phoenixRespone);
		offerResponse.setCreatedOn(createdOn);
		offerResponse.setCreatedBy(createdBy);
		offerResponse.setModifiedOn(modifiedOn);
		offerResponse.setModifiedBy(modifiedBy);
		offerResponse.setUserComments(userComments);

		assertEquals(offeroutcomeId, offerResponse.getOfferoutcomeId());
		assertEquals(requestDatetime, offerResponse.getRequestDatetime());
		assertEquals(phoenixRespone, offerResponse.getPhoenixRespone());
		assertEquals(createdOn, offerResponse.getCreatedOn());
		assertEquals(createdBy, offerResponse.getCreatedBy());
		assertEquals(modifiedOn, offerResponse.getModifiedOn());
		assertEquals(modifiedBy, offerResponse.getModifiedBy());
		assertEquals(userComments, offerResponse.getUserComments());
	}

}
