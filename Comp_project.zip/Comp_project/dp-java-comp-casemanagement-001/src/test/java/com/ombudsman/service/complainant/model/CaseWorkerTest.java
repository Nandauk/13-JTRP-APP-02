package com.ombudsman.service.complainant.model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

import com.ombudsman.service.complainant.model.CaseWorker;

class CaseWorkerTest {

    @Test
    void testGettersAndSetters() {
        CaseWorker caseWorker = new CaseWorker();

        caseWorker.setTicketnumber("TICK-123");
        assertEquals("TICK-123", caseWorker.getTicketnumber());

        caseWorker.setFos_caseworker("FOS-WorkerVal");
        assertEquals("FOS-WorkerVal", caseWorker.getFos_caseworker());

        caseWorker.setOwninguser("OWN-UserVal");
        assertEquals("OWN-UserVal", caseWorker.getOwninguser());

        caseWorker.setFullname("John Doe");
        assertEquals("John Doe", caseWorker.getFullname());

        caseWorker.setFos_casestagename("Enquiry");
        assertEquals("Enquiry", caseWorker.getFos_casestagename());
        
        caseWorker.setEmail("abc@gmail.com");
        assertEquals("abc@gmail.com", caseWorker.getEmail());
        
        caseWorker.setPhone("9876543210");
        assertEquals("9876543210",caseWorker.getPhone());
		/*
		 * caseWorker.setTitle("Mr."); assertEquals("Mr.", caseWorker.getTitle());
		 * 
		 * caseWorker.setFirstname("John"); assertEquals("John",
		 * caseWorker.getFirstname());
		 * 
		 * caseWorker.setLastname("Doe"); assertEquals("Doe", caseWorker.getLastname());
		 * 
		 * caseWorker.setAddress1_telephone1("555-1234"); assertEquals("555-1234",
		 * caseWorker.getAddress1_telephone1());
		 * 
		 * caseWorker.setInternalemailaddress("john.doe@example.com");
		 * assertEquals("john.doe@example.com", caseWorker.getInternalemailaddress());
		 */
    }
}
