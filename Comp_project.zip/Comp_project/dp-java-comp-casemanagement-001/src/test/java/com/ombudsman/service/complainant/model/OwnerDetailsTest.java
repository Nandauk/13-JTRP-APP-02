package com.ombudsman.service.complainant.model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

class OwnerDetailsTest {

	@Test
	void testGettersAndSetters() {
		String ownerid = "Test Owner Id";
		String owningteam = "Test Owner TEam";
		String owninguser = "Test Owner User";

		OwnerDetails owner = new OwnerDetails();
		owner.setOwnerid(ownerid);
		owner.setOwningteam(owningteam);
		owner.setOwninguser(owninguser);

		assertEquals(ownerid, owner.getOwnerid());
		assertEquals(owningteam, owner.getOwningteam());
		assertEquals(owninguser, owner.getOwninguser());

	}

}
