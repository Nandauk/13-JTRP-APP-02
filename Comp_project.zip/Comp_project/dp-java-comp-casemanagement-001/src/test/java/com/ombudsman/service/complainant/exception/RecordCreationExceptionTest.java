package com.ombudsman.service.complainant.exception;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

class RecordCreationExceptionTest {	
	
	@Test
	void testExceptionMessage() {

	String message = "Record Creation exception";
	String exceptionMessage = "Exception Occured";

	RecordCreationException ex = new  RecordCreationException(message,exceptionMessage);
	assertEquals(message, ex.getMessage());
	assertEquals(exceptionMessage, ex.getExceptionMessage());
}

}
