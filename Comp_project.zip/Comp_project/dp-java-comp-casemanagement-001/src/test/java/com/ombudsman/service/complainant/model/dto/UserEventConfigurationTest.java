package com.ombudsman.service.complainant.model.dto;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.ombudsman.service.complainant.model.dto.UserEventConfiguration;

import java.time.OffsetDateTime;

import static org.junit.jupiter.api.Assertions.*;
@ExtendWith(SpringExtension.class)
public class UserEventConfigurationTest {
	@InjectMocks
	private UserEventConfiguration userEventConfiguration;

	@BeforeEach
	public void setUp() {
		userEventConfiguration = new UserEventConfiguration();
	}

	@Test
	public void testGetterAndSetter() {
		// Set values
		int id = 1;
		String userEventName = "User Event";
		Boolean isAuditRequired = true;
		Boolean isUserRequestNeeded = false;
		Boolean isNotificationNeeded = true;
		OffsetDateTime createdOn = OffsetDateTime.now();
		String createdBy = "Admin";
		OffsetDateTime modifiedOn = OffsetDateTime.now().plusDays(1);
		String modifiedBy = "User123";

		userEventConfiguration.setId(id);
		userEventConfiguration.setUserEventName(userEventName);
		userEventConfiguration.setIsAuditRequired(isAuditRequired);
		userEventConfiguration.setIsUserRequestNeeded(isUserRequestNeeded);
		userEventConfiguration.setIsNotificationNeeded(isNotificationNeeded);
		userEventConfiguration.setCreatedOn(createdOn);
		userEventConfiguration.setCreatedBy(createdBy);
		userEventConfiguration.setModifiedOn(modifiedOn);
		userEventConfiguration.setModifiedBy(modifiedBy);

		// Assert values
		assertEquals(id, userEventConfiguration.getId());
		assertEquals(userEventName, userEventConfiguration.getUserEventName());
		assertEquals(isAuditRequired, userEventConfiguration.getIsAuditRequired());
		assertEquals(isUserRequestNeeded, userEventConfiguration.getIsUserRequestNeeded());
		assertEquals(isNotificationNeeded, userEventConfiguration.getIsNotificationNeeded());
		assertEquals(createdOn, userEventConfiguration.getCreatedOn());
		assertEquals(createdBy, userEventConfiguration.getCreatedBy());
		assertEquals(modifiedOn, userEventConfiguration.getModifiedOn());
		assertEquals(modifiedBy, userEventConfiguration.getModifiedBy());
	}
}
