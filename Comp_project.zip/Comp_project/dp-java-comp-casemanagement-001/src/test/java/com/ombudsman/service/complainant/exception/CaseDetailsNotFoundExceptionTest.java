package com.ombudsman.service.complainant.exception;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

class CaseDetailsNotFoundExceptionTest {
	@Test
	void testExceptionMessage() {

		String message = "Case Details Not Found";

		CaseDetailsNotFoundException ex = new CaseDetailsNotFoundException(message);
		assertEquals(message, ex.getMessage());

	}

}
