package com.ombudsman.service.complainant.model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

public class UpdateOfferOutcomeObjectTest {
	@Test
	void testGettersAndSetters() {
		String activityId = "Test Activity";
		String ownerId = "Test OwnerId";
		String regardingObjectIdIncidentFosPortal = "INC12345";
		String subject = "Test Subject";
		String fosOtherReasonForChange = "Teat Reason";
		String description = "Desc123";
		int fosCapacity = 140001;
		String fosPackageId = "Test Package";
		int fosReasonForChange = 1234;
		boolean fosBusinessResponse = true;
		String fosDpUserEmailAddress = "testing@gmail.com";
		String fosDpUserFullName = "Test User";

		UpdateOfferOutcomeObject portalActivity = new UpdateOfferOutcomeObject();
		portalActivity.setActivityId(activityId);
		portalActivity.setOwnerId(ownerId);
		portalActivity.setRegardingObjectIdIncidentFosPortal(regardingObjectIdIncidentFosPortal);
		portalActivity.setSubject(subject);
		portalActivity.setFosOtherReasonForChange(fosOtherReasonForChange);
		portalActivity.setDescription(description);
		portalActivity.setFosCapacity(fosCapacity);
		portalActivity.setFosPackageId(fosPackageId);
		portalActivity.setFosReasonForChange(fosReasonForChange);
		portalActivity.setFosBusinessResponse(fosBusinessResponse);
		portalActivity.setFosDpUserEmailAddress(fosDpUserEmailAddress);
		portalActivity.setFosDpUserFullName(fosDpUserFullName);

		assertEquals(activityId, portalActivity.getActivityId());
		assertEquals(ownerId, portalActivity.getOwnerId());
		assertEquals(regardingObjectIdIncidentFosPortal, portalActivity.getRegardingObjectIdIncidentFosPortal());
		assertEquals(subject, portalActivity.getSubject());
		assertEquals(fosOtherReasonForChange, portalActivity.getFosOtherReasonForChange());
		assertEquals(description, portalActivity.getDescription());
		assertEquals(fosCapacity, portalActivity.getFosCapacity());
		assertEquals(fosPackageId, portalActivity.getFosPackageId());
		assertEquals(fosReasonForChange, portalActivity.getFosReasonForChange());
		assertEquals(fosBusinessResponse, portalActivity.isFosBusinessResponse());
		assertEquals(fosDpUserEmailAddress, portalActivity.getFosDpUserEmailAddress());
		assertEquals(fosDpUserFullName, portalActivity.getFosDpUserFullName());
	}

}
