package com.ombudsman.service.complainant.exception;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

class SQLServerExceptionTest {	
	
	@Test
	void testExceptionMessage() {

	String message = "SQL Server exception";

	SQLServerException ex = new SQLServerException(message);
	assertEquals(message, ex.getMessage());

}

}
