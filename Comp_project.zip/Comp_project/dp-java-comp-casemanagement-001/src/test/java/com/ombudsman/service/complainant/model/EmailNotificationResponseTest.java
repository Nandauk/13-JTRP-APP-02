package com.ombudsman.service.complainant.model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

class EmailNotificationResponseTest {

	@Test
	void testGettersAndSetters() {
		String status = "Test Status";
		String message = "Test Message";

		EmailNotificationResponse test = new EmailNotificationResponse();
		test.setStatus(status);
		test.setMessage(message);

		assertEquals(status, test.getStatus());
		assertEquals(message, test.getMessage());
	}
}
