package com.ombudsman.service.complainant.exception;

import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.test.context.junit.jupiter.SpringExtension;


@ExtendWith(SpringExtension.class)
class UnAuthorisedExceptionTest {
	
	@Test
    void testUnAuthorisedException() {
        assertThrows(UnAuthorisedException.class, () -> {
            throw new UnAuthorisedException("Unauthorised access");
        });
    }

}

