package com.ombudsman.service.complainant.model.response;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

class CaseByCaseReferenceResTest {
	
	@Test
    void testGetAndSetIncidentid()
	{
		CaseByCaseReferenceRes obj = new CaseByCaseReferenceRes();
		
		String expectedIncidentId = "Inc12345";
		obj.setIncidentid(expectedIncidentId);
		
		String actualIncidentId = obj.getIncidentid();
		assertEquals(expectedIncidentId, actualIncidentId);
	}

}
