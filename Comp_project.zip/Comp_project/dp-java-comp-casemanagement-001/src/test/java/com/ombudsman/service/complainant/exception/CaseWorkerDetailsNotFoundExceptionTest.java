package com.ombudsman.service.complainant.exception;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

class CaseWorkerDetailsNotFoundExceptionTest {	
	
	@Test
	void testExceptionMessage() {

	String message = "Case Worker Details Not Found";

	CaseWorkerDetailsNotFoundException ex = new CaseWorkerDetailsNotFoundException(message);
	assertEquals(message, ex.getMessage());

}}
