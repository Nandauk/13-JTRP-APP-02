package com.ombudsman.service.complainant.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.text.ParseException;
import java.util.List;

import javax.security.auth.login.AccountNotFoundException;

import org.json.JSONException;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.ombudsman.service.complainant.common.CaseManagementWebClient;
import com.ombudsman.service.complainant.common.UserBean;
import com.ombudsman.service.complainant.common.ValidateUserSession;
import com.ombudsman.service.complainant.exception.InputValidationException;
import com.ombudsman.service.complainant.exception.InvalidOrganisationException;
import com.ombudsman.service.complainant.exception.MailJetServiceException;
import com.ombudsman.service.complainant.exception.MandatoryFieldException;
import com.ombudsman.service.complainant.exception.OrganizationNotFoundException;
import com.ombudsman.service.complainant.exception.SQLDataAccessException;
import com.ombudsman.service.complainant.exception.UnAuthorisedException;
import com.ombudsman.service.complainant.model.ApiResponse;
import com.ombudsman.service.complainant.model.CaseWithdraw;
import com.ombudsman.service.complainant.model.dto.AcceptRejectRequest;
import com.ombudsman.service.complainant.model.request.CaseByCaseReferenceReq;
import com.ombudsman.service.complainant.model.request.CaseDetailsByIdReq;
import com.ombudsman.service.complainant.model.request.CaseFileFrDownloadReq;
import com.ombudsman.service.complainant.model.request.CaseOutcomeByIdReq;
import com.ombudsman.service.complainant.model.response.CaseByCaseReferenceRes;
import com.ombudsman.service.complainant.model.response.CaseCountRes;
import com.ombudsman.service.complainant.model.response.CaseDetailsByIdRes;
import com.ombudsman.service.complainant.model.response.CaseDocumentFrDownloadRes;
import com.ombudsman.service.complainant.model.response.CaseMessagingFrDownloadRes;
import com.ombudsman.service.complainant.model.response.CaseOutcomeByIdRes;
import com.ombudsman.service.complainant.model.response.CaseOwnerRes;
import com.ombudsman.service.complainant.model.response.CaseSummaryRes;
import com.ombudsman.service.complainant.model.response.GenericResponse;
import com.ombudsman.service.complainant.service.CaseByCaseReferenceService;
import com.ombudsman.service.complainant.service.CaseCountService;
import com.ombudsman.service.complainant.service.CaseDetailDownloadService;
import com.ombudsman.service.complainant.service.CaseDetailsByIdService;
import com.ombudsman.service.complainant.service.CaseOutcomeByIdService;
import com.ombudsman.service.complainant.service.CaseSummaryService;
import com.ombudsman.service.complainant.service.IUpdateFileService;
import com.ombudsman.service.complainant.serviceimpl.helper.AcceptRejectHelper;

@ExtendWith(MockitoExtension.class)
public class CaseManagementControllerTest {

	@InjectMocks
	CaseManagementController controller;

	@Mock
	CaseCountService caseCountService;

	@Mock
	CaseDetailsByIdService caseDetailsByIdService;

	@Mock
	CaseOutcomeByIdService caseOutcomeByIdService;

	@Mock
	UserBean userBean;

	@Mock
	private IUpdateFileService updateFileService;

	@Mock
	CaseManagementWebClient caseManagementWebClient;

	@Mock
	CaseDetailDownloadService caseDetailDownloadService;

	@Mock
	CaseSummaryService caseSummaryService;

	@Mock
	AcceptRejectHelper acceptRejectHelper;

	@Mock
	CaseByCaseReferenceService caseByCaseReferenceService;

	@Mock
	ValidateUserSession validateUserSession;

	@Test
	void getCaseCountTest() throws SQLDataAccessException, AccountNotFoundException, InvalidOrganisationException,
			UnAuthorisedException, IOException {

		CaseCountRes response = new CaseCountRes();
		response.setIncidentId("Incid");
		when(validateUserSession.isValidSession()).thenReturn(true);
		when(userBean.getRoles()).thenReturn(List.of("Individual Complainant"));
		when(caseCountService.getCaseCount()).thenReturn(response);
		ResponseEntity<CaseCountRes> caseCount = controller.getCaseCount();
		assertEquals(HttpStatus.OK, caseCount.getStatusCode());

	}

	@Test
	void getCaseDetailsById() throws SQLDataAccessException, AccountNotFoundException, InvalidOrganisationException,
			UnAuthorisedException, IOException {

		CaseDetailsByIdRes response = new CaseDetailsByIdRes();
		CaseDetailsByIdReq request = new CaseDetailsByIdReq();
		request.setIncidentid("Incid");
		response.setStatus("success");
		when(validateUserSession.isValidSession()).thenReturn(true);
		when(userBean.getRoles()).thenReturn(List.of("Individual Complainant"));
		when(caseDetailsByIdService.getCaseDetailsById(request)).thenReturn(response);
		ResponseEntity<CaseDetailsByIdRes> caseDetailsById = controller.getCaseDetailsById(request);
		assertEquals(HttpStatus.OK, caseDetailsById.getStatusCode());

	}

	@Test
	void getCaseOutcomeByIdTest() throws SQLDataAccessException, AccountNotFoundException, InvalidOrganisationException,
			UnAuthorisedException, IOException {

		CaseOutcomeByIdRes response = new CaseOutcomeByIdRes();
		CaseOutcomeByIdReq request = new CaseOutcomeByIdReq();
		request.setIncidentid("Incid");
		response.setStatus("success");
		when(validateUserSession.isValidSession()).thenReturn(true);
		when(userBean.getRoles()).thenReturn(List.of("Individual Complainant"));
		when(userBean.getRoles()).thenReturn(List.of("Organisation Complainant"));

		when(caseOutcomeByIdService.getCaseOutcomeById(request)).thenReturn(response);
		ResponseEntity<CaseOutcomeByIdRes> caseDetailsById = controller.getCaseOutcomeById(request);
		assertEquals(HttpStatus.OK, caseDetailsById.getStatusCode());

	}

	@Test
	void CaseOwnerResTest() throws SQLDataAccessException, AccountNotFoundException, InvalidOrganisationException,
			UnAuthorisedException, IOException {

		CaseOwnerRes response = new CaseOwnerRes();
		CaseDetailsByIdReq request = new CaseDetailsByIdReq();
		request.setIncidentid("Incid");
		response.setStatus("success");
		when(validateUserSession.isValidSession()).thenReturn(true);
		when(userBean.getRoles()).thenReturn(List.of("Individual Complainant"));
		when(userBean.getRoles()).thenReturn(List.of("Organisation Complainant"));

		when(caseDetailsByIdService.getCaseOwnerDetails(request)).thenReturn(response);
		ResponseEntity<CaseOwnerRes> caseDetailsById = controller.getCaseOwner(request);
		assertEquals(HttpStatus.OK, caseDetailsById.getStatusCode());

	}

	@Test
	void caseWithdrawTest() throws SQLDataAccessException, AccountNotFoundException, InvalidOrganisationException,
			UnAuthorisedException, IOException, JSONException, ParseException, OrganizationNotFoundException,
			MandatoryFieldException {

		ApiResponse response = new ApiResponse();
		CaseWithdraw request = new CaseWithdraw();
		request.setCaseId("Incid");
		response.setSuccess(true);
		when(validateUserSession.isValidSession()).thenReturn(true);
		when(userBean.getRoles()).thenReturn(List.of("Individual Complainant"));
		when(userBean.getRoles()).thenReturn(List.of("Organisation Complainant"));

		when(updateFileService.updateCase(request)).thenReturn(response);
		ResponseEntity<ApiResponse> casewithdrawById = controller.caseWithdraw(request);
		assertEquals(HttpStatus.OK, casewithdrawById.getStatusCode());

	}

	@Test
	void handleAcceptOrRejectTest() throws SQLDataAccessException, AccountNotFoundException,
			InvalidOrganisationException, UnAuthorisedException, IOException, JSONException, ParseException,
			OrganizationNotFoundException, MandatoryFieldException, InputValidationException, MailJetServiceException {

		GenericResponse response = new GenericResponse();
		AcceptRejectRequest request = new AcceptRejectRequest();
		request.setComment("Incid");
		response.setStatus("");
		when(validateUserSession.isValidSession()).thenReturn(true);
		when(userBean.getRoles()).thenReturn(List.of("Individual Complainant"));
		when(userBean.getRoles()).thenReturn(List.of("Organisation Complainant"));

		when(acceptRejectHelper.handleRequest(request)).thenReturn(response);
		ResponseEntity<GenericResponse> casewithdrawById = controller.handleAcceptOrReject(request);
		assertEquals(HttpStatus.OK, casewithdrawById.getStatusCode());

	}

	@Test
	void getSummaryDetailsForDownloadTest() throws SQLDataAccessException, AccountNotFoundException,
			InvalidOrganisationException, UnAuthorisedException, IOException, JSONException, ParseException,
			OrganizationNotFoundException, MandatoryFieldException, InputValidationException, MailJetServiceException {

		CaseSummaryRes response = new CaseSummaryRes();
		CaseDetailsByIdReq request = new CaseDetailsByIdReq();
		request.setIncidentid("Incid");
		response.setStatus("");
		when(validateUserSession.isValidSession()).thenReturn(true);
		when(userBean.getRoles()).thenReturn(List.of("Individual Complainant"));
		when(userBean.getRoles()).thenReturn(List.of("Organisation Complainant"));

		when(caseSummaryService.getCaseSummary(request)).thenReturn(response);
		ResponseEntity<CaseSummaryRes> casewithdrawById = controller.getSummaryDetailsForDownload(request);
		assertEquals(HttpStatus.OK, casewithdrawById.getStatusCode());

	}

	@Test
	void getCaseOutcomeForDownloadTest() throws SQLDataAccessException, AccountNotFoundException,
			InvalidOrganisationException, UnAuthorisedException, IOException, JSONException, ParseException,
			OrganizationNotFoundException, MandatoryFieldException, InputValidationException, MailJetServiceException {

		CaseOutcomeByIdRes response = new CaseOutcomeByIdRes();
		CaseOutcomeByIdReq request = new CaseOutcomeByIdReq();
		request.setIncidentid("Incid");
		response.setStatus("");
		when(validateUserSession.isValidSession()).thenReturn(true);
		
		when(userBean.getRoles()).thenReturn(List.of("Organisation Complainant"));
when(userBean.getRoles()).thenReturn(List.of("Individual Complainant"));
		when(caseOutcomeByIdService.getCaseOutcomeById(request)).thenReturn(response);
		ResponseEntity<CaseOutcomeByIdRes> casewithdrawById = controller.getCaseOutcomeForDownload(request);
		assertEquals(HttpStatus.OK, casewithdrawById.getStatusCode());

	}

	@Test
	void getCaseDocumentDetailsForDownloadTest() throws SQLDataAccessException, AccountNotFoundException,
			InvalidOrganisationException, UnAuthorisedException, IOException, JSONException, ParseException,
			OrganizationNotFoundException, MandatoryFieldException, InputValidationException, MailJetServiceException {

		CaseDocumentFrDownloadRes response = new CaseDocumentFrDownloadRes();
		CaseFileFrDownloadReq request = new CaseFileFrDownloadReq();
		request.setCaseId("Incid");
		response.setStatus("");
		when(validateUserSession.isValidSession()).thenReturn(true);
		when(userBean.getRoles()).thenReturn(List.of("Individual Complainant"));
		when(userBean.getRoles()).thenReturn(List.of("Organisation Complainant"));

		when(caseDetailDownloadService.getCaseDocumentDetailsFrDownload(request)).thenReturn(response);
		ResponseEntity<CaseDocumentFrDownloadRes> casewithdrawById = controller
				.getCaseDocumentDetailsForDownload(request);
		assertEquals(HttpStatus.OK, casewithdrawById.getStatusCode());

	}
	
	@Test
	void getConversationMessageDetailsForDownloadTest() throws SQLDataAccessException, AccountNotFoundException,
			InvalidOrganisationException, UnAuthorisedException, IOException, JSONException, ParseException,
			OrganizationNotFoundException, MandatoryFieldException, InputValidationException, MailJetServiceException {

		CaseMessagingFrDownloadRes response = new CaseMessagingFrDownloadRes();
		CaseDetailsByIdReq request = new CaseDetailsByIdReq();
		request.setIncidentid("Incid");
		response.setStatus("");
		when(validateUserSession.isValidSession()).thenReturn(true);
		when(userBean.getRoles()).thenReturn(List.of("Individual Complainant"));
		when(userBean.getRoles()).thenReturn(List.of("Organisation Complainant"));

		when(caseDetailDownloadService.getCaseConversationDetailsFrDownload(request)).thenReturn(response);
		ResponseEntity<CaseMessagingFrDownloadRes> casewithdrawById = controller
				.getConversationMessageDetailsForDownload(request);
		assertEquals(HttpStatus.OK, casewithdrawById.getStatusCode());

	}
	
	@Test
	void getCaseByCasePreferenceTest() throws SQLDataAccessException, AccountNotFoundException,
			InvalidOrganisationException, UnAuthorisedException, IOException, JSONException, ParseException,
			OrganizationNotFoundException, MandatoryFieldException, InputValidationException, MailJetServiceException {

		CaseByCaseReferenceRes response = new CaseByCaseReferenceRes();
		CaseByCaseReferenceReq request = new CaseByCaseReferenceReq();
		request.setCasefererence("Incid");
		response.setStatus("");
		when(validateUserSession.isValidSession()).thenReturn(true);
		when(userBean.getRoles()).thenReturn(List.of("Individual Complainant"));
		when(userBean.getRoles()).thenReturn(List.of("Organisation Complainant"));

		when(caseByCaseReferenceService.getCaseIncidentidByCaseReference(request)).thenReturn(response);
		ResponseEntity<CaseByCaseReferenceRes> casewithdrawById = controller
				.getCaseByCasePreference(request);
		assertEquals(HttpStatus.OK, casewithdrawById.getStatusCode());

	}
	
	@Test
	void getHealthCheckTest() throws SQLDataAccessException, AccountNotFoundException,
			InvalidOrganisationException, UnAuthorisedException, IOException, JSONException, ParseException,
			OrganizationNotFoundException, MandatoryFieldException, InputValidationException, MailJetServiceException {

		GenericResponse response = new GenericResponse();
		response.setStatus("");

		ResponseEntity<GenericResponse> casewithdrawById = controller
				.getHealthCheck();
		assertEquals(HttpStatus.OK, casewithdrawById.getStatusCode());

	}

}
