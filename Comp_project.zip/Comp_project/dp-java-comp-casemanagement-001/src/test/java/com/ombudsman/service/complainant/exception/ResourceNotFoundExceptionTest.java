package com.ombudsman.service.complainant.exception;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.test.context.junit.jupiter.SpringExtension;


@ExtendWith(SpringExtension.class)
class ResourceNotFoundExceptionTest {
	
	
	 @Test
		void testResourceNotFoundException() {
			String ex = "Caught Exception";

			ResourceNotFoundException exception = new ResourceNotFoundException(ex);

			assertEquals("Caught Exception", exception.getMessage());
		}

}
