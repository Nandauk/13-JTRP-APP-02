package com.ombudsman.service.complainant.model;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

import com.ombudsman.service.complainant.model.CaseWithdraw;

class UpdateCaseTest {

    @Test
    void testGettersAndSetters() {
        CaseWithdraw uc = new CaseWithdraw();

        uc.setCaseId("CASE-111");
        assertEquals("CASE-111", uc.getCaseId());

        uc.setComments("Some comments");
        assertEquals("Some comments", uc.getComments());

        uc.setDetails("Details here");
        assertEquals("Details here", uc.getDetails());

        uc.setReasonForChange("caseWithdraw");
        assertEquals("caseWithdraw", uc.getReasonForChange());

        uc.setPackageId("PKG-888");
        assertEquals("PKG-888", uc.getPackageId());

        String[] accIds = {"ACC1", "ACC2"};
        uc.setUsersAccountIds(accIds);
        assertArrayEquals(accIds, uc.getUsersAccountIds());

        uc.setDigitalPortalUserName("dpUser");
        assertEquals("dpUser", uc.getDigitalPortalUserName());

        uc.setDigitalPortalUserEmailAddress("dpUser@example.com");
        assertEquals("dpUser@example.com", uc.getDigitalPortalUserEmailAddress());

        uc.setContactId("CONT-123");
        assertEquals("CONT-123", uc.getContactId());

        uc.setIsRespondent("true");
        assertEquals("true", uc.getIsRespondent());
    }
}
