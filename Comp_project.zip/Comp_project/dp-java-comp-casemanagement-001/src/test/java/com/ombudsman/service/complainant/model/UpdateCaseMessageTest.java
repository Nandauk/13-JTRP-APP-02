package com.ombudsman.service.complainant.model;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

import com.ombudsman.service.complainant.model.UpdateCaseMessage;

class UpdateCaseMessageTest {

    @Test
    void testGettersAndSetters() {
        UpdateCaseMessage msg = new UpdateCaseMessage();

        msg.setIsRespondent("true");
        assertEquals("true", msg.getIsRespondent());

        msg.setContactId("CONTACT-123");
        assertEquals("CONTACT-123", msg.getContactId());

        msg.setDigitalPortalUserName("dpUser");
        assertEquals("dpUser", msg.getDigitalPortalUserName());

        msg.setDigitalPortalUserEmailAddress("dpUser@example.com");
        assertEquals("dpUser@example.com", msg.getDigitalPortalUserEmailAddress());

        msg.setCaseId("CASE-001");
        assertEquals("CASE-001", msg.getCaseId());

        msg.setComments("Some comments here");
        assertEquals("Some comments here", msg.getComments());

        msg.setDetails("Case details info");
        assertEquals("Case details info", msg.getDetails());

        msg.setReasonForChange(100L);
        assertEquals(100L, msg.getReasonForChange());

        msg.setUserId("USER-XYZ");
        assertEquals("USER-XYZ", msg.getUserId());

        msg.setPackageId("PKG-999");
        assertEquals("PKG-999", msg.getPackageId());

        String[] accountIds = {"ACC1", "ACC2"};
        msg.setUsersAccountIds(accountIds);
        assertArrayEquals(accountIds, msg.getUsersAccountIds());
    }
}
