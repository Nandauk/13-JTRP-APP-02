package com.ombudsman.service.complainant.exception;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

class CaseManagementInvalidEventNameExceptionTest {
	
	 @Test
	    void testException() {
	        String message = "Test exception";
	        String exceptionMessage = "Test exception message";
	        StackTraceElement[] stackTraceElements = new StackTraceElement[0];

	        CaseManagementInvalidEventNameException exception = new CaseManagementInvalidEventNameException(message, exceptionMessage, stackTraceElements);

	        assertEquals(message, exception.getMessage());
	        assertEquals(exceptionMessage, exception.getExceptionMessage());
	    }

}
