package com.ombudsman.service.complainant.model.dto;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.ombudsman.service.complainant.model.dto.CaseOutcomeDto;

import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(SpringExtension.class)
public class CaseOutcomeDtoTest {
	@InjectMocks
    private CaseOutcomeDto caseOutcomeDto;

    @BeforeEach
    public void setUp() {
        caseOutcomeDto = new CaseOutcomeDto();
    }

    @Test
    public void testGetterAndSetter() {
        
        caseOutcomeDto.setFos_case("CASE123");
        caseOutcomeDto.setFos_offeroroutcomeid("OFFER123");
        caseOutcomeDto.setFos_type("TYPE123");
        caseOutcomeDto.setFos_typename("Type Name");
        caseOutcomeDto.setFos_meritsjurisdictiondismissal("Dismissal123");
        caseOutcomeDto.setFos_meritsjurisdictiondismissalname("Dismissal Name");
        caseOutcomeDto.setFos_meritopinion("Opinion123");
        caseOutcomeDto.setFos_meritopinionname("Opinion Name");
        caseOutcomeDto.setFos_jurisdictioninout("Jurisdiction123");
        caseOutcomeDto.setFos_jurisdictioninoutname("Jurisdiction Name");
        caseOutcomeDto.setFos_dismissalreason("Reason123");
        caseOutcomeDto.setFos_withopinion("Opinion123");
        caseOutcomeDto.setFos_changeinoutcome("Change123");
        caseOutcomeDto.setFos_changeinoutcomename("Change Name");
        caseOutcomeDto.setFos_settlementbandid("Band123");
        caseOutcomeDto.setFos_settlementbandidname("Band Name");
        caseOutcomeDto.setFos_nonmonetarysettlement("Non-Monetary");
        caseOutcomeDto.setFos_troubleupsetamt("1000");
        caseOutcomeDto.setFos_complainantresponse("Response123");
        caseOutcomeDto.setFos_complainantresponsename("Response Name");
        caseOutcomeDto.setFos_respondentresponse("Respondent123");
        caseOutcomeDto.setFos_respondentresponse_txt("Respondent Text");
        caseOutcomeDto.setFos_outcomedispatcheddate("2025-01-10");
        caseOutcomeDto.setStatuscode("Status123");
        caseOutcomeDto.setFos_jurisdiction("Jurisdiction123");
        caseOutcomeDto.setFos_jurisdictionreason("Reason123");
        caseOutcomeDto.setFos_outcomedispatchedby("Dispatcher123");
        caseOutcomeDto.setFos_outcomedispatched("2025-01-10");
        caseOutcomeDto.setFos_settlementamount("5000");
        caseOutcomeDto.setFos_senttocomplainant("2025-01-09");
        caseOutcomeDto.setFos_othercomplaintbody("Other Body");
        caseOutcomeDto.setFos_senttorespondent("2025-01-08");
        caseOutcomeDto.setStatecode("State123");

        // Assert values
        assertEquals("CASE123", caseOutcomeDto.getFos_case());
        assertEquals("OFFER123", caseOutcomeDto.getFos_offeroroutcomeid());
        assertEquals("TYPE123", caseOutcomeDto.getFos_type());
        assertEquals("Type Name", caseOutcomeDto.getFos_typename());
        assertEquals("Dismissal123", caseOutcomeDto.getFos_meritsjurisdictiondismissal());
        assertEquals("Dismissal Name", caseOutcomeDto.getFos_meritsjurisdictiondismissalname());
        assertEquals("Opinion123", caseOutcomeDto.getFos_meritopinion());
        assertEquals("Opinion Name", caseOutcomeDto.getFos_meritopinionname());
        assertEquals("Jurisdiction123", caseOutcomeDto.getFos_jurisdictioninout());
        assertEquals("Jurisdiction Name", caseOutcomeDto.getFos_jurisdictioninoutname());
        assertEquals("Reason123", caseOutcomeDto.getFos_dismissalreason());
        assertEquals("Opinion123", caseOutcomeDto.getFos_withopinion());
        assertEquals("Change123", caseOutcomeDto.getFos_changeinoutcome());
        assertEquals("Change Name", caseOutcomeDto.getFos_changeinoutcomename());
        assertEquals("Band123", caseOutcomeDto.getFos_settlementbandid());
        assertEquals("Band Name", caseOutcomeDto.getFos_settlementbandidname());
        assertEquals("Non-Monetary", caseOutcomeDto.getFos_nonmonetarysettlement());
        assertEquals("1000", caseOutcomeDto.getFos_troubleupsetamt());
        assertEquals("Response123", caseOutcomeDto.getFos_complainantresponse());
        assertEquals("Response Name", caseOutcomeDto.getFos_complainantresponsename());
        assertEquals("Respondent123", caseOutcomeDto.getFos_respondentresponse());
        assertEquals("Respondent Text", caseOutcomeDto.getFos_respondentresponse_txt());
        assertEquals("2025-01-10", caseOutcomeDto.getFos_outcomedispatcheddate());
        assertEquals("Status123", caseOutcomeDto.getStatuscode());
        assertEquals("Jurisdiction123", caseOutcomeDto.getFos_jurisdiction());
        assertEquals("Reason123", caseOutcomeDto.getFos_jurisdictionreason());
        assertEquals("Dispatcher123", caseOutcomeDto.getFos_outcomedispatchedby());
        assertEquals("2025-01-10", caseOutcomeDto.getFos_outcomedispatched());
        assertEquals("5000", caseOutcomeDto.getFos_settlementamount());
        assertEquals("2025-01-09", caseOutcomeDto.getFos_senttocomplainant());
        assertEquals("Other Body", caseOutcomeDto.getFos_othercomplaintbody());
        assertEquals("2025-01-08", caseOutcomeDto.getFos_senttorespondent());
        assertEquals("State123", caseOutcomeDto.getStatecode());
    }
}
