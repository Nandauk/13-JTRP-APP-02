package com.ombudsman.service.complainant.exception;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

class MailJetServiceExceptionTest {	
	
	@Test
	void testExceptionMessage() {

	String message = "Mailjet Exception";

	MailJetServiceException ex = new MailJetServiceException(message);
	assertEquals(message, ex.getMessage());

}}
