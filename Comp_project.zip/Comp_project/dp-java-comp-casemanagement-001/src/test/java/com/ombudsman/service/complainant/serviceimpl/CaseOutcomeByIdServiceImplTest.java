package com.ombudsman.service.complainant.serviceimpl;

import static com.ombudsman.service.complainant.common.Constants.CASE_OUTCOMES_NOT_FOUND;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.security.auth.login.AccountNotFoundException;

import org.assertj.core.util.Lists;
import org.json.JSONException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.ombudsman.service.complainant.common.CommonUtil;
import com.ombudsman.service.complainant.common.UserBean;
import com.ombudsman.service.complainant.exception.AzureServiceException;
import com.ombudsman.service.complainant.exception.CaseOutComesNotFoundException;
import com.ombudsman.service.complainant.exception.SQLDataAccessException;
import com.ombudsman.service.complainant.exception.UnAuthorisedException;
import com.ombudsman.service.complainant.model.dto.CaseOutcomeDto;
import com.ombudsman.service.complainant.model.request.CaseOutcomeByIdReq;
import com.ombudsman.service.complainant.model.response.CaseOutcomeByIdRes;
import com.ombudsman.service.complainant.repository.dao.CaseDetailsDao;
import com.ombudsman.service.complainant.service.CaseOutcomeByIdService;
import com.ombudsman.service.complainant.serviceimpl.CaseOutcomeByIdServiceImpl;

@ExtendWith(SpringExtension.class)
public class CaseOutcomeByIdServiceImplTest {

	@InjectMocks
	private CaseOutcomeByIdServiceImpl caseOutcomeByIdServiceImpl;

	@Mock
	UserBean userbean;

	@Mock
	private CommonUtil mMockCommonUtil;

	@Mock
	CaseOutcomeByIdService mMockCaseOutcomeByIdService;

	@Mock
	CaseDetailsDao mMockcaseDetailsDao;

	@Mock
	private CaseOutcomeByIdReq mMockCaseOutcomeByIdReq;

	private static List<String> groupIds = new ArrayList<>();

	@BeforeEach
	void setUp() {
		groupIds.add("groupId1");
		groupIds.add("groupId2");
		when(userbean.getGroups()).thenReturn(groupIds);

		when(mMockCommonUtil.isValidInput("Test@1234")).thenReturn(true);
	}

	@DisplayName("GetCaseOutcomeUserUnauthorised")
	@Test
	void GetCaseOutcomeUserUnauthorised()
			throws AzureServiceException, JSONException, IOException, SQLDataAccessException, AccountNotFoundException, UnAuthorisedException {

		final String accIds = "acctId1,acctId2";
		final Map<String, Object> caseOutcomeDetails = new HashMap<>();
		CaseOutcomeDto caseOutDto = new CaseOutcomeDto();
		caseOutDto.setFos_case("testCaseId");
		caseOutcomeDetails.put("#result-set-1", Lists.newArrayList(caseOutDto));

		when(mMockCaseOutcomeByIdReq.getIncidentid()).thenReturn("Test@1234");
		when(mMockcaseDetailsDao.getOfferOutcomes("Test@1234")).thenReturn(caseOutcomeDetails);
		//CaseOutcomeByIdRes result = caseOutcomeByIdServiceImpl.getCaseOutcomeById(mMockCaseOutcomeByIdReq);

		//assertEquals("user_unauthorized", result.getMessage());

	}

	@DisplayName("GetCaseOutcomeInvalidIncidentId_Failed")
	@Test
	void GetCaseOutcomeInvalidIncidentIdFailed()
			throws AzureServiceException, JSONException, IOException, SQLDataAccessException, AccountNotFoundException {

		when(mMockCaseOutcomeByIdReq.getIncidentid()).thenReturn(null);

		try {
			CaseOutcomeByIdRes result = caseOutcomeByIdServiceImpl.getCaseOutcomeById(mMockCaseOutcomeByIdReq);
			assertNotNull(result);
			assertEquals("IncidentID is  an invalid field", result.getMessage());
		} catch (Exception e) {
			// TODO: handle exception
		}

	}

	@DisplayName("GetCaseOutcome_Failed")
	@Test
	void GetCaseOutcomeFailed()
			throws AzureServiceException, JSONException, IOException, SQLDataAccessException, AccountNotFoundException {

		when(mMockCaseOutcomeByIdReq.getIncidentid()).thenReturn(null);

		try {
			CaseOutcomeByIdRes result = caseOutcomeByIdServiceImpl.getCaseOutcomeById(mMockCaseOutcomeByIdReq);
			assertNotNull(result);
			assertEquals("IncidentID is  an invalid field", result.getMessage());
		} catch (Exception e) {
			// TODO: handle exception
		}

	}

	@DisplayName("GetCaseOutcomeImpl_Failed")
	@Test
	void GetCaseOutcomeImplFailed()
			throws AzureServiceException, JSONException, IOException, SQLDataAccessException, AccountNotFoundException {

		when(mMockCaseOutcomeByIdReq.getIncidentid()).thenReturn("Test@1234");
		try {
			CaseOutcomeByIdRes result = caseOutcomeByIdServiceImpl.getCaseOutcomeById(mMockCaseOutcomeByIdReq);
			assertNotNull(result);

		} catch (Exception e) {
			// TODO: handle exception
		}

	}

	@DisplayName("GetCaseOutcomeImpl_Success")
	@Test
	void GetCaseOutcomeImplSuccess()
			throws AzureServiceException, JSONException, IOException, SQLDataAccessException, AccountNotFoundException {

		when(mMockCaseOutcomeByIdReq.getIncidentid()).thenReturn("Test@1234");
		final Map<String, Object> caseOutcomeDetails = new HashMap<>();
		CaseOutcomeDto caseOutDto = new CaseOutcomeDto();
		caseOutDto.setFos_case("testCaseId");
		caseOutcomeDetails.put("#result-set-1", Lists.newArrayList(caseOutDto));

		when(mMockCaseOutcomeByIdReq.getIncidentid()).thenReturn("Test@1234");
		when(Optional
				.ofNullable(mMockcaseDetailsDao.getOfferOutcomes("Test@123"))
				.orElseThrow(() -> new CaseOutComesNotFoundException(CASE_OUTCOMES_NOT_FOUND))).thenReturn(caseOutcomeDetails);

		try {
			CaseOutcomeByIdRes result = caseOutcomeByIdServiceImpl.getCaseOutcomeById(mMockCaseOutcomeByIdReq);
			assertNotNull(result);

		} catch (Exception e) {
			// TODO: handle exception
		}

	}
}
