package com.ombudsman.service.complainant.model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

class UserRequestBodyTest {
	@Test
	void testGettersAndSetters() {
		String emailId = "test@gmail.com";
		String fullName = "Test User";
		String templateName = "Test Template";
		int templateID = 123;
		
		UserRequestBody userbody = new UserRequestBody();
		userbody.setEmailId(emailId);
		userbody.setFullName(fullName);
		userbody.setTemplateName(templateName);
		userbody.setTemplateID(templateID);
		
		assertEquals(emailId, userbody.getEmailId());
		assertEquals(fullName, userbody.getFullName());
		assertEquals(templateName, userbody.getTemplateName());
		assertEquals(templateID, userbody.getTemplateID());
	}

}
