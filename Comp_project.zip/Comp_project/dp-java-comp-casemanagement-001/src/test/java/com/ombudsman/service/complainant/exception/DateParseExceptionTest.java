package com.ombudsman.service.complainant.exception;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

class DateParseExceptionTest {	
	
	@Test
	void testExceptionMessage() {

	String message = "Error while parsing Date";

	DateParseException ex = new DateParseException(message);
	assertEquals(message, ex.getMessage());

}}
