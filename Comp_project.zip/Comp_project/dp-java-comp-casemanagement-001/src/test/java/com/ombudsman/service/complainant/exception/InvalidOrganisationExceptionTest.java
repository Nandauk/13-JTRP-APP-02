package com.ombudsman.service.complainant.exception;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

class InvalidOrganisationExceptionTest {	
	
	@Test
	void testExceptionMessage() {

	String message = "Invalid Organisation";

	InvalidOrganisationException ex = new InvalidOrganisationException(message);
	assertEquals(message, ex.getMessage());

}}
