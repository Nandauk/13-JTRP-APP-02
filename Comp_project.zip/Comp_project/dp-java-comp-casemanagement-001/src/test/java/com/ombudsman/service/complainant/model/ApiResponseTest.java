package com.ombudsman.service.complainant.model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.springframework.http.HttpStatus;

public class ApiResponseTest {

	@Test
	void testApiResponseGettersAndSetters() {
		ApiResponse apiResp = new ApiResponse();

		apiResp.setSuccess(true);
		assertEquals(true, apiResp.isSuccess());

		apiResp.setMessage("Test Message");
		assertEquals("Test Message", apiResp.getMessage());

		apiResp.setStatus(HttpStatus.OK);
		assertEquals(HttpStatus.OK, apiResp.getStatus());

		apiResp.setData(new String("Hello"));
		assertEquals(new String("Hello"), apiResp.getData());
	}

}
