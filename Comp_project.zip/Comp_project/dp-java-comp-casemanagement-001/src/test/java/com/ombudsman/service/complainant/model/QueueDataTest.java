package com.ombudsman.service.complainant.model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

class QueueDataTest {
	@Test
	void testGettersAndSetters() {
		String queueid = "Queue123";
		String description = "Test Description";
		String name = "Name123";
		String _ownerid_value = "Owner123";

		QueueData queuedata = new QueueData();
		queuedata.setQueueid(queueid);
		queuedata.setDescription(description);
		queuedata.setName(name);
		queuedata.setOwneridValue(_ownerid_value);

		assertEquals(queueid, queuedata.getQueueid());
		assertEquals(description, queuedata.getDescription());
		assertEquals(name, queuedata.getName());
		assertEquals(_ownerid_value, queuedata.getOwneridValue());

	}

}
