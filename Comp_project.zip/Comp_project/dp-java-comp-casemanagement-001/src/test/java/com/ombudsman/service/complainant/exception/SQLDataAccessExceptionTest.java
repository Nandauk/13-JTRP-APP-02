package com.ombudsman.service.complainant.exception;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

class SQLDataAccessExceptionTest {	
	
	@Test
	void testExceptionMessage() {

	String message = "SQL Data Accessexception";

	SQLDataAccessException ex = new SQLDataAccessException(message);
	assertEquals(message, ex.getMessage());

}

}
