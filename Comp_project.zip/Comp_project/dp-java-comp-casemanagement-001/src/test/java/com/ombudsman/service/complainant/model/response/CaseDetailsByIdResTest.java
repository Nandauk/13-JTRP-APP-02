package com.ombudsman.service.complainant.model.response;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;

import java.util.List;

import org.assertj.core.util.Arrays;
import org.junit.jupiter.api.Test;

import com.ombudsman.service.complainant.model.CaseDetail;

public class CaseDetailsByIdResTest {
	
	@Test
	public void testGetAndSetCaseDetails() {
		CaseDetailsByIdRes res = new CaseDetailsByIdRes();
		CaseDetail mockCaseDetail = mock(CaseDetail.class);
		
		res.setCasedetails(mockCaseDetail);
		assertEquals(mockCaseDetail, res.getCasedetails());
	}
	
	@Test
	public void testGetAndSetCaseParties()
	{
		CaseDetailsByIdRes res = new CaseDetailsByIdRes();
		CasePartiesDetail party1 = mock(CasePartiesDetail.class);
		CasePartiesDetail party2 = mock(CasePartiesDetail.class);
		//List<CasePartiesDetail> parties = Arrays.asList(party1,party2);
	}

}
