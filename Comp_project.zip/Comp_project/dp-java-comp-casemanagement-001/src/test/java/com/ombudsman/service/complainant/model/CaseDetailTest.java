package com.ombudsman.service.complainant.model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

public class CaseDetailTest {
	
	@Test
	void testCaseDetailGettersAndSetters()
	{
		 String incidentid = "Test Incident"; 
		 String title = "Test Title";
		 String ticketnumber = "TRN123";
		 String fos_crn = "Test FOSCRN";
		 String fos_complaintissue = "Test Complaint";
		 String fos_complaintissuename = "Test Complaint Issue Name";
		 String fos_productorproductfamily = "Test Productor Family";
		 String fos_productorproductfamilyname = "Test Productor Family Name";
		 String fos_casestage = "Test Case Stage";
		 String fos_casestagename = "Test Case Stage Name";
		 String statuscode = "Test Status Code";
		 String statuscodename = "Test Status Code Name";
		 String caseage = "Test Case Age";
		 String fos_representatives = "Test FOS Representatives";
		 String fos_datecasefirstmovedtoinvestigation = "17-06-2025";
		 String fos_datebusinessfilereceived ="17-06-2025";
		 String fos_prioritycode = "Test Priority Code";
		 String fos_prioritycodename = "Test Priority Code Name";
		 String statecode = "Test State Code";
		 String fos_caseprogress = "Test Case Progess";
		 String fos_caseprogress_name = "Test Case Progess";
		 String customerid = "Test Customer Id";
		 String customeridname = "Test Customer Id Name";
		 String fos_dateofconversion  = "17-06-2025";
		 String fos_dateofreferral  = "17-06-2025";
		 String ownerid = "Test Owner Id";
		 String contactid = "Test Owner Id Name";
		 
		 CaseDetail caseTest = new CaseDetail();
		 caseTest.setIncidentid(incidentid);
		 caseTest.setTitle(title);
		 caseTest.setTicketnumber(ticketnumber);
		 caseTest.setFos_crn(fos_crn);
		 caseTest.setFos_complaintissue(fos_complaintissue);
		 caseTest.setFos_complaintissuename(fos_complaintissuename);
		 caseTest.setFos_productorproductfamily(fos_productorproductfamily);
		 caseTest.setFos_productorproductfamilyname(fos_productorproductfamilyname);
		 caseTest.setFos_casestage(fos_casestage);
		 caseTest.setFos_casestagename(fos_casestagename);
		 caseTest.setStatuscode(statuscode);
		 caseTest.setStatuscodename(statuscodename);
		 caseTest.setCaseage(caseage);
		 caseTest.setFos_representatives(fos_representatives);
		 caseTest.setFos_datecasefirstmovedtoinvestigation(fos_datecasefirstmovedtoinvestigation);
		 caseTest.setFos_datebusinessfilereceived(fos_datebusinessfilereceived);
		 caseTest.setFos_prioritycode(fos_prioritycode);
		 caseTest.setFos_prioritycodename(fos_prioritycodename);
		 caseTest.setStatecode(statecode);
		 caseTest.setFos_caseprogress(fos_caseprogress);
		 caseTest.setFos_caseprogress_name(fos_caseprogress_name);
		 caseTest.setCustomerid(customerid);
		 caseTest.setCustomeridname(customeridname);
		 caseTest.setFos_dateofconversion(fos_dateofconversion);
		 caseTest.setFos_dateofreferral(fos_dateofreferral);
		 caseTest.setOwnerid(ownerid);
		 caseTest.setContactid(contactid);
		 
		 assertEquals(incidentid, caseTest.getIncidentid());
		 assertEquals(title, caseTest.getTitle());
		 assertEquals(ticketnumber, caseTest.getTicketnumber());
		 assertEquals(fos_crn, caseTest.getFos_crn());
		 assertEquals(fos_complaintissue, caseTest.getFos_complaintissue());
		 assertEquals(fos_complaintissuename, caseTest.getFos_complaintissuename());
		 assertEquals(fos_productorproductfamily, caseTest.getFos_productorproductfamily());
		 assertEquals(fos_productorproductfamilyname, caseTest.getFos_productorproductfamilyname());	 
		 assertEquals(fos_casestage, caseTest.getFos_casestage());
		 assertEquals(fos_casestagename, caseTest.getFos_casestagename());
		 assertEquals(statuscode, caseTest.getStatuscode());
		 assertEquals(statuscodename, caseTest.getStatuscodename());
		 assertEquals(caseage, caseTest.getCaseage());
		 assertEquals(fos_representatives, caseTest.getFos_representatives());
		 assertEquals(fos_datecasefirstmovedtoinvestigation, caseTest.getFos_datecasefirstmovedtoinvestigation());
		 assertEquals(fos_datebusinessfilereceived, caseTest.getFos_datebusinessfilereceived());		 
		 assertEquals(fos_prioritycode, caseTest.getFos_prioritycode());
		 assertEquals(fos_prioritycodename, caseTest.getFos_prioritycodename());
		 assertEquals(statecode, caseTest.getStatecode());
		 assertEquals(fos_caseprogress, caseTest.getFos_caseprogress());
		 assertEquals(fos_caseprogress_name, caseTest.getFos_caseprogress_name());
		 assertEquals(customerid, caseTest.getCustomerid());
		 assertEquals(customeridname, caseTest.getCustomeridname());
		 assertEquals(fos_dateofconversion, caseTest.getFos_dateofconversion());
		 assertEquals(fos_dateofreferral, caseTest.getFos_dateofreferral());
		 assertEquals(ownerid, caseTest.getOwnerid());
		 assertEquals(contactid, caseTest.getContactid());
		 
	}

}
