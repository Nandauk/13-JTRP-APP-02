package com.ombudsman.service.complainant.exception;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

class MandatoryFieldExceptionTest {	
	
	@Test
	void testExceptionMessage() {

	String message = "Mandatory exception";

	MandatoryFieldException ex = new MandatoryFieldException(message);
	assertEquals(message, ex.getMessage());

}

}
