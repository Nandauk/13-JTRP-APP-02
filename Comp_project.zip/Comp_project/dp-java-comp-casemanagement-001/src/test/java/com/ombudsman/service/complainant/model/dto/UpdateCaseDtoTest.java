package com.ombudsman.service.complainant.model.dto;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.ombudsman.service.complainant.model.dto.UpdateCaseDto;

import java.time.OffsetDateTime;
import static org.junit.jupiter.api.Assertions.*;
@ExtendWith(SpringExtension.class)
public class UpdateCaseDtoTest {
	@InjectMocks
    private UpdateCaseDto updateCaseDto;

    @BeforeEach
    public void setUp() {
        updateCaseDto = new UpdateCaseDto();
    }

    @Test
    public void testGetterAndSetter() {
        // Set values
        updateCaseDto.setId(1);
        updateCaseDto.setCase_id("CASE123");
        updateCaseDto.setComments("This is a comment.");
        updateCaseDto.setDetails("These are the details.");
        updateCaseDto.setReason_for_change(1001);
        updateCaseDto.setUser_id("USER123");
        updateCaseDto.setPackage_id("PKG123");
        updateCaseDto.setCreated(OffsetDateTime.now());

        // Assert values
        assertEquals(1, updateCaseDto.getId());
        assertEquals("CASE123", updateCaseDto.getCase_id());
        assertEquals("This is a comment.", updateCaseDto.getComments());
        assertEquals("These are the details.", updateCaseDto.getDetails());
        assertEquals(1001L, updateCaseDto.getReason_for_change());
        assertEquals("USER123", updateCaseDto.getUser_id());
        assertEquals("PKG123", updateCaseDto.getPackage_id());
        assertNotNull(updateCaseDto.getCreated());
    }
}
