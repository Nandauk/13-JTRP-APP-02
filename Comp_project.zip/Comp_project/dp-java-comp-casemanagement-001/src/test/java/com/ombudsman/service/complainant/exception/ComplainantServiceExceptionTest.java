package com.ombudsman.service.complainant.exception;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

class ComplainantServiceExceptionTest {

	@Test
	 void testConstructor() {
		String message = "Test exception";
		String code = "123";
		String exceptionMessage = "Test exception message";

		ComplainantServiceException exception = new ComplainantServiceException(message, code, exceptionMessage);

		assertEquals(message, exception.getMessage());
		assertEquals(code, exception.getCode());
		assertEquals(exceptionMessage, exception.getExceptionMessage());
	}

}
