package com.ombudsman.service.complainant.exception;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

class OrganisationIdMissingExceptionTest {	
	
	@Test
	void testExceptionMessage() {

	String message = "Organisation Id Missing";

	OrganisationIdMissingException ex = new OrganisationIdMissingException(message);
	assertEquals(message, ex.getMessage());

}

}
