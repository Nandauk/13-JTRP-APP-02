package com.ombudsman.service.complainant.exception;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

class PhoenixServiceExceptionTest {	
	
	@Test
	void testExceptionMessage() {

	String message = "Mandatory Field Missing exception";
	String exceptionMessage = "Exception Occured";

	PhoenixServiceException ex = new PhoenixServiceException(message,exceptionMessage);
	assertEquals(message, ex.getMessage());
	assertEquals(exceptionMessage, ex.getExceptionMessage());
}

}
