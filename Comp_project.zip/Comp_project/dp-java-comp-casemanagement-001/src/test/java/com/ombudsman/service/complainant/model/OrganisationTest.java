package com.ombudsman.service.complainant.model;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertSame;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;

import com.ombudsman.service.complainant.model.Organisation;
import com.ombudsman.service.complainant.model.Respondents;

class OrganisationTest {

    @Test
    void testGettersAndSetters() {
        Organisation org = new Organisation();

        org.setName("OrgName");
        assertEquals("OrgName", org.getName());

        org.setFos_fcareference("FCA-Ref");
        assertEquals("FCA-Ref", org.getFos_fcareference());

        org.setFos_hierarchylevel("Group");
        assertEquals("Group", org.getFos_hierarchylevel());

        org.setLegalentityname("LegalEntity");
        assertEquals("LegalEntity", org.getLegalentityname());

        org.setAccountnumber("PhoenixID-001");
        assertEquals("PhoenixID-001", org.getAccountnumber());

        org.setAccountid("ACC-999");
        assertEquals("ACC-999", org.getAccountid());

        org.set_parentaccountid_value("PARENT-ACC");
        assertEquals("PARENT-ACC", org.get_parentaccountid_value());

        org.setAccountcategorycode("Capacity-Code");
        assertEquals("Capacity-Code", org.getAccountcategorycode());

        org.setBusinesstypecode("BusinessType-X");
        assertEquals("BusinessType-X", org.getBusinesstypecode());

        org.setFos_approvalstatus("Approved");
        assertEquals("Approved", org.getFos_approvalstatus());

        
        List<Respondents> respondentsList = new ArrayList<>();
        org.setRespondents(respondentsList);
        assertSame(respondentsList, org.getRespondents());
    }
}
