package com.ombudsman.service.complainant.model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

class SubjectAndCatCodeTest {
	@Test
	void testGettersAndSetters() {
		String subject = "Test Subject";
		int categoryCode = 123;
		
		SubjectAndCatCode subCode = new SubjectAndCatCode();
		subCode.setSubject(subject);
		subCode.setCategoryCode(categoryCode);
		
		assertEquals(subject, subCode.getSubject());
		assertEquals(categoryCode, subCode.getCategoryCode());
	}

}
