package com.ombudsman.service.complainant.exception;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.springframework.test.context.junit.jupiter.SpringExtension;


@ExtendWith(SpringExtension.class)
class AzureServiceExceptionTest {

	@InjectMocks
	AzureServiceException AzureServiceException;
	
	 @Test
	     void testConstructor() {
	        String message = "Test message";
	        String exceptionMessage = "Test exception message";
	        AzureServiceException exception = new AzureServiceException(message, exceptionMessage);

	        assertEquals(message, exception.getMessage());
	        assertEquals("COMPLAINANT_AZURE_1000", exception.getCode());
	        assertEquals(exceptionMessage, exception.getExceptionMessage());
	    }
}

