package com.ombudsman.service.complainant.model.dto;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.ombudsman.service.complainant.model.dto.NotificationModel;

import static org.junit.jupiter.api.Assertions.*;

public class NotificationModelTest {

    private NotificationModel notificationModel;

    @BeforeEach
    public void setUp() {
        notificationModel = new NotificationModel();
    }

    @Test
    public void testGetterAndSetter() {
        // Set values
        Long notificationId = 1L;
        String requestId = "REQ123";
        String userOid = "USER123";
        String requestingActivityName = "Activity Name";
        String message = "This is a message.";
        String notificationStatusId = "STATUS123";
        String notificationStatusDescription = "Notification Status Description";
        String fileDownloadUrl = "http://example.com/download";
        String modifiedBy = "User123";
        String createdOn = "2025-01-10";
        String createdBy = "Admin";
        String modifiedOn = "2025-01-11";

        notificationModel.setNotification_id(notificationId);
        notificationModel.setRequest_id(requestId);
        notificationModel.setUser_oid(userOid);
        notificationModel.setRequesting_activity_name(requestingActivityName);
        notificationModel.setMessage(message);
        notificationModel.setNotification_status_id(notificationStatusId);
        notificationModel.setNotification_status_description(notificationStatusDescription);
        notificationModel.setFile_download_url(fileDownloadUrl);
        notificationModel.setModified_by(modifiedBy);
        notificationModel.setCreated_on(createdOn);
        notificationModel.setCreated_by(createdBy);
        notificationModel.setModified_on(modifiedOn);

        // Assert values
        assertEquals(notificationId, notificationModel.getNotification_id());
        assertEquals(requestId, notificationModel.getRequest_id());
        assertEquals(userOid, notificationModel.getUser_oid());
        assertEquals(requestingActivityName, notificationModel.getRequesting_activity_name());
        assertEquals(message, notificationModel.getMessage());
        assertEquals(notificationStatusId, notificationModel.getNotification_status_id());
        assertEquals(notificationStatusDescription, notificationModel.getNotification_status_description());
        assertEquals(fileDownloadUrl, notificationModel.getFile_download_url());
        assertEquals(modifiedBy, notificationModel.getModified_by());
        assertEquals(createdOn, notificationModel.getCreated_on());
        assertEquals(createdBy, notificationModel.getCreated_by());
        assertEquals(modifiedOn, notificationModel.getModified_on());
    }
}
