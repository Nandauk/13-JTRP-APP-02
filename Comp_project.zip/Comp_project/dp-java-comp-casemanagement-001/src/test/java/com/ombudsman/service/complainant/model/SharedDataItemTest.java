package com.ombudsman.service.complainant.model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

class SharedDataItemTest {

	@Test
	void testGettersAndSetters() {
		String name = "Test Name" ;
	    String code = "Test Code" ;
	    
	    SharedDataItem item = new SharedDataItem();
	    item.setCode(code);
	    item.setName(name);
	    
	    assertEquals(name, item.getName());
	    assertEquals(code, item.getCode());
	}
}
