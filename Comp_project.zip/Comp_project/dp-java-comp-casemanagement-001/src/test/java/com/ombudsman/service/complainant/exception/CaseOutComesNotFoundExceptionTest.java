package com.ombudsman.service.complainant.exception;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

class CaseOutComesNotFoundExceptionTest {
	@Test
	void testExceptionMessage() {

		String message = "Case Outcomes Not Found";

		CaseOutComesNotFoundException ex = new CaseOutComesNotFoundException(message);
		assertEquals(message, ex.getMessage());

	}

}
