package com.ombudsman.service.complainant.exception;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

class InputValidationExceptionTest {
	
	 @Test
	    void testException() {
	        String message = "Test exception";
	        String exceptionMessage = "Test exception message";
	        String code = "Complainant_USER_1000";

	        InputValidationException exception = new InputValidationException(message, code,exceptionMessage);

	        assertEquals(message, exception.getMessage());
	        assertEquals(exceptionMessage, exception.getExceptionMessage());
	        assertEquals(code, exception.getCode());
	    }

}
