package com.ombudsman.service.complainant.model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

class DrupalApiResponseTest {
	@Test
	void testGettersAndSetters() {
		String templateName = "Temp123";
		String categories = "Category123";
		String templateId = "123456";

		DrupalApiResponse drupResp = new DrupalApiResponse();
		drupResp.setTemplateName(templateName);
		drupResp.setCategories(categories);
		drupResp.setTemplateId(templateId);

		assertEquals(templateName, drupResp.getTemplateName());
		assertEquals(categories, drupResp.getCategories());
		assertEquals(templateId, drupResp.getTemplateId());
	}
}
