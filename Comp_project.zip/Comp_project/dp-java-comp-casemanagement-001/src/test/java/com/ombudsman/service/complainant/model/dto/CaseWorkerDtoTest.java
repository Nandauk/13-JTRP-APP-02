package com.ombudsman.service.complainant.model.dto;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;

import com.ombudsman.service.complainant.model.dto.CaseWorkerDto;

import static org.junit.jupiter.api.Assertions.*;

public class CaseWorkerDtoTest {
	@InjectMocks

    private CaseWorkerDto caseWorkerDto;

    @BeforeEach
    public void setUp() {
        caseWorkerDto = new CaseWorkerDto();
    }

    @Test
    public void testGetterAndSetter() {
        // Set values
        caseWorkerDto.setTicketnumber("TICKET123");
        caseWorkerDto.set_fos_caseworker_value("Worker123");
        caseWorkerDto.set_owninguser_value("Owner123");
        caseWorkerDto.setFullname("John A. Doe");
        caseWorkerDto.setTitle("Title123");
        caseWorkerDto.setAddress1_telephone1("123-456-7890");
        caseWorkerDto.setInternalemailaddress("john.doe@example.com");
        caseWorkerDto.setCwFullname("CW John Doe");
        caseWorkerDto.setCwAdddress1_telephone1("098-765-4321");
        caseWorkerDto.setCwInternalemailaddress("cw.johndoe@example.com");
        caseWorkerDto.setOId("OID123");

        // Assert values
        assertEquals("TICKET123", caseWorkerDto.getTicketnumber());
        assertEquals("Worker123", caseWorkerDto.get_fos_caseworker_value());
        assertEquals("Owner123", caseWorkerDto.get_owninguser_value());
        assertEquals("John A. Doe", caseWorkerDto.getFullname());
        assertEquals("Title123", caseWorkerDto.getTitle());
        assertEquals("123-456-7890", caseWorkerDto.getAddress1_telephone1());
        assertEquals("john.doe@example.com", caseWorkerDto.getInternalemailaddress());
        assertEquals("CW John Doe", caseWorkerDto.getCwFullname());
        assertEquals("098-765-4321", caseWorkerDto.getCwAdddress1_telephone1());
        assertEquals("cw.johndoe@example.com", caseWorkerDto.getCwInternalemailaddress());
        assertEquals("OID123", caseWorkerDto.getOId());
    }
}
