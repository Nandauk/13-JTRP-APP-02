package com.ombudsman.service.complainant.model.dto;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.ombudsman.service.complainant.model.dto.CaseDetailDto;

import static org.junit.jupiter.api.Assertions.*;
@ExtendWith(SpringExtension.class)
public class CaseDetailsDtoTest {
	@InjectMocks
    private CaseDetailDto caseDetailDto;

    @BeforeEach
    public void setUp() {
        caseDetailDto = new CaseDetailDto();
    }

    @Test
    public void testGetterAndSetter() {
        // Set values
        caseDetailDto.setIncidentid("INC123");
        caseDetailDto.setTicketnumber("TICKET123");
        caseDetailDto.setFos_crn("FOS123");
        caseDetailDto.setFos_casestage("Stage123");
        caseDetailDto.setStatuscode("Status123");
        caseDetailDto.setFos_dateofreferral("2025-01-10");
        caseDetailDto.setFos_representatives("Rep123");
        caseDetailDto.setFos_datecasefirstmovedtoinvestigation("2025-01-01");
        caseDetailDto.setFos_dateofconversion("2025-01-05");
        caseDetailDto.setFos_datebusinessfilereceived("2025-01-07");
        caseDetailDto.setFos_prioritycode("Priority123");
        caseDetailDto.setStatecode("State123");
        caseDetailDto.setFos_caseprogress("Progress123");
        caseDetailDto.setFos_caseprogress_name("ProgressName123");
        
        // Assert values
        assertEquals("INC123", caseDetailDto.getIncidentid());
        assertEquals("TICKET123", caseDetailDto.getTicketnumber());
        assertEquals("FOS123", caseDetailDto.getFos_crn());
        assertEquals("Stage123", caseDetailDto.getFos_casestage());
        assertEquals("Status123", caseDetailDto.getStatuscode());
        assertEquals("2025-01-10", caseDetailDto.getFos_dateofreferral());
        assertEquals("Rep123", caseDetailDto.getFos_representatives());
        assertEquals("2025-01-01", caseDetailDto.getFos_datecasefirstmovedtoinvestigation());
        assertEquals("2025-01-05", caseDetailDto.getFos_dateofconversion());
        assertEquals("2025-01-07", caseDetailDto.getFos_datebusinessfilereceived());
        assertEquals("State123", caseDetailDto.getStatecode());
        assertEquals("Progress123", caseDetailDto.getFos_caseprogress());
        assertEquals("ProgressName123", caseDetailDto.getFos_caseprogress_name());
    }

}
