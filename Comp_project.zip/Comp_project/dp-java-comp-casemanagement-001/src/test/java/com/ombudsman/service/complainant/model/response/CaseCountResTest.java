package com.ombudsman.service.complainant.model.response;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

class CaseCountResTest {
	
	@Test
	void testGettersAndSetters() {
		CaseCountRes res = new CaseCountRes();
		res.setIncidentId("inc1234");
		res.setNumberOfCases("2");
		
		String incidentId="inc1234";
		String numberOfCases = "2";
		
		assertEquals(res.getIncidentId(), incidentId);
		assertEquals(res.getNumberOfCases(), numberOfCases);
	}

}
