package com.ombudsman.service.complainant.model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

class AccountsTest {

	@Test
	void testAccountsModelGettersAndSetters() {
		Accounts a = new Accounts();
		a.setAccountid("Test Account");
		assertEquals("Test Account", a.getAccountid());
	}

}
