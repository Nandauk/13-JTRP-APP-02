package com.ombudsman.service.complainant.model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

class RequestProcessingDetailsTest {
	@Test
	void testGettersAndSetters() {
		String incidentId = "Inc1233";
		String offeroutcomeId = "Outcome123";
		String comment = "Test Comment";

		RequestProcessingDetails testInc = new RequestProcessingDetails();
		testInc.setIncidentId(incidentId);
		testInc.setOfferoutcomeId(offeroutcomeId);
		testInc.setComment(comment);

		assertEquals(incidentId, testInc.getIncidentId());
		assertEquals(offeroutcomeId, testInc.getOfferoutcomeId());
		assertEquals(comment, testInc.getComment());
	}
}
