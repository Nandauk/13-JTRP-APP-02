package com.ombudsman.service.casereporting.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.transaction.Transactional;

@Entity
@Table(name = "account")
@Transactional
public class account {
	
	  private Long accountcategorycode;
	  
	  public Long getAccountcategorycode() { return accountcategorycode; }
	  
	  public void setAccountcategorycode(Long accountcategorycode) {
	  this.accountcategorycode = accountcategorycode; }
	 

	private String name;
  private String  parentaccountid;
  
  
  @Id
  @Column(name = "accountid")
  private String accountid;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getParentaccountid() {
		return parentaccountid;
	}
	public void setParentaccountid(String parentaccountid) {
		this.parentaccountid = parentaccountid;
	}
	public String getAccountid() {
		return accountid;
	}
	public void setAccountid(String accountid) {
		this.accountid = accountid;
	}
	
  
 
  
	
  
  // Getters and setters

	
	

	

	/*
	 * private Long accountcategorycode;
	 * 
	 * private String name; private String parentaccountid;
	 * 
	 * @Id
	 * 
	 * @Column(name = "accountid") private String accountid;
	 * 
	 * public Long getAccountcategorycode() { return accountcategorycode; }
	 * 
	 * public void setAccountcategorycode(Long accountcategorycode) {
	 * this.accountcategorycode = accountcategorycode; }
	 * 
	 * public String getName() { return name; }
	 * 
	 * public void setName(String name) { this.name = name; }
	 * 
	 * public String getParentaccountid() { return parentaccountid; }
	 * 
	 * public void setParentaccountid(String parentaccountid) { this.parentaccountid
	 * = parentaccountid; }
	 * 
	 * public String getAccountid() { return accountid; }
	 * 
	 * public void setAccountid(String accountid) { this.accountid = accountid; }
	 */

	// Getters and setters
}
