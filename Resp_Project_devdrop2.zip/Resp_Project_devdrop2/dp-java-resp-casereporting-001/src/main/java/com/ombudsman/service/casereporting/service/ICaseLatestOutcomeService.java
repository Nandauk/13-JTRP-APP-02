package com.ombudsman.service.casereporting.service;

import com.ombudsman.service.casereporting.exception.AccountNotFoundException;
import com.ombudsman.service.casereporting.exception.DashboardCaseException;
import com.ombudsman.service.casereporting.exception.RecentCaseNotFoundException;
import com.ombudsman.service.casereporting.model.response.CaseOutcomeCountRes;

public interface ICaseLatestOutcomeService {

	public CaseOutcomeCountRes getLatestCount()throws RecentCaseNotFoundException, AccountNotFoundException, DashboardCaseException;
}
