package com.ombudsman.service.casereporting.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ombudsman.service.casereporting.exception.AccountNotFoundException;
import com.ombudsman.service.casereporting.exception.DashboardCaseException;
import com.ombudsman.service.casereporting.exception.DashboardDataParseException;
import com.ombudsman.service.casereporting.model.response.RecentCasesRes;

public interface IRecentCasesService {
	
	public RecentCasesRes getRecentCaseList() throws DashboardCaseException, AccountNotFoundException, JsonProcessingException, DashboardDataParseException;

}
