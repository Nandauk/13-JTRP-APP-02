package com.ombudsman.service.casereporting.exception;

import org.springframework.dao.DataAccessException;

public class SQLDataAccessException extends DataAccessException {
	/**
   * 
   */
  private static final long serialVersionUID = 1L;

  public SQLDataAccessException(String orgName){
		super(orgName);
	}
}
