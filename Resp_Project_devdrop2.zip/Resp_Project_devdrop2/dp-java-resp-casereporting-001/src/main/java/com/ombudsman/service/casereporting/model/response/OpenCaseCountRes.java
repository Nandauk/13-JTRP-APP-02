package com.ombudsman.service.casereporting.model.response;

public class OpenCaseCountRes extends GenericResponse {

	private String totalopencases;
	private String totalprioritycases;
	private String totaloverduecases;
	private String totallatestoutcomelastweek;
	private String totalawaitingyourresponse;
	
	public String getTotalopencases() {
		return totalopencases;
	}
	public void setTotalopencases(String totalopencases) {
		this.totalopencases = totalopencases;
	}
	public String getTotalprioritycases() {
		return totalprioritycases;
	}
	public void setTotalprioritycases(String totalprioritycases) {
		this.totalprioritycases = totalprioritycases;
	}
	public String getTotaloverduecases() {
		return totaloverduecases;
	}
	public void setTotaloverduecases(String totaloverduecases) {
		this.totaloverduecases = totaloverduecases;
	}
	public String getTotallatestoutcomelastweek() {
		return totallatestoutcomelastweek;
	}
	public void setTotallatestoutcomelastweek(String totallatestoutcomelastweek) {
		this.totallatestoutcomelastweek = totallatestoutcomelastweek;
	}
	public String getTotalawaitingyourresponse() {
		return totalawaitingyourresponse;
	}
	public void setTotalawaitingyourresponse(String totalawaitingyourresponse) {
		this.totalawaitingyourresponse = totalawaitingyourresponse;
	}
}
