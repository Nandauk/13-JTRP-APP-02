package com.ombudsman.service.casereporting.model;

public class CaseTypeCount {

    private String id;
    private String value;
	private String investigationcount;
	private Integer viewcount;//DPSPS-982
	private String ombudsmancount;
	private String total;
	

	public String getTotal() {
		return total;
	}
	public void setTotal(String total) {
		this.total = total;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	public String getInvestigationcount() {
		return investigationcount;
	}
	public void setInvestigationcount(String investigationcount) {
		this.investigationcount = investigationcount;
	}
	public String getOmbudsmancount() {
		return ombudsmancount;
	}
	public Integer getViewcount() {
		return viewcount;
	}
	//DPSPS-982
	public void setViewcount(Integer viewcount) {
		this.viewcount = viewcount;
	}
	public void setOmbudsmancount(String ombudsmancount) {
		this.ombudsmancount = ombudsmancount;
	}
	//DPSP-982
	
	

}
