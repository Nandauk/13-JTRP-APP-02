package com.ombudsman.service.casereporting.dto;

public interface RecentCaseDto {
	public String getIncidentid();
	public String getTicketnumber();
	public String getFos_dateofreferral();
	public String getFos_datecasefirstmovedtoinvestigation();
	
	public String getFos_dateofconversion();
	public String getFos_dateofevent();
	public String getFos_reference();
	public String getFos_prioritycode();
	public String getBr_required();

}
