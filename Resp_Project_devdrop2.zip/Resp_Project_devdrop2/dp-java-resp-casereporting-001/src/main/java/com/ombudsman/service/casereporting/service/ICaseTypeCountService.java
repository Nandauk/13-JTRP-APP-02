package com.ombudsman.service.casereporting.service;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

import com.ombudsman.service.casereporting.dto.ViewCaseCountProjectionDto;
import com.ombudsman.service.casereporting.exception.AzureServiceException;
import com.ombudsman.service.casereporting.model.CaseTypeCount;
import com.ombudsman.service.casereporting.model.response.CaseTypeCountRes;

public interface ICaseTypeCountService {
	

	public CaseTypeCountRes getCaseTypeCount()
			throws  AzureServiceException, Exception;
	
	default List<CaseTypeCount> getViewCaseCountForAll(final List<ViewCaseCountProjectionDto> viewCases) {

		final List<CaseTypeCount> complainantCountList = new ArrayList<>();
		viewCases.forEach(view -> {
			CaseTypeCount caseTypeCount = new CaseTypeCount();

			caseTypeCount.setId(view.getId());
			caseTypeCount.setValue(StringUtils.isNotEmpty(view.getName()) ? view.getName() : "");
			caseTypeCount.setInvestigationcount(view.getInvestigationcount());
			caseTypeCount.setViewcount((view.getViewcount()));
			caseTypeCount.setOmbudsmancount(view.getOmbudsmancount());
			caseTypeCount.setTotal(String.valueOf(view.getTotal()));
			complainantCountList.add(caseTypeCount);
		});
		return complainantCountList;
	}
}
