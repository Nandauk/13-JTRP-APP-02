package com.ombudsman.service.casereporting.model.request;

import java.io.Serializable;

 import jakarta.validation.Valid;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;



public class CaseDetailsByIdReq implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 35817432348796930L;
	@Valid
	@NotNull
	@NotEmpty
	private String incidentid;
	

	public String getIncidentid() {
		return incidentid;
	}
	
	
	public void setIncidentid(String incidentid) {
		this.incidentid = incidentid;
	}

}
