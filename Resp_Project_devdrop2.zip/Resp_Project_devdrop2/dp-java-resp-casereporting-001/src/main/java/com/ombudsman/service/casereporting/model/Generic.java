package com.ombudsman.service.casereporting.model;

public class Generic<T> {
	// An object of type T is declared
	T obj;

	Generic(T obj) {
		this.obj = obj;
	} // constructor

	public T getObject() {
		return this.obj;
	}
}
