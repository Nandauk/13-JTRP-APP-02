package com.ombudsman.service.casereporting.dto;




public interface OpenCaseCountByStatusResDto {

	//public String getStatuscode();	
	public int getTotalrecordcount();
	//public String getStatuscodename();
	public String getCasestagename();
	public String getCaseprogressname();
	public String getCaseprogresscode();
	public String getCasestage();

}
