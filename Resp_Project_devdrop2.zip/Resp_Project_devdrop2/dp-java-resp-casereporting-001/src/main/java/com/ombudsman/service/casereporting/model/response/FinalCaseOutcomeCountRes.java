package com.ombudsman.service.casereporting.model.response;

import java.util.List;

import com.ombudsman.service.casereporting.model.FinalCaseOutcomeCount;

public class FinalCaseOutcomeCountRes extends GenericResponse{ 

	
	private List<FinalCaseOutcomeCount> caseoutcomecount;
	
	public List<FinalCaseOutcomeCount> getCaseoutcomecount() {
		return caseoutcomecount;
	}
	public void setCaseoutcomecount(List<FinalCaseOutcomeCount> caseoutcomecount) {
		this.caseoutcomecount = caseoutcomecount;
	}






}
