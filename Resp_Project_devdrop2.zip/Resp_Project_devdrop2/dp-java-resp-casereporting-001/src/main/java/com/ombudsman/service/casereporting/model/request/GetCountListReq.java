package com.ombudsman.service.casereporting.model.request;

public class GetCountListReq {
	private String username;
	private String organisationaccountid;

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getOrganisationaccountid() {
		return organisationaccountid;
	}

	public void setOrganisationaccountid(String organisationaccountid) {
		this.organisationaccountid = organisationaccountid;
	}

}
