package com.ombudsman.service.casereporting.controller;

import static com.ombudsman.service.casereporting.common.Constants.CASEWORKER_ROLES;
import static com.ombudsman.service.casereporting.common.Constants.SUPERVISOR_ROLES;

import java.time.Instant;
import java.time.LocalDateTime;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ombudsman.service.casereporting.common.CommonUtil;
import com.ombudsman.service.casereporting.common.UserBean;
import com.ombudsman.service.casereporting.common.ValidateUserSession;
import com.ombudsman.service.casereporting.exception.AccountNotFoundException;
import com.ombudsman.service.casereporting.exception.DashboardCaseException;
import com.ombudsman.service.casereporting.exception.DashboardDataParseException;
import com.ombudsman.service.casereporting.exception.RecentCaseNotFoundException;
import com.ombudsman.service.casereporting.exception.UnAuthorisedException;
import com.ombudsman.service.casereporting.model.response.CaseOutcomeCountRes;
import com.ombudsman.service.casereporting.model.response.CaseTypeCountRes;
import com.ombudsman.service.casereporting.model.response.CaseWorkerCaseOwnerCountRes;
import com.ombudsman.service.casereporting.model.response.FinalCaseOutcomeCountRes;
import com.ombudsman.service.casereporting.model.response.GenericResponse;
import com.ombudsman.service.casereporting.model.response.OpenCaseCountByStatusRes;
import com.ombudsman.service.casereporting.model.response.OpenCaseCountRes;
import com.ombudsman.service.casereporting.model.response.RecentCasesRes;
import com.ombudsman.service.casereporting.service.ICaseLatestOutcomeService;
import com.ombudsman.service.casereporting.service.ICaseTypeCountService;
import com.ombudsman.service.casereporting.service.ICaseWorkerCountService;
import com.ombudsman.service.casereporting.service.IFinalOutcomeCountService;
import com.ombudsman.service.casereporting.service.IRecentCasesService;

@RestController
public class CaseReportingController {
	private static final Logger LOG = LogManager.getRootLogger();

	private String successMsg = "Success";

	@Autowired
	IFinalOutcomeCountService finalOutcomeCountService;
	@Autowired
	ICaseLatestOutcomeService getCaseLatestOutcomeService;

	@Autowired
	ICaseWorkerCountService caseWorkerCountService;

	@Autowired
	ICaseTypeCountService caseTypeCountService;

	@Autowired
	IRecentCasesService recentCasesService;

	@Autowired
	UserBean userbean;


	@Autowired
	CommonUtil commonUtil;

	@Autowired
	ValidateUserSession validateUserSession;


	@GetMapping(path = "/ombudsmanservice/v1/casereporting/latestoutcomecount")
	public @ResponseBody ResponseEntity<CaseOutcomeCountRes> getLatestCount() throws RecentCaseNotFoundException,
			AccountNotFoundException, DashboardCaseException, UnAuthorisedException {

		LOG.debug("Respondents latestoutcomecount Controller Method Started.CorrelationId:-{} OID:-{}",
				userbean.getCorrelationId(), userbean.getUserObjectId());

		CaseOutcomeCountRes result = null;
		if ((userbean.getRoles().contains(CASEWORKER_ROLES) ||userbean.getRoles().contains(SUPERVISOR_ROLES))  && validateUserSession.isValidSession()) {
			result = getCaseLatestOutcomeService.getLatestCount();

			if (result != null) {
				result.setStatus(successMsg);
				result.setMessage(successMsg);
			}
			LOG.debug("End of Respondents latestoutcomecount Controller Method.CorrelationId:-{} OID:-{}",
					userbean.getCorrelationId(), userbean.getUserObjectId());

			return new ResponseEntity<>(result, HttpStatus.OK);
		}
		return new ResponseEntity<>(result, HttpStatus.UNAUTHORIZED);

	}


	@GetMapping(value = "/ombudsmanservice/v1/casereporting/caseownercount")
	public ResponseEntity<CaseWorkerCaseOwnerCountRes> getCaseOwnerCount()
			throws DashboardCaseException, AccountNotFoundException, UnAuthorisedException {
		LOG.debug("Caseworker Caseownercount Controller Method Started.CorrelationId:-{} OID:-{}",
				userbean.getCorrelationId(), userbean.getUserObjectId());
		Instant validating = Instant.now();
		LOG.info(String.format("validation Start Time: %s" , validating.toString()));

		CaseWorkerCaseOwnerCountRes result = null;
		if ((userbean.getRoles().contains(CASEWORKER_ROLES) ||userbean.getRoles().contains(SUPERVISOR_ROLES))  && validateUserSession.isValidSession()) {
			

			Instant start = Instant.now();
			LOG.info(String.format("controller Start Time: %s" , start.toString()));
			
			result = caseWorkerCountService.getCaseOwnerCount();
			
			Instant end = Instant.now();
			LOG.info(String.format("controller end Time: %s" , end.toString()));

			if (result != null) {
				result.setStatus(successMsg);
			}
			LOG.debug("Caseworker Caseownercount Controller Method ended.CorrelationId:-{} OID:-{}",
					userbean.getCorrelationId(), userbean.getUserObjectId());

			return new ResponseEntity<>(result, HttpStatus.OK);
		}
		return new ResponseEntity<>(result, HttpStatus.UNAUTHORIZED);

	}

	@GetMapping(value = "/ombudsmanservice/v1/casereporting/opencasecount")
	public ResponseEntity<OpenCaseCountByStatusRes> getOpenCaseCountByStatus()
			throws RecentCaseNotFoundException, AccountNotFoundException, UnAuthorisedException {
		LOG.debug("Caseworker Opencasecount Controller Method Started.CorrelationId:-{} OID:-{}",
				userbean.getCorrelationId(), userbean.getUserObjectId());

		OpenCaseCountByStatusRes result = null;
		if ((userbean.getRoles().contains(CASEWORKER_ROLES) ||userbean.getRoles().contains(SUPERVISOR_ROLES))  && validateUserSession.isValidSession()) {
			result = caseWorkerCountService.getOpenCaseCount();

			if (result != null) {
				result.setStatus(successMsg);
			}
			LOG.debug("Caseworker Opencasecount Controller Method Ended.CorrelationId:-{} OID:-{}",
					userbean.getCorrelationId(), userbean.getUserObjectId());

			return new ResponseEntity<>(result, HttpStatus.OK);
		}
		return new ResponseEntity<>(result, HttpStatus.UNAUTHORIZED);

	}


	@GetMapping(value = "/ombudsmanservice/v1/casereporting/casetypecount")
	public ResponseEntity<CaseTypeCountRes> getCaseTypeCount() throws Exception {

		LOG.debug("Caseworker Casetypecount Controller Method Started.CorrelationId:-{} OID:-{}",
				userbean.getCorrelationId(), userbean.getUserObjectId());
		CaseTypeCountRes result = null;
		if ((userbean.getRoles().contains(CASEWORKER_ROLES) ||userbean.getRoles().contains(SUPERVISOR_ROLES))  && validateUserSession.isValidSession()) {
			result = caseTypeCountService.getCaseTypeCount();

			if (result != null) {
				result.setStatus(successMsg);
			}
			LOG.debug("Caseworker Casetypecount Controller Method Ended..CorrelationId:-{} OID:-{}",
					userbean.getCorrelationId(), userbean.getUserObjectId());

			return new ResponseEntity<>(result, HttpStatus.OK);
		}
		return new ResponseEntity<>(result, HttpStatus.UNAUTHORIZED);
	}

	
	@GetMapping(path = "/ombudsmanservice/v1/casereporting/recentcases")
	public @ResponseBody ResponseEntity<RecentCasesRes> getRecentCaseList() throws JsonProcessingException,
			DashboardCaseException, AccountNotFoundException, DashboardDataParseException, UnAuthorisedException {
		LOG.debug("Caseworker Recentcases Controller Method Started.CorrelationId:-{} OID:-{}",
				userbean.getCorrelationId(), userbean.getUserObjectId());

		RecentCasesRes result = null;
		if ((userbean.getRoles().contains(CASEWORKER_ROLES) ||userbean.getRoles().contains(SUPERVISOR_ROLES))  && validateUserSession.isValidSession()) {
			result = recentCasesService.getRecentCaseList();

			if (result != null) {
				result.setStatus(successMsg);
			}
			LOG.debug("Caseworker Recentcases Controller Method Started.CorrelationId:-{} OID:-{}",
					userbean.getCorrelationId(), userbean.getUserObjectId());

			return new ResponseEntity<>(result, HttpStatus.OK);
		}
		return new ResponseEntity<>(result, HttpStatus.UNAUTHORIZED);

	}


	@GetMapping(value = "/ombudsmanservice/v1/casereporting/casecount")
	public ResponseEntity<OpenCaseCountRes> getCaseCount()
			throws AccountNotFoundException, DashboardCaseException, UnAuthorisedException {
		LOG.debug("Caseworker Casecount Controller Method Started.CorrelationId:-{} OID:-{}",
				userbean.getCorrelationId(), userbean.getUserObjectId());

		OpenCaseCountRes result = null;
		if ((userbean.getRoles().contains(CASEWORKER_ROLES) ||userbean.getRoles().contains(SUPERVISOR_ROLES))  && validateUserSession.isValidSession()) {
			result = caseWorkerCountService.getOpenCaseCountGeneric();

			if (result != null) {
				result.setStatus(successMsg);
			}
			LOG.debug("Caseworker Casecount Controller Method Ended.CorrelationId:-{} OID:-{}",
					userbean.getCorrelationId(), userbean.getUserObjectId());

			return new ResponseEntity<>(result, HttpStatus.OK);
		}
		return new ResponseEntity<>(result, HttpStatus.UNAUTHORIZED);

	}

	@GetMapping(value = "/ombudsmanservice/v1/casereporting/finaloutcomecount")
	public ResponseEntity<FinalCaseOutcomeCountRes> getFinalOutcomeCount()
			throws JsonProcessingException, AccountNotFoundException, DashboardCaseException, UnAuthorisedException {
		LOG.debug("FinalOutcomeCount Controller Method Started.CorrelationId:-{} OID:-{}", userbean.getCorrelationId(),
				userbean.getUserObjectId());

		FinalCaseOutcomeCountRes result = null;
		if ((userbean.getRoles().contains(CASEWORKER_ROLES) ||userbean.getRoles().contains(SUPERVISOR_ROLES))  && validateUserSession.isValidSession()) {
		result = finalOutcomeCountService.getFinalOutcomeCount();

		LOG.debug("FinalOutcomeCount Controller Method Ended.CorrelationId:-{} OID:-{}", userbean.getCorrelationId(),
				userbean.getUserObjectId());

		return new ResponseEntity<>(result, HttpStatus.OK);
		}
		return new ResponseEntity<>(result, HttpStatus.UNAUTHORIZED);


	}
	
	@GetMapping(value = "/ombudsmanservice/v1/casereporting/healthcheck")
	public ResponseEntity<GenericResponse> getHealthCheck() {
		final GenericResponse result = new GenericResponse();
		result.setMessage(LocalDateTime.now().toString());
		result.setStatus("Available");
		return new ResponseEntity<>(result, HttpStatus.OK);
	}

	
}
