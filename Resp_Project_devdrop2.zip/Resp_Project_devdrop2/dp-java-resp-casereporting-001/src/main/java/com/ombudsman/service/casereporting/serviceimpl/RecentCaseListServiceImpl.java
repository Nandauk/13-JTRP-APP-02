package com.ombudsman.service.casereporting.serviceimpl;

import java.util.List;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.compress.utils.Lists;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ombudsman.service.casereporting.common.UserBean;
import com.ombudsman.service.casereporting.dao.ICaseReportingDataProcessDao;
import com.ombudsman.service.casereporting.dto.RecentCaseDto;
import com.ombudsman.service.casereporting.exception.AccountNotFoundException;
import com.ombudsman.service.casereporting.exception.DashboardCaseException;
import com.ombudsman.service.casereporting.exception.DashboardDataParseException;
import com.ombudsman.service.casereporting.model.response.RecentCasesRes;
import com.ombudsman.service.casereporting.service.IRecentCasesService;
import com.ombudsman.service.casereporting.serviceimpl.helper.CaseReportingDetailsHelper;

@Service
public class RecentCaseListServiceImpl implements IRecentCasesService {

	private static final String ACCOUNT_NOT_FOUND = "Account not found.";

	private static final String SUCCESS = "Success";

	@Autowired
	ICaseReportingDataProcessDao dashboardDataProcessDao;

	@Autowired
	UserBean userbean;

	@Autowired
	CaseReportingDetailsHelper dashboardCaseDetailsHelper;
	private static final Logger LOG = LogManager.getRootLogger();

	@Override
	public RecentCasesRes getRecentCaseList() throws DashboardCaseException, AccountNotFoundException,
			JsonProcessingException, DashboardDataParseException {

		final String methodName = "getRecentCaseList";
		RecentCasesRes response = new RecentCasesRes();
		LOG.debug(methodName, ":: Service Method Started.CorrelationId:-{} OID:-{}",
				userbean.getCorrelationId(), userbean.getUserObjectId());
		userbean.setGroups(null);

		final List<String> adAccountIds = dashboardDataProcessDao.getAccountIds(userbean.getUserObjectId());
		if (CollectionUtils.isEmpty(adAccountIds)) {
			LOG.info("Data is not present for given OID");
			throw new AccountNotFoundException(ACCOUNT_NOT_FOUND);
		}

		final List<RecentCaseDto> recentCases = dashboardDataProcessDao.getFetchRecentCase(adAccountIds);
		response.setRecentcaselist(
				CollectionUtils.isNotEmpty(recentCases) ? dashboardCaseDetailsHelper.getRecentCases(recentCases)
						: Lists.newArrayList());
		response.setStatus(SUCCESS);

		LOG.debug(methodName, ":: Service Method Ended.CorrelationId:-{} OID:-{}", userbean.getCorrelationId(),
				userbean.getUserObjectId());
		return response;

	}

}
