package com.ombudsman.service.casereporting.model.request;

public class GetFinalOutcomeCountReq {

	private String resolutionRange;

	public String getResolutionRange() {
		return resolutionRange;
	}

	public void setResolutionRange(String resolutionRange) {
		this.resolutionRange = resolutionRange;
	}



}
