package com.ombudsman.service.casereporting.model;

import java.util.List;

public class CaseOutcomeCount {

	private List<GenericCount> caseoutcomecountvar;
	private String caseoutcomestatus;
	private Integer totalcount;

	public List<GenericCount> getCaseoutcomecountvar() {
		return caseoutcomecountvar;
	}

	public void setCaseoutcomecountvar(List<GenericCount> caseoutcomecountvar) {
		this.caseoutcomecountvar = caseoutcomecountvar;
	}

	public String getCaseoutcomestatus() {
		return caseoutcomestatus;
	}

	public void setCaseoutcomestatus(String caseoutcomestatus) {
		this.caseoutcomestatus = caseoutcomestatus;
	}

	public Integer getTotalcount() {
		return totalcount;
	}

	public void setTotalcount(Integer totalcount) {
		this.totalcount = totalcount;
	}

}
