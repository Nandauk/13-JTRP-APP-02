package com.ombudsman.service.casereporting.serviceimpl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ombudsman.service.casereporting.common.UserBean;
import com.ombudsman.service.casereporting.dao.ICaseReportingDataProcessDao;
import com.ombudsman.service.casereporting.dto.CaseLatestOutCome;
import com.ombudsman.service.casereporting.exception.AccountNotFoundException;
import com.ombudsman.service.casereporting.exception.DashboardCaseException;
import com.ombudsman.service.casereporting.exception.RespondentNumberFormatException;
import com.ombudsman.service.casereporting.model.FinalCaseOutcomeCount;
import com.ombudsman.service.casereporting.model.FinalOutComeCount;
import com.ombudsman.service.casereporting.model.response.FinalCaseOutcomeCountRes;
import com.ombudsman.service.casereporting.service.IFinalOutcomeCountService;

@Service
public class FinalOutcomeCountServiceImpl implements IFinalOutcomeCountService {

	private static final String SUCCESS = "Success";

	
	private static final String ACCOUNT_NOT_FOUND = "Account not found in repository";	
	private static final String FINAL_OUTCOME = "Final Outcome";

	@Autowired
	UserBean userbean;

	@Autowired
	ICaseReportingDataProcessDao dashboardDataProcessDao;

	private static final Logger LOG = LogManager.getRootLogger();

	@Override
	public FinalCaseOutcomeCountRes getFinalOutcomeCount() throws AccountNotFoundException, DashboardCaseException {
		final String methodName = "getFinalOutcomeCount";

		LOG.debug(methodName, ":: Service Method Started.CorrelationId:-{} OID:-{}- accountIds::{}",
				userbean.getCorrelationId(), userbean.getUserObjectId(), userbean.getGroups());

		FinalCaseOutcomeCountRes caseOutcomeCountRes = new FinalCaseOutcomeCountRes();

		final List<String> adAccountIds = dashboardDataProcessDao.getAccountIds(userbean.getUserObjectId());
		if (CollectionUtils.isEmpty(adAccountIds)) {
			LOG.info("Data is not present for given OID");
			throw new AccountNotFoundException(ACCOUNT_NOT_FOUND);
		}
		LOG.info("get account ids from DB ::{} ", adAccountIds);
		final List<CaseLatestOutCome> finalOutcomeCount = Optional
				.ofNullable(dashboardDataProcessDao.getFinalOutcomeCount(adAccountIds))
				.orElseThrow(() -> new DashboardCaseException("Final outcome not found"));

		final List<FinalOutComeCount> caseoutcomeCountvar = new ArrayList<>();
		final List<FinalCaseOutcomeCount> caseOutcomeCountList = new ArrayList<>();
		final FinalCaseOutcomeCount caseOutcomeCount = new FinalCaseOutcomeCount();
		Integer totalcountCurrent = 0;
		Integer totalcountLast = 0;
		if (CollectionUtils.isNotEmpty(finalOutcomeCount)) {
			for (CaseLatestOutCome idx : finalOutcomeCount) {
				final FinalOutComeCount gen = new FinalOutComeCount();
				gen.setId("");
				gen.setCount(idx.getOutcomeCount());
				gen.setCountCurrentMonth(idx.getCurrentMonthCount());
				gen.setCountLastMonth(idx.getLastMonthCount());
				gen.setValue(idx.getOutcomeType());
				totalcountCurrent += getTotalCurrentMonth(idx.getCurrentMonthCount());
				totalcountLast += getTotalCurrentMonth(idx.getLastMonthCount());
				gen.setEmail("");
				caseoutcomeCountvar.add(gen);

			}
			
			caseOutcomeCount.setCaseoutcomecountvar(caseoutcomeCountvar);
			caseOutcomeCount
					.setTotalcount(caseoutcomeCountvar.stream().mapToInt(i -> Integer.parseInt(i.getCount())).sum());
			caseOutcomeCount.setCurrentmonthcount(totalcountCurrent);
			caseOutcomeCount.setLastmonthcount(totalcountLast);
			caseOutcomeCount.setCaseoutcomestatus(FINAL_OUTCOME);
			caseOutcomeCountList.add(caseOutcomeCount);
			caseOutcomeCountRes.setCaseoutcomecount(caseOutcomeCountList);
			caseOutcomeCountRes.setStatus(SUCCESS);
		}

		LOG.debug(methodName, ":: Service Method Ended.CorrelationId:-{} OID:-{}", userbean.getCorrelationId(),
				userbean.getUserObjectId());
		return caseOutcomeCountRes;
	}

	private int getTotalCurrentMonth(final String monthCount) {
		int count = 0;
		try {
			if (null != monthCount) {
				count = Integer.parseInt(monthCount);
			}
		} catch (RespondentNumberFormatException ex) {
			LOG.error("unable to parse input String to integer:-{}", ex.getMessage());
		}
		return count;
	}

}
