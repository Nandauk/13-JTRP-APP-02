package com.ombudsman.service.casereporting.exception;

public class RespondentNumberFormatException  extends ArithmeticException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public RespondentNumberFormatException(String exceptionMsg)
	{
		super(exceptionMsg);
	}

}
