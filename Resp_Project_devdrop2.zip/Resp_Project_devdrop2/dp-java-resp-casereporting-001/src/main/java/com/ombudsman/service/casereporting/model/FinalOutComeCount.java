package com.ombudsman.service.casereporting.model;

public class FinalOutComeCount {

	private String id;
	private String value;
	private String count;
	private String email;
	private String countCurrentMonth;
	private String countLastMonth;

	public String getCountCurrentMonth() {
		return countCurrentMonth;
	}

	public void setCountCurrentMonth(final String countCurrentMonth) {
		this.countCurrentMonth = countCurrentMonth;
	}

	public String getCountLastMonth() {
		return countLastMonth;
	}

	public void setCountLastMonth(String countLastMonth) {
		this.countLastMonth = countLastMonth;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public String getCount() {
		return count;
	}

	public void setCount(String count) {
		this.count = count;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

}
