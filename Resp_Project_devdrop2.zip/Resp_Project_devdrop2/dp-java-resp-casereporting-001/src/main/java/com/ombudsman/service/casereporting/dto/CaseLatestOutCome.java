package com.ombudsman.service.casereporting.dto;

import java.io.Serializable;



public interface CaseLatestOutCome extends Serializable{
	public String getOutcomeType();
	public String getOutcomeCount();
	public String getCurrentMonthCount();
	public String getLastMonthCount();

}
