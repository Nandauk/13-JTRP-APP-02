package com.ombudsman.service.casereporting.dto;

public interface OrganizationData {
	public String getAccountcategorycode();
	public String getAccountid();
	public String getParentaccountid();
	public String getName();
	
}
