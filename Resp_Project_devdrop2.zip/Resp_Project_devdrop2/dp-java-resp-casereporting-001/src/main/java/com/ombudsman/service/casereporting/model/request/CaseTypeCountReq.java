package com.ombudsman.service.casereporting.model.request;

import java.util.List;

import com.ombudsman.service.casereporting.model.Accounts;

public class CaseTypeCountReq {
	
	private List<Accounts> organisationlist;

	public List<Accounts> getOrganisationlist() {
		return organisationlist;
	}

	public void setOrganisationlist(List<Accounts> organisationlist) {
		this.organisationlist = organisationlist;
	}

}
