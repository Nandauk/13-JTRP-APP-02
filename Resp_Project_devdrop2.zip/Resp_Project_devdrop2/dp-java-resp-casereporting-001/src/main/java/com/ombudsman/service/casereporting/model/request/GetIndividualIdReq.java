package com.ombudsman.service.casereporting.model.request;

 import jakarta.validation.Valid;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;

public class GetIndividualIdReq {

	@Valid
	@NotNull
	@NotEmpty
	private String Organisationid;

	public String getOrganisationid() {
		return Organisationid;
	}

	public void setOrganisationid(String organisationid) {
		Organisationid = organisationid;
	}

}
