package com.ombudsman.service.casereporting.dto;

import java.io.Serializable;

public interface CaseOwnerCountProjectionDto extends Serializable{
 
	
	public String getIncident_count();
	public String getOwnername();
	public String getEmailaddress();
	public String getCustomerid();
}
