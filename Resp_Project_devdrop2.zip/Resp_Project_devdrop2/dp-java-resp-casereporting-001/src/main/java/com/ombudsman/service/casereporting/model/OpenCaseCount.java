package com.ombudsman.service.casereporting.model;

import java.util.List;

public class OpenCaseCount {
	
	//private List<GenericCount> opencasecounts;
	//private String opencasestatus;
	private String totalcount;
    private List<GenericCount> caseprogresscounts;
	
	private String  casesprogresstatus;
	public List<GenericCount> getCaseprogresscounts() {
		return caseprogresscounts;
	}
	public void setCaseprogresscounts(List<GenericCount> caseprogresscounts) {
		this.caseprogresscounts = caseprogresscounts;
	}
	public String getCasesprogresstatus() {
		return casesprogresstatus;
	}
	public void setCasesprogresstatus(String casesprogresstatus) {
		this.casesprogresstatus = casesprogresstatus;
	}
	
	/*
	 * public List<GenericCount> getOpencasecounts() { return opencasecounts; }
	 * public void setOpencasecounts(List<GenericCount> opencasecounts) {
	 * this.opencasecounts = opencasecounts; } public String getOpencasestatus() {
	 * return opencasestatus; } public void setOpencasestatus(String opencasestatus)
	 * { this.opencasestatus = opencasestatus; }
	 */
	public String getTotalcount() {
		return totalcount;
	}
	public void setTotalcount(String totalcount) {
		this.totalcount = totalcount;
	}
	
}
