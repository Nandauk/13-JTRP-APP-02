package com.ombudsman.service.casereporting.model.response;

import java.util.List;

import com.ombudsman.service.casereporting.model.GenericCount;

public class CaseWorkerCaseOwnerCountRes extends GenericResponse{

	private List<GenericCount> caseworkercountlist;
	private String totalcount;
	
	@Override
	public String getStatus() {
		return status;
	}
	@Override
	public void setStatus(String status) {
		this.status = status;
	}
	@Override
	public String getMessage() {
		return message;
	}
	@Override
	public void setMessage(String message) {
		this.message = message;
	}
	public List<GenericCount> getCaseworkercountlist() {
		return caseworkercountlist;
	}
	public void setCaseworkercountlist(List<GenericCount> caseworkercountlist) {
		this.caseworkercountlist = caseworkercountlist;
	}
	public String getTotalcount() {
		return totalcount;
	}
	public void setTotalcount(String totalcount) {
		this.totalcount = totalcount;
	}
	
	
}
