package com.ombudsman.service.casereporting.dto;

public interface OpenCaseCountSummeryDto {
	
	public String getAwaitingactions();
	public String getOutcomecasecount();
	public String getOpencasecount();
	public String getPrioritycasecount();
	public String getDuecasecount();

} 