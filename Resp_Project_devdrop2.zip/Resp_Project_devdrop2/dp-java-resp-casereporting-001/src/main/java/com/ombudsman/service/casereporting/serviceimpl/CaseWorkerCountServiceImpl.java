package com.ombudsman.service.casereporting.serviceimpl;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Service;

import com.ombudsman.service.casereporting.common.UserBean;
import com.ombudsman.service.casereporting.dao.ICaseReportingDataProcessDao;
import com.ombudsman.service.casereporting.dto.CaseOwnerCountProjectionDto;
import com.ombudsman.service.casereporting.dto.OpenCaseCountByStatusResDto;
import com.ombudsman.service.casereporting.dto.OpenCaseCountSummeryDto;
import com.ombudsman.service.casereporting.exception.AccountNotFoundException;
import com.ombudsman.service.casereporting.exception.DashboardCaseException;
import com.ombudsman.service.casereporting.exception.RecentCaseNotFoundException;
import com.ombudsman.service.casereporting.exception.SqlDatabaseServiceException;
import com.ombudsman.service.casereporting.model.GenericCount;
import com.ombudsman.service.casereporting.model.OpenCaseCount;
import com.ombudsman.service.casereporting.model.response.CaseWorkerCaseOwnerCountRes;
import com.ombudsman.service.casereporting.model.response.OpenCaseCountByStatusRes;
import com.ombudsman.service.casereporting.model.response.OpenCaseCountRes;
import com.ombudsman.service.casereporting.repository.RecentCaseRepository;
import com.ombudsman.service.casereporting.service.ICaseWorkerCountService;

@Service
public class CaseWorkerCountServiceImpl implements ICaseWorkerCountService {

	
	private static final String FAILURE = "Failure..";
	private static final String ACCOUNT_NOT_FOUND = "Account not found in repository";

	private static final String SUCCESS = "Success";

	@Autowired
	RecentCaseRepository recentCaseRepository;

	@Autowired
	UserBean userbean;

	@Autowired
	ICaseReportingDataProcessDao dashboardDataProcessDao;

	@Autowired
	private MessageSource messageSource;

	private static final Logger LOG = LogManager.getRootLogger();

	@Override
	public CaseWorkerCaseOwnerCountRes getCaseOwnerCount() throws DashboardCaseException, AccountNotFoundException {

		final String methodName = "getCaseOwnerCount";

		LOG.debug(methodName, "::Service Method Started.CorrelationId:-{} OID:-{}- accountIDs{}",
				userbean.getCorrelationId(), userbean.getUserObjectId(), userbean.getGroups());

		CaseWorkerCaseOwnerCountRes response = new CaseWorkerCaseOwnerCountRes();
		try {
			
			Instant start = Instant.now();
			LOG.info(String.format("service Start Time: %s" , start.toString()));

			final List<String> adAccountIds = dashboardDataProcessDao.getAccountIds(userbean.getUserObjectId());
			if (CollectionUtils.isEmpty(adAccountIds)) {
				LOG.info("Data is not present for given OID");
				throw new AccountNotFoundException(ACCOUNT_NOT_FOUND);
			}
			Instant mid = Instant.now();
			LOG.info(String.format("service mid after fetching account id, now SP start Time: %s" , mid.toString()));	
			

			final List<CaseOwnerCountProjectionDto> caseOwnerDetails = dashboardDataProcessDao
					.getCaseOwnerCountSQL(adAccountIds);
			LOG.info(methodName, "::Service Method caseOwnerDetails from DB:{}", caseOwnerDetails);
			response = this.getCaseOwnerCount(caseOwnerDetails);
			
			Instant end = Instant.now();
			LOG.info(String.format("Service Start Time: %s" , end.toString()));

		} catch (AccountNotFoundException ex) {
			throw new AccountNotFoundException(ACCOUNT_NOT_FOUND);

		}

		LOG.debug("GetCaseOwnerCount Service Method Ended.CorrelationId:-{} OID:-{}", userbean.getCorrelationId(),
				userbean.getUserObjectId());
		return response;
	}

	private CaseWorkerCaseOwnerCountRes getCaseOwnerCount(List<CaseOwnerCountProjectionDto> caseOwnwerDetails) {

		LOG.debug("getCaseOwnerCount Service Method Started.CorrelationId:-{} OID:-{}", userbean.getCorrelationId(),
				userbean.getUserObjectId());
		final CaseWorkerCaseOwnerCountRes response = new CaseWorkerCaseOwnerCountRes();

		try {
			final List<GenericCount> caseOwenrCountList = new ArrayList<>();
caseOwnwerDetails.forEach(e -> {	
				GenericCount genericCount = new GenericCount();
				genericCount.setId(e.getEmailaddress());
				genericCount.setEmail(e.getEmailaddress());
				genericCount.setCount(e.getIncident_count());
				genericCount.setValue(e.getOwnername());
				caseOwenrCountList.add(genericCount);
			});
			response.setStatus("Success");
			response.setTotalcount(String.valueOf(caseOwenrCountList.size()));
			response.setCaseworkercountlist(caseOwenrCountList);

		} catch (Exception e) {
			throw new SqlDatabaseServiceException(
					messageSource.getMessage("API_ERROR_SQLDATABASE", null, Locale.ENGLISH), e.getMessage());
		}
		LOG.debug("getCaseOwnerCount Service Method Ended.CorrelationId:-{} OID:-{}", userbean.getCorrelationId(),
				userbean.getUserObjectId());
		return response;

	}

	@Override
	public OpenCaseCountByStatusRes getOpenCaseCount() throws RecentCaseNotFoundException, AccountNotFoundException {
		final String methodName = "getOpenCaseCount";
		LOG.info("{} Service Method Started.CorrelationId:-{} OID:-{}-", methodName,
				userbean.getCorrelationId(), userbean.getUserObjectId());

		final OpenCaseCountByStatusRes response = new OpenCaseCountByStatusRes();
		final List<OpenCaseCount> openCaseCountList = new ArrayList<>();
		OpenCaseCount openCaseCount = null;
		try {
			final List<String> adAccountIds = dashboardDataProcessDao.getAccountIds(userbean.getUserObjectId());
			if (CollectionUtils.isEmpty(adAccountIds)) {
				LOG.info("Data is not present for given OID");
				throw new AccountNotFoundException(ACCOUNT_NOT_FOUND);

			}

			LOG.info("{} account ids from database:-{}", methodName, adAccountIds);
			final List<OpenCaseCountByStatusResDto> openCaseCountSummeryMap = dashboardDataProcessDao
					.getOpenCaseCount(adAccountIds);
			if (CollectionUtils.isNotEmpty(openCaseCountSummeryMap)) {
				final Map<String, List<OpenCaseCountByStatusResDto>> groupByPriceMap = openCaseCountSummeryMap.stream()
						.collect(Collectors.groupingBy(OpenCaseCountByStatusResDto::getCasestagename));

				for (Map.Entry<String, List<OpenCaseCountByStatusResDto>> entry : groupByPriceMap.entrySet()) {
					openCaseCount = new OpenCaseCount();
					// openCaseCount.setOpencasestatus(entry.getKey());
					openCaseCount.setCasesprogresstatus(entry.getKey());
					openCaseCount.setTotalcount(getTotalStausCodeCount(entry.getValue()));
					// openCaseCount.setOpencasecounts(getOpenCases(entry.getValue()));
					openCaseCount.setCaseprogresscounts(getOpenCases(entry.getValue()));
					openCaseCountList.add(openCaseCount);
				}
				// response.setOpencasecount(openCaseCountList);
				response.setCaseprogresscount(openCaseCountList);
				response.setStatus("Success");
			} else {
				throw new RecentCaseNotFoundException("Open cases not found in repository");
			}

		} catch (AccountNotFoundException ex) {
			throw new AccountNotFoundException(ACCOUNT_NOT_FOUND);
		}
		LOG.debug("{} correllation id:{}:: Open case count:-{}", methodName, userbean.getCorrelationId(),
				response.getCaseprogresscount());
		return response;
	}

	private String getTotalStausCodeCount(final List<OpenCaseCountByStatusResDto> stausCount) {
		return String.valueOf(stausCount.stream().mapToInt(OpenCaseCountByStatusResDto::getTotalrecordcount).sum());
	}

	private List<GenericCount> getOpenCases(List<OpenCaseCountByStatusResDto> openCases) {
		GenericCount genericCount = null;
		List<GenericCount> list = new ArrayList<>();
		for (OpenCaseCountByStatusResDto openCase : openCases) {
			genericCount = new GenericCount();
			// genericCount.setId(openCase.getStatuscode());
			// genericCount.setValue(openCase.getStatuscodename());
			genericCount.setId(openCase.getCaseprogresscode());
			genericCount.setValue(openCase.getCaseprogressname());
			genericCount.setCount(String.valueOf(openCase.getTotalrecordcount()));
			genericCount.setCasestage(openCase.getCasestage());
			list.add(genericCount);
		}
		return list;
	}

	@Override
	public OpenCaseCountRes getOpenCaseCountGeneric() throws AccountNotFoundException, DashboardCaseException {
		final String methodName = "getOpenCaseCountGeneric";

		LOG.debug("{} Service Method Started.CorrelationId:-{} OID:-{} : GroupId:{}", methodName,
				userbean.getCorrelationId(), userbean.getUserObjectId(), userbean.getGroups());

		final OpenCaseCountRes response = new OpenCaseCountRes();

		final List<String> adAccountIds = dashboardDataProcessDao.getAccountIds(userbean.getUserObjectId());
		if (CollectionUtils.isEmpty(adAccountIds)) {
			LOG.info("Data is not present for given OID");
			throw new AccountNotFoundException(ACCOUNT_NOT_FOUND);
		}
		String accIds = adAccountIds.stream().map(Object::toString).collect(Collectors.joining(","));

		final OpenCaseCountSummeryDto openCaseCountSummery = dashboardDataProcessDao.getCaseCountSummery(accIds);
		LOG.debug("{}::Case Summery details:-{}", methodName, openCaseCountSummery);
		if (null != openCaseCountSummery) {
			response.setTotalawaitingyourresponse(openCaseCountSummery.getAwaitingactions());
			response.setTotallatestoutcomelastweek(openCaseCountSummery.getOutcomecasecount());
			response.setTotalopencases(openCaseCountSummery.getOpencasecount());
			response.setTotalprioritycases(openCaseCountSummery.getPrioritycasecount());
			response.setTotaloverduecases(openCaseCountSummery.getDuecasecount());
			response.setStatus(SUCCESS);
		} else {
			throw new DashboardCaseException("No open case found");
		}

		LOG.debug("{}:: Service Method Ended.CorrelationId:-{} OID:-{}", userbean.getCorrelationId(), methodName,
				userbean.getUserObjectId());
		return response;
	}

}
