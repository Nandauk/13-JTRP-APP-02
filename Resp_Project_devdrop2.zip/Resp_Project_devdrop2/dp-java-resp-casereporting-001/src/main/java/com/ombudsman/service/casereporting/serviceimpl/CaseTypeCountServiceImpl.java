package com.ombudsman.service.casereporting.serviceimpl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ombudsman.service.casereporting.common.UserBean;
import com.ombudsman.service.casereporting.dao.ICaseReportingDataProcessDao;
import com.ombudsman.service.casereporting.dto.ViewCaseCountProjectionDto;
import com.ombudsman.service.casereporting.exception.AccountNotFoundException;
import com.ombudsman.service.casereporting.exception.DashboardCaseException;
import com.ombudsman.service.casereporting.model.CaseTypeCount;
import com.ombudsman.service.casereporting.model.response.CaseTypeCountRes;
import com.ombudsman.service.casereporting.repository.RecentCaseRepository;
import com.ombudsman.service.casereporting.service.ICaseTypeCountService;

@Service
public class CaseTypeCountServiceImpl implements ICaseTypeCountService {
	
	private static final String ACCOUNT_NOT_FOUND = "Account not found in repository";	
	private static final String COMMA = ",";

	@Autowired
	RecentCaseRepository recentCaseRepository;

	@Autowired
	UserBean userbean;

	@Autowired
	ICaseReportingDataProcessDao dashboardDataProcessDao;
	private static final Logger LOG = LogManager.getRootLogger();

	@Override
	public CaseTypeCountRes getCaseTypeCount() throws Exception {
		final String methodName = "getCaseTypeCount";
		LOG.debug("GetCaseTypeCount Service Method Started.CorrelationId:-{} OID:-{}", userbean.getCorrelationId(),
				userbean.getUserObjectId());

		CaseTypeCountRes response = new CaseTypeCountRes();

		LOG.debug(methodName, ":: organisation list is not empty.CorrelationId:-{} OID:-{}",
				userbean.getCorrelationId(), userbean.getUserObjectId());

		final List<String> adAccountIds = dashboardDataProcessDao.getAccountIds(userbean.getUserObjectId());
		if (CollectionUtils.isEmpty(adAccountIds)) {
			LOG.info("Data is not present for given OID");
			throw new AccountNotFoundException(ACCOUNT_NOT_FOUND);
		}

		final List<ViewCaseCountProjectionDto> businessInvestigationCount = dashboardDataProcessDao
				.getBusnissCountList(adAccountIds);
		if (CollectionUtils.isEmpty(businessInvestigationCount)) {
			throw new DashboardCaseException("case type count not found");
		}
		final Map<String, List<ViewCaseCountProjectionDto>> groupByPriceMap = businessInvestigationCount.stream()
				.collect(Collectors.groupingBy(ViewCaseCountProjectionDto::getViewid));
		groupByPriceMap.forEach((key, value) -> setBusinessCases(response, key, value));

		return response;
	}
	
	

	/*
	 * private void setBusinessCases(final CaseTypeCountRes response, final String
	 * key, final List<ViewCaseCountProjectionDto> value) { if (key.equals("1")) {
	 * response.setBusinesscount(getViewCaseCountForAll(value)); } if
	 * (key.equals("2")) {
	 * response.setComplainantcount(getViewCaseCountForAll(value)); } if
	 * (key.equals("3")) { response.setProductcount(getViewCaseCountForAll(value));
	 * } }
	 */
	
	private void setBusinessCases(final CaseTypeCountRes response, final String key,
			final List<ViewCaseCountProjectionDto> value) {
		if (key.equals("1")) {
			
			response.setBusinesscount(getViewCaseCountForAll(value));
		}
		if (key.equals("2")) {
			List<CaseTypeCount> complainantCases=getViewCaseCountForAll(value);
			List<CaseTypeCount> complainantList = groupById(complainantCases);
			response.setComplainantcount(complainantList);
		}
		if (key.equals("3")) {
			List<CaseTypeCount> businessCases=getViewCaseCountForAll(value);
			List<CaseTypeCount> productList = groupById(businessCases);
			response.setProductcount(productList);
		}
	}



	private List<CaseTypeCount> groupById(List<CaseTypeCount> businessCases) {
		Map<String, CaseTypeCount> groupedById = businessCases.stream()
		        .collect(Collectors.groupingBy(
		            CaseTypeCount::getId,
		            Collectors.collectingAndThen(
		                Collectors.reducing((a, b) -> {
		                    CaseTypeCount result = new CaseTypeCount();
		                    result.setId(a.getId());
		                    result.setValue(a.getValue()); // Assuming value is the same for the same id
		                    result.setInvestigationcount(
		                            String.valueOf(
		                                (a.getInvestigationcount() != null ? Integer.parseInt(a.getInvestigationcount()) : 0) +
		                                (b.getInvestigationcount() != null ? Integer.parseInt(b.getInvestigationcount()) : 0)
		                            )
		                        );
		                    result.setViewcount(a.getViewcount() + b.getViewcount());
		                    result.setOmbudsmancount(
		                            String.valueOf(
		                                (a.getOmbudsmancount() != null ? Integer.parseInt(a.getOmbudsmancount()) : 0) +
		                                (b.getOmbudsmancount() != null ? Integer.parseInt(b.getOmbudsmancount()) : 0)
		                            )
		                        );
		                    
		                    result.setTotal(
		                            String.valueOf(
		                                (a.getTotal() != null ? Integer.parseInt(a.getTotal()) : 0) +
		                                (b.getTotal() != null ? Integer.parseInt(b.getTotal()) : 0)
		                            )
		                        );
		                   
		                   
		                    return result;
		                }),
		                Optional::get
		            )
		        ));
		
		List<CaseTypeCount> groupedList = new ArrayList<>(groupedById.values());
		return groupedList;
	}	

}
