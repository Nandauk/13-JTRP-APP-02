#! /bin/bash
if [ -z "$1" ]; then
  echo "Usage: $0 [dv2|prf|prf-dr]"
  exit 1
fi

stage="$1"
#ENVIRONMENT="$stage"

#Set subscription ID based on environment
if [ "$stage" = "dv2" ]; then 
  echo "deploying to dv2 environment"
  SUBSCRIPTION_ID="b70424dd-d53a-40a3-98a4-0cf1f27c11f0"
  ENVIRON=dev2
  ENVIRONMENT=dv2
elif [ "$stage" = "prf" ]; then
  echo "deploying to prf environment"
  SUBSCRIPTION_ID="07285016-701b-4617-9557-1cedc46548fb"
  ENVIRON=prf
  ENVIRONMENT=prf
elif [ "$stage" = "prf-dr" ]; then
  echo "deploying to prf-dr environment"
  SUBSCRIPTION_ID="07285016-701b-4617-9557-1cedc46548fb"
  ENVIRON=prf 
  ENVIRONMENT=prf 
else
   echo "Invalid environment. Use 'dv2' or 'prf'."
   exit 1
fi     

#Set the subscription
az account set --subscription "$SUBSCRIPTION_ID"

# Generate ConfigMap YAML
cat <<EOF > dp-api-resp-${stage}-configmap.yaml
apiVersion: v1
kind: ConfigMap
metadata:
  name: dp-api-resp-casereporting
  namespace: var_namespace_respondent
data:
  AD_RESP_ISSUER_URI: https://ombportalrespb2c${ENVIRON}.b2clogin.com/tfp/0bb19641-84bf-404f-bf52-6d11ac41ab82/b2c_1a_signin_fosresp_dp/v2.0/
  AD_RESP_B2C_JWT_SET_URI: https://ombportalrespb2c${ENVIRON}.b2clogin.com/ombportalrespb2c${ENVIRON}.onmicrosoft.com/discovery/v2.0/keys?p=b2c_1a_signin_fosresp_dp
  SERVER_PORT: '8443'
  SESSION_BASE_URL: https://apim-${ENVIRONMENT}.financial-ombudsman.org.uk
  SESSION_FLAG: 'true'
  INFRA_TENENT_ID: 3df253a5-1a74-47e7-a5e0-204525367f22
EOF

echo "ConfigMap YAML generated: dp-api-resp-${stage}-configmap.yaml"