#! /bin/bash
if [ -z "$1" ]; then
  echo "Usage: $0 [dv2|prf|prf-dr]"
  exit 1
fi

stage="$1"
#ENVIRONMENT="$stage"

#Set subscription ID based on environment
if [ "$stage" = "dv2" ]; then 
  echo "deploying to dv2 environment"
  SUBSCRIPTION_ID="b70424dd-d53a-40a3-98a4-0cf1f27c11f0"
  ENVIRON=dev2
  ENVIRONMENT=dv2
  UPDATE_CASE_SERVICE_BUS_QUALIFIED_NAME=sb-dp-app-ext-uks-${ENVIRONMENT}-001.servicebus.windows.net
  CASE_EXPORT_SERVICE_BUS_QUALIFIED_NAME=sb-dp-app-int-uks-${ENVIRONMENT}-001.servicebus.windows.net
  BULK_UPDATE_CASE_SERVICE_BUS_QUALIFIED_NAME=sb-dp-app-int-uks-${ENVIRONMENT}-001.servicebus.windows.net
elif [ "$stage" = "prf" ]; then
  echo "deploying to prf environment"
  SUBSCRIPTION_ID="07285016-701b-4617-9557-1cedc46548fb"
  ENVIRON=prf
  ENVIRONMENT=prf
  UPDATE_CASE_SERVICE_BUS_QUALIFIED_NAME=sb-dp-app-ext-uks-${ENVIRONMENT}-001.servicebus.windows.net
  CASE_EXPORT_SERVICE_BUS_QUALIFIED_NAME=sb-dp-app-int-uks-${ENVIRONMENT}-001.servicebus.windows.net
  BULK_UPDATE_CASE_SERVICE_BUS_QUALIFIED_NAME=sb-dp-app-int-uks-${ENVIRONMENT}-001.servicebus.windows.net
elif [ "$stage" = "prf-dr" ]; then
  echo "deploying to prf-dr environment"
  SUBSCRIPTION_ID="07285016-701b-4617-9557-1cedc46548fb"
  ENVIRON=prf 
  ENVIRONMENT=prf 
  UPDATE_CASE_SERVICE_BUS_QUALIFIED_NAME=sb-dp-app-ext-ukw-${ENVIRONMENT}-001.servicebus.windows.net
  CASE_EXPORT_SERVICE_BUS_QUALIFIED_NAME=sb-dp-app-int-ukw-${ENVIRONMENT}-001.servicebus.windows.net
  BULK_UPDATE_CASE_SERVICE_BUS_QUALIFIED_NAME=sb-dp-app-int-ukw-${ENVIRONMENT}-001.servicebus.windows.net

else
   echo "Invalid environment. Use 'dv2' or 'prf'."
   exit 1
fi     

# Convert ENVIRONMENT to uppercase
ENVIRONMENT_UPPER=$(echo "$ENVIRONMENT" | tr '[:lower:]' '[:upper:]')

#Set the subscription
az account set --subscription "$SUBSCRIPTION_ID"

#Define SPNs
CASEUPDATE_SPN="SPN-APP-CM-CASEUPDATE-${ENVIRONMENT}"
INT_CASEUPDATE_SPN="SPN-APP-MS-CM-CASEUPDATE-${ENVIRONMENT}"
CASEEXP_SPN="SPN-APP-MS-CM-CEXPT-${ENVIRONMENT}"

# Generate ConfigMap YAML
cat <<EOF > dp-api-resp-${stage}-configmap.yaml
apiVersion: v1
kind: ConfigMap
metadata:
  name: dp-api-resp-casemanagement
  namespace: var_namespace_respondent
data:
  AD_RESP_ISSUER_URI: https://ombportalrespb2c${ENVIRON}.b2clogin.com/tfp/0bb19641-84bf-404f-bf52-6d11ac41ab82/b2c_1a_signin_fosresp_dp/v2.0/
  AD_RESP_B2C_JWT_SET_URI: https://ombportalrespb2c${ENVIRON}.b2clogin.com/ombportalrespb2c${ENVIRON}.onmicrosoft.com/discovery/v2.0/keys?p=b2c_1a_signin_fosresp_dp
  SERVER_PORT: '8443'
  SESSION_BASE_URL: https://portal-${ENVIRONMENT}.financial-ombudsman.org.uk
  SESSION_FLAG: 'true'   
  CASEUPDATE_APIMURL: https://apim-${ENVIRONMENT}.financial-ombudsman.org.uk/respondentfunctions/api
  CASEUPDATE_EVENTNAME: caseUpdate
  NOTIFICATIONAPIURL: /ombudsmanservice/v1/notification/postnotification
  INDIVIDUALIDAPIURL: /ombudsmanservice/v1/usermanagement/respondentadminindividualid
  UPDATE_CASE_SERVICE_BUS_QUALIFIED_NAME: ${UPDATE_CASE_SERVICE_BUS_QUALIFIED_NAME}   
  INFRA_TENANTID: 3df253a5-1a74-47e7-a5e0-204525367f22
  SB_CASEEXP_CLIENTID: $(az ad sp list --display-name $CASEEXP_SPN --query "[0].appId" --output tsv)
  SB_CASEUPDATE_CLIENTID: $(az ad sp list --display-name $CASEUPDATE_SPN --query "[0].appId" --output tsv)
  SB_INT_CASEUPDATE_CLIENTID: $(az ad sp list --display-name $INT_CASEUPDATE_SPN --query "[0].appId" --output tsv)
  CASEUPDATE_SB_QUEUE_NAME: queue-dp-ext-input-${ENVIRONMENT}
  CASE_EXPORT_SERVICE_BUS_QUALIFIED_NAME: ${CASE_EXPORT_SERVICE_BUS_QUALIFIED_NAME}
  CASE_EXPORT_SB_QUEUE_NAME: queue-dp-int-caseexport-queue-${ENVIRONMENT}
  CASE_EXPORT_AVAILABLE_DOWNLOAD_URL: /ombudsmanservice/v1/notification/gettypenotification
  APIM_URL: https://apim-${ENVIRON}.financial-ombudsman.org.uk
  BULK_UPDATE_CASE_SERVICE_BUS_QUALIFIED_NAME : ${BULK_UPDATE_CASE_SERVICE_BUS_QUALIFIED_NAME}
  BULK_CASEUPDATE_SB_QUEUE_NAME : queue-dp-int-caseupdate-queue-${ENVIRONMENT}
EOF

echo "ConfigMap YAML generated: dp-api-resp-${stage}-configmap.yaml"
