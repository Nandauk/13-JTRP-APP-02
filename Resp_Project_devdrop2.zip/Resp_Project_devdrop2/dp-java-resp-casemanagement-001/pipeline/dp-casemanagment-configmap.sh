#! /bin/bash
az account set --subscription "b70424dd-d53a-40a3-98a4-0cf1f27c11f0"
cat <<EOF > dp-api-resp-dv2-configmap.yaml
apiVersion: v1
kind: ConfigMap
metadata:
  name: dp-api-resp-casemanagement
  namespace: var_namespace_respondent
data:
EOF

ENVIRONMENT=dv2
CASEUPDATE_SPN="SPN-APP-CM-CASEUPDATE-${ENVIRONMENT}"
INT_CASEUPDATE_SPN="SPN-APP-MS-CM-CASEUPDATE-${ENVIRONMENT}"
CASEEXP_SPN="SPN-APP-MS-CM-CEXPT-${ENVIRONMENT}"
cat <<EOF>> dp-api-resp-dv2-configmap.yaml
   AD_RESP_ISSUER_URI: https://ombportalrespb2cdev.b2clogin.com/tfp/65a36538-9d84-4717-a24f-19666eb31ca6/b2c_1a_smart_hrd_poc/v2.0/
   AD_RESP_B2C_JWT_SET_URI: https://ombportalrespb2cdev.b2clogin.com/ombportalrespb2cdev.onmicrosoft.com/discovery/v2.0/keys?p=b2c_1a_smart_hrd_poc
   SERVER_PORT: '8443'
   SESSION_BASE_URL: hhttps://portal-dev2.financial-ombudsman.org.uk
   SESSION_FLAG: 'true'   
   CASEUPDATE_APIMURL: https://apim-dev2.financial-ombudsman.org.uk/respondentfunctions/api
   CASEUPDATE_EVENTNAME: caseUpdate
   NOTIFICATIONAPIURL: /ombudsmanservice/v1/notification/postnotification
   INDIVIDUALIDAPIURL: /ombudsmanservice/v1/usermanagement/respondentadminindividualid
   UPDATE_CASE_SERVICE_BUS_QUALIFIED_NAME: sb-dp-app-ext-uks-${ENVIRONMENT}-001.servicebus.windows.net   
   INFRA_TENANTID: 3df253a5-1a74-47e7-a5e0-204525367f22
   SB_CASEEXP_CLIENTID: $(az ad sp list --display-name $CASEEXP_SPN --query "[0].appId" --output tsv)
   SB_CASEUPDATE_CLIENTID: $(az ad sp list --display-name $CASEUPDATE_SPN --query "[0].appId" --output tsv)
   SB_INT_CASEUPDATE_CLIENTID: $(az ad sp list --display-name $INT_CASEUPDATE_SPN --query "[0].appId" --output tsv)
   CASEUPDATE_SB_QUEUE_NAME: queue-dp-ext-input-${ENVIRONMENT}
   CASE_EXPORT_SERVICE_BUS_QUALIFIED_NAME: sb-dp-app-int-uks-${ENVIRONMENT}-001.servicebus.windows.net
   CASE_EXPORT_SB_QUEUE_NAME: queue-dp-int-caseexport-queue-${ENVIRONMENT}
   CASE_EXPORT_AVAILABLE_DOWNLOAD_URL: /ombudsmanservice/v1/notification/gettypenotification
   APIM_URL: https://apim-dev2.financial-ombudsman.org.uk
   BULK_UPDATE_CASE_SERVICE_BUS_QUALIFIED_NAME : sb-dp-app-int-uks-${ENVIRONMENT}-001.servicebus.windows.net
   BULK_CASEUPDATE_SB_QUEUE_NAME : queue-dp-int-caseupdate-queue-${ENVIRONMENT}
EOF

cat dp-api-resp-${ENVIRONMENT}-configmap.yaml