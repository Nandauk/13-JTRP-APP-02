          #casemanagement
          #! bin/bash
          sudo touch "/mnt/configmap_casereporting/dp-api-resp-dv2-configmap.yaml"
          sudo chmod 777 "/mnt/configmap_casereporting/dp-api-resp-dv2-configmap.yaml"
          configmap_file_path="/mnt/configmap_casereporting/dp-api-resp-dv2-configmap.yaml"
          cat > $(configmap_file_path) <<EOF
          apiVersion: v1
          kind: ConfigMap
          metadata:
            name: dp-api-resp-casemanagement
            namespace: var_namespace_respondent
          data:
            AD_RESP_ISSUER_URI="https://ombportalrespb2cdev.b2clogin.com/tfp/65a36538-9d84-4717-a24f-19666eb31ca6/b2c_1a_smart_hrd_poc/v2.0/"
            echo AD_RESP_ISSUER_URI": $AD_RESP_ISSUER_URI " >> "/mnt/configmap_casereporting/dp-api-resp-dv2-configmap.yaml"
            AD_RESP_B2C_JWT_SET_URI="https://ombportalrespb2cdev.b2clogin.com/ombportalrespb2cdev.onmicrosoft.com/discovery/v2.0/keys?p=b2c_1a_smart_hrd_poc"
            echo AD_RESP_B2C_JWT_SET_URI": $AD_RESP_B2C_JWT_SET_URI " >> "/mnt/configmap_casereporting/dp-api-resp-dv2-configmap.yaml"
            SERVER_PORT="8443"
            echo SERVER_PORT": $SERVER_PORT " >> "/mnt/configmap_casereporting/dp-api-resp-dv2-configmap.yaml"
          EOF