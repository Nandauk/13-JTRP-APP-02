package com.ombudsman.service.respondent.model;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertSame;

import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.Test;

class CaseExportTest {

    @Test
    void testGettersAndSetters() {
        CaseExport caseExport = new CaseExport();

        caseExport.setVersion("v1");
        assertEquals("v1", caseExport.getVersion());

        caseExport.setMessageId("MSG-123");
        assertEquals("MSG-123", caseExport.getMessageId());

        caseExport.setEntityName("ENTITY");
        assertEquals("ENTITY", caseExport.getEntityName());

        caseExport.setTemplateId(42);
        assertEquals(42, caseExport.getTemplateId());

        Attributes attr = new Attributes();
        caseExport.setAttributes(attr);
        assertSame(attr, caseExport.getAttributes());

        List<String> numCases = Arrays.asList("CASE1", "CASE2");
        caseExport.setNumberOfCases(numCases);
        assertSame(numCases, caseExport.getNumberOfCases());
    }
}
