package com.ombudsman.service.respondent.serviceimpl;

import static org.assertj.core.api.Assertions.assertThat;

import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.anyList;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.sql.SQLException;
import java.util.Arrays;
import java.util.List;

import javax.security.auth.login.AccountNotFoundException;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.ombudsman.service.respondent.common.UserBean;
import com.ombudsman.service.respondent.exception.DbRecordCreationException;
import com.ombudsman.service.respondent.exception.InvalidOrganisationException;
import com.ombudsman.service.respondent.exception.MandatoryFieldMissingException;
import com.ombudsman.service.respondent.exception.UnAuthorisedException;
import com.ombudsman.service.respondent.model.request.AssignCasesReq;
import com.ombudsman.service.respondent.model.response.CaseAssignmentRes;
import com.ombudsman.service.respondent.service.repository.CaseListJdbcRepository;

@ExtendWith(MockitoExtension.class)
class CaseAssignmentServiceImplTest {

    private static final String MISSING_FIELD = "MISSING_FIELD";

	@InjectMocks
    private CaseAssignmentServiceImpl caseAssignmentService;

    @Mock
    private CaseListJdbcRepository caseListJdbcRepository;

    @Mock
    private UserBean userBean;

    private AssignCasesReq request;

    @BeforeEach
    void setUp() {
        //default request
        request = new AssignCasesReq();
        request.setCaseIds(Arrays.asList("PNX-389587-Q2X5", "PNX-388531-N9L9"));
        request.setOid("4C4AF41C-F4C3-4C98-9B36-65F71650C7B0");

        // Logged-in user
        when(userBean.getUserObjectId()).thenReturn("1852697B-D1AD-41EC-A326-D633B64C0294");
        when(userBean.getCorrelationId()).thenReturn("test-correlation-id");
    }

    @DisplayName("assignCases - Success Scenario")
    @Test
    void testAssignCases_Success() throws SQLException, UnAuthorisedException, InvalidOrganisationException {
        // 1) Mock DB calls
        List<String> incidentIds = Arrays.asList("INC001", "INC002");
        when(caseListJdbcRepository.getIncidentIdsByTicketNumbers(request.getCaseIds()))
            .thenReturn(incidentIds);

        // The user/cases are valid
        when(caseListJdbcRepository.validateUserAndCases(request.getOid(), incidentIds))
            .thenReturn(true);

        when(caseListJdbcRepository.assignCasesToUser(incidentIds, request.getOid()))
            .thenReturn("Nanda UKProfile");

        CaseAssignmentRes response = caseAssignmentService.assignCases(request);

        assertNotNull(response, "Response should not be null");
        assertThat(response.getCode()).isEqualTo("200");
        assertThat(response.getMessage()).isEqualTo("Cases assigned to Nanda UKProfile");

        // 4) Verify createAuditForCaseAssignment was called
        verify(caseListJdbcRepository).createAuditForCaseAssignment(
                "dp-java-respondent-db-casemanagement-001",
                "cases",
                "4C4AF41C-F4C3-4C98-9B36-65F71650C7B0",  // the user we assigned
                "Nanda UKProfile",
                incidentIds,
                "1852697B-D1AD-41EC-A326-D633B64C0294",  // the logged-in user
                "caseAssignmentService"
        );
    }

    @DisplayName("assignCases - Invalid Organisation")
    @Test
    void testAssignCases_() throws SQLException, UnAuthorisedException, InvalidOrganisationException {
        // Suppose the incident ID are found
        List<String> incidentIds = Arrays.asList("INC001", "INC002");
        when(caseListJdbcRepository.getIncidentIdsByTicketNumbers(request.getCaseIds()))
            .thenReturn(incidentIds);

        // But validateUserAndCases returns false -> invalid org
        when(caseListJdbcRepository.validateUserAndCases(request.getOid(), incidentIds))
            .thenReturn(false);

        // 2) Invoke
        InvalidOrganisationException ex = assertThrows(
            InvalidOrganisationException.class,
            () -> caseAssignmentService.assignCases(request)
        );

        // 3) Assert
        assertThat(ex.getMessage()).isEqualTo("Cases belong to an invalid or unauthorised account.");
    }
    
    @DisplayName("assignCases - missing userOid")
    @Test
    void testAssignCases_missing_userOid() throws MandatoryFieldMissingException {
        // Arrange: Create a request with an empty userOid and some caseIds
    	AssignCasesReq request = new AssignCasesReq();
        request.setOid("");
        request.setCaseIds(Arrays.asList("CASE001", "CASE002"));
        
        // Act and Assert: Expect a MandatoryFieldMissingException to be thrown
        MandatoryFieldMissingException ex = assertThrows(
            MandatoryFieldMissingException.class,
            () -> caseAssignmentService.assignCases(request)
        );
        
        // Assert: Verify that the exception message is as expected
        assertThat(ex.getMessage()).isEqualTo("MISSING_FIELD");
    }

    @DisplayName("assignCases - missing caseIds")
    @Test
    void testAssignCases_missing_caseIds() throws MandatoryFieldMissingException {
        // Arrange: Create a request with an empty userOid and some caseIds
    	AssignCasesReq request = new AssignCasesReq();
        request.setOid("abc");
        request.setCaseIds(Arrays.asList());
        
        // Act and Assert: Expect a MandatoryFieldMissingException to be thrown
        MandatoryFieldMissingException ex = assertThrows(
            MandatoryFieldMissingException.class,
            () -> caseAssignmentService.assignCases(request)
        );
     
        assertThat(ex.getMessage()).isEqualTo("MISSING_FIELD");
    }
  


   

}
