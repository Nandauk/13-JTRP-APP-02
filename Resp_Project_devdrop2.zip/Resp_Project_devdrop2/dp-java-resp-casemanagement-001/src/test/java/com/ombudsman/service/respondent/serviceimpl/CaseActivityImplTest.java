package com.ombudsman.service.respondent.serviceimpl;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

import java.time.OffsetDateTime;
import java.util.Locale;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.context.MessageSource;

import com.ombudsman.service.respondent.common.UserBean;
import com.ombudsman.service.respondent.common.WebClientData;
import com.ombudsman.service.respondent.exception.CaseManagementInvalidEventNameException;
import com.ombudsman.service.respondent.exception.RecordCreationException;
import com.ombudsman.service.respondent.model.UpdateCase;
import com.ombudsman.service.respondent.model.dto.AuditMaster;
import com.ombudsman.service.respondent.model.dto.NotificationModel;
import com.ombudsman.service.respondent.model.dto.RequestModel;
import com.ombudsman.service.respondent.model.dto.UserEventConfiguration;
import com.ombudsman.service.respondent.service.repository.AuditRepository;
import com.ombudsman.service.respondent.service.repository.RequestModelRepository;
import com.ombudsman.service.respondent.service.repository.UserEventConfigurationRepository;

@ExtendWith(MockitoExtension.class)
public class CaseActivityImplTest {

    @InjectMocks
    private CaseActivityImpl caseActivity;

    @Mock
    private UserBean userbean;

    @Mock
    private AuditRepository auditMasterRepository;

    @Mock
    private MessageSource messageSource;

    @Mock
    private UserEventConfigurationRepository userEventConfigurationRepository;

    @Mock
    private RequestModelRepository requestModelRepository;

    @Mock
    private WebClientData webClientData;

    @Mock
    private UserEventConfiguration userEventConfiguration;

    @BeforeEach
    public void setUp() {
        when(userbean.getUserObjectId()).thenReturn("USER123");
        when(userbean.getName()).thenReturn("Admin");
        doReturn(userEventConfiguration).when(userEventConfigurationRepository).getUserEventRecord(anyString());
        when(userEventConfiguration.getUserEventName()).thenReturn("EventName");

        // Set a default value for userEventName to avoid null
        caseActivity.userEventName = "DefaultEventName";
    }

 
    @Test
    @DisplayName("Test Activity Failure Due to Record Creation Exception")
    public void testActivity_Failure_RecordCreation() {
        UpdateCase updateCase = new UpdateCase();
        updateCase.setComments("Some Comments");
        String ticketNumber = "TICKET123";

        when(requestModelRepository.save(any(RequestModel.class))).thenThrow(new RuntimeException("DB Error"));

        when(messageSource.getMessage(anyString(), any(), eq(Locale.ENGLISH)))
                .thenReturn("Record Creation Failed. Please Try Again.");

        RecordCreationException exception = assertThrows(RecordCreationException.class,
                () -> caseActivity.activity(updateCase, ticketNumber));

        assertEquals("Record Creation Failed. Please Try Again. ", exception.getMessage());
        verify(auditMasterRepository).save(any(AuditMaster.class));
        verify(requestModelRepository).save(any(RequestModel.class));
        verify(webClientData, never()).caseupdateNotificationWebclient(any(NotificationModel.class));
    }
}
