package com.ombudsman.service.respondent.model.dto;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import static org.junit.jupiter.api.Assertions.*;
@ExtendWith(SpringExtension.class)
public class NotificationTest {
	@InjectMocks

    private Notification notification;

    @BeforeEach
    public void setUp() {
        notification = new Notification();
    }

    @Test
    public void testGetterAndSetter() {
        // Set values
        Long notificationId = 1L;
        String requestId = "REQ123";
        String userOid = "USER123";
        String requestingActivityName = "Activity Name";
        String notificationStatusId = "STATUS123";
        String notificationStatusDescription = "Notification Status Description";
        String message = "This is a message.";
        String fileDownloadUrl = "http://example.com/download";
        String createdOn = "2025-01-10";
        String createdBy = "Admin";
        String modifiedOn = "2025-01-11";
        String modifiedBy = "User123";

        notification.setNotificationid(notificationId);
        notification.setRequestId(requestId);
        notification.setUserOid(userOid);
        notification.setRequestingActivityName(requestingActivityName);
        notification.setNotificationStatusId(notificationStatusId);
        notification.setNotificationStatusDescription(notificationStatusDescription);
        notification.setMessage(message);
        notification.setFileDownloadUrl(fileDownloadUrl);
        notification.setCreatedOn(createdOn);
        notification.setCreatedBy(createdBy);
        notification.setModifiedOn(modifiedOn);
        notification.setModifiedBy(modifiedBy);

        // Assert values
        assertEquals(notificationId, notification.getNotificationid());
        assertEquals(requestId, notification.getRequestId());
        assertEquals(userOid, notification.getUserOid());
        assertEquals(requestingActivityName, notification.getRequestingActivityName());
        assertEquals(notificationStatusId, notification.getNotificationStatusId());
        assertEquals(notificationStatusDescription, notification.getNotificationStatusDescription());
        assertEquals(message, notification.getMessage());
        assertEquals(fileDownloadUrl, notification.getFileDownloadUrl());
        assertEquals(createdOn, notification.getCreatedOn());
        assertEquals(createdBy, notification.getCreatedBy());
        assertEquals(modifiedOn, notification.getModifiedOn());
        assertEquals(modifiedBy, notification.getModifiedBy());
    }
}
