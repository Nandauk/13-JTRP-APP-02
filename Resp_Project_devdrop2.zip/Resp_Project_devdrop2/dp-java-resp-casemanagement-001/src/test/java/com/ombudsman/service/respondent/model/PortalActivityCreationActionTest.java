package com.ombudsman.service.respondent.model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

class PortalActivityCreationActionTest {

    @Test
    void testGettersAndSetters() {
        PortalActivityCreationAction action = new PortalActivityCreationAction();

        action.setDigitalPortalUserName("dpUser");
        assertEquals("dpUser", action.getDigitalPortalUserName());

        action.setDigitalPortalUserEmailAddress("dpUser@example.com");
        assertEquals("dpUser@example.com", action.getDigitalPortalUserEmailAddress());

        action.setContactId("CONT-555");
        assertEquals("CONT-555", action.getContactId());
    }
}
