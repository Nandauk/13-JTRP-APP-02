package com.ombudsman.service.respondent.model;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertSame;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;

class OrganisationComplainantTest {

    @Test
    void testGettersAndSetters() {
        OrganisationComplainant orgCompl = new OrganisationComplainant();

        // Inherited from GenericCaseLinkAndOrganisation
        orgCompl.setFos_numberofemployees("10");
        assertEquals("10", orgCompl.getFos_numberofemployees());

        orgCompl.setFos_organisationid("ORG-111");
        assertEquals("ORG-111", orgCompl.getFos_organisationid());

        orgCompl.setName("OrgName");
        assertEquals("OrgName", orgCompl.getName());

        orgCompl.setBusines_scharity_trust("Charity");
        assertEquals("Charity", orgCompl.getBusines_scharity_trust());

        orgCompl.setContactnumber("555-9999");
        assertEquals("555-9999", orgCompl.getContactnumber());

        orgCompl.setAddress("123 Elm Street");
        assertEquals("123 Elm Street", orgCompl.getAddress());

        List<Complainant> members = new ArrayList<>();
        orgCompl.setMembers(members);
        assertSame(members, orgCompl.getMembers());
    }
}
