package com.ombudsman.service.respondent.model;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

class UpdateCaseTest {

    @Test
    void testGettersAndSetters() {
        UpdateCase uc = new UpdateCase();

        uc.setCaseId("CASE-111");
        assertEquals("CASE-111", uc.getCaseId());

        uc.setComments("Some comments");
        assertEquals("Some comments", uc.getComments());

        uc.setDetails("Details here");
        assertEquals("Details here", uc.getDetails());

        uc.setReasonForChange(101L);
        assertEquals(101L, uc.getReasonForChange());

        uc.setPackageId("PKG-888");
        assertEquals("PKG-888", uc.getPackageId());

        String[] accIds = {"ACC1", "ACC2"};
        uc.setUsersAccountIds(accIds);
        assertArrayEquals(accIds, uc.getUsersAccountIds());

        uc.setDigitalPortalUserName("dpUser");
        assertEquals("dpUser", uc.getDigitalPortalUserName());

        uc.setDigitalPortalUserEmailAddress("dpUser@example.com");
        assertEquals("dpUser@example.com", uc.getDigitalPortalUserEmailAddress());

        uc.setContactId("CONT-123");
        assertEquals("CONT-123", uc.getContactId());

        uc.setIsRespondent("true");
        assertEquals("true", uc.getIsRespondent());
    }
}
