package com.ombudsman.service.respondent.model.dto;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

class ComplainantDtoTest {

    @Test
    void testGettersAndSetters() {
        ComplainantDto dto = new ComplainantDto();

        // Basic fields
        dto.setSuffix("Jr.");
        assertEquals("Jr.", dto.getSuffix());

        dto.setAddress1_composite("123 Main St");
        assertEquals("123 Main St", dto.getAddress1_composite());

        dto.setTelephone1("555-1111");
        assertEquals("555-1111", dto.getTelephone1());

        dto.setTelephone2("555-2222");
        assertEquals("555-2222", dto.getTelephone2());

        dto.setEmailaddress1("test@example.com");
        assertEquals("test@example.com", dto.getEmailaddress1());

        dto.setBirthdate("1990-01-01");
        assertEquals("1990-01-01", dto.getBirthdate());

        dto.setOrganisation_existInComplainant("true");
        assertEquals("true", dto.getOrganisation_existInComplainant());

        dto.setFirstname("John");
        assertEquals("John", dto.getFirstname());

        dto.setMiddlename("M.");
        assertEquals("M.", dto.getMiddlename());

        dto.setLastname("Doe");
        assertEquals("Doe", dto.getLastname());

        dto.setParentcustomerid("PARENT-123");
        assertEquals("PARENT-123", dto.getParentcustomerid());

        // Fields from CaseLink Query
        dto.setFos_case("CASE-001");
        assertEquals("CASE-001", dto.getFos_case());

        dto.setFos_role("ROLE-VAL");
        assertEquals("ROLE-VAL", dto.getFos_role());

        dto.setFos_individualid("IND-999");
        assertEquals("IND-999", dto.getFos_individualid());

        dto.setFos_organisationid("ORG-ABC");
        assertEquals("ORG-ABC", dto.getFos_organisationid());

        dto.setFos_reference("REF-777");
        assertEquals("REF-777", dto.getFos_reference());

        dto.setFos_representativecaselinkid("REP-LINK-123");
        assertEquals("REP-LINK-123", dto.getFos_representativecaselinkid());

        dto.setFos_caselinkid("CL-345");
        assertEquals("CL-345", dto.getFos_caselinkid());

        dto.setFos_numberofemployees("100");
        assertEquals("100", dto.getFos_numberofemployees());

        dto.setFos_numberofpartners("5");
        assertEquals("5", dto.getFos_numberofpartners());

        dto.setFos_annualturnover("1M");
        assertEquals("1M", dto.getFos_annualturnover());

        dto.setFos_balancesheet("BalanceSheetVal");
        assertEquals("BalanceSheetVal", dto.getFos_balancesheet());

        dto.setFos_islinkedorpartnered("Yes");
        assertEquals("Yes", dto.getFos_islinkedorpartnered());

        dto.setFos_annualincome("500K");
        assertEquals("500K", dto.getFos_annualincome());

        dto.setFos_netassets("200K");
        assertEquals("200K", dto.getFos_netassets());

        dto.setFos_businesstypecode("BusTypeCode");
        assertEquals("BusTypeCode", dto.getFos_businesstypecode());

        dto.setFos_preferredemailaddress("pref@example.com");
        assertEquals("pref@example.com", dto.getFos_preferredemailaddress());
    }
}
