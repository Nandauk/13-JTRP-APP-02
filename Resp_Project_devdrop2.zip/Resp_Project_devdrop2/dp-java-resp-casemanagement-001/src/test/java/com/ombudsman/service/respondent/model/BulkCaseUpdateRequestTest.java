package com.ombudsman.service.respondent.model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.Test;

import com.ombudsman.service.respondent.model.request.BulkCaseUpdateRequest;

public class BulkCaseUpdateRequestTest {

    @Test
    public void testGetSetTemplateId() {
        BulkCaseUpdateRequest request = new BulkCaseUpdateRequest();
        Integer templateId = 123;
        request.setTemplateId(templateId);
        assertEquals(templateId, request.getTemplateId());
    }

    @Test
    public void testGetSetUserId() {
        BulkCaseUpdateRequest request = new BulkCaseUpdateRequest();
        String userId = "user123";
        request.setUserId(userId);
        assertEquals(userId, request.getUserId());
    }

    @Test
    public void testGetSetUsersAccountIds() {
        BulkCaseUpdateRequest request = new BulkCaseUpdateRequest();
        List<String> usersAccountIds = Arrays.asList("account1", "account2");
        request.setUsersAccountIds(usersAccountIds);
        assertEquals(usersAccountIds, request.getUsersAccountIds());
    }

    @Test
    public void testGetSetPackageIdReq() {
        BulkCaseUpdateRequest request = new BulkCaseUpdateRequest();
        String packageIdReq = "package123";
        request.setPackageIdReq(packageIdReq);
        assertEquals(packageIdReq, request.getPackageIdReq());
    }

    @Test
    public void testGetSetReasonForChange() {
        BulkCaseUpdateRequest request = new BulkCaseUpdateRequest();
        Long reasonForChange = 456L;
        request.setReasonForChange(reasonForChange);
        assertEquals(reasonForChange, request.getReasonForChange());
    }

    @Test
    public void testGetSetDetails() {
        BulkCaseUpdateRequest request = new BulkCaseUpdateRequest();
        String details = "details here";
        request.setDetails(details);
        assertEquals(details, request.getDetails());
    }

    @Test
    public void testGetSetNumberOfCases() {
        BulkCaseUpdateRequest request = new BulkCaseUpdateRequest();
        BulkCaseUpdateRequest.NumberOfCases case1 = new BulkCaseUpdateRequest.NumberOfCases();
        case1.setComment("comment1");
        case1.setCaseId("case1");
        BulkCaseUpdateRequest.NumberOfCases case2 = new BulkCaseUpdateRequest.NumberOfCases();
        case2.setComment("comment2");
        case2.setCaseId("case2");
        List<BulkCaseUpdateRequest.NumberOfCases> numberOfCases = Arrays.asList(case1, case2);
        request.setNumberOfCases(numberOfCases);
        assertEquals(numberOfCases, request.getNumberOfCases());
    }

    @Test
    public void testNumberOfCasesGetSetComment() {
        BulkCaseUpdateRequest.NumberOfCases numberOfCases = new BulkCaseUpdateRequest.NumberOfCases();
        String comment = "test comment";
        numberOfCases.setComment(comment);
        assertEquals(comment, numberOfCases.getComment());
    }

    @Test
    public void testNumberOfCasesGetSetCaseId() {
        BulkCaseUpdateRequest.NumberOfCases numberOfCases = new BulkCaseUpdateRequest.NumberOfCases();
        String caseId = "case123";
        numberOfCases.setCaseId(caseId);
        assertEquals(caseId, numberOfCases.getCaseId());
    }
}

