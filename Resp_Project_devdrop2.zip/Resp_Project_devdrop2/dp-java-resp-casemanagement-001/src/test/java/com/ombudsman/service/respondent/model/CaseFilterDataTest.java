package com.ombudsman.service.respondent.model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

class CaseFilterDataTest {

    @Test
    void testConstructorAndSettersGetters() {
        // Using constructor with (id, value)
        CaseFilterData cfd = new CaseFilterData("ID1", "Value1");
        assertEquals("ID1", cfd.getId());
        assertEquals("Value1", cfd.getValue());

        // Modify with setters
        cfd.setId("ID2");
        cfd.setValue("Value2");
        assertEquals("ID2", cfd.getId());
        assertEquals("Value2", cfd.getValue());
    }
}
