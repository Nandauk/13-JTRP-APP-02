package com.ombudsman.service.respondent.model.dto;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import static org.junit.jupiter.api.Assertions.*;
@ExtendWith(SpringExtension.class)
public class RepresentativeDtoTest {
	@InjectMocks
    private RepresentativeDto representativeDto;

    @BeforeEach
    public void setUp() {
        representativeDto = new RepresentativeDto();
    }

    @Test
    public void testGetterAndSetter() {
        // Set values
        representativeDto.setRepresentativeType("Type123");
        representativeDto.setOrganisation("Organisation123");
        representativeDto.setReferenace("Reference123");
        representativeDto.setContactid("Contact123");

        // Assert values
        assertEquals("Type123", representativeDto.getRepresentativeType());
        assertEquals("Organisation123", representativeDto.getOrganisation());
        assertEquals("Reference123", representativeDto.getReferenace());
        assertEquals("Contact123", representativeDto.getContactid());
    }
}
