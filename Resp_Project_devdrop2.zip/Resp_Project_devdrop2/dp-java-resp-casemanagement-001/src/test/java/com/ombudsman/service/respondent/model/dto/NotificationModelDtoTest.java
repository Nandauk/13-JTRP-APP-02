package com.ombudsman.service.respondent.model.dto;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class NotificationModelDtoTest {

    private NotificationModelDto notificationModelDto;
    private NotificationModel notificationModel;

    @BeforeEach
    public void setUp() {
        notificationModelDto = new NotificationModelDto();
        notificationModel = new NotificationModel();
    }

    @Test
    public void testGetterAndSetter() {
        // Set values
        notificationModelDto.setNotificationModel(notificationModel);
        notificationModelDto.setSessionflag(true);

        // Assert values
        assertEquals(notificationModel, notificationModelDto.getNotificationModel());
        assertTrue(notificationModelDto.isSessionflag());
    }

    @Test
    public void testNotificationModelSetterAndGetter() {
        NotificationModel newNotificationModel = new NotificationModel();
        notificationModelDto.setNotificationModel(newNotificationModel);
        assertEquals(newNotificationModel, notificationModelDto.getNotificationModel());
    }

    @Test
    public void testSessionflagSetterAndGetter() {
        notificationModelDto.setSessionflag(false);
        assertFalse(notificationModelDto.isSessionflag());
    }
}
