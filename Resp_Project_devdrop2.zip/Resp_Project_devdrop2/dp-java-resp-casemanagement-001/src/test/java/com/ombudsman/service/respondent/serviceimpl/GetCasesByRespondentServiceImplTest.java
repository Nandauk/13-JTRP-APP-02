package com.ombudsman.service.respondent.serviceimpl;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.assertj.core.util.Lists;
import org.json.JSONException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.ombudsman.service.respondent.common.CaseListMapper;
import com.ombudsman.service.respondent.common.UserBean;
import com.ombudsman.service.respondent.exception.CaseListNotFoundException;
import com.ombudsman.service.respondent.exception.SQLDataAccessException;
import com.ombudsman.service.respondent.model.Case;
import com.ombudsman.service.respondent.model.CaseFilterData;
import com.ombudsman.service.respondent.model.CaseListDto;
import com.ombudsman.service.respondent.model.Filters;
import com.ombudsman.service.respondent.model.request.GetCasesByRespondentReq;
import com.ombudsman.service.respondent.model.response.CasesManagementRes;
import com.ombudsman.service.respondent.repository.dao.ICaseListDao;
import com.ombudsman.service.respondent.serviceimpl.helper.CaseServiceHelper;

@ExtendWith(SpringExtension.class)
class GetCasesByRespondentServiceImplTest {	
	private static final String TOTAL_CASES = "totalcases";
	private static final String PERIORITY_CASES = "prioritycases";
	private static final String BUSINESS_FILE = "businessfileoverdue";
	private static final String AWITING_ACTIONS = "1234";
	private static final String TOTAL_CASES_COUNT = "4678";
	private static final String PERIORITY_CASES_COUNT = "1234";
	private static final String BUSINESS_FILE_COUNT = "567";
	private static final String AWITING_ACTIONS_COUNT = "45";


	@InjectMocks
	private CasesByRespondentServiceImpl getCasesByRespondentService;

	@Mock
	private UserBean userBean;

	@Mock
	private ICaseListDao mMockCaseFilterDao;
	@Mock
	CaseServiceHelper mMockCaseServiceHelper;

	@Mock
	private Filters mMockFilters;

	@Mock
	private CaseFilterData mMockCaseFilterDataIsOpenCases;
	@Mock
	private CaseFilterData mMockCaseFilterDatacaseage;
	Map<String, Object> caseList3 = new HashMap<>();

	@Mock
	private GetCasesByRespondentReq mMockGetCasesByRespondentReq;

	/*
	 * @Mock private CaseListMapper mapper;
	 */

	@Mock
	private Case mMockCase;
	private static List<String> groupIds = new ArrayList<>();

	@BeforeEach
	void setUp() {
		groupIds.add("groupId1");
		groupIds.add("groupId2");
		when(userBean.getGroups()).thenReturn(groupIds);

	}

	@Test
	@DisplayName("shouldGetCasesByRespondenSuccessfully")
	void shouldGetCasesByRespondenSuccessfully()
			throws JSONException, IOException, SQLDataAccessException, CaseListNotFoundException {
		final Map<String, Object> caseList1 = new HashMap<>();
		final Map<String, String> caseItems = new HashMap<>();
		caseItems.put("totalCount", "123");
		CaseListDto dto = new CaseListDto();
		dto.setAwaitingaction("123");
		caseList1.put("#result-set-1", Lists.newArrayList(caseItems));
		caseList1.put("#result-set-2", Lists.newArrayList(dto));
		Map<String, Object> caseList2 = new HashMap<>();
		caseList2.put("caseowner", "#");

		//when(mapper.caseListDto(dto)).thenReturn(mMockCase);
		when(mMockCaseServiceHelper.getRequestData(mMockGetCasesByRespondentReq)).thenReturn(caseList2);
		when(mMockCaseFilterDao.getCasesByRespondent(caseList2, "oid"))
				.thenReturn(caseList1);

		// Act
		//CasesManagementRes result = getCasesByRespondentService.getCaseListForOrganization(mMockGetCasesByRespondentReq);
		// Assert
		/*
		 * assertNotNull(result); assertEquals(1, result.getCases().size());
		 * assertEquals("123", result.getCases().get(0).getAwaitingAction());
		 * assertNotNull(result.getCases().get(0)); // verify
		 * verify(mMockCaseFilterDao).getCasesByRespondent(Mockito.anyMap(),
		 * Mockito.any()); verify(userBean).getGroups();
		 * verify(mMockCaseServiceHelper).getRequestData(mMockGetCasesByRespondentReq);
		 */
	}
	@Test
	@DisplayName("shouldGetCasesByRespondenSuccessfully")
	void shouldPopulateAllCaseListDataSuccessfully()
			throws JSONException, IOException, SQLDataAccessException, CaseListNotFoundException {
		final Map<String, Object> caseList1 = new HashMap<>();
		final Map<String, String> caseItems = new HashMap<>();
		
		caseItems.put("totalCount", "123");
		CaseListDto dto = new CaseListDto();
		dto.setAwaitingaction("123");
		
		caseItems.put(TOTAL_CASES, TOTAL_CASES_COUNT);
		caseItems.put(PERIORITY_CASES, PERIORITY_CASES_COUNT);		
		caseItems.put(BUSINESS_FILE, BUSINESS_FILE_COUNT);
		caseItems.put(AWITING_ACTIONS, AWITING_ACTIONS_COUNT);
		caseList1.put("#result-set-1", Lists.newArrayList(caseItems));
		caseList1.put("#result-set-2", Lists.newArrayList(dto));

		Map<String, Object> caseList2 = new HashMap<>();
		caseList2.put("caseowner", "#");

	//	when(mapper.caseListDto(dto)).thenReturn(mMockCase);
		when(mMockCaseServiceHelper.getRequestData(mMockGetCasesByRespondentReq)).thenReturn(caseList2);
		when(mMockCaseFilterDao.getCasesByRespondent(caseList2, "oid"))
				.thenReturn(caseList1);

		// Act
		/*
		 * CasesManagementRes result =
		 * getCasesByRespondentService.getCaseListForOrganization(
		 * mMockGetCasesByRespondentReq); // Assert assertNotNull(result);
		 * assertEquals(1, result.getCases().size()); assertEquals(TOTAL_CASES_COUNT,
		 * result.getCounttotalcases()); assertEquals(PERIORITY_CASES_COUNT,
		 * result.getCountprioritycases()); assertEquals(BUSINESS_FILE_COUNT,
		 * result.getCountoverduecases()); assertEquals("123",
		 * result.getCases().get(0).getAwaitingAction());
		 * assertNotNull(result.getCases().get(0)); // verify
		 * verify(mMockCaseFilterDao).getCasesByRespondent(Mockito.anyMap(),
		 * Mockito.any()); verify(userBean).getGroups();
		 * verify(mMockCaseServiceHelper).getRequestData(mMockGetCasesByRespondentReq);
		 */
	}


	@Test
	@DisplayName("shouldReturnCaseListNotFoundException")
	void shouldThrowSQLDataAccessException()
			throws JSONException, CaseListNotFoundException, SQLDataAccessException, IOException {
		// Arrange
		GetCasesByRespondentReq request = new GetCasesByRespondentReq();
		Filters mMockfilter = new Filters();
		mMockfilter.setSearchBy("");
		request.setFilters(mMockfilter);
		CasesManagementRes result = null;
		List<String> listOfgroups = new ArrayList<String>();
		listOfgroups.add(null);		
		Map<String, Object> caseList = new HashMap<>();
		List<Object> caseListSummary = Arrays.asList("summary1", "summary2");
		List<Object> caseListDetail = Arrays.asList("detail1", "detail2");
		caseList.put("result-set-1", caseListSummary);
		caseList.put("result-set-2", caseListDetail);

		doThrow(new SQLDataAccessException(null)).when(mMockCaseFilterDao).getCasesByRespondent(caseList, "oid");
		request.setOpencasesonly("true");
		List<CaseFilterData> list = new ArrayList<>();
		list.add(new CaseFilterData("id", "value"));
		// Act
		try {
			result = getCasesByRespondentService.getCaseListForOrganization(request);
		} catch (final CaseListNotFoundException ex) {
			assertNull(result);
		}

		// Assert
		assertNull(result);
		
		// verify
		verify(mMockCaseFilterDao).getCasesByRespondent(Mockito.anyMap(), Mockito.any());
		verify(userBean).getGroups();
		
	}

	@DisplayName("shouldNotReturnAnyCaseDetailsFromRepository")
	@Test
	void shouldNotReturnAnyCaseDetailsFromRepository() throws JSONException, IOException, CaseListNotFoundException {
		// Arrange
		GetCasesByRespondentReq request = new GetCasesByRespondentReq();
		Filters mMockfilter = new Filters();
		mMockfilter.setSearchBy("");
		request.setFilters(mMockfilter);
		CasesManagementRes result = null;
		CaseListDto caseListDto = new CaseListDto();
		Map<String, Object> caseList = new HashMap<>();
		caseList.put("RESULT_SET_1", "");
		when(userBean.getGroups()).thenReturn(groupIds);
		when(mMockCaseServiceHelper.getRequestData(mMockGetCasesByRespondentReq)).thenReturn(Mockito.anyMap());
		when(mMockCaseFilterDao.getCasesByRespondent(Mockito.anyMap(), "oid"))
				.thenReturn(caseList);
	//	when(mapper.caseListDto(caseListDto)).thenReturn(mMockCase);

		try {
			result = getCasesByRespondentService.getCaseListForOrganization(request);
		} catch (final CaseListNotFoundException ex) {
			assertNull(result);
		}
		// Assert
		assertFalse(caseList.isEmpty());

		// verify
		verify(mMockCaseFilterDao).getCasesByRespondent(Mockito.anyMap(), Mockito.any());
		verify(userBean).getGroups();
	}

}
