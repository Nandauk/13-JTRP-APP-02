package com.ombudsman.service.respondent.model;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertSame;

import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.Test;

class AttributesTest {

    @Test
    void testGettersAndSetters() {
        Attributes attrs = new Attributes();

        attrs.setOpencasesonly("true");
        assertEquals("true", attrs.getOpencasesonly());

        List<String> orgs = Arrays.asList("Org1", "Org2");
        attrs.setOrganisations(orgs);
        assertSame(orgs, attrs.getOrganisations());

        Filters filterObj = new Filters();
        attrs.setFilters(filterObj);
        assertSame(filterObj, attrs.getFilters());

        UserData userData = new UserData();
        attrs.setUsers(userData);
        assertSame(userData, attrs.getUsers());
    }
}
