package com.ombudsman.service.respondent.model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

class CaseFilterTest {

    @Test
    void testGettersAndSetters() {
        CaseFilter caseFilter = new CaseFilter();

        caseFilter.setCasereference("TICK-123");
        assertEquals("TICK-123", caseFilter.getCasereference());

        caseFilter.setMigratedreference("CRN-999");
        assertEquals("CRN-999", caseFilter.getMigratedreference());

        caseFilter.setBusinessname("BusinessName");
        assertEquals("BusinessName", caseFilter.getBusinessname());

        caseFilter.setBusinessreference("BR-REF");
        assertEquals("BR-REF", caseFilter.getBusinessreference());

        caseFilter.setComplaintissue("Complaint Issue");
        assertEquals("Complaint Issue", caseFilter.getComplaintissue());

        caseFilter.setProducttype("Product Type");
        assertEquals("Product Type", caseFilter.getProducttype());

        caseFilter.setCasestage("Stage 1");
        assertEquals("Stage 1", caseFilter.getCasestage());

        caseFilter.setOpenstockstatus("Open Stock Status");
        assertEquals("Open Stock Status", caseFilter.getOpenstockstatus());

        caseFilter.setEnquirydate("2023-10-01");
        assertEquals("2023-10-01", caseFilter.getEnquirydate());

        caseFilter.setProfessionalrep("Pro Rep");
        assertEquals("Pro Rep", caseFilter.getProfessionalrep());

        caseFilter.setConversiondate("2023-10-02");
        assertEquals("2023-10-02", caseFilter.getConversiondate());

        caseFilter.setDefaultBusinessfile("BusinessFile-default");
        assertEquals("BusinessFile-default", caseFilter.getDefaultBusinessfile());

        caseFilter.setLastviewdate("2023-10-03");
        assertEquals("2023-10-03", caseFilter.getLastviewdate());

        caseFilter.setLastviewoutcome("Approved");
        assertEquals("Approved", caseFilter.getLastviewoutcome());

        caseFilter.setFoscaseowner("FOS-Case-Owner");
        assertEquals("FOS-Case-Owner", caseFilter.getFoscaseowner());

        caseFilter.setRespondentcaseowner("Respondent-Owner");
        assertEquals("Respondent-Owner", caseFilter.getRespondentcaseowner());

        caseFilter.setCaseagebanding("6-12 months");
        assertEquals("6-12 months", caseFilter.getCaseagebanding());

        caseFilter.setNoofefile("2");
        assertEquals("2", caseFilter.getNoofefile());

        caseFilter.setNoofcorrespondet("5");
        assertEquals("5", caseFilter.getNoofcorrespondet());

        caseFilter.setEventdate("2023-10-05");
        assertEquals("2023-10-05", caseFilter.getEventdate());

        caseFilter.setVulnerable("Yes");
        assertEquals("Yes", caseFilter.getVulnerable());

        caseFilter.setFinalresponsedate("2023-10-06");
        assertEquals("2023-10-06", caseFilter.getFinalresponsedate());

        caseFilter.setClosuredate("2023-10-07");
        assertEquals("2023-10-07", caseFilter.getClosuredate());

        caseFilter.setClosureoutcome("Closed");
        assertEquals("Closed", caseFilter.getClosureoutcome());

        caseFilter.setDeadlockcases("Deadlock info");
        assertEquals("Deadlock info", caseFilter.getDeadlockcases());
    }
}
