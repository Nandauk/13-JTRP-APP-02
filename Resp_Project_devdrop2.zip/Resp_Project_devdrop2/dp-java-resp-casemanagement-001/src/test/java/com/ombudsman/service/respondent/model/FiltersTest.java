package com.ombudsman.service.respondent.model;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertSame;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;

class FiltersTest {

    @Test
    void testGettersAndSetters() {
        Filters filters = new Filters();

        // Prepare some dummy CaseFilterData lists
        List<CaseFilterData> list1 = new ArrayList<>();
        List<CaseFilterData> list2 = new ArrayList<>();

        filters.setBusinessname(list1);
        assertSame(list1, filters.getBusinessname());

        filters.setComplaintissue(list2);
        assertSame(list2, filters.getComplaintissue());

        filters.setAwaitingactionbusiness(list1);
        assertSame(list1, filters.getAwaitingactionbusiness());

        filters.setProducttype(list2);
        assertSame(list2, filters.getProducttype());

        filters.setCasestage(list1);
        assertSame(list1, filters.getCasestage());

        filters.setTradingname(list2);
        assertSame(list2, filters.getTradingname());

        filters.setCaseowner(list1);
        assertSame(list1, filters.getCaseowner());

        filters.setCaseage(list2);
        assertSame(list2, filters.getCaseage());

        filters.setCloseroutcome(list1);
        assertSame(list1, filters.getCloseroutcome());

        filters.setPrioritycases(list2);
        assertSame(list2, filters.getPrioritycases());

        filters.setOldcasestatus(list1);
        assertSame(list1, filters.getOldcasestatus());

        filters.setAwaitingactionfilter(list2);
        assertSame(list2, filters.getAwaitingactionfilter());

        filters.setAgecaseflag(list1);
        assertSame(list1, filters.getAgecaseflag());

        filters.setCaseprogress(list2);
        assertSame(list2, filters.getCaseprogress());

        filters.setEmailid(list1);
        assertSame(list1, filters.getEmailid());

        filters.setOutcome7days(list1);
        assertEquals(list1, filters.getOutcome7days());

        filters.setBfileoverdue(list1);
        assertEquals(list1, filters.getBfileoverdue());

        filters.setStartdate("2023-10-01");
        assertEquals("2023-10-01", filters.getStartdate());

        filters.setEnddate("2023-10-31");
        assertEquals("2023-10-31", filters.getEnddate());

        filters.setPage(1);
        assertEquals(1, filters.getPage());

        filters.setPagesize(50);
        assertEquals(50, filters.getPagesize());

        filters.setSortby("sortField");
        assertEquals("sortField", filters.getSortby());

        filters.setSorttype("DESC");
        assertEquals("DESC", filters.getSorttype());

        filters.setSearchBy("SearchString");
        assertEquals("SearchString", filters.getSearchBy());
    }
}
