package com.ombudsman.service.respondent.serviceimpl;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List; 
import java.util.Map;

import javax.security.auth.login.AccountNotFoundException;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;

import com.ombudsman.service.respondent.common.UserBean;
import com.ombudsman.service.respondent.exception.InvalidOrganisationException;
import com.ombudsman.service.respondent.exception.MandatoryFieldMissingException;
import com.ombudsman.service.respondent.exception.OrganisationIdMissingException;
import com.ombudsman.service.respondent.exception.SQLDataAccessException;
import com.ombudsman.service.respondent.exception.SQLServerException;
import com.ombudsman.service.respondent.exception.UnAuthorisedException;
import com.ombudsman.service.respondent.model.dto.CaseWorkerDto;
import com.ombudsman.service.respondent.model.request.CaseworkerReq;
import com.ombudsman.service.respondent.model.response.CaseworkerListByIdRes;
import com.ombudsman.service.respondent.service.repository.CaseListJdbcRepository;

@ExtendWith(MockitoExtension.class)
public class CaseworkerListbyIdServiceImplTest {

    @InjectMocks
    private CaseworkerListByIdServiceImpl caseworkerListbyIdServiceImpl;

    @Mock
    private CaseListJdbcRepository caseListJdbcRepository;

    @Mock
    private UserBean userbean;

    @Mock
    private CaseworkerReq mMockCaseworkerReq;

    // We set up common stubs in @BeforeEach to handle the happy path,
    // and override them in the failure tests if needed.
    @BeforeEach
    void setUp() {
        // Mock userBean
        // The user performing the assignment
        when(userbean.getCorrelationId()).thenReturn("test-corr-id");
        when(userbean.getUserObjectId()).thenReturn("1852697B-D1AD-41EC-A326-D633B64C0294");

        // Mock request
        when(mMockCaseworkerReq.getAccountid()).thenReturn("FC412CFE-8089-4832-ABC4-6854948ED423");

        // By default, we simulate a valid scenario in which:
        // 1) The stored procedure returns a matching account ID
        // 2) We have role IDs for "supervisor" and "caseworker"
        // 3) We have a groupId for the account
        Map<String, Object> spResult = buildSpResult(
            "FC412CFE-8089-4832-ABC4-6854948ED423", 
            "app-dp-role-supervisor-dev"
        );
        lenient().when(caseListJdbcRepository.getAccountIdsAndRolesByOid("1852697B-D1AD-41EC-A326-D633B64C0294"))
            .thenReturn(spResult);

        lenient().when(caseListJdbcRepository.getRoleId("caseworker")).thenReturn(29);
        lenient().when(caseListJdbcRepository.getRoleId("supervisor")).thenReturn(40);
        lenient().when(caseListJdbcRepository.getGroupId("FC412CFE-8089-4832-ABC4-6854948ED423"))
            .thenReturn( Arrays.asList(261));
    }

    /**
     * Helper method to build a fake SP result for getAccountIdsAndRolesByOid(..)
     */
    private Map<String, Object> buildSpResult(String accountId, String adGroupName) {
        Map<String, Object> spResult = new HashMap<>();
        List<Map<String, Object>> resultSet = new ArrayList<>();

        Map<String, Object> row = new HashMap<>();
        row.put("accountid", accountId);
        row.put("ad_group_name", adGroupName);
        resultSet.add(row);

        spResult.put("#result-set-1", resultSet);
        return spResult;
    }

    @DisplayName("getCaseworkersTest - Successful Retrieval for Large User Base")
    @Test
    public void getCaseworkersTest_Success_LargeUserBase() throws Exception {
      
        List<CaseWorkerDto> expectedCaseworkers = Arrays.asList(
            CaseWorkerDto.create("Nanda UKProfile", "nandaukprofile@gmail.com", "4C4AF41C-F4C3-4C98-9B36-65F71650C7B0"),
            CaseWorkerDto.create("Moha dutta",       "mohanta.devadutta@gmail.com",  "3703AD10-776D-4634-ABE9-70ABF174B939"),
            CaseWorkerDto.create("Sawan Verma",      "sawan17verma@outlook.com",     "C4311B54-8CB5-47BF-AE8C-7851CF7F5056"),
            CaseWorkerDto.create("Parbati Debnath",  "parbati2019debnath@outlook.com","739A6FBE-F1AE-4109-A8F4-90308F28E144"),
            CaseWorkerDto.create("abhiraj bhoir",    "abhirajbhoir21@outlook.com",    "29F1BC30-A82E-4E2A-8092-91F70E427118"),
            CaseWorkerDto.create("test DP",          "testdpdev4@outlook.com",       "9EB51BE3-2580-40F7-9166-A6C030FCF58E"),
            CaseWorkerDto.create("Pranav Singh",     "pranavsingh3152@gmail.com",     "1852697B-D1AD-41EC-A326-D633B64C0294"),
            CaseWorkerDto.create("deepali m",        "dmaheshwari@fos.org.uk",        "D309BF2A-A126-4300-A395-E1C9D0ED7DAE"),
            CaseWorkerDto.create("Dilip Biswal",     "dilip.kumar.biswal@outlook.com","DCF65940-BBD1-4187-87BD-EBA560F30760"),
            CaseWorkerDto.create("Test Divya",       "testdpdev2@outlook.com",        "4E4791B2-A0B3-4EF0-A931-EE02EB4248B1"),
            CaseWorkerDto.create("Test DP",          "test2caseworker@outlook.com",   "7C6EE6C5-B59B-49EA-8DBD-FB1AE9678F8C")
        );

        when(caseListJdbcRepository.getCaseworkersByRoleIdsAndGroup(Arrays.asList(0, 0), Arrays.asList(261), "1852697B-D1AD-41EC-A326-D633B64C0294"))
            .thenReturn(expectedCaseworkers);

        // Call the real service
        CaseworkerListByIdRes response = caseworkerListbyIdServiceImpl.getCaseworkers(mMockCaseworkerReq);

        // Assertions
        assertNotNull(response, "Response should not be null");
        assertThat(response.getCaseworkerList()).hasSize(11);

        // Build expected final output list
        List<CaseworkerListByIdRes.Caseworker> expectedCaseworkers1 = Arrays.asList(
            new CaseworkerListByIdRes.Caseworker("Nanda UKProfile", "nandaukprofile@gmail.com",   "4C4AF41C-F4C3-4C98-9B36-65F71650C7B0"),
            new CaseworkerListByIdRes.Caseworker("Moha dutta",      "mohanta.devadutta@gmail.com","3703AD10-776D-4634-ABE9-70ABF174B939"),
            new CaseworkerListByIdRes.Caseworker("Sawan Verma",     "sawan17verma@outlook.com",   "C4311B54-8CB5-47BF-AE8C-7851CF7F5056"),
            new CaseworkerListByIdRes.Caseworker("Parbati Debnath", "parbati2019debnath@outlook.com","739A6FBE-F1AE-4109-A8F4-90308F28E144"),
            new CaseworkerListByIdRes.Caseworker("abhiraj bhoir",   "abhirajbhoir21@outlook.com",  "29F1BC30-A82E-4E2A-8092-91F70E427118"),
            new CaseworkerListByIdRes.Caseworker("test DP",         "testdpdev4@outlook.com",      "9EB51BE3-2580-40F7-9166-A6C030FCF58E"),
           new CaseworkerListByIdRes.Caseworker("Pranav Singh",    "pranavsingh3152@gmail.com",   "1852697B-D1AD-41EC-A326-D633B64C0294"),
            new CaseworkerListByIdRes.Caseworker("deepali m",       "dmaheshwari@fos.org.uk",      "D309BF2A-A126-4300-A395-E1C9D0ED7DAE"),
            new CaseworkerListByIdRes.Caseworker("Dilip Biswal",    "dilip.kumar.biswal@outlook.com","DCF65940-BBD1-4187-87BD-EBA560F30760"),
            new CaseworkerListByIdRes.Caseworker("Test Divya",      "testdpdev2@outlook.com",      "4E4791B2-A0B3-4EF0-A931-EE02EB4248B1"),
            new CaseworkerListByIdRes.Caseworker("Test DP",         "test2caseworker@outlook.com", "7C6EE6C5-B59B-49EA-8DBD-FB1AE9678F8C")
        );

        // Compare each item
        for (int i = 0; i < expectedCaseworkers1.size(); i++) {
            CaseworkerListByIdRes.Caseworker expected = expectedCaseworkers1.get(i);
            CaseworkerListByIdRes.Caseworker actual   = response.getCaseworkerList().get(i);

            assertThat(actual.getName()).isEqualTo(expected.getName());
            assertThat(actual.getEmail()).isEqualTo(expected.getEmail());
            assertThat(actual.getOId()).isEqualTo(expected.getOId());
        }
    }

    // ------------------------------------------------------------------
    // Failure Test #1: Missing/Empty Account ID -> OrganisationIdMissingException
    // ------------------------------------------------------------------
    @DisplayName("getCaseworkersTest - Missing Account ID")
    @Test
    public void getCaseworkersTest_MissingAccountId() throws Exception {
        when(mMockCaseworkerReq.getAccountid()).thenReturn(""); // or null

        OrganisationIdMissingException ex = assertThrows(
            OrganisationIdMissingException.class,
            () -> caseworkerListbyIdServiceImpl.getCaseworkers(mMockCaseworkerReq)
        );
        String msg = ex.getMessage();
        assertThat(ex.getMessage()).isEqualTo("Organisation Id is missing");
    }

    // ------------------------------------------------------------------
    // Failure Test #2: Missing/Empty User OID -> MandatoryFieldMissingException
    // ------------------------------------------------------------------
    @DisplayName("getCaseworkersTest - Missing User OID")
    @Test
    public void getCaseworkersTest_MissingUserOid() throws Exception {
        when(userbean.getUserObjectId()).thenReturn("");

        MandatoryFieldMissingException ex = assertThrows(
            MandatoryFieldMissingException.class,
            () -> caseworkerListbyIdServiceImpl.getCaseworkers(mMockCaseworkerReq)
        );
        assertThat(ex.getMessage()).isEqualTo("MISSING_FIELD");
    }

    // ------------------------------------------------------------------
    // Failure Test #3: User Not Authorized for That Account -> InvalidOrganisationException
    // ------------------------------------------------------------------
    @DisplayName("getCaseworkersTest - Unauthorised Account")
    @Test
    public void getCaseworkersTest_UnauthorisedAccount() throws Exception {
        // We can keep the same userOID, but we stub the SP to return a DIFFERENT account
        Map<String, Object> spResult = buildSpResult("SOME-OTHER-ACCOUNT", "app-dp-role-supervisor-dev");
        when(caseListJdbcRepository.getAccountIdsAndRolesByOid("1852697B-D1AD-41EC-A326-D633B64C0294"))
            .thenReturn(spResult);

        InvalidOrganisationException ex = assertThrows(
            InvalidOrganisationException.class,
            () -> caseworkerListbyIdServiceImpl.getCaseworkers(mMockCaseworkerReq)
        );
        // the code in validateAndAuthorize throws new InvalidOrganisationException(USER_UNAUTHORIZED)
        assertThat(ex.getMessage()).isNull(); 
        // or "USER_UNAUTHORIZED", depending on how your code sets it
    }

    // ------------------------------------------------------------------
    // Failure Test #4: Role Not Found -> SQLDataAccessException
    // ------------------------------------------------------------------
    @DisplayName("getCaseworkersTest - Role Not Found")
    @Test
    public void getCaseworkersTest_RoleNotFound() throws Exception {
        // Suppose we can't find "supervisor"
        lenient().when(caseListJdbcRepository.getRoleId("Supervisor"))
            .thenThrow(new MandatoryFieldMissingException("USER_UNAUTHORIZED"));

        // caseworker role is fine
        lenient().when(caseListJdbcRepository.getRoleId("CaseWorker")).thenReturn(29);

        MandatoryFieldMissingException ex = assertThrows(
            MandatoryFieldMissingException.class,
            () -> caseworkerListbyIdServiceImpl.getCaseworkers(mMockCaseworkerReq)
        );
        assertThat(ex.getMessage()).isEqualTo("USER_UNAUTHORIZED");
    }

    // ------------------------------------------------------------------
    // Failure Test #5: Database Error -> e.g. SQLServerException
    // ------------------------------------------------------------------
    @DisplayName("getCaseworkersTest - Database Error on groupId")
    @Test
    public void getCaseworkersTest_DatabaseError() throws Exception {
        // role IDs are fine
        when(caseListJdbcRepository.getRoleId("Supervisor")).thenReturn(40);
        when(caseListJdbcRepository.getRoleId("CaseWorker")).thenReturn(29);

        // But groupId fails
        when(caseListJdbcRepository.getGroupId("FC412CFE-8089-4832-ABC4-6854948ED423"))
            .thenThrow(new SQLServerException("Record creation failed"));

        SQLServerException ex = assertThrows(
            SQLServerException.class,
            () -> caseworkerListbyIdServiceImpl.getCaseworkers(mMockCaseworkerReq)
        );
        assertThat(ex.getMessage()).isEqualTo("Record creation failed");
    }
    

}
