package com.ombudsman.service.respondent.repository;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;

import com.ombudsman.service.respondent.exception.SQLDataAccessException;
import com.ombudsman.service.respondent.model.dto.CaseByCaseReferenceDto;
import com.ombudsman.service.respondent.model.dto.CaseDetailDto;
import com.ombudsman.service.respondent.model.dto.CaseOutcomeDto;
import com.ombudsman.service.respondent.model.dto.CaseWorkerDto;
import com.ombudsman.service.respondent.model.dto.OrganizationDto;
import com.ombudsman.service.respondent.service.repository.CaseDetailsJdbcRepository;

@ExtendWith(MockitoExtension.class)
class CaseDetailsJdbcRepositoryTest {

    @Mock
    private JdbcTemplate jdbcTemplate;

    @Mock
    private NamedParameterJdbcTemplate namedJdbcTemplate;

    @InjectMocks
    private CaseDetailsJdbcRepository caseDetailsJdbcRepository;

    @BeforeEach
    void setUp() {
    	MockitoAnnotations.openMocks(this);
    }
    @Test
    @DisplayName("setDataSource - ensures JdbcTemplate is set without errors")
    void testSetDataSource() {
        DataSource ds = org.mockito.Mockito.mock(DataSource.class);
        caseDetailsJdbcRepository.setDataSource(ds);
        // No direct assertion—just verifying no exception is thrown.
    }

    // --------------------------------------------------------------------------------
    // 1) getOrganisationListByParentOrgId(...)
    // --------------------------------------------------------------------------------
    @Test
    @DisplayName("getOrganisationListByParentOrgId - returns list of OrganizationDto")
    void testGetOrganisationListByParentOrgId() throws SQLDataAccessException {
        // Given
        List<String> accountIds = Arrays.asList("ACC1", "ACC2");

        // We must specify the row mapper type parameter to disambiguate:
        when(namedJdbcTemplate.query(
            anyString(),
            ArgumentMatchers.<SqlParameterSource>any(),
            ArgumentMatchers.<RowMapper<OrganizationDto>>any()
        ))
        .thenReturn(Arrays.asList(new OrganizationDto("orgName", "orgId")));

        // When
        List<OrganizationDto> result = caseDetailsJdbcRepository.getOrganisationListByParentOrgId(accountIds);

        // Then
        assertThat(result).hasSize(1);
        assertThat(result.get(0).getOrganizationName()).isEqualTo("orgName");
        assertThat(result.get(0).getOrganizationId()).isEqualTo("orgId");
    }

    // --------------------------------------------------------------------------------
    // 2) getCaseDetailsById(...)
    // --------------------------------------------------------------------------------
    @Test
    @DisplayName("getCaseDetailsById - returns list of CaseDetailDto")
    void testGetCaseDetailsById() throws SQLDataAccessException {
        // Given
        Map<String, Object> reqParam = new HashMap<>();
        reqParam.put("incident", "INC123");
        reqParam.put("acctId", Arrays.asList("ACC1", "ACC2"));

        CaseDetailDto sampleDto = new CaseDetailDto();
        sampleDto.setIncidentid("INC123");
        sampleDto.setTicketnumber("TICKET-999");

        when(namedJdbcTemplate.query(
            anyString(),
            ArgumentMatchers.<SqlParameterSource>any(),
            ArgumentMatchers.<RowMapper<CaseDetailDto>>any()
        ))
        .thenReturn(Arrays.asList(sampleDto));

        // When
        List<CaseDetailDto> details = caseDetailsJdbcRepository.getCaseDetailsById(reqParam);

        // Then
        assertThat(details).hasSize(1);
        CaseDetailDto dto = details.get(0);
        assertThat(dto.getIncidentid()).isEqualTo("INC123");
        assertThat(dto.getTicketnumber()).isEqualTo("TICKET-999");
    }

    // --------------------------------------------------------------------------------
    // 3) getCaseOutcomeById(...)
    // --------------------------------------------------------------------------------
    @Test
    @DisplayName("getCaseOutcomeById - returns list of CaseOutcomeDto")
    void testGetCaseOutcomeById() throws SQLDataAccessException {
        // Given
        Map<String, Object> reqParam = new HashMap<>();
        reqParam.put("incident", "INC-ABC");
        reqParam.put("acctId", Collections.singletonList("ACC1"));

        CaseOutcomeDto sampleOutcome = new CaseOutcomeDto();
        sampleOutcome.setFos_case("CASE-XYZ");
        sampleOutcome.setFos_offeroroutcomeid("OFFER-123");

        when(namedJdbcTemplate.query(
            anyString(),
            ArgumentMatchers.<SqlParameterSource>any(),
            ArgumentMatchers.<RowMapper<CaseOutcomeDto>>any()
        ))
        .thenReturn(Arrays.asList(sampleOutcome));

        // When
        List<CaseOutcomeDto> outcomes = caseDetailsJdbcRepository.getCaseOutcomeById(reqParam);

        // Then
        assertThat(outcomes).hasSize(1);
        CaseOutcomeDto co = outcomes.get(0);
        assertThat(co.getFos_case()).isEqualTo("CASE-XYZ");
        assertThat(co.getFos_offeroroutcomeid()).isEqualTo("OFFER-123");
    }

    // --------------------------------------------------------------------------------
    // 4) getCaseWorkerDetailsById(...)
    // --------------------------------------------------------------------------------
    @Test
    @DisplayName("getCaseWorkerDetailsById - returns list of CaseWorkerDto")
    void testGetCaseWorkerDetailsById() throws SQLDataAccessException {
        // Given
        Map<String, Object> reqParam = new HashMap<>();
        reqParam.put("incident", "INC-555");
        reqParam.put("acctId", Arrays.asList("ACC-X"));

        CaseWorkerDto sampleWorker = new CaseWorkerDto();
        sampleWorker.set_owninguser_value("OWNUSER-XYZ");
        sampleWorker.setFullname("Owner Name");
        sampleWorker.setCwFullname("CW Name");
        sampleWorker.setTicketnumber("TICK-555");

        when(namedJdbcTemplate.query(
            anyString(),
            ArgumentMatchers.<SqlParameterSource>any(),
            ArgumentMatchers.<RowMapper<CaseWorkerDto>>any()
        ))
        .thenReturn(Arrays.asList(sampleWorker));

        // When
        List<CaseWorkerDto> workers = caseDetailsJdbcRepository.getCaseWorkerDetailsById(reqParam);

        // Then
        assertThat(workers).hasSize(1);
        CaseWorkerDto w = workers.get(0);
        assertThat(w.get_owninguser_value()).isEqualTo("OWNUSER-XYZ");
        assertThat(w.getFullname()).isEqualTo("Owner Name");
        assertThat(w.getCwFullname()).isEqualTo("CW Name");
        assertThat(w.getTicketnumber()).isEqualTo("TICK-555");
    }

    // --------------------------------------------------------------------------------
    // 5) getCaseIncidentidByCaseReference(...)
    // --------------------------------------------------------------------------------
    @Test
    @DisplayName("getCaseIncidentidByCaseReference - returns list of CaseByCaseReferenceDto")
    void testGetCaseIncidentidByCaseReference() throws SQLDataAccessException {
        // Given
        Map<String, Object> reqParam = new HashMap<>();
        reqParam.put("ticket", "TICK-999");
        reqParam.put("acctId", Arrays.asList("ACC-1"));

        CaseByCaseReferenceDto sampleRef = new CaseByCaseReferenceDto("INCIDENT-999");

        when(namedJdbcTemplate.query(
            anyString(),
            ArgumentMatchers.<SqlParameterSource>any(),
            ArgumentMatchers.<RowMapper<CaseByCaseReferenceDto>>any()
        ))
        .thenReturn(Arrays.asList(sampleRef));

        // When
        List<CaseByCaseReferenceDto> list = caseDetailsJdbcRepository.getCaseIncidentidByCaseReference(reqParam);

        // Then
        assertThat(list).hasSize(1);
        assertThat(list.get(0).getIncidentId()).isEqualTo("INCIDENT-999");
    }

   
    @SuppressWarnings("unchecked")
	@Test
    void getCaseDetailsById_ShouldReturnCaseDetails() throws SQLException, SQLDataAccessException {
        
        Map<String, Object> reqParam = new HashMap<>();
        reqParam.put("incident", "123");
        reqParam.put("acctId", Arrays.asList("acc1", "acc2"));

        ResultSet mockResultSet = mockResultSetForCaseDetails();
        when(namedJdbcTemplate.query(
                anyString(), 
                any(SqlParameterSource.class), 
                any(org.springframework.jdbc.core.RowMapper.class)))
            .thenAnswer(invocation -> {
                org.springframework.jdbc.core.RowMapper<CaseDetailDto> rowMapper = 
                    invocation.getArgument(2);
                return Arrays.asList(rowMapper.mapRow(mockResultSet, 1));
            });


        
        List<CaseDetailDto> result = caseDetailsJdbcRepository.getCaseDetailsById(reqParam);

      
        assertNotNull(result);
        assertEquals(1, result.size());
        CaseDetailDto dto = result.get(0);
        
       
        assertEquals("123", dto.getIncidentid());
        assertEquals("Test Case", dto.getTicketnumber());
        assertEquals("CRN123", dto.getFos_crn());
        assertEquals("Customer Name", dto.get_customerid_value());
        assertEquals("REF123", dto.getFos_reference());
        assertEquals("EXTREF123", dto.getFos_extendedreference());
        assertEquals("ISSUE123", dto.get_fos_complaintissue_value());
        assertEquals("Complaint Issue", dto.get_fos_complaintissue_value_txt());
        assertEquals("PROD123", dto.get_fos_productorproductfamily_value());
        assertEquals("Product Family", dto.get_fos_productorproductfamily_value_txt());
        assertEquals("140000002", dto.getFos_casestage());
        assertEquals("Investigation", dto.getFos_casestage_txt());
        assertEquals("1", dto.getStatuscode());
        assertEquals("Active", dto.getStatuscode_txt());
        assertEquals("10/15/2023 11:04:01 PM", dto.getFos_dateofreferral());
        assertEquals("30", dto.getAgecaseflag());
        assertEquals("Rep Name", dto.getFos_representatives());
        assertEquals("10/15/2023 11:04:01 PM", dto.getFos_datecasefirstmovedtoinvestigation());
        assertEquals("10/15/2023 11:04:01 PM", dto.getFos_dateofconversion());
        assertEquals("2023-10-15 23:04:01.1234567", dto.getFos_datebusinessfilereceived());
        assertEquals("Older Status", dto.getFos_oldercasestatus());
        assertEquals("CW123", dto.get_fos_caseworker_value());
        assertEquals("IND123", dto.getFos_individualid());
        assertEquals("10/15/2023 11:04:01 PM", dto.getFos_dateofevent());
        assertEquals("10/15/2023 11:04:01 PM", dto.getFos_dateoffinalresponse());
        assertEquals("Change", dto.getFos_changeinoutcome());
        assertEquals("Trading Name", dto.getFos_tradingname());
        assertEquals("PRIORITY1", dto.getFos_prioritycode());
        assertEquals("High Priority", dto.getFos_prioritycode_txt());
        assertEquals("OWNER123", dto.get_owninguser_value());
        assertEquals("Case description", dto.getDescription());
        assertEquals("0", dto.getStatecode());
        assertEquals("PROGRESS1", dto.getFos_caseprogress());
        assertEquals("In Progress", dto.getFos_caseprogress_name());
    }

    
    

    private ResultSet mockResultSetForCaseDetails() throws SQLException {
        ResultSet rs = mock(ResultSet.class);
        
       
        when(rs.getString("incidentid")).thenReturn("123");
        when(rs.getString("title")).thenReturn("Test Case");
        when(rs.getString("fos_crn")).thenReturn("CRN123");
        when(rs.getString("customeridname")).thenReturn("Customer Name");
        when(rs.getString("fos_reference")).thenReturn("REF123");
        when(rs.getString("fos_extendedreference")).thenReturn("EXTREF123");
        when(rs.getString("fos_complaintissue")).thenReturn("ISSUE123");
        when(rs.getString("fos_complaintissuename")).thenReturn("Complaint Issue");
        when(rs.getString("fos_productorproductfamily")).thenReturn("PROD123");
        when(rs.getString("fos_productorproductfamilyname")).thenReturn("Product Family");
        when(rs.getString("fos_casestage")).thenReturn("140000002");
        when(rs.getString("fos_casestagename")).thenReturn("Investigation");
        when(rs.getString("statuscode")).thenReturn("1");
        when(rs.getString("statuscodename")).thenReturn("Active");
        when(rs.getString("dateOfReferral")).thenReturn("2023-10-15 23:04:01.1234567");
        when(rs.getString("caseage")).thenReturn("30");
        when(rs.getString("fos_representatives")).thenReturn("Rep Name");
        when(rs.getString("dateMovedToInvestigation")).thenReturn("2023-10-15 23:04:01.1234567");
        when(rs.getString("dateOfConversion")).thenReturn("2023-10-15 23:04:01.1234567");
        when(rs.getString("fos_datebusinessfilereceived")).thenReturn("2023-10-15 23:04:01.1234567");
        when(rs.getString("fos_oldercasestatus")).thenReturn("Older Status");
        when(rs.getString("fos_caseworker")).thenReturn("CW123");
        when(rs.getString("fos_individualid")).thenReturn("IND123");
        when(rs.getString("dateOfEvent")).thenReturn("2023-10-15 23:04:01.1234567");
        when(rs.getString("dateOfFinalResponse")).thenReturn("2023-10-15 23:04:01.1234567");
        when(rs.getString("fos_changeinoutcome")).thenReturn("Change");
        when(rs.getString("fos_tradingname")).thenReturn("Trading Name");
        when(rs.getString("fos_prioritycode")).thenReturn("PRIORITY1");
        when(rs.getString("fos_prioritycodename")).thenReturn("High Priority");
        when(rs.getString("owninguser")).thenReturn("OWNER123");
        when(rs.getString("description")).thenReturn("Case description");
        when(rs.getString("statecode")).thenReturn("0");
        when(rs.getString("fos_caseprogress")).thenReturn("PROGRESS1");
        when(rs.getString("fos_caseprogress_name")).thenReturn("In Progress");
        
        return rs;
    }
    @SuppressWarnings("unchecked")
	@Test
    void getCaseOutcomeById_ShouldReturnCaseOutcomes() throws SQLException, SQLDataAccessException {
        
        Map<String, Object> reqParam = new HashMap<>();
        reqParam.put("incident", "123");
        reqParam.put("acctId", Arrays.asList("acc1", "acc2"));

        ResultSet mockResultSet = mockResultSetForCaseOutcome();
        when(namedJdbcTemplate.query(
                anyString(), 
                any(SqlParameterSource.class), 
                any(org.springframework.jdbc.core.RowMapper.class)))
            .thenAnswer(invocation -> {
                org.springframework.jdbc.core.RowMapper<CaseOutcomeDto> rowMapper = 
                    invocation.getArgument(2);
                return Arrays.asList(rowMapper.mapRow(mockResultSet, 1));
            });


       
        List<CaseOutcomeDto> result = caseDetailsJdbcRepository.getCaseOutcomeById(reqParam);

       
        assertNotNull(result);
        assertEquals(1, result.size());
        CaseOutcomeDto dto = result.get(0);
        assertEquals("123", dto.getFos_case());
        assertEquals("OUT456", dto.getFos_offeroroutcomeid());
        assertEquals("Jurisdiction", dto.getFos_typename());
       
    }

    @SuppressWarnings("unchecked")
	@Test
    void getCaseWorkerDetailsById_ShouldReturnCaseWorkerDetails() throws SQLException, SQLDataAccessException {
        
        Map<String, Object> reqParam = new HashMap<>();
        reqParam.put("incident", "123");
        reqParam.put("acctId", Arrays.asList("acc1", "acc2"));

        ResultSet mockResultSet = mockResultSetForCaseWorker();
        when(namedJdbcTemplate.query(
                anyString(), 
                any(SqlParameterSource.class), 
                any(org.springframework.jdbc.core.RowMapper.class)))
            .thenAnswer(invocation -> {
                org.springframework.jdbc.core.RowMapper<CaseWorkerDto> rowMapper = 
                    invocation.getArgument(2);
                return Arrays.asList(rowMapper.mapRow(mockResultSet, 1));
            });


       
        List<CaseWorkerDto> result = caseDetailsJdbcRepository.getCaseWorkerDetailsById(reqParam);

        
        assertNotNull(result);
        assertEquals(1, result.size());
        CaseWorkerDto dto = result.get(0);
        assertEquals("CASE123", dto.getTicketnumber());
        assertEquals("John Doe", dto.getFullname());
        assertEquals("john.doe@example.com", dto.getInternalemailaddress());
       
    }

   
   

    private ResultSet mockResultSetForCaseOutcome() throws SQLException {
        ResultSet rs = mock(ResultSet.class);
        
        when(rs.getString("fos_case")).thenReturn("123");
        when(rs.getString("fos_offeroroutcomeid")).thenReturn("OUT456");
        when(rs.getString("fos_type")).thenReturn("1");
        when(rs.getString("fos_typename")).thenReturn("Jurisdiction");
        when(rs.getString("fos_meritsjurisdictiondismissal")).thenReturn("2");
        when(rs.getString("fos_meritsjurisdictiondismissalname")).thenReturn("Merits");
        when(rs.getString("fos_meritopinion")).thenReturn("3");
        when(rs.getString("fos_meritopinionname")).thenReturn("Opinion");
        when(rs.getString("fos_jurisdictioninout")).thenReturn("4");
        when(rs.getString("fos_jurisdictioninoutname")).thenReturn("In");
        when(rs.getString("fos_dismissalreason")).thenReturn("5");
        when(rs.getString("fos_withopinion")).thenReturn("Yes");
        when(rs.getString("fos_changeinoutcome")).thenReturn("6");
        when(rs.getString("fos_changeinoutcomename")).thenReturn("Changed");
        when(rs.getString("fos_settlementbandid")).thenReturn("7");
        when(rs.getString("fos_settlementbandidname")).thenReturn("Band A");
        when(rs.getString("fos_nonmonetarysettlement")).thenReturn("No");
        when(rs.getString("fos_troubleupsetamt")).thenReturn("100.00");
        when(rs.getString("fos_complainantresponse")).thenReturn("8");
        when(rs.getString("fos_complainantresponsename")).thenReturn("Accepted");
        when(rs.getString("fos_respondentresponse")).thenReturn("9");
        when(rs.getString("fos_outcomedispatcheddate")).thenReturn("07-01-2023");
        
        return rs;
    }

    private ResultSet mockResultSetForCaseWorker() throws SQLException {
        ResultSet rs = mock(ResultSet.class);
        
        when(rs.getString("TICKETNUMBER")).thenReturn("CASE123");
        when(rs.getString("OWNINGUSER")).thenReturn("OWNER123");
        when(rs.getString("OU_FULLNAME")).thenReturn("John Doe");
        when(rs.getString("OU_ADDRESS1")).thenReturn("1234567890");
        when(rs.getString("OU_INTERNALEMAIL")).thenReturn("john.doe@example.com");
        when(rs.getString("CW_FULLNAME")).thenReturn("Jane Smith");
        when(rs.getString("CW_ADDRESS1")).thenReturn("0987654321");
        when(rs.getString("CW_INTERNALEMAIL")).thenReturn("jane.smith@example.com");
        when(rs.getString("CW_TITLE")).thenReturn("Case Worker");
        
        return rs;
    }

}
