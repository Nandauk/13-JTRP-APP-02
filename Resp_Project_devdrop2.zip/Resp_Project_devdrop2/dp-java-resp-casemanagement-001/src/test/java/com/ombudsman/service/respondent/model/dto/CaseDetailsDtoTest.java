package com.ombudsman.service.respondent.model.dto;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import static org.junit.jupiter.api.Assertions.*;
@ExtendWith(SpringExtension.class)
public class CaseDetailsDtoTest {
	@InjectMocks
    private CaseDetailDto caseDetailDto;

    @BeforeEach
    public void setUp() {
        caseDetailDto = new CaseDetailDto();
    }

    @Test
    public void testGetterAndSetter() {
        // Set values
        caseDetailDto.setIncidentid("INC123");
        caseDetailDto.setTicketnumber("TICKET123");
        caseDetailDto.setFos_crn("FOS123");
        caseDetailDto.set_customerid_value("CUST123");
        caseDetailDto.setFos_tradingnamename("TradingName123");
        caseDetailDto.setBusinessname("BusinessName123");
        caseDetailDto.setFos_reference("FOSREF123");
        caseDetailDto.setFos_extendedreference("FOSXREF123");
        caseDetailDto.set_fos_complaintissue_value("COMP123");
        caseDetailDto.set_fos_complaintissue_value_txt("Complaint Issue");
        caseDetailDto.set_fos_productorproductfamily_value("PRODFAM123");
        caseDetailDto.set_fos_productorproductfamily_value_txt("Product Family");
        caseDetailDto.setFos_casestage("Stage123");
        caseDetailDto.setFos_casestage_txt("Investigation");
        caseDetailDto.setStatuscode("Status123");
        caseDetailDto.setStatuscode_txt("Awaiting Action");
        caseDetailDto.setFos_dateofreferral("2025-01-10");
        caseDetailDto.setAgecaseflag("yes");
        caseDetailDto.setFos_representatives("Rep123");
        caseDetailDto.setFos_datecasefirstmovedtoinvestigation("2025-01-01");
        caseDetailDto.setFos_dateofconversion("2025-01-05");
        caseDetailDto.setFos_datebusinessfilereceived("2025-01-07");
        caseDetailDto.setFos_dispatcheddate("2025-01-09");
        caseDetailDto.setFos_type("Type123");
        caseDetailDto.setFos_categorycode("Category123");
        caseDetailDto.setFos_oldercasestatus("Old123");
        caseDetailDto.set_fos_caseworker_value("Worker123");
        caseDetailDto.setFos_individualid("Indiv123");
        caseDetailDto.setCaseagebanding("Band123");
        caseDetailDto.setNoofefile("10");
        caseDetailDto.setNoofcorrespondet("5");
        caseDetailDto.setFos_dateofevent("2025-01-08");
        caseDetailDto.setVulnerable("No");
        caseDetailDto.setFos_dateoffinalresponse("2025-01-09");
        caseDetailDto.setFos_offeroutcome("Outcome123");
        caseDetailDto.setFos_changeinoutcome("Change123");
        caseDetailDto.setDeadlockcases("Deadlock123");
        caseDetailDto.setFos_tradingname("Trade123");
        caseDetailDto.setFos_prioritycode("Priority123");
        caseDetailDto.setFos_prioritycode_txt("High");
        caseDetailDto.set_owninguser_value("Owner123");
        caseDetailDto.setDescription("Description123");
        caseDetailDto.setBr_required("Required123");
        caseDetailDto.setStatecode("State123");
        caseDetailDto.setAwaitingAction("AwaitingAction123");
        caseDetailDto.setFos_caseprogress("Progress123");
        caseDetailDto.setFos_caseprogress_name("ProgressName123");
        
        // Assert values
        assertEquals("INC123", caseDetailDto.getIncidentid());
        assertEquals("TICKET123", caseDetailDto.getTicketnumber());
        assertEquals("FOS123", caseDetailDto.getFos_crn());
        assertEquals("CUST123", caseDetailDto.get_customerid_value());
        assertEquals("TradingName123", caseDetailDto.getFos_tradingnamename());
        assertEquals("BusinessName123", caseDetailDto.getBusinessname());
        assertEquals("FOSREF123", caseDetailDto.getFos_reference());
        assertEquals("FOSXREF123", caseDetailDto.getFos_extendedreference());
        assertEquals("COMP123", caseDetailDto.get_fos_complaintissue_value());
        assertEquals("Complaint Issue", caseDetailDto.get_fos_complaintissue_value_txt());
        assertEquals("PRODFAM123", caseDetailDto.get_fos_productorproductfamily_value());
        assertEquals("Product Family", caseDetailDto.get_fos_productorproductfamily_value_txt());
        assertEquals("Stage123", caseDetailDto.getFos_casestage());
        assertEquals("Investigation", caseDetailDto.getFos_casestage_txt());
        assertEquals("Status123", caseDetailDto.getStatuscode());
        assertEquals("Awaiting Action", caseDetailDto.getStatuscode_txt());
        assertEquals("2025-01-10", caseDetailDto.getFos_dateofreferral());
        assertEquals("yes", caseDetailDto.getAgecaseflag());
        assertEquals("Rep123", caseDetailDto.getFos_representatives());
        assertEquals("2025-01-01", caseDetailDto.getFos_datecasefirstmovedtoinvestigation());
        assertEquals("2025-01-05", caseDetailDto.getFos_dateofconversion());
        assertEquals("2025-01-07", caseDetailDto.getFos_datebusinessfilereceived());
        assertEquals("2025-01-09", caseDetailDto.getFos_dispatcheddate());
        assertEquals("Type123", caseDetailDto.getFos_type());
        assertEquals("Category123", caseDetailDto.getFos_categorycode());
        assertEquals("Old123", caseDetailDto.getFos_oldercasestatus());
        assertEquals("Worker123", caseDetailDto.get_fos_caseworker_value());
        assertEquals("Indiv123", caseDetailDto.getFos_individualid());
        assertEquals("Band123", caseDetailDto.getCaseagebanding());
        assertEquals("10", caseDetailDto.getNoofefile());
        assertEquals("5", caseDetailDto.getNoofcorrespondet());
        assertEquals("2025-01-08", caseDetailDto.getFos_dateofevent());
        assertEquals("No", caseDetailDto.getVulnerable());
        assertEquals("2025-01-09", caseDetailDto.getFos_dateoffinalresponse());
        assertEquals("Outcome123", caseDetailDto.getFos_offeroutcome());
        assertEquals("Change123", caseDetailDto.getFos_changeinoutcome());
        assertEquals("Deadlock123", caseDetailDto.getDeadlockcases());
        assertEquals("Trade123", caseDetailDto.getFos_tradingname());
        assertEquals("Priority123", caseDetailDto.getFos_prioritycode());
        assertEquals("High", caseDetailDto.getFos_prioritycode_txt());
        assertEquals("Owner123", caseDetailDto.get_owninguser_value());
        assertEquals("Description123", caseDetailDto.getDescription());
        assertEquals("Required123", caseDetailDto.getBr_required());
        assertEquals("State123", caseDetailDto.getStatecode());
        assertEquals("AwaitingAction123", caseDetailDto.getAwaitingAction());
        assertEquals("Progress123", caseDetailDto.getFos_caseprogress());
        assertEquals("ProgressName123", caseDetailDto.getFos_caseprogress_name());
    }
}
