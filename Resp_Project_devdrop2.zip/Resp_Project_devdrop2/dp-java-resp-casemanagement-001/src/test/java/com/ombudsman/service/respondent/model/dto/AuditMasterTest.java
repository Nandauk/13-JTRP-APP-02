package com.ombudsman.service.respondent.model.dto;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.time.OffsetDateTime;

import static org.junit.jupiter.api.Assertions.*;

public class AuditMasterTest {

    private AuditMaster auditMaster;

    @BeforeEach
    public void setUp() {
        auditMaster = new AuditMaster();
    }

    @Test
    public void testGetterAndSetter() {
        // Set values
        Integer auditRecordID = 1;
        String userOID = "USER123";
        OffsetDateTime auditEventTimestamp = OffsetDateTime.now();
        String auditEventName = "Event Name";
        String primaryAuditEntity = "Primary Entity";
        String primaryAuditEntityIdentifier = "Primary Identifier";
        String preAuditSnapshot = "Pre Snapshot";
        String postAuditSnapshot = "Post Snapshot";
        String createdBy = "Admin";
        OffsetDateTime modifiedOn = OffsetDateTime.now().plusDays(1);
        String modifiedBy = "User123";

        auditMaster.setAuditRecordID(auditRecordID);
        auditMaster.setUserOID(userOID);
        auditMaster.setAuditEventTimestamp(auditEventTimestamp);
        auditMaster.setAuditEventName(auditEventName);
        auditMaster.setPrimaryAuditEntity(primaryAuditEntity);
        auditMaster.setPrimaryAuditEntityIdentifier(primaryAuditEntityIdentifier);
        auditMaster.setPreAuditSnapshot(preAuditSnapshot);
        auditMaster.setPostAuditSnapshot(postAuditSnapshot);
        auditMaster.setCreatedBy(createdBy);
        auditMaster.setModifiedOn(modifiedOn);
        auditMaster.setModifiedBy(modifiedBy);

        // Assert values
        assertEquals(auditRecordID, auditMaster.getAuditRecordID());
        assertEquals(userOID, auditMaster.getUserOID());
        assertEquals(auditEventTimestamp, auditMaster.getAuditEventTimestamp());
        assertEquals(auditEventName, auditMaster.getAuditEventName());
        assertEquals(primaryAuditEntity, auditMaster.getPrimaryAuditEntity());
        assertEquals(primaryAuditEntityIdentifier, auditMaster.getPrimaryAuditEntityIdentifier());
        assertEquals(preAuditSnapshot, auditMaster.getPreAuditSnapshot());
        assertEquals(postAuditSnapshot, auditMaster.getPostAuditSnapshot());
        assertEquals(createdBy, auditMaster.getCreatedBy());
        assertEquals(modifiedOn, auditMaster.getModifiedOn());
        assertEquals(modifiedBy, auditMaster.getModifiedBy());
    }
}
