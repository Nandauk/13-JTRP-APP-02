package com.ombudsman.service.respondent.model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

class CaseWorkerTest {

    @Test
    void testGettersAndSetters() {
        CaseWorker caseWorker = new CaseWorker();

        caseWorker.setTicketnumber("TICK-123");
        assertEquals("TICK-123", caseWorker.getTicketnumber());

        caseWorker.set_fos_caseworker_value("FOS-WorkerVal");
        assertEquals("FOS-WorkerVal", caseWorker.get_fos_caseworker_value());

        caseWorker.set_owninguser_value("OWN-UserVal");
        assertEquals("OWN-UserVal", caseWorker.get_owninguser_value());

        caseWorker.setFullname("John Doe");
        assertEquals("John Doe", caseWorker.getFullname());

        caseWorker.setTitle("Mr.");
        assertEquals("Mr.", caseWorker.getTitle());

        caseWorker.setFirstname("John");
        assertEquals("John", caseWorker.getFirstname());

        caseWorker.setLastname("Doe");
        assertEquals("Doe", caseWorker.getLastname());

        caseWorker.setAddress1_telephone1("555-1234");
        assertEquals("555-1234", caseWorker.getAddress1_telephone1());

        caseWorker.setInternalemailaddress("john.doe@example.com");
        assertEquals("john.doe@example.com", caseWorker.getInternalemailaddress());
    }
}
