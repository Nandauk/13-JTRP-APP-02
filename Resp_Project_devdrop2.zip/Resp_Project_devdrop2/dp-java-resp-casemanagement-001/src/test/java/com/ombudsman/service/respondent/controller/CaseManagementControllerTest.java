
package com.ombudsman.service.respondent.controller;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;

import java.util.ArrayList;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.google.common.collect.Lists;
import com.ombudsman.service.respondent.common.CaseManagementWebClient;
import com.ombudsman.service.respondent.common.CommonUtil;
import com.ombudsman.service.respondent.common.Constants;
import com.ombudsman.service.respondent.common.StaticUtils;
import com.ombudsman.service.respondent.common.UserBean;
import com.ombudsman.service.respondent.common.ValidateUserSession;
import com.ombudsman.service.respondent.model.Accounts;
import com.ombudsman.service.respondent.model.ApiResponse;
import com.ombudsman.service.respondent.model.CaseExport;
import com.ombudsman.service.respondent.model.Filters;
import com.ombudsman.service.respondent.model.UpdateCase;
import com.ombudsman.service.respondent.model.UpdateCaseMessage;
import com.ombudsman.service.respondent.model.request.BulkCaseUpdateRequest;
import com.ombudsman.service.respondent.model.request.CaseByCaseReferenceReq;
import com.ombudsman.service.respondent.model.request.CaseDetailsByIdReq;
import com.ombudsman.service.respondent.model.request.CaseOutcomeByIdReq;
import com.ombudsman.service.respondent.model.request.CaseworkerReq;
import com.ombudsman.service.respondent.model.request.GetCaseFilterReq;
import com.ombudsman.service.respondent.model.request.GetCasesByRespondentReq;
import com.ombudsman.service.respondent.model.response.CaseByCaseReferenceRes;
import com.ombudsman.service.respondent.model.response.CaseDetailsByIdRes;
import com.ombudsman.service.respondent.model.response.CaseExportDownloadResponse;
import com.ombudsman.service.respondent.model.response.CaseOutcomeByIdRes;
import com.ombudsman.service.respondent.model.response.CasePartiesByIdRes;
import com.ombudsman.service.respondent.model.response.CaseWorkerDetailsByIdRes;
import com.ombudsman.service.respondent.model.response.CasesManagementRes;
import com.ombudsman.service.respondent.model.response.CaseworkerListByIdRes;
import com.ombudsman.service.respondent.model.response.GenericResponse;
import com.ombudsman.service.respondent.model.response.GetCaseFilterDataRes;
import com.ombudsman.service.respondent.model.response.GetResponseMessage;
import com.ombudsman.service.respondent.service.CaseByCaseReferenceService;
import com.ombudsman.service.respondent.service.CaseDetailsByIdService;
import com.ombudsman.service.respondent.service.CaseExportForDownloadService;
import com.ombudsman.service.respondent.service.CaseOutcomeByIdService;
import com.ombudsman.service.respondent.service.CaseworkerListByIdService;
import com.ombudsman.service.respondent.service.ICaseFilterService;
import com.ombudsman.service.respondent.service.ICasesByRespondentService;
import com.ombudsman.service.respondent.service.IExportCasesService;
import com.ombudsman.service.respondent.service.ILoginService;
import com.ombudsman.service.respondent.serviceimpl.CaseworkerListByIdServiceImpl;
import com.ombudsman.service.respondent.serviceimpl.ExportCasesServiceImpl;
import com.ombudsman.service.respondent.serviceimpl.UpdateFileService;

@ExtendWith(SpringExtension.class)
class CaseManagementControllerTest {
	private static final String STATUS = "valid";

	@InjectMocks
	private CaseManagementController respondentController;

	@Mock
	IExportCasesService exportService;
	@Mock
	private GenericResponse mMockGenericResponse;
	@Mock
	CommonUtil commonUtil;

	@Mock
	private ICaseFilterService getCaseFilterService;
	@Mock
	private ValidateUserSession mMockILoginService;

	@Mock
	private ICasesByRespondentService getCasesByRespondentService;
	@Mock
	private CaseManagementWebClient mMockCaseManagementWebClient;
	@Mock
	GetCasesByRespondentReq requestmMock;

	@Mock
	UserBean userbean;
	
	@Mock
	CaseExportDownloadResponse mMockCaseExportDownloadResponse;
	
	@Mock
	CaseExportForDownloadService mMockCaseExportForDownloadService;
	
	@Mock
	GetResponseMessage mMockGetResponseMessage;
	
	@Mock
	CaseDetailsByIdRes mMockaseDetailsByIdRes;
	
	@Mock
	CaseDetailsByIdReq mMockCaseDetailsByIdReq;
	
	@Mock
	CaseOutcomeByIdService caseOutcomeByIdService;
	
	@Mock
	CaseOutcomeByIdRes mMockCaseOutcomeByIdRes;
	@Mock
	CaseOutcomeByIdReq mMockcaseOutcomeByIdReq;
	@Mock
	CaseByCaseReferenceRes mMockCaseByCaseReferenceRes;
	@Mock
	CaseByCaseReferenceReq mMockCaseByCaseReferenceReq;
	@Mock
	CaseByCaseReferenceService caseByCaseReferenceService;
	@Mock
	CasePartiesByIdRes mMockCasePartiesByIdRes;

	@Mock
	CaseWorkerDetailsByIdRes mMockCaseWorkerDetailsByIdRes;
	
	@Mock
	CaseExport mMockCaseExport;

	@Mock
	private UpdateFileService updateFileService;
	
	@Mock
	CaseDetailsByIdService mMockCaseDetailsByIdService;
	@Mock
	ExportCasesServiceImpl mMockExportCasesServiceImpl;
	
	 @Mock
	 CaseworkerListByIdServiceImpl caseworkerListByIdServiceImpl;

	    @Mock
	    CaseworkerReq mMockCaseworkerReq;

	    @Mock
	    CaseworkerListByIdRes mMockCaseworkerListByIdRes;

	@Mock
	StaticUtils staticUtils;

	@BeforeEach
	public void setUp() throws Exception {
		when(mMockILoginService.isValidSession()).thenReturn(true);
		when(mMockGenericResponse.getStatus()).thenReturn(STATUS);
		when(userbean.getCorrelationId()).thenReturn("test");
		when(userbean.getUserObjectId()).thenReturn("test");
		when(userbean.getRoles()).thenReturn(Lists.newArrayList("CaseWorker"));

	}

	@SuppressWarnings("deprecation")
	@DisplayName("getCaseFilter")
	@Test
	void getCaseFilterTest() throws Exception {
		commonUtil.sessionFlag = "true";
		Mockito.when(userbean.getCorrelationId()).thenReturn("123456");
		GetCaseFilterReq request = new GetCaseFilterReq();
		ArrayList<Accounts> accountsList = new ArrayList<Accounts>();
		Accounts account = new Accounts();
		account.setAccountid("AC1234");
		accountsList.add(account);
		request.setOrganisationlist(accountsList);

		GetCaseFilterDataRes response = new GetCaseFilterDataRes();
		response.setMessage("Sucess");

		when(mMockGenericResponse.getStatus()).thenReturn(STATUS);

		Mockito.when(getCaseFilterService.getCaseFilterDataForOrganisation()).thenReturn(response);

		ResponseEntity<GetCaseFilterDataRes> responseEntity = respondentController.getCaseFilter();

		assertThat(responseEntity.getStatusCodeValue()).isEqualTo(200);

	}

	@SuppressWarnings("deprecation")
	@DisplayName("getCasesByRespondent")
	@Test
	void getCasesByRespondentTest() throws Exception {
		Mockito.when(userbean.getCorrelationId()).thenReturn("123456");
		GetCasesByRespondentReq request = new GetCasesByRespondentReq();
		ArrayList<Accounts> accountsList = new ArrayList<Accounts>();
		Accounts account = new Accounts();
		account.setAccountid("AC1234");
		accountsList.add(account);
		request.setOpencasesonly("false");
		Filters filters= new Filters();
		filters.setPagesize(10);
		filters.setPage(1);
		request.setFilters(filters);
		commonUtil.sessionFlag = "true";
		when(mMockGenericResponse.getStatus()).thenReturn(STATUS);
		CasesManagementRes response = new CasesManagementRes();
		response.setMessage("Sucess");

		Mockito.when(getCasesByRespondentService.getCaseListForOrganization(request)).thenReturn(response);

		ResponseEntity<CasesManagementRes> responseEntity = respondentController.getViewCaseList(request);

		assertThat(responseEntity.getStatusCodeValue()).isEqualTo(200);

	}

	@DisplayName("exportCSV")
	@Test
	void exportCSVTest() throws Exception {
		Mockito.when(userbean.getCorrelationId()).thenReturn("123456");
		commonUtil.sessionFlag = "true";
		CaseExport request = new CaseExport();
		request.setEntityName("export Cases");
		GetResponseMessage response = new GetResponseMessage();

		response.setMessage("Success");

		Mockito.when(exportService.getCasesExportDataByRespondent(request)).thenReturn(response);
		assertThat(response.getMessage()).isEqualTo("Success");

	}

//	@DisplayName("updateCaseTest")
//	@Test
//	public void updateCaseTest() throws Exception {
//		ApiResponse response = new ApiResponse();
//		response.setStatus(HttpStatus.OK);
//		response.setMessage("true");
//
//		UpdateCase dto = new UpdateCase();
//		Mockito.when(userbean.getCorrelationId()).thenReturn("123456");
//		when(mMockGenericResponse.getStatus()).thenReturn(STATUS);
//
//		Mockito.when(updateFileService.updateCase(dto)).thenReturn(response);
//
//		ResponseEntity<ApiResponse> responseEntity = respondentController.updateCase(dto);
//		assertThat(responseEntity.getStatusCodeValue()).isEqualTo(200);
//	}
	
	@DisplayName("BulkupdateCaseTest")
	@Test
	public void bulkUpdateCaseTest() throws Exception {
		ApiResponse response = new ApiResponse();
		response.setStatus(HttpStatus.OK);
		response.setMessage("true");

		BulkCaseUpdateRequest dto =  new BulkCaseUpdateRequest();
		Mockito.when(userbean.getCorrelationId()).thenReturn("123456");
		when(mMockGenericResponse.getStatus()).thenReturn(STATUS);

		Mockito.when(updateFileService.bulkupdateCase(dto)).thenReturn(response);

		ResponseEntity<ApiResponse> responseEntity = respondentController.bulkCaseUpdate(dto);
		assertThat(responseEntity.getStatusCodeValue()).isEqualTo(200);
	}

	@DisplayName("getSharedConfigTest")
	@Test
	public void getSharedConfigTest() throws Exception {
		ApiResponse response = new ApiResponse();
		response.setMessage("true");
		String url = "Mockurl";
		Mockito.when(userbean.getCorrelationId()).thenReturn("123456");
		when(mMockGenericResponse.getStatus()).thenReturn(STATUS);
		Mockito.when(staticUtils.getUrl(Constants.GetSharedConfigurationUrl)).thenReturn(url);
		Mockito.when(updateFileService.getSharedConfiguration(url)).thenReturn(response);
		ResponseEntity<ApiResponse> responseEntity = respondentController.getSharedConfig();
		assertThat(responseEntity.getStatusCodeValue()).isEqualTo(200);
	}
	
	
	@DisplayName("getexportCsvTest")
	@Test
	public void getexportCsvTest() throws Exception {
		CaseExport export = new CaseExport();
		Mockito.when(userbean.getCorrelationId()).thenReturn("123456");
		when(mMockGetResponseMessage.getMessage()).thenReturn("Success");
		Mockito.when(mMockExportCasesServiceImpl.getCasesExportDataByRespondent(mMockCaseExport)).thenReturn(mMockGetResponseMessage);
		ResponseEntity<GetResponseMessage> responseEntity = respondentController.exportCSV(mMockCaseExport);
		assertThat(responseEntity.getStatusCodeValue()).isEqualTo(200);
	}
		
	@DisplayName("casedetailsbyidTest")
	@Test
	public void casedetailsbyidTest() throws Exception {
		CaseDetailsByIdRes response = new CaseDetailsByIdRes();
		response.setMessage("true");
		Mockito.when(userbean.getCorrelationId()).thenReturn("123456");
		when(mMockGenericResponse.getStatus()).thenReturn(STATUS);
		Mockito.when(mMockCaseDetailsByIdService.getCaseDetailsById(mMockCaseDetailsByIdReq)).thenReturn(mMockaseDetailsByIdRes);
		ResponseEntity<CaseDetailsByIdRes> responseEntity = respondentController.getCaseDetailsById(mMockCaseDetailsByIdReq);
		assertThat(responseEntity.getStatusCodeValue()).isEqualTo(200);
	}
	
	@DisplayName("getCaseOutcomeByIdTest")
	@Test
	public void getCaseOutcomeByIdTest() throws Exception {
		CaseOutcomeByIdRes response = new CaseOutcomeByIdRes();
		response.setMessage("true");
		Mockito.when(userbean.getCorrelationId()).thenReturn("123456");
		when(mMockGenericResponse.getStatus()).thenReturn(STATUS);
		Mockito.when(caseOutcomeByIdService.getCaseOutcomeById(mMockcaseOutcomeByIdReq)).thenReturn(mMockCaseOutcomeByIdRes);
		ResponseEntity<CaseOutcomeByIdRes> responseEntity = respondentController.getCaseOutcomeById(mMockcaseOutcomeByIdReq);
		assertThat(responseEntity.getStatusCodeValue()).isEqualTo(200);
	}
	
	@DisplayName("getCaseWorkerDetailsByIdTest")
	@Test
	public void getCaseWorkerDetailsByIdTest() throws Exception {
		CaseWorkerDetailsByIdRes response = new CaseWorkerDetailsByIdRes();
		response.setMessage("true");
		Mockito.when(userbean.getCorrelationId()).thenReturn("123456");
		when(mMockGenericResponse.getStatus()).thenReturn(STATUS);
		Mockito.when(mMockCaseDetailsByIdService.getCaseWorkerDetailsById(mMockCaseDetailsByIdReq)).thenReturn(mMockCaseWorkerDetailsByIdRes);
		ResponseEntity<CaseWorkerDetailsByIdRes> responseEntity = respondentController.getCaseWorkerDetailsById(mMockCaseDetailsByIdReq);
		assertThat(responseEntity.getStatusCodeValue()).isEqualTo(200);
	}
	
	@DisplayName("getCaseByCasePreferenceTest")
	@Test
	public void getCaseByCasePreferenceTest() throws Exception {
		CaseByCaseReferenceRes response = new CaseByCaseReferenceRes();
		response.setMessage("true");
		Mockito.when(userbean.getCorrelationId()).thenReturn("123456");
		when(mMockGenericResponse.getStatus()).thenReturn(STATUS);
		Mockito.when(caseByCaseReferenceService.getCaseIncidentidByCaseReference(mMockCaseByCaseReferenceReq)).thenReturn(mMockCaseByCaseReferenceRes);
		ResponseEntity<CaseByCaseReferenceRes> responseEntity = respondentController.getCaseByCasePreference(mMockCaseByCaseReferenceReq);
		assertThat(responseEntity.getStatusCodeValue()).isEqualTo(200);
	}
	
	@DisplayName("getCasePartiesByIdTest")
	@Test
	public void getCasePartiesByIdTest() throws Exception {
		CasePartiesByIdRes response = new CasePartiesByIdRes();
		response.setMessage("true");
		Mockito.when(userbean.getCorrelationId()).thenReturn("123456");
		when(mMockGenericResponse.getStatus()).thenReturn(STATUS);
		Mockito.when(mMockCaseDetailsByIdService.getCasePartiesById(mMockCaseDetailsByIdReq)).thenReturn(mMockCasePartiesByIdRes);
		ResponseEntity<CasePartiesByIdRes> responseEntity = respondentController.getCasePartiesById(mMockCaseDetailsByIdReq);
		assertThat(responseEntity.getStatusCodeValue()).isEqualTo(200);
	}

	
//	@DisplayName("assignCasesTest")
//	@Test
//	public void assignCasesTest() throws Exception {
//		CaseAssignmentRes response = new CaseAssignmentRes();
//		response.setMessage("true");
//		Mockito.when(userbean.getCorrelationId()).thenReturn("123456");
//		when(mMockILoginService.getSessionTokenStatus()).thenReturn(mMockGenericResponse);
//		when(mMockGenericResponse.getStatus()).thenReturn(STATUS);
//		Mockito.when(mMockCaseworkerListByIdService.assignCasesTest(mMockCaseworkerReq)).thenReturn(mMockCaseworkerListByIdRes);
//		ResponseEntity<CaseworkerListByIdRes> responseEntity = respondentController.fetchCaseworkers(mMockCaseworkerReq);
//		assertThat(responseEntity.getStatusCodeValue()).isEqualTo(200);
//	}
//	
	
	
	
	
	

}
