package com.ombudsman.service.respondent.model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

class RepresentativeTest {

    @Test
    void testGettersAndSetters() {
        Representative rep = new Representative();

        // Complainant fields (inherited)
        rep.setSuffix("Sr.");
        assertEquals("Sr.", rep.getSuffix());
        
        rep.setAddress1_composite("456 Elm Street");
        assertEquals("456 Elm Street", rep.getAddress1_composite());

        // Representative fields
        rep.setRepresentativeType("LegalRep");
        assertEquals("LegalRep", rep.getRepresentativeType());

        rep.setOrganisation("RepOrg");
        assertEquals("RepOrg", rep.getOrganisation());

        rep.setReferenace("Ref-XYZ");
        assertEquals("Ref-XYZ", rep.getReferenace());

        rep.setContactid("CONT-777");
        assertEquals("CONT-777", rep.getContactid());
    }
}
