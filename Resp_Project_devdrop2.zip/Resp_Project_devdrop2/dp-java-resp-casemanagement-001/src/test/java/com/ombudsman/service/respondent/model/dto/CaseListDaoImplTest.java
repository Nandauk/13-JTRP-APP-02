package com.ombudsman.service.respondent.model.dto;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.security.auth.login.AccountNotFoundException;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.google.common.collect.Lists;
import com.ombudsman.service.respondent.common.UserBean;
import com.ombudsman.service.respondent.exception.OrganizationNotFoundException;
import com.ombudsman.service.respondent.exception.SQLDataAccessException;
import com.ombudsman.service.respondent.repository.dao.ICaseListDao;
import com.ombudsman.service.respondent.repository.daoimpl.CaseListDaoImpl;
import com.ombudsman.service.respondent.service.repository.CaseListJdbcRepository;
import com.ombudsman.service.respondent.serviceimpl.helper.CaseServiceHelper;

@ExtendWith(SpringExtension.class)
class CaseListDaoImplTest {
	private static List<String> groupIds = new ArrayList<>();
	private static List<Object> accountId = new ArrayList<>();

	@Mock
	private UserBean mMockuserBean;
	@Mock
	List<OrganizationDto> mMockOrganizationDto;
	@Mock
	OrganizationDto mMockorg ;
	@Mock
	CaseListJdbcRepository caseListJdbcRepositoryMock;
	@Mock
	CaseServiceHelper caseServiceHelperMock;
	@InjectMocks
	CaseListDaoImpl mMockCaseListDaoImpl;
	@Mock
	CaseFilterDetailsDto mMockCaseFilterDetailsDto;
	@Mock
	ICaseListDao mMockCaseListDao;

	@BeforeEach
	void setUp() {
		groupIds.add("groupId1");
		groupIds.add("groupId2");
		when(mMockuserBean.getGroups()).thenReturn(groupIds);

		accountId.add("accountId");
		accountId.add("accountId2");

	}

	@Test
	@DisplayName("GetCaseFilter")
	void testGetCaseFilter() throws Exception {
		// Arrange
		List<String> accountIds = Arrays.asList("accountId1,accountId2");
		Map<String, Object> gpids = new HashMap<>();
		Map<String, Object> accountIdsMap = new HashMap<>();
		accountIdsMap.put("#result-set-1", accountId);
		gpids.put("accountids", groupIds.stream().collect(Collectors.joining(",")));

		when(caseServiceHelperMock.getAccountIds("oid")).thenReturn(Lists.newArrayList("accountId1","accountId2"));
		List<CaseFilterDetailsDto> caseFilterDataFromRepo = new ArrayList<>();
		caseFilterDataFromRepo.add(new CaseFilterDetailsDto("filter1", "filterType1", "filterValue1"));
		caseFilterDataFromRepo.add(new CaseFilterDetailsDto("filter2", "filterType2", "filterValue2"));
		when(caseListJdbcRepositoryMock.getCaseFilter(groupIds)).thenReturn(caseFilterDataFromRepo);

		mMockorg.setOrganizationId("IdOrg");
		mMockorg.setOrganizationName("NameOrg");
		mMockOrganizationDto.add(mMockorg);
//		when(caseListJdbcRepositoryMock.getFindOrganizationName(groupIds)).thenReturn(mMockOrganizationDto);
		when(Optional.ofNullable(groupIds)
		.map(i -> caseListJdbcRepositoryMock.getFindOrganizationName(groupIds))
		.orElseThrow(() -> new AccountNotFoundException("No account found"))).thenReturn(mMockOrganizationDto);
				
		// Act
		try {
			when(mMockCaseListDao.getCaseFilter("oid")).thenReturn(caseFilterDataFromRepo);
			List<CaseFilterDetailsDto> result = mMockCaseListDaoImpl.getCaseFilter("oid");
			// Assert
			assertNotNull(result);
		//	assertEquals(2, result.size());
		} catch (Exception e) {
//			assertNotNull("");
			
		}
	}

	@Test
	@DisplayName("GetCaseFilter_OrganizationNotFoundException")
	void testGetCaseFilter_OrganizationNotFoundException()
			throws SQLDataAccessException, OrganizationNotFoundException, AccountNotFoundException {
		// Arrange
		when(caseServiceHelperMock.getAccountIds("oid")).thenReturn(Lists.newArrayList("accountId1","accountId2"));
		when(caseListJdbcRepositoryMock.getFindOrganizationName(any())).thenReturn(Collections.emptyList());
		// Act
		try {
		List<CaseFilterDetailsDto> result = mMockCaseListDaoImpl.getCaseFilter("oid");
		assertTrue(result.isEmpty());
		}catch (Exception e) {
			// TODO: handle exception
		}
	}

	@Test
	@DisplayName("GetCaseFilter_AccountNotFoundException")
	void testGetCaseFilter_AccountNotFoundException()
			throws SQLDataAccessException, OrganizationNotFoundException, AccountNotFoundException {
		// Arrange
		when(caseServiceHelperMock.getAccountIds("oid")).thenReturn(groupIds);
		when(caseListJdbcRepositoryMock.getFindOrganizationName(groupIds)).thenReturn(null);
		// Act
		try {
		List<CaseFilterDetailsDto> result = mMockCaseListDaoImpl.getCaseFilter("oid");
		assertNotNull(result);
		assertTrue(result.isEmpty());
		}catch (AccountNotFoundException e) {
			assertNotNull(e.getMessage());
			// TODO: handle exception
		}
	}

	@Test
	@DisplayName("GetCasesByRespondent")
	void testGetCasesByRespondent() throws SQLDataAccessException {
		// Arrange
		Map<String, Object> reqParam = new HashMap<>();
		when(caseServiceHelperMock.getAccountIds("oid")).thenReturn(Lists.newArrayList("accountId1","accountId2"));
		Map<String, Object> caseListDetails = new HashMap<>();
		caseListDetails.put("accountId1", "accountId2");
		when(caseListJdbcRepositoryMock.getCaseListDetails(reqParam)).thenReturn(caseListDetails);
		// Act
		ICaseListDao caseListDao = mock(ICaseListDao.class);
		when(caseListDao.getCasesByRespondent(reqParam, "oid")).thenReturn(caseListDetails);
		Map<String, Object> result = mMockCaseListDaoImpl.getCasesByRespondent(reqParam, "oid");
		// Assert
		assertNotNull(result);
	}

	@Test
	@DisplayName("GetCasesByRespondent_null")
	void testGetCasesByRespondent_Negative() throws SQLDataAccessException {
		// Arrange
		when(caseServiceHelperMock.getAccountIds("oid")).thenReturn(null);
		when(caseListJdbcRepositoryMock.getCaseListDetails(new HashMap<>())).thenReturn(null);
		// Act
		try {
		Map<String, Object> result = mMockCaseListDaoImpl.getCasesByRespondent(new HashMap<>(), "oid");
		// Assert
		assertTrue(result.isEmpty());
		}catch (Exception e) {
			// TODO: handle exception
		}
	}

}
