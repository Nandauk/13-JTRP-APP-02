package com.ombudsman.service.respondent.model;
 
import java.util.List;
 
 
public class Filters {
 
	private List<CaseFilterData> businessname;
	private List<CaseFilterData> complaintissue;
	private List<CaseFilterData> awaitingactionbusiness;
	private List<CaseFilterData> producttype;
	private List<CaseFilterData> casestage;
	private List<CaseFilterData> tradingname;
	private List<CaseFilterData> caseowner;
	private List<CaseFilterData> caseage;
	private List<CaseFilterData> closeroutcome;
	private List<CaseFilterData> prioritycases;
	private List<CaseFilterData> oldcasestatus;
	private List<CaseFilterData> awaitingactionfilter;
	private List<CaseFilterData> agecaseflag;//CaseAgeFlag
	private List<CaseFilterData> caseprogress; //CaseProgress
	private List<CaseFilterData> emailid;
	private List<CaseFilterData> outcome7days; // case filter for Outcome for Last seven Days
	private List<CaseFilterData> bfileoverdue;//case filter for Business file overdue
	private String startdate;
	private String enddate;
	private int page;
	private int pagesize;
	private String sortby;
	private String sorttype;
	private String searchBy;

	public List<CaseFilterData> getCaseprogress() {
		return caseprogress;
	}

	public void setCaseprogress(List<CaseFilterData> caseprogress) {
		this.caseprogress = caseprogress;
	}

	public List<CaseFilterData> getEmailid() {
		return emailid;
	}

	public void setEmailid(List<CaseFilterData> emailid) {
		this.emailid = emailid;
	}
	public List<CaseFilterData> getOutcome7days() {
		return outcome7days;
	}

	public void setOutcome7days(List<CaseFilterData> outcome7days) {
		this.outcome7days = outcome7days;
	}

	public List<CaseFilterData> getBfileoverdue() {
		return bfileoverdue;
	}

	public void setBfileoverdue(List<CaseFilterData> bfileoverdue) {
		this.bfileoverdue = bfileoverdue;
	}

	public String getSortby() {
		return sortby;
	}
 
	public void setSortby(final String sortby) {
		this.sortby = sortby;
	}
 
	public String getSorttype() {
		return sorttype;
	}
 
	public void setSorttype(final String sorttype) {
		this.sorttype = sorttype;
	}
 
	public List<CaseFilterData> getAwaitingactionfilter() {
		return awaitingactionfilter;
	}
 
	public void setAwaitingactionfilter(final List<CaseFilterData> awaitingactionfilter) {
		this.awaitingactionfilter = awaitingactionfilter;
	}
 
	public List<CaseFilterData> getComplaintissue() {
		return complaintissue;
	}
 
	public void setComplaintissue(List<CaseFilterData> complaintissue) {
		this.complaintissue = complaintissue;
	}
	public List<CaseFilterData> getAwaitingactionbusiness() {
		return awaitingactionbusiness;
	}
 
	public void setAwaitingactionbusiness(List<CaseFilterData> awaitingactionbusiness) {
		this.awaitingactionbusiness = awaitingactionbusiness;
	}
 
	public List<CaseFilterData> getProducttype() {
		return producttype;
	}
 
	public void setProducttype(List<CaseFilterData> producttype) {
		this.producttype = producttype;
	}
 
	public List<CaseFilterData> getCasestage() {
		return casestage;
	}
 
	public void setCasestage(List<CaseFilterData> casestage) {
		this.casestage = casestage;
	}
 
	public int getPage() {
		return page;
	}
 
	public void setPage(int page) {
		this.page = page;
	}
 
	public int getPagesize() {
		return pagesize;
	}
 
	public void setPagesize(int pagesize) {
		this.pagesize = pagesize;
	}
 
	public List<CaseFilterData> getBusinessname() {
		return businessname;
	}
 
	public void setBusinessname(List<CaseFilterData> businessname) {
		this.businessname = businessname;
	}
 
	public List<CaseFilterData> getTradingname() {
		return tradingname;
	}
 
	public void setTradingname(List<CaseFilterData> tradingname) {
		this.tradingname = tradingname;
	}
 
	public List<CaseFilterData> getCaseowner() {
		return caseowner;
	}
 
	public void setCaseowner(List<CaseFilterData> caseowner) {
		this.caseowner = caseowner;
	}
 
	public List<CaseFilterData> getCaseage() {
		return caseage;
	}
 
	public void setCaseage(List<CaseFilterData> caseage) {
		this.caseage = caseage;
	}
 
	public List<CaseFilterData> getCloseroutcome() {
		return closeroutcome;
	}
 
	public void setCloseroutcome(List<CaseFilterData> closeroutcome) {
		this.closeroutcome = closeroutcome;
	}
 
	public List<CaseFilterData> getPrioritycases() {
		return prioritycases;
	}
 
	public void setPrioritycases(List<CaseFilterData> prioritycases) {
		this.prioritycases = prioritycases;
	}
 
	public List<CaseFilterData> getOldcasestatus() {
		return oldcasestatus;
	}
 
	public void setOldcasestatus(List<CaseFilterData> oldcasestatus) {
		this.oldcasestatus = oldcasestatus;
	}
 
	//Setter getter method for CaseAgeFlag Started
	public List<CaseFilterData> getAgecaseflag() {
		return agecaseflag;
	}
	public void setAgecaseflag(List<CaseFilterData> agecaseflag) {
		this.agecaseflag = agecaseflag;
	} //Setter getter method for CaseAgeFlag ended
 
 
	public String getStartdate() {
		return startdate;
	}
 
	public void setStartdate(String startdate) {
		this.startdate = startdate;
	}
 
	public String getEnddate() {
		return enddate;
	}
 
	public void setEnddate(String enddate) {
		this.enddate = enddate;
	}
 
	public String getSearchBy() {
		return searchBy;
	}
 
	public void setSearchBy(String searchBy) {
		this.searchBy = searchBy;
	}
}