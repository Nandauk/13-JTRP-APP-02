package com.ombudsman.service.respondent.model.dto;

import java.io.Serializable;

public class OrganisationComplainantDto extends ComplainantDto implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String businesstypecode;
	private String address1_line1;
	private String address1_line2;
	private String address1_line3;
	private String address1_county;
	private String address1_postalcode;
	private String rcount;
	private String fos_businesstypecode_txt;
	private String name;
	public String getBusinesstypecode() {
		return businesstypecode;
	}
	public void setBusinesstypecode(String businesstypecode) {
		this.businesstypecode = businesstypecode;
	}
	public String getAddress1_line1() {
		return address1_line1;
	}
	public void setAddress1_line1(String address1_line1) {
		this.address1_line1 = address1_line1;
	}
	public String getAddress1_line2() {
		return address1_line2;
	}
	public void setAddress1_line2(String address1_line2) {
		this.address1_line2 = address1_line2;
	}
	public String getAddress1_line3() {
		return address1_line3;
	}
	public void setAddress1_line3(String address1_line3) {
		this.address1_line3 = address1_line3;
	}
	public String getAddress1_county() {
		return address1_county;
	}
	public void setAddress1_county(String address1_county) {
		this.address1_county = address1_county;
	}
	public String getAddress1_postalcode() {
		return address1_postalcode;
	}
	public void setAddress1_postalcode(String address1_postalcode) {
		this.address1_postalcode = address1_postalcode;
	}
	public String getRcount() {
		return rcount;
	}
	public void setRcount(String rcount) {
		this.rcount = rcount;
	}
	public String getFos_businesstypecode_txt() {
		return fos_businesstypecode_txt;
	}
	public void setFos_businesstypecode_txt(String fos_businesstypecode_txt) {
		this.fos_businesstypecode_txt = fos_businesstypecode_txt;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}

}
