package com.ombudsman.service.respondent.model.dto;

import java.time.OffsetDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.transaction.Transactional;

@Entity
@Table(name = "dp_audit_event")
@Transactional
public class AuditMaster {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "audit_record_id")
	private Integer auditRecordID; // notnull
	@Column(name = "user_oid")
	private String userOID; // notnull
	@Column(name = "audit_event_timestamp")
	private OffsetDateTime auditEventTimestamp; // notnull
	@Column(name = "audit_event_name")
	private String auditEventName; // notnull
	@Column(name = "primary_audit_entity")
	private String primaryAuditEntity;
	@Column(name = "primary_audit_entity_identifier")
	private String primaryAuditEntityIdentifier;
	@Column(name = "pre_audit_snapshot")
	private String preAuditSnapshot;
	@Column(name = "post_audit_snapshot")
	private String postAuditSnapshot;
	@Column(name = "created_by")
	private String createdBy; // notnull
	@Column(name = "modified_on")
	private OffsetDateTime modifiedOn;
	@Column(name = "modified_by")
	private String modifiedBy;

	public OffsetDateTime getAuditEventTimestamp() {
		return auditEventTimestamp;
	}

	public void setAuditEventTimestamp(OffsetDateTime auditEventTimestamp) {
		this.auditEventTimestamp = auditEventTimestamp;
	}

	public Integer getAuditRecordID() {
		return auditRecordID;
	}

	public void setAuditRecordID(Integer auditRecordID) {
		this.auditRecordID = auditRecordID;
	}

	public String getUserOID() {
		return userOID;
	}

	public void setUserOID(String userOID) {
		this.userOID = userOID;
	}

	public String getAuditEventName() {
		return auditEventName;
	}

	public void setAuditEventName(String auditEventName) {
		this.auditEventName = auditEventName;
	}

	public String getPrimaryAuditEntity() {
		return primaryAuditEntity;
	}

	public void setPrimaryAuditEntity(String primaryAuditEntity) {
		this.primaryAuditEntity = primaryAuditEntity;
	}

	public String getPrimaryAuditEntityIdentifier() {
		return primaryAuditEntityIdentifier;
	}

	public void setPrimaryAuditEntityIdentifier(String primaryAuditEntityIdentifier) {
		this.primaryAuditEntityIdentifier = primaryAuditEntityIdentifier;
	}

	public String getPreAuditSnapshot() {
		return preAuditSnapshot;
	}

	public void setPreAuditSnapshot(String preAuditSnapshot) {
		this.preAuditSnapshot = preAuditSnapshot;
	}

	public String getPostAuditSnapshot() {
		return postAuditSnapshot;
	}

	public void setPostAuditSnapshot(String postAuditSnapshot) {
		this.postAuditSnapshot = postAuditSnapshot;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public OffsetDateTime getModifiedOn() {
		return modifiedOn;
	}

	public void setModifiedOn(OffsetDateTime modifiedOn) {
		this.modifiedOn = modifiedOn;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
}
