package com.ombudsman.service.respondent.exception;

public class OrganisationIdMissingException extends RuntimeException {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public OrganisationIdMissingException(String exceptionMsg)
	{
		super(exceptionMsg);
	}


}
