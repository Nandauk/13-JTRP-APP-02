package com.ombudsman.service.respondent.repository.dao;

import java.util.List;
import java.util.Map;

import javax.security.auth.login.AccountNotFoundException;

import com.ombudsman.service.respondent.exception.OrganizationNotFoundException;
import com.ombudsman.service.respondent.exception.SQLDataAccessException;
import com.ombudsman.service.respondent.model.dto.CaseFilterDetailsDto;

public interface ICaseListDao {

	List<CaseFilterDetailsDto> getCaseFilter(String oid)
			throws SQLDataAccessException, OrganizationNotFoundException, AccountNotFoundException;

	Map<String, Object> getCasesByRespondent(Map<String, Object> requestData, String oid) throws SQLDataAccessException;

}
