package com.ombudsman.service.respondent;

import com.microsoft.applicationinsights.attach.ApplicationInsights;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.security.servlet.SecurityAutoConfiguration;

@SpringBootApplication(exclude = { SecurityAutoConfiguration.class })
public class CaseManagementApplication {

	public static void main(String[] args) {
		ApplicationInsights.attach();
		SpringApplication.run(CaseManagementApplication.class, args);
	}

}
