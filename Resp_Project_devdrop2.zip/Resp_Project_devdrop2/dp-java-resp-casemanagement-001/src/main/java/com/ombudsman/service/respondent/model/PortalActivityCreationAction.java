package com.ombudsman.service.respondent.model;

public class PortalActivityCreationAction {
	 private String digitalPortalUserName ;
	 private String digitalPortalUserEmailAddress ;
	 private String contactId ;
	public String getDigitalPortalUserName() {
		return digitalPortalUserName;
	}
	public void setDigitalPortalUserName(String digitalPortalUserName) {
		this.digitalPortalUserName = digitalPortalUserName;
	}
	public String getDigitalPortalUserEmailAddress() {
		return digitalPortalUserEmailAddress;
	}
	public void setDigitalPortalUserEmailAddress(String digitalPortalUserEmailAddress) {
		this.digitalPortalUserEmailAddress = digitalPortalUserEmailAddress;
	}
	public String getContactId() {
		return contactId;
	}
	public void setContactId(String contactId) {
		this.contactId = contactId;
	}
	
     
     
}
