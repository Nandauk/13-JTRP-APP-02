package com.ombudsman.service.respondent.exception;

import java.sql.SQLException;
import java.time.LocalDateTime;

import javax.security.auth.login.AccountNotFoundException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.UncategorizedSQLException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestController;

import jakarta.servlet.http.HttpServletRequest;

@RestController
@ControllerAdvice
public class GlobalControllerExceptionHandler {

	private static final String RESPONDENT_1002 = "RESPONDENT_1002";
	private static final String ERRORS_WHILE_EXECUTING_CASE_FILTER_DB_QUERY_URL_COMPLETE_ERRORS = "Errors while executing case filter db query:: URL= {}, complete errors::{}";
	private static final Logger LOG = LoggerFactory.getLogger(GlobalControllerExceptionHandler.class);
	
	@ExceptionHandler({UncategorizedSQLException.class})
	public ResponseEntity<ApiError> handleUncategorizedSQLException(Exception ex) {
		LOG.info("SQLException Occured::  complete errors::{}", ex.getMessage());
		ApiError err = new ApiError(LocalDateTime.now(), HttpStatus.INTERNAL_SERVER_ERROR,
				HttpStatusCode.valueOf(HttpStatus.INTERNAL_SERVER_ERROR.value()).toString(),"RESPONDENT_DB_1001");
		return new ResponseEntity<>(err, HttpStatus.INTERNAL_SERVER_ERROR);
	}

	@ExceptionHandler({SQLDataAccessException.class})
	public ResponseEntity<ApiError> handleSQLDataException(HttpServletRequest request, Exception ex) {
		LOG.info("SQLException Occured:: URL= {}, complete errors::{}", request.getRequestURL(), ex.getMessage());
		ApiError err = new ApiError(LocalDateTime.now(), HttpStatus.INTERNAL_SERVER_ERROR,
				HttpStatusCode.valueOf(HttpStatus.INTERNAL_SERVER_ERROR.value()).toString(),"RESPONDENT_DB_1001");
		return new ResponseEntity<>(err, HttpStatus.INTERNAL_SERVER_ERROR);
	}
	@ExceptionHandler({SQLException.class})
	public ResponseEntity<ApiError> handleSQLException(Exception ex) {
		LOG.info("SQLException complete errors::{}", ex.getMessage());
		ApiError err = new ApiError(LocalDateTime.now(), HttpStatus.INTERNAL_SERVER_ERROR, 
				HttpStatusCode.valueOf(HttpStatus.INTERNAL_SERVER_ERROR.value()).toString(),"RESPONDENT_DB_1001");
		return new ResponseEntity<>(err, HttpStatus.INTERNAL_SERVER_ERROR);
	}

	@ExceptionHandler({CaseFilterNotFoundException.class})
	public ResponseEntity<ApiError> handleCaseFilterNotFoundException(HttpServletRequest request, Exception ex) {
		LOG.info(ERRORS_WHILE_EXECUTING_CASE_FILTER_DB_QUERY_URL_COMPLETE_ERRORS, request.getRequestURL(),
				ex.getMessage());
		ApiError err = new ApiError(LocalDateTime.now(), HttpStatus.PRECONDITION_FAILED, "Case Filter not found",
				RESPONDENT_1002);
		return new ResponseEntity<>(err, HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler({CaseListNotFoundException.class})
	public ResponseEntity<ApiError> handleCaseListNotFoundExceptionError(HttpServletRequest request, Exception ex) {
		LOG.info(ERRORS_WHILE_EXECUTING_CASE_FILTER_DB_QUERY_URL_COMPLETE_ERRORS, request.getRequestURL(),
				ex.getMessage());
		ApiError err = new ApiError(LocalDateTime.now(), HttpStatus.PRECONDITION_FAILED, "Case List not found",
				RESPONDENT_1002);
		return new ResponseEntity<>(err, HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler({ResourceNotFoundException.class})
	public ResponseEntity<ApiError> handleResourceNotFoundException(HttpServletRequest request, Exception ex) {
		LOG.info(ERRORS_WHILE_EXECUTING_CASE_FILTER_DB_QUERY_URL_COMPLETE_ERRORS, request.getRequestURL(),
				ex.getMessage());
		ApiError err = new ApiError(LocalDateTime.now(), HttpStatus.NOT_FOUND,
				HttpStatusCode.valueOf(HttpStatus.NOT_FOUND.value()).toString(), "RESPONDENT_1004");
		return new ResponseEntity<>(err, HttpStatus.NOT_FOUND);
	}

	@ExceptionHandler({UnAuthorisedException.class})
	public ResponseEntity<ApiError> handleUnAuthorisedException(UnAuthorisedException error) {
		LOG.info("Errors while executing the method::{}", error.getMessage());
		ApiError err = new ApiError(LocalDateTime.now(), HttpStatus.UNAUTHORIZED,
				HttpStatusCode.valueOf(HttpStatus.UNAUTHORIZED.value()).toString(),"RESPONDENT_AZURE_1000");
		LOG.info("Errors while executing the method::{}", err);
		return new ResponseEntity<>(err, HttpStatus.UNAUTHORIZED);
	}

	@ExceptionHandler({OrganizationNotFoundException.class})
	public ResponseEntity<ApiError> handleOrganizationNotFoundException(OrganizationNotFoundException exception) {
	    LOG.info("Organization not found for the account ids= {}", exception.getMessage());
	    ApiError err = new ApiError(LocalDateTime.now(), HttpStatus.UNAUTHORIZED.value(),
	            "Please provide Organisation ID", "RESPONDENT_ORGANISATIONID_IS_REQUIRED_1008");
	    return new ResponseEntity<>(err, HttpStatus.UNAUTHORIZED);
	}


	
	
	@ExceptionHandler({MandatoryFieldException.class})
	public ResponseEntity<ApiError> handleMandatoryFieldException(MandatoryFieldException exception) {
	    LOG.info("CaseID is null {}", exception.getMessage());
	    ApiError err = new ApiError(LocalDateTime.now(), HttpStatus.NOT_FOUND.value(),
	            "Mandatory field error", "RESPONDENT_MANDATORY_FIELD_1006");
	    return new ResponseEntity<>(err, HttpStatus.NOT_FOUND);
	}




	@ExceptionHandler({AccountNotFoundException.class})
	public ResponseEntity<ApiError> handleAccountNotFoundException(AccountNotFoundException exception) {
		LOG.info("Account not found for the account ids= {}", exception.getMessage());
		ApiError err = new ApiError(LocalDateTime.now(), HttpStatus.INTERNAL_SERVER_ERROR, "No account found",
				String.valueOf(HttpStatus.INTERNAL_SERVER_ERROR.value()));
		return new ResponseEntity<>(err, HttpStatus.INTERNAL_SERVER_ERROR);
	}
	

	@ExceptionHandler({Exception.class})
	protected ResponseEntity<ApiError> handleException(Exception e) {

		ApiError err = new ApiError(LocalDateTime.now(), HttpStatus.PRECONDITION_FAILED, "Input is Invalid",
				RESPONDENT_1002);
		LOG.info("Input is Invalid {}", e.getMessage());
		return new ResponseEntity<>(err, HttpStatus.BAD_REQUEST);
	}
	
	@ExceptionHandler({CaseUpdateException.class})
	protected ResponseEntity<ApiError> handleCaseUpdateException(CaseUpdateException e) {

		ApiError err = new ApiError(LocalDateTime.now(), HttpStatus.PRECONDITION_FAILED, "Error Occurred in Case Update API. Please Try Again.",
				RESPONDENT_1002);
		LOG.info("CaseUpdateException {}", e.getMessage());
		return new ResponseEntity<>(err, HttpStatus.BAD_REQUEST);
	}
	
	@ExceptionHandler({Throwable.class})
	protected ResponseEntity<ApiError> handleThrowable(Exception e) {

		ApiError err = new ApiError(LocalDateTime.now(), HttpStatus.INTERNAL_SERVER_ERROR,
				String.valueOf(HttpStatus.INTERNAL_SERVER_ERROR.value()), "RESPONDENT_1004");
		LOG.info("Error while executing SP :: {}", e.getMessage());
		return new ResponseEntity<>(err, HttpStatus.INTERNAL_SERVER_ERROR);
	}

	@ExceptionHandler({CaseOutComesNotFoundException.class})
	public ResponseEntity<ApiError> handleCaseOutComesNotFoundException(CaseOutComesNotFoundException exception) {
		LOG.info("Case Outcomes not found for the incident id :: {}", exception.getMessage());
		ApiError err = new ApiError(LocalDateTime.now(), HttpStatus.PRECONDITION_FAILED, "Case Outcomes not found",
				RESPONDENT_1002);
		return new ResponseEntity<>(err, HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler({CaseDetailsNotFoundException.class})
	public ResponseEntity<ApiError> handleCaseDetailsNotFoundException(CaseDetailsNotFoundException exception) {
		LOG.info("Case Details not found for the incident id :: {}", exception.getMessage());
		ApiError err = new ApiError(LocalDateTime.now(), HttpStatus.PRECONDITION_FAILED, "Case Details not found",
				RESPONDENT_1002);
		return new ResponseEntity<>(err, HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler({CasePartiesNotFoundException.class})
	public ResponseEntity<ApiError> handleCasePartiesNotFoundException(CasePartiesNotFoundException exception) {
		LOG.info("Case Parties not found for the incident id :: {}", exception.getMessage());
		ApiError err = new ApiError(LocalDateTime.now(), HttpStatus.PRECONDITION_FAILED, "Case Parties not found",
				RESPONDENT_1002);
		return new ResponseEntity<>(err, HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler({CaseWorkerDetailsNotFoundException.class})
	public ResponseEntity<ApiError> handleCaseWorkerDetailsNotFoundException(
			CaseWorkerDetailsNotFoundException exception) {
		LOG.info("Case Worker Details not found for the incident id :: {}", exception.getMessage());
		ApiError err = new ApiError(LocalDateTime.now(), HttpStatus.PRECONDITION_FAILED,
				"Case Worker Details not found", RESPONDENT_1002);
		return new ResponseEntity<>(err, HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler({CaseReferenceDetailsNotFoundException.class})
	public ResponseEntity<ApiError> handleCaseReferenceDetailsNotFoundException(
			CaseReferenceDetailsNotFoundException exception) {
		LOG.info("Case Reference not found for the ticket id :: {}", exception.getMessage());
		ApiError err = new ApiError(LocalDateTime.now(), HttpStatus.PRECONDITION_FAILED,
				"Case reference not found for organisation.", RESPONDENT_1002);
		return new ResponseEntity<>(err, HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler({RecordCreationException.class})
	public ResponseEntity<ApiError> handleRecordCreationException(
			RecordCreationException exception) {		
		LOG.info("Record Creation Failed. Please Try Again. {}", exception.getMessage());
		ApiError err = new ApiError(LocalDateTime.now(), HttpStatus.INTERNAL_SERVER_ERROR,
				String.valueOf(HttpStatus.INTERNAL_SERVER_ERROR), RESPONDENT_1002);
		return new ResponseEntity<>(err, HttpStatus.INTERNAL_SERVER_ERROR);
	}
	
	@ExceptionHandler({OrganisationIdMissingException.class})
	public ResponseEntity<ApiError> handleOrganisationIdMissingException(
	        OrganisationIdMissingException exception) {
	    LOG.info("Organisation Id is missing:: {}", exception.getMessage());
	    ApiError err = new ApiError(LocalDateTime.now(), HttpStatus.UNAUTHORIZED.value(),
	            "Please provide Organisation ID", "RESPONDENT_ORGANISATIONID_IS_REQUIRED_1008");
	    return new ResponseEntity<>(err, HttpStatus.UNAUTHORIZED);
	}


	 
	@ExceptionHandler({MandatoryFieldMissingException.class})
	public ResponseEntity<ApiError> handleMandatoryFieldMissingException(
	        MandatoryFieldMissingException exception) {
	    LOG.info("Mandatory field is missing:: {}", exception.getMessage());
	    ApiError err = new ApiError(LocalDateTime.now(), HttpStatus.BAD_REQUEST.value(),
	            "Mandatory field error", "RESPONDENT_MANDATORY_FIELD_1006");
	    return new ResponseEntity<>(err, HttpStatus.BAD_REQUEST);
	}


	@ExceptionHandler({InvalidOrganisationException.class})
	public ResponseEntity<ApiError> handleInvalidOrganisationException(
	        InvalidOrganisationException exception) {
	    LOG.info("Invalid Organisation id:: {}", exception.getMessage());
	    ApiError err = new ApiError(LocalDateTime.now(), HttpStatus.NOT_FOUND.value(),
	            "Invalid Organisation", "RESPONDENT_INVALID_AD_ORG_1000");
	    return new ResponseEntity<>(err, HttpStatus.NOT_FOUND);
	}

	@ExceptionHandler({SQLServerException.class})
	public ResponseEntity<ApiError> handleSQLServerException(SQLServerException exception) {
	    LOG.info("Invalid Organisation id:: {}", exception.getMessage());
	    ApiError err = new ApiError(LocalDateTime.now(), HttpStatus.NOT_FOUND.value(),
	            "Error in SQL server connectivity", "RESPONDENT_SQL_1001");
	    return new ResponseEntity<>(err, HttpStatus.NOT_FOUND);
	}

	
	@ExceptionHandler({DbRecordCreationException.class})
	public ResponseEntity<ApiError> handleDbRecordCreationException(
	        DbRecordCreationException exception) {
	    LOG.info("Invalid Organisation id:: {}", exception.getMessage());
	    ApiError err = new ApiError(LocalDateTime.now(), HttpStatus.INTERNAL_SERVER_ERROR.value(),
	            "Record creation failed", "RESPONDENT_RECORD_CREATION_FAILED_1005");
	    return new ResponseEntity<>(err, HttpStatus.INTERNAL_SERVER_ERROR);
	}
	

}
