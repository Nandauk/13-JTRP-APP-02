package com.ombudsman.service.respondent.exception;

public class AzureServiceException extends RespondentsServiceExceptions {

	private static final long serialVersionUID = 1L;

	public AzureServiceException(String message, String exceptionMessage) {
		super(message, "RESPONDENT_AZURE_1000", exceptionMessage);
	}

}
