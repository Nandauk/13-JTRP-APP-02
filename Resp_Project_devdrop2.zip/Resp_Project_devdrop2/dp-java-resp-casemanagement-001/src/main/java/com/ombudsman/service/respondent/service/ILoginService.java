package com.ombudsman.service.respondent.service;

import com.ombudsman.service.respondent.model.response.GenericResponse;

public interface ILoginService {	
	public GenericResponse addUserSessionEntry();
	GenericResponse logoutForUserSession() ;
	GenericResponse getSessionTokenStatus() ;

}
