package com.ombudsman.service.respondent.service;

import java.io.IOException;

import org.json.JSONException;

import com.ombudsman.service.respondent.exception.AzureServiceException;
import com.ombudsman.service.respondent.exception.CaseReferenceDetailsNotFoundException;
import com.ombudsman.service.respondent.exception.SQLDataAccessException;
import com.ombudsman.service.respondent.exception.UnAuthorisedException;
import com.ombudsman.service.respondent.model.request.CaseByCaseReferenceReq;
import com.ombudsman.service.respondent.model.response.CaseByCaseReferenceRes;

public interface CaseByCaseReferenceService {
	
	public CaseByCaseReferenceRes getCaseIncidentidByCaseReference(CaseByCaseReferenceReq request) throws AzureServiceException, JSONException, IOException, SQLDataAccessException, CaseReferenceDetailsNotFoundException, UnAuthorisedException;

}
