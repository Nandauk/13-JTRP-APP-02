package com.ombudsman.service.respondent.common;

public class Constants {
	public static final String PAGE_SIZE="pagesize";
	public static final String PAGE_COUNT="pagecount";
	public static final String IS_OPEN_CASE="isOpenCases";
	public static final String COMPLAINANT_ISSUE="complainantissue";
	public static final String CASE_STATUS="casestatus";
	public static final String PRODUCT_TYPE="producttype";
	public static final String CASE_STAGE="casestage";
	public static final String ACCOUNT_ID="accountid";
	public static final String CASE_OWNER="caseowner";
	public static final String CASE_AGE="caseage";
	public static final String RESOLVING_OUTCOME="resolvingoutcome";	
	public static final String LIVE_CASE_AGE="livecaseage";
	public static final String TRADE_NAME="tradingname";
	public static final String EMAIL_ID="emailid";
	public static final String PERIORITY_CASE="prioritycase";
	public static final String ACCOUNT_IDS="accountids";
	public static final String VALID="valid";
	public static final String CASE_PROGRESS="caseprogress";
	public static final String BUSINESS_FILE_OVERDUE="bfileoverdue";
	public static final String OUTCOME_LAST_SEVENDAYS="outcome7days";
	public static final String CASEWORKER_ROLES = "CaseWorker";
	public static final String SUPERVISOR_ROLES = "Supervisor";
	private Constants() {
	      //not called
	   }
	public static final String GetSharedConfigurationUrl = "/GetSharedConfiguration";
	
	public static final String DD_MM_YYYY = "MM/dd/yyyy hh:mm:ss a";
	public static final String INCIDENTID_IS_A_MANDATORY_FIELD = "Incidentid is a mandatory field.";
	public static final String FAILED = "Failed";
	public static final String INCIDENTID_IS_NOT_A_VALID_FIELD = "IncidentID is  an invalid field";
	public static final String INCIDENTID_IS_A_VALID_FIELD = "IncidentID is  a valid field";
	public static final String CASE_PARTIES_NOT_FOUND = "Case Parties not found";
	public static final String CASE_DETAILS_NOT_FOUND = "Case Details not found";
	public static final String CASE_WORKER_DETAILS_NOT_FOUND = "Case Worker Details not found";
	public static final String RESULT_SET_1 = "#result-set-1";
	public static final String RESULT_SET_2 = "#result-set-2";
	public static final String RESULT_SET_3 = "#result-set-3";
	public static final String RESULT_SET_4 = "#result-set-4";
	public static final String RESULT_SET_5 = "#result-set-5";
	public static final String CASE_OUTCOMES_NOT_FOUND = "Case Outcomes not found";
	public static final String CASE_REFERENCE_IS_REQUIRED = "Case reference is required.";
	public static final String CASE_REFERENCE_NOT_FOUND_FOR_ORGANISATION = "Case reference not found for organisation.";
	public static final String SUCCESS = "Success";
	public static final String CASE_REFERENCE_IS_NOT_A_VALID_FIELD = "Case Reference is an invalid field";
	public static final String CASE_REFERENCE_IS_A_VALID_FIELD = "Case Reference is a valid Field";
	public static final String COMMA = ",";
	public static final String USER_IS_NOT_TAGGED_WITH_ANY_ORGANISATION = "User is not tagged with any organisation.";
	public static final String EMAILID="emailid";
	
}
