package com.ombudsman.service.respondent.controller;

import static com.ombudsman.service.respondent.common.Constants.CASEWORKER_ROLES;
import static com.ombudsman.service.respondent.common.Constants.GetSharedConfigurationUrl;
import static com.ombudsman.service.respondent.common.Constants.SUPERVISOR_ROLES;

import java.io.IOException;
import java.sql.SQLException;
import java.time.LocalDateTime;

import javax.security.auth.login.AccountNotFoundException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ombudsman.service.respondent.common.CaseManagementWebClient;
import com.ombudsman.service.respondent.common.CommonUtil;
import com.ombudsman.service.respondent.common.StaticUtils;
import com.ombudsman.service.respondent.common.UserBean;
import com.ombudsman.service.respondent.common.ValidateUserSession;
import com.ombudsman.service.respondent.exception.CaseFilterNotFoundException;
import com.ombudsman.service.respondent.exception.CaseListNotFoundException;
import com.ombudsman.service.respondent.exception.CasePartiesNotFoundException;
import com.ombudsman.service.respondent.exception.InvalidOrganisationException;
import com.ombudsman.service.respondent.exception.MandatoryFieldException;
import com.ombudsman.service.respondent.exception.OrganizationNotFoundException;
import com.ombudsman.service.respondent.exception.SQLDataAccessException;
import com.ombudsman.service.respondent.exception.UnAuthorisedException;
import com.ombudsman.service.respondent.heathprobe.RespondentReadinessHolder;
import com.ombudsman.service.respondent.model.ApiResponse;
import com.ombudsman.service.respondent.model.CaseExport;
import com.ombudsman.service.respondent.model.request.AssignCasesReq;
import com.ombudsman.service.respondent.model.request.BulkCaseUpdateRequest;
import com.ombudsman.service.respondent.model.request.CaseByCaseReferenceReq;
import com.ombudsman.service.respondent.model.request.CaseDetailsByIdReq;
import com.ombudsman.service.respondent.model.request.CaseOutcomeByIdReq;
import com.ombudsman.service.respondent.model.request.CaseworkerReq;
import com.ombudsman.service.respondent.model.request.GetCasesByRespondentReq;
import com.ombudsman.service.respondent.model.response.CaseAssignmentRes;
import com.ombudsman.service.respondent.model.response.CaseByCaseReferenceRes;
import com.ombudsman.service.respondent.model.response.CaseDetailsByIdRes;
import com.ombudsman.service.respondent.model.response.CaseOutcomeByIdRes;
import com.ombudsman.service.respondent.model.response.CasePartiesByIdRes;
import com.ombudsman.service.respondent.model.response.CaseWorkerDetailsByIdRes;
import com.ombudsman.service.respondent.model.response.CasesManagementRes;
import com.ombudsman.service.respondent.model.response.CaseworkerListByIdRes;
import com.ombudsman.service.respondent.model.response.GenericResponse;
import com.ombudsman.service.respondent.model.response.GetCaseFilterDataRes;
import com.ombudsman.service.respondent.model.response.GetResponseMessage;
import com.ombudsman.service.respondent.service.CaseAssignmentService;
import com.ombudsman.service.respondent.service.CaseByCaseReferenceService;
import com.ombudsman.service.respondent.service.CaseDetailsByIdService;
import com.ombudsman.service.respondent.service.CaseExportForDownloadService;
import com.ombudsman.service.respondent.service.CaseOutcomeByIdService;
import com.ombudsman.service.respondent.service.CaseworkerListByIdService;
import com.ombudsman.service.respondent.service.ICaseFilterService;
import com.ombudsman.service.respondent.service.ICasesByRespondentService;
import com.ombudsman.service.respondent.service.IExportCasesService;
import com.ombudsman.service.respondent.service.IUpdateFileService;

import jakarta.validation.Valid;

@RestController
public class CaseManagementController {

	private static final String PAGESIZE_LIMIT_EXCEEDED = "Pagesize limit exceeded";

	private static final int _25 = 25;

	Logger appLogger = LogManager.getRootLogger();

	@Autowired
	ICasesByRespondentService getCasesByRespondentService;

	@Autowired
	CaseOutcomeByIdService caseOutcomeByIdService;

	@Autowired
	CaseByCaseReferenceService caseByCaseReferenceService;

	@Autowired
	ICaseFilterService getCaseFilterService;
	@Autowired
	RespondentReadinessHolder redinessHealthHolder;
	@Autowired
	IExportCasesService exportService;
	@Autowired
	CaseExportForDownloadService caseExportForDownloadService;
	@Autowired
	StaticUtils staticUtils;

	@Autowired
	CommonUtil commonUtil;

	@Autowired
	UserBean userbean;

	@Autowired
	ValidateUserSession validateUserSession;

	@Autowired
	private IUpdateFileService updateFileService;

	@Autowired
	CaseManagementWebClient caseManagementWebClient;

	@Autowired

	CaseDetailsByIdService caseDetailsByIdService;

	@Autowired
	CaseworkerListByIdService caseworkerListByIdService;

	@Autowired
	CaseAssignmentService caseAssignmentService;

	@GetMapping(value = "/ombudsmanservice/v1/casemanagement/casefilter")
	public ResponseEntity<GetCaseFilterDataRes> getCaseFilter() throws SQLDataAccessException, AccountNotFoundException,
			OrganizationNotFoundException, UnAuthorisedException, CaseFilterNotFoundException {
		GetCaseFilterDataRes response = null;

		if ((userbean.getRoles().contains(CASEWORKER_ROLES) || userbean.getRoles().contains(SUPERVISOR_ROLES))
				&& validateUserSession.isValidSession()) {
			response = getCaseFilterService.getCaseFilterDataForOrganisation();

			appLogger.info("Respondent Casefilter Controller Method Started.CorrelationId:-{} OID:-{}",
					userbean.getCorrelationId(), userbean.getUserObjectId());
			return new ResponseEntity<>(response, HttpStatus.OK);
		}
		return new ResponseEntity<>(response, HttpStatus.UNAUTHORIZED);
	}

	@PostMapping(path = "/ombudsmanservice/v1/casemanagement/caselist")
	public @ResponseBody ResponseEntity<CasesManagementRes> getViewCaseList(
			@Valid @RequestBody GetCasesByRespondentReq request) throws SQLDataAccessException, JSONException,
			CaseListNotFoundException, IOException, UnAuthorisedException {

		CasesManagementRes result = new CasesManagementRes();
		if ((userbean.getRoles().contains(CASEWORKER_ROLES) || userbean.getRoles().contains(SUPERVISOR_ROLES))
				&& validateUserSession.isValidSession()) {
			if (request.getFilters().getPagesize() > _25) {
				result.setMessage(PAGESIZE_LIMIT_EXCEEDED);
				return new ResponseEntity<>(result, HttpStatus.BAD_REQUEST);
			}
			result = getCasesByRespondentService.getCaseListForOrganization(request);
			return new ResponseEntity<>(result, HttpStatus.OK);
		}
		return new ResponseEntity<>(result, HttpStatus.UNAUTHORIZED);

	}

	@PostMapping("/ombudsmanservice/v1/casemanagement/caseexport")
	public @ResponseBody ResponseEntity<GetResponseMessage> exportCSV(@RequestBody @Valid CaseExport request)
			throws NullPointerException, InterruptedException, IOException, SQLException, OrganizationNotFoundException,
			UnAuthorisedException {

		appLogger.info("Info : Respondents Caseexport Controller Method Started.CorrelationId:-{} OID:-{}",
				userbean.getCorrelationId(), userbean.getUserObjectId());

		appLogger.info("Session flag: {}", commonUtil.sessionFlag);
		GetResponseMessage response = null;
		if ((userbean.getRoles().contains(CASEWORKER_ROLES) || userbean.getRoles().contains(SUPERVISOR_ROLES))
				&& validateUserSession.isValidSession()) {
			response = exportService.getCasesExportDataByRespondent(request);

			appLogger.info("End of Respondents Caseexport Controller Method.CorrelationId:-{} OID:-{}",
					userbean.getCorrelationId(), userbean.getUserObjectId());
			return new ResponseEntity<>(response, HttpStatus.OK);
		}
		return new ResponseEntity<>(response, HttpStatus.UNAUTHORIZED);

	}

	@GetMapping(value = "/ombudsmanservice/v1/casemanagement/getsharedconfiguration")
	public ResponseEntity<ApiResponse> getSharedConfig() throws JsonProcessingException, UnAuthorisedException {
		appLogger.info("Respondents getSharedConfig Controller Method Started.CorrelationId:-{} OID:-{}",
				userbean.getCorrelationId(), userbean.getUserObjectId());
		ApiResponse response = null;
		if ((userbean.getRoles().contains(CASEWORKER_ROLES) || userbean.getRoles().contains(SUPERVISOR_ROLES))
				&& validateUserSession.isValidSession()) {
			String url = staticUtils.getUrl(GetSharedConfigurationUrl);
			response = updateFileService.getSharedConfiguration(url);

			appLogger.info("End of Respondents getSharedConfig Controller Method.CorrelationId:-{} OID:-{}",
					userbean.getCorrelationId(), userbean.getUserObjectId());
			return new ResponseEntity<>(response, HttpStatus.OK);
		}
		return new ResponseEntity<>(response, HttpStatus.UNAUTHORIZED);
	}

	@PostMapping("/ombudsmanservice/v1/casemanagement/bulkupdatecase")
	public ResponseEntity<ApiResponse> bulkCaseUpdate(@RequestBody BulkCaseUpdateRequest dto)
			throws UnAuthorisedException, OrganizationNotFoundException, MandatoryFieldException,
			JsonProcessingException {
		appLogger.info("Respondents Bulk UpdateCase Controller Method Started.CorrelationId:-{} OID:-{}",
				userbean.getCorrelationId(), userbean.getUserObjectId());
		ApiResponse response = null;
		if ((userbean.getRoles().contains(CASEWORKER_ROLES) || userbean.getRoles().contains(SUPERVISOR_ROLES))
				&& validateUserSession.isValidSession()) {
			response = updateFileService.bulkupdateCase(dto);
			appLogger.info("End of Respondents Bulk UpdateCase Controller Method.CorrelationId:-{} OID:-{}",
					userbean.getCorrelationId(), userbean.getUserObjectId());
			return new ResponseEntity<>(response, HttpStatus.OK);
		}
		return new ResponseEntity<>(response, HttpStatus.UNAUTHORIZED);
	}

	@PostMapping("/ombudsmanservice/v1/casemanagement/casedetails/casedetailsbyid")
	public ResponseEntity<CaseDetailsByIdRes> getCaseDetailsById(@Valid @RequestBody CaseDetailsByIdReq request)
			throws SQLDataAccessException, UnAuthorisedException, IOException {

		appLogger.info("CaseManagement Casedetails Controller Method Started.CorrelationId:-{} OID:-{}",
				userbean.getCorrelationId(), userbean.getUserObjectId());
		CaseDetailsByIdRes response = null;
		if ((userbean.getRoles().contains(CASEWORKER_ROLES) || userbean.getRoles().contains(SUPERVISOR_ROLES))
				&& validateUserSession.isValidSession()) {

			response = caseDetailsByIdService.getCaseDetailsById(request);

			appLogger.info("End of CaseManagement Casedetails Controller Method.CorrelationId:-{} OID:-{}",
					userbean.getCorrelationId(), userbean.getUserObjectId());
			return new ResponseEntity<>(response, HttpStatus.OK);
		}
		return new ResponseEntity<>(response, HttpStatus.UNAUTHORIZED);
	}

	@PostMapping(value = "/ombudsmanservice/v1/casemanagement/casedetails/caseoutcomes")
	public ResponseEntity<CaseOutcomeByIdRes> getCaseOutcomeById(@Valid @RequestBody CaseOutcomeByIdReq request)
			throws SQLDataAccessException, AccountNotFoundException, UnAuthorisedException, IOException {

		appLogger.info("CaseManagement Caseoutcomes Controller Method Started.CorrelationId:-{} OID:-{}",
				userbean.getCorrelationId(), userbean.getUserObjectId());
		CaseOutcomeByIdRes response = null;
		if ((userbean.getRoles().contains(CASEWORKER_ROLES) || userbean.getRoles().contains(SUPERVISOR_ROLES))
				&& validateUserSession.isValidSession()) {
			response = caseOutcomeByIdService.getCaseOutcomeById(request);

			appLogger.info("End of CaseManagement Caseoutcomes Controller Method.CorrelationId:-{} OID:-{}",
					userbean.getCorrelationId(), userbean.getUserObjectId());
			return new ResponseEntity<>(response, HttpStatus.OK);
		}
		return new ResponseEntity<>(response, HttpStatus.UNAUTHORIZED);
	}

	@PostMapping(value = "/ombudsmanservice/v1/casemanagement/casedetails/caseworker")
	public ResponseEntity<CaseWorkerDetailsByIdRes> getCaseWorkerDetailsById(
			@Valid @RequestBody CaseDetailsByIdReq request)
			throws SQLDataAccessException, UnAuthorisedException, IOException {

		appLogger.info("CaseManagement Caseworker Controller Method Started.CorrelationId:-{} OID:-{}",
				userbean.getCorrelationId(), userbean.getUserObjectId());

		CaseWorkerDetailsByIdRes response = null;
		if ((userbean.getRoles().contains(CASEWORKER_ROLES) || userbean.getRoles().contains(SUPERVISOR_ROLES))
				&& validateUserSession.isValidSession()) {
			response = caseDetailsByIdService.getCaseWorkerDetailsById(request);
			appLogger.info("End of CaseManagement Caseworker Controller Method.CorrelationId:-{} OID:-{}",
					userbean.getCorrelationId(), userbean.getUserObjectId());
			return new ResponseEntity<>(response, HttpStatus.OK);
		}
		return new ResponseEntity<>(response, HttpStatus.UNAUTHORIZED);
	}

	@PostMapping(path = "/ombudsmanservice/v1/casemanagement/casedetails/casepreference")
	public @ResponseBody ResponseEntity<CaseByCaseReferenceRes> getCaseByCasePreference(
			@Valid @RequestBody CaseByCaseReferenceReq request)
			throws SQLDataAccessException, UnAuthorisedException, IOException {
		appLogger.info("CaseManagement Casepreference Controller Method Started.CorrelationId:-{} OID:-{}",
				userbean.getCorrelationId(), userbean.getUserObjectId());

		CaseByCaseReferenceRes response = null;
		if ((userbean.getRoles().contains(CASEWORKER_ROLES) || userbean.getRoles().contains(SUPERVISOR_ROLES))
				&& validateUserSession.isValidSession()) {
			response = caseByCaseReferenceService.getCaseIncidentidByCaseReference(request);
			appLogger.info("End of CaseManagement Casepreference Controller Method.CorrelationId:-{} OID:-{}",
					userbean.getCorrelationId(), userbean.getUserObjectId());
			return new ResponseEntity<>(response, HttpStatus.OK);
		}
		return new ResponseEntity<>(response, HttpStatus.UNAUTHORIZED);

	}

	@PostMapping(value = "/ombudsmanservice/v1/casemanagement/casedetails/caseparties")
	public ResponseEntity<CasePartiesByIdRes> getCasePartiesById(@Valid @RequestBody CaseDetailsByIdReq request)
			throws SQLDataAccessException, CasePartiesNotFoundException, UnAuthorisedException, IOException {
		appLogger.info("CaseManagement Caseparties Controller Method Started.CorrelationId:-{} OID:-{}",
				userbean.getCorrelationId(), userbean.getUserObjectId());

		CasePartiesByIdRes response = null;
		if ((userbean.getRoles().contains(CASEWORKER_ROLES) || userbean.getRoles().contains(SUPERVISOR_ROLES))
				&& validateUserSession.isValidSession()) {
			response = caseDetailsByIdService.getCasePartiesById(request);
			appLogger.info("CaseManagement Caseparties Controller Method Ended.CorrelationId:-{} OID:-{}",
					userbean.getCorrelationId(), userbean.getUserObjectId());
			return new ResponseEntity<>(response, HttpStatus.OK);
		}
		return new ResponseEntity<>(response, HttpStatus.UNAUTHORIZED);

	}

	@PostMapping("/ombudsmanservice/v1/casemanagement/fetchcaseworkers")
	public ResponseEntity<CaseworkerListByIdRes> fetchCaseworkers(@RequestBody @Valid CaseworkerReq request)
			throws InvalidOrganisationException, SQLDataAccessException, AccountNotFoundException,
			UnAuthorisedException {
		appLogger.info("fetchCaseworkers Controller Method Started. CorrelationId:-{} OID:-{}",
				userbean.getCorrelationId(), userbean.getUserObjectId());

		CaseworkerListByIdRes response = null;

		if ((userbean.getRoles().contains(CASEWORKER_ROLES) || userbean.getRoles().contains(SUPERVISOR_ROLES))
				&& validateUserSession.isValidSession()) {
			response = caseworkerListByIdService.getCaseworkers(request);

			appLogger.info("End of fetchCaseworkers Controller Method. CorrelationId:-{} OID:-{}",
					userbean.getCorrelationId(), userbean.getUserObjectId());

			return new ResponseEntity<>(response, HttpStatus.OK);
		}

		return new ResponseEntity<>(response, HttpStatus.UNAUTHORIZED);
	}

	@PostMapping("/ombudsmanservice/v1/casemanagement/assigncases")
	public ResponseEntity<CaseAssignmentRes> assignCases(@RequestBody @Valid AssignCasesReq request)
			throws SQLException, UnAuthorisedException, InvalidOrganisationException {
		appLogger.info("assignCases Controller Method Started. CorrelationId:-{} OID:-{}", userbean.getCorrelationId(),
				userbean.getUserObjectId());

		CaseAssignmentRes response = null;

		if ((userbean.getRoles().contains(CASEWORKER_ROLES) || userbean.getRoles().contains(SUPERVISOR_ROLES))
				&& validateUserSession.isValidSession()) {
			response = caseAssignmentService.assignCases(request);

			appLogger.info("End of assignCases Controller Method. CorrelationId:-{} OID:-{}",
					userbean.getCorrelationId(), userbean.getUserObjectId());

			return new ResponseEntity<>(response, HttpStatus.OK);
		}

		return new ResponseEntity<>(response, HttpStatus.UNAUTHORIZED);
	}

	@GetMapping(value = "/ombudsmanservice/v1/casemanagement/liveness")
	public ResponseEntity<GenericResponse> getLiveHealthCheck() {
		appLogger.info("Inside Liveness service");
		final GenericResponse result = new GenericResponse();
		result.setMessage(LocalDateTime.now().toString());
		result.setStatus("Available");
		appLogger.info("Liveness service available");
		return new ResponseEntity<>(result, HttpStatus.OK);
	}
	@GetMapping(value = "/ombudsmanservice/v1/casemanagement/readiness")
	public ResponseEntity<GenericResponse> getRedinessHealthCheck() {
		appLogger.info("Inside readiness service");
		final GenericResponse result = new GenericResponse();
		result.setMessage(LocalDateTime.now().toString());
		result.setStatus("Available");
		appLogger.info("Readiness service available");
		return new ResponseEntity<>(result, HttpStatus.OK);
	}

}
