package com.ombudsman.service.respondent.model.request;

public class CaseExportDownloadReq {
	private String requestingActivityName;
	private String userOid;

	public String getRequestingActivityName() {
		return requestingActivityName;
	}

	public void setRequestingActivityName(String requestingActivityName) {
		this.requestingActivityName = requestingActivityName;
	}

	public String getUserOid() {
		return userOid;
	}

	public void setUserOid(String userOid) {
		this.userOid = userOid;
	}
}
