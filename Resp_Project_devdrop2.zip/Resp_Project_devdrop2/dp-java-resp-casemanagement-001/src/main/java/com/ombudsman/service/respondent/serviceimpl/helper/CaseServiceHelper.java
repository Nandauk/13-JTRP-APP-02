package com.ombudsman.service.respondent.serviceimpl.helper;

import static com.ombudsman.service.respondent.common.Constants.ACCOUNT_ID;
import static com.ombudsman.service.respondent.common.Constants.BUSINESS_FILE_OVERDUE;
import static com.ombudsman.service.respondent.common.Constants.CASE_AGE;
import static com.ombudsman.service.respondent.common.Constants.CASE_OWNER;
import static com.ombudsman.service.respondent.common.Constants.CASE_PROGRESS;
import static com.ombudsman.service.respondent.common.Constants.CASE_STAGE;
import static com.ombudsman.service.respondent.common.Constants.COMPLAINANT_ISSUE;
import static com.ombudsman.service.respondent.common.Constants.EMAILID;
import static com.ombudsman.service.respondent.common.Constants.IS_OPEN_CASE;
import static com.ombudsman.service.respondent.common.Constants.LIVE_CASE_AGE;
import static com.ombudsman.service.respondent.common.Constants.OUTCOME_LAST_SEVENDAYS;
import static com.ombudsman.service.respondent.common.Constants.PAGE_COUNT;
import static com.ombudsman.service.respondent.common.Constants.PAGE_SIZE;
import static com.ombudsman.service.respondent.common.Constants.PERIORITY_CASE;
import static com.ombudsman.service.respondent.common.Constants.PRODUCT_TYPE;
import static com.ombudsman.service.respondent.common.Constants.RESOLVING_OUTCOME;
import static com.ombudsman.service.respondent.common.Constants.TRADE_NAME;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;

import com.ombudsman.service.respondent.exception.SQLDataAccessException;
import com.ombudsman.service.respondent.model.CaseFilterData;
import com.ombudsman.service.respondent.model.request.GetCasesByRespondentReq;
import com.ombudsman.service.respondent.service.repository.CaseListJdbcRepository;

@Configuration
public class CaseServiceHelper {
	private static final String AWAITINGACTIONFILTER = "awaitingactionfilter";
	private static final String TRUE = "true";
	private static final String RESULT_SET_1 = "#result-set-1";
	private static final String HASH = "#";
	private static final String COMMA = ",";
	Logger LOG =  LogManager.getRootLogger();
	@Autowired
	CaseListJdbcRepository caseListJdbcRepository;

	@SuppressWarnings("unchecked")
	public List<String> getAccountIds(String oid) throws SQLDataAccessException {		
		final Map<String, Object> accountIdsMap = caseListJdbcRepository.getOrganisationAccountIds(oid);		
		final List<Object> obj = (List<Object>) accountIdsMap.get(RESULT_SET_1);
		final List<String> accountList=new ArrayList<>();
		for(Object accountMap: obj) {			
			final Map<String,String> dd=(Map<String,String>)accountMap;
			accountList.add(dd.get("accountid"));
		}

		return accountList;
	}
	public Map<String, Object> getRequestData(final GetCasesByRespondentReq getOrganisationsReq) {
		LOG.debug("Request attributes caselist-{}", getOrganisationsReq);
		final Map<String, Object> data = new HashMap<>();
		data.put(PAGE_SIZE, getOrganisationsReq.getFilters().getPagesize());
		data.put(PAGE_COUNT, getOrganisationsReq.getFilters().getPage());
		data.put("fromdate", getDateForCaseList(getOrganisationsReq.getFilters().getStartdate()));
		data.put("todate", getDateForCaseList(getOrganisationsReq.getFilters().getEnddate()));
		data.put("sortby", getOrganisationsReq.getFilters().getSortby());
		data.put("sorttype", getOrganisationsReq.getFilters().getSorttype());
		data.put("searchby", getOrganisationsReq.getFilters().getSearchBy());
		data.put(IS_OPEN_CASE, TRUE.equalsIgnoreCase(getOrganisationsReq.getOpencasesonly())? 1:0);
		data.put(COMPLAINANT_ISSUE, getRequestValues(getOrganisationsReq.getFilters().getComplaintissue()));
		data.put(PRODUCT_TYPE, getRequestValues(getOrganisationsReq.getFilters().getProducttype()));
		data.put(CASE_STAGE, getRequestValues(getOrganisationsReq.getFilters().getCasestage()));
		data.put(TRADE_NAME, getRequestValues(getOrganisationsReq.getFilters().getTradingname()));
		data.put(CASE_OWNER, getRequestValues(getOrganisationsReq.getFilters().getCaseowner()));
		data.put(CASE_AGE, getRequestValues(getOrganisationsReq.getFilters().getCaseage()));
		data.put(PERIORITY_CASE, getRequestValues(getOrganisationsReq.getFilters().getPrioritycases()));
		data.put(LIVE_CASE_AGE, getRequestValues(getOrganisationsReq.getFilters().getAgecaseflag()));
		data.put(ACCOUNT_ID, getRequestValues(getOrganisationsReq.getFilters().getBusinessname()));
		data.put(RESOLVING_OUTCOME, getRequestValues(getOrganisationsReq.getFilters().getCloseroutcome()));
		data.put(AWAITINGACTIONFILTER, getRequestAwitingAction(getOrganisationsReq.getFilters().getAwaitingactionfilter()));
		data.put(EMAILID, getRequestValues(getOrganisationsReq.getFilters().getEmailid()));
		data.put(CASE_PROGRESS, getRequestValues(getOrganisationsReq.getFilters().getCaseprogress()));
		data.put(BUSINESS_FILE_OVERDUE, getRequestValues(getOrganisationsReq.getFilters().getBfileoverdue()));
		data.put(OUTCOME_LAST_SEVENDAYS, getRequestValues(getOrganisationsReq.getFilters().getOutcome7days()));
		return data;
	}

	private String getPriorityRequestValues(final List<CaseFilterData> caseData) {
		List<String> periorityCase = new ArrayList<>();
		if (CollectionUtils.isNotEmpty(caseData)) {
			caseData.forEach(i -> {
				if (i.getId().equalsIgnoreCase("1")) {
					periorityCase.add("140000001");
				}
				if (i.getId().equalsIgnoreCase("0")) {
					periorityCase.add("140000000");
				}

			});
			return String.join(COMMA, periorityCase);

		} else {
			return HASH;
		}
	}
	private String getRequestValues(final List<CaseFilterData> caseData) {

		if(caseData == null || caseData.isEmpty())return "#";
		return caseData.stream().filter(n -> n.getId() != null).map(CaseFilterData::getId)
				.collect(Collectors.joining(COMMA))
				.lines().findAny().orElse(HASH);
	}
	private String getRequestAwitingAction(final List<CaseFilterData> caseData) {
		return caseData.stream().filter(n -> n.getId() != null).map(CaseFilterData::getValue)
				.collect(Collectors.joining(COMMA))
				.lines().findAny().orElse(HASH);
	}
	
	private Date getDateForCaseList(final String stEndDate) {
		String pattern = "dd/MM/yyyy";
		SimpleDateFormat sdf = new SimpleDateFormat(pattern);
		try {
			if (StringUtils.isNotEmpty(stEndDate)) {
				return sdf.parse(stEndDate);
			} else {
				return sdf.parse("01/01/1900");
			}
		} catch (ParseException e) {
			LOG.error("Unable to parse the date::{}",
					e.getMessage());
		}
		return null;
	}




}
