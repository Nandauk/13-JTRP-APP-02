package com.ombudsman.service.respondent.exception;

public class CryptoServiceException extends RespondentsServiceExceptions {

	private static final long serialVersionUID = 1L;

	public CryptoServiceException(String message,String exceptionMessage) {
		super(message, "RESPONDENT_CRYPTO_1003",exceptionMessage);
	}
	
	
}
