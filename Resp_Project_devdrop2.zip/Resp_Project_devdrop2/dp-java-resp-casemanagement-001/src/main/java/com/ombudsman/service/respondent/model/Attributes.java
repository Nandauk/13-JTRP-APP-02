package com.ombudsman.service.respondent.model;

import java.util.List;

import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;

public class Attributes {

	@NotNull
	@NotEmpty
	private String opencasesonly;
	private List<String> organisations;
	private Filters filters;
	private UserData users;

	public UserData getUsers() {
		return users;
	}

	public void setUsers(UserData users) {
		this.users = users;
	}

	public Filters getFilters() {
		return filters;
	}

	public void setFilters(Filters filters) {
		this.filters = filters;
	}

	public String getOpencasesonly() {
		return opencasesonly;
	}

	public void setOpencasesonly(String opencasesonly) {
		this.opencasesonly = opencasesonly;
	}

	public List<String> getOrganisations() {
		return organisations;
	}

	public void setOrganisations(List<String> organisations) {
		this.organisations = organisations;
	}
}
