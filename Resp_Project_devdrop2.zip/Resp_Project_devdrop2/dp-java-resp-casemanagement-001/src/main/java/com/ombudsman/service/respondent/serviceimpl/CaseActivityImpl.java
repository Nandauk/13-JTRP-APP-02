package com.ombudsman.service.respondent.serviceimpl;

import java.time.OffsetDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Service;

import com.ombudsman.service.respondent.common.UserBean;
import com.ombudsman.service.respondent.common.WebClientData;
import com.ombudsman.service.respondent.exception.CaseManagementInvalidEventNameException;
import com.ombudsman.service.respondent.exception.RecordCreationException;
import com.ombudsman.service.respondent.model.ApiResponse;
import com.ombudsman.service.respondent.model.UpdateCase;
import com.ombudsman.service.respondent.model.dto.AuditMaster;
import com.ombudsman.service.respondent.model.dto.NotificationModel;
import com.ombudsman.service.respondent.model.dto.RequestModel;
import com.ombudsman.service.respondent.model.dto.UserEventConfiguration;
import com.ombudsman.service.respondent.service.CaseActivity;
import com.ombudsman.service.respondent.service.repository.AuditRepository;
import com.ombudsman.service.respondent.service.repository.RequestModelRepository;
import com.ombudsman.service.respondent.service.repository.UserEventConfigurationRepository;

@Service
public class CaseActivityImpl implements CaseActivity {

	private static final String API_ERROR_RECORD_CREATION_FAILED = "api.error.RecordCreationFailed";

	private static final Logger LOG = LoggerFactory.getLogger(CaseActivityImpl.class);

	@Autowired
	UserBean userbean;
	
	@Autowired
	AuditRepository auditMasterRepository;
	@Autowired
	private MessageSource messageSource;

	@Autowired
	UserEventConfigurationRepository userEventConfigurationRepository;

	@Autowired
	RequestModelRepository requestModelRepository;

	@Autowired
	WebClientData webClientData;

	@Value("${case_update_user_event_name}")
	public String userEventName;

	public String activity(UpdateCase dto, String ticketnumber) {
		ApiResponse response = new ApiResponse();

		UserEventConfiguration eventName = userEventConfigurationRepository.getUserEventRecord(userEventName);
		LOG.info("UserEventName:-{}", eventName.getUserEventName());

		if (!(eventName.getUserEventName().isBlank() && eventName.getUserEventName().isEmpty())) {
			postAuditEntries(response, eventName.getUserEventName());
		}

		// Updating data in Request Entity
		RequestModel request = new RequestModel();
		String id = requestEntity(request, requestModelRepository, dto, eventName.getUserEventName());
		LOG.info("id from Request extity from CaseUpdate : {}", id);

		if (id != null) {
			// Updating data in Notification Entity through Webclient
			NotificationModel notifyModel = new NotificationModel();

			try {
				notificationEntity(request, notifyModel, id, ticketnumber);
				webClientData.caseupdateNotificationWebclient(notifyModel);
				LOG.info("caseupdateNotificationWebclient successfully");

			} catch (Exception e) {

				request.setRequestStatusId(4);
				request.setRequestId(id);
				request.setRequestStatusDescription("Failed for Notification ");
				requestModelRepository.save(request);
				LOG.error("Notification Creation Failed. Please Try Again. {}", e.getMessage());
				throw new RecordCreationException("Record Creation Failed. Please Try Again.",
						messageSource.getMessage(API_ERROR_RECORD_CREATION_FAILED, null, Locale.ENGLISH));
			}
		}
		return id;
	}

	public void postAuditEntries(ApiResponse genericResponse, String userEventName) {
		LOG.info("getAuditEntries method started ");
		AuditMaster audit = new AuditMaster();
		try {

			audit.setUserOID(userbean.getUserObjectId());
			OffsetDateTime offsetdatetime = OffsetDateTime.now();
			audit.setAuditEventTimestamp(offsetdatetime);
			audit.setAuditEventName(userEventName);
			audit.setCreatedBy(userbean.getName());
			auditMasterRepository.save(audit);
			LOG.info("getAuditEntries method ended {}", audit);

		} catch (Exception e) {
			LOG.error("Invalid Event Name {}", e.getMessage());
			genericResponse.setMessage("Case Management Invalid Event Name ");
			throw new CaseManagementInvalidEventNameException("Case Management Invalid Event Name ",
					messageSource.getMessage("api.error.CaseManagementInvalidEventName", null, Locale.ENGLISH));

		}

	}

	private String requestEntity(RequestModel request, RequestModelRepository requestModelRepository,
			UpdateCase updatecase, String userEventName) {
		LOG.info("RequestEntity method started ");
		String requestId;

		try {
			request.setUserOid(userbean.getUserObjectId());
			request.setRequestingActivityName(userEventName);
			request.setRequestStatusId(1);
			request.setRequestStatusDescription("InProgress");
			request.setRequestProcessingDetails(updatecase.getComments().toString());
			OffsetDateTime offsetdatetime = OffsetDateTime.now();
			request.setRequestStartTime(offsetdatetime);
			request.setRequestProcessingCounter(0);
			request.setCreatedBy("dp-java-resp-casemanagement-001");
			request.setCreatedOn(offsetdatetime);

			requestModelRepository.save(request);
			requestId = request.getRequestId();
			LOG.info("RequestEntity method ended {}", requestId);

		} catch (Exception e) {
			request.setRequestStatusId(4);
			request.setRequestStatusDescription("Failed");
			LOG.info("Request Creation Failed. Please Try Again. {}", e.getMessage());
			throw new RecordCreationException("Record Creation Failed. Please Try Again. ",
					messageSource.getMessage(API_ERROR_RECORD_CREATION_FAILED, null, Locale.ENGLISH));
		}

		return requestId;
	}

	private void notificationEntity(RequestModel request, NotificationModel notifyModel, String id,
			String ticketnumber) {
		try {
			LOG.info("notificationEntity method started ");
			notifyModel.setRequest_id(id);
			notifyModel.setUser_oid(request.getUserOid());
			notifyModel.setRequesting_activity_name(request.getRequestingActivityName());
			notifyModel.setMessage(ticketnumber);
			notifyModel.setNotification_status_id("1");
			notifyModel.setNotification_status_description("Pending");
			notifyModel.setModified_by(request.getModifiedBy());
			notifyModel
					.setCreated_on(request.getCreatedOn().format(DateTimeFormatter.ofPattern("MM/dd/yyyy HH:mm:ss")));
			notifyModel.setCreated_by(request.getCreatedBy());
			notifyModel.setModified_on(request.getModifiedOn());
			LOG.info("notificationEntity method ended ");
		} catch (Exception e) {
			notifyModel.setNotification_status_id("4");
			notifyModel.setNotification_status_description("Expired");
			LOG.info("Setting data in Notification Failed. {}", e.getMessage());
			throw new RecordCreationException("Record Creation Failed. Please Try Again.",
					messageSource.getMessage(API_ERROR_RECORD_CREATION_FAILED, null, Locale.ENGLISH));
		}

	}
}
