package com.ombudsman.service.respondent.model.response;

import java.util.List;

import com.ombudsman.service.respondent.model.CaseOutcome;

public class CaseOutcomeByIdRes extends GenericResponse{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private List<CaseOutcome> caseoutcomes;
	
	public List<CaseOutcome> getCaseoutcomes() {
		return caseoutcomes;
	}
	public void setCaseoutcomes(List<CaseOutcome> caseoutcomes) {
		this.caseoutcomes = caseoutcomes;
	}

}
