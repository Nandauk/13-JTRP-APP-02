package com.ombudsman.service.respondent.model.response;
import java.util.List;

public class CaseworkerListByIdRes {
    private List<Caseworker> caseworkerList;
    String status;
    String message;
    

   
    public List<Caseworker> getCaseworkerList() {
        return caseworkerList;
    }

    public void setCaseworkerList(List<Caseworker> caseworkerList) {
        this.caseworkerList = caseworkerList;
    }
    
    public String getStatus() {
		return status;
		
	}

	public void setStatus(String status) {
		this.status = status;
		
	}
	public String getMessage() {
		
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
		
	}
	

	

 public static class Caseworker {
    private String name;
    private String email;
    private String OId;
    

   
    public Caseworker(String name, String email , String OId) {
        this.name = name;
        this.email = email;
        this.OId = OId;
    }

    
    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }
    public String getOId()
    {
    	return OId;
    }
}
}
