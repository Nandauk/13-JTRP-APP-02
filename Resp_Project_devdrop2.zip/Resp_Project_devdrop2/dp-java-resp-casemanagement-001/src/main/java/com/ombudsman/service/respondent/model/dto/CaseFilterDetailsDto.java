package com.ombudsman.service.respondent.model.dto;

import java.io.Serializable;

public class CaseFilterDetailsDto implements Serializable{

	private static final long serialVersionUID = 1L;
	public String getFilterType() {
		return filterType;
	}
	public void setFilterType(String filterType) {
		this.filterType = filterType;
	}
	public String getFilterValue() {
		return filterValue;
	}
	public void setFilterValue(String filterValue) {
		this.filterValue = filterValue;
	}
	public String getAccountId() {
		return accountId;
	}
	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}
	public CaseFilterDetailsDto(String filterType, String filterValue, String accountId) {
		this.setAccountId(accountId);
		this.setFilterType(filterType);
		this.setFilterValue(filterValue);
	}
	private String filterType;
	private String filterValue;
	private String accountId;

}
