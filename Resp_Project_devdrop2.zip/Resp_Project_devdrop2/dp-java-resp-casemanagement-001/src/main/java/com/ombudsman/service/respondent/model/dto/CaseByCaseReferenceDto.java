package com.ombudsman.service.respondent.model.dto;

import java.io.Serializable;

public class CaseByCaseReferenceDto implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public String incidentId;
	public String getIncidentId() {
		return incidentId;
	}
	public void setIncidentId(String incidentId) {
		this.incidentId = incidentId;
	}
	
	public CaseByCaseReferenceDto(String incidentId)
	{
		this.setIncidentId(incidentId);
	}
	
}

