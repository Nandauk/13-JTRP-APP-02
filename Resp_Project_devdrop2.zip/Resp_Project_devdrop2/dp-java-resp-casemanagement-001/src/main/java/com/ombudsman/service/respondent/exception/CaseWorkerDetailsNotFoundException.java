package com.ombudsman.service.respondent.exception;

public class CaseWorkerDetailsNotFoundException  extends RuntimeException {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public CaseWorkerDetailsNotFoundException(String exceptionMsg)
	{
		super(exceptionMsg);
	}


}
