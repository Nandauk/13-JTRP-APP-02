package com.ombudsman.service.respondent.repository.dao;

import java.util.List;
import java.util.Map;

import com.ombudsman.service.respondent.exception.SQLDataAccessException;
import com.ombudsman.service.respondent.model.dto.CaseByCaseReferenceDto;
import com.ombudsman.service.respondent.model.dto.CaseDetailDto;
import com.ombudsman.service.respondent.model.dto.CaseOutcomeDto;
import com.ombudsman.service.respondent.model.dto.CaseWorkerDto;

public interface CaseDetailsDao {

	List<CaseDetailDto> getCaseDetailsById(String incidentId, List<String> accIds) throws SQLDataAccessException;

	List<CaseOutcomeDto> getCaseOutcomeById(String incidentId, List<String> accIds) throws SQLDataAccessException;
 
	List<CaseWorkerDto> getCaseWorkerDetailsById(String incidentId, List<String> accIds) throws SQLDataAccessException;

	List<CaseByCaseReferenceDto> getCaseIncidentidByCaseReference(String ticketId, List<String> accIds)
			throws SQLDataAccessException;

	Map<String, Object> getOfferOutcomes(String incidentId) throws SQLDataAccessException;

	Integer chkIncidentAuthorized(String incidentId, List<String> accIds) throws SQLDataAccessException;

	Map<String, Object> getCaseParties(String incidentId, List<String> accIds) throws SQLDataAccessException;
}
