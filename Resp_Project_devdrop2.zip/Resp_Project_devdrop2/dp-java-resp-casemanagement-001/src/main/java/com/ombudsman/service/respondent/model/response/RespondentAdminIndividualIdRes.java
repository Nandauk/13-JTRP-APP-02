package com.ombudsman.service.respondent.model.response;

public class RespondentAdminIndividualIdRes extends GenericResponse{
	
	private String isAdminUser;
	private String contactId;
	private String digitalPortalUserName;
	private String digitalPortalUserEmailAddress;
	

	public String getIsAdminUser() {
		return isAdminUser;
	}
	public void setIsAdminUser(String isAdminUser) {
		this.isAdminUser = isAdminUser;
	}
	public String getContactId() {
		return contactId;
	}
	public void setContactId(String contactId) {
		this.contactId = contactId;
	}
	public String getDigitalPortalUserName() {
		return digitalPortalUserName;
	}
	public void setDigitalPortalUserName(String digitalPortalUserName) {
		this.digitalPortalUserName = digitalPortalUserName;
	}
	public String getDigitalPortalUserEmailAddress() {
		return digitalPortalUserEmailAddress;
	}
	public void setDigitalPortalUserEmailAddress(String digitalPortalUserEmailAddress) {
		this.digitalPortalUserEmailAddress = digitalPortalUserEmailAddress;
	}
}
