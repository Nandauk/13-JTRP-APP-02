package com.ombudsman.service.respondent.model.dto;

public class NotificationModelDto {
	private NotificationModel notificationModel;
	private boolean sessionflag;

	public NotificationModel getNotificationModel() {
		return notificationModel;
	}

	public void setNotificationModel(NotificationModel notificationModel) {
		this.notificationModel = notificationModel;
	}

	public boolean isSessionflag() {
		return sessionflag;
	}

	public void setSessionflag(boolean sessionflag) {
		this.sessionflag = sessionflag;
	}

}
