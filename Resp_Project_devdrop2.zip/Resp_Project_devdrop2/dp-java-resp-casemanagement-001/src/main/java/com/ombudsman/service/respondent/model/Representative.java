package com.ombudsman.service.respondent.model;

public class Representative extends Complainant{

    private String representativeType;
    private String organisation;
    private String referenace;
    private String contactid;
   
	public String getRepresentativeType() {
		return representativeType;
	}
	public void setRepresentativeType(String representativeType) {
		this.representativeType = representativeType;
	}
	public String getOrganisation() {
		return organisation;
	}
	public void setOrganisation(String organisation) {
		this.organisation = organisation;
	}
	public String getContactid() {
		return contactid;
	}
	public void setContactid(String contactid) {
		this.contactid = contactid;
	}
	public String getReferenace() {
		return referenace;
	}
	public void setReferenace(String referenace) {
		this.referenace = referenace;
	}
    
	
}
