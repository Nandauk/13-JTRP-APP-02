package com.ombudsman.service.respondent.model.dto;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Entity
@Table(name = "dp_user_notification")
@Data
public class NotificationModel {

	@Id
	@Column(name = "notification_id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long notification_id;

	private String request_id;

	public Long getNotification_id() {
		return notification_id;
	}

	public void setNotification_id(Long notification_id) {
		this.notification_id = notification_id;
	}

	public String getRequest_id() {
		return request_id;
	}

	public void setRequest_id(String request_id) {
		this.request_id = request_id;
	}

	public String getUser_oid() {
		return user_oid;
	}

	public void setUser_oid(String user_oid) {
		this.user_oid = user_oid;
	}

	public String getRequesting_activity_name() {
		return requesting_activity_name;
	}

	public void setRequesting_activity_name(String requesting_activity_name) {
		this.requesting_activity_name = requesting_activity_name;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getNotification_status_id() {
		return notification_status_id;
	}

	public void setNotification_status_id(String notification_status_id) {
		this.notification_status_id = notification_status_id;
	}

	public String getNotification_status_description() {
		return notification_status_description;
	}

	public void setNotification_status_description(String notification_status_description) {
		this.notification_status_description = notification_status_description;
	}

	public String getFile_download_url() {
		return file_download_url;
	}

	public void setFile_download_url(String file_download_url) {
		this.file_download_url = file_download_url;
	}

	public String getModified_by() {
		return modified_by;
	}

	public void setModified_by(String modified_by) {
		this.modified_by = modified_by;
	}

	public String getCreated_on() {
		return created_on;
	}

	public void setCreated_on(String created_on) {
		this.created_on = created_on;
	}

	public String getCreated_by() {
		return created_by;
	}

	public void setCreated_by(String created_by) {
		this.created_by = created_by;
	}

	public String getModified_on() {
		return modified_on;
	}

	public void setModified_on(String modified_on) {
		this.modified_on = modified_on;
	}

	private String user_oid;
	private String requesting_activity_name;
	private String message;
	private String notification_status_id;
	private String notification_status_description;

	private String file_download_url;

	private String modified_by;

	private String created_on;

	private String created_by;

	private String modified_on;



}
