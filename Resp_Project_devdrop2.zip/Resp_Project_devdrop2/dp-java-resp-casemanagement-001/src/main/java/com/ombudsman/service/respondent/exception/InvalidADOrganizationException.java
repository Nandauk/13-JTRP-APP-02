package com.ombudsman.service.respondent.exception;

public class InvalidADOrganizationException extends RespondentsServiceExceptions {

	private static final long serialVersionUID = 1L;

	public InvalidADOrganizationException(String message, String exceptionMessage) {
		super(message, "RESPONDENT_INVALID_AD_ORG_1000", exceptionMessage);
	}

}
