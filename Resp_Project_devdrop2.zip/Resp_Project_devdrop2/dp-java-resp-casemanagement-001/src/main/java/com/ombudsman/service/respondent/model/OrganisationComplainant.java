package com.ombudsman.service.respondent.model;

import java.util.List;

public class OrganisationComplainant extends GenericCaseLinkAndOrganisation{
	
	private String fos_organisationid;
	private String name;
	private String busines_scharity_trust;
	private String contactnumber;
	private String address;
	private List<Complainant> members;
	

	public String getFos_organisationid() {
		return fos_organisationid;
	}
	public void setFos_organisationid(String fos_organisationid) {
		this.fos_organisationid = fos_organisationid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getBusines_scharity_trust() {
		return busines_scharity_trust;
	}
	public void setBusines_scharity_trust(String busines_scharity_trust) {
		this.busines_scharity_trust = busines_scharity_trust;
	}
	public List<Complainant> getMembers() {
		return members;
	}
	public void setMembers(List<Complainant> members) {
		this.members = members;
	}
	public String getContactnumber() {
		return contactnumber;
	}
	public void setContactnumber(String contactnumber) {
		this.contactnumber = contactnumber;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}

}
