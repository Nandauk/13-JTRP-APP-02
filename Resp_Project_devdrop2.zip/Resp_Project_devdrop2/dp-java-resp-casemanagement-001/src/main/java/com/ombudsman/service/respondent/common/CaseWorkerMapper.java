package com.ombudsman.service.respondent.common;

import org.mapstruct.BeforeMapping;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import com.ombudsman.service.respondent.model.CaseWorker;
import com.ombudsman.service.respondent.model.dto.CaseWorkerDto;

@Mapper(componentModel = "spring")
public interface CaseWorkerMapper {
	CaseWorkerMapper INSTANCE = Mappers.getMapper(CaseWorkerMapper.class);

	
	  @BeforeMapping 
	  private void owningUsermapping(CaseWorkerDto caseDtoObj,CaseWorker caseObj) 
	  { 
		  if(caseDtoObj.get_owninguser_value()!= null)
		  	{ 
			  caseObj.set_owninguser_value(caseDtoObj.get_owninguser_value());
			  caseObj.setFullname(caseDtoObj.getFullname());
			  caseObj.setAddress1_telephone1(caseDtoObj.getAddress1_telephone1());
			  caseObj.setInternalemailaddress(caseDtoObj.getInternalemailaddress()); 
			 }
		  else
		  { 
			  caseObj.setTitle(caseDtoObj.getTitle());
			  caseObj.setFullname(caseDtoObj.getCwFullname());
			  caseObj.setAddress1_telephone1(caseDtoObj.getCwAdddress1_telephone1());
			  caseObj.setInternalemailaddress(caseDtoObj.getCwInternalemailaddress());
		  } 
	 }
		 

	
	/*
	 * @Mapping(source = "fullname", target = "fullname")
	 * 
	 * @Mapping(source = "title", target = "title")
	 * 
	 * @Mapping(source = "address1_telephone1", target = "address1_telephone1")
	 * 
	 * @Mapping(source = "internalemailaddress", target = "internalemailaddress")
	 */
	 
	CaseWorker caseWorkerLst(CaseWorkerDto caseWorkerDto);

}
