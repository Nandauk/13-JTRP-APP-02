package com.ombudsman.service.respondent.model.request;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.nimbusds.jose.shaded.gson.annotations.SerializedName;
import com.ombudsman.service.respondent.model.IncidentInfo;

public class BulkCaseUpdateRequest {

	//Coming from UI
	@JsonProperty("field_dp_x_numberOfCases")
	private List<NumberOfCases> numberOfCases;
	@SerializedName("details")
	private String details;
	@SerializedName("reasonForChange")
	private Long reasonForChange;
	
	//we will add in request inside service layer which then sent to service bus
	private String userId;
    private List<String> usersAccountIds;
    private String packageIdReq;
    private Integer templateId;
    

	public Integer getTemplateId() {
		return templateId;
	}
	public void setTemplateId(Integer templateId) {
		this.templateId = templateId;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public List<String> getUsersAccountIds() {
		return usersAccountIds;
	}
	public void setUsersAccountIds(List<String> usersAccountIds) {
		this.usersAccountIds = usersAccountIds;
	}
	public String getPackageIdReq() {
		return packageIdReq;
	}
	public void setPackageIdReq(String packageIdReq) {
		this.packageIdReq = packageIdReq;
	}
	
	public Long getReasonForChange() {
		return reasonForChange;
	}
	
	public List<NumberOfCases> getNumberOfCases() {
		return numberOfCases;
	}
	public void setNumberOfCases(List<NumberOfCases> numberOfCases) {
		this.numberOfCases = numberOfCases;
	}
	public void setReasonForChange(Long reasonForChange) {
		this.reasonForChange = reasonForChange;
	}
	public String getDetails() {
		return details;
	}
	public void setDetails(String details) {
		this.details = details;
	}
	
	public static class NumberOfCases  {
		
		@SerializedName("comment")
		private String comment;
		@SerializedName("caseId")
		private String caseId;
		
		public String getComment() {
			return comment;
		}
		public void setComment(String comment) {
			this.comment = comment;
		}
		public String getCaseId() {
			return caseId;
		}
		public void setCaseId(String caseId) {
			this.caseId = caseId;
		}
		
		
	}
	
}

