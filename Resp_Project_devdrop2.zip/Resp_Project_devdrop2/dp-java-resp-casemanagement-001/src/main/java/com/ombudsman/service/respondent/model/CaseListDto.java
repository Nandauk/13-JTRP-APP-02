package com.ombudsman.service.respondent.model;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import org.apache.commons.lang3.StringUtils;

import com.ombudsman.service.respondent.exception.CaseOutComesNotFoundException;

public class CaseListDto implements Serializable {

	private static final String NA = "NA";
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String incidentid; // Primary Key
	private String ticketnumber; // Case Reference - incident
	private String fos_crn; // Migrated Reference - incident
	private String customerid; // _customerid_value - incident (organisation account id)
	private String businessname; // Business Name, _customerid_value -
									// "_customerid_value@OData.Community.Display.V1.FormattedValue":"AXA Insurance
									// UK Plc"
	private String fos_reference; // Business Reference - fos_reference, fos_extendedreference - fos_caselink
	private String fos_extendedreference; // Business Reference - fos_reference, fos_extendedreference - fos_caselink
	private String fos_complaintissue; // Complaint Issue - incident
	private String fos_complaintissuename; // fos_complaintissue_value@OData.Community.Display.V1.FormattedValue":"Breach
											// of Confidentiality"
	private String fos_productorproductfamily; // Product Type - fos_productorproductfamily - incident
	private String fos_productorproductfamilyname; // "_fos_productorproductfamily_value@OData.Community.Display.V1.FormattedValue":"Balance
													// Transfers"
	private String fos_casestage; // Case Stage - incident
	private String fos_casestagename; // Case Stage -
										// fos_casestage@OData.Community.Display.V1.FormattedValue":"Investigation"
	private String statuscode; // Case Status - incident
	private String fos_dateofreferral; // Enquiry Date - incident

	private String agecaseflag;
	private String fos_representatives; // Professional Representative Name - incident
	private String fos_datecasefirstmovedtoinvestigation; // Conversion Date - incident
	private String fos_dateofconversion; // Fix added DPSP-685
	private String fos_datebusinessfilereceived; // Business File Received Date - incident
	private String fos_dispatcheddate; // Last View Date - letter
	private String fos_type; // Last View OutCome - fos_offeroutcome
	private String fos_oldercasestatus; // Live 12 month case - incident
	private String fos_caseworker; // FOS case owner once allocated - incident
	private String fos_individualid; // Respondent case owner - fos_caselink
	private String caseagebanding; // Case age banding - incident
	private String caseagebandingid;
	private String noofefile; // TBC
	private String noofcorrespondet; // TBC
	private String fos_dateofevent; // Event Date - incident
	private String vulnerable; // TBC
	private String fos_dateoffinalresponse; // Final Response Date - incident
	private String fos_offeroutcome; // Closure date - fos_offeroutcome
	private String fos_changeinoutcome; // Closure outcome fos_changeinoutcome - fos_offeroutcome
	private String fos_changeinoutcomename;
	private String deadlockcases; // Dedlock Case Date - fos_datecasefirstmovedtoinvestigation - incident
	private String fos_tradingname; // Trading Name - caselink
	private String fos_tradingnamename;
	private String fos_prioritycode; // Priority Code - incident
	private String fos_prioritycodename;
	private String owninguser;
	private String description;
	private String br_required; // 14+ Conversion Date
	private String statecode;
	private String awaitingaction;
	private String fos_caselinkid;
	private String fos_resolvingoutcomeid;

	private String statuscodename;
	private String awaitingactionfilter;
	private String fos_individualidname;
	private String fos_typename;

	
	
	
	private String emailid;


	public String getEmailid() {
		return emailid;
	}

	public void setEmailid(String emailid) {
		this.emailid = emailid;
	}

	private String fos_caseprogress;
	private String fos_caseprogress_name;


	public String getFos_representatives() {
		return fos_representatives;
	}

	public void setFos_representatives(String fos_representatives) {
		this.fos_representatives = fos_representatives;
	}

	public String getFos_individualidname() {
		return fos_individualidname;
	}

	public void setFos_individualidname(String fos_individualidname) {
		this.fos_individualidname = fos_individualidname;
	}

	public String getFos_typename() {
		return fos_typename;
	}

	public void setFos_typename(String fos_typename) {
		this.fos_typename = fos_typename;
	}

	public String getFos_resolvingoutcomeid() {
		return fos_resolvingoutcomeid;
	}

	public void setFos_resolvingoutcomeid(String fos_resolvingoutcomeid) {
		this.fos_resolvingoutcomeid = fos_resolvingoutcomeid;
	}

	private String fos_outcomedispatcheddate;

	public String getFos_outcomedispatcheddate() {
		return fos_outcomedispatcheddate;
	}

	public void setFos_outcomedispatcheddate(String fos_outcomedispatcheddate) {
		this.fos_outcomedispatcheddate = datetimeformate(fos_outcomedispatcheddate);
	}

	public String getAwaitingactionfilter() {
		return awaitingactionfilter;
	}

	public void setAwaitingactionfilter(String awaitingactionfilter) {
		this.awaitingactionfilter = awaitingactionfilter;
	}

	public String getStatuscodename() {
		return statuscodename;
	}

	public void setStatuscodename(String statuscodename) {
		this.statuscodename = statuscodename;
	}

	public String getFos_caselinkid() {
		return fos_caselinkid;
	}

	public void setFos_caselinkid(String fos_caselinkid) {
		this.fos_caselinkid = fos_caselinkid;
	}

	public String getIncidentid() {
		return incidentid;
	}

	public void setIncidentid(String incidentid) {
		this.incidentid = incidentid;
	}

	public String getTicketnumber() {
		return ticketnumber;
	}

	public void setTicketnumber(String ticketnumber) {
		this.ticketnumber = ticketnumber;
	}

	public String getFos_crn() {
		return fos_crn;
	}

	public void setFos_crn(String fos_crn) {
		this.fos_crn = fos_crn;
	}

	public String getCustomerid() {
		return customerid;
	}

	public void setCustomerid(String customerid) {
		this.customerid = customerid;
	}

	public String getBusinessname() {
		return businessname;
	}

	public void setBusinessname(String businessname) {
		this.businessname = businessname;
	}

	public String getFos_reference() {
		return fos_reference;
	}

	public void setFos_reference(String fos_reference) {
		this.fos_reference = fos_reference;
	}

	public String getFos_extendedreference() {
		return fos_extendedreference;
	}

	public void setFos_extendedreference(String fos_extendedreference) {
		this.fos_extendedreference = fos_extendedreference;
	}

	public String getFos_complaintissue() {
		return fos_complaintissue;
	}

	public void setFos_complaintissue(String fos_complaintissue) {
		this.fos_complaintissue = fos_complaintissue;
	}

	public String getFos_complaintissuename() {
		return fos_complaintissuename;
	}

	public void setFos_complaintissuename(String fos_complaintissuename) {
		this.fos_complaintissuename = fos_complaintissuename;
	}

	public String getFos_productorproductfamily() {
		return fos_productorproductfamily;
	}

	public void setFos_productorproductfamily(String fos_productorproductfamily) {
		this.fos_productorproductfamily = fos_productorproductfamily;
	}

	public String getFos_productorproductfamilyname() {
		return fos_productorproductfamilyname;
	}

	public void setFos_productorproductfamilyname(String fos_productorproductfamilyname) {
		this.fos_productorproductfamilyname = fos_productorproductfamilyname;
	}

	public String getFos_casestage() {
		return fos_casestage;
	}

	public void setFos_casestage(String fos_casestage) {
		this.fos_casestage = fos_casestage;
	}

	public String getFos_casestagename() {
		return fos_casestagename;
	}

	public void setFos_casestagename(String fos_casestagename) {
		this.fos_casestagename = fos_casestagename;
	}

	public String getStatuscode() {
		return statuscode;
	}

	public void setStatuscode(String statuscode) {
		this.statuscode = statuscode;
	}

	public String getFos_dateofreferral() {
		return fos_dateofreferral;
	}

	public void setFos_dateofreferral(String fos_dateofreferral) {
		this.fos_dateofreferral = datetimeformate(fos_dateofreferral);

	}

	public String getAgecaseflag() {
		return agecaseflag;
	}

	public void setAgecaseflag(String agecaseflag) {
		this.agecaseflag = agecaseflag;
	}

	public String getFos_datecasefirstmovedtoinvestigation() {
		return fos_datecasefirstmovedtoinvestigation;
	}

	public void setFos_datecasefirstmovedtoinvestigation(String fos_datecasefirstmovedtoinvestigation) {
		this.fos_datecasefirstmovedtoinvestigation = datetimeformate(fos_datecasefirstmovedtoinvestigation);;

	}

	public String getFos_dateofconversion() {
		return fos_dateofconversion;
	}

	public void setFos_dateofconversion(String fos_dateofconversion) {
		this.fos_dateofconversion = datetimeformate(fos_dateofconversion);

	}

	public String getFos_datebusinessfilereceived() {
		return fos_datebusinessfilereceived;
	}

	public void setFos_datebusinessfilereceived(String fos_datebusinessfilereceived) {
		this.fos_datebusinessfilereceived = datetimeformate(fos_datebusinessfilereceived);

	}

	public String getFos_dispatcheddate() {
		return fos_dispatcheddate;
	}

	public void setFos_dispatcheddate(String fos_dispatcheddate) {
		this.fos_dispatcheddate = fos_dispatcheddate;

	}

	public String getFos_type() {
		return fos_type;
	}

	public void setFos_type(String fos_type) {
		this.fos_type = fos_type;
	}

	public String getFos_oldercasestatus() {
		return fos_oldercasestatus;
	}

	public void setFos_oldercasestatus(String fos_oldercasestatus) {
		this.fos_oldercasestatus = fos_oldercasestatus;
	}

	public String getFos_caseworker() {
		return fos_caseworker;
	}

	public void setFos_caseworker(String fos_caseworker) {
		this.fos_caseworker = fos_caseworker;
	}

	public String getFos_individualid() {
		return fos_individualid;
	}

	public void setFos_individualid(String fos_individualid) {
		this.fos_individualid = fos_individualid;
	}

	public String getCaseagebanding() {
		return caseagebanding;
	}

	public void setCaseagebanding(String caseagebanding) {
		this.caseagebanding = caseagebanding;
	}

	public String getCaseagebandingid() {
		return caseagebandingid;
	}

	public void setCaseagebandingid(String caseagebandingid) {
		this.caseagebandingid = caseagebandingid;
	}

	public String getNoofefile() {
		return noofefile;
	}

	public void setNoofefile(String noofefile) {
		this.noofefile = noofefile;
	}

	public String getNoofcorrespondet() {
		return noofcorrespondet;
	}

	public void setNoofcorrespondet(String noofcorrespondet) {
		this.noofcorrespondet = noofcorrespondet;
	}

	public String getFos_dateofevent() {
		return fos_dateofevent;
	}

	public void setFos_dateofevent(String fos_dateofevent) {
		this.fos_dateofevent = datetimeformate(fos_dateofevent);

	}

	public String getVulnerable() {
		return vulnerable;
	}

	public void setVulnerable(String vulnerable) {
		this.vulnerable = vulnerable;
	}

	public String getFos_dateoffinalresponse() {
		return fos_dateoffinalresponse;
	}

	public void setFos_dateoffinalresponse(String fos_dateoffinalresponse) {
		this.fos_dateoffinalresponse = datetimeformate(fos_dateoffinalresponse);

	}

	public String getFos_offeroutcome() {
		return fos_offeroutcome;
	}

	public void setFos_offeroutcome(String fos_offeroutcome) {
		this.fos_offeroutcome = datetimeformate(fos_offeroutcome);
	}

	public String getFos_changeinoutcome() {
		return fos_changeinoutcome;
	}

	public void setFos_changeinoutcome(String fos_changeinoutcome) {
		this.fos_changeinoutcome = fos_changeinoutcome;
	}

	public String getFos_changeinoutcomename() {
		return fos_changeinoutcomename;
	}

	public void setFos_changeinoutcomename(String fos_changeinoutcomename) {
		this.fos_changeinoutcomename = fos_changeinoutcomename;
	}

	public String getDeadlockcases() {
		return deadlockcases;
	}

	public void setDeadlockcases(String deadlockcases) {
		this.deadlockcases = deadlockcases;
	}

	public String getFos_tradingname() {
		return fos_tradingname;
	}

	public void setFos_tradingname(String fos_tradingname) {
		this.fos_tradingname = fos_tradingname;
	}

	public String getFos_tradingnamename() {
		return fos_tradingnamename;
	}

	public void setFos_tradingnamename(String fos_tradingnamename) {
		this.fos_tradingnamename = fos_tradingnamename;
	}

	public String getFos_prioritycode() {
		return fos_prioritycode;
	}

	public void setFos_prioritycode(String fos_prioritycode) {
		this.fos_prioritycode = fos_prioritycode;
	}

	public String getFos_prioritycodename() {
		return fos_prioritycodename;
	}

	public void setFos_prioritycodename(String fos_prioritycodename) {
		this.fos_prioritycodename = fos_prioritycodename;
	}

	public String getOwninguser() {
		return owninguser;
	}

	public void setOwninguser(String owninguser) {
		this.owninguser = owninguser;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getBr_required() {
		return br_required;
	}

	public void setBr_required(String br_required) {
		this.br_required = datetimeformate(br_required);

	}

	public String getStatecode() {
		return statecode;
	}

	public void setStatecode(String statecode) {
		this.statecode = statecode;
	}

	public String getAwaitingaction() {
		return awaitingaction;
	}

	public void setAwaitingaction(String awaitingaction) {
		this.awaitingaction = awaitingaction;
	}

	public String getFos_caseprogress() {
		return fos_caseprogress;
	}

	public void setFos_caseprogress(String fos_caseprogress) {
		this.fos_caseprogress = fos_caseprogress;
	}



	public String getFos_caseprogress_name() {
		return fos_caseprogress_name;
	}

	public void setFos_caseprogress_name(String fos_caseprogress_name) {
		if (null != fos_caseprogress_name && NA.equalsIgnoreCase(fos_caseprogress_name)) {
			this.fos_caseprogress_name = StringUtils.EMPTY;
		} else {
			this.fos_caseprogress_name = fos_caseprogress_name;
		}
	}
	
	public String datetimeformate(String date) {
		if (date != null) {
			try {
				LocalDateTime localDateTime = LocalDateTime.parse(date,DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSSSSSS"));
				return localDateTime.format(DateTimeFormatter.ofPattern("MM/dd/yyyy hh:mm:ss a"));
			} catch (Exception e) {
				throw new CaseOutComesNotFoundException("Datetime convertion error");
			}
		} else {
			return null;
		}
	}

	
}
