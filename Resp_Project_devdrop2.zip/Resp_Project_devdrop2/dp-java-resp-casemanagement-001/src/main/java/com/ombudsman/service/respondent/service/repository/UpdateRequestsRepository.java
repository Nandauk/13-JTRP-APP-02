package com.ombudsman.service.respondent.service.repository;

import java.util.List;

import org.springframework.dao.DataAccessException;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.ombudsman.service.respondent.model.IncidentInfo;
import com.ombudsman.service.respondent.model.dto.UpdateCaseDto;


@Repository
public interface UpdateRequestsRepository extends JpaRepository<UpdateCaseDto, Integer> {
	
	@Query(value = "EXEC prc_getUserAccountId ?", nativeQuery = true)
	List<String> getAccountId(@Param("accountids") String accountids) ;
	
	//SP for authorization
	@Query(value = "exec dbo.prc_oidIncActValidation :userOid,:caseIds", nativeQuery = true)
	List<Object[]> validateOrg(@Param("userOid") String userOid,@Param("caseIds") String caseIds) ;
	
	@Query(value = "SELECT COUNT(incidentid) as incidentid,ticketnumber  FROM incident WHERE incidentid =:incidentid AND customerid IN :customerid GROUP BY ticketnumber", nativeQuery = true)// return count 
		IncidentInfo getIncident(@Param("incidentid") String incidentid, @Param("customerid") List<String> customerid);
}