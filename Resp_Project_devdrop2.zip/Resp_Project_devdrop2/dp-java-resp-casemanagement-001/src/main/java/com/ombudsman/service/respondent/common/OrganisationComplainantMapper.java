package com.ombudsman.service.respondent.common;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;


import com.ombudsman.service.respondent.model.OrganisationComplainant;
import com.ombudsman.service.respondent.model.dto.OrganisationComplainantDto;

@Mapper(componentModel = "spring")
public interface OrganisationComplainantMapper {
	OrganisationComplainantMapper INSTANCE = Mappers.getMapper(OrganisationComplainantMapper.class);
	
	@Mapping(source = "fos_numberofemployees", target = "fos_numberofemployees")
	@Mapping(source = "fos_numberofpartners", target = "fos_numberofpartners")
	@Mapping(source = "fos_annualturnover", target = "fos_annualturnover")
	@Mapping(source = "fos_balancesheet", target = "fos_balancesheet")
	@Mapping(source = "fos_islinkedorpartnered", target = "fos_islinkedorpartnered")
	@Mapping(source = "fos_annualincome", target = "fos_annualincome")
	//@Mapping(source = "fos_annualturnover_txt", target = "telephone2")
	@Mapping(source = "fos_netassets", target = "fos_netassets")
	@Mapping(source = "businesstypecode", target = "fos_businesstypecode")	
	@Mapping(source = "fos_preferredemailaddress", target = "_fos_preferredemailaddress_value")
	@Mapping(source = "fos_organisationid", target = "fos_organisationid")
	OrganisationComplainant organisationComplainantDtls(OrganisationComplainantDto organisationComplainantDto ) ;
}
