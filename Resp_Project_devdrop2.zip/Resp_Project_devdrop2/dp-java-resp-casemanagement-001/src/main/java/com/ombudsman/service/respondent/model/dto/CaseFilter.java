package com.ombudsman.service.respondent.model.dto;

import java.io.Serializable;



public interface CaseFilter extends Serializable{
	public String getFilterType();
	public String getFilterValue();
	public String getAccountId();

}
