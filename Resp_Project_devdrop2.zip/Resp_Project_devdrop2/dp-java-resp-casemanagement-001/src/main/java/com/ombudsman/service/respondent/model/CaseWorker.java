package com.ombudsman.service.respondent.model;

public class CaseWorker {
	
	private String ticketnumber;
	private String _fos_caseworker_value;
	private String _owninguser_value;
	private String fullname;
	private String title;
	private String firstname;
	private String lastname;
	private String address1_telephone1;
	private String internalemailaddress;
	
	public String getTicketnumber() {
		return ticketnumber;
	}
	public void setTicketnumber(String ticketnumber) {
		this.ticketnumber = ticketnumber;
	}
	public String getFullname() {
		return fullname;
	}
	public void setFullname(String fullname) {
		this.fullname = fullname;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public String getAddress1_telephone1() {
		return address1_telephone1;
	}
	public void setAddress1_telephone1(String address1_telephone1) {
		this.address1_telephone1 = address1_telephone1;
	}
	public String getInternalemailaddress() {
		return internalemailaddress;
	}
	public void setInternalemailaddress(String internalemailaddress) {
		this.internalemailaddress = internalemailaddress;
	}
	public String get_fos_caseworker_value() {
		return _fos_caseworker_value;
	}
	public void set_fos_caseworker_value(String _fos_caseworker_value) {
		this._fos_caseworker_value = _fos_caseworker_value;
	}
	public String get_owninguser_value() {
		return _owninguser_value;
	}
	public void set_owninguser_value(String _owninguser_value) {
		this._owninguser_value = _owninguser_value;
	}


}
