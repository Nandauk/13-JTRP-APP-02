package com.ombudsman.service.respondent.repository.daoimpl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.security.auth.login.AccountNotFoundException;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ombudsman.service.respondent.common.UserBean;
import com.ombudsman.service.respondent.exception.OrganizationNotFoundException;
import com.ombudsman.service.respondent.exception.SQLDataAccessException;
import com.ombudsman.service.respondent.model.dto.CaseFilterDetailsDto;
import com.ombudsman.service.respondent.model.dto.CaseOwnerCountProjectionDto;
import com.ombudsman.service.respondent.model.dto.OrganizationDto;
import com.ombudsman.service.respondent.repository.dao.ICaseListDao;
import com.ombudsman.service.respondent.service.repository.CaseListJdbcRepository;
import com.ombudsman.service.respondent.serviceimpl.helper.CaseServiceHelper;
@Component
public class CaseListDaoImpl implements ICaseListDao {
	Logger log = LogManager.getRootLogger();	
	private static final String BUSINESS_NAME = "businessname";
	private static final String ACCOUNT_IDS = "accountids";
	

	@Autowired
	CaseServiceHelper caseServiceHelper;

	@Autowired
	CaseListJdbcRepository caseListJdbcRepository;
	@Autowired
	UserBean userbean;


	@Override
	public List<CaseFilterDetailsDto> getCaseFilter(String oid)
	        throws SQLDataAccessException, OrganizationNotFoundException, AccountNotFoundException {
	    final String methodName = "getCaseFilter";

	    List<CaseFilterDetailsDto> filterDataOrg = null;
	    List<CaseFilterDetailsDto> caseFilterData = null;
	    List<CaseFilterDetailsDto> caseOwnerData = null;

	    final List<String> accIds = caseServiceHelper.getAccountIds(oid);

	    log.info(methodName, String.format("::Account ids from database:: %s", accIds));

	    if (CollectionUtils.isNotEmpty(accIds)) {
	        
	        caseFilterData = caseListJdbcRepository.getCaseFilter(accIds);

	      
	        final List<OrganizationDto> orgName = Optional.ofNullable(accIds)
	                .map(i -> caseListJdbcRepository.getFindOrganizationName(accIds))
	                .orElseThrow(() -> new AccountNotFoundException("No account found"));

			/*
			 * if (CollectionUtils.isNotEmpty(orgName)) { filterDataOrg = orgName.stream()
			 * .map(i -> new CaseFilterDetailsDto(BUSINESS_NAME, i.getOrganizationName(),
			 * i.getOrganizationId())) .collect(Collectors.toList()); } else { throw new
			 * OrganizationNotFoundException("Organization not found"); }
			 */

	        
	        final List<CaseOwnerCountProjectionDto> caseOwners = caseListJdbcRepository.getCaseOwnerCountSQL(String.join(",", accIds));

	        if (CollectionUtils.isNotEmpty(caseOwners)) {
	            caseOwnerData = caseOwners.stream()
	                    .map(i -> new CaseFilterDetailsDto("caseowner", i.getOwnername(),i.getEmailAddress()))
	                    .collect(Collectors.toList());
	        }

	       
	        if (caseFilterData == null) {
	            caseFilterData = new ArrayList<>();
	        }
	     //   caseFilterData.addAll(filterDataOrg);
	        if (caseOwnerData != null) {
	            caseFilterData.addAll(caseOwnerData);
	        }

	        
	    }

	    return caseFilterData;
	}

	@Override	
	public Map<String, Object> getCasesByRespondent(final Map<String, Object> reqParam, String oid) throws SQLDataAccessException {

		Map<String, Object> caseList = null;		
		@SuppressWarnings("unchecked")
		final List<String> accIds = caseServiceHelper.getAccountIds(oid);
		log.info(String.format("accountIds returns  from store procedure :: %s", accIds));
		if (CollectionUtils.isNotEmpty(accIds)) {
			this.setAccountIds(reqParam, accIds);
			caseList = caseListJdbcRepository.getCaseListDetails(reqParam);

		}
		return caseList;
	}

	private void setAccountIds(Map<String, Object> paramReq,final List<String> accountIds) {				
		paramReq.put(ACCOUNT_IDS, String.join(",", accountIds));
	}

}
