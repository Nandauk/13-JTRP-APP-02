package com.ombudsman.service.respondent.model.dto;

public class CaseOwnerCountProjectionDto {
    private final String incidentCount;
    private final String ownerName;
    private final String emailAddress;
	/* private final String customerId; */

    // Constructor
    public CaseOwnerCountProjectionDto(String incidentCount, String ownerName, String emailAddress) {
        this.incidentCount = incidentCount;
        this.ownerName = ownerName;
        this.emailAddress = emailAddress;
       // this.customerId = customerId;
    }

    // Getters
    public String getIncident_count() {
        return incidentCount;
    }

    public String getOwnername() {
        return ownerName;
    }

	public String getEmailAddress() {
		return emailAddress;
	}

   
	/*
	 * public String getCustomerid() { return customerId; }
	 */
}
