package com.ombudsman.service.respondent.model.response;

import com.ombudsman.service.respondent.exception.ApiError;
import com.ombudsman.service.respondent.model.CaseWorker;

public class CaseWorkerDetailsByIdRes extends GenericResponse{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private CaseWorker caseworker;
	private ApiError errorcode;

	public CaseWorker getCaseworker() {
		return caseworker;
	}
	public void setCaseworker(CaseWorker caseworker) {
		this.caseworker = caseworker;
	}
	public ApiError getErrorcode() {
		return errorcode;
	}
	public void setErrorcode(ApiError errorcode) {
		this.errorcode = errorcode;
	}
}
