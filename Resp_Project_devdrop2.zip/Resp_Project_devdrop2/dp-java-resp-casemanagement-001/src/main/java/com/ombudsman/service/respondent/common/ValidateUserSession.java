package com.ombudsman.service.respondent.common;

import static com.ombudsman.service.respondent.common.Constants.VALID;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ombudsman.service.respondent.exception.UnAuthorisedException;
import com.ombudsman.service.respondent.model.response.GenericResponse;
import com.ombudsman.service.respondent.service.ILoginService;
@Component
public class ValidateUserSession {
	private static final String TRUE = "true";
	private static final String FALSE = "false";
	private static final String INVALID_SESSION = "invalid user session";
	@Autowired
	CommonUtil commonUtil;
	@Autowired
	ILoginService loginService;
	public boolean isValidSession() throws UnAuthorisedException {

		Logger log = LogManager.getRootLogger();

		try {
			final String sessionFlag = commonUtil.sessionFlag;
			GenericResponse tokenStatus;
			if (TRUE.equalsIgnoreCase(sessionFlag)) {
				tokenStatus = loginService.getSessionTokenStatus();
				log.info("Token Status:: {} when session flag::{}",format(tokenStatus.getStatus()), format(sessionFlag));
				if (VALID.equalsIgnoreCase(tokenStatus.getStatus())) {					
					return true;
				} else {
					log.info("Token status:{}",tokenStatus.getStatus());
					throw new UnAuthorisedException(INVALID_SESSION);
				}
			}
			if (FALSE.equalsIgnoreCase(sessionFlag)) {				
				return false;
			}

		} catch (Exception e) {
			log.error("Error while validating user session::{}",e.getMessage());
			throw new UnAuthorisedException(INVALID_SESSION);
		}
		return false;
	}

		private static String format(String original) {
		String clean = original.replace('\n', '_').replace('\r', '_');
		StringBuilder sb = new StringBuilder(clean);
		return sb.toString();
	}


}