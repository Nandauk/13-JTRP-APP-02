package com.ombudsman.service.respondent.service;

import java.sql.SQLException;

import javax.security.auth.login.AccountNotFoundException;

import com.ombudsman.service.respondent.exception.InvalidOrganisationException;
import com.ombudsman.service.respondent.exception.MandatoryFieldMissingException;
import com.ombudsman.service.respondent.exception.OrganisationIdMissingException;
import com.ombudsman.service.respondent.exception.SQLDataAccessException;
import com.ombudsman.service.respondent.exception.SQLServerException;
import com.ombudsman.service.respondent.exception.UnAuthorisedException;
import com.ombudsman.service.respondent.model.request.CaseworkerReq;
import com.ombudsman.service.respondent.model.response.CaseworkerListByIdRes;

public interface CaseworkerListByIdService {
    CaseworkerListByIdRes getCaseworkers(CaseworkerReq request)
            throws SQLDataAccessException, AccountNotFoundException, UnAuthorisedException, InvalidOrganisationException;
}
