package com.ombudsman.service.respondent.repository.daoimpl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.ombudsman.service.respondent.exception.SQLDataAccessException;
import com.ombudsman.service.respondent.model.dto.CaseByCaseReferenceDto;
import com.ombudsman.service.respondent.model.dto.CaseDetailDto;
import com.ombudsman.service.respondent.model.dto.CaseOutcomeDto;
import com.ombudsman.service.respondent.model.dto.CaseWorkerDto;
import com.ombudsman.service.respondent.repository.dao.CaseDetailsDao;
import com.ombudsman.service.respondent.service.repository.CaseDetailsJdbcRepository;
import com.ombudsman.service.respondent.serviceimpl.helper.CaseServiceHelper;

@Component
public class CaseDetailsDaoImpl implements CaseDetailsDao{
	Logger log = LogManager.getRootLogger();
	private static final String ACCOUNT_IDS = "acctId";
	private static final String INCIDENT = "incident";
	private static final String TICKET = "ticket";
	
	@Autowired 
	CaseDetailsJdbcRepository caseDetailsJdbcRepository;
	
	@Autowired
	CaseServiceHelper caseServiceHelper;
	
	
	@Override
	public List<CaseDetailDto> getCaseDetailsById(String incidentId,List<String> accIds) throws SQLDataAccessException
	{
		Map<String, Object> paramReq = this.setReqParam(incidentId, accIds);
		return caseDetailsJdbcRepository.getCaseDetailsById(paramReq);
	}
	
	@Override
	public List<CaseOutcomeDto> getCaseOutcomeById(String incidentId, List<String> accIds) throws SQLDataAccessException
	{
		Map<String, Object> paramReq = this.setReqParam(incidentId, accIds);
		return caseDetailsJdbcRepository.getCaseOutcomeById(paramReq);
	}
	
	@Override
	public List<CaseWorkerDto> getCaseWorkerDetailsById(String incidentId, List<String> accIds) throws SQLDataAccessException
	{
		Map<String, Object> paramReq = this.setReqParam(incidentId, accIds);
		return caseDetailsJdbcRepository.getCaseWorkerDetailsById(paramReq);
	}
	
	@Override
	public List<CaseByCaseReferenceDto> getCaseIncidentidByCaseReference(String ticketId, List<String> accIds) throws SQLDataAccessException
	{
		Map<String, Object> paramReq = new HashMap<>();
		paramReq.put(TICKET, ticketId);
		paramReq.put(ACCOUNT_IDS, accIds);
		return caseDetailsJdbcRepository.getCaseIncidentidByCaseReference(paramReq);
	}
	
	private Map<String, Object> setReqParam( String incidentId,List<String> accIds) {	
		Map<String, Object> paramReq = new HashMap<>();
		paramReq.put(INCIDENT, incidentId);
		paramReq.put(ACCOUNT_IDS, accIds);
		return paramReq;
	}
	
	@Override
	public Map<String, Object> getCaseParties(String incidentId, List<String> accIds) throws SQLDataAccessException {
		Map<String, Object> paramReq = new HashMap<>();
		Map<String, Object> casePartiesDtls = null;
			paramReq.put("Incidentids", incidentId);
			paramReq.put("Accountids", accIds.stream().collect(Collectors.joining(",")));
			casePartiesDtls = caseDetailsJdbcRepository.getCaseParties(paramReq);
		
		return casePartiesDtls;
	}
	
	@Override
	public  Map<String, Object> getOfferOutcomes(String incidentId) throws SQLDataAccessException
	{
		Map<String, Object> paramReq = new HashMap<>();
		paramReq.put("Incidentids", incidentId);
		
		 Map<String, Object> caseOutcomes = null;
		 caseOutcomes =  caseDetailsJdbcRepository.getOfferOutcomes(paramReq);
		 return caseOutcomes;
	}
	
	@Override
	public  Integer chkIncidentAuthorized(String incidentId, List<String> accIds) throws SQLDataAccessException
	{
		Map<String, Object> paramReq = this.setReqParam(incidentId, accIds);
		List<Object> countLst = caseDetailsJdbcRepository.chkIncidentAuthorized(paramReq);
		return (Integer)countLst.get(0);
	}
}
