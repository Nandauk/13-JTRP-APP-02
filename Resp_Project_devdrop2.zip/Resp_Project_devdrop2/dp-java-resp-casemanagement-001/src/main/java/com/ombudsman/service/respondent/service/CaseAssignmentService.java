package com.ombudsman.service.respondent.service;

import java.sql.SQLException;

import javax.security.auth.login.AccountNotFoundException;

import com.ombudsman.service.respondent.exception.InvalidOrganisationException;
import com.ombudsman.service.respondent.exception.UnAuthorisedException;
import com.ombudsman.service.respondent.model.request.AssignCasesReq;
import com.ombudsman.service.respondent.model.response.CaseAssignmentRes;

public interface CaseAssignmentService {
   
    CaseAssignmentRes assignCases(AssignCasesReq request)
            throws SQLException, UnAuthorisedException, InvalidOrganisationException;
}
