package com.ombudsman.service.respondent.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.ombudsman.service.respondent.exception.MandatoryFieldException;
import com.ombudsman.service.respondent.exception.OrganizationNotFoundException;
import com.ombudsman.service.respondent.model.ApiResponse;
import com.ombudsman.service.respondent.model.UpdateCase;
import com.ombudsman.service.respondent.model.request.BulkCaseUpdateRequest;

public interface IUpdateFileService {
	

	ApiResponse getSharedConfiguration(String url) throws JsonMappingException, JsonProcessingException;


	//ApiResponse updateCase(UpdateCase dto);
	
	ApiResponse bulkupdateCase(BulkCaseUpdateRequest dto) throws OrganizationNotFoundException, MandatoryFieldException,JsonProcessingException;

}
