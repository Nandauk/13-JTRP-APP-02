package com.ombudsman.service.respondent.common;

import org.mapstruct.BeforeMapping;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import com.ombudsman.service.respondent.model.Representative;
import com.ombudsman.service.respondent.model.dto.RepresentativeDto;

@Mapper(componentModel = "spring")
public interface RepresentativeMapper {
	RepresentativeMapper INSTANCE = Mappers.getMapper(RepresentativeMapper.class);
	static final String PERSONAL_REPRESENTATIVE = "Personal Representative";
    static final String PROFESSIONAL_REPRESENTATIVE = "Professional Representative";
	
	@BeforeMapping
	public default void bithDateMapping(RepresentativeDto representativeDtoObj)
	{
		if(representativeDtoObj.getFos_organisationid()==null || representativeDtoObj.getFos_organisationid().isEmpty() || representativeDtoObj.getFos_organisationid().isBlank())
			representativeDtoObj.setRepresentativeType(PERSONAL_REPRESENTATIVE);
		else
		{
			representativeDtoObj.setRepresentativeType(PROFESSIONAL_REPRESENTATIVE);
			//organizationName needs to be mapped
		}
	}
		
	
	@Mapping(source = "firstname", target = "firstname")
	@Mapping(source = "middlename", target = "middlename")
	@Mapping(source = "lastname", target = "lastname")
	@Mapping(source = "suffix", target = "suffix")
	@Mapping(source = "address1_composite", target = "address1_composite")
	@Mapping(source = "telephone1", target = "telephone1")
	@Mapping(source = "telephone2", target = "telephone2")
	@Mapping(source = "emailaddress1", target = "emailaddress1")
	@Mapping(source = "birthdate", target = "birthdate")
	//@Mapping(source = "representativeType", target = "representativeType")
	@Mapping(source = "fos_reference", target = "referenace")
	Representative representativeDtls(RepresentativeDto representativeDtoObj);
}
