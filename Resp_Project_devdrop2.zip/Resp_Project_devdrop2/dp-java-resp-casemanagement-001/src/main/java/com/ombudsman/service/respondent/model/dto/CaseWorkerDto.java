package com.ombudsman.service.respondent.model.dto;

public class CaseWorkerDto {
	
	private String ticketnumber;
	private String _fos_caseworker_value;
	private String _owninguser_value;
	private String fullname;
	private String title;
	private String address1_telephone1;
	private String internalemailaddress;
	private String cwFullname;
	private String cwAdddress1_telephone1;
	private String cwInternalemailaddress;
	private String OId;
	public String getTicketnumber() {
		return ticketnumber;
	}
	public void setTicketnumber(String ticketnumber) {
		this.ticketnumber = ticketnumber;
	}
	public String get_fos_caseworker_value() {
		return _fos_caseworker_value;
	}
	public void set_fos_caseworker_value(String _fos_caseworker_value) {
		this._fos_caseworker_value = _fos_caseworker_value;
	}
	public String get_owninguser_value() {
		return _owninguser_value;
	}
	public void set_owninguser_value(String _owninguser_value) {
		this._owninguser_value = _owninguser_value;
	}
	public String getFullname() {
		return fullname;
	}
	public void setFullname(String fullname) {
		this.fullname = fullname;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getAddress1_telephone1() {
		return address1_telephone1;
	}
	public void setAddress1_telephone1(String address1_telephone1) {
		this.address1_telephone1 = address1_telephone1;
	}
	public String getInternalemailaddress() {
		return internalemailaddress;
	}
	public void setInternalemailaddress(String internalemailaddress) {
		this.internalemailaddress = internalemailaddress;
	}
	public String getCwFullname() {
		return cwFullname;
	}
	public void setCwFullname(String cwFullname) {
		this.cwFullname = cwFullname;
	}
	public String getCwAdddress1_telephone1() {
		return cwAdddress1_telephone1;
	}
	public void setCwAdddress1_telephone1(String cwAdddress1_telephone1) {
		this.cwAdddress1_telephone1 = cwAdddress1_telephone1;
	}
	public String getCwInternalemailaddress() {
		return cwInternalemailaddress;
	}
	public void setCwInternalemailaddress(String cwInternalemailaddress) {
		this.cwInternalemailaddress = cwInternalemailaddress;
	}
	public String getOId() {
		return OId;
	}
	public void setOId(String OId) {
		this.OId = OId;
	}
	public static CaseWorkerDto create(String name , String email, String id)
	{
		CaseWorkerDto dto = new CaseWorkerDto();
		dto.cwFullname = name;
		dto.fullname = name;
		
		
		dto.cwInternalemailaddress=email;
		dto.internalemailaddress=email;
		
		dto.OId = id;
		return dto;
	}
	

}
