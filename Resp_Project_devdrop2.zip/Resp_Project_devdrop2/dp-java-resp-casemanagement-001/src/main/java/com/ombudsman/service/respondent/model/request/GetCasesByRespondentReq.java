package com.ombudsman.service.respondent.model.request;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;

import java.io.Serializable;

import com.ombudsman.service.respondent.model.Filters;

public class GetCasesByRespondentReq implements Serializable {

	private static final long serialVersionUID = 1L;

	//@NotNull
	//@NotEmpty
	private String opencasesonly;


	private transient Filters filters;


	public Filters getFilters() {
		return filters;
	}

	public void setFilters(Filters filters) {
		this.filters = filters;
	}

	public String getOpencasesonly() {
		return opencasesonly;
	}

	public void setOpencasesonly(String opencasesonly) {
		this.opencasesonly = opencasesonly;
	}

}
