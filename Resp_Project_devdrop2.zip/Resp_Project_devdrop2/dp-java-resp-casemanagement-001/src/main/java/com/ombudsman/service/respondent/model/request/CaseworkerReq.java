package com.ombudsman.service.respondent.model.request;
import jakarta.validation.constraints.NotNull;


public class CaseworkerReq {

    @NotNull(message = "Account ID is required.")
    private String accountid;

    // Getters and Setters
    public String getAccountid() {
        return accountid;
    }

    public void setAccountid(String accountid) {
        this.accountid = accountid;
    }
}