package com.ombudsman.service.respondent.service;

import java.io.IOException;
import java.sql.SQLException;

import com.ombudsman.service.respondent.exception.OrganizationNotFoundException;
import com.ombudsman.service.respondent.model.CaseExport;
import com.ombudsman.service.respondent.model.response.GetResponseMessage;

public interface IExportCasesService {
	public GetResponseMessage getCasesExportDataByRespondent(CaseExport caseExport)
			throws InterruptedException, IOException, SQLException, NullPointerException, OrganizationNotFoundException;

}
