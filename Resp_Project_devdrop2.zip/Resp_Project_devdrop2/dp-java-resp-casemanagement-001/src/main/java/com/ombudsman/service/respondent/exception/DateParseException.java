package com.ombudsman.service.respondent.exception;

import java.text.ParseException;

public class DateParseException extends ParseException {

	/**
	   * 
	   */
	  private static final long serialVersionUID = 1L;

	  public DateParseException(String errMsg){
			super(errMsg, 0);
		}
}
