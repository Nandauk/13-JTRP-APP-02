package com.ombudsman.service.respondent.service.repository;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Component;

import com.ombudsman.service.respondent.exception.CaseOutComesNotFoundException;
import com.ombudsman.service.respondent.exception.SQLDataAccessException;
import com.ombudsman.service.respondent.model.dto.CaseByCaseReferenceDto;
import com.ombudsman.service.respondent.model.dto.CaseDetailDto;
import com.ombudsman.service.respondent.model.dto.CaseOutcomeDto;
import com.ombudsman.service.respondent.model.dto.CaseWorkerDto;
import com.ombudsman.service.respondent.model.dto.OrganizationDto;

@Component
public class CaseDetailsJdbcRepository {
	@Autowired
	JdbcTemplate jdbcTemplate;
	@Autowired
	NamedParameterJdbcTemplate namedJdbcTemplate;
	private static final Logger LOG = LoggerFactory.getLogger(CaseDetailsJdbcRepository.class);
	
	public void setDataSource(DataSource dataSource) {
		this.jdbcTemplate = new JdbcTemplate(dataSource);
	}
	
	public List<OrganizationDto> getOrganisationListByParentOrgId(List<String> accountIds) throws SQLDataAccessException
	{
		  final String sql = "select accountid,parentaccountid,name from account where "
		  		+ "fos_hierarchylevel in (1,2) and (accountid in (:ids) or parentaccountid in (:ids))";
			
			final SqlParameterSource parameters = new MapSqlParameterSource("ids", accountIds);
			return namedJdbcTemplate.query(sql, parameters,
					(rs, rowNum) -> new OrganizationDto(rs.getString("organizationName"),rs.getString("organizationId")));
	}
	
	public List<CaseDetailDto> getCaseDetailsById(Map<String, Object> reqParam) throws SQLDataAccessException{
		final String sql = "SELECT *, cl.fos_reference, cl.fos_extendedreference, cl.fos_tradingname, cl.fos_individualid, fos_datecasefirstmovedtoinvestigation as dateMovedToInvestigation, fos_dateofconversion as dateOfConversion, fos_dateofreferral as dateOfReferral,"
				+ "fos_dateoffinalresponse as dateOfFinalResponse, fos_dateofevent as dateOfEvent FROM incident LEFT OUTER JOIN " 
				+ "caselink cl ON cl.fos_case = incident.incidentid AND (cl.fos_role = 140000003 AND cl.statecode = 0) WHERE (incidentid = :incident "
				+ "AND fos_datecasefirstmovedtoinvestigation IS NOT NULL AND fos_casestage IN (140000002,140000003,140000004) "
				+ "AND (fos_suppressedfordigitalportal IS NULL OR fos_suppressedfordigitalportal NOT IN (140000000,14000002)) AND customerid IN (:acctId))";

		final SqlParameterSource parameters = new MapSqlParameterSource(reqParam);
		return namedJdbcTemplate.query(sql, parameters,
				(rs, rowNum) ->  {
	                CaseDetailDto caseRow = new CaseDetailDto();
	                caseRow.setIncidentid(rs.getString("incidentid"));
	                caseRow.setTicketnumber(rs.getString("title"));
	                caseRow.setFos_crn(rs.getString("fos_crn"));	                
	                caseRow.set_customerid_value(rs.getString("customeridname"));
	               // caseRow.setBusinessname(rs.getString("businessname"));-----------------To Discuss
	                caseRow.setFos_reference(rs.getString("fos_reference"));	              
	                caseRow.setFos_extendedreference(rs.getString("fos_extendedreference"));
	                caseRow.set_fos_complaintissue_value(rs.getString("fos_complaintissue"));
	                caseRow.set_fos_complaintissue_value_txt(rs.getString("fos_complaintissuename"));	                
	                caseRow.set_fos_productorproductfamily_value(rs.getString("fos_productorproductfamily"));
	                caseRow.set_fos_productorproductfamily_value_txt(rs.getString("fos_productorproductfamilyname"));
	                caseRow.setFos_casestage(rs.getString("fos_casestage"));	                
	                caseRow.setFos_casestage_txt(rs.getString("fos_casestagename"));
	                caseRow.setStatuscode(rs.getString("statuscode"));
	                caseRow.setStatuscode_txt(rs.getString("statuscodename"));	                
	                caseRow.setFos_dateofreferral(datetimeformate(rs.getString("dateOfReferral")));
	                caseRow.setAgecaseflag(rs.getString("caseage"));
	                caseRow.setFos_representatives(rs.getString("fos_representatives"));	              
	                caseRow.setFos_datecasefirstmovedtoinvestigation(datetimeformate(rs.getString("dateMovedToInvestigation")));
	                caseRow.setFos_dateofconversion(datetimeformate(rs.getString("dateOfConversion")));
	                caseRow.setFos_datebusinessfilereceived(rs.getString("fos_datebusinessfilereceived"));	                
	                //caseRow.setFos_dispatcheddate(rs.getString("fos_dispatcheddate"));-------------To Discuss
	                //caseRow.setFos_type(rs.getString("fos_type"));-------------To Discuss
	                //caseRow.setFos_categorycode(rs.getString("fos_categorycode"));----------------To Discuss              
	                caseRow.setFos_oldercasestatus(rs.getString("fos_oldercasestatus"));	                
	                caseRow.set_fos_caseworker_value(rs.getString("fos_caseworker"));
	                caseRow.setFos_individualid(rs.getString("fos_individualid"));
	                //caseRow.setCaseagebanding(rs.getString("caseagebanding"));-------------To Discuss	                
	                //caseRow.setNoofefile(rs.getString("noofefile"));-----------To Discuss
	                //caseRow.setNoofcorrespondet(rs.getString("noofcorrespondet"));
	                caseRow.setFos_dateofevent(datetimeformate(rs.getString("dateOfEvent")));	              
	               // caseRow.setVulnerable(rs.getString("vulnerable"));
	                caseRow.setFos_dateoffinalresponse(datetimeformate(rs.getString("dateOfFinalResponse")));
	                //caseRow.setFos_offeroutcome(rs.getString("fos_offeroutcome"));	                
	                caseRow.setFos_changeinoutcome(rs.getString("fos_changeinoutcome"));
	               // caseRow.setDeadlockcases(rs.getString("deadlockcases"));
	                caseRow.setFos_tradingname(rs.getString("fos_tradingname"));               
	                caseRow.setFos_prioritycode(rs.getString("fos_prioritycode"));
	                caseRow.setFos_prioritycode_txt(rs.getString("fos_prioritycodename"));
	                caseRow.set_owninguser_value(rs.getString("owninguser"));	                
	                caseRow.setDescription(rs.getString("description"));
	               // caseRow.setBr_required(rs.getString("br_required"));
	                caseRow.setStatecode(rs.getString("statecode"));
	              //  caseRow.setAwaitingAction(rs.getString("awaitingAction"));
	                caseRow.setFos_caseprogress(rs.getString("fos_caseprogress"));
	                caseRow.setFos_caseprogress_name(rs.getString("fos_caseprogress_name"));
	                return caseRow;
	            });	
	}
	
	public String datetimeformate(String date) {
		LOG.info("start date time formate method");
		if (date != null) {
			LOG.info("date is not null:-{}",date);
			try {
				LocalDateTime localDateTime = LocalDateTime.parse(date,DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSSSSSS"));
				String format = localDateTime.format(DateTimeFormatter.ofPattern("MM/dd/yyyy hh:mm:ss a"));
				LOG.info("after formate change:-{}",format);
				return format;
			} catch (Exception e) {
				LOG.error("after formate change:-{}",date);
				throw new CaseOutComesNotFoundException("Datetime convertion error");
			}
		} else {
			LOG.debug("date is null:-{}",date);
			return null;
		}
	}
	
	
	public List<CaseOutcomeDto> getCaseOutcomeById(Map<String, Object> reqParam) throws SQLDataAccessException{
		final String sql = "SELECT fos_case, fos_offeroroutcomeid, fos_type, fos_typename, fos_jurisdiction, fos_meritsjurisdictiondismissal, fos_meritopinion, fos_jurisdictionreason, fos_jurisdictioninout, fos_dismissalreason, fos_withopinion, fos_outcomedispatchedby, offeroutcome.fos_changeinoutcome, fos_outcomedispatched, fos_settlementamount, fos_settlementbandid, fos_nonmonetarysettlement, fos_troubleupsetamt, fos_complainantresponse, fos_senttocomplainant, fos_othercomplaintbody, fos_respondentresponse, fos_senttorespondent, caseDtl.statecode,fos_meritopinionname,fos_meritsjurisdictiondismissalname,fos_jurisdictioninoutname,fos_changeinoutcomename,fos_settlementbandidname,fos_complainantresponsename,offeroutcome.statuscode,fos_outcomedispatcheddate FROM offeroutcome JOIN incident caseDtl ON caseDtl.incidentid = offeroutcome.fos_case WHERE (fos_case = :incident AND fos_dispatchstatuscode IS NOT NULL AND customerid IN (:acctId)) ORDER BY fos_outcomedispatcheddate DESC";

		final SqlParameterSource parameters = new MapSqlParameterSource(reqParam);
		return namedJdbcTemplate.query(sql, parameters,
				(rs, rowNum) ->  {
	                CaseOutcomeDto caseOutcomeRow = new CaseOutcomeDto();
	                caseOutcomeRow.setFos_case(rs.getString("fos_case"));
	                caseOutcomeRow.setFos_offeroroutcomeid(rs.getString("fos_offeroroutcomeid"));
	                caseOutcomeRow.setFos_type(rs.getString("fos_type"));	                
	                caseOutcomeRow.setFos_typename(rs.getString("fos_typename"));
	                caseOutcomeRow.setFos_meritsjurisdictiondismissal(rs.getString("fos_meritsjurisdictiondismissal"));
	                caseOutcomeRow.setFos_meritsjurisdictiondismissalname(rs.getString("fos_meritsjurisdictiondismissalname"));	              
	                caseOutcomeRow.setFos_meritopinion(rs.getString("fos_meritopinion"));
	                caseOutcomeRow.setFos_meritopinionname(rs.getString("fos_meritopinionname"));
	                caseOutcomeRow.setFos_jurisdictioninout(rs.getString("fos_jurisdictioninout"));	                
	                caseOutcomeRow.setFos_jurisdictioninoutname(rs.getString("fos_jurisdictioninoutname"));
	                caseOutcomeRow.setFos_dismissalreason(rs.getString("fos_dismissalreason"));
	                caseOutcomeRow.setFos_withopinion(rs.getString("fos_withopinion"));	                
	                caseOutcomeRow.setFos_changeinoutcome(rs.getString("fos_changeinoutcome"));
	                caseOutcomeRow.setFos_changeinoutcomename(rs.getString("fos_changeinoutcomename"));
	                caseOutcomeRow.setFos_settlementbandid(rs.getString("fos_settlementbandid"));	                
	                caseOutcomeRow.setFos_settlementbandidname(rs.getString("fos_settlementbandidname"));
	                caseOutcomeRow.setFos_nonmonetarysettlement(rs.getString("fos_nonmonetarysettlement"));
	                caseOutcomeRow.setFos_troubleupsetamt(rs.getString("fos_troubleupsetamt"));	              
	                caseOutcomeRow.setFos_complainantresponse(rs.getString("fos_complainantresponse"));
	                caseOutcomeRow.setFos_complainantresponsename(rs.getString("fos_complainantresponsename"));
	                caseOutcomeRow.setFos_respondentresponse(rs.getString("fos_respondentresponse"));	                
	                //caseOutcomeRow.setFos_respondentresponse_txt(rs.getString("fos_respondentresponse_txt"));
	                caseOutcomeRow.setFos_outcomedispatcheddate(rs.getString("fos_outcomedispatcheddate"));
	                return caseOutcomeRow;
	            });	
	}

	public List<CaseWorkerDto> getCaseWorkerDetailsById(Map<String, Object> reqParam) throws SQLDataAccessException{
		final String sql = "SELECT TICKETNUMBER, FOS_CASEWORKER, OWNINGUSER, OU.FULLNAME OU_FULLNAME, OU.TITLE OU_TITLE, OU.ADDRESS1_TELEPHONE1 OU_ADDRESS1, "
				+ " OU.INTERNALEMAILADDRESS OU_INTERNALEMAIL, CW.FULLNAME CW_FULLNAME, CW.TITLE CW_TITLE, CW.ADDRESS1_TELEPHONE1 CW_ADDRESS1, CW.INTERNALEMAILADDRESS CW_INTERNALEMAIL FROM INCIDENT LEFT OUTER JOIN [dbo].[user] OU ON OU.SYSTEMUSERID = INCIDENT.OWNINGUSER LEFT OUTER JOIN [dbo].[user] CW ON CW.SYSTEMUSERID = INCIDENT.FOS_CASEWORKER WHERE (INCIDENTID = :incident AND CUSTOMERID IN (:acctId) AND fos_datecasefirstmovedtoinvestigation IS NOT NULL AND fos_casestage IN (140000002,140000003,140000004)"
				+ " AND (fos_suppressedfordigitalportal IS NULL OR fos_suppressedfordigitalportal NOT IN (140000000,14000002)))";

		final SqlParameterSource parameters = new MapSqlParameterSource(reqParam);
		return namedJdbcTemplate.query(sql, parameters,
				(rs, rowNum) ->  {
					CaseWorkerDto caseWorkerRow = new CaseWorkerDto();
					caseWorkerRow.set_owninguser_value(rs.getString("OWNINGUSER"));
					caseWorkerRow.setFullname(rs.getString("OU_FULLNAME"));                
					caseWorkerRow.setAddress1_telephone1(rs.getString("OU_ADDRESS1"));
					caseWorkerRow.setInternalemailaddress(rs.getString("OU_INTERNALEMAIL"));
					caseWorkerRow.setCwFullname(rs.getString("CW_FULLNAME"));                
					caseWorkerRow.setCwAdddress1_telephone1(rs.getString("CW_ADDRESS1"));
					caseWorkerRow.setCwInternalemailaddress(rs.getString("CW_INTERNALEMAIL"));
					caseWorkerRow.setTitle(rs.getString("CW_TITLE"));	
					caseWorkerRow.setTicketnumber(rs.getString("TICKETNUMBER"));

	                return caseWorkerRow;
	            });	
	}
	
	public List<CaseByCaseReferenceDto> getCaseIncidentidByCaseReference(Map<String, Object> reqParam) throws SQLDataAccessException{
		  final String sql = "SELECT incidentid FROM   incident WHERE  ticketnumber = :ticket AND fos_datecasefirstmovedtoinvestigation IS NOT NULL AND statecode <> 2 AND (fos_suppressedfordigitalportal NOT IN ('140000002', '140000000')  OR fos_suppressedfordigitalportal IS NULL) AND fos_casestage IN ('140000002', '140000003', '140000004') AND customerid IN (:acctId)";
			
			final SqlParameterSource parameters = new MapSqlParameterSource(reqParam);
			return namedJdbcTemplate.query(sql, parameters,
					(rs, rowNum) -> new CaseByCaseReferenceDto(rs.getString("incidentid")));
		}
	
	public Map<String, Object> getCaseParties(Map<String, Object> reqParam) throws SQLDataAccessException{
		final SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate)
				.withProcedureName("prc_GetCaseParties");
		SqlParameterSource in = new MapSqlParameterSource(reqParam);
		LOG.debug("getCaseListDetails method parameteres passing to Store procedure::{}:", reqParam);
		return simpleJdbcCall.execute(in);

	}
	
	public Map<String, Object> getOfferOutcomes(Map<String, Object> reqParam) throws SQLDataAccessException{
		final SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate)
				.withProcedureName("prc_getCaseoutcomesforcasedetails");
		SqlParameterSource in = new MapSqlParameterSource(reqParam);
		LOG.debug("getCaseListDetails method parameteres passing to Store procedure::{}:", reqParam);
		return simpleJdbcCall.execute(in);

	}
	
	public List<Object> chkIncidentAuthorized(Map<String, Object> reqParam) throws SQLDataAccessException{
		  final String sql = "SELECT COUNT(incidentid) as count FROM incident WHERE incidentid =:incident AND customerid IN (:acctId)";
			
			final SqlParameterSource parameters = new MapSqlParameterSource(reqParam);
			return namedJdbcTemplate.query(sql, parameters,
					(rs, rowNum) -> rs.getInt("count"));
		}

}
