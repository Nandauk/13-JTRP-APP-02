package com.ombudsman.service.respondent.serviceimpl;

import static com.ombudsman.service.respondent.common.Constants.CASE_REFERENCE_IS_A_VALID_FIELD;
import static com.ombudsman.service.respondent.common.Constants.CASE_REFERENCE_IS_NOT_A_VALID_FIELD;
import static com.ombudsman.service.respondent.common.Constants.CASE_REFERENCE_NOT_FOUND_FOR_ORGANISATION;
import static com.ombudsman.service.respondent.common.Constants.FAILED;
import static com.ombudsman.service.respondent.common.Constants.SUCCESS;
import static com.ombudsman.service.respondent.common.Constants.USER_IS_NOT_TAGGED_WITH_ANY_ORGANISATION;

import java.io.IOException;
import java.util.List;
import java.util.Optional;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nimbusds.oauth2.sdk.util.CollectionUtils;
import com.ombudsman.service.respondent.common.CommonUtil;
import com.ombudsman.service.respondent.common.UserBean;
import com.ombudsman.service.respondent.exception.AzureServiceException;
import com.ombudsman.service.respondent.exception.CaseReferenceDetailsNotFoundException;
import com.ombudsman.service.respondent.exception.SQLDataAccessException;
import com.ombudsman.service.respondent.exception.UnAuthorisedException;
import com.ombudsman.service.respondent.model.dto.CaseByCaseReferenceDto;
import com.ombudsman.service.respondent.model.request.CaseByCaseReferenceReq;
import com.ombudsman.service.respondent.model.response.CaseByCaseReferenceRes;
import com.ombudsman.service.respondent.repository.dao.CaseDetailsDao;
import com.ombudsman.service.respondent.service.CaseByCaseReferenceService;
import com.ombudsman.service.respondent.serviceimpl.helper.CaseServiceHelper;

@Service
public class CaseByCaseReferenceServiceImpl implements CaseByCaseReferenceService {

	private CommonUtil commonUtil;

	UserBean userbean;

	CaseServiceHelper caseServiceHelper;
	
	CaseDetailsDao caseDetailsDao;
	
	@Autowired
	public CaseByCaseReferenceServiceImpl(UserBean userbean, CaseDetailsDao caseDetailsDao,
			CommonUtil commonUtil,CaseServiceHelper caseServiceHelper) {
		super();
		this.userbean = userbean;
		this.caseDetailsDao = caseDetailsDao;
		this.commonUtil = commonUtil;
		this.caseServiceHelper = caseServiceHelper;
	}
	private static final Logger log =  LogManager.getRootLogger();

	@Override
	public CaseByCaseReferenceRes getCaseIncidentidByCaseReference(CaseByCaseReferenceReq request)
			throws AzureServiceException, JSONException, IOException, SQLDataAccessException, CaseReferenceDetailsNotFoundException, UnAuthorisedException {

		log.debug("GetCaseIncidentidByCaseReference Service Method Started.CorrelationId:-{} OID:-{}",
				userbean.getCorrelationId(), userbean.getUserObjectId());
		CaseByCaseReferenceRes response = new CaseByCaseReferenceRes();
		final String methodName = "getCaseIncidentidByCaseReference";
		
		// verification as per regex provided started
		if (StringUtils.isNotEmpty(request.getCasefererence()) && commonUtil.isValidInput(request.getCasefererence())) {
			log.debug(CASE_REFERENCE_IS_A_VALID_FIELD);
					final List<String> accIds = caseServiceHelper.getAccountIds(userbean.getUserObjectId());

					if (CollectionUtils.isNotEmpty(accIds)) {					

						final List<CaseByCaseReferenceDto> caseByCaseReferenceData = Optional.ofNullable(accIds)
								.map(i -> caseDetailsDao.getCaseIncidentidByCaseReference(request.getCasefererence(),
										accIds))
								.orElseThrow(() -> new CaseReferenceDetailsNotFoundException(CASE_REFERENCE_NOT_FOUND_FOR_ORGANISATION));

						if (CollectionUtils.isNotEmpty(caseByCaseReferenceData)) {
							final String incidentId = caseByCaseReferenceData.get(caseByCaseReferenceData.size() - 1)
									.getIncidentId();
							response.setIncidentid(incidentId);
							response.setStatus(SUCCESS);
						}
						 else {
							log.debug(CASE_REFERENCE_NOT_FOUND_FOR_ORGANISATION);
							throw new CaseReferenceDetailsNotFoundException(CASE_REFERENCE_NOT_FOUND_FOR_ORGANISATION);
						}

					}			
		}else {
				response.setStatus(FAILED);
				response.setMessage(CASE_REFERENCE_IS_NOT_A_VALID_FIELD);
				log.debug(CASE_REFERENCE_IS_NOT_A_VALID_FIELD);
			}
		log.debug("GetCaseIncidentidByCaseReference Service Method Ended.CorrelationId:-{} OID:-{}",
				userbean.getCorrelationId(), userbean.getUserObjectId());
		return response;
	}
}
