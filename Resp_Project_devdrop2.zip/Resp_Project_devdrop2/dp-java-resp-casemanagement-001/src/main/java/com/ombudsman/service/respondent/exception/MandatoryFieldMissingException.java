package com.ombudsman.service.respondent.exception;

public class MandatoryFieldMissingException  extends RuntimeException {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public MandatoryFieldMissingException(String exceptionMsg)
	{
		super(exceptionMsg);
	}


}
