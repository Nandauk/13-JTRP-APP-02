package com.ombudsman.service.respondent.serviceimpl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.security.auth.login.AccountNotFoundException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ombudsman.service.respondent.common.UserBean;
import com.ombudsman.service.respondent.exception.CaseFilterNotFoundException;
import com.ombudsman.service.respondent.exception.OrganizationNotFoundException;
import com.ombudsman.service.respondent.exception.SQLDataAccessException;
import com.ombudsman.service.respondent.model.CaseFilterData;
import com.ombudsman.service.respondent.model.dto.CaseFilterDetailsDto;
import com.ombudsman.service.respondent.model.response.GetCaseFilterDataRes;
import com.ombudsman.service.respondent.repository.dao.ICaseListDao;
import com.ombudsman.service.respondent.service.ICaseFilterService;
import com.ombudsman.service.respondent.serviceimpl.helper.CaseServiceHelper;

@Service
public class CaseFilterServiceImpl implements ICaseFilterService {

	
	private static final String SUCCESS = "Success";

	@Autowired
	ICaseListDao caseListDao;

	@Autowired
	CaseServiceHelper dashboardServiceHelper;
	@Autowired
	UserBean userbean;
	Logger LOG = LogManager.getRootLogger();

	@Override
	public GetCaseFilterDataRes getCaseFilterDataForOrganisation()
			throws SQLDataAccessException, AccountNotFoundException, OrganizationNotFoundException, CaseFilterNotFoundException {
		final String methodName = "getCaseFilterDataForOrganisation";
		final List<String> groupIds = userbean.getGroups();

		LOG.debug(methodName, "::Service Method Started.CorrelationId:-{} OID:-{} group ids{}",
				userbean.getCorrelationId(), userbean.getUserObjectId(), groupIds);

		final Map<String, List<CaseFilterData>> caseFilterMap = new HashMap<>();
		final GetCaseFilterDataRes getCaseFilterDataRes = new GetCaseFilterDataRes();


			try {
				
				
				final List<CaseFilterDetailsDto> caseFilterData=Optional.ofNullable(caseListDao.getCaseFilter(userbean.getUserObjectId()))
						.orElseThrow(() -> new CaseFilterNotFoundException("Case Filter not found"));
				Map<String, List<CaseFilterDetailsDto>> groupByPriceMap = caseFilterData.stream()
						.collect(Collectors.groupingBy(CaseFilterDetailsDto::getFilterType));

				for (Map.Entry<String, List<CaseFilterDetailsDto>> entry : groupByPriceMap.entrySet()) {
					final List<CaseFilterData> filterData = entry.getValue().stream()
							.map(i -> new CaseFilterData(i.getAccountId(), i.getFilterValue()))
							.collect(Collectors.toList());
					caseFilterMap.put(entry.getKey().toLowerCase().replaceAll("\\s", ""), filterData);
				}
				getCaseFilterDataRes.setFilters(caseFilterMap);
				getCaseFilterDataRes.setStatus(SUCCESS);
				LOG.debug(methodName, "::Case filer list size from database ::", caseFilterMap.size());

			} catch (final CaseFilterNotFoundException ex) {
				LOG.error("Error while getting data::{}", ex.getMessage());
				throw new CaseFilterNotFoundException("Case Filter not found");
			}

		LOG.debug(methodName, ":: Service Method Ended.CorrelationId:-{} OID:-{}",
				userbean.getCorrelationId(), userbean.getUserObjectId());

		return getCaseFilterDataRes;
	}

}
