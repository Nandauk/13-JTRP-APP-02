package com.ombudsman.service.respondent.service;

import java.io.IOException;

import org.json.JSONException;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ombudsman.service.respondent.exception.AzureServiceException;
import com.ombudsman.service.respondent.exception.CaseDetailsNotFoundException;
import com.ombudsman.service.respondent.exception.CasePartiesNotFoundException;
import com.ombudsman.service.respondent.exception.CaseWorkerDetailsNotFoundException;
import com.ombudsman.service.respondent.exception.SQLDataAccessException;
import com.ombudsman.service.respondent.model.request.CaseDetailsByIdReq;
import com.ombudsman.service.respondent.model.response.CaseDetailsByIdRes;
import com.ombudsman.service.respondent.model.response.CasePartiesByIdRes;
import com.ombudsman.service.respondent.model.response.CaseWorkerDetailsByIdRes;


public interface CaseDetailsByIdService {
	
	public CaseDetailsByIdRes getCaseDetailsById(CaseDetailsByIdReq request) throws AzureServiceException, JsonProcessingException,IOException, SQLDataAccessException, CaseDetailsNotFoundException;
	
	public CaseWorkerDetailsByIdRes getCaseWorkerDetailsById(CaseDetailsByIdReq request) throws AzureServiceException, JSONException, IOException, SQLDataAccessException, CaseWorkerDetailsNotFoundException;

	CasePartiesByIdRes getCasePartiesById(CaseDetailsByIdReq request) throws AzureServiceException, JSONException, IOException, SQLDataAccessException, CasePartiesNotFoundException;
	
	

}
