/**
 * 
 */
package com.ombudsman.service.respondent.common;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Service;

@Configuration
@Service
public class CommonUtil {

	@Autowired
	UserBean userbean;

	@Value("${app.session_base_url}")
	public String SESSION_BASE_URL;

	@Value("${app.session_flag}")
	public String sessionFlag;

	public boolean isValidEmailInput(String input) {
		String regex = "^[a-zA-Z0-9-@.+]+$";
		Pattern pattern = Pattern.compile(regex);
		Matcher matcher = pattern.matcher(input);
		return matcher.matches();
	}

	public boolean isValidInput(String input) {
		String regex = "^[a-zA-Z0-9-]+$";
		Pattern pattern = Pattern.compile(regex);
		Matcher matcher = pattern.matcher(input);
		return matcher.matches();
	}

	public boolean isValidNameInput(String input) {
		String regex = "^[a-zA-Z_-]+$";
		Pattern pattern = Pattern.compile(regex);
		Matcher matcher = pattern.matcher(input);
		return matcher.matches();
	}
	
	public boolean isValidComment(String comment) {
		String regex = "^[a-zA-Z0-9.,\\s]*$";
		return comment != null && comment.matches(regex);
		
	}

}
