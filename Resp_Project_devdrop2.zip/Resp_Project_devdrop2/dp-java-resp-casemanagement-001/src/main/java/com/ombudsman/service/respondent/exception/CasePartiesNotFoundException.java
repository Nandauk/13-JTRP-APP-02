package com.ombudsman.service.respondent.exception;

public class CasePartiesNotFoundException extends RuntimeException{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public CasePartiesNotFoundException(String exceptionMsg)
	{
		super(exceptionMsg);
	}

}
