package com.ombudsman.service.respondent.model.dto;

import java.io.Serializable;

public class ComplainantDto implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private String suffix;
	private String address1_composite;
    private String telephone1;
    private String telephone2;
    private String emailaddress1;
    private String birthdate;
    private String organisation_existInComplainant;
    private String firstname;
    private String middlename;
    private String lastname;
    private String parentcustomerid;
	public String getSuffix() {
		return suffix;
	}
	public void setSuffix(String suffix) {
		this.suffix = suffix;
	}
	public String getAddress1_composite() {
		return address1_composite;
	}
	public void setAddress1_composite(String address1_composite) {
		this.address1_composite = address1_composite;
	}
	public String getTelephone1() {
		return telephone1;
	}
	public void setTelephone1(String telephone1) {
		this.telephone1 = telephone1;
	}
	public String getTelephone2() {
		return telephone2;
	}
	public void setTelephone2(String telephone2) {
		this.telephone2 = telephone2;
	}
	public String getEmailaddress1() {
		return emailaddress1;
	}
	public void setEmailaddress1(String emailaddress1) {
		this.emailaddress1 = emailaddress1;
	}
	public String getBirthdate() {
		return birthdate;
	}
	public void setBirthdate(String birthdate) {
		this.birthdate = birthdate;
	}
	public String getOrganisation_existInComplainant() {
		return organisation_existInComplainant;
	}
	public void setOrganisation_existInComplainant(String organisation_existInComplainant) {
		this.organisation_existInComplainant = organisation_existInComplainant;
	}
    public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getMiddlename() {
		return middlename;
	}
	public void setMiddlename(String middlename) {
		this.middlename = middlename;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public String getParentcustomerid() {
		return parentcustomerid;
	}
	public void setParentcustomerid(String parentcustomerid) {
		this.parentcustomerid = parentcustomerid;
	}

/*********From CaseLink Query**********/
    private String fos_case;
    private String fos_role;
    private String fos_individualid;
    private String fos_organisationid;
    private String fos_reference;
    private String fos_representativecaselinkid;
    private String fos_caselinkid;
	private String fos_numberofemployees;
	private String fos_numberofpartners;
	private String fos_annualturnover;
	private String fos_balancesheet;
	private String fos_islinkedorpartnered;
	private String fos_annualincome;
	private String fos_netassets;
	private String fos_businesstypecode;
	private String fos_preferredemailaddress;
	public String getFos_case() {
		return fos_case;
	}
	public void setFos_case(String fos_case) {
		this.fos_case = fos_case;
	}
	public String getFos_role() {
		return fos_role;
	}
	public void setFos_role(String fos_role) {
		this.fos_role = fos_role;
	}
	public String getFos_individualid() {
		return fos_individualid;
	}
	public void setFos_individualid(String fos_individualid) {
		this.fos_individualid = fos_individualid;
	}
	public String getFos_organisationid() {
		return fos_organisationid;
	}
	public void setFos_organisationid(String fos_organisationid) {
		this.fos_organisationid = fos_organisationid;
	}
	public String getFos_reference() {
		return fos_reference;
	}
	public void setFos_reference(String fos_reference) {
		this.fos_reference = fos_reference;
	}
	public String getFos_representativecaselinkid() {
		return fos_representativecaselinkid;
	}
	public void setFos_representativecaselinkid(String fos_representativecaselinkid) {
		this.fos_representativecaselinkid = fos_representativecaselinkid;
	}
	public String getFos_caselinkid() {
		return fos_caselinkid;
	}
	public void setFos_caselinkid(String fos_caselinkid) {
		this.fos_caselinkid = fos_caselinkid;
	}
	public String getFos_numberofemployees() {
		return fos_numberofemployees;
	}
	public void setFos_numberofemployees(String fos_numberofemployees) {
		this.fos_numberofemployees = fos_numberofemployees;
	}
	public String getFos_numberofpartners() {
		return fos_numberofpartners;
	}
	public void setFos_numberofpartners(String fos_numberofpartners) {
		this.fos_numberofpartners = fos_numberofpartners;
	}
	public String getFos_annualturnover() {
		return fos_annualturnover;
	}
	public void setFos_annualturnover(String fos_annualturnover) {
		this.fos_annualturnover = fos_annualturnover;
	}
	public String getFos_balancesheet() {
		return fos_balancesheet;
	}
	public void setFos_balancesheet(String fos_balancesheet) {
		this.fos_balancesheet = fos_balancesheet;
	}
	public String getFos_islinkedorpartnered() {
		return fos_islinkedorpartnered;
	}
	public void setFos_islinkedorpartnered(String fos_islinkedorpartnered) {
		this.fos_islinkedorpartnered = fos_islinkedorpartnered;
	}
	public String getFos_annualincome() {
		return fos_annualincome;
	}
	public void setFos_annualincome(String fos_annualincome) {
		this.fos_annualincome = fos_annualincome;
	}
	public String getFos_netassets() {
		return fos_netassets;
	}
	public void setFos_netassets(String fos_netassets) {
		this.fos_netassets = fos_netassets;
	}
	public String getFos_businesstypecode() {
		return fos_businesstypecode;
	}
	public void setFos_businesstypecode(String fos_businesstypecode) {
		this.fos_businesstypecode = fos_businesstypecode;
	}
	public String getFos_preferredemailaddress() {
		return fos_preferredemailaddress;
	}
	public void setFos_preferredemailaddress(String fos_preferredemailaddress) {
		this.fos_preferredemailaddress = fos_preferredemailaddress;
	}


}
