package com.ombudsman.service.delete.reconciliation.model;

import com.google.gson.annotations.SerializedName;

public class MailjetVariables {
	
	@SerializedName("templateName")
	String templateName;

	@SerializedName("role")
	String role;

	@SerializedName("templateId")
	String templateId;
	
	@SerializedName("auditId")
	String auditId;
	
	@SerializedName("source")
	String source;
	
	@SerializedName("timestamp")
	String timestamp;
	
	@SerializedName("entityName")
	String entityName;
	
	@SerializedName("Errorlog")
	String errorlog;
	

	
	

	public String getAuditId() {
		return auditId;
	}

	public void setAuditId(String auditId) {
		this.auditId = auditId;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(String timestamp) {
		this.timestamp = timestamp;
	}

	public String getEntityName() {
		return entityName;
	}

	public void setEntityName(String entityName) {
		this.entityName = entityName;
	}

	public String getErrorlog() {
		return errorlog;
	}

	public void setErrorlog(String errorlog) {
		this.errorlog = errorlog;
	}

	public String getTemplateName() {
		return templateName;
	}

	public void setTemplateName(String templateName) {
		this.templateName = templateName;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getTemplateId() {
		return templateId;
	}

	public void setTemplateId(String templateId) {
		this.templateId = templateId;
	}

	

}
