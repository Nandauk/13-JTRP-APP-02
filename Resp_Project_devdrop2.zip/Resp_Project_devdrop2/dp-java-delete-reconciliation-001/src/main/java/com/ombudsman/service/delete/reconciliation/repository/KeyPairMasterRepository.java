package com.ombudsman.service.delete.reconciliation.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.ombudsman.service.delete.reconciliation.model.KeyPairMasterData;

public interface KeyPairMasterRepository  extends JpaRepository<KeyPairMasterData, Integer> {
	
	@Query(value = "select id from dp_key_pair_master_data where data_source_name=:dataSourceName and item_value=:status", nativeQuery = true)
	int getCurrentStatusCId(@Param("dataSourceName") String dataSourceName, String status);
	
	@Query(value = "select id from dp_key_pair_master_data where data_source_name=:dataSourceName and item_value=:inProgress", nativeQuery = true)
	int getCurrentStatusIPId(String dataSourceName,String inProgress);
}
