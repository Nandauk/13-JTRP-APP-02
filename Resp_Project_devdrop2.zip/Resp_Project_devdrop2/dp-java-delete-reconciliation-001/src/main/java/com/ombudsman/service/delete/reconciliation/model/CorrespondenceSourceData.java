package com.ombudsman.service.delete.reconciliation.model;

import java.util.UUID;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.transaction.Transactional;

@Entity
@Table(name = "d_correspondencesource")
@Transactional
@JsonIgnoreProperties(ignoreUnknown = true)
public class CorrespondenceSourceData extends BaseEntity {

	@Id
	@Column(name = "fos_corespondencesourceid")
	private UUID fosCorespondencesourceId;

	
	public UUID getFosCorespondencesourceId() {
		return fosCorespondencesourceId;
	}

	public void setFosCorespondencesourceId(UUID fosCorespondencesourceId) {
		this.fosCorespondencesourceId = fosCorespondencesourceId;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((fosCorespondencesourceId == null) ? 0 : fosCorespondencesourceId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CorrespondenceSourceData other = (CorrespondenceSourceData) obj;
		if (fosCorespondencesourceId == null) {
			if (other.fosCorespondencesourceId != null)
				return false;
		} else if (!fosCorespondencesourceId.equals(other.fosCorespondencesourceId))
			return false;
		return true;
	}

	
	

}
