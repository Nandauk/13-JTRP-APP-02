package com.ombudsman.service.delete.reconciliation.model;

import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.transaction.Transactional;
@Entity
@Table(name = "dp_job_master")
@Transactional
public class JobMaster {
	
	@Column(name="job_id")
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int jobId;
	@Column(name="endpoint_name")
	private String endpointName;
	@Column(name="service_name")
	private String serviceName;
	@Column(name="schedule_type")
	private String scheduleType;
	@Column(name="cron_expression")
	private String cronExpression;
	@Column(name="job_description")
	private String jobDescription;
	@Column(name="job_activestatus")
	private String jobActivestatus;
	@Column(name="created_on")
	
	private LocalDateTime createdOn;
	@Column(name="created_by")
	private String createdBy;
	@Column(name="modified_on")
	private LocalDateTime modifiedOn;
	@Column(name="modified_by")
	private String modifiedBy;
	public int getJobId() {
		return jobId;
	}
	public void setJobId(int jobId) {
		this.jobId = jobId;
	}
	public String getEndpointName() {
		return endpointName;
	}
	public void setEndpointName(String endpointName) {
		this.endpointName = endpointName;
	}
	public String getServiceName() {
		return serviceName;
	}
	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}
	public String getScheduleType() {
		return scheduleType;
	}
	public void setScheduleType(String scheduleType) {
		this.scheduleType = scheduleType;
	}
	public String getCronExpression() {
		return cronExpression;
	}
	public void setCronExpression(String cronExpression) {
		this.cronExpression = cronExpression;
	}
	public String getJobDescription() {
		return jobDescription;
	}
	public void setJobDescription(String jobDescription) {
		this.jobDescription = jobDescription;
	}
	public String getJobActivestatus() {
		return jobActivestatus;
	}
	public void setJobActivestatus(String jobActivestatus) {
		this.jobActivestatus = jobActivestatus;
	}
	public LocalDateTime getCreatedOn() {
		return createdOn;
	}
	public void setCreatedOn(LocalDateTime createdOn) {
		this.createdOn = createdOn;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public LocalDateTime getModifiedOn() {
		return modifiedOn;
	}
	public void setModifiedOn(LocalDateTime modifiedOn) {
		this.modifiedOn = modifiedOn;
	}
	public String getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	
	


}
