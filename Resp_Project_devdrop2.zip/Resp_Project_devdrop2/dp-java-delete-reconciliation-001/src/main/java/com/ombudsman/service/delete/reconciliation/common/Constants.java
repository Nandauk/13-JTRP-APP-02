package com.ombudsman.service.delete.reconciliation.common;

import java.util.Arrays;
import java.util.List;

public final class Constants {

    private Constants() {
    // restrict instantiation
    }
    public static final String DATE_FORMAT="yyyy-MM-dd HH:mm:ss.SSSSSSS";
    public static final String SLASH = "/";
    public static final String DATASOURCE_NAME = "RCON_DELETE_JOB";
    public static final String DATASOURCE_SCH = "SCH";
    public static final String COMPLETED = "Completed";
    public static final String IN_PROGRESS = "In_Progress";
    public static final String FAILED="Failed";
    public static final String DIGITALMESSAGE_ENTITY = "DIGITALMESSAGE_ENTITY";
    public static final String CUSTOMERADDRESS_ENTITY="CUSTOMERADDRESS_ENTITY";
    public static final String INCIDENT_ENTITY = "INCIDENT_ENTITY";
    public static final String CONTACT_ENTITY = "CONTACT_ENTITY";
    public static final String EMAIL_ENTITY = "EMAIL_ENTITY";
    public static final String CORREPONDENCE_ENTITY = "CORRESPONDENCE_ENTITY";
    public static final String CORRESPONDENCE_SOURCE_ENTITY ="CORRESPONDENCESOURCE_ENTITY";
    public static final String ACCOUNT_ENTITY = "ACCOUNT_ENTITY";
    public static final String USER_ENTITY = "USER_ENTITY";
    public static final String CASECONSIDERATION_ENTITY = "CASECONSIDERATION_ENTITY";
    public static final String OFFEROUTCOME_ENTITY = "OFFEROUTCOME_ENTITY";
    public static final String PHONE_ENTITY = "PHONE_ENTITY";
    public static final String PORTAL_ENTITY ="PORTAL_ENTITY";
    public static final String TASK_ENTITY = "TASK_ENTITY";
    public static final String ACCOUNT_CODE="1";
    public static final String USER_CODE="8";
    public static final String OFFEROUTCOME_CODE="10408";
    public static final String PHONE_CODE="4210";
    public static final String PORTAL_CODE="11364";
    public static final String TASK_CODE="4212";
    public static  final String ERROR_LOG = "SQL_SP_001";
    public static final String INCIDENT_CODE="112";
    public static final String CASELINK_CODE="10384";
    public static final String CONTACT_CODE="2";
    public static final String EMAIL_CODE="4202";
    public static final String CORRESPONDENCE_CODE="10390";
    public static final String CORRESPONDENCE_SOURCE_CODE="10392";
    public static final String CASECONSIDERATTION_CODE="10383";
    public static final String DIGITALMESSAGE_CODE ="12002";
    public static final String CUSTOMERADDRESS_CODE="1071";
    public static final String CASELINK_ENTITY="CASELINK_ENTITY";
    public static final String LETTER_ENTITY="LETTER_ENTITY";
    public static final String LETTER_CODE="4207";
    public static final String STATUS_COMPLETED="Completed";
    public static final String STATUS_READY_TO_PROCESS="Ready_To_Process";
    public static final String Error_log="Delete Submission failed";

    public static final String DELETE_SUBMISSION="DELETE_SUBMISSION";
    public static List<String> tablenames = Arrays.asList("d_contact","d_account","d_email","d_phone","d_letter","d_caselink","d_incident","d_portal","d_task","d_caseconsideration","d_correspondence","d_correspondencesource","d_offeroutcome","d_user","d_fosdigitalmessages","d_customeraddress");
    public static final String TEMPLATE_NAME="Delete-Reconciliation-Job";
    public static final String ERROR_NOTIFICATION="Delete_Reconciliation_Job_Error_Notification";
    public static final String FROM_EMAIL="No-Reply@DigitalSelfServe.Financial-Ombudsman.org.uk";
    public static final String TIME_FOR_INSERTION="Time for insertion: %s";
    public static final String STARTED_CATCH_BLOCK= "STARTED in CATCH BLOCK for : %s";
    public static final String DELETE_RECON_JOB_FINISHED="delete recon job finished : %s,  from Catch block at: %s";
    public static final String TOTAL_TIME="****************Total time taken by delete recon job: %s,  till completion from catch block is: %s millisec***************";
    public static final String MAIL_THREAD="mail thread started  : %s";
   
    public static final String INSERT_INTO_ERROR= "Insert into Error table started";
    public static final String DATA_PAYLOAD="Not applicable, Failed at phoenix side for delete reconciliation";
    public static final String JOB_FAILED= "Job failed for ";
    public static final String JOB_COMPLETED="Job completed for entity: %s";
    public static final String DATA_RESPONSE="data response : %s, for : %s";
    public static final String CODE_ENDED="Code ended for: %s , at : %s";
    public static final String TOTAL_TIME_TAKEN= "***************Total time taken for: %s,  by all operations : %s";
    public static final String UNKNOWN_TYPE="unknown entity type: ";
    public static final String TOTAL_TIME_TAKEN_PHENOIX_CALL= "***************Total time taken for: %s,  by Phoenix call is : %s milliseconds ";
    public static final String TOTAL_RECORDS="Total recs extracted for: %s,  from Phoenix call are : %s";
    
    public static final String OBJECTID_VALUE= "_objectid_value";
    public static final String  CREATED_ON="createdon";
    public static final String UPDATE_MAXMODIFIEDON= "Update in maxModifedOn call started: %s %s";
    public static final String DELETE_JOB_STORE_PROCEDURE="Delete Job Stored procedure call started: %s";
    public static final String RESPONDENT_DELETE_CODE= "RESPONDENT_DELETE_2000";
    public static final String AZURE_SERVICE_BUS_CONNECTIVITY= "api.error.AzureServiceBusconnectivity";
    
    public static final String FAILEDMESSAGE="Some jobs are in FAILED STATE so exiting, please have a look";

}


