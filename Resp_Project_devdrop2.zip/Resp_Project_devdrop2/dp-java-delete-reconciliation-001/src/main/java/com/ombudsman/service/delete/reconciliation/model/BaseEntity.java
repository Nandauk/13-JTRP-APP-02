package com.ombudsman.service.delete.reconciliation.model;
import java.util.UUID;

import jakarta.persistence.Column;
import jakarta.persistence.MappedSuperclass;

@MappedSuperclass
public abstract class BaseEntity {
	

    @Column(name="delete_datetime", insertable = false, updatable = false)
    private String deleteDatetime;

    @Column(name="incremental_data_load_job_audit_id")
    private UUID incrementalDataLoadJobAuditId;

    public UUID getIncrementalDataLoadJobAuditId() {
        return incrementalDataLoadJobAuditId;
    }

    public void setIncrementalDataLoadJobAuditId(UUID incrementalDataLoadJobAuditId) {
        this.incrementalDataLoadJobAuditId = incrementalDataLoadJobAuditId;
    }

    public String getDeleteDatetime() {
        return deleteDatetime;
    }

    public void setDeleteDatetime(String deleteDatetime) {
        this.deleteDatetime = deleteDatetime;
    }

   
}