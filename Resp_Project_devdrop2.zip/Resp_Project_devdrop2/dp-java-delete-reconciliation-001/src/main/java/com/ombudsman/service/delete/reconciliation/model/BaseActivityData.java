package com.ombudsman.service.delete.reconciliation.model;

import java.util.UUID;

import jakarta.persistence.Id;
import jakarta.persistence.MappedSuperclass;
@MappedSuperclass
public class BaseActivityData extends BaseEntity {
    @Id
    private UUID activityid;

    public UUID getActivityid() {
        return activityid;
    }

    public void setActivityid(UUID activityid) {
        this.activityid = activityid;
    }

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((activityid == null) ? 0 : activityid.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		BaseActivityData other = (BaseActivityData) obj;
		if (activityid == null) {
			if (other.activityid != null)
				return false;
		} else if (!activityid.equals(other.activityid))
			return false;
		return true;
	} 
    
    

}
