package com.ombudsman.service.delete.reconciliation.common;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

import okhttp3.Request;

@Configuration
public class PhoenixHelper {
	//@SuppressWarnings("unused")
	private static final String API_ERROR_PHOENIXCONNECTIVITY = "api.error.phoenixconnectivity";

	@Value("${Start_time}")
	public String startTime;
	
	@Value("${flag_deleteAccountFromAD}")
	public String flag_deleteAccountFromAD;
	
	@Value("${flag_deleteContactFromAD}")
	public String flag_deleteContactFromAD;

	@Value("${End_time}")
	public String endTime;
	@Value("${apim.host}")
	public String pheonixHost;
	@Value("${offboardServiceBusfullyQualifiedNamespace}")
	public String offboardServiceBusfullyQualifiedNamespace;
	@Value("${offboardqueueName}")
	public String offboardqueueName;
	@Value("${servicbustenantId}")
	public String servicbustenantId;
	@Value("${servicbusclientId}")
	public String servicbusclientId;

	@Value("${servicebussecretId}")
	public String servicebussecretId;

	@Value("${Fetch_Record}")
	public int fetchRecord;
	
	@Value("${TEMPLATE_ID}")
	public String templateId;
	@Value("${To_Email}")
	public String toEmail;
	@Value("${MAILJET_URL}")
	public String mailJetUrl;
	@Value("${connection_timeout}")
	public long connectionTimeout;
	@Value("${read_timeout}")
	public long readTimeout;



	

	public Request getPhoenixRequestBuild(String httpUrl) {
		return new Request.Builder().url(httpUrl).get().addHeader("OData-MaxVersion", "4.0")
				.addHeader("OData-Version", "4.0").addHeader("Accept", "application/json")
				.addHeader("Content-Type", "application/json; charset=utf-8")
				.addHeader("Prefer", "odata.include-annotations=\"*\"")
				.addHeader("cache-control", "no-cache").build();
	}

	
	
	
	public String getFetchXML(String entityname, String jobEndTime, String lastUpdatedDate,int fetchxmlrecord,String pagingCookie, int page) {
		
		StringBuilder fetchXml = new StringBuilder(
				"<fetch version='1.0' mapping='logical' count='" + fetchxmlrecord + "' page='" + page + "' ><entity name='audit'>");
		fetchXml.append(
				"<attribute name='objecttypecode'/><attribute name='operation'/><attribute name='createdon'/><attribute name='objectid'/>");
		fetchXml.append("<filter><condition attribute='objecttypecode' operator='eq' value='" + entityname + "'/>");
		fetchXml.append("<condition attribute='operation' operator='eq' value='3'/>");
		fetchXml.append("<condition attribute='createdon' operator='gt' value='" + lastUpdatedDate + "'/>");
		fetchXml.append("<condition attribute='createdon' operator='le' value='" + jobEndTime + "'/>");
		fetchXml.append("</filter>");
		fetchXml.append("<order attribute='objectid'/>");
		fetchXml.append("</entity></fetch>");
		
		if (pagingCookie != null) {
			
			String fetchXmlStr = fetchXml.toString();
			fetchXmlStr = fetchXmlStr.replace("fetch ", "fetch paging-cookie='" + pagingCookie + "' ");
			fetchXml = new StringBuilder(fetchXmlStr);

			}
			return fetchXml.toString();
	}




	public String getStartTime() {
		return startTime;
	}




	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}




	public String getEndTime() {
		return endTime;
	}




	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}




	public String getPheonixHost() {
		return pheonixHost;
	}




	public void setPheonixHost(String pheonixHost) {
		this.pheonixHost = pheonixHost;
	}




	public int getFetchRecord() {
		return fetchRecord;
	}




	public void setFetchRecord(int fetchRecord) {
		this.fetchRecord = fetchRecord;
	}




	public String getTemplateId() {
		return templateId;
	}




	public void setTemplateId(String templateId) {
		this.templateId = templateId;
	}




	public String getToEmail() {
		return toEmail;
	}




	public void setToEmail(String toEmail) {
		this.toEmail = toEmail;
	}




	public String getMailJetUrl() {
		return mailJetUrl;
	}




	public void setMailJetUrl(String mailJetUrl) {
		this.mailJetUrl = mailJetUrl;
	}
	
	public long getConnectionTimeout() {
		return connectionTimeout;
	}




	public void setConnectionTimeout(long connectionTimeout) {
		this.connectionTimeout = connectionTimeout;
	}




	public long getReadTimeout() {
		return readTimeout;
	}




	public void setReadTimeout(long readTimeout) {
		this.readTimeout = readTimeout;
	}



	
}
