package com.ombudsman.service.delete.reconciliation.model;

import java.util.UUID;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.transaction.Transactional;

@Entity
@Table(name = "d_user")
@Transactional
@JsonIgnoreProperties(ignoreUnknown = true)
public class UserData extends BaseEntity {

	@Id
	private UUID systemuserid;
	
	public UUID getSystemuserid() {
		return systemuserid;
	}

	public void setSystemuserid(UUID systemuserid) {
		this.systemuserid = systemuserid;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((systemuserid == null) ? 0 : systemuserid.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		UserData other = (UserData) obj;
		if (systemuserid == null) {
			if (other.systemuserid != null)
				return false;
		} else if (!systemuserid.equals(other.systemuserid))
			return false;
		return true;
	}
	
	
	}
	