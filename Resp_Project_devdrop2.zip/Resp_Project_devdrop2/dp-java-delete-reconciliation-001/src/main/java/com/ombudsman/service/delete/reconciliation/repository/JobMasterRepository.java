package com.ombudsman.service.delete.reconciliation.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.ombudsman.service.delete.reconciliation.model.JobMaster;


@Repository
public interface JobMasterRepository extends JpaRepository<JobMaster, Integer>{
	@Query(value = "select job_id from dp_job_master where created_by=:createdby", nativeQuery = true)
	int getJobID( String createdby);
	
	
	
	


}
