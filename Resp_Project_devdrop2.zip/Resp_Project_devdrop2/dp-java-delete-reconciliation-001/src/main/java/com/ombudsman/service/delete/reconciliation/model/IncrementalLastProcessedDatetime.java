package com.ombudsman.service.delete.reconciliation.model;

import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "dp_incremental_last_processed_datetime")
public class IncrementalLastProcessedDatetime {
	
	@Id
	@Column(name = "process_name")
	private String processName; 
	
	
	@Column(name = "last_processed_datetime")
    private Date  lastProcessedDatetime;


	public String getProcessName() {
		return processName;
	}


	public void setProcessName(String processName) {
		this.processName = processName;
	}


	public Date getLastProcessedDatetime() {
		return lastProcessedDatetime;
	}


	public void setLastProcessedDatetime(Date lastProcessedDatetime) {
		this.lastProcessedDatetime = lastProcessedDatetime;
	}


	
	
	
	
	

}
