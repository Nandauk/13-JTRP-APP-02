package com.ombudsman.service.delete.reconciliation.model;

import java.util.UUID;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.transaction.Transactional;
@Entity
@Table(name = "d_correspondence")
@Transactional
@JsonIgnoreProperties(ignoreUnknown = true)
public class CorrespondenceData extends BaseEntity {

	@Id
	@Column(name="fos_corespondenceid")
	private UUID fosCorespondenceId;
	
	
	 public UUID getFosCorespondenceId() {
		return fosCorespondenceId;
	}

	public void setFosCorespondenceId(UUID fosCorespondenceId) {
		this.fosCorespondenceId = fosCorespondenceId;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((fosCorespondenceId == null) ? 0 : fosCorespondenceId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CorrespondenceData other = (CorrespondenceData) obj;
		if (fosCorespondenceId == null) {
			if (other.fosCorespondenceId != null)
				return false;
		} else if (!fosCorespondenceId.equals(other.fosCorespondenceId))
			return false;
		return true;
	}
	
	
}
