package com.ombudsman.service.delete.reconciliation.repository;

import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.ombudsman.service.delete.reconciliation.model.CorrespondenceData;

public interface CorrespondenceRepository extends JpaRepository<CorrespondenceData, Integer> { 
	
	@Modifying
	@Transactional
	@Query(value = "INSERT INTO d_correspondence (fos_corespondenceid,incremental_data_load_job_audit_id) VALUES (:fos_corespondenceid,:fetchIncrementalDataLoadAuditId)", nativeQuery = true)
	int InsertQuery(@Param("fos_corespondenceid") UUID fos_corespondenceid, @Param("fetchIncrementalDataLoadAuditId") UUID fetchIncrementalDataLoadAuditId);

}
