package com.ombudsman.service.delete.reconciliation.model;

public class From extends BaseEntitySendEmail {



}
