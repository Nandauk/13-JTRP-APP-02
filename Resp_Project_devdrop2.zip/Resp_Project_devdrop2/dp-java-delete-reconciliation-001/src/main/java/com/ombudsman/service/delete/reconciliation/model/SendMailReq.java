package com.ombudsman.service.delete.reconciliation.model;

import java.util.List;

import com.google.gson.annotations.SerializedName;


public class SendMailReq {
	
	@SerializedName("Messages")
	   List<Messages> messages;


	    public void setMessages(List<Messages> messages) {
	        this.messages = messages;
	    }
	    public List<Messages> getMessages() {
	        return messages;
	    }

}
