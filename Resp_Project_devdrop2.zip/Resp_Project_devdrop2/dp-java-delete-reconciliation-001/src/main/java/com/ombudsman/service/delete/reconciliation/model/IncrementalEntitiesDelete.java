package com.ombudsman.service.delete.reconciliation.model;

import java.util.UUID;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.transaction.Transactional;

@Entity
@Table(name = "dp_incremental_entities_delete")
@Transactional
public class IncrementalEntitiesDelete {
	
	@Id
	@Column(name = "id")
	private UUID id; 
	
	@Column(name = "auditid")
	private UUID incrementalDataLoadAuditId; 
	
	
	@Column(name = "entityname")
    private String entityName;

    @Column(name = "status")
    private String status;

    @Column(name = "datetimestamp")
    private String dateTimeStamp;

	public UUID getId() {
		return id;
	}

	public void setId(UUID id) {
		this.id = id;
	}

	public UUID getIncrementalDataLoadAuditId() {
		return incrementalDataLoadAuditId;
	}

	public void setIncrementalDataLoadAuditId(UUID incrementalDataLoadAuditId) {
		this.incrementalDataLoadAuditId = incrementalDataLoadAuditId;
	}

	public String getEntityName() {
		return entityName;
	}

	public void setEntityName(String entityName) {
		this.entityName = entityName;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getDateTimeStamp() {
		return dateTimeStamp;
	}

	public void setDateTimeStamp(String dateTimeStamp) {
		this.dateTimeStamp = dateTimeStamp;
	}

	

   


}
