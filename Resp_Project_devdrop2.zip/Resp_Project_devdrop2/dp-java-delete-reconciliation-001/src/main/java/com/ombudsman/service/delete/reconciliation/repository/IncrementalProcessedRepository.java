package com.ombudsman.service.delete.reconciliation.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.ombudsman.service.delete.reconciliation.model.IncrementalLastProcessedDatetime;

@Repository
public interface IncrementalProcessedRepository extends JpaRepository<IncrementalLastProcessedDatetime, String>{

	@Query(value = "select cast(last_processed_datetime as DATETIME2(0)) as lpd from dp_incremental_last_processed_datetime where process_name='RCON_DELETE_JOB';", nativeQuery = true)
	String getLatestProcessedDatetime();
	
}
