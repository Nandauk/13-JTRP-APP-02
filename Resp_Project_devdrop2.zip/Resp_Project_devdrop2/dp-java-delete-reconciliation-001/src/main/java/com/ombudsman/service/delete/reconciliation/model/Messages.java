package com.ombudsman.service.delete.reconciliation.model;

import java.util.List;

import com.google.gson.annotations.SerializedName;

public class Messages {
	
	@SerializedName("From")
	private From from;

	@SerializedName("To")
	private List<To> to;

	@SerializedName("TemplateID")
	private int templateID;

	@SerializedName("TemplateLanguage")
	private boolean templateLanguage;

	
	@SerializedName("Variables")
	MailjetVariables mailJetVar;
	


	public MailjetVariables getMailJetVar() {
		return mailJetVar;
	}

	public void setMailJetVar(MailjetVariables mailJetVar) {
		this.mailJetVar = mailJetVar;
	}

	public void setFrom(From from) {
		this.from = from;
	}

	public From getFrom() {
		return from;
	}

	public void setTo(List<To> to) {
		this.to = to;
	}

	public List<To> getTo() {
		return to;
	}

	public int getTemplateID() {
		return templateID;
	}

	public void setTemplateID(int templateID) {
		this.templateID = templateID;
	}

	public void setTemplateLanguage(boolean templateLanguage) {
		this.templateLanguage = templateLanguage;
	}

	public boolean getTemplateLanguage() {
		return templateLanguage;
	}


}
