package com.ombudsman.service.delete.reconciliation.model;

import java.util.UUID;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.transaction.Transactional;

@Entity
@Table(name = "d_incident")
@Transactional
@JsonIgnoreProperties(ignoreUnknown = true)
public class IncidentData extends BaseEntity{

	@Id
	private UUID incidentid;
	

	
	public UUID getIncidentid() {
		return incidentid;
	}

	public void setIncidentid(UUID incidentid) {
		this.incidentid = incidentid;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((incidentid == null) ? 0 : incidentid.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		IncidentData other = (IncidentData) obj;
		if (incidentid == null) {
			if (other.incidentid != null)
				return false;
		} else if (!incidentid.equals(other.incidentid))
			return false;
		return true;
	}
	
	


	 
}
