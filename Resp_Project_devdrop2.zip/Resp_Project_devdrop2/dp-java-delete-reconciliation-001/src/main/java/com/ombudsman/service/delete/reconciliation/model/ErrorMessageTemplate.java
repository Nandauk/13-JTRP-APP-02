package com.ombudsman.service.delete.reconciliation.model;

import java.time.Instant;

import com.ombudsman.service.delete.reconciliation.common.Constants;

public class ErrorMessageTemplate extends BaseTemplate {


	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	String errorMessage;
	String errorTimestamp;

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public String getErrorTimestamp() {
		return errorTimestamp;
	}

	public void setErrorTimestamp(String errorTimestamp) {
		this.errorTimestamp = errorTimestamp;
	}

	
	
	
	 public static ErrorMessageTemplate setErrorMessage(String message, String entity, String auditId) {
	        String errorTimestamp = Instant.now().toString();
	        ErrorMessageTemplate errorMessageTemplate = new ErrorMessageTemplate();
	        errorMessageTemplate.setRole("Delete-Reconciliation Job");
	        errorMessageTemplate.setTemplateName(Constants.TEMPLATE_NAME);
	        errorMessageTemplate.setErrorTimestamp(errorTimestamp);
	        errorMessageTemplate.setErrorMessage(message);
	        errorMessageTemplate.setEntityName(entity);
	        errorMessageTemplate.setAuditId(auditId);
	        return errorMessageTemplate;
	    }
	
}
