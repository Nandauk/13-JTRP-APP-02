package com.ombudsman.service.delete.reconciliation.exception;

public class ServiceExceptions extends RuntimeException {

	private static final long serialVersionUID = 1L;
	private final String code;
	private final String message;


	public ServiceExceptions(String message, String code) {
		super(message);

		this.code = code;
		this.message = message;

	}

	public String getCode() {
		return code;
	}

	@Override
	public String getMessage() {
		return message;
	}

}
