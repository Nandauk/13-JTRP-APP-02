package com.ombudsman.service.delete.reconciliation.model;

import java.util.UUID;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.transaction.Transactional;

@Entity
@Table(name = "d_customeraddress")
@Transactional
@JsonIgnoreProperties(ignoreUnknown = true)
public class CustomeraddressData extends BaseEntity {
	
	@Id
	private UUID customeraddressid;

	public UUID getCustomeraddressid() {
		return customeraddressid;
	}

	public void setCustomeraddressid(UUID customeraddressid) {
		this.customeraddressid = customeraddressid;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + ((customeraddressid == null) ? 0 : customeraddressid.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		CustomeraddressData other = (CustomeraddressData) obj;
		if (customeraddressid == null) {
			if (other.customeraddressid != null)
				return false;
		} else if (!customeraddressid.equals(other.customeraddressid))
			return false;
		return true;
	}
	
	
	
}
