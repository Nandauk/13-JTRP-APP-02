package com.ombudsman.service.delete.reconciliation.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.ombudsman.service.delete.reconciliation.model.CaselinkData;
@Repository
public interface DeleteReconciliationRepository extends JpaRepository<CaselinkData, String> {


	@Modifying
	@Transactional
	@Query(value = "INSERT INTO d_caselink(fos_caselinkid,incremental_data_load_job_audit_id) VALUES(?,?)", nativeQuery = true)
	void updateStgToBaseTable(@Param("Fetch_IncrementalDataLoadAuditId") String fetchIncrementalDataLoadAuditId);


}
