package com.ombudsman.service.delete.reconciliation.repository;

import java.util.UUID;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.ombudsman.service.delete.reconciliation.model.IncrementalEntitiesDelete;

public interface IncrementalEntityDeleteRepository extends JpaRepository<IncrementalEntitiesDelete, UUID>{
	
	@Modifying
	@Transactional
	@Query(value = "INSERT INTO dp_incremental_entities_delete(id,auditid,entityName,status) VALUES (:id,:incrementalDataLoadAuditId,:entityName,:status)", nativeQuery = true)
	int InsertQuery(@Param("id") UUID id, @Param("incrementalDataLoadAuditId") UUID incrementalDataLoadAuditId,
			@Param("entityName") String entityName,@Param("status") String status);
			


}
