package com.ombudsman.service.delete.reconciliation.model;

import java.util.Date;
import java.util.UUID;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.transaction.Transactional;

@Entity
@Table(name = "dp_incremental_load_error")
@Transactional
public class IncreLoadErrorData extends BaseEntityIncrementalAuditLoad implements IncrementalDataLoadAuditInterface {

	@Id
	@GeneratedValue(generator = "uuid2")
	@Column(name = "incremental_data_load_error_id")
	private UUID incrementalDataLoadErrorId;

	@Column(name = "incremental_data_load_audit_id")
	private String incrementalDataLoadAuditId;
	@Column(name = "data_pay_load")
	private String dataPayLoad;

	@Column(name = "error_created_datetime")
	private Date errorCreatedDatetime;

	@Column(name = "current_error_status_id")
	private Long currentErrorStatusId;

	@Column(name = "error_code")
	private String errorCode;

	@Column(name = "error_log")
	private String errorLog;

	public UUID getIncrementalDataLoadErrorId() {
		return incrementalDataLoadErrorId;
	}

	public void setIncrementalDataLoadErrorId(UUID incrementalDataLoadErrorId) {
		this.incrementalDataLoadErrorId = incrementalDataLoadErrorId;
	}

	public String getDataPayLoad() {
		return dataPayLoad;
	}

	public void setDataPayLoad(String dataPayLoad) {
		this.dataPayLoad = dataPayLoad;
	}

	public Date getErrorCreatedDatetime() {
		return errorCreatedDatetime;
	}

	public void setErrorCreatedDatetime(Date errorCreatedDatetime) {
		this.errorCreatedDatetime = errorCreatedDatetime;
	}

	public Long getCurrentErrorStatusId() {
		return currentErrorStatusId;
	}

	public void setCurrentErrorStatusId(Long currentErrorStatusId) {
		this.currentErrorStatusId = currentErrorStatusId;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getErrorLog() {
		return errorLog;
	}

	public void setErrorLog(String errorLog) {
		this.errorLog = errorLog;
	}


	
	@Override
	public String getIncrementalDataLoadAuditId() {

		return this.incrementalDataLoadAuditId;
	}

	@Override
	public void setIncrementalDataLoadAuditId(String incrementalDataLoadAuditId) {
		this.incrementalDataLoadAuditId = incrementalDataLoadAuditId;
		
	}


}
