package com.ombudsman.service.delete.reconciliation.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.transaction.Transactional;
@Entity
@Table(name = "dp_incremental_data_load_job_audit")
@Transactional
public class IncreLoadAuditData extends BaseEntityIncrementalAuditLoad implements IncrementalDataLoadAuditInterface{

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "incremental_data_load_audit_id")
	private String incrementalDataLoadAuditId; 
	
	
	@Column(name = "job_id")
    private Integer jobId;

    @Column(name = "job_start_date_time")
    private String jobStartDatetime;

    @Column(name = "total_number_of_records")
    private Integer totalNumberOfRecords;

    @Column(name = "number_of_processed_record")
    private Integer numberOfProcessedRecord;

    @Column(name = "number_of_failed_record")
    private Integer numberOfFailedRecord;

    @Column(name = "current_job_status_id")
    private Integer currentJobStatusId;

    @Column(name = "job_close_datetime")
    private String jobCloseDatetime;

    @Column(name = "next_job_run_datetime")
    private String nextJobRunDatetime;

    @Column(name = "source")
    private String source;



	public Integer getJobId() {
		return jobId;
	}

	public void setJobId(Integer jobId) {
		this.jobId = jobId;
	}

	public String getJobStartDatetime() {
		return jobStartDatetime;
	}

	public void setJobStartDatetime(String jobStartDatetime) {
		this.jobStartDatetime = jobStartDatetime;
	}

	public Integer getTotalNumberOfRecords() {
		return totalNumberOfRecords;
	}

	public void setTotalNumberOfRecords(Integer totalNumberOfRecords) {
		this.totalNumberOfRecords = totalNumberOfRecords;
	}

	public Integer getNumberOfProcessedRecord() {
		return numberOfProcessedRecord;
	}

	public void setNumberOfProcessedRecord(Integer numberOfProcessedRecord) {
		this.numberOfProcessedRecord = numberOfProcessedRecord;
	}

	public Integer getNumberOfFailedRecord() {
		return numberOfFailedRecord;
	}

	public void setNumberOfFailedRecord(Integer numberOfFailedRecord) {
		this.numberOfFailedRecord = numberOfFailedRecord;
	}

	public Integer getCurrentJobStatusId() {
		return currentJobStatusId;
	}

	public void setCurrentJobStatusId(Integer currentJobStatusId) {
		this.currentJobStatusId = currentJobStatusId;
	}

	public String getJobCloseDatetime() {
		return jobCloseDatetime;
	}

	public void setJobCloseDatetime(String jobCloseDatetime) {
		this.jobCloseDatetime = jobCloseDatetime;
	}

	public String getNextJobRunDatetime() {
		return nextJobRunDatetime;
	}

	public void setNextJobRunDatetime(String nextJobRunDatetime) {
		this.nextJobRunDatetime = nextJobRunDatetime;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	
	@Override
	public String getIncrementalDataLoadAuditId() {

		return this.incrementalDataLoadAuditId;
	}

	@Override
	public void setIncrementalDataLoadAuditId(String incrementalDataLoadAuditId) {
		this.incrementalDataLoadAuditId = incrementalDataLoadAuditId;
		
	}

	
	

}
