package com.ombudsman.service.delete.reconciliation.model;

import java.util.UUID;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.transaction.Transactional;
@Entity
@Table(name = "d_caselink")
@Transactional
@JsonIgnoreProperties(ignoreUnknown = true)
public class CaselinkData extends BaseEntity{
	

	@Id
	@Column(name="fos_caselinkid")
	private UUID foscaselinkId;
	
	
	
	public UUID getFoscaselinkId() {
		return foscaselinkId;
	}

	public void setFoscaselinkId(UUID foscaselinkId) {
		this.foscaselinkId = foscaselinkId;
	}

}
