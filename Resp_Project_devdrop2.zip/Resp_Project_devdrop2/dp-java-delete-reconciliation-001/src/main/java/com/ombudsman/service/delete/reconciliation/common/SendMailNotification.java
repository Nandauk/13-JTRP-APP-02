package com.ombudsman.service.delete.reconciliation.common;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONException;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.WebClient;

import com.google.gson.Gson;
import com.ombudsman.service.delete.reconciliation.exception.MailJetServiceException;
import com.ombudsman.service.delete.reconciliation.model.ErrorMessageTemplate;
import com.ombudsman.service.delete.reconciliation.model.From;
import com.ombudsman.service.delete.reconciliation.model.MailjetResponseBody;
import com.ombudsman.service.delete.reconciliation.model.MailjetVariables;
import com.ombudsman.service.delete.reconciliation.model.Messages;
import com.ombudsman.service.delete.reconciliation.model.SendMailReq;
import com.ombudsman.service.delete.reconciliation.model.To;

@Service
public class SendMailNotification {
	private static final Logger log = LogManager.getLogger(SendMailNotification.class);
	private static final boolean TRUE = true;

	PhoenixHelper phoenixHelper;

	public SendMailNotification(PhoenixHelper phoenixHelper) {
		super();
		this.phoenixHelper = phoenixHelper;
	}

	public void sendErrorNotificationToUserWebclient(ErrorMessageTemplate errorMessageTemplate) {

		try {
			log.info("SendMailReq code started....");
			SendMailReq sendMailReq = new SendMailReq();
			MailjetVariables mailJetVar = new MailjetVariables();
			Messages message = new Messages();
			List<To> to = new ArrayList<>();
			List<Messages> sendmessage = new ArrayList<>();
			To to1 = new To();
			to1.setEmail(phoenixHelper.getToEmail());
			to1.setName(Constants.TEMPLATE_NAME);
			to.add(to1);

			mailJetVar.setRole(errorMessageTemplate.getRole());
			mailJetVar.setTemplateId(errorMessageTemplate.getTemplateId());
			mailJetVar.setTemplateName(errorMessageTemplate.getTemplateName());
			mailJetVar.setEntityName(errorMessageTemplate.getEntityName());
			mailJetVar.setAuditId(errorMessageTemplate.getAuditId());
			mailJetVar.setErrorlog(errorMessageTemplate.getErrorMessage());
			mailJetVar.setTemplateId(errorMessageTemplate.getTemplateId());
			mailJetVar.setSource(errorMessageTemplate.getTemplateName());
			mailJetVar.setTimestamp(Instant.now().toString());
			message.setMailJetVar(mailJetVar);
			message.setTemplateID(Integer.parseInt(mailJetVar.getTemplateId()));
			message.setTemplateLanguage(TRUE);
			message.setTo(to);
			From from = new From();
			from.setEmail(Constants.FROM_EMAIL);
			from.setName(Constants.ERROR_NOTIFICATION);
			message.setFrom(from);
			sendmessage.add(message);
			sendMailReq.setMessages(sendmessage);

			String response = send(sendMailReq);

			log.info(String.format("sendMailReq response: %s", response));

			if (response.equals("success")) {
				log.info(String.format("MailJet API call success: %s", response));
			} else {
				log.info(String.format("MailJet API call failed: %s", response));
			}
			log.info("SendMailReq code  ended...");
		} catch (Exception e) {
			log.error(String.format("Error in Method SendMailReq: %s", e.getMessage()));
		}
	}

	public String send(SendMailReq req) throws JSONException {
		log.info("Mailjet Send request method started");
		Gson gson = new Gson();
		String json = gson.toJson(req);
		MailjetResponseBody responseBody = new MailjetResponseBody();
		String status = null;
		log.info(String.format("Request data: %s", json));

		log.info(String.format("mailjet URL: %s", phoenixHelper.getMailJetUrl()));

		try {

			responseBody = WebClient.create().post().uri(phoenixHelper.getMailJetUrl())
					.body(BodyInserters.fromValue(json)).accept(MediaType.APPLICATION_JSON).retrieve()
					.bodyToMono(MailjetResponseBody.class).block();
			if (responseBody != null) {
				status = responseBody.getMessages().get(0).getStatus();
				log.info(String.format("Response status: %s", status));
			}
		} catch (Exception ex) {
			throw new MailJetServiceException("Mailjet Exception occured", ex.getMessage());
		}

		log.info(String.format("Response : %s", responseBody));
		if (null != responseBody) {
			status = responseBody.getMessages().get(0).getStatus();
		}

		return status;

	}

}
