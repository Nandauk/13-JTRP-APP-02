package com.ombudsman.service.delete.reconciliation.exception;

public class JobFailedException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public JobFailedException(String message, String originalMessage) {
		super(message + ": " + originalMessage);

	}

	
}