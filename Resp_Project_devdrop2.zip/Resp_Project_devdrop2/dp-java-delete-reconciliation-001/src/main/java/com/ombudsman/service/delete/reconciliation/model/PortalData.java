package com.ombudsman.service.delete.reconciliation.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import jakarta.transaction.Transactional;

@Entity
@Table(name = "d_portal")
@Transactional
@JsonIgnoreProperties(ignoreUnknown = true)
public class PortalData extends BaseActivityData{

	
	
}
	