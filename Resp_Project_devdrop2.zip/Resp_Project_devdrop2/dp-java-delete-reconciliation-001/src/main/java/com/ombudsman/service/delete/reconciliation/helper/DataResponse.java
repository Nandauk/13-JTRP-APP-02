package com.ombudsman.service.delete.reconciliation.helper;

import java.util.ArrayList;
import java.util.List;

import com.ombudsman.service.delete.reconciliation.model.AccountData;
import com.ombudsman.service.delete.reconciliation.model.CaseconsiderationData;
import com.ombudsman.service.delete.reconciliation.model.CaselinkData;
import com.ombudsman.service.delete.reconciliation.model.ContactData;
import com.ombudsman.service.delete.reconciliation.model.CorrespondenceData;
import com.ombudsman.service.delete.reconciliation.model.CorrespondenceSourceData;
import com.ombudsman.service.delete.reconciliation.model.CustomeraddressData;
import com.ombudsman.service.delete.reconciliation.model.DigitalMessageData;
import com.ombudsman.service.delete.reconciliation.model.EmailData;
import com.ombudsman.service.delete.reconciliation.model.IncidentData;
import com.ombudsman.service.delete.reconciliation.model.LetterData;
import com.ombudsman.service.delete.reconciliation.model.OfferoutcomeData;
import com.ombudsman.service.delete.reconciliation.model.PhoneData;
import com.ombudsman.service.delete.reconciliation.model.PortalData;
import com.ombudsman.service.delete.reconciliation.model.TaskData;
import com.ombudsman.service.delete.reconciliation.model.UserData;



public class DataResponse {
	
	private List<AccountData> accountData= new ArrayList<>();
	private List<CaselinkData> caselinkData=new ArrayList<>();
	private List<CaseconsiderationData> caseconsiderationData=new ArrayList<>();
	private List<ContactData> contactData=new ArrayList<>();
	private List<CorrespondenceData> correspondenceData=new ArrayList<>();
	private List<CorrespondenceSourceData> correspondenceSourceData=new ArrayList<>();
	private List<EmailData> emailData=new ArrayList<>();
	private List<IncidentData> incidentData=new ArrayList<>();
	private List<LetterData> letterData=new ArrayList<>();
	private List<PhoneData> phoneData=new ArrayList<>();
	private List<PortalData> portalData=new ArrayList<>();
	private List<TaskData> taskData=new ArrayList<>();
	private List<UserData> userData=new ArrayList<>();
	private List<OfferoutcomeData> offeroutcomeData=new ArrayList<>();
	private List<DigitalMessageData> digitalMessageData=new ArrayList<>();
	private List<CustomeraddressData> customeraddressData=new ArrayList<>();
	

	public List<AccountData> getAccountData() {
		return accountData;
	}

	public void setAccountData(List<AccountData> accountData) {
		this.accountData = accountData;
	}

	public List<CaselinkData> getCaselinkData() {
		return caselinkData;
	}

	public void setCaselinkData(List<CaselinkData> caselinkData) {
		this.caselinkData = caselinkData;
	}

	public List<CaseconsiderationData> getCaseconsiderationData() {
		return caseconsiderationData;
	}

	public void setCaseconsiderationData(List<CaseconsiderationData> caseconsiderationData) {
		this.caseconsiderationData = caseconsiderationData;
	}

	public List<ContactData> getContactData() {
		return contactData;
	}

	public void setContactData(List<ContactData> contactData) {
		this.contactData = contactData;
	}

	public List<CorrespondenceData> getCorrespondenceData() {
		return correspondenceData;
	}

	public void setCorrespondenceData(List<CorrespondenceData> correspondenceData) {
		this.correspondenceData = correspondenceData;
	}

	public List<CorrespondenceSourceData> getCorrespondenceSourceData() {
		return correspondenceSourceData;
	}

	public void setCorrespondenceSourceData(List<CorrespondenceSourceData> correspondenceSourceData) {
		this.correspondenceSourceData = correspondenceSourceData;
	}

	public List<EmailData> getEmailData() {
		return emailData;
	}

	public void setEmailData(List<EmailData> emailData) {
		this.emailData = emailData;
	}

	public List<IncidentData> getIncidentData() {
		return incidentData;
	}

	public void setIncidentData(List<IncidentData> incidentData) {
		this.incidentData = incidentData;
	}

	public List<LetterData> getLetterData() {
		return letterData;
	}

	public void setLetterData(List<LetterData> letterData) {
		this.letterData = letterData;
	}

	public List<PhoneData> getPhoneData() {
		return phoneData;
	}

	public void setPhoneData(List<PhoneData> phoneData) {
		this.phoneData = phoneData;
	}

	public List<PortalData> getPortalData() {
		return portalData;
	}

	public void setPortalData(List<PortalData> portalData) {
		this.portalData = portalData;
	}

	public List<TaskData> getTaskData() {
		return taskData;
	}

	public void setTaskData(List<TaskData> taskData) {
		this.taskData = taskData;
	}

	public List<UserData> getUserData() {
		return userData;
	}

	public void setUserData(List<UserData> userData) {
		this.userData = userData;
	}

	public List<OfferoutcomeData> getOfferoutcomeData() {
		return offeroutcomeData;
	}

	public void setOfferoutcomeData(List<OfferoutcomeData> offeroutcomeData) {
		this.offeroutcomeData = offeroutcomeData;
	}

	public List<DigitalMessageData> getDigitalMessageData() {
		return digitalMessageData;
	}

	public void setDigitalMessageData(List<DigitalMessageData> digitalMessageData) {
		this.digitalMessageData = digitalMessageData;
	}

	public List<CustomeraddressData> getCustomeraddressData() {
		return customeraddressData;
	}

	public void setCustomeraddressData(List<CustomeraddressData> customeraddressData) {
		this.customeraddressData = customeraddressData;
	}
	


}
