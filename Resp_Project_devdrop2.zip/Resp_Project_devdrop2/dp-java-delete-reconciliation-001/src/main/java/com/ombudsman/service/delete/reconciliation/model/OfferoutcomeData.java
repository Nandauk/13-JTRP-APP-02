package com.ombudsman.service.delete.reconciliation.model;

import java.util.UUID;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.transaction.Transactional;

@Entity
@Table(name = "d_offeroutcome")
@Transactional
@JsonIgnoreProperties(ignoreUnknown = true)
public class OfferoutcomeData extends BaseEntity{

	@Id
	@Column(name="fos_offeroutcomeid")
	private UUID fosOfferoutcomeId;
	

	
	 public UUID getFosOfferoutcomeId() {
		return fosOfferoutcomeId;
	}

	public void setFosOfferoutcomeId(UUID fosOfferoutcomeId) {
		this.fosOfferoutcomeId = fosOfferoutcomeId;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((fosOfferoutcomeId == null) ? 0 : fosOfferoutcomeId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		OfferoutcomeData other = (OfferoutcomeData) obj;
		if (fosOfferoutcomeId == null) {
			if (other.fosOfferoutcomeId != null)
				return false;
		} else if (!fosOfferoutcomeId.equals(other.fosOfferoutcomeId))
			return false;
		return true;
	}
	
	

	
	
}
	