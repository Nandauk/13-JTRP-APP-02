package com.ombudsman.service.delete.reconciliation.services;

import java.io.IOException;
import java.time.Instant;
import java.util.UUID;

import org.json.JSONArray;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ombudsman.service.delete.reconciliation.exception.JobFailedException;
import com.ombudsman.service.delete.reconciliation.helper.DataResponse;
public interface DeletePhnxReconciliationService {
	
	

	void insertToCaseLink() throws InterruptedException,IOException ;
	void insertToIncident()throws InterruptedException,IOException;
	void insertToContact()throws InterruptedException,IOException;
	void insertToCorrespondence()throws InterruptedException,IOException;
	void insertToCorrepondenceSource()throws InterruptedException,IOException;
	void insertToEmail()throws InterruptedException,IOException;
	void insertToLetter()throws InterruptedException,IOException;
	void insertToUser()throws InterruptedException,IOException;
	void insertToAccount()throws InterruptedException,IOException;
	void insertToCaseconsideration()throws InterruptedException,IOException;
	void insertToOfferoutcome()throws InterruptedException,IOException;
	void insertToPhone()throws InterruptedException,IOException;
	void insertToPortal()throws InterruptedException,IOException;
	void insertToTask()throws InterruptedException,IOException;
	void insertToDigitalMessage()throws InterruptedException,IOException;
	void insertToCustomerAddress()throws InterruptedException,IOException;
	public void processAllJob() throws InterruptedException, JobFailedException;
	void deleteSubmission() throws IOException, InterruptedException;
	
	 void handleException(Instant startWebJob,Exception e, UUID fetchIncrementalDataLoadAuditId, 
		        Long totalCount, String entity, int failedCount);
	 void processAccountEntity(JSONArray jsonArray, boolean isLastItem, 
				UUID fetchIncrementalDataLoadAuditId, DataResponse newDataRes, String startFormmatedDate,
				ObjectMapper mapper, int i) throws IOException,InterruptedException;
	 void processIncidentEntity(JSONArray jsonArray, boolean isLastItem, 
				UUID fetchIncrementalDataLoadAuditId, DataResponse newDataRes, String startFormmatedDate,
				ObjectMapper mapper, int i) throws IOException,InterruptedException;
	 void processCaseLinkEntity(JSONArray jsonArray, boolean isLastItem, 
				UUID fetchIncrementalDataLoadAuditId, DataResponse newDataRes, String startFormmatedDate,
				ObjectMapper mapper, int i) throws IOException,InterruptedException;
	 void processContactEntity(JSONArray jsonArray, boolean isLastItem, 
				UUID fetchIncrementalDataLoadAuditId, DataResponse newDataRes, String startFormmatedDate,
				ObjectMapper mapper, int i) throws IOException ,InterruptedException;
	 void processEmailEntity(JSONArray jsonArray, boolean isLastItem, 
				UUID fetchIncrementalDataLoadAuditId, DataResponse newDataRes, String startFormmatedDate,
				ObjectMapper mapper, int i) throws IOException,InterruptedException;
	 void processCorrespondenceEntity(JSONArray jsonArray, boolean isLastItem, 
				UUID fetchIncrementalDataLoadAuditId, DataResponse newDataRes, String startFormmatedDate,
				ObjectMapper mapper, int i) throws IOException,InterruptedException;
	 void processCorrespondenceSourceEntity(JSONArray jsonArray, boolean isLastItem, 
				UUID fetchIncrementalDataLoadAuditId, DataResponse newDataRes, String startFormmatedDate,
				ObjectMapper mapper, int i) throws IOException,InterruptedException;
	 void processLetterEntity(JSONArray jsonArray, boolean isLastItem, 
				UUID fetchIncrementalDataLoadAuditId, DataResponse newDataRes, String startFormmatedDate,
				ObjectMapper mapper, int i) throws IOException,InterruptedException;
	 void processUserEntity(JSONArray jsonArray, boolean isLastItem, 
				UUID fetchIncrementalDataLoadAuditId, DataResponse newDataRes, String startFormmatedDate,
				ObjectMapper mapper, int i) throws IOException,InterruptedException;
	 void processCaseconsiderationEntity(JSONArray jsonArray, boolean isLastItem, 
				UUID fetchIncrementalDataLoadAuditId, DataResponse newDataRes, String startFormmatedDate,
				ObjectMapper mapper, int i) throws IOException,InterruptedException;
	 void processPortalEntity(JSONArray jsonArray, boolean isLastItem, 
				UUID fetchIncrementalDataLoadAuditId, DataResponse newDataRes, String startFormmatedDate,
				ObjectMapper mapper, int i) throws IOException,InterruptedException;
	 void processOfferoutcomeEntity(JSONArray jsonArray, boolean isLastItem, 
				UUID fetchIncrementalDataLoadAuditId, DataResponse newDataRes, String startFormmatedDate,
				ObjectMapper mapper, int i) throws IOException,InterruptedException;
	 void processPhoneEntity(JSONArray jsonArray, boolean isLastItem, 
					UUID fetchIncrementalDataLoadAuditId, DataResponse newDataRes, String startFormmatedDate,
					ObjectMapper mapper, int i) throws IOException,InterruptedException;
	 void processTaskEntity(JSONArray jsonArray, boolean isLastItem, 
					UUID fetchIncrementalDataLoadAuditId, DataResponse newDataRes, String startFormmatedDate,
					ObjectMapper mapper, int i) throws IOException,InterruptedException;
		  
	 void processDigitalMessageEntity(JSONArray jsonArray, boolean isLastItem,
					UUID fetchIncrementalDataLoadAuditId, DataResponse newDataRes, String startFormmatedDate,
					ObjectMapper mapper, int i) throws IOException, InterruptedException;
	 void processCustomeraddressEntity(JSONArray jsonArray, boolean isLastItem,
					UUID fetchIncrementalDataLoadAuditId, DataResponse newDataRes, String startFormmatedDate,
					ObjectMapper mapper, int i) throws IOException, InterruptedException;
	 void processEntity(String entityName, JSONArray jsonArray, boolean isLastItem,
					UUID fetchIncrementalDataLoadAuditId, DataResponse newDataRes, String startFormmatedDate, int index)
					throws IOException, InterruptedException;

	
	

}
