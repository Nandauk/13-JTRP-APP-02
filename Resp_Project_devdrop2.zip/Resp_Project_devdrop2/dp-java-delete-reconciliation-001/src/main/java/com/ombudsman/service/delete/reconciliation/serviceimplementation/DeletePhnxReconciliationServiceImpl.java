package com.ombudsman.service.delete.reconciliation.serviceimplementation;

import static com.ombudsman.service.delete.reconciliation.common.Constants.DATASOURCE_NAME;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.apache.commons.text.StringEscapeUtils;
import org.springframework.beans.factory.annotation.Autowired;
import com.ombudsman.service.delete.reconciliation.repository.IncrementalAuditRepository;
import com.ombudsman.service.delete.reconciliation.repository.IncrementalLoadErrorRepository;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.net.URLDecoder;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.collections.CollectionUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ombudsman.service.delete.reconciliation.common.Constants;
import com.ombudsman.service.delete.reconciliation.common.PhoenixHelper;
import com.ombudsman.service.delete.reconciliation.common.SendMailNotification;
import com.ombudsman.service.delete.reconciliation.dao.IDeleteReconciliationDao;
import com.ombudsman.service.delete.reconciliation.exception.JobFailedException;
import com.ombudsman.service.delete.reconciliation.helper.DataResponse;
import com.ombudsman.service.delete.reconciliation.model.AccountData;
import com.ombudsman.service.delete.reconciliation.model.CaseconsiderationData;
import com.ombudsman.service.delete.reconciliation.model.CaselinkData;
import com.ombudsman.service.delete.reconciliation.model.ContactData;
import com.ombudsman.service.delete.reconciliation.model.CorrespondenceData;
import com.ombudsman.service.delete.reconciliation.model.CorrespondenceSourceData;
import com.ombudsman.service.delete.reconciliation.model.CustomeraddressData;
import com.ombudsman.service.delete.reconciliation.model.DigitalMessageData;
import com.ombudsman.service.delete.reconciliation.model.EmailData;
import com.ombudsman.service.delete.reconciliation.model.ErrorMessageTemplate;
import com.ombudsman.service.delete.reconciliation.model.IncidentData;
import com.ombudsman.service.delete.reconciliation.model.LetterData;
import com.ombudsman.service.delete.reconciliation.model.OfferoutcomeData;
import com.ombudsman.service.delete.reconciliation.model.PhoneData;
import com.ombudsman.service.delete.reconciliation.model.PortalData;
import com.ombudsman.service.delete.reconciliation.model.TaskData;
import com.ombudsman.service.delete.reconciliation.model.UserData;
import com.ombudsman.service.delete.reconciliation.services.DeletePhnxReconciliationService;

import okhttp3.HttpUrl;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import java.time.ZoneId;
import java.time.ZoneOffset;

@Service
public class DeletePhnxReconciliationServiceImpl implements DeletePhnxReconciliationService {
	private static final Logger log = LogManager.getLogger(DeletePhnxReconciliationServiceImpl.class);
	
	
	@Autowired
	IncrementalAuditRepository increLoadAuditRep;

	@Autowired
	IncrementalLoadErrorRepository increLoadErrorRep;

	@Autowired
	private SqlHelper sqlHelper;

	private static final int FAILED_COUNT = 0;
	private PhoenixHelper phoenixHelper;
	private SendMailNotification sendMailNotification;
	private IDeleteReconciliationDao deleteReconciliationDao;
	long totalCount = 0L;
	Integer currentStatusId = 0;
	UUID fetchIncrementalDataLoadAuditId = null;
	Integer currentStatusIdInprogress = 0;
	int batch = 0;
	Integer currentStatusIdFailed = 0;
	String jobEndTime;
	String lastupdatedDate;
	String entity;
	String lastSevenJobDate;
	private static final boolean Sting = false;

	List<CorrespondenceSourceData> arrayListCorrespondenceSourceData = new ArrayList<>();
	List<IncidentData> arrayListIncidentData = new ArrayList<>();
	List<CaselinkData> arrayListCaselinkData = new ArrayList<>();
	List<TaskData> arrayListTaskData = new ArrayList<>();
	List<PhoneData> arrayListPhoneData = new ArrayList<>();
	List<ContactData> arrayListContactData = new ArrayList<>();
	List<AccountData> arrayListAccountData = new ArrayList<>();
	List<EmailData> arrayListEmailData = new ArrayList<>();
	List<UserData> arrayListUserData = new ArrayList<>();
	List<CorrespondenceData> arrayListCorrespondenceData = new ArrayList<>();
	List<CaseconsiderationData> arrayListCaseconsiderationData = new ArrayList<>();
	List<PortalData> arrayListPortalData = new ArrayList<>();
	List<OfferoutcomeData> arrayListOfferoutcomeData = new ArrayList<>();
	List<LetterData> arrayListLetterData = new ArrayList<>();
	List<DigitalMessageData> arrayListDigitalMessageData = new ArrayList<>();
	List<CustomeraddressData> arrayListCustomeraddressData = new ArrayList<>();

	public DeletePhnxReconciliationServiceImpl(PhoenixHelper phoenixHelper,
			IDeleteReconciliationDao deleteReconciliationDao, SendMailNotification sendMailNotification) {

		this.phoenixHelper = phoenixHelper;
		this.deleteReconciliationDao = deleteReconciliationDao;
		this.sendMailNotification = sendMailNotification;

	}

	@Override
	public void processAllJob() throws InterruptedException, JobFailedException {
		final Instant startWebJob = Instant.now();
		totalCount = 0L;
		batch = phoenixHelper.getFetchRecord();
		final String startWebJob_formatted = startWebJob.truncatedTo(ChronoUnit.MILLIS).toString().replaceAll("[TZ]",
				" ");
		

		try {
			
			 
			// Check if any job is in failed state in last 7 days.Then exit without doing
			// entry in audit table
			int current_status_id_failed = increLoadAuditRep.getCurrentStatusFId(Constants.DATASOURCE_SCH,
					Constants.FAILED);
			int current_status_id_failed_azurfunc = increLoadAuditRep.getCurrentStatusFId(Constants.DELETE_SUBMISSION,
					Constants.FAILED);
			int current_status_id_failed_deleterecon = increLoadAuditRep.getCurrentStatusFId(Constants.DATASOURCE_NAME,
					Constants.FAILED);

			 lastSevenJobDate = java.time.LocalDateTime.now().minusDays(7)
					.format(java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss:SSS"));
			
			int failedCountLast7days = increLoadAuditRep.getFailedEntries(current_status_id_failed,
					current_status_id_failed_azurfunc, current_status_id_failed_deleterecon, lastSevenJobDate);
			
			if (failedCountLast7days > 0) {
				log.warn(String.format("There are failed jobs in the last 7 days, Aborting the process: %s",
						failedCountLast7days));

				ErrorMessageTemplate errorMessageTemplate = ErrorMessageTemplate
						.setErrorMessage(Constants.FAILEDMESSAGE, "", "");
				errorMessageTemplate.setTemplateId(phoenixHelper.templateId);
				sendMailNotification.sendErrorNotificationToUserWebclient(errorMessageTemplate);

				return;
			}

			currentStatusIdInprogress = deleteReconciliationDao.getCurrentStatusIPId();
			int jobId = deleteReconciliationDao.getJobID(Constants.INCIDENT_ENTITY);
			log.info(String.format(Constants.TIME_FOR_INSERTION, startWebJob_formatted));
			
			deleteReconciliationDao.insertToIncrementalAudit(jobId, currentStatusIdInprogress,
					Constants.DATASOURCE_NAME, startWebJob_formatted);
			fetchIncrementalDataLoadAuditId = deleteReconciliationDao.getIncrementalDataLoadAuditId(
					currentStatusIdInprogress, startWebJob_formatted, DATASOURCE_NAME, DATASOURCE_NAME);
			
			String jobEndTime_temp = phoenixHelper.getEndTime().equals("NA") ? LocalDateTime
					.of(LocalDate.now(), LocalTime.now()).format(DateTimeFormatter.ofPattern(Constants.DATE_FORMAT))
					: phoenixHelper.getEndTime();

			jobEndTime = dateConvertToUtc(jobEndTime_temp);

			final String jobStartTime_temp = deleteReconciliationDao.getLatestProcessedDatetime();

			String jobStartTime = dateConvertToUtcStart(jobStartTime_temp);

			log.info(String.format("JobStartTime : %s", jobStartTime));

			lastupdatedDate = phoenixHelper.getStartTime().equals("NA") ? jobStartTime : phoenixHelper.getStartTime();
			
			
			if (fetchIncrementalDataLoadAuditId != null) {
				insertToIncident();
				insertToCaseLink();
				insertToContact();
				insertToCorrepondenceSource();
				insertToCorrespondence();
				insertToLetter();
				insertToEmail();
				insertToOfferoutcome();
				insertToPhone();
				insertToPortal();
				insertToTask();
				insertToUser();
				insertToAccount();
				insertToCaseconsideration();
				insertToDigitalMessage();
				insertToCustomerAddress();
				
				

				Integer readyToProcessId = deleteReconciliationDao.getCurrentStatusCId(DATASOURCE_NAME,
						Constants.STATUS_READY_TO_PROCESS);// Ready_To_Process
				deleteReconciliationDao.updateIncrementAuditJobQuery(totalCount, FAILED_COUNT, readyToProcessId,
						Instant.now().toString(), fetchIncrementalDataLoadAuditId, DATASOURCE_NAME);
			}
		} catch (InterruptedException e) {
			// Re-interrupt the current thread
			Thread.currentThread().interrupt();
			// Insert into the database before rethrowing
			handleException(startWebJob, e, fetchIncrementalDataLoadAuditId, totalCount, entity, FAILED_COUNT);
			throw e;
		} catch (Exception e) {
			handleException(startWebJob, e, fetchIncrementalDataLoadAuditId, totalCount, Constants.DATASOURCE_NAME,
					FAILED_COUNT);
			throw new JobFailedException(Constants.JOB_FAILED + entity, getStackTraceAsString(e));
		} finally {
			log.info(Constants.JOB_COMPLETED, Constants.DATASOURCE_NAME);
		}
	}

	@Override
	public void insertToAccount() throws InterruptedException, IOException {
		phxDeleteReconAccount(fetchIncrementalDataLoadAuditId, batch, Constants.ACCOUNT_ENTITY, Constants.ACCOUNT_CODE,
				jobEndTime, lastupdatedDate);

	}

	@Override
	public void insertToCaseLink() throws InterruptedException, IOException {
		phxDeleteReconCaseLink(fetchIncrementalDataLoadAuditId, batch, Constants.CASELINK_ENTITY,
				Constants.CASELINK_CODE, jobEndTime, lastupdatedDate);

	}

	@Override
	public void insertToIncident() throws InterruptedException, IOException {
		phxDeleteReconIncident(fetchIncrementalDataLoadAuditId, batch, Constants.INCIDENT_ENTITY,
				Constants.INCIDENT_CODE, jobEndTime, lastupdatedDate);

	}

	@Override
	public void insertToContact() throws InterruptedException, IOException {
		phxDeleteReconContact(fetchIncrementalDataLoadAuditId, batch, Constants.CONTACT_ENTITY, Constants.CONTACT_CODE,
				jobEndTime, lastupdatedDate);

	}

	@Override
	public void insertToCorrespondence() throws InterruptedException, IOException {
		phxDeleteReconCorrespondence(fetchIncrementalDataLoadAuditId, batch, Constants.CORREPONDENCE_ENTITY,
				Constants.CORRESPONDENCE_CODE, jobEndTime, lastupdatedDate);

	}

	@Override
	public void insertToCorrepondenceSource() throws InterruptedException, IOException {
		phxDeleteReconCorrespondenceSource(fetchIncrementalDataLoadAuditId, batch,
				Constants.CORRESPONDENCE_SOURCE_ENTITY, Constants.CORRESPONDENCE_SOURCE_CODE, jobEndTime,
				lastupdatedDate);

	}

	@Override
	public void insertToEmail() throws InterruptedException, IOException {
		phxDeleteReconEmail(fetchIncrementalDataLoadAuditId, batch, Constants.EMAIL_ENTITY, Constants.EMAIL_CODE,
				jobEndTime, lastupdatedDate);

	}

	@Override
	public void insertToLetter() throws InterruptedException, IOException {
		phxDeleteReconLetter(fetchIncrementalDataLoadAuditId, batch, Constants.LETTER_ENTITY, Constants.LETTER_CODE,
				jobEndTime, lastupdatedDate);

	}

	@Override
	public void insertToUser() throws InterruptedException, IOException {
		phxDeleteReconUser(fetchIncrementalDataLoadAuditId, batch, Constants.USER_ENTITY, Constants.USER_CODE,
				jobEndTime, lastupdatedDate);

	}

	@Override
	public void insertToCaseconsideration() throws InterruptedException, IOException {
		phxDeleteReconCaseConsideration(fetchIncrementalDataLoadAuditId, batch, Constants.CASECONSIDERATION_ENTITY,
				Constants.CASECONSIDERATTION_CODE, jobEndTime, lastupdatedDate);

	}

	@Override
	public void insertToOfferoutcome() throws InterruptedException, IOException {
		phxDeleteReconOfferoutcome(fetchIncrementalDataLoadAuditId, batch, Constants.OFFEROUTCOME_ENTITY,
				Constants.OFFEROUTCOME_CODE, jobEndTime, lastupdatedDate);

	}

	@Override
	public void insertToPhone() throws InterruptedException, IOException {
		phxDeleteReconPhone(fetchIncrementalDataLoadAuditId, batch, Constants.PHONE_ENTITY, Constants.PHONE_CODE,
				jobEndTime, lastupdatedDate);

	}

	@Override
	public void insertToPortal() throws InterruptedException, IOException {
		phxDeleteReconPortal(fetchIncrementalDataLoadAuditId, batch, Constants.PORTAL_ENTITY, Constants.PORTAL_CODE,
				jobEndTime, lastupdatedDate);

	}

	@Override
	public void insertToTask() throws InterruptedException, IOException {
		phxDeleteReconTask(fetchIncrementalDataLoadAuditId, batch, Constants.TASK_ENTITY, Constants.TASK_CODE,
				jobEndTime, lastupdatedDate);

	}

	@Override
	public void insertToDigitalMessage() throws InterruptedException, IOException {
		phxDeleteReconDigitalMessage(fetchIncrementalDataLoadAuditId, batch, Constants.DIGITALMESSAGE_ENTITY,
				Constants.DIGITALMESSAGE_CODE, jobEndTime, lastupdatedDate);
	}

	@Override
	public void insertToCustomerAddress() throws InterruptedException, IOException {
		phxDeleteReconCustomerAddress(fetchIncrementalDataLoadAuditId, batch, Constants.CUSTOMERADDRESS_ENTITY,
				Constants.CUSTOMERADDRESS_CODE, jobEndTime, lastupdatedDate);
	}

	/**
	 * This method fetches records from the PHX system based on the provided
	 * parameters.
	 *
	 * @param entityName                       The name of the entity.
	 * @param entityCode                       The code of the entity.
	 * @param startFormmatedDate               The start formatted date for fetching
	 *                                         records.
	 * @param lastUpdatedDate                  The date when the data was last
	 *                                         updated.
	 * @param fetch_IncrementalDataLoadAuditId The audit ID for the incremental data
	 *                                         load.
	 * @param dataResponse                     The data response object to store the
	 *                                         fetched data.
	 * @return The start date for the next batch of records.
	 * @throws InterruptedException If the thread executing the method is
	 *                              interrupted.
	 * @throws IOException          If an I/O error occurs.
	 */
	public String fetchRecordsFromPhnx(final String entityName, String entityCode, String jobEndTime,
			String lastDateUpdated, UUID fetchIncrementalDataLoadAuditId,int batchsize, DataResponse newDataRes, boolean moreRecords, String pagingCookie,
			int page)
			throws InterruptedException, IOException {

		Instant startpnx = Instant.now();
		String finalcookie = null;

		log.info(String.format("Phiniox entity name: %s", entityName));
		try {
			OkHttpClient client = new OkHttpClient.Builder()
					.connectTimeout(phoenixHelper.getConnectionTimeout(), TimeUnit.MINUTES)
					.writeTimeout(120, TimeUnit.SECONDS).readTimeout(phoenixHelper.readTimeout, TimeUnit.MINUTES)
					.build();

			final String fetchXml = phoenixHelper.getFetchXML(entityCode, jobEndTime, lastDateUpdated,batchsize,pagingCookie,
					page);
			
			log.info(String.format("fetchxml for: %s fetchxml is: %s", entityName, fetchXml));
			
			  String httpUrl = new  HttpUrl.Builder().scheme("https").host(phoenixHelper.pheonixHost)
			  .addPathSegment("phoniex").addPathSegment("audits")
			  .addQueryParameter( "fetchXml", fetchXml).build() .toString(); 
			
			  Request request =  phoenixHelper.getPhoenixRequestBuild(httpUrl);
			 
			

			log.info(String.format("calling phoenix: %s", httpUrl));
			Response response = client.newCall(request).execute();
			//String phoenixResp = response.toString();
		//	log.info(String.format("receive response from phoenix..... : %s", phoenixResp));
			String dataReturned = response.body().string();
		//	log.info(String.format("Data returned from phoenix: %s", dataReturned));
			JSONObject jsonObject = new JSONObject(dataReturned);
			JSONArray jsonArray = jsonObject.getJSONArray("value");

			if (jsonArray != null) {
				int size = jsonArray.length();
				log.info(String.format("size of the jsonArray: %s for the entity: %s", size, entity));
				for (int i = 0; i < jsonArray.length(); i++) {
					boolean isLastitem = (i == size - 1);

					 processEntity(entityName, jsonArray, isLastitem, fetchIncrementalDataLoadAuditId,
							newDataRes, jobEndTime, i);
				 
					

				}
				Instant endpnx = Instant.now();
				long timeElapsedphnx = Duration.between(startpnx, endpnx).toMillis();
				log.info(String.format(Constants.TOTAL_TIME_TAKEN_PHENOIX_CALL, entityName, timeElapsedphnx));
				
				finalcookie = getFinalCookie(dataReturned,entityName,jsonObject,moreRecords,pagingCookie);
			}
		} catch (InterruptedException e) {
			// Re-interrupt the current thread
			Thread.currentThread().interrupt();
			log.info(String.format("Error occurred in phx for: %s Error logs: %s", entityName, e.getMessage()));
			throw e;
		}

		return finalcookie;
	}

	/**
	 * This method deletes reconciliation case link data from the PHX system.
	 *
	 * @param FetchIncrementalDataLoadAuditId The audit ID for the incremental data
	 *                                        load.
	 * @param totalRecord                     The total number of records processed
	 *                                        so far.
	 * @param batchsize                       The batch size for fetching records.
	 * @param entityName                      The name of the entity.
	 * @param entityCode                      The code of the entity.
	 * @param startJob                        The start job identifier.
	 * @param lastupdatedDate                 The date when the data was last
	 *                                        updated.
	 * @return The total number of records processed.
	 * @throws InterruptedException If the thread executing the method is
	 *                              interrupted.
	 * @throws IOException          If an I/O error occurs.
	 */
	public Long phxDeleteReconCaseLink(UUID fetchIncrementalDataLoadAuditId, int batchsize, String entityName,
			String entityCode, String jobEndTime, String lastupdatedDate) throws InterruptedException, IOException {
		long totalRecord = 0l;
		String startDate = null;
		String startdateValue = null;
		DataResponse dataResponse = new DataResponse();
		Instant startpnx = Instant.now();
		
		//Pagination
		String pagingCookie = null;
		int page = 1;
		boolean moreRecords = false;

		do {
			dataResponse.getCaselinkData().clear();
			startdateValue = (startDate == null || startDate.isEmpty()) ? lastupdatedDate : startDate;
			
			pagingCookie = fetchRecordsFromPhnx(entityName, entityCode, jobEndTime, startdateValue,
					fetchIncrementalDataLoadAuditId, batchsize,dataResponse, moreRecords, pagingCookie,
					page);
			
			log.info(String.format("data response: %s for: %s", dataResponse.getCaselinkData().size(),
					Constants.CASELINK_ENTITY));
			totalRecord += dataResponse.getCustomeraddressData().size();
			
			page++;

		} while (pagingCookie != null);
		
		Instant endpnx = Instant.now();
		log.info(String.format(Constants.CODE_ENDED, Constants.CASELINK_ENTITY, endpnx));
		long timeElapsedphnx = Duration.between(startpnx, endpnx).toMillis();
		log.info(String.format(Constants.TOTAL_TIME_TAKEN, Constants.CASELINK_ENTITY, timeElapsedphnx));
		dataResponse.getCaselinkData().clear();
		totalCount += totalRecord;
		log.info(String.format("total count and total record for %s : %s : %s", entityName, totalCount, totalRecord));
		return totalRecord;
	}

	/**
	 * This method deletes reconciliation account data from the PHX system.
	 *
	 * @param FetchIncrementalDataLoadAuditId The audit ID for the incremental data
	 *                                        load.
	 * @param totalRecord                     The total number of records processed
	 *                                        so far.
	 * @param batchsize                       The batch size for fetching records.
	 * @param entityName                      The name of the entity.
	 * @param entityCode                      The code of the entity.
	 * @param startJob                        The start job identifier.
	 * @param lastupdatedDate                 The date when the data was last
	 *                                        updated.
	 * @return The total number of records processed.
	 * @throws InterruptedException If the thread executing the method is
	 *                              interrupted.
	 * @throws IOException
	 */
	public Long phxDeleteReconAccount(UUID fetchIncrementalDataLoadAuditId, int batchsize, String entityName,
			String entityCode, String startJob, String lastupdatedDate) throws InterruptedException, IOException {
		long totalRecord = 0l;
		String startDate = null;
		String startdateValue = null;
		DataResponse dataResponse = new DataResponse();
		Instant startpnx = Instant.now();
		
		//Pagination
		String pagingCookie = null;
		int page = 1;
		boolean moreRecords = false;

		do {
			dataResponse.getAccountData().clear();
			startdateValue = (startDate == null || startDate.isEmpty()) ? lastupdatedDate : startDate;
			
			pagingCookie = fetchRecordsFromPhnx(entityName, entityCode, startJob, startdateValue,
					fetchIncrementalDataLoadAuditId,batchsize, dataResponse, moreRecords, pagingCookie,
					page);
			
			log.info(String.format(Constants.DATA_RESPONSE, dataResponse.getAccountData().size(), entityName));
			totalRecord += dataResponse.getCustomeraddressData().size();
			page++;

		} while (pagingCookie != null);
		Instant endpnx = Instant.now();
		log.info(String.format(Constants.CODE_ENDED, Constants.ACCOUNT_ENTITY, endpnx));
		long timeElapsedphnx = Duration.between(startpnx, endpnx).toMillis();
		log.info(String.format(Constants.TOTAL_TIME_TAKEN, Constants.ACCOUNT_ENTITY, timeElapsedphnx));
		dataResponse.getAccountData().clear();
		totalCount += totalRecord;
		log.info(String.format("total count and total record for %s : %s : %s", entityName, totalCount, totalRecord));
		return totalRecord;
	}

	/**
	 * This method deletes reconciliation contact data from the PHX system.
	 *
	 * @param FetchIncrementalDataLoadAuditId The audit ID for the incremental data
	 *                                        load.
	 * @param totalRecord                     The total number of records processed
	 *                                        so far.
	 * @param batchsize                       The batch size for fetching records.
	 * @param entityName                      The name of the entity.
	 * @param entityCode                      The code of the entity.
	 * @param startJob                        The start job identifier.
	 * @param lastupdatedDate                 The date when the data was last
	 *                                        updated.
	 * @return The total number of records processed.
	 * @throws InterruptedException If the thread executing the method is
	 *                              interrupted.
	 * @throws IOException
	 */
	public Long phxDeleteReconContact(UUID fetchIncrementalDataLoadAuditId, int batchsize, String entityName,
			String entityCode, String jobEndTime, String lastupdatedDate) throws InterruptedException, IOException {
		long totalRecord = 0l;
		String startDate = null;
		String startdateValue = null;
		DataResponse dataResponse = new DataResponse();
		Instant startpnx = Instant.now();
		
		//Pagination
		String pagingCookie = null;
		int page = 1;
		boolean moreRecords = false;

		do {
			dataResponse.getContactData().clear();
			startdateValue = (startDate == null || startDate.isEmpty()) ? lastupdatedDate : startDate;
			
			pagingCookie = fetchRecordsFromPhnx(entityName, entityCode, jobEndTime, startdateValue,
					fetchIncrementalDataLoadAuditId,batchsize, dataResponse, moreRecords, pagingCookie,
					page);
			
			log.info(String.format(Constants.DATA_RESPONSE, dataResponse.getContactData().size(),
					Constants.CONTACT_ENTITY));
			totalRecord += dataResponse.getCustomeraddressData().size();
			page++;

		} while (pagingCookie != null);
		Instant endpnx = Instant.now();
		log.info(String.format(Constants.CODE_ENDED, Constants.CONTACT_ENTITY, endpnx));
		long timeElapsedphnx = Duration.between(startpnx, endpnx).toMillis();
		log.info(String.format(Constants.TOTAL_TIME_TAKEN, Constants.CONTACT_ENTITY, timeElapsedphnx));
		dataResponse.getContactData().clear();
		totalCount += totalRecord;
		log.info(String.format("total count and total record for %s : %s : %s", entityName, totalCount, totalRecord));
		return totalRecord;
	}

	/**
	 * This method deletes reconciliation case consideration data from the PHX
	 * system.
	 *
	 * @param Fetch_IncrementalDataLoadAuditId The audit ID for the incremental data
	 *                                         load.
	 * @param totalRecord                      The total number of records processed
	 *                                         so far.
	 * @param batchsize                        The batch size for fetching records.
	 * @param entityName                       The name of the entity.
	 * @param entityCode                       The code of the entity.
	 * @param startJob                         The start job identifier.
	 * @param lastupdatedDate                  The date when the data was last
	 *                                         updated.
	 * @return The total number of records processed.
	 * @throws InterruptedException If the thread executing the method is
	 *                              interrupted.
	 * @throws IOException
	 */
	public Long phxDeleteReconCaseConsideration(UUID fetchIncrementalDataLoadAuditId, int batchsize, String entityName,
			String entityCode, String jobEndTime, String lastupdatedDate) throws InterruptedException, IOException {
		long totalRecord = 0l;
		String startDate = null;
		String startdateValue = null;
		DataResponse dataResponse = new DataResponse();
		Instant startpnx = Instant.now();
		
		//Pagination
		String pagingCookie = null;
		int page = 1;
		boolean moreRecords = false;

		do {
			dataResponse.getCaseconsiderationData().clear();
			startdateValue = (startDate == null || startDate.isEmpty()) ? lastupdatedDate : startDate;
			
			pagingCookie = fetchRecordsFromPhnx(entityName, entityCode, jobEndTime, startdateValue,
					fetchIncrementalDataLoadAuditId,batchsize, dataResponse, moreRecords, pagingCookie,
					page);
			
			log.info(String.format(Constants.DATA_RESPONSE, dataResponse.getCaseconsiderationData().size(),
					Constants.CASECONSIDERATION_ENTITY));
			totalRecord += dataResponse.getCustomeraddressData().size();
			page++;

		} while (pagingCookie != null);
		Instant endpnx = Instant.now();
		log.info(String.format(Constants.CODE_ENDED, Constants.CASECONSIDERATION_ENTITY, endpnx));
		long timeElapsedphnx = Duration.between(startpnx, endpnx).toMillis();
		log.info(String.format(Constants.TOTAL_TIME_TAKEN, Constants.CASECONSIDERATION_ENTITY, timeElapsedphnx));
		dataResponse.getCaseconsiderationData().clear();
		totalCount += totalRecord;
		log.info(String.format("total count and total record for %s : %s : %s", entityName, totalCount, totalRecord));
		return totalRecord;
	}

	/**
	 * This method deletes reconciliation correspondence source data from the PHX
	 * system.
	 *
	 * @param fetchIncrementalDataLoadAuditId The audit ID for the incremental data
	 *                                        load.
	 * @param totalRecord                     The total number of records processed
	 *                                        so far.
	 * @param batchsize                       The batch size for fetching records.
	 * @param entityName                      The name of the entity.
	 * @param entityCode                      The code of the entity.
	 * @param startJob                        The start job identifier.
	 * @param lastupdatedDate                 The date when the data was last
	 *                                        updated.
	 * @return The total number of records processed.
	 * @throws InterruptedException If the thread executing the method is
	 *                              interrupted.
	 * @throws IOException
	 */
	public Long phxDeleteReconCorrespondenceSource(UUID fetchIncrementalDataLoadAuditId, int batchsize,
			String entityName, String entityCode, String jobEndTime, String lastupdatedDate)
			throws InterruptedException, IOException {
		long totalRecord = 0l;
		String startDate = null;
		String startdateValue = null;
		DataResponse dataResponse = new DataResponse();
		Instant startpnx = Instant.now();
		
		//Pagination
		String pagingCookie = null;
		int page = 1;
		boolean moreRecords = false;

		do {
			dataResponse.getCorrespondenceSourceData().clear();
			startdateValue = (startDate == null || startDate.isEmpty()) ? lastupdatedDate : startDate;
			pagingCookie = fetchRecordsFromPhnx(entityName, entityCode, jobEndTime, startdateValue,
					fetchIncrementalDataLoadAuditId,batchsize, dataResponse, moreRecords, pagingCookie,
					page);
			log.info(String.format(Constants.DATA_RESPONSE, dataResponse.getCorrespondenceSourceData().size(),
					Constants.CORRESPONDENCE_SOURCE_ENTITY));
			totalRecord += dataResponse.getCustomeraddressData().size();
			page++;

		} while (pagingCookie != null);
		Instant endpnx = Instant.now();
		log.info(String.format(Constants.CODE_ENDED, Constants.CORRESPONDENCE_SOURCE_ENTITY, endpnx));
		long timeElapsedphnx = Duration.between(startpnx, endpnx).toMillis();
		log.info(String.format(Constants.TOTAL_TIME_TAKEN, Constants.CORRESPONDENCE_SOURCE_ENTITY, timeElapsedphnx));
		dataResponse.getCorrespondenceSourceData().clear();
		totalCount += totalRecord;
		log.info(String.format("total count and total record for %s : %s : %s", entityName, totalCount, totalRecord));
		return totalRecord;
	}

	/**
	 * This method deletes reconciliation correspondence data from the PHX system.
	 *
	 * @param FetchIncrementalDataLoadAuditId The audit ID for the incremental data
	 *                                        load.
	 * @param totalRecord                     The total number of records processed
	 *                                        so far.
	 * @param batchsize                       The batch size for fetching records.
	 * @param entityName                      The name of the entity.
	 * @param entityCode                      The code of the entity.
	 * @param startJob                        The start job identifier.
	 * @param lastupdatedDate                 The date when the data was last
	 *                                        updated.
	 * @return The total number of records processed.
	 * @throws InterruptedException If the thread executing the method is
	 *                              interrupted.
	 * @throws IOException
	 */
	public Long phxDeleteReconCorrespondence(UUID fetchIncrementalDataLoadAuditId, int batchsize, String entityName,
			String entityCode, String jobEndTime, String lastupdatedDate) throws InterruptedException, IOException {
		long totalRecord = 0l;
		String startDate = null;
		String startdateValue = null;
		DataResponse dataResponse = new DataResponse();
		Instant startpnx = Instant.now();
		
		//Pagination
		String pagingCookie = null;
		int page = 1;
		boolean moreRecords = false;

		do {
			dataResponse.getCorrespondenceData().clear();
			startdateValue = (startDate == null || startDate.isEmpty()) ? lastupdatedDate : startDate;
			pagingCookie = fetchRecordsFromPhnx(entityName, entityCode, jobEndTime, startdateValue,
					fetchIncrementalDataLoadAuditId,batchsize, dataResponse, moreRecords, pagingCookie,
					page);
			log.info(String.format(Constants.DATA_RESPONSE, dataResponse.getCorrespondenceData().size(),
					Constants.CORREPONDENCE_ENTITY));
			totalRecord += dataResponse.getCustomeraddressData().size();
			page++;

		} while (pagingCookie != null);
		Instant endpnx = Instant.now();
		log.info(String.format(Constants.CODE_ENDED, Constants.CORREPONDENCE_ENTITY, endpnx));
		long timeElapsedphnx = Duration.between(startpnx, endpnx).toMillis();
		log.info(String.format(Constants.TOTAL_TIME_TAKEN, Constants.CORREPONDENCE_ENTITY, timeElapsedphnx));
		dataResponse.getCorrespondenceData().clear();
		totalCount += totalRecord;
		log.info(String.format("total count and total record for %s : %s : %s", entityName, totalCount, totalRecord));
		return totalRecord;
	}

	/**
	 * This method deletes reconciliation incident data from the PHX system.
	 *
	 * @param FetchIncrementalDataLoadAuditId The audit ID for the incremental data
	 *                                        load.
	 * @param totalRecord                     The total number of records processed
	 *                                        so far.
	 * @param batchsize                       The batch size for fetching records.
	 * @param entityName                      The name of the entity.
	 * @param entityCode                      The code of the entity.
	 * @param startJob                        The start job identifier.
	 * @param lastupdatedDate                 The date when the data was last
	 *                                        updated.
	 * @return The total number of records processed.
	 * @throws InterruptedException If the thread executing the method is
	 *                              interrupted.
	 * @throws IOException
	 */
	public Long phxDeleteReconIncident(UUID fetchIncrementalDataLoadAuditId, int batchsize, String entityName,
			String entityCode, String jobEndTime, String lastupdatedDate) throws InterruptedException, IOException {
		long totalRecord = 0l;
		
		entity = entityName;
		DataResponse dataResponse = new DataResponse();
		Instant startpnx = Instant.now();
		
		//Pagination
				String pagingCookie = null;
				int page = 1;
				boolean moreRecords = false;


		do {
			dataResponse.getIncidentData().clear();
			
			pagingCookie = fetchRecordsFromPhnx(entityName, entityCode, jobEndTime, lastupdatedDate,
					fetchIncrementalDataLoadAuditId,batchsize, dataResponse, moreRecords, pagingCookie,
					page);
			
			log.info(String.format(Constants.DATA_RESPONSE, dataResponse.getIncidentData().size(),
					Constants.INCIDENT_ENTITY));
			totalRecord += dataResponse.getCustomeraddressData().size();
			
			page++;

		} while (pagingCookie != null);
		
		Instant endpnx = Instant.now();
		log.info(String.format(Constants.CODE_ENDED, Constants.INCIDENT_ENTITY, endpnx));
		long timeElapsedphnx = Duration.between(startpnx, endpnx).toMillis();
		log.info(String.format(Constants.TOTAL_TIME_TAKEN, Constants.INCIDENT_ENTITY, timeElapsedphnx));
		dataResponse.getIncidentData().clear();
		totalCount += totalRecord;
		log.info(String.format("total count and total record for %s : %s : %s", entityName, totalCount, totalRecord));
		return totalRecord;
	}

	/**
	 * This method deletes reconciliation portal data from the PHX system.
	 *
	 * @param fetchIncrementalDataLoadAuditId The audit ID for the incremental data
	 *                                        load.
	 * @param totalRecord                     The total number of records processed
	 *                                        so far.
	 * @param batchsize                       The batch size for fetching records.
	 * @param entityName                      The name of the entity.
	 * @param entityCode                      The code of the entity.
	 * @param startJob                        The start job identifier.
	 * @param lastupdatedDate                 The date when the data was last
	 *                                        updated.
	 * @return The total number of records processed.
	 * @throws InterruptedException If the thread executing the method is
	 *                              interrupted.
	 * @throws IOException          If an I/O error occurs.
	 */
	public Long phxDeleteReconPortal(UUID fetchIncrementalDataLoadAuditId, int batchsize, String entityName,
			String entityCode, String jobEndTime, String lastupdatedDate) throws InterruptedException, IOException {
		long totalRecord = 0l;
		String startDate = null;
		String startdateValue = null;
		DataResponse dataResponse = new DataResponse();
		Instant startpnx = Instant.now();
		
		//Pagination
				String pagingCookie = null;
				int page = 1;
				boolean moreRecords = false;


		do {
			dataResponse.getPortalData().clear();
			startdateValue = (startDate == null || startDate.isEmpty()) ? lastupdatedDate : startDate;
			
			pagingCookie = fetchRecordsFromPhnx(entityName, entityCode, jobEndTime, startdateValue,
					fetchIncrementalDataLoadAuditId,batchsize, dataResponse, moreRecords, pagingCookie,
					page);
			
			log.info(String.format(Constants.DATA_RESPONSE, dataResponse.getPortalData().size(),
					Constants.PORTAL_ENTITY));
			
			totalRecord += dataResponse.getCustomeraddressData().size();
			
			page++;

		} while (pagingCookie != null);
		Instant endpnx = Instant.now();
		log.info(String.format(Constants.CODE_ENDED, Constants.PORTAL_ENTITY, endpnx));
		long timeElapsedphnx = Duration.between(startpnx, endpnx).toMillis();
		log.info(String.format(Constants.TOTAL_TIME_TAKEN, Constants.PORTAL_ENTITY, timeElapsedphnx));
		dataResponse.getPortalData().clear();
		totalCount += totalRecord;
		log.info(String.format("total count and total record for %s : %s : %s", entityName, totalCount, totalRecord));
		return totalRecord;
	}

	/**
	 * This method deletes reconciliation phone data from the PHX system.
	 *
	 * @param fetchIncrementalDataLoadAuditId The audit ID for the incremental data
	 *                                        load.
	 * @param totalRecord                     The total number of records processed
	 *                                        so far.
	 * @param batchsize                       The batch size for fetching records.
	 * @param entityName                      The name of the entity.
	 * @param entityCode                      The code of the entity.
	 * @param startJob                        The start job identifier.
	 * @param lastupdatedDate                 The date when the data was last
	 *                                        updated.
	 * @return The total number of records processed.
	 * @throws InterruptedException If the thread executing the method is
	 *                              interrupted.
	 * @throws IOException          If an I/O error occurs.
	 */
	public Long phxDeleteReconPhone(UUID fetchIncrementalDataLoadAuditId, int batchsize, String entityName,
			String entityCode, String jobEndTime, String lastupdatedDate) throws InterruptedException, IOException {
		long totalRecord = 0l;
		String startDate = null;
		String startdateValue = null;
		DataResponse dataResponse = new DataResponse();
		Instant startpnx = Instant.now();
		
		//Pagination
				String pagingCookie = null;
				int page = 1;
				boolean moreRecords = false;


		do {
			dataResponse.getPhoneData().clear();
			startdateValue = (startDate == null || startDate.isEmpty()) ? lastupdatedDate : startDate;
			
			pagingCookie = fetchRecordsFromPhnx(entityName, entityCode, jobEndTime, startdateValue,
					fetchIncrementalDataLoadAuditId, batchsize,dataResponse, moreRecords, pagingCookie,
					page);
			
			log.info(
					String.format(Constants.DATA_RESPONSE, dataResponse.getPhoneData().size(), Constants.PHONE_ENTITY));
			totalRecord += dataResponse.getCustomeraddressData().size();
			
			page++;

		} while (pagingCookie != null);
		
		Instant endpnx = Instant.now();
		log.info(String.format(Constants.CODE_ENDED, Constants.PHONE_ENTITY, endpnx));
		long timeElapsedphnx = Duration.between(startpnx, endpnx).toMillis();
		log.info(String.format(Constants.TOTAL_TIME_TAKEN, Constants.PHONE_ENTITY, timeElapsedphnx));
		dataResponse.getPhoneData().clear();
		totalCount += totalRecord;
		log.info(String.format("total count and total record for %s : %s : %s", entityName, totalCount, totalRecord));
		return totalRecord;
	}

	/**
	 * This method deletes reconciliation task data from the PHX system.
	 *
	 * @param fetchIncrementalDataLoadAuditId The audit ID for the incremental data
	 *                                        load.
	 * @param totalRecord                     The total number of records processed
	 *                                        so far.
	 * @param batchsize                       The batch size for fetching records.
	 * @param entityName                      The name of the entity.
	 * @param entityCode                      The code of the entity.
	 * @param startJob                        The start job identifier.
	 * @param lastupdatedDate                 The date when the data was last
	 *                                        updated.
	 * @return The total number of records processed.
	 * @throws InterruptedException If the thread executing the method is
	 *                              interrupted.
	 * @throws IOException
	 */
	public Long phxDeleteReconTask(UUID fetchIncrementalDataLoadAuditId, int batchsize, String entityName,
			String entityCode, String jobEndTime, String lastupdatedDate) throws InterruptedException, IOException {
		long totalRecord = 0l;
		String startDate = null;
		String startdateValue = null;
		DataResponse dataResponse = new DataResponse();
		Instant startpnx = Instant.now();
		
		//Pagination
				String pagingCookie = null;
				int page = 1;
				boolean moreRecords = false;


		do {
			dataResponse.getTaskData().clear();
			startdateValue = (startDate == null || startDate.isEmpty()) ? lastupdatedDate : startDate;
			
			pagingCookie =fetchRecordsFromPhnx(entityName, entityCode, jobEndTime, startdateValue,
					fetchIncrementalDataLoadAuditId,batchsize, dataResponse, moreRecords, pagingCookie,
					page);
			
			log.info(String.format(Constants.DATA_RESPONSE, dataResponse.getTaskData().size(), Constants.TASK_ENTITY));
			totalRecord += dataResponse.getTaskData().size();
			
			page++;

		} while (pagingCookie != null);
		
		Instant endpnx = Instant.now();
		log.info(String.format(Constants.CODE_ENDED, Constants.TASK_ENTITY, endpnx));
		long timeElapsedphnx = Duration.between(startpnx, endpnx).toMillis();
		log.info(String.format(Constants.TOTAL_TIME_TAKEN, Constants.TASK_ENTITY, timeElapsedphnx));
		dataResponse.getTaskData().clear();
		totalCount += totalRecord;
		log.info(String.format("total count and total record for %s : %s : %s", entityName, totalCount, totalRecord));
		return totalRecord;
	}

	/**
	 * This method deletes reconciliation offer outcome data from the PHX system.
	 *
	 * @param Fetch_IncrementalDataLoadAuditId The audit ID for the incremental data
	 *                                         load.
	 * @param totalRecord                      The total number of records processed
	 *                                         so far.
	 * @param batchsize                        The batch size for fetching records.
	 * @param entityName                       The name of the entity.
	 * @param entityCode                       The code of the entity.
	 * @param startJob                         The start job identifier.
	 * @param lastupdatedDate                  The date when the data was last
	 *                                         updated.
	 * @return The total number of records processed.
	 * @throws InterruptedException If the thread executing the method is
	 *                              interrupted.
	 * @throws IOException
	 */
	public Long phxDeleteReconOfferoutcome(UUID fetchIncrementalDataLoadAuditId, int batchsize, String entityName,
			String entityCode, String jobEndTime, String lastupdatedDate) throws InterruptedException, IOException {
		long totalRecord = 0l;
		String startDate = null;
		String startdateValue = null;
		DataResponse dataResponse = new DataResponse();
		Instant startpnx = Instant.now();
		
		//Pagination
				String pagingCookie = null;
				int page = 1;
				boolean moreRecords = false;


		do {
			dataResponse.getOfferoutcomeData().clear();
			startdateValue = (startDate == null || startDate.isEmpty()) ? lastupdatedDate : startDate;
			
			pagingCookie = fetchRecordsFromPhnx(entityName, entityCode, jobEndTime, startdateValue,
					fetchIncrementalDataLoadAuditId,batchsize, dataResponse, moreRecords, pagingCookie,
					page);
			
			log.info(String.format(Constants.DATA_RESPONSE, dataResponse.getOfferoutcomeData().size(),
					Constants.OFFEROUTCOME_ENTITY));
			totalRecord += dataResponse.getOfferoutcomeData().size();
			
			page++;

		} while (pagingCookie != null);
		
		Instant endpnx = Instant.now();
		log.info(String.format(Constants.CODE_ENDED, Constants.OFFEROUTCOME_ENTITY, endpnx));
		long timeElapsedphnx = Duration.between(startpnx, endpnx).toMillis();
		log.info(String.format(Constants.TOTAL_TIME_TAKEN, Constants.OFFEROUTCOME_ENTITY, timeElapsedphnx));
		dataResponse.getOfferoutcomeData().clear();
		totalCount += totalRecord;
		log.info(String.format("total count and total record for %s : %s : %s", entityName, totalCount, totalRecord));
		return totalRecord;
	}

	/**
	 * This method deletes reconciliation user data from the PHX system.
	 *
	 * @param fetchIncrementalDataLoadAuditId The audit ID for the incremental data
	 *                                        load.
	 * @param totalRecord                     The total number of records processed
	 *                                        so far.
	 * @param batchsize                       The batch size for fetching records.
	 * @param entityName                      The name of the entity.
	 * @param entityCode                      The code of the entity.
	 * @param startJob                        The start job identifier.
	 * @param lastupdatedDate                 The date when the data was last
	 *                                        updated.
	 * @return The total number of records processed.
	 * @throws InterruptedException If the thread executing the method is
	 *                              interrupted.
	 * @throws IOException
	 */
	public Long phxDeleteReconUser(UUID fetchIncrementalDataLoadAuditId, int batchsize, String entityName,
			String entityCode, String jobEndTime, String lastupdatedDate) throws InterruptedException, IOException {
		long totalRecord = 0l;
		String startDate = null;
		String startdateValue = null;
		DataResponse dataResponse = new DataResponse();
		Instant startpnx = Instant.now();

		//Pagination
				String pagingCookie = null;
				int page = 1;
				boolean moreRecords = false;

		do {
			dataResponse.getUserData().clear();
			startdateValue = (startDate == null || startDate.isEmpty()) ? lastupdatedDate : startDate;
			
			pagingCookie = fetchRecordsFromPhnx(entityName, entityCode, jobEndTime, startdateValue,
					fetchIncrementalDataLoadAuditId,batchsize, dataResponse, moreRecords, pagingCookie,
					page);
			
			log.info(String.format(Constants.DATA_RESPONSE, dataResponse.getUserData().size(), Constants.USER_ENTITY));
			totalRecord += dataResponse.getUserData().size();
			
			page++;

		} while (pagingCookie != null);
		
		Instant endpnx = Instant.now();
		log.info(String.format(Constants.CODE_ENDED, Constants.USER_ENTITY, endpnx));
		long timeElapsedphnx = Duration.between(startpnx, endpnx).toMillis();
		log.info(String.format(Constants.TOTAL_TIME_TAKEN, Constants.USER_ENTITY, timeElapsedphnx));
		dataResponse.getUserData().clear();
		totalCount += totalRecord;
		log.info(String.format("total count and total record for %s : %s : %s", entityName, totalCount, totalRecord));
		return totalRecord;
	}

	/**
	 * This method deletes reconciliation letter data from the PHX system.
	 *
	 * @param fetchIncrementalDataLoadAuditId The audit ID for the incremental data
	 *                                        load.
	 * @param totalRecord                     The total number of records processed
	 *                                        so far.
	 * @param batchsize                       The batch size for fetching records.
	 * @param entityName                      The name of the entity.
	 * @param entityCode                      The code of the entity.
	 * @param startJob                        The start job identifier.
	 * @param lastupdatedDate                 The date when the data was last
	 *                                        updated.
	 * @return The total number of records processed.
	 * @throws InterruptedException If the thread executing the method is
	 *                              interrupted.
	 * @throws IOException
	 */
	public Long phxDeleteReconLetter(UUID fetchIncrementalDataLoadAuditId, int batchsize, String entityName,
			String entityCode, String jobEndTime, String lastupdatedDate) throws InterruptedException, IOException {
		long totalRecord = 0l;
		String startDate = null;
		String startdateValue = null;
		DataResponse dataResponse = new DataResponse();
		Instant startpnx = Instant.now();

		//Pagination
				String pagingCookie = null;
				int page = 1;
				boolean moreRecords = false;

		do {
			dataResponse.getLetterData().clear();
			startdateValue = (startDate == null || startDate.isEmpty()) ? lastupdatedDate : startDate;
			
			pagingCookie = fetchRecordsFromPhnx(entityName, entityCode, jobEndTime, startdateValue,
					fetchIncrementalDataLoadAuditId,batchsize, dataResponse, moreRecords, pagingCookie,
					page);
			
			log.info(
					String.format(Constants.DATA_RESPONSE, dataResponse.getLetterData().size(), Constants.USER_ENTITY));
			totalRecord += dataResponse.getLetterData().size();
			
			page++;

		} while (pagingCookie != null);
		
		Instant endpnx = Instant.now();
		log.info(String.format(Constants.CODE_ENDED, Constants.USER_ENTITY, endpnx));
		long timeElapsedphnx = Duration.between(startpnx, endpnx).toMillis();
		log.info(String.format(Constants.TOTAL_TIME_TAKEN, Constants.USER_ENTITY, timeElapsedphnx));
		dataResponse.getLetterData().clear();
		totalCount += totalRecord;
		log.info(String.format("total count and total record for %s : %s : %s", entityName, totalCount, totalRecord));
		return totalRecord;
	}

	/**
	 * This method deletes reconciliation email data from the PHX system.
	 *
	 * @param fetchIncrementalDataLoadAuditId The audit ID for the incremental data
	 *                                        load.
	 * @param totalRecord                     The total number of records processed
	 *                                        so far.
	 * @param batchsize                       The batch size for fetching records.
	 * @param entityName                      The name of the entity.
	 * @param entityCode                      The code of the entity.
	 * @param startJob                        The start job identifier.
	 * @param lastupdatedDate                 The date when the data was last
	 *                                        updated.
	 * @return The total number of records processed.
	 * @throws InterruptedException If the thread executing the method is
	 *                              interrupted.
	 * @throws IOException
	 */
	public Long phxDeleteReconEmail(UUID fetchIncrementalDataLoadAuditId, int batchsize, String entityName,
			String entityCode, String jobEndTime, String lastupdatedDate) throws InterruptedException, IOException {
		long totalRecord = 0l;
		String startDate = null;
		String startdateValue = null;
		DataResponse dataResponse = new DataResponse();
		Instant startpnx = Instant.now();
		
		//Pagination
				String pagingCookie = null;
				int page = 1;
				boolean moreRecords = false;


		do {
			dataResponse.getEmailData().clear();
			startdateValue = (startDate == null || startDate.isEmpty()) ? lastupdatedDate : startDate;
			
			pagingCookie = fetchRecordsFromPhnx(entityName, entityCode, jobEndTime, startdateValue,
					fetchIncrementalDataLoadAuditId,batchsize, dataResponse, moreRecords, pagingCookie,
					page);
			
			log.info(
					String.format(Constants.DATA_RESPONSE, dataResponse.getEmailData().size(), Constants.EMAIL_ENTITY));
			totalRecord += dataResponse.getEmailData().size();
			
			page++;

		} while (pagingCookie != null);
		
		Instant endpnx = Instant.now();
		log.info(String.format(Constants.CODE_ENDED, Constants.EMAIL_ENTITY, endpnx));
		long timeElapsedphnx = Duration.between(startpnx, endpnx).toMillis();
		log.info(String.format(Constants.TOTAL_TIME_TAKEN, Constants.EMAIL_ENTITY, timeElapsedphnx));
		dataResponse.getEmailData().clear();
		totalCount += totalRecord;
		log.info(String.format("total count and total record for %s : %s : %s", entityName, totalCount, totalRecord));
		return totalRecord;
	}

	public Long phxDeleteReconDigitalMessage(UUID fetchIncrementalDataLoadAuditId, int batchsize, String entityName,
			String entityCode, String jobEndTime, String lastupdatedDate) throws InterruptedException, IOException {
		long totalRecord = 0l;
		String startDate = null;
		String startdateValue = null;
		DataResponse dataResponse = new DataResponse();
		Instant startpnx = Instant.now();
		
		//Pagination
				String pagingCookie = null;
				int page = 1;
				boolean moreRecords = false;


		do {
			dataResponse.getDigitalMessageData().clear();
			startdateValue = (startDate == null || startDate.isEmpty()) ? lastupdatedDate : startDate;
			
			pagingCookie = fetchRecordsFromPhnx(entityName, entityCode, jobEndTime, startdateValue,
					fetchIncrementalDataLoadAuditId,batchsize, dataResponse, moreRecords, pagingCookie,
					page);
			
			log.info(String.format(Constants.DATA_RESPONSE, dataResponse.getDigitalMessageData().size(),
					Constants.DIGITALMESSAGE_ENTITY));
			totalRecord += dataResponse.getDigitalMessageData().size();
			
			page++;

		} while (pagingCookie != null);
		
		Instant endpnx = Instant.now();
		log.info(String.format(Constants.CODE_ENDED, Constants.DIGITALMESSAGE_ENTITY, endpnx));
		long timeElapsedphnx = Duration.between(startpnx, endpnx).toMillis();
		log.info(String.format(Constants.TOTAL_TIME_TAKEN, Constants.DIGITALMESSAGE_ENTITY, timeElapsedphnx));
		dataResponse.getDigitalMessageData().clear();
		totalCount += totalRecord;
		log.info(String.format("total count and total record for %s : %s : %s", entityName, totalCount, totalRecord));
		return totalRecord;
	}

	public Long phxDeleteReconCustomerAddress(UUID fetchIncrementalDataLoadAuditId, int batchsize, String entityName,
			String entityCode, String jobEndTime, String lastupdatedDate) throws InterruptedException, IOException {
		long totalRecord = 0l;
		String startDate = null;
		String startdateValue = null;
		DataResponse dataResponse = new DataResponse();
		Instant startpnx = Instant.now();
		
		//Pagination
				String pagingCookie = null;
				int page = 1;
				boolean moreRecords = false;


		do {
			dataResponse.getCustomeraddressData().clear();
			startdateValue = (startDate == null || startDate.isEmpty()) ? lastupdatedDate : startDate;
			
			pagingCookie = fetchRecordsFromPhnx(entityName, entityCode, jobEndTime, startdateValue,
					fetchIncrementalDataLoadAuditId,batchsize, dataResponse, moreRecords, pagingCookie,
					page);
			
			log.info(String.format(Constants.DATA_RESPONSE, dataResponse.getCustomeraddressData().size(),
					Constants.CUSTOMERADDRESS_ENTITY));
			totalRecord += dataResponse.getCustomeraddressData().size();
			
			page++;

		} while (pagingCookie != null);
		
		Instant endpnx = Instant.now();
		log.info(String.format(Constants.CODE_ENDED, Constants.CUSTOMERADDRESS_ENTITY, endpnx));
		long timeElapsedphnx = Duration.between(startpnx, endpnx).toMillis();
		log.info(String.format(Constants.TOTAL_TIME_TAKEN, Constants.CUSTOMERADDRESS_ENTITY, timeElapsedphnx));
		dataResponse.getCustomeraddressData().clear();
		totalCount += totalRecord;
		log.info(String.format("total count and total record for %s : %s : %s", entityName, totalCount, totalRecord));
		return totalRecord;
	}

	public static LocalDateTime getDeleteDatetimeSorting(String deleteDatetime) {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss'Z'");
		return LocalDateTime.parse(deleteDatetime, formatter);
	}

	public void processAccountEntity(JSONArray jsonArray, boolean isLastItem, UUID fetchIncrementalDataLoadAuditId,
			DataResponse newDataRes, String startFormmatedDate, ObjectMapper mapper, int i)
			throws IOException, InterruptedException {
		AccountData objAccount = mapper.readValue(jsonArray.get(i).toString(), AccountData.class);

		JSONObject jsonObj = new JSONObject(jsonArray.get(i).toString());
		objAccount.setAccountid(UUID.fromString(jsonObj.optString(Constants.OBJECTID_VALUE)));
		objAccount.setDeleteDatetime(jsonObj.optString(Constants.CREATED_ON));
		arrayListAccountData.add(objAccount);
		log.info(String.format(Constants.TOTAL_RECORDS, Constants.ACCOUNT_ENTITY, arrayListAccountData.size()));

		if (isLastItem) {
			newDataRes.setAccountData(arrayListAccountData);
			log.info(String.format(Constants.TOTAL_RECORDS, Constants.ACCOUNT_ENTITY, arrayListAccountData.size()));

			List<UUID> accountIds = deleteReconciliationDao.insertRecordAccount(arrayListAccountData,
					fetchIncrementalDataLoadAuditId);
			deleteReconciliationDao.insertRecordIncrementalEntityDelete(fetchIncrementalDataLoadAuditId, accountIds,
					Constants.ACCOUNT_ENTITY);

		}

	}

	public void processIncidentEntity(JSONArray jsonArray, boolean isLastItem, UUID fetchIncrementalDataLoadAuditId,
			DataResponse newDataRes, String startFormmatedDate, ObjectMapper mapper, int i)
			throws IOException, InterruptedException {

		IncidentData objIncident = mapper.readValue(jsonArray.get(i).toString(), IncidentData.class);
		JSONObject jsonObj = new JSONObject(jsonArray.get(i).toString());
		objIncident.setIncidentid(UUID.fromString(jsonObj.optString(Constants.OBJECTID_VALUE)));
		objIncident.setDeleteDatetime(jsonObj.optString(Constants.CREATED_ON));
		arrayListIncidentData.add(objIncident);
		
		if (isLastItem) {
			newDataRes.setIncidentData(arrayListIncidentData);
			log.info(String.format(Constants.TOTAL_RECORDS, Constants.INCIDENT_ENTITY, arrayListIncidentData.size()));


			deleteReconciliationDao.insertRecordIncident(arrayListIncidentData, fetchIncrementalDataLoadAuditId);
			
		}
	}

	public void processCaseLinkEntity(JSONArray jsonArray, boolean isLastItem, UUID fetchIncrementalDataLoadAuditId,
			DataResponse newDataRes, String startFormmatedDate, ObjectMapper mapper, int i)
			throws IOException, InterruptedException {

		CaselinkData caseObjCaselink = mapper.readValue(jsonArray.get(i).toString(), CaselinkData.class);
		JSONObject jsonObj = new JSONObject(jsonArray.get(i).toString());
		caseObjCaselink.setFoscaselinkId(UUID.fromString(jsonObj.optString(Constants.OBJECTID_VALUE)));
		caseObjCaselink.setDeleteDatetime(jsonObj.optString(Constants.CREATED_ON));
		arrayListCaselinkData.add(caseObjCaselink);

		if (isLastItem) {
			newDataRes.setCaselinkData(arrayListCaselinkData);
			log.info(String.format(Constants.TOTAL_RECORDS, Constants.CASELINK_ENTITY, arrayListCaselinkData.size()));

			
			deleteReconciliationDao.insertCaseLink(arrayListCaselinkData, fetchIncrementalDataLoadAuditId);
		}
	}

	public void processContactEntity(JSONArray jsonArray, boolean isLastItem, UUID fetchIncrementalDataLoadAuditId,
			DataResponse newDataRes, String startFormmatedDate, ObjectMapper mapper, int i)
			throws IOException, InterruptedException {

		ContactData objContact = mapper.readValue(jsonArray.get(i).toString(), ContactData.class);
		JSONObject jsonObj = new JSONObject(jsonArray.get(i).toString());
		objContact.setContactid(UUID.fromString(jsonObj.optString(Constants.OBJECTID_VALUE)));
		objContact.setDeleteDatetime(jsonObj.optString(Constants.CREATED_ON));
		arrayListContactData.add(objContact);

		if (isLastItem) {
			newDataRes.setContactData(arrayListContactData);
			log.info(String.format(Constants.TOTAL_RECORDS, Constants.CONTACT_ENTITY, arrayListContactData.size()));

			
			List<UUID> contactIds = deleteReconciliationDao.insertRecordContact(arrayListContactData,
					fetchIncrementalDataLoadAuditId);
			deleteReconciliationDao.insertRecordIncrementalEntityDelete(fetchIncrementalDataLoadAuditId, contactIds,
					Constants.CONTACT_ENTITY);
		}
	}

	public void processEmailEntity(JSONArray jsonArray, boolean isLastItem, UUID fetchIncrementalDataLoadAuditId,
			DataResponse newDataRes, String startFormmatedDate, ObjectMapper mapper, int i)
			throws IOException, InterruptedException {

		EmailData objEmail = mapper.readValue(jsonArray.get(i).toString(), EmailData.class);
		JSONObject jsonObj = new JSONObject(jsonArray.get(i).toString());
		objEmail.setActivityid(UUID.fromString(jsonObj.optString(Constants.OBJECTID_VALUE)));
		objEmail.setDeleteDatetime(jsonObj.optString(Constants.CREATED_ON));
		arrayListEmailData.add(objEmail);

		if (isLastItem) {
			newDataRes.setEmailData(arrayListEmailData);
			log.info(String.format(Constants.TOTAL_RECORDS, Constants.EMAIL_ENTITY, arrayListEmailData.size()));

			deleteReconciliationDao.insertRecordEmail(arrayListEmailData, fetchIncrementalDataLoadAuditId);
		}
	}

	public void processCorrespondenceEntity(JSONArray jsonArray, boolean isLastItem,
			UUID fetchIncrementalDataLoadAuditId, DataResponse newDataRes, String startFormmatedDate,
			ObjectMapper mapper, int i) throws IOException, InterruptedException {

		CorrespondenceData objCorrespondence = mapper.readValue(jsonArray.get(i).toString(), CorrespondenceData.class);
		JSONObject jsonObj = new JSONObject(jsonArray.get(i).toString());
		objCorrespondence.setFosCorespondenceId(UUID.fromString(jsonObj.optString(Constants.OBJECTID_VALUE)));
		objCorrespondence.setDeleteDatetime(jsonObj.optString(Constants.CREATED_ON));
		arrayListCorrespondenceData.add(objCorrespondence);

		if (isLastItem) {
			newDataRes.setCorrespondenceData(arrayListCorrespondenceData);
			log.info(String.format(Constants.TOTAL_RECORDS, Constants.CORREPONDENCE_ENTITY,
					arrayListCorrespondenceData.size()));

			deleteReconciliationDao.insertRecordCorresponce(arrayListCorrespondenceData,
					fetchIncrementalDataLoadAuditId);
		}
	}

	public void processCorrespondenceSourceEntity(JSONArray jsonArray, boolean isLastItem,
			UUID fetchIncrementalDataLoadAuditId, DataResponse newDataRes, String startFormmatedDate,
			ObjectMapper mapper, int i) throws IOException, InterruptedException {

		CorrespondenceSourceData objCorresSource = mapper.readValue(jsonArray.get(i).toString(),
				CorrespondenceSourceData.class);
		JSONObject jsonObj = new JSONObject(jsonArray.get(i).toString());
		objCorresSource.setFosCorespondencesourceId(UUID.fromString(jsonObj.optString(Constants.OBJECTID_VALUE)));
		objCorresSource.setDeleteDatetime(jsonObj.optString(Constants.CREATED_ON));
		arrayListCorrespondenceSourceData.add(objCorresSource);

		if (isLastItem) {
			newDataRes.setCorrespondenceSourceData(arrayListCorrespondenceSourceData);
			log.info(String.format(Constants.TOTAL_RECORDS, Constants.CORRESPONDENCE_SOURCE_ENTITY,
					arrayListCorrespondenceSourceData.size()));

			deleteReconciliationDao.insertRecordcorrespondenceSource(arrayListCorrespondenceSourceData,
					fetchIncrementalDataLoadAuditId);
		}
	}

	public void processLetterEntity(JSONArray jsonArray, boolean isLastItem, UUID fetchIncrementalDataLoadAuditId,
			DataResponse newDataRes, String startFormmatedDate, ObjectMapper mapper, int i)
			throws IOException, InterruptedException {

		LetterData objLetter = mapper.readValue(jsonArray.get(i).toString(), LetterData.class);
		JSONObject jsonObj = new JSONObject(jsonArray.get(i).toString());
		objLetter.setActivityid(UUID.fromString(jsonObj.optString(Constants.OBJECTID_VALUE)));
		objLetter.setDeleteDatetime(jsonObj.optString(Constants.CREATED_ON));
		arrayListLetterData.add(objLetter);

		if (isLastItem) {
			newDataRes.setLetterData(arrayListLetterData);
			log.info(String.format(Constants.TOTAL_RECORDS, Constants.LETTER_ENTITY, arrayListLetterData.size()));

			deleteReconciliationDao.insertRecordLetter(arrayListLetterData, fetchIncrementalDataLoadAuditId);
		}
	}

	public void processUserEntity(JSONArray jsonArray, boolean isLastItem, UUID fetchIncrementalDataLoadAuditId,
			DataResponse newDataRes, String startFormmatedDate, ObjectMapper mapper, int i)
			throws IOException, InterruptedException {

		UserData objUser = mapper.readValue(jsonArray.get(i).toString(), UserData.class);
		JSONObject jsonObj = new JSONObject(jsonArray.get(i).toString());
		objUser.setSystemuserid(UUID.fromString(jsonObj.optString(Constants.OBJECTID_VALUE)));
		objUser.setDeleteDatetime(jsonObj.optString(Constants.CREATED_ON));
		arrayListUserData.add(objUser);

		if (isLastItem) {
			newDataRes.setUserData(arrayListUserData);
			log.info(String.format(Constants.TOTAL_RECORDS, Constants.USER_ENTITY, arrayListUserData.size()));

			deleteReconciliationDao.insertRecordUser(arrayListUserData, fetchIncrementalDataLoadAuditId);
		}
	}

	public void processCaseconsiderationEntity(JSONArray jsonArray, boolean isLastItem,
			UUID fetchIncrementalDataLoadAuditId, DataResponse newDataRes, String startFormmatedDate,
			ObjectMapper mapper, int i) throws IOException, InterruptedException {

		CaseconsiderationData objCaseconsideration = mapper.readValue(jsonArray.get(i).toString(),
				CaseconsiderationData.class);
		JSONObject jsonObj = new JSONObject(jsonArray.get(i).toString());
		objCaseconsideration.setFosCaseconsiderationId(UUID.fromString(jsonObj.optString(Constants.OBJECTID_VALUE)));
		objCaseconsideration.setDeleteDatetime(jsonObj.optString(Constants.CREATED_ON));
		arrayListCaseconsiderationData.add(objCaseconsideration);

		if (isLastItem) {
			newDataRes.setCaseconsiderationData(arrayListCaseconsiderationData);
			log.info(String.format(Constants.TOTAL_RECORDS, Constants.CASECONSIDERATION_ENTITY,
					arrayListCaseconsiderationData.size()));

			deleteReconciliationDao.insertRecordCaseconsideration(arrayListCaseconsiderationData,
					fetchIncrementalDataLoadAuditId);
		}
	}

	public void processPortalEntity(JSONArray jsonArray, boolean isLastItem, UUID fetchIncrementalDataLoadAuditId,
			DataResponse newDataRes, String startFormmatedDate, ObjectMapper mapper, int i)
			throws IOException, InterruptedException {

		PortalData objPortal = mapper.readValue(jsonArray.get(i).toString(), PortalData.class);
		JSONObject jsonObj = new JSONObject(jsonArray.get(i).toString());
		objPortal.setActivityid(UUID.fromString(jsonObj.optString(Constants.OBJECTID_VALUE)));
		objPortal.setDeleteDatetime(jsonObj.optString(Constants.CREATED_ON));
		arrayListPortalData.add(objPortal);

		if (isLastItem) {
			newDataRes.setPortalData(arrayListPortalData);
			log.info(String.format(Constants.TOTAL_RECORDS, Constants.PORTAL_ENTITY, arrayListPortalData.size()));

			deleteReconciliationDao.insertRecordPortal(arrayListPortalData, fetchIncrementalDataLoadAuditId);
		}
	}

	public void processOfferoutcomeEntity(JSONArray jsonArray, boolean isLastItem,
			UUID fetchIncrementalDataLoadAuditId, DataResponse newDataRes, String startFormmatedDate,
			ObjectMapper mapper, int i) throws IOException, InterruptedException {

		OfferoutcomeData objOfferoutcome = mapper.readValue(jsonArray.get(i).toString(), OfferoutcomeData.class);
		JSONObject jsonObj = new JSONObject(jsonArray.get(i).toString());
		objOfferoutcome.setFosOfferoutcomeId(UUID.fromString(jsonObj.optString(Constants.OBJECTID_VALUE)));
		objOfferoutcome.setDeleteDatetime(jsonObj.optString(Constants.CREATED_ON));
		arrayListOfferoutcomeData.add(objOfferoutcome);

		if (isLastItem) {
			newDataRes.setOfferoutcomeData(arrayListOfferoutcomeData);
			log.info(String.format(Constants.TOTAL_RECORDS, Constants.OFFEROUTCOME_ENTITY,
					arrayListOfferoutcomeData.size()));

			deleteReconciliationDao.insertRecordOfferoutcome(arrayListOfferoutcomeData,
					fetchIncrementalDataLoadAuditId);
		}
	}

	public void processPhoneEntity(JSONArray jsonArray, boolean isLastItem, UUID fetchIncrementalDataLoadAuditId,
			DataResponse newDataRes, String startFormmatedDate, ObjectMapper mapper, int i)
			throws IOException, InterruptedException {

		PhoneData objPhone = mapper.readValue(jsonArray.get(i).toString(), PhoneData.class);
		JSONObject jsonObj = new JSONObject(jsonArray.get(i).toString());
		objPhone.setActivityid(UUID.fromString(jsonObj.optString(Constants.OBJECTID_VALUE)));
		objPhone.setDeleteDatetime(jsonObj.optString(Constants.CREATED_ON));
		arrayListPhoneData.add(objPhone);

		if (isLastItem) {
			newDataRes.setPhoneData(arrayListPhoneData);
			log.info(String.format(Constants.TOTAL_RECORDS, Constants.PHONE_ENTITY, arrayListPhoneData.size()));

			deleteReconciliationDao.insertRecordPhone(arrayListPhoneData, fetchIncrementalDataLoadAuditId);
		}
	}

	public void processTaskEntity(JSONArray jsonArray, boolean isLastItem, UUID fetchIncrementalDataLoadAuditId,
			DataResponse newDataRes, String startFormmatedDate, ObjectMapper mapper, int i)
			throws IOException, InterruptedException {

		TaskData objTask = mapper.readValue(jsonArray.get(i).toString(), TaskData.class);
		JSONObject jsonObj = new JSONObject(jsonArray.get(i).toString());
		objTask.setActivityid(UUID.fromString(jsonObj.optString(Constants.OBJECTID_VALUE)));
		objTask.setDeleteDatetime(jsonObj.optString(Constants.CREATED_ON));
		arrayListTaskData.add(objTask);

		if (isLastItem) {
			newDataRes.setTaskData(arrayListTaskData);
			log.info(String.format(Constants.TOTAL_RECORDS, Constants.TASK_ENTITY, arrayListTaskData.size()));

			deleteReconciliationDao.insertRecordTask(arrayListTaskData, fetchIncrementalDataLoadAuditId);
		}
	}

	@Override
	public void processDigitalMessageEntity(JSONArray jsonArray, boolean isLastItem,
			UUID fetchIncrementalDataLoadAuditId, DataResponse newDataRes, String startFormmatedDate,
			ObjectMapper mapper, int i) throws IOException, InterruptedException {
		DigitalMessageData objDigitalMessage = mapper.readValue(jsonArray.get(i).toString(), DigitalMessageData.class);
		JSONObject jsonObj = new JSONObject(jsonArray.get(i).toString());
		objDigitalMessage.setActivityid(UUID.fromString(jsonObj.optString(Constants.OBJECTID_VALUE)));
		objDigitalMessage.setDeleteDatetime(jsonObj.optString(Constants.CREATED_ON));
		arrayListDigitalMessageData.add(objDigitalMessage);

		if (isLastItem) {
			newDataRes.setDigitalMessageData(arrayListDigitalMessageData);
			log.info(String.format(Constants.TOTAL_RECORDS, Constants.DIGITALMESSAGE_ENTITY,
					arrayListDigitalMessageData.size()));

			deleteReconciliationDao.insertRecordDigitalMessageData(arrayListDigitalMessageData,
					fetchIncrementalDataLoadAuditId);
		}
	}

	@Override
	public void processCustomeraddressEntity(JSONArray jsonArray, boolean isLastItem,
			UUID fetchIncrementalDataLoadAuditId, DataResponse newDataRes, String startFormmatedDate,
			ObjectMapper mapper, int i) throws IOException, InterruptedException {
		CustomeraddressData customeraddressData = mapper.readValue(jsonArray.get(i).toString(),
				CustomeraddressData.class);
		JSONObject jsonObj = new JSONObject(jsonArray.get(i).toString());
		customeraddressData.setCustomeraddressid(UUID.fromString(jsonObj.optString(Constants.OBJECTID_VALUE)));
		customeraddressData.setDeleteDatetime(jsonObj.optString(Constants.CREATED_ON));
		arrayListCustomeraddressData.add(customeraddressData);

		if (isLastItem) {
			newDataRes.setCustomeraddressData(arrayListCustomeraddressData);
			log.info(String.format(Constants.TOTAL_RECORDS, Constants.CUSTOMERADDRESS_ENTITY,
					arrayListCustomeraddressData.size()));

			deleteReconciliationDao.insertRecordCustomerAddressData(arrayListCustomeraddressData,
					fetchIncrementalDataLoadAuditId);
		}
	}

	public void processEntity(String entityName, JSONArray jsonArray, boolean isLastItem,
			UUID fetchIncrementalDataLoadAuditId, DataResponse newDataRes, String startFormmatedDate, int index)
			throws IOException, InterruptedException {
		ObjectMapper mapper = new ObjectMapper();
		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		switch (entityName) {

		case Constants.INCIDENT_ENTITY:
			 processIncidentEntity(jsonArray, isLastItem, fetchIncrementalDataLoadAuditId, newDataRes,
					startFormmatedDate, mapper, index);
			 break;

		case Constants.CASELINK_ENTITY:

			 processCaseLinkEntity(jsonArray, isLastItem, fetchIncrementalDataLoadAuditId, newDataRes,
					startFormmatedDate, mapper, index);
			 break;

		case Constants.ACCOUNT_ENTITY:

			 processAccountEntity(jsonArray, isLastItem, fetchIncrementalDataLoadAuditId, newDataRes,
					startFormmatedDate, mapper, index);
			 break;

		case Constants.CONTACT_ENTITY:
			 processContactEntity(jsonArray, isLastItem, fetchIncrementalDataLoadAuditId, newDataRes,
					startFormmatedDate, mapper, index);
			 break;
			 
		case Constants.EMAIL_ENTITY:

			 processEmailEntity(jsonArray, isLastItem, fetchIncrementalDataLoadAuditId, newDataRes,
					startFormmatedDate, mapper, index);
			 break;

		case Constants.CORREPONDENCE_ENTITY:

			 processCorrespondenceEntity(jsonArray, isLastItem, fetchIncrementalDataLoadAuditId, newDataRes,
					startFormmatedDate, mapper, index);
			 break;

		case Constants.CORRESPONDENCE_SOURCE_ENTITY:
			 processCorrespondenceSourceEntity(jsonArray, isLastItem, fetchIncrementalDataLoadAuditId, newDataRes,
					startFormmatedDate, mapper, index);
			 break;

		case Constants.LETTER_ENTITY:

			 processLetterEntity(jsonArray, isLastItem, fetchIncrementalDataLoadAuditId, newDataRes,
					startFormmatedDate, mapper, index);
			 break;

		case Constants.USER_ENTITY:

			 processUserEntity(jsonArray, isLastItem, fetchIncrementalDataLoadAuditId, newDataRes,
					startFormmatedDate, mapper, index);
			 break;

		case Constants.CASECONSIDERATION_ENTITY:

			 processCaseconsiderationEntity(jsonArray, isLastItem, fetchIncrementalDataLoadAuditId, newDataRes,
					startFormmatedDate, mapper, index);
			 break;

		case Constants.PORTAL_ENTITY:

			 processPortalEntity(jsonArray, isLastItem, fetchIncrementalDataLoadAuditId, newDataRes,
					startFormmatedDate, mapper, index);
			 break;

		case Constants.OFFEROUTCOME_ENTITY:
			 processOfferoutcomeEntity(jsonArray, isLastItem, fetchIncrementalDataLoadAuditId, newDataRes,
					startFormmatedDate, mapper, index);
			 break;

		case Constants.PHONE_ENTITY:
			 processPhoneEntity(jsonArray, isLastItem, fetchIncrementalDataLoadAuditId, newDataRes,
					startFormmatedDate, mapper, index);
			 break;

		case Constants.TASK_ENTITY:

			 processTaskEntity(jsonArray, isLastItem, fetchIncrementalDataLoadAuditId, newDataRes,
					startFormmatedDate, mapper, index);
			 break;
			 
		case Constants.DIGITALMESSAGE_ENTITY:
			 processDigitalMessageEntity(jsonArray, isLastItem, fetchIncrementalDataLoadAuditId, newDataRes,
					startFormmatedDate, mapper, index);
			 break;

		case Constants.CUSTOMERADDRESS_ENTITY:
			 processCustomeraddressEntity(jsonArray, isLastItem, fetchIncrementalDataLoadAuditId, newDataRes,
					startFormmatedDate, mapper, index);
			 break;

		default:
			log.info(String.format(": %s : %s", Constants.UNKNOWN_TYPE, entityName));

			break;
		}
		

	}

	public void handleException(Instant startWebJob, Exception e, UUID fetchIncrementalDataLoadAuditId, Long totalCount,
			String entity, int failedCount) {
		log.warn(String.format(Constants.STARTED_CATCH_BLOCK, entity));
		Instant finishWebJobCatch = Instant.now();

		log.info(String.format(Constants.DELETE_RECON_JOB_FINISHED, entity, finishWebJobCatch));
		long timeElapsedWebJobcatch = Duration.between(startWebJob, finishWebJobCatch).toMillis();
		log.info(String.format(Constants.TOTAL_TIME, entity, timeElapsedWebJobcatch));
		log.info(String.format(Constants.MAIL_THREAD, entity));
		ErrorMessageTemplate errorMessageTemplate = ErrorMessageTemplate.setErrorMessage(e.getMessage(), entity,
				fetchIncrementalDataLoadAuditId.toString());
		sendMailNotification.sendErrorNotificationToUserWebclient(errorMessageTemplate);
		log.info(String.format(Constants.INSERT_INTO_ERROR, entity));
		deleteReconciliationDao.insertRecordIncrementalloadError(fetchIncrementalDataLoadAuditId,
				Constants.DATA_PAYLOAD, currentStatusIdFailed, Constants.ERROR_LOG, getStackTraceAsString(e), entity,
				entity);
		deleteReconciliationDao.updateIncrementAuditJobQuery(totalCount, failedCount, currentStatusIdFailed,
				Instant.now().toString(), fetchIncrementalDataLoadAuditId, Constants.DATASOURCE_NAME);
	}

	public static String getStackTraceAsString(Exception e) {

		StringWriter sw = new StringWriter();
		PrintWriter pw = new PrintWriter(sw);
		e.printStackTrace(pw);
		return sw.toString();

	}

	@Override
	public void deleteSubmission() throws IOException, InterruptedException {

		Integer failedCount = 0;
		String Fetch_IncrementalDataLoadAuditId = null;
		Instant startWebJob = Instant.now();
		int current_status_id_failed_ds, current_status_id_readytoprocess_ds, current_status_id_inprogress_ds;

		Integer total_ds = 0;
		Integer totalSuccessCount_ds = 0;

		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS").withZone(ZoneId.of("UTC"));
		String startWebJob_formatted = formatter.format(startWebJob);
		try {

			log.info(String.format("WebJob started for  %s  at : %s ", Constants.DELETE_SUBMISSION, startWebJob));

			// Check if any job is in failed state in last 7 days.Then exit without doing
			// entry in audit table
			int current_status_id_failed = increLoadAuditRep.getCurrentStatusFId(Constants.DATASOURCE_SCH,
					Constants.FAILED);
			int current_status_id_failed_azurfunc = increLoadAuditRep.getCurrentStatusFId(Constants.DELETE_SUBMISSION,
					Constants.FAILED);
			int current_status_id_failed_deleterecon = increLoadAuditRep.getCurrentStatusFId(Constants.DATASOURCE_NAME,
					Constants.FAILED);

			String last7DaysTimeStamp = java.time.LocalDateTime.now().minusDays(7)
					.format(java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss:SSS"));
			int failedCountLast7days = increLoadAuditRep.getFailedEntries(current_status_id_failed,
					current_status_id_failed_azurfunc, current_status_id_failed_deleterecon, last7DaysTimeStamp);

			if (failedCountLast7days > 0) {
				log.warn(String.format("There are failed jobs in the last 7 days, Aborting the process: %s",
						failedCount));

				ErrorMessageTemplate errorMessageTemplate = ErrorMessageTemplate
						.setErrorMessage(Constants.FAILEDMESSAGE, Constants.DELETE_SUBMISSION, "NA");
				errorMessageTemplate.setTemplateId(phoenixHelper.templateId);
				sendMailNotification.sendErrorNotificationToUserWebclient(errorMessageTemplate);

				return;
			}

			// Its own prev entry is running or not
			current_status_id_inprogress_ds = increLoadAuditRep.getCurrentStatusIPId(Constants.DELETE_SUBMISSION,
					Constants.IN_PROGRESS);
			int prevDataprocessingEntry = increLoadAuditRep.getPrevEntries(Constants.DELETE_SUBMISSION,
					current_status_id_inprogress_ds);

			if (prevDataprocessingEntry > 0) {
				log.info(String.format(
						"Previous entry of Delete Submission job is still running, so webJob is exiting for %s at :%s.",
						Constants.DELETE_SUBMISSION, startWebJob));
				return;
			}

			int JobId = increLoadAuditRep.getJobID(Constants.DELETE_SUBMISSION);
			current_status_id_readytoprocess_ds = increLoadAuditRep.getCurrentStatusRTPId(Constants.DELETE_SUBMISSION,
					Constants.STATUS_READY_TO_PROCESS);
			increLoadAuditRep.InsertQuery(JobId, startWebJob_formatted, total_ds, totalSuccessCount_ds, failedCount,
					current_status_id_inprogress_ds, null, Constants.DELETE_SUBMISSION, Constants.DELETE_SUBMISSION,
					Constants.DELETE_SUBMISSION);
			Fetch_IncrementalDataLoadAuditId = increLoadAuditRep.getIncrementalDataLoadAuditId(startWebJob_formatted,
					current_status_id_inprogress_ds, Constants.DELETE_SUBMISSION, Constants.DELETE_SUBMISSION);

			// update all entries from all d_tables where auditId is null to new auditId
			sqlHelper.deletionEntryinAuditTable(failedCount, Fetch_IncrementalDataLoadAuditId,
					current_status_id_readytoprocess_ds, total_ds, totalSuccessCount_ds);

		} catch (Exception e) {
			Instant finishWebJobCatch = Instant.now();

			log.error(String.format("Web job finished for %s  from Catch block at : %s :", Constants.DELETE_SUBMISSION,
					finishWebJobCatch));
			long timeElapsedWebJobcatch = Duration.between(startWebJob, finishWebJobCatch).toMillis();
			log.info(String.format(
					"Error occured while accumulating recs from triggerDelete tables for %s for which Audit is %s, Error logs: %s",
					Constants.DELETE_SUBMISSION, Fetch_IncrementalDataLoadAuditId, e.getMessage()));

			log.info(String.format(
					"****************Total time taken by Webjob for %s  till completion from catch block is %s millisec*************** :",
					Constants.DELETE_SUBMISSION, timeElapsedWebJobcatch));
			String DataPayload = e.getMessage();
			current_status_id_failed_ds = increLoadAuditRep.getCurrentStatusFId(Constants.DELETE_SUBMISSION,
					Constants.FAILED);
			// Entry in Error Table
			increLoadErrorRep.InsertQuery(Fetch_IncrementalDataLoadAuditId, DataPayload, current_status_id_failed_ds,
					Constants.Error_log, e.getMessage(), Constants.DELETE_SUBMISSION, Constants.DELETE_SUBMISSION);

			// Entry in Audit table
			increLoadAuditRep.UpdateQuery(total_ds, totalSuccessCount_ds, failedCount, current_status_id_failed_ds,
					Instant.now().toString(), Fetch_IncrementalDataLoadAuditId, Constants.DELETE_SUBMISSION);
			// Send email to support team
			ErrorMessageTemplate errorMessageTemplate = ErrorMessageTemplate.setErrorMessage(e.getMessage(),
					Constants.DELETE_SUBMISSION, Fetch_IncrementalDataLoadAuditId);
			errorMessageTemplate.setTemplateId(phoenixHelper.templateId);
			sendMailNotification.sendErrorNotificationToUserWebclient(errorMessageTemplate);
			//
			Thread.currentThread().interrupt();
			throw new RuntimeException(String.format("Job failed for %s  with Error : %s", Constants.DELETE_SUBMISSION,
					ExceptionUtils.getStackTrace(e)));

		}

		Instant Finalfinish = Instant.now();

		long timeElapsedcompleteJob = Duration.between(startWebJob, Finalfinish).toMillis();
		log.info(String.format("***************Total time taken for %s entity for Complete Job  is : %s ms ",
				Constants.DELETE_SUBMISSION, timeElapsedcompleteJob));
	}

	private String dateConvertToUtc(final String jobStartTime_temp) {

		String jobStartTime = LocalDateTime
				.parse(jobStartTime_temp, DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSSSSSS"))
				.atZone(ZoneOffset.UTC).format(DateTimeFormatter.ISO_INSTANT);
		return jobStartTime;
	}
	
	private String dateConvertToUtcStart(final String jobStartTime_temp) {

		String jobStartTime = LocalDateTime
				.parse(jobStartTime_temp, DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.S"))
				.atZone(ZoneOffset.UTC).format(DateTimeFormatter.ISO_INSTANT);
		return jobStartTime;
	}
	
	public String getFinalCookie(String dataReturned,String entity,JSONObject jsonObject,boolean moreRecords,String pagingCookie) throws IOException   {
		String responseXml = dataReturned;

		String pagingcookie = jsonObject.isNull("@Microsoft.Dynamics.CRM.fetchxmlpagingcookie") ? null
				: jsonObject.optString("@Microsoft.Dynamics.CRM.fetchxmlpagingcookie");
		String finalcookie = null;
		if (pagingcookie != null) {
			pagingCookie = extractPagingCookie(pagingcookie).replace("\"", "");
			String decodedpagingCookie1 = URLDecoder.decode(pagingCookie, "UTF-8");
			String decodedpagingCookie2 = URLDecoder.decode(decodedpagingCookie1, "UTF-8");
			finalcookie = StringEscapeUtils.escapeXml11(decodedpagingCookie2);

			moreRecords = responseXml.contains("\"@Microsoft.Dynamics.CRM.morerecords\":true");
		}

		/*
		 * log.info(String.format("Recs extracted for %s  from Phoenix call are : %s",
		 * entity, arrayListcontact.size()));
		 */
		log.info(String.format("More records are there for %s : %s", entity, moreRecords));
		return finalcookie;

	}
	
	private String extractPagingCookie(String pagingcookie) {

		Pattern pattern = Pattern.compile("pagingcookie=([^\\s>]+)");
		Matcher matcher = pattern.matcher(pagingcookie);
		return matcher.find() ? matcher.group(1) : null;
	}

}
