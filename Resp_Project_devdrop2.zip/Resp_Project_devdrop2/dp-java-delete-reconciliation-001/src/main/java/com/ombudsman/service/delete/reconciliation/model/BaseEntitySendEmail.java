package com.ombudsman.service.delete.reconciliation.model;

import com.google.gson.annotations.SerializedName;

import jakarta.persistence.MappedSuperclass;
@MappedSuperclass
public  abstract class BaseEntitySendEmail {
	
	@SerializedName("Email")
	   String email;

	   @SerializedName("Name")
	   String name;
	    	
		public void setEmail(String email) {
	        this.email = email;
	    }
	    public String getEmail() {
	        return email;
	    }
	    
	    public void setName(String name) {
	        this.name = name;
	    }
	    public String getName() {
	        return name;
	    }

}
