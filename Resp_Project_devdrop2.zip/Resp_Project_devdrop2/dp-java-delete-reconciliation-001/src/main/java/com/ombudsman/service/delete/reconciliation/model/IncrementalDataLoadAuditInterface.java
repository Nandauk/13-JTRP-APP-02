package com.ombudsman.service.delete.reconciliation.model;

public interface IncrementalDataLoadAuditInterface {
	String getIncrementalDataLoadAuditId();
    void setIncrementalDataLoadAuditId(String incrementalDataLoadAuditId);
}
