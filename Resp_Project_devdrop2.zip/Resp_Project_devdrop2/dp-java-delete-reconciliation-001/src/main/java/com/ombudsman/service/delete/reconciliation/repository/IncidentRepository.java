package com.ombudsman.service.delete.reconciliation.repository;

import java.util.UUID;

import org.springframework.dao.DataAccessException;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import com.ombudsman.service.delete.reconciliation.model.IncidentData;



public interface IncidentRepository  extends JpaRepository<IncidentData, Integer>{
	
	@Modifying
	@Transactional
	@Query(value = "INSERT INTO d_incident(incidentid,incremental_data_load_job_audit_id) VALUES (:incidentid,:fetchIncrementalDataLoadAuditId)", nativeQuery = true)
	int InsertQuery(@Param("incidentid") UUID incidentid, @Param("fetchIncrementalDataLoadAuditId") UUID fetchIncrementalDataLoadAuditId);


}
