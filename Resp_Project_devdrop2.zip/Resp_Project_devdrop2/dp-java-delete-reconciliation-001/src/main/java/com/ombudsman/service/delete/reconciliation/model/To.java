package com.ombudsman.service.delete.reconciliation.model;

public class To extends BaseEntitySendEmail{
	
	

}
