package com.ombudsman.service.delete.reconciliation.serviceimplementation;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ombudsman.service.delete.reconciliation.common.Constants;
import com.ombudsman.service.delete.reconciliation.common.PhoenixHelper;
import com.ombudsman.service.delete.reconciliation.repository.IncrementalAuditRepository;

@Service
public class SqlHelper {

	private static final Logger log = LogManager.getLogger(SqlHelper.class);

	@Autowired
	IncrementalAuditRepository increLoadAuditRep;

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Autowired
	private PhoenixHelper phoenixHelper;

	@Transactional
	public void deletionEntryinAuditTable(Integer failedCount, String Fetch_IncrementalDataLoadAuditId,
			int current_status_id_readytoprocess_ds, Integer total_ds, Integer totalSuccessCount_ds) {

		log.info(String.format("Flag value for Contact entity is : %s,Flag value for Contact entity is : %s",
				phoenixHelper.flag_deleteContactFromAD, phoenixHelper.flag_deleteAccountFromAD));
		String status = "In_Progress";
		for (String tablename : Constants.tablenames) {

			log.info(String.format("Data loading started for table: %s", tablename));
			if (tablename.equalsIgnoreCase("d_contact")
					&& "true".equalsIgnoreCase(phoenixHelper.flag_deleteContactFromAD)) {
				// fetch contactids from d_contact table
				List<Object[]> results = increLoadAuditRep.getContactIds();

				int temp_contact = increLoadAuditRep.updateContactAuditId(Fetch_IncrementalDataLoadAuditId);
				log.info(String.format("Count for table %s is : %s", tablename, temp_contact));
				total_ds += temp_contact;

				// Insert into dp_incremental_entities_delete
				String entityName = "CONTACT_ENTITY";
				for (Object[] result : results) {
					String contactid = (String) result[0];
					increLoadAuditRep.updateDeleteTable(contactid, Fetch_IncrementalDataLoadAuditId, entityName,
							status);
				}
			} else if (tablename.equalsIgnoreCase("d_account")
					&& "true".equalsIgnoreCase(phoenixHelper.flag_deleteAccountFromAD)) {
				// fetch accountids from d_account table
				List<Object[]> resultsAcc = increLoadAuditRep.getAccountids();

				int temp_account = increLoadAuditRep.updateAccountAuditId(Fetch_IncrementalDataLoadAuditId);
				log.info(String.format("Count for table %s is : %s", tablename, temp_account));
				total_ds += temp_account;

				// Insert into dp_incremental_entities_delete
				String entityName = "ACCOUNT_ENTITY";
				for (Object[] resultacc : resultsAcc) {
					String accountid = (String) resultacc[0];
					increLoadAuditRep.updateDeleteTable(accountid, Fetch_IncrementalDataLoadAuditId, entityName,
							status);
				}
			} else {
				String sql = String.format("%s%s%s", "Update ", tablename,
						" set incremental_data_load_job_audit_id=? where incremental_data_load_job_audit_id is NULL");
				int temp_otherTables = jdbcTemplate.update(sql, Fetch_IncrementalDataLoadAuditId);
				log.info(String.format("Count for table %s is : %s", tablename, temp_otherTables));
				total_ds += temp_otherTables;
			}
			log.info(String.format("Data loading finished for table: %s", tablename));
		}

		log.info(String.format("Updating audit table with ready to process state for : %s", Constants.DELETE_SUBMISSION));
		increLoadAuditRep.UpdateQuery(total_ds, totalSuccessCount_ds, failedCount, current_status_id_readytoprocess_ds,
				null, Fetch_IncrementalDataLoadAuditId, Constants.DELETE_SUBMISSION);
	}

}
