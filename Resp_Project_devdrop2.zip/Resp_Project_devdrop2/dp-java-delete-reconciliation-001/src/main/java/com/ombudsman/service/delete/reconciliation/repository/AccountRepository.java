package com.ombudsman.service.delete.reconciliation.repository;

import java.util.UUID;

import org.springframework.dao.DataAccessException;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.ombudsman.service.delete.reconciliation.model.AccountData;


@Repository
public interface AccountRepository extends JpaRepository<AccountData, Integer>{
	
	
	@Modifying
	@Transactional
	@Query(value = "INSERT INTO d_account(accountid,incremental_data_load_job_audit_id) VALUES (:accountid,:fetchIncrementalDataLoadAuditId)", nativeQuery = true)
	int InsertQuery(@Param("accountid") UUID accountid, @Param("fetchIncrementalDataLoadAuditId") UUID fetchIncrementalDataLoadAuditId);
			




}
