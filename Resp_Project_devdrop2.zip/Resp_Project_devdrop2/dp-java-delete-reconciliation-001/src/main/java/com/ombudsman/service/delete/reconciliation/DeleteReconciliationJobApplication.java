package com.ombudsman.service.delete.reconciliation;


import java.io.IOException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;

import com.microsoft.applicationinsights.attach.ApplicationInsights;
import com.microsoft.applicationinsights.connectionstring.ConnectionString;
import com.ombudsman.service.delete.reconciliation.common.KeyVaultUtil;

import com.ombudsman.service.delete.reconciliation.exception.JobFailedException;
import com.ombudsman.service.delete.reconciliation.services.DeletePhnxReconciliationService;

@SpringBootApplication
@EnableScheduling
@EnableAsync
public class DeleteReconciliationJobApplication extends SpringBootServletInitializer {
	private static final Logger log = LogManager.getLogger(DeleteReconciliationJobApplication.class);

	@Value("${RUN_FLAG}")
	public String flag;
	
	static String connectionString=null;

	DeletePhnxReconciliationService deletePhnxReconciliationService;
	
	
	

	public DeleteReconciliationJobApplication(DeletePhnxReconciliationService deletePhnxReconciliationService) {
		this.deletePhnxReconciliationService = deletePhnxReconciliationService;
	}

	public static void main(String[] args) {
		
		ApplicationInsights.attach();
	     String KEYVAULT_URL=System.getenv("KEYVAULT_URL");
	     String APPLICATIONINSIGHTS_CONNECTION_STRING_S="secret-dp-logging-appidpincrfunc-connectionstring";
	     connectionString=KeyVaultUtil.getSecret(KEYVAULT_URL, APPLICATIONINSIGHTS_CONNECTION_STRING_S);
		 ConnectionString.configure(connectionString);
		 
		SpringApplication.run(DeleteReconciliationJobApplication.class, args);
	}

	@Scheduled(cron = "${corn_job_time}")
	public void callingIncident() throws InterruptedException, JobFailedException {
		if ("OFF".equals(flag)) {
			log.debug(String.format("Exiting as the flagvalue for: %s", flag));
			return;
		}
		log.info("Cron job started for delete reconciliation job");
		deletePhnxReconciliationService.processAllJob();
	}

	@Scheduled(cron = "${cron_job_time_delete_submission}")
	public void deleteSubmission() throws  IOException, InterruptedException {
		if ("OFF".equals(flag)) {
			log.debug(String.format("Exiting as the flagvalue for: %s", flag));
			return;
		}
		log.info("Cron job started for delete submission job");
		deletePhnxReconciliationService.deleteSubmission();
	}
}
