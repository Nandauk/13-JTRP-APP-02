package com.ombudsman.service.delete.reconciliation.dao;


import java.text.ParseException;
import java.util.List;
import java.util.UUID;

import com.ombudsman.service.delete.reconciliation.model.AccountData;
import com.ombudsman.service.delete.reconciliation.model.CaseconsiderationData;
import com.ombudsman.service.delete.reconciliation.model.CaselinkData;
import com.ombudsman.service.delete.reconciliation.model.ContactData;
import com.ombudsman.service.delete.reconciliation.model.CorrespondenceData;
import com.ombudsman.service.delete.reconciliation.model.CorrespondenceSourceData;
import com.ombudsman.service.delete.reconciliation.model.CustomeraddressData;
import com.ombudsman.service.delete.reconciliation.model.DigitalMessageData;
import com.ombudsman.service.delete.reconciliation.model.EmailData;
import com.ombudsman.service.delete.reconciliation.model.IncidentData;
import com.ombudsman.service.delete.reconciliation.model.LetterData;
import com.ombudsman.service.delete.reconciliation.model.OfferoutcomeData;
import com.ombudsman.service.delete.reconciliation.model.PhoneData;
import com.ombudsman.service.delete.reconciliation.model.PortalData;
import com.ombudsman.service.delete.reconciliation.model.TaskData;
import com.ombudsman.service.delete.reconciliation.model.UserData;

public interface IDeleteReconciliationDao {
	public int getJobID(String entityName);
	public int getCurrentStatusIPId();
	public void insertToIncrementalAudit(int jobId,int currentStatusIdInprogress,String createdBy,String startWebJobTime)throws ParseException;
	public UUID getIncrementalDataLoadAuditId(int currentStatusIdInprogress, String startWebJobFormatted,String sourceName, String entityName);
	public void insertRecordCorresponce(List<CorrespondenceData> arrayListCorrespondenceData,UUID fetchIncrementalDataLoadAuditId);
	public void insertRecordcorrespondenceSource(List<CorrespondenceSourceData> arrayListCorrespondenceSourceData,UUID fetchIncrementalDataLoadAuditId);
	public void insertRecordEmail(List<EmailData> arrayListEmailData,UUID fetchIncrementalDataLoadAuditId);
	public void insertRecordLetter(List<LetterData> arrayListLetterData,UUID fetchIncrementalDataLoadAuditId);
	public void insertRecordTask(List<TaskData> arrayListTaskData,UUID fetchIncrementalDataLoadAuditId);
	public void insertRecordPortal(List<PortalData> arrayListPortalData ,UUID fetchIncrementalDataLoadAuditId);
	public void insertRecordUser(List<UserData> arrayListUserData,UUID fetchIncrementalDataLoadAuditId);
	public void insertRecordPhone(List<PhoneData> arrayListPhoneData,UUID fetchIncrementalDataLoadAuditId);
	public void insertRecordCaseconsideration(List<CaseconsiderationData> arrayListCaseconsiderationData ,UUID fetchIncrementalDataLoadAuditId);
	public List<UUID> insertRecordAccount(List<AccountData> accountIds,UUID fetchIncrementalDataLoadAuditId);
	public void insertRecordOfferoutcome(List<OfferoutcomeData> arrayListOfferoutcomeData ,UUID fetchIncrementalDataLoadAuditId);
	
	public Integer getCurrentStatusCId(String entity,String status);
	public void insertRecordIncident(List<IncidentData> arrayListIncidentData ,UUID fetchIncrementalDataLoadAuditId);
	public List<UUID> insertRecordContact(List<ContactData> contactData,UUID fetchIncrementalDataLoadAuditId);
	public void insertRecordDigitalMessageData(List<DigitalMessageData> arrayListDigitalMessageData ,UUID fetchIncrementalDataLoadAuditId);
	public void insertRecordCustomerAddressData(List<CustomeraddressData> arrayListCustomeraddressData,
			UUID fetchIncrementalDataLoadAuditId);
	public void insertRecordIncrementalloadError(UUID fetchIncrementalDataLoadAuditId, String dataPayload,
			int currentStatusIdFailed, String errorLog, String stackTrace, String createdBy, String modifiedBy);
	public void updateIncrementAuditJobQuery(Long totalCount, Integer failedCount,
			int currentStatusIdInprogress, String string, UUID fetchIncrementalDataLoadAuditId, String incidentEntity);
	public void insertCaseLink(List<CaselinkData> arrayListCaseLinkData,
			UUID fetchIncrementalDataLoadAuditId);
	public void updateLatestDateCtlTbl(String maxModifedOn, String processName);
	public Long getCountFailedJobsInLast7Days( String source,String  startDate,int failedStatusId);
	public void insertRecordIncrementalEntityDelete(UUID fetchIncrementalDataLoadAuditId, 
			 List<UUID> ids, String entityName) ;
	public String getLatestProcessedDatetime();
}
