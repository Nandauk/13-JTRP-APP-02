package com.ombudsman.service.delete.reconciliation.model;

import java.util.UUID;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.transaction.Transactional;

@Entity
@Table(name = "d_account")
@Transactional
@JsonIgnoreProperties(ignoreUnknown = true)
public class AccountData extends BaseEntity {

	@Id
	private UUID accountid;

	public UUID getAccountid() {
		return accountid;
	}

	public void setAccountid(UUID accountid) {
		this.accountid = accountid;

	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((accountid == null) ? 0 : accountid.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		AccountData other = (AccountData) obj;
		if (accountid == null) {
			if (other.accountid != null)
				return false;
		} else if (!accountid.equals(other.accountid))
			return false;
		return true;
	}
	
	

   
	}