package com.ombudsman.service.delete.reconciliation.daoimplementation;

import static com.ombudsman.service.delete.reconciliation.common.Constants.DATASOURCE_NAME;
import static com.ombudsman.service.delete.reconciliation.common.Constants.IN_PROGRESS;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

import com.ombudsman.service.delete.reconciliation.dao.IDeleteReconciliationDao;
import com.ombudsman.service.delete.reconciliation.model.AccountData;
import com.ombudsman.service.delete.reconciliation.model.CaseconsiderationData;
import com.ombudsman.service.delete.reconciliation.model.CaselinkData;
import com.ombudsman.service.delete.reconciliation.model.ContactData;
import com.ombudsman.service.delete.reconciliation.model.CorrespondenceData;
import com.ombudsman.service.delete.reconciliation.model.CorrespondenceSourceData;
import com.ombudsman.service.delete.reconciliation.model.CustomeraddressData;
import com.ombudsman.service.delete.reconciliation.model.DigitalMessageData;
import com.ombudsman.service.delete.reconciliation.model.EmailData;
import com.ombudsman.service.delete.reconciliation.model.IncidentData;
import com.ombudsman.service.delete.reconciliation.model.IncreLoadAuditData;
import com.ombudsman.service.delete.reconciliation.model.IncreLoadErrorData;
import com.ombudsman.service.delete.reconciliation.model.LetterData;
import com.ombudsman.service.delete.reconciliation.model.OfferoutcomeData;
import com.ombudsman.service.delete.reconciliation.model.PhoneData;
import com.ombudsman.service.delete.reconciliation.model.PortalData;
import com.ombudsman.service.delete.reconciliation.model.TaskData;
import com.ombudsman.service.delete.reconciliation.model.UserData;
import com.ombudsman.service.delete.reconciliation.repository.AccountRepository;
import com.ombudsman.service.delete.reconciliation.repository.CaseLinkRepository;
import com.ombudsman.service.delete.reconciliation.repository.CaseconsiderationRepository;
import com.ombudsman.service.delete.reconciliation.repository.ContactRepository;
import com.ombudsman.service.delete.reconciliation.repository.CorrespondenceRepository;
import com.ombudsman.service.delete.reconciliation.repository.CorrespondenceSourceRepository;
import com.ombudsman.service.delete.reconciliation.repository.CustomeraddressRepository;
import com.ombudsman.service.delete.reconciliation.repository.DigitalmessagesRepository;
import com.ombudsman.service.delete.reconciliation.repository.EmailRepository;
import com.ombudsman.service.delete.reconciliation.repository.IncidentRepository;
import com.ombudsman.service.delete.reconciliation.repository.IncrementalAuditRepository;
import com.ombudsman.service.delete.reconciliation.repository.IncrementalEntityDeleteRepository;
import com.ombudsman.service.delete.reconciliation.repository.IncrementalLoadErrorRepository;
import com.ombudsman.service.delete.reconciliation.repository.IncrementalProcessedRepository;
import com.ombudsman.service.delete.reconciliation.repository.JobMasterRepository;
import com.ombudsman.service.delete.reconciliation.repository.KeyPairMasterRepository;
import com.ombudsman.service.delete.reconciliation.repository.LetterRepository;
import com.ombudsman.service.delete.reconciliation.repository.OfferoutcomeRepository;
import com.ombudsman.service.delete.reconciliation.repository.PhoneRepository;
import com.ombudsman.service.delete.reconciliation.repository.PortalRepository;
import com.ombudsman.service.delete.reconciliation.repository.TaskRepository;
import com.ombudsman.service.delete.reconciliation.repository.UserRepository;

@Component
public class DeleteReconciliationDaoImpl implements IDeleteReconciliationDao {
	private static final Logger log = LogManager.getLogger(DeleteReconciliationDaoImpl.class);

	Integer failedCount = 0;
	Integer totalSuccessCount = 0;
	Integer totalCount = 0;
	JobMasterRepository jobMasterRepository;
	IncrementalAuditRepository incrementalAuditRepository;
	CaseLinkRepository caseLinkRepository;
	IncidentRepository incidentRepository;
	ContactRepository contactRepository;
	IncrementalLoadErrorRepository incrementalLoadErrorRepository;
	KeyPairMasterRepository keyPairMasterRepository;
	CorrespondenceRepository correspondenceRepository;
	CorrespondenceSourceRepository correspondenceSourceRepository;
	EmailRepository emailRepository;
	LetterRepository letterRepository;
	AccountRepository accountRepository;
	TaskRepository taskRepository;
	CaseconsiderationRepository caseconsiderationRepository;
	OfferoutcomeRepository offeroutcomeRepository;
	PhoneRepository phoneRepository;
	PortalRepository portalRepository;
	UserRepository userRepository;
	IncrementalEntityDeleteRepository incrementalEntityDeleteRepository;
	DigitalmessagesRepository digitalmessagesRepository;
	CustomeraddressRepository customeraddressRepository;
	IncrementalProcessedRepository incrementalProcessedRepository;

	public DeleteReconciliationDaoImpl(JobMasterRepository jobMasterRepository,
			IncrementalAuditRepository incrementalAuditRepository, CaseLinkRepository caseLinkRepository,
			IncidentRepository incidentRepository, ContactRepository contactRepository,
			IncrementalLoadErrorRepository incrementalLoadErrorRepository,
			KeyPairMasterRepository keyPairMasterRepository, CorrespondenceRepository correspondenceRepository,
			CorrespondenceSourceRepository correspondenceSourceRepository, EmailRepository emailRepository,
			LetterRepository letterRepository, AccountRepository accountRepository, TaskRepository taskRepository,
			CaseconsiderationRepository caseconsiderationRepository, OfferoutcomeRepository offeroutcomeRepository,
			PhoneRepository phoneRepository, PortalRepository portalRepository, UserRepository userRepository,
			IncrementalEntityDeleteRepository incrementalEntityDeleteRepository,
			DigitalmessagesRepository digitalmessagesRepository, CustomeraddressRepository customeraddressRepository,
			IncrementalProcessedRepository incrementalProcessedRepository) {
		super();
		this.jobMasterRepository = jobMasterRepository;
		this.incrementalAuditRepository = incrementalAuditRepository;
		this.caseLinkRepository = caseLinkRepository;
		this.incidentRepository = incidentRepository;
		this.contactRepository = contactRepository;
		this.incrementalLoadErrorRepository = incrementalLoadErrorRepository;
		this.keyPairMasterRepository = keyPairMasterRepository;
		this.correspondenceRepository = correspondenceRepository;
		this.correspondenceSourceRepository = correspondenceSourceRepository;
		this.emailRepository = emailRepository;
		this.letterRepository = letterRepository;
		this.accountRepository = accountRepository;
		this.taskRepository = taskRepository;
		this.caseconsiderationRepository = caseconsiderationRepository;
		this.offeroutcomeRepository = offeroutcomeRepository;
		this.phoneRepository = phoneRepository;
		this.portalRepository = portalRepository;
		this.userRepository = userRepository;
		this.incrementalEntityDeleteRepository = incrementalEntityDeleteRepository;
		this.digitalmessagesRepository = digitalmessagesRepository;
		this.customeraddressRepository = customeraddressRepository;
		this.incrementalProcessedRepository = incrementalProcessedRepository;

	}

	@Override
	public int getJobID(String entityName) {
		return jobMasterRepository.getJobID(entityName);
	}

	@Override
	public int getCurrentStatusIPId() {
		return keyPairMasterRepository.getCurrentStatusIPId(DATASOURCE_NAME, IN_PROGRESS);
	}

	@Override
	public void insertToIncrementalAudit(int jobId, int currentStatusIdInprogress, String createdBy,
			String startWebJobTime) throws ParseException {

		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date date = format.parse(startWebJobTime);
		final IncreLoadAuditData increLoadAuditData = new IncreLoadAuditData();
		increLoadAuditData.setJobId(jobId);
		increLoadAuditData.setCurrentJobStatusId(currentStatusIdInprogress);
		increLoadAuditData.setCreatedBy(createdBy);
		increLoadAuditData.setJobStartDatetime(startWebJobTime);
		increLoadAuditData.setTotalNumberOfRecords(totalCount);
		increLoadAuditData.setNumberOfFailedRecord(failedCount);
		increLoadAuditData.setCreatedOn(date);
		increLoadAuditData.setSource(DATASOURCE_NAME);
		incrementalAuditRepository.save(increLoadAuditData);
	}

	@Override
	public UUID getIncrementalDataLoadAuditId(int currentStatusIdInprogress, String startWebJobFormatted,
			String sourceName, String createdBy) {
		return incrementalAuditRepository.getIncrementalDataLoadAuditId(currentStatusIdInprogress, sourceName,
				startWebJobFormatted, createdBy);
	}

	

	@Override
	public void insertRecordIncident(List<IncidentData> arrayListIncidentData, UUID fetchIncrementalDataLoadAuditId) {

		List<IncidentData> uniqueIncidentDataList = arrayListIncidentData.stream().filter(distinctByKey(IncidentData::getIncidentid))				
				.collect(Collectors.toList());

		uniqueIncidentDataList.forEach(data -> {
			if (data.getIncidentid() != null) {
				
				incidentRepository.InsertQuery(data.getIncidentid(), fetchIncrementalDataLoadAuditId);
				

			}
		});
	}

	@Override
	public List<UUID> insertRecordContact(List<ContactData> arrayListContactData,
			UUID fetchIncrementalDataLoadAuditId) {
		List<UUID> contacttIds = new ArrayList<>();

		List<ContactData> uniqueContactDataList = arrayListContactData.stream().filter(distinctByKey(ContactData::getContactid)).collect(Collectors.toList());
		
		contacttIds = uniqueContactDataList.stream()
		        .map(ContactData::getContactid)
		        //.filter(Objects::nonNull)
		        .collect(Collectors.toList());

		uniqueContactDataList.forEach(data -> {
			if (data.getContactid() != null) {
			
				contactRepository.InsertQuery(data.getContactid(), fetchIncrementalDataLoadAuditId);
				
			}
		});

		return contacttIds;
	}

	@Override
	public void insertRecordUser(List<UserData> arrayListUserData, UUID fetchIncrementalDataLoadAuditId) {

		List<UserData> uniqueUserDataList = arrayListUserData.stream().filter(distinctByKey(UserData::getSystemuserid)).collect(Collectors.toList());

		uniqueUserDataList.forEach(data -> {
			if (data.getSystemuserid() != null) {
				
				userRepository.InsertQuery(data.getSystemuserid(), fetchIncrementalDataLoadAuditId);
				
			}
		});

	}

	@Override
	public List<UUID> insertRecordAccount(List<AccountData> accountDataList, UUID fetchIncrementalDataLoadAuditId) {
		List<UUID> accountIds = new ArrayList<>();

		List<AccountData> uniqueAccountDataList = accountDataList.stream().filter(distinctByKey(AccountData::getAccountid)).collect(Collectors.toList());
		accountIds = uniqueAccountDataList.stream()
		        .map(AccountData::getAccountid)
		        //.filter(Objects::nonNull)
		        .collect(Collectors.toList());

		uniqueAccountDataList.forEach(data -> {

			if (data.getAccountid() != null) {
				
				accountRepository.InsertQuery(data.getAccountid(), fetchIncrementalDataLoadAuditId);
				
				
			}
		});

		return accountIds;
	}

	@Override
	public void insertRecordCaseconsideration(List<CaseconsiderationData> arrayListCaseconsiderationData,
			UUID fetchIncrementalDataLoadAuditId) {


		List<CaseconsiderationData> uniqueCaseconsDataList = arrayListCaseconsiderationData.stream().filter(distinctByKey(CaseconsiderationData::getFosCaseconsiderationId))
				.collect(Collectors.toList());

		uniqueCaseconsDataList.forEach(data -> {
			if (data.getFosCaseconsiderationId() != null) {
				
				caseconsiderationRepository.InsertQuery(data.getFosCaseconsiderationId(), fetchIncrementalDataLoadAuditId);
				
			}
		});

	}

	@Override
	public void insertRecordOfferoutcome(List<OfferoutcomeData> arrayListOfferoutcomeData,
			UUID fetchIncrementalDataLoadAuditId) {

		List<OfferoutcomeData> uniqueOfferoutcomeDataList = arrayListOfferoutcomeData.stream().filter(distinctByKey(OfferoutcomeData::getFosOfferoutcomeId))
				.collect(Collectors.toList());

		uniqueOfferoutcomeDataList.forEach(data -> {
				if (data.getFosOfferoutcomeId() != null) {
					
					offeroutcomeRepository.InsertQuery(data.getFosOfferoutcomeId(), fetchIncrementalDataLoadAuditId);
					
			}
		});


	}

	@Override
	public void insertRecordPhone(List<PhoneData> arrayListPhoneData, UUID fetchIncrementalDataLoadAuditId) {

		List<PhoneData> uniquePhoneDataList = arrayListPhoneData.stream().filter(distinctByKey(PhoneData::getActivityid)).collect(Collectors.toList());

		uniquePhoneDataList.forEach(data -> {
			if (data.getActivityid() != null) {
				
				phoneRepository.InsertQuery(data.getActivityid(), fetchIncrementalDataLoadAuditId);
				
				
			}
		});

	}

	@Override
	public void insertRecordPortal(List<PortalData> arrayListPortalData, UUID fetchIncrementalDataLoadAuditId) {

		List<PortalData> uniquePortalDataList = arrayListPortalData.stream().filter(distinctByKey(PortalData::getActivityid)).collect(Collectors.toList());

		uniquePortalDataList.forEach(data -> {
			if (data.getActivityid() != null) {
				
				portalRepository.InsertQuery(data.getActivityid(), fetchIncrementalDataLoadAuditId);
				
			}
		});

	}

	@Override
	public void insertRecordTask(List<TaskData> arrayListTaskData, UUID fetchIncrementalDataLoadAuditId) {

		List<TaskData> uniqueTaskDataList = arrayListTaskData.stream().filter(distinctByKey(TaskData::getActivityid)).collect(Collectors.toList());

		uniqueTaskDataList.forEach(data -> {
			if (data.getActivityid() != null) {
				
				taskRepository.InsertQuery(data.getActivityid(), fetchIncrementalDataLoadAuditId);
				
			}
		});

	}

	@Override
	public void insertRecordEmail(List<EmailData> arrayListEmailData, UUID fetchIncrementalDataLoadAuditId) {

		List<EmailData> uniqueEmailDataList = arrayListEmailData.stream().filter(distinctByKey(EmailData::getActivityid)).collect(Collectors.toList());

		uniqueEmailDataList.forEach(data -> {
			if (data.getActivityid() != null) {
				
				emailRepository.InsertQuery(data.getActivityid(), fetchIncrementalDataLoadAuditId);
				
			}
		});

	}

	@Override
	public void insertRecordLetter(List<LetterData> arrayListLetterData, UUID fetchIncrementalDataLoadAuditId) {

		List<LetterData> uniqueLetterDataList = arrayListLetterData.stream().filter(distinctByKey(LetterData::getActivityid)).collect(Collectors.toList());

		uniqueLetterDataList.forEach(data -> {
			if (data.getActivityid() != null) {
				
				letterRepository.InsertQuery(data.getActivityid(), fetchIncrementalDataLoadAuditId);
				
				
			}
		});

	}

	

	@Override
	public Integer getCurrentStatusCId(String entity, String status) {

		return keyPairMasterRepository.getCurrentStatusCId(entity, status);

	}

	@Override
	public void insertRecordIncrementalloadError(UUID fetchIncrementalDataLoadAuditId, String dataPayload,
			int currentStatusIdfailed, String errorLog, String stackTrace, String createdBy, String modifiedBy) {

		IncreLoadErrorData increLoadErrorData = new IncreLoadErrorData();

		increLoadErrorData.setCreatedBy(createdBy);
		increLoadErrorData.setCurrentErrorStatusId((long) currentStatusIdfailed);
		increLoadErrorData.setIncrementalDataLoadAuditId(fetchIncrementalDataLoadAuditId.toString());
		increLoadErrorData.setDataPayLoad(dataPayload);
		increLoadErrorData.setErrorLog(stackTrace);
		increLoadErrorData.setModifiedBy(modifiedBy);
		increLoadErrorData.setErrorCode(errorLog);
		increLoadErrorData.setCreatedOn(new Date());
		increLoadErrorData.setErrorCreatedDatetime(new Date());
		incrementalLoadErrorRepository.save(increLoadErrorData);
	}

	@Override
	public void updateIncrementAuditJobQuery(Long totalCount, Integer failedCount, int currentStatusId, String date,
			UUID fetchIncrementalDataLoadAuditId, String entity) {

		incrementalAuditRepository.updateIncrementDataLoadJobAudit(totalCount, failedCount, currentStatusId, date,
				entity, fetchIncrementalDataLoadAuditId);
	}

	@Override
	public void insertRecordCorresponce(List<CorrespondenceData> arrayListCorrespondenceData,
			UUID fetchIncrementalDataLoadAuditId) {

		List<CorrespondenceData> uniqueCorrespondenceDataList = arrayListCorrespondenceData.stream().filter(distinctByKey(CorrespondenceData::getFosCorespondenceId))
				.collect(Collectors.toList());

		uniqueCorrespondenceDataList.forEach(data -> {
			if (data.getFosCorespondenceId() != null) {
				
				correspondenceRepository.InsertQuery(data.getFosCorespondenceId(), fetchIncrementalDataLoadAuditId);
			
			}
		});


	}

	@Override
	public void insertRecordcorrespondenceSource(List<CorrespondenceSourceData> arrayListCorrespondenceSourceData,
			UUID fetchIncrementalDataLoadAuditId) {


		List<CorrespondenceSourceData> uniqueCorreSourDataList = arrayListCorrespondenceSourceData.stream().filter(distinctByKey(CorrespondenceSourceData::getFosCorespondencesourceId))
				.collect(Collectors.toList());

		uniqueCorreSourDataList.forEach(data -> {
			if (data.getFosCorespondencesourceId() != null) {
				
				correspondenceSourceRepository.InsertQuery(data.getFosCorespondencesourceId(), fetchIncrementalDataLoadAuditId);
				
				
			}
		});


	}

	@Override
	public void insertCaseLink(List<CaselinkData> arrayListCaseLinkData, UUID fetchIncrementalDataLoadAuditId) {
		
		List<CaselinkData> uniqueCaselinkDataList = arrayListCaseLinkData.stream().filter(distinctByKey(CaselinkData::getFoscaselinkId)).collect(Collectors.toList());
		
		for (CaselinkData caseLinkData : uniqueCaselinkDataList) {

			if (caseLinkData.getFoscaselinkId() != null) {
				caseLinkRepository.InsertQuery(caseLinkData.getFoscaselinkId(), fetchIncrementalDataLoadAuditId);
			}

		}
	}

	@Override
	public void updateLatestDateCtlTbl(String maxModifedOn, String processName) {
		log.info("calling updateLatestDateCtlTbl");
		incrementalAuditRepository.updateLatestDateCtlTbl(maxModifedOn, processName);

	}

	@Override
	public Long getCountFailedJobsInLast7Days(String source, String startDate, int failedStatusId) {
		log.info("calling getCountFailedJobsInLast7Days");
		return incrementalAuditRepository.getCountFailedJobsInLast7Days(source, startDate, failedStatusId);
	}

	public void insertRecordIncrementalEntityDelete(UUID fetchIncrementalDataLoadAuditId, List<UUID> ids,
			String entityName) {
		ZonedDateTime utcTime = ZonedDateTime.now(ZoneId.of("UTC"));
		// BST timezone
		ZoneId bstzoneId = ZoneId.of("Europe/London");
		// Convert UTC time to BST , taking DST into account
		ZonedDateTime bsttime = utcTime.withZoneSameInstant(bstzoneId);
		ids.forEach(id -> {
			
			incrementalEntityDeleteRepository.InsertQuery(id, fetchIncrementalDataLoadAuditId,entityName,IN_PROGRESS);
			
		});

	}

	@Override
	public void insertRecordDigitalMessageData(List<DigitalMessageData> arrayListDigitalMessageData,
			UUID fetchIncrementalDataLoadAuditId) {
		
		List<DigitalMessageData> uniqueDigitalMessageDataList = arrayListDigitalMessageData.stream().filter(distinctByKey(DigitalMessageData::getActivityid))
				.collect(Collectors.toList());
		
		uniqueDigitalMessageDataList.forEach(data -> {
			if(data.getActivityid() != null) {
				
				digitalmessagesRepository.InsertQuery(data.getActivityid(), fetchIncrementalDataLoadAuditId);
				
			
			}});
		
	}
	
	@Override
	public void insertRecordCustomerAddressData(List<CustomeraddressData> arrayListCustomeraddressData,
			UUID fetchIncrementalDataLoadAuditId) {
		
		List<CustomeraddressData> uniqueCustomeraddressDataList = arrayListCustomeraddressData.stream().filter(distinctByKey(CustomeraddressData::getCustomeraddressid))
				.collect(Collectors.toList());
		
		uniqueCustomeraddressDataList.forEach(data -> {
			if(data.getCustomeraddressid() != null) {
				
				customeraddressRepository.InsertQuery(data.getCustomeraddressid(), fetchIncrementalDataLoadAuditId);
				
			}});
		
	}

	@Override
	public String getLatestProcessedDatetime() {
		log.info("calling getLatestProcessedDatetime");
		return incrementalProcessedRepository.getLatestProcessedDatetime();
	}

	
	public static <T> Predicate<T> distinctByKey(Function<? super T, ?> keyExtractor) {
        Set<Object> seen = new HashSet<>();
        return t -> seen.add(keyExtractor.apply(t));
    }

}
