package com.ombudsman.service.delete.reconciliation.exception;

public class PhoenixServiceException extends ServiceExceptions {

	private static final long serialVersionUID = 1L;
	

	public PhoenixServiceException(String message, String exceptionMessage) {
		super(message, "PHOENIX_ERROR");
	}

}
