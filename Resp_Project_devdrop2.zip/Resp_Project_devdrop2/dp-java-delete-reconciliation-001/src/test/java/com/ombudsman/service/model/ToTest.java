package com.ombudsman.service.model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.ombudsman.service.delete.reconciliation.model.To;

 class ToTest {

    @Test
    @DisplayName("Test getEmail and setEmail")
    void testGetAndSetEmail() {
        // Given
        To to = new To();
        String email = "test@example.com";

        // When
        to.setEmail(email);

        // Then
        assertEquals(email, to.getEmail());
    }

    @Test
    @DisplayName("Test getName and setName")
    void testGetAndSetName() {
        // Given
        To to = new To();
        String name = "Test Name";

        // When
        to.setName(name);

        // Then
        assertEquals(name, to.getName());
    }}
    
