package com.ombudsman.service.model;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.ombudsman.service.delete.reconciliation.model.IncreLoadAuditData;

import java.util.Date;

class IncreLoadAuditDataTest {

	

	    @Test
	    @DisplayName("Test get and set Incremental_data_load_audit_id")
	    void testGetAndSetIncrementalDataLoadAuditId() {
	        // Given
	        IncreLoadAuditData increLoadAuditData = new IncreLoadAuditData();
	        String incrementalDataLoadAuditId = "test_id";

	        // When
	        increLoadAuditData.setIncrementalDataLoadAuditId(incrementalDataLoadAuditId);

	        // Then
	        assertEquals(incrementalDataLoadAuditId, increLoadAuditData.getIncrementalDataLoadAuditId());
	    }

	    @Test
	    @DisplayName("Test get and set Job_id")
	    void testGetAndSetJobId() {
	        // Given
	        IncreLoadAuditData increLoadAuditData = new IncreLoadAuditData();
	        Integer jobId = 123;

	        // When
	        increLoadAuditData.setJobId(jobId);

	        // Then
	        assertEquals(jobId, increLoadAuditData.getJobId());
	    }

	    @Test
	    @DisplayName("Test get and set Job_start_dateTime")
	    void testGetAndSetJobStartDateTime() {
	        // Given
	        IncreLoadAuditData increLoadAuditData = new IncreLoadAuditData();
	        String jobStartDateTime = "2025-01-01T00:00:00Z";

	        // When
	        increLoadAuditData.setJobStartDatetime(jobStartDateTime);

	        // Then
	        assertEquals(jobStartDateTime, increLoadAuditData.getJobStartDatetime());
	    }

	    @Test
	    @DisplayName("Test get and set Total_number_of_records")
	    void testGetAndSetTotalNumberOfRecords() {
	        // Given
	        IncreLoadAuditData increLoadAuditData = new IncreLoadAuditData();
	        Integer totalNumberOfRecords = 100;

	        // When
	        increLoadAuditData.setTotalNumberOfRecords(totalNumberOfRecords);

	        // Then
	        assertEquals(totalNumberOfRecords, increLoadAuditData.getTotalNumberOfRecords());
	    }

	    @Test
	    @DisplayName("Test get and set Number_of_processed_record")
	    void testGetAndSetNumberOfProcessedRecord() {
	        // Given
	        IncreLoadAuditData increLoadAuditData = new IncreLoadAuditData();
	        Integer numberOfProcessedRecord = 90;

	        // When
	        increLoadAuditData.setNumberOfProcessedRecord(numberOfProcessedRecord);

	        // Then
	        assertEquals(numberOfProcessedRecord, increLoadAuditData.getNumberOfProcessedRecord());
	    }

	    @Test
	    @DisplayName("Test get and set Number_of_failed_record")
	    void testGetAndSetNumberOfFailedRecord() {
	        // Given
	        IncreLoadAuditData increLoadAuditData = new IncreLoadAuditData();
	        Integer numberOfFailedRecord = 10;

	        // When
	        increLoadAuditData.setNumberOfFailedRecord(numberOfFailedRecord);

	        // Then
	        assertEquals(numberOfFailedRecord, increLoadAuditData.getNumberOfFailedRecord());
	    }

	    @Test
	    @DisplayName("Test get and set Current_job_status_id")
	    void testGetAndSetCurrentJobStatusId() {
	        // Given
	        IncreLoadAuditData increLoadAuditData = new IncreLoadAuditData();
	        Integer currentJobStatusId = 1;

	        // When
	        increLoadAuditData.setCurrentJobStatusId(currentJobStatusId);

	        // Then
	        assertEquals(currentJobStatusId, increLoadAuditData.getCurrentJobStatusId());
	    }

	    @Test
	    @DisplayName("Test get and set Job_close_datetime")
	    void testGetAndSetJobCloseDateTime() {
	        // Given
	        IncreLoadAuditData increLoadAuditData = new IncreLoadAuditData();
	        String jobCloseDateTime = "2025-01-01T12:00:00Z";

	        // When
	        increLoadAuditData.setJobCloseDatetime(jobCloseDateTime);

	        // Then
	        assertEquals(jobCloseDateTime, increLoadAuditData.getJobCloseDatetime());
	    }

	    @Test
	    @DisplayName("Test get and set Next_job_run_datetime")
	    void testGetAndSetNextJobRunDateTime() {
	        // Given
	        IncreLoadAuditData increLoadAuditData = new IncreLoadAuditData();
	        String nextJobRunDateTime = "2025-01-02T00:00:00Z";

	        // When
	        increLoadAuditData.setNextJobRunDatetime(nextJobRunDateTime);

	        // Then
	        assertEquals(nextJobRunDateTime, increLoadAuditData.getNextJobRunDatetime());
	    }

	    @Test
	    @DisplayName("Test get and set Source")
	    void testGetAndSetSource() {
	        // Given
	        IncreLoadAuditData increLoadAuditData = new IncreLoadAuditData();
	        String source = "TestSource";

	        // When
	        increLoadAuditData.setSource(source);

	        // Then
	        assertEquals(source, increLoadAuditData.getSource());
	    }

	    @Test
	    @DisplayName("Test get and set Created_on")
	    void testGetAndSetCreatedOn() {
	        // Given
	        IncreLoadAuditData increLoadAuditData = new IncreLoadAuditData();
	        Date createdOn = new Date();

	        // When
	        increLoadAuditData.setCreatedOn(createdOn);

	        // Then
	        assertEquals(createdOn, increLoadAuditData.getCreatedOn());
	    }

	    @Test
	    @DisplayName("Test get and set Modified_on")
	    void testGetAndSetModifiedOn() {
	        // Given
	        IncreLoadAuditData increLoadAuditData = new IncreLoadAuditData();
	        String modifiedOn = "2025-01-01T12:00:00Z";

	        // When
	        increLoadAuditData.setModifiedOn(modifiedOn);

	        // Then
	        assertEquals(modifiedOn, increLoadAuditData.getModifiedOn());
	    }

	    @Test
	    @DisplayName("Test get and set Created_by")
	    void testGetAndSetCreatedBy() {
	        // Given
	        IncreLoadAuditData increLoadAuditData = new IncreLoadAuditData();
	        String createdBy = "TestUser";

	        // When
	        increLoadAuditData.setCreatedBy(createdBy);

	        // Then
	        assertEquals(createdBy, increLoadAuditData.getCreatedBy());
	    }

	    @Test
	    @DisplayName("Test get and set Modified_by")
	    void testGetAndSetModifiedBy() {
	        // Given
	        IncreLoadAuditData increLoadAuditData = new IncreLoadAuditData();
	        String modifiedBy = "TestUser";

	        // When
	        increLoadAuditData.setModifiedBy(modifiedBy);

	        // Then
	        assertEquals(modifiedBy, increLoadAuditData.getModifiedBy());
	    }}