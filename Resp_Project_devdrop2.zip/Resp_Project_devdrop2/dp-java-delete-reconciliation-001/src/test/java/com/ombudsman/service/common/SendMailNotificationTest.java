package com.ombudsman.service.common;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import com.ombudsman.service.delete.reconciliation.common.PhoenixHelper;
import com.ombudsman.service.delete.reconciliation.common.SendMailNotification;
import com.ombudsman.service.delete.reconciliation.model.ErrorMessageTemplate;
import com.ombudsman.service.delete.reconciliation.model.SendMailReq;
import com.ombudsman.service.delete.reconciliation.model.To;

@ExtendWith(MockitoExtension.class)
class SendMailNotificationTest {
	
	@Mock
	private To to1;
	
 

    @InjectMocks
    @Spy
    private SendMailNotification sendMailNotification;
    
    @Mock
    private PhoenixHelper phoenixHelper;
    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);   
        
    }

    @Test
    @DisplayName("Test sendErrorNotificationToUserWebclient")
    void testSendErrorNotificationToUserWebclient(){
        // Given
        ErrorMessageTemplate errorMessageTemplate = new ErrorMessageTemplate();
        errorMessageTemplate.setRole("Test Role");
        errorMessageTemplate.setTemplateId("123");
        errorMessageTemplate.setTemplateName("Test Template");
        errorMessageTemplate.setEntityName("Test Entity");
        errorMessageTemplate.setAuditId("456");
        errorMessageTemplate.setErrorMessage("Test Error");
       
        // Mock the send method
       
        doReturn("success").when(sendMailNotification).send(any(SendMailReq.class));

        // When
        sendMailNotification.sendErrorNotificationToUserWebclient(errorMessageTemplate);

        // Then
        verify(sendMailNotification, times(1)).send(any(SendMailReq.class));
    }

   
    }
