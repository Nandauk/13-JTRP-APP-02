package com.ombudsman.service.model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.UUID;

import org.junit.jupiter.api.Test;

import com.ombudsman.service.delete.reconciliation.model.CorrespondenceSourceData;

class CorrespondenceSourceDataTest {

    @Test
    void testGetSetFosCorrespondencesourceId() {
        CorrespondenceSourceData correspondenceSourceData = new CorrespondenceSourceData();
        UUID fosCorrespondencesourceId = UUID.randomUUID();
        correspondenceSourceData.setFosCorespondencesourceId(fosCorrespondencesourceId);
        assertEquals(fosCorrespondencesourceId, correspondenceSourceData.getFosCorespondencesourceId());
    }

    @Test
    void testGetSetDeleteDatetime() {
        CorrespondenceSourceData correspondenceSourceData = new CorrespondenceSourceData();
        String deleteDatetime = "2025-02-04T20:19:00Z";
        correspondenceSourceData.setDeleteDatetime(deleteDatetime);
        assertEquals(deleteDatetime, correspondenceSourceData.getDeleteDatetime());
    }

    @Test
    void testGetSetIncrementalDataLoadJobAuditId() {
        CorrespondenceSourceData correspondenceSourceData = new CorrespondenceSourceData();
        UUID incrementalDataLoadJobAuditId = UUID.randomUUID();
        correspondenceSourceData.setIncrementalDataLoadJobAuditId(incrementalDataLoadJobAuditId);
        assertEquals(incrementalDataLoadJobAuditId, correspondenceSourceData.getIncrementalDataLoadJobAuditId());
    }

   }
