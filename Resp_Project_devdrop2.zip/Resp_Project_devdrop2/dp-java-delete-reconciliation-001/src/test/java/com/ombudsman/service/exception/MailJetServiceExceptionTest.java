package com.ombudsman.service.exception;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import org.junit.jupiter.api.Test;

import com.ombudsman.service.delete.reconciliation.exception.MailJetServiceException;

 class MailJetServiceExceptionTest {

    @Test
    void testMailJetServiceException() {
        String message = "Test Message";
        String exceptionMessage = "Test Exception Message";
  

        MailJetServiceException exception = new MailJetServiceException(message, exceptionMessage);

        assertNotNull(exception);
        assertEquals(message, exception.getMessage());
        assertEquals("RESPONDENT_AZURE_1000", exception.getCode());
        assertEquals(exceptionMessage, exception.getExceptionMessage());
       
    }
}
