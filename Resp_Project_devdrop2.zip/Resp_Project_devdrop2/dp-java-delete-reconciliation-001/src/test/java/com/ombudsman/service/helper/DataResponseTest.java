package com.ombudsman.service.helper;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;

import com.ombudsman.service.delete.reconciliation.helper.DataResponse;
import com.ombudsman.service.delete.reconciliation.model.AccountData;
import com.ombudsman.service.delete.reconciliation.model.CaseconsiderationData;
import com.ombudsman.service.delete.reconciliation.model.CaselinkData;
import com.ombudsman.service.delete.reconciliation.model.ContactData;
import com.ombudsman.service.delete.reconciliation.model.CorrespondenceData;
import com.ombudsman.service.delete.reconciliation.model.CorrespondenceSourceData;
import com.ombudsman.service.delete.reconciliation.model.EmailData;
import com.ombudsman.service.delete.reconciliation.model.IncidentData;
import com.ombudsman.service.delete.reconciliation.model.LetterData;
import com.ombudsman.service.delete.reconciliation.model.OfferoutcomeData;
import com.ombudsman.service.delete.reconciliation.model.PhoneData;
import com.ombudsman.service.delete.reconciliation.model.PortalData;
import com.ombudsman.service.delete.reconciliation.model.TaskData;
import com.ombudsman.service.delete.reconciliation.model.UserData;

class DataResponseTest {

    @Test
    void testGetSetAccountData() {
        DataResponse dataResponse = new DataResponse();
        List<AccountData> accountData = new ArrayList<>();
        dataResponse.setAccountData(accountData);
        assertEquals(accountData, dataResponse.getAccountData());
    }

    @Test
    void testGetSetCaselinkData() {
        DataResponse dataResponse = new DataResponse();
        List<CaselinkData> caselinkData = new ArrayList<>();
        dataResponse.setCaselinkData(caselinkData);
        assertEquals(caselinkData, dataResponse.getCaselinkData());
    }

    @Test
    void testGetSetCaseconsiderationData() {
        DataResponse dataResponse = new DataResponse();
        List<CaseconsiderationData> caseconsiderationData = new ArrayList<>();
        dataResponse.setCaseconsiderationData(caseconsiderationData);
        assertEquals(caseconsiderationData, dataResponse.getCaseconsiderationData());
    }

    @Test
    void testGetSetContactData() {
        DataResponse dataResponse = new DataResponse();
        List<ContactData> contactData = new ArrayList<>();
        dataResponse.setContactData(contactData);
        assertEquals(contactData, dataResponse.getContactData());
    }

    @Test
    void testGetSetCorrespondenceData() {
        DataResponse dataResponse = new DataResponse();
        List<CorrespondenceData> correspondenceData = new ArrayList<>();
        dataResponse.setCorrespondenceData(correspondenceData);
        assertEquals(correspondenceData, dataResponse.getCorrespondenceData());
    }

    @Test
    void testGetSetCorrespondenceSourceData() {
        DataResponse dataResponse = new DataResponse();
        List<CorrespondenceSourceData> correspondenceSourceData = new ArrayList<>();
        dataResponse.setCorrespondenceSourceData(correspondenceSourceData);
        assertEquals(correspondenceSourceData, dataResponse.getCorrespondenceSourceData());
    }

    @Test
    void testGetSetEmailData() {
        DataResponse dataResponse = new DataResponse();
        List<EmailData> emailData = new ArrayList<>();
        dataResponse.setEmailData(emailData);
        assertEquals(emailData, dataResponse.getEmailData());
    }

    @Test
    void testGetSetIncidentData() {
        DataResponse dataResponse = new DataResponse();
        List<IncidentData> incidentData = new ArrayList<>();
        dataResponse.setIncidentData(incidentData);
        assertEquals(incidentData, dataResponse.getIncidentData());
    }

    @Test
    void testGetSetLetterData() {
        DataResponse dataResponse = new DataResponse();
        List<LetterData> letterData = new ArrayList<>();
        dataResponse.setLetterData(letterData);
        assertEquals(letterData, dataResponse.getLetterData());
    }

    @Test
    void testGetSetPhoneData() {
        DataResponse dataResponse = new DataResponse();
        List<PhoneData> phoneData = new ArrayList<>();
        dataResponse.setPhoneData(phoneData);
        assertEquals(phoneData, dataResponse.getPhoneData());
    }

    @Test
    void testGetSetPortalData() {
        DataResponse dataResponse = new DataResponse();
        List<PortalData> portalData = new ArrayList<>();
        dataResponse.setPortalData(portalData);
        assertEquals(portalData, dataResponse.getPortalData());
    }

    @Test
    void testGetSetTaskData() {
        DataResponse dataResponse = new DataResponse();
        List<TaskData> taskData = new ArrayList<>();
        dataResponse.setTaskData(taskData);
        assertEquals(taskData, dataResponse.getTaskData());
    }

    @Test
    void testGetSetUserData() {
        DataResponse dataResponse = new DataResponse();
        List<UserData> userData = new ArrayList<>();
        dataResponse.setUserData(userData);
        assertEquals(userData, dataResponse.getUserData());
    }

    @Test
    void testGetSetOfferoutcomeData() {
        DataResponse dataResponse = new DataResponse();
        List<OfferoutcomeData> offeroutcomeData = new ArrayList<>();
        dataResponse.setOfferoutcomeData(offeroutcomeData);
        assertEquals(offeroutcomeData, dataResponse.getOfferoutcomeData());
    }
}