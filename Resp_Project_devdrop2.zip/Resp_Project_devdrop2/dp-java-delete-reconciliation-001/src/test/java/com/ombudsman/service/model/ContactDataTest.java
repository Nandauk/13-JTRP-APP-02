package com.ombudsman.service.model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.UUID;

import org.junit.jupiter.api.Test;

import com.ombudsman.service.delete.reconciliation.model.ContactData;

class ContactDataTest {

    @Test
    void testGetSetContactid() {
        ContactData contactData = new ContactData();
        UUID contactId = UUID.randomUUID();
        contactData.setContactid(contactId);
        assertEquals(contactId, contactData.getContactid());
    }

    @Test
    void testGetSetDeleteDatetime() {
        ContactData contactData = new ContactData();
        String deleteDatetime = "2025-02-04T20:19:00Z";
        contactData.setDeleteDatetime(deleteDatetime);
        assertEquals(deleteDatetime, contactData.getDeleteDatetime());
    }

    @Test
    void testGetSetIncrementalDataLoadJobAuditId() {
        ContactData contactData = new ContactData();
        UUID incrementalDataLoadJobAuditId = UUID.randomUUID();
        contactData.setIncrementalDataLoadJobAuditId(incrementalDataLoadJobAuditId);
        assertEquals(incrementalDataLoadJobAuditId, contactData.getIncrementalDataLoadJobAuditId());
    }

   }