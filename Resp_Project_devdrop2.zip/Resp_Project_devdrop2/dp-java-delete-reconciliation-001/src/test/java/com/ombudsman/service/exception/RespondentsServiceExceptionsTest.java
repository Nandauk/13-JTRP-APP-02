package com.ombudsman.service.exception;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import org.junit.jupiter.api.Test;

import com.ombudsman.service.delete.reconciliation.exception.RespondentsServiceExceptions;

 class RespondentsServiceExceptionsTest {

    @Test
    void testExceptionProperties() {
        String message = "Test Message";
        String code = "Test Code";
        String exceptionMessage = "Test Exception Message";


        RespondentsServiceExceptions exception = new RespondentsServiceExceptions(message, code, exceptionMessage);

        assertNotNull(exception);
        assertEquals(message, exception.getMessage());
        assertEquals(code, exception.getCode());
        assertEquals(exceptionMessage, exception.getExceptionMessage());
       
    }
}

