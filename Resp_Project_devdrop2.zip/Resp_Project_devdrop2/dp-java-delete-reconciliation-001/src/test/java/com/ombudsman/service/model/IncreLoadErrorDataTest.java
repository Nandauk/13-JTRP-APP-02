package com.ombudsman.service.model;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import com.ombudsman.service.delete.reconciliation.model.IncreLoadErrorData;

import java.util.Date;
import java.util.UUID;

class IncreLoadErrorDataTest {

    @Test
    void testGetSetIncremental_data_load_error_id() {
        IncreLoadErrorData increLoadErrorData = new IncreLoadErrorData();
        UUID incrementalDataLoadErrorId = UUID.randomUUID();
        increLoadErrorData.setIncrementalDataLoadErrorId(incrementalDataLoadErrorId);
        assertEquals(incrementalDataLoadErrorId, increLoadErrorData.getIncrementalDataLoadErrorId());
    }

    @Test
    void testGetSetIncremental_data_load_audit_id() {
        IncreLoadErrorData increLoadErrorData = new IncreLoadErrorData();
        String incrementalDataLoadAuditId = "Test Audit ID";
        increLoadErrorData.setIncrementalDataLoadAuditId(incrementalDataLoadAuditId);
        assertEquals(incrementalDataLoadAuditId, increLoadErrorData.getIncrementalDataLoadAuditId());
    }

    @Test
    void testGetSetData_pay_load() {
        IncreLoadErrorData increLoadErrorData = new IncreLoadErrorData();
        String dataPayLoad = "Test Data Pay Load";
        increLoadErrorData.setDataPayLoad(dataPayLoad);
        assertEquals(dataPayLoad, increLoadErrorData.getDataPayLoad());
    }

    @Test
    void testGetSetError_created_datetime() {
        IncreLoadErrorData increLoadErrorData = new IncreLoadErrorData();
        Date errorCreatedDatetime = new Date();
        increLoadErrorData.setErrorCreatedDatetime(errorCreatedDatetime);
        assertEquals(errorCreatedDatetime, increLoadErrorData.getErrorCreatedDatetime());
    }

    @Test
    void testGetSetCurrent_error_status_id() {
        IncreLoadErrorData increLoadErrorData = new IncreLoadErrorData();
        Long currentErrorStatusId = 1L;
        increLoadErrorData.setCurrentErrorStatusId(currentErrorStatusId);
        assertEquals(currentErrorStatusId, increLoadErrorData.getCurrentErrorStatusId());
    }

    @Test
    void testGetSetError_code() {
        IncreLoadErrorData increLoadErrorData = new IncreLoadErrorData();
        String errorCode = "Error Code 1";
        increLoadErrorData.setErrorCode(errorCode);
        assertEquals(errorCode, increLoadErrorData.getErrorCode());
    }

    @Test
    void testGetSetError_log() {
        IncreLoadErrorData increLoadErrorData = new IncreLoadErrorData();
        String errorLog = "Error Log 1";
        increLoadErrorData.setErrorLog(errorLog);
        assertEquals(errorLog, increLoadErrorData.getErrorLog());
    }

    @Test
    void testGetSetCreated_on() {
        IncreLoadErrorData increLoadErrorData = new IncreLoadErrorData();
        Date createdOn = new Date();
        increLoadErrorData.setCreatedOn(createdOn);
        assertEquals(createdOn, increLoadErrorData.getCreatedOn());
    }

    @Test
    void testGetSetModified_on() {
        IncreLoadErrorData increLoadErrorData = new IncreLoadErrorData();
        String modifiedOn = "2025-02-04T20:19:00Z";
        increLoadErrorData.setModifiedOn(modifiedOn);
        assertEquals(modifiedOn, increLoadErrorData.getModifiedOn());
    }

    @Test
    void testGetSetCreated_by() {
        IncreLoadErrorData increLoadErrorData = new IncreLoadErrorData();
        String createdBy = "Test Creator";
        increLoadErrorData.setCreatedBy(createdBy);
        assertEquals(createdBy, increLoadErrorData.getCreatedBy());
    }

    @Test
    void testGetSetModified_by() {
        IncreLoadErrorData increLoadErrorData = new IncreLoadErrorData();
        String modifiedBy = "Test Modifier";
        increLoadErrorData.setModifiedBy(modifiedBy);
        assertEquals(modifiedBy, increLoadErrorData.getModifiedBy());
    }
}