package com.ombudsman.service.model;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import com.ombudsman.service.delete.reconciliation.model.From;

class FromTest {

    @Test
    void testGetSetEmail() {
        From from = new From();
        String email = "test@example.com";
        from.setEmail(email);
        assertEquals(email, from.getEmail());
    }

    @Test
    void testGetSetName() {
        From from = new From();
        String name = "John Doe";
        from.setName(name);
        assertEquals(name, from.getName());
    }
}