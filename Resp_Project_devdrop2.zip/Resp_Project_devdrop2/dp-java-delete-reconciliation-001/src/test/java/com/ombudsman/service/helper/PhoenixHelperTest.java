 package com.ombudsman.service.helper;
 import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import com.ombudsman.service.delete.reconciliation.common.PhoenixHelper;

import okhttp3.Request;

@ExtendWith(MockitoExtension.class)
class PhoenixHelperTest {

    @InjectMocks
    private PhoenixHelper phoenixHelper;

    @BeforeEach
    void setUp() {
        // Initialize fields with reflection
        ReflectionTestUtils.setField(phoenixHelper, "startTime", "2025-01-01T00:00:00Z");
        ReflectionTestUtils.setField(phoenixHelper, "endTime", "2025-12-31T23:59:59Z");
        ReflectionTestUtils.setField(phoenixHelper, "pheonixHost", "http://localhost");
        ReflectionTestUtils.setField(phoenixHelper, "offboardServiceBusfullyQualifiedNamespace", "namespace");
        ReflectionTestUtils.setField(phoenixHelper, "offboardqueueName", "queueName");
        ReflectionTestUtils.setField(phoenixHelper, "servicbustenantId", "tenantId");
        ReflectionTestUtils.setField(phoenixHelper, "servicbusclientId", "clientId");
        ReflectionTestUtils.setField(phoenixHelper, "servicebussecretId", "secretId");
        ReflectionTestUtils.setField(phoenixHelper, "fetchRecord", 100);
    }

    @Test
    @DisplayName("Test getPhoenixRequestBuild")
    void testGetPhoenixRequestBuild() {
        String url = "http://example.com/";
        Request request = phoenixHelper.getPhoenixRequestBuild(url);
        assertNotNull(request);
        assertEquals(url, request.url().toString());
        assertEquals("4.0", request.header("OData-MaxVersion"));
        assertEquals("application/json", request.header("Accept"));
    }

    @Test
    @DisplayName("Test getPhoenixHost")
    void testGetPhoenixHost() {
        String expectedHost = "http://localhost";
        String actualHost = phoenixHelper.getPheonixHost();
        assertEquals(expectedHost, actualHost);
    }

    @Test
    @DisplayName("Test getStart_time")
    void testGetStart_time() {
        String expectedStartTime = "2025-01-01T00:00:00Z";
        String actualStartTime = phoenixHelper.getStartTime();
        assertEquals(expectedStartTime, actualStartTime);
    }

    @Test
    @DisplayName("Test getEnd_time")
    void testGetEnd_time() {
        String expectedEndTime = "2025-12-31T23:59:59Z";
        String actualEndTime = phoenixHelper.getEndTime();
        assertEquals(expectedEndTime, actualEndTime);
    }

    @Test
    @DisplayName("Test getFetch_Record")
    void testGetFetch_Record() {
        int expectedFetchRecord = 100;
        int actualFetchRecord = phoenixHelper.getFetchRecord();
        assertEquals(expectedFetchRecord, actualFetchRecord);
    }

	/*
	 * @Test
	 * 
	 * @DisplayName("Test getFetchXML") void testGetFetchXML() { String entityName =
	 * "audit"; String startFormattedDate = "2025-01-01T00:00:00Z"; String
	 * lastUpdatedDate = "2025-01-02T00:00:00Z";
	 * 
	 * String pagingCookie = null; int page = 1; boolean moreRecords = false; int
	 * batchsize = 150;
	 * 
	 * String fetchXml = phoenixHelper.getFetchXML(entityName, startFormattedDate,
	 * lastUpdatedDate,batchsize,pagingCookie,page); assertNotNull(fetchXml);
	 * assertTrue(fetchXml.contains("fetch count='100' page='4'"));
	 * assertTrue(fetchXml.contains("<entity name='audit'>")); assertTrue(fetchXml.
	 * contains("<condition attribute='objecttypecode' operator='eq' value='" +
	 * entityName + "'/>")); assertTrue(fetchXml.
	 * contains("<condition attribute='createdon' operator='gt' value='" +
	 * lastUpdatedDate + "'/>")); assertTrue(fetchXml.
	 * contains("<condition attribute='createdon' operator='le' value='" +
	 * startFormattedDate + "'/>")); }
	 */
}