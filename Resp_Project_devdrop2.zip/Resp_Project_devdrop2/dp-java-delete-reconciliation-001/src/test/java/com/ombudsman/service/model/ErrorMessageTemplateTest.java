package com.ombudsman.service.model;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.ombudsman.service.delete.reconciliation.common.Constants;
import com.ombudsman.service.delete.reconciliation.model.ErrorMessageTemplate;

class ErrorMessageTemplateTest {

    @Test
    void testGetSetTemplateName() {
        ErrorMessageTemplate errorMessageTemplate = new ErrorMessageTemplate();
        String templateName = "Test Template";
        errorMessageTemplate.setTemplateName(templateName);
        assertEquals(templateName, errorMessageTemplate.getTemplateName());
    }

    @Test
    void testGetSetRole() {
        ErrorMessageTemplate errorMessageTemplate = new ErrorMessageTemplate();
        String role = "Admin";
        errorMessageTemplate.setRole(role);
        assertEquals(role, errorMessageTemplate.getRole());
    }

    @Test
    void testGetSetTemplateId() {
        ErrorMessageTemplate errorMessageTemplate = new ErrorMessageTemplate();
        String templateId = "Template_001";
        errorMessageTemplate.setTemplateId(templateId);
        assertEquals(templateId, errorMessageTemplate.getTemplateId());
    }

    @Test
    void testGetSetErrorMessage() {
        ErrorMessageTemplate errorMessageTemplate = new ErrorMessageTemplate();
        String errorMessage = "Error Message Example";
        errorMessageTemplate.setErrorMessage(errorMessage);
        assertEquals(errorMessage, errorMessageTemplate.getErrorMessage());
    }

    @Test
    void testGetSetEntityName() {
        ErrorMessageTemplate errorMessageTemplate = new ErrorMessageTemplate();
        String entityName = "Entity_001";
        errorMessageTemplate.setEntityName(entityName);
        assertEquals(entityName, errorMessageTemplate.getEntityName());
    }

    @Test
    void testGetSetAuditId() {
        ErrorMessageTemplate errorMessageTemplate = new ErrorMessageTemplate();
        String auditId = "Audit_123";
        errorMessageTemplate.setAuditId(auditId);
        assertEquals(auditId, errorMessageTemplate.getAuditId());
    }

    @Test
    void testGetSetErrorTimestamp() {
        ErrorMessageTemplate errorMessageTemplate = new ErrorMessageTemplate();
        String errorTimestamp = "2025-02-04T20:19:00Z";
        errorMessageTemplate.setErrorTimestamp(errorTimestamp);
        assertEquals(errorTimestamp, errorMessageTemplate.getErrorTimestamp());
    }
    

        @Test
        @DisplayName("Test setErrorMessage")
        void testSetErrorMessage() {
            // Given
            String message = "Test error message";
            String entity = "TestEntity";
            String auditId = "12345";
            String expectedRole = "Delete-Reconciliation Job";
            String expectedTemplateName = Constants.TEMPLATE_NAME;
         

            // When
            ErrorMessageTemplate errorMessageTemplate = ErrorMessageTemplate.setErrorMessage(message, entity, auditId);

            // Then
            assertNotNull(errorMessageTemplate);
            assertEquals(expectedRole, errorMessageTemplate.getRole());
            assertEquals(expectedTemplateName, errorMessageTemplate.getTemplateName());
            assertEquals(message, errorMessageTemplate.getErrorMessage());
            assertEquals(entity, errorMessageTemplate.getEntityName());
            assertEquals(auditId, errorMessageTemplate.getAuditId());
            
           
            assertNotNull(errorMessageTemplate.getErrorTimestamp());
     
        
}}