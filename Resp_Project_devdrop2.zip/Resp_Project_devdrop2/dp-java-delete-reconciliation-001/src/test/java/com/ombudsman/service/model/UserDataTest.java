package com.ombudsman.service.model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.UUID;

import org.junit.jupiter.api.Test;

import com.ombudsman.service.delete.reconciliation.model.UserData;

class UserDataTest {

    @Test
    void testGetSetSystemuserid() {
        UserData userData = new UserData();
        UUID systemuserid = UUID.randomUUID();
        userData.setSystemuserid(systemuserid);
        assertEquals(systemuserid, userData.getSystemuserid());
    }

    @Test
    void testGetSetDeleteDatetime() {
        UserData userData = new UserData();
        String deleteDatetime = "2025-02-04T20:19:00Z";
        userData.setDeleteDatetime(deleteDatetime);
        assertEquals(deleteDatetime, userData.getDeleteDatetime());
    }

    @Test
    void testGetSetIncrementalDataLoadJobAuditId() {
        UserData userData = new UserData();
        UUID incrementalDataLoadJobAuditId = UUID.randomUUID();
        userData.setIncrementalDataLoadJobAuditId(incrementalDataLoadJobAuditId);
        assertEquals(incrementalDataLoadJobAuditId, userData.getIncrementalDataLoadJobAuditId());
    }

    }