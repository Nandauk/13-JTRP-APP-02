package com.ombudsman.service.model;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.UUID;

import org.junit.jupiter.api.Test;

import com.ombudsman.service.delete.reconciliation.model.AccountData;

class AccountDataTest {

    @Test
    void testGetSetAccountid() {
        AccountData accountData = new AccountData();
        UUID accountId = UUID.randomUUID();
        accountData.setAccountid(accountId);
        assertEquals(accountId, accountData.getAccountid());
    }

    @Test
    void testGetSetDeleteDatetime() {
        AccountData accountData = new AccountData();
        String deleteDatetime = "2025-02-04T20:19:00Z";
        accountData.setDeleteDatetime(deleteDatetime);
        assertEquals(deleteDatetime, accountData.getDeleteDatetime());
    }

    @Test
    void testGetSetIncrementalDataLoadJobAuditId() {
        AccountData accountData = new AccountData();
        UUID incrementalDataLoadJobAuditId = UUID.randomUUID();
        accountData.setIncrementalDataLoadJobAuditId(incrementalDataLoadJobAuditId);
        assertEquals(incrementalDataLoadJobAuditId, accountData.getIncrementalDataLoadJobAuditId());
    }

   
}
