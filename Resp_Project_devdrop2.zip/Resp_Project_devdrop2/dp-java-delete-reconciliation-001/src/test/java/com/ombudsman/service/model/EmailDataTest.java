package com.ombudsman.service.model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.UUID;

import org.junit.jupiter.api.Test;

import com.ombudsman.service.delete.reconciliation.model.EmailData;

class EmailDataTest {

    @Test
    void testGetSetActivityid() {
        EmailData emailData = new EmailData();
        UUID activityid = UUID.randomUUID();
        emailData.setActivityid(activityid);
        assertEquals(activityid, emailData.getActivityid());
    }

    @Test
    void testGetSetDeleteDatetime() {
        EmailData emailData = new EmailData();
        String deleteDatetime = "2025-02-04T20:19:00Z";
        emailData.setDeleteDatetime(deleteDatetime);
        assertEquals(deleteDatetime, emailData.getDeleteDatetime());
    }

    @Test
    void testGetSetIncrementalDataLoadJobAuditId() {
        EmailData emailData = new EmailData();
        UUID incrementalDataLoadJobAuditId = UUID.randomUUID();
        emailData.setIncrementalDataLoadJobAuditId(incrementalDataLoadJobAuditId);
        assertEquals(incrementalDataLoadJobAuditId, emailData.getIncrementalDataLoadJobAuditId());
    }

    
}
