package com.ombudsman.service.model;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import com.ombudsman.service.delete.reconciliation.model.MailjetVariables;

class MailjetVariablesTest {

    @Test
    void testGetSetTemplateName() {
        MailjetVariables mailjetVariables = new MailjetVariables();
        String templateName = "Test Template";
        mailjetVariables.setTemplateName(templateName);
        assertEquals(templateName, mailjetVariables.getTemplateName());
    }

    @Test
    void testGetSetRole() {
        MailjetVariables mailjetVariables = new MailjetVariables();
        String role = "Admin";
        mailjetVariables.setRole(role);
        assertEquals(role, mailjetVariables.getRole());
    }

    @Test
    void testGetSetTemplateId() {
        MailjetVariables mailjetVariables = new MailjetVariables();
        String templateId = "Template_001";
        mailjetVariables.setTemplateId(templateId);
        assertEquals(templateId, mailjetVariables.getTemplateId());
    }

    @Test
    void testGetSetAuditId() {
        MailjetVariables mailjetVariables = new MailjetVariables();
        String auditId = "Audit_123";
        mailjetVariables.setAuditId(auditId);
        assertEquals(auditId, mailjetVariables.getAuditId());
    }

    @Test
    void testGetSetSource() {
        MailjetVariables mailjetVariables = new MailjetVariables();
        String source = "Source_001";
        mailjetVariables.setSource(source);
        assertEquals(source, mailjetVariables.getSource());
    }

    @Test
    void testGetSetTimestamp() {
        MailjetVariables mailjetVariables = new MailjetVariables();
        String timestamp = "2025-02-04T20:19:00Z";
        mailjetVariables.setTimestamp(timestamp);
        assertEquals(timestamp, mailjetVariables.getTimestamp());
    }

    @Test
    void testGetSetEntityName() {
        MailjetVariables mailjetVariables = new MailjetVariables();
        String entityName = "Entity_001";
        mailjetVariables.setEntityName(entityName);
        assertEquals(entityName, mailjetVariables.getEntityName());
    }

    @Test
    void testGetSetErrorlog() {
        MailjetVariables mailjetVariables = new MailjetVariables();
        String errorlog = "Error Log 1";
        mailjetVariables.setErrorlog(errorlog);
        assertEquals(errorlog, mailjetVariables.getErrorlog());
    }
}