package com.ombudsman.service.exception;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import org.junit.jupiter.api.Test;

import com.ombudsman.service.delete.reconciliation.exception.AzureServiceException;

 class AzureServiceExceptionTest {

    @Test
    void testAzureServiceException() {
        String message = "Test Message";
        String exceptionMessage = "Test Exception Message";


        AzureServiceException exception = new AzureServiceException(message, exceptionMessage);

        assertNotNull(exception);
        assertEquals(message, exception.getMessage());
        assertEquals("RESPONDENT_AZURE_1000", exception.getCode());
        assertEquals(exceptionMessage, exception.getExceptionMessage());
      
    }
}
