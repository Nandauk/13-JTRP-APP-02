package com.ombudsman.service.model;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import com.ombudsman.service.delete.reconciliation.model.OffboardMessage;

class OffboardMessageTest {

    @Test
    void testGetSetAccountId() {
        OffboardMessage offboardMessage = new OffboardMessage();
        String accountId = "Account_001";
        offboardMessage.setAccountId(accountId);
        assertEquals(accountId, offboardMessage.getAccountId());
    }

    @Test
    void testGetSetType() {
        OffboardMessage offboardMessage = new OffboardMessage();
        String type = "Type_001";
        offboardMessage.setType(type);
        assertEquals(type, offboardMessage.getType());
    }

    @Test
    void testGetSetRequestId() {
        OffboardMessage offboardMessage = new OffboardMessage();
        String requestId = "Request_123";
        offboardMessage.setRequestId(requestId);
        assertEquals(requestId, offboardMessage.getRequestId());
    }

    @Test
    void testGetSetEmailId() {
        OffboardMessage offboardMessage = new OffboardMessage();
        String emailId = "user@example.com";
        offboardMessage.setEmailId(emailId);
        assertEquals(emailId, offboardMessage.getEmailId());
    }

    @Test
    void testGetSetName() {
        OffboardMessage offboardMessage = new OffboardMessage();
        String name = "John Doe";
        offboardMessage.setName(name);
        assertEquals(name, offboardMessage.getName());
    }

    @Test
    void testGetSetUserEmailId() {
        OffboardMessage offboardMessage = new OffboardMessage();
        String userEmailId = "johndoe@example.com";
        offboardMessage.setUserEmailId(userEmailId);
        assertEquals(userEmailId, offboardMessage.getUserEmailId());
    }
}