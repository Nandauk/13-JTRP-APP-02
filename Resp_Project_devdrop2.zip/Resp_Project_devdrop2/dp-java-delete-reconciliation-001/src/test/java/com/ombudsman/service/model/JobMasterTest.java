package com.ombudsman.service.model;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import com.ombudsman.service.delete.reconciliation.model.JobMaster;

import java.time.LocalDateTime;

class JobMasterTest {

    @Test
    void testGetSetJobId() {
        JobMaster jobMaster = new JobMaster();
        int jobId = 1;
        jobMaster.setJobId(jobId);
        assertEquals(jobId, jobMaster.getJobId());
    }

    @Test
    void testGetSetEndpointName() {
        JobMaster jobMaster = new JobMaster();
        String endpointName = "Test Endpoint";
        jobMaster.setEndpointName(endpointName);
        assertEquals(endpointName, jobMaster.getEndpointName());
    }

    @Test
    void testGetSetServiceName() {
        JobMaster jobMaster = new JobMaster();
        String serviceName = "Test Service";
        jobMaster.setServiceName(serviceName);
        assertEquals(serviceName, jobMaster.getServiceName());
    }

    @Test
    void testGetSetScheduleType() {
        JobMaster jobMaster = new JobMaster();
        String scheduleType = "Test Schedule";
        jobMaster.setScheduleType(scheduleType);
        assertEquals(scheduleType, jobMaster.getScheduleType());
    }

    @Test
    void testGetSetCronExpression() {
        JobMaster jobMaster = new JobMaster();
        String cronExpression = "0 0 12 * * ?";
        jobMaster.setCronExpression(cronExpression);
        assertEquals(cronExpression, jobMaster.getCronExpression());
    }

    @Test
    void testGetSetJobDescription() {
        JobMaster jobMaster = new JobMaster();
        String jobDescription = "Test Job Description";
        jobMaster.setJobDescription(jobDescription);
        assertEquals(jobDescription, jobMaster.getJobDescription());
    }

    @Test
    void testGetSetJobActivestatus() {
        JobMaster jobMaster = new JobMaster();
        String jobActivestatus = "Active";
        jobMaster.setJobActivestatus(jobActivestatus);
        assertEquals(jobActivestatus, jobMaster.getJobActivestatus());
    }

    @Test
    void testGetSetCreatedOn() {
        JobMaster jobMaster = new JobMaster();
        LocalDateTime createdOn = LocalDateTime.now();
        jobMaster.setCreatedOn(createdOn);
        assertEquals(createdOn, jobMaster.getCreatedOn());
    }

    @Test
    void testGetSetCreatedBy() {
        JobMaster jobMaster = new JobMaster();
        String createdBy = "Test Creator";
        jobMaster.setCreatedBy(createdBy);
        assertEquals(createdBy, jobMaster.getCreatedBy());
    }

    @Test
    void testGetSetModifiedOn() {
        JobMaster jobMaster = new JobMaster();
        LocalDateTime modifiedOn = LocalDateTime.now();
        jobMaster.setModifiedOn(modifiedOn);
        assertEquals(modifiedOn, jobMaster.getModifiedOn());
    }

    @Test
    void testGetSetModifiedBy() {
        JobMaster jobMaster = new JobMaster();
        String modifiedBy = "Test Modifier";
        jobMaster.setModifiedBy(modifiedBy);
        assertEquals(modifiedBy, jobMaster.getModifiedBy());
    }
}