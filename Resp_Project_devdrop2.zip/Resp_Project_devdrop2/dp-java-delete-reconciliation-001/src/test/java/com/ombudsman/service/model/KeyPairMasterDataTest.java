package com.ombudsman.service.model;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import com.ombudsman.service.delete.reconciliation.model.KeyPairMasterData;

import java.time.LocalDateTime;

class KeyPairMasterDataTest {

    @Test
    void testGetSetId() {
        KeyPairMasterData keyPairMasterData = new KeyPairMasterData();
        Integer id = 1;
        keyPairMasterData.setId(id);
        assertEquals(id, keyPairMasterData.getId());
    }

    @Test
    void testGetSetItemValue() {
        KeyPairMasterData keyPairMasterData = new KeyPairMasterData();
        String itemValue = "Test Item Value";
        keyPairMasterData.setItemValue(itemValue);
        assertEquals(itemValue, keyPairMasterData.getItemValue());
    }

    @Test
    void testGetSetDataSourceName() {
        KeyPairMasterData keyPairMasterData = new KeyPairMasterData();
        String dataSourceName = "Test DataSource";
        keyPairMasterData.setDataSourceName(dataSourceName);
        assertEquals(dataSourceName, keyPairMasterData.getDataSourceName());
    }

    @Test
    void testGetSetCreatedOn() {
        KeyPairMasterData keyPairMasterData = new KeyPairMasterData();
        LocalDateTime createdOn = LocalDateTime.now();
        keyPairMasterData.setCreatedOn(createdOn);
        assertEquals(createdOn, keyPairMasterData.getCreatedOn());
    }

    @Test
    void testGetSetCreatedBy() {
        KeyPairMasterData keyPairMasterData = new KeyPairMasterData();
        String createdBy = "Test Created By";
        keyPairMasterData.setCreatedBy(createdBy);
        assertEquals(createdBy, keyPairMasterData.getCreatedBy());
    }

    @Test
    void testGetSetModifiedBy() {
        KeyPairMasterData keyPairMasterData = new KeyPairMasterData();
        String modifiedBy = "Test Modified By";
        keyPairMasterData.setModifiedBy(modifiedBy);
        assertEquals(modifiedBy, keyPairMasterData.getModifiedBy());
    }

    @Test
    void testGetSetModifiedOn() {
        KeyPairMasterData keyPairMasterData = new KeyPairMasterData();
        LocalDateTime modifiedOn = LocalDateTime.now();
        keyPairMasterData.setModifiedOn(modifiedOn);
        assertEquals(modifiedOn, keyPairMasterData.getModifiedOn());
    }
}