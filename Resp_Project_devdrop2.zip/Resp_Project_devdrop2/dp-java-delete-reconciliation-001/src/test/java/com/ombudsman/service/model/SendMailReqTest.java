package com.ombudsman.service.model;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import com.ombudsman.service.delete.reconciliation.model.Messages;
import com.ombudsman.service.delete.reconciliation.model.SendMailReq;

import java.util.Arrays;
import java.util.List;

class SendMailReqTest {

    @Test
    void testGetSetMessages() {
        SendMailReq sendMailReq = new SendMailReq();
        Messages message = new Messages();
        List<Messages> messages = Arrays.asList(message);
        sendMailReq.setMessages(messages);
        assertEquals(messages, sendMailReq.getMessages());
    }
}