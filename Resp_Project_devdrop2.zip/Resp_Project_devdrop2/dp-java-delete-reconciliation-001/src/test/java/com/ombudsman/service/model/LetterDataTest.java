package com.ombudsman.service.model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.UUID;

import org.junit.jupiter.api.Test;

import com.ombudsman.service.delete.reconciliation.model.LetterData;

class LetterDataTest {

    @Test
    void testGetSetActivityid() {
        LetterData letterData = new LetterData();
        UUID activityid = UUID.randomUUID();
        letterData.setActivityid(activityid);
        assertEquals(activityid, letterData.getActivityid());
    }

    @Test
    void testGetSetDeleteDatetime() {
        LetterData letterData = new LetterData();
        String deleteDatetime = "2025-02-04T20:19:00Z";
        letterData.setDeleteDatetime(deleteDatetime);
        assertEquals(deleteDatetime, letterData.getDeleteDatetime());
    }

    @Test
    void testGetSetIncrementalDataLoadJobAuditId() {
        LetterData letterData = new LetterData();
        UUID incrementalDataLoadJobAuditId = UUID.randomUUID();
        letterData.setIncrementalDataLoadJobAuditId(incrementalDataLoadJobAuditId);
        assertEquals(incrementalDataLoadJobAuditId, letterData.getIncrementalDataLoadJobAuditId());
    }

    }