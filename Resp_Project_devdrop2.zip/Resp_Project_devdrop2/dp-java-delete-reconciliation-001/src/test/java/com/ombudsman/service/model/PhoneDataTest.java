package com.ombudsman.service.model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.UUID;

import org.junit.jupiter.api.Test;

import com.ombudsman.service.delete.reconciliation.model.PhoneData;

class PhoneDataTest {

    @Test
    void testGetSetActivityid() {
        PhoneData phoneData = new PhoneData();
        UUID activityid = UUID.randomUUID();
        phoneData.setActivityid(activityid);
        assertEquals(activityid, phoneData.getActivityid());
    }

    @Test
    void testGetSetDeleteDatetime() {
        PhoneData phoneData = new PhoneData();
        String deleteDatetime = "2025-02-04T20:19:00Z";
        phoneData.setDeleteDatetime(deleteDatetime);
        assertEquals(deleteDatetime, phoneData.getDeleteDatetime());
    }

    @Test
    void testGetSetIncrementalDataLoadJobAuditId() {
        PhoneData phoneData = new PhoneData();
        UUID incrementalDataLoadJobAuditId = UUID.randomUUID();
        phoneData.setIncrementalDataLoadJobAuditId(incrementalDataLoadJobAuditId);
        assertEquals(incrementalDataLoadJobAuditId, phoneData.getIncrementalDataLoadJobAuditId());
    }

   }