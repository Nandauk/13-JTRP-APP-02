// package com.ombudsman.service.common;

// import static org.junit.jupiter.api.Assertions.assertEquals;

// import org.junit.jupiter.api.Test;

// import com.ombudsman.service.delete.reconciliation.common.Constants;

//  class ConstantsTest {
	
// 	@Test
//      void testConstants() {
//         assertEquals("/", Constants.SLASH);
//         assertEquals("RCON_DELETE_JOB", Constants.DATASOURCE_NAME);
//         assertEquals("Completed", Constants.COMPLETED);
//         assertEquals("In_Progress", Constants.IN_PROGRESS);
//         assertEquals("INCIDENT_ENTITY", Constants.INCIDENT_ENTITY);
//         assertEquals("CONTACT_ENTITY", Constants.CONTACT_ENTITY);
//         assertEquals("EMAIL_ENTITY", Constants.EMAIL_ENTITY);
//         assertEquals("CORRESPONDENCE_ENTITY", Constants.CORREPONDENCE_ENTITY);
//         assertEquals("CORRESPONDENCESOURCE_ENTITY", Constants.CORRESPONDENCE_SOURCE_ENTITY);
//         assertEquals("ACCOUNT_ENTITY", Constants.ACCOUNT_ENTITY);
//         assertEquals("USER_ENTITY", Constants.USER_ENTITY);
//         assertEquals("CASECONSIDERATION_ENTITY", Constants.CASECONSIDERATION_ENTITY);
//         assertEquals("OFFEROUTCOME_ENTITY", Constants.OFFEROUTCOME_ENTITY);
//         assertEquals("PHONE_ENTITY", Constants.PHONE_ENTITY);
//         assertEquals("PORTAL_ENTITY", Constants.PORTAL_ENTITY);
//         assertEquals("TASK_ENTITY", Constants.TASK_ENTITY);
//         assertEquals("CASELINK_ENTITY", Constants.CASELINK_ENTITY);
//         assertEquals("LETTER_ENTITY", Constants.LETTER_ENTITY);
//         assertEquals("Completed", Constants.STATUS_COMPLETED);
//         assertEquals("Ready_To_Process", Constants.STATUS_READY_TO_PROCESS);
//     }

// }
