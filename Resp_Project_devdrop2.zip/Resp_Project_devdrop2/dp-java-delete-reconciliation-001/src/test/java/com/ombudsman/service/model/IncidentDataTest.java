package com.ombudsman.service.model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.UUID;

import org.junit.jupiter.api.Test;

import com.ombudsman.service.delete.reconciliation.model.IncidentData;

class IncidentDataTest {

    @Test
    void testGetSetIncidentid() {
        IncidentData incidentData = new IncidentData();
        UUID incidentid = UUID.randomUUID();
        incidentData.setIncidentid(incidentid);
        assertEquals(incidentid, incidentData.getIncidentid());
    }

    @Test
    void testGetSetDeleteDatetime() {
        IncidentData incidentData = new IncidentData();
        String deleteDatetime = "2025-02-04T20:19:00Z";
        incidentData.setDeleteDatetime(deleteDatetime);
        assertEquals(deleteDatetime, incidentData.getDeleteDatetime());
    }

    @Test
    void testGetSetIncrementalDataLoadJobAuditId() {
        IncidentData incidentData = new IncidentData();
        UUID incrementalDataLoadJobAuditId = UUID.randomUUID();
        incidentData.setIncrementalDataLoadJobAuditId(incrementalDataLoadJobAuditId);
        assertEquals(incrementalDataLoadJobAuditId, incidentData.getIncrementalDataLoadJobAuditId());
    }

    }