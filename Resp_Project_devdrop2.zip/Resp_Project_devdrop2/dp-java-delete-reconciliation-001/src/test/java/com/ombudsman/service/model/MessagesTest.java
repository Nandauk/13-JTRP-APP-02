package com.ombudsman.service.model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.Test;

import com.ombudsman.service.delete.reconciliation.model.From;
import com.ombudsman.service.delete.reconciliation.model.MailjetVariables;
import com.ombudsman.service.delete.reconciliation.model.Messages;
import com.ombudsman.service.delete.reconciliation.model.To;

class MessagesTest {

    @Test
    void testGetSetFrom() {
        Messages messages = new Messages();
        From from = new From();
        messages.setFrom(from);
        assertEquals(from, messages.getFrom());
    }

    @Test
    void testGetSetTo() {
        Messages messages = new Messages();
        To toRecipient = new To();
        List<To> toRecipients = Arrays.asList(toRecipient);
        messages.setTo(toRecipients);
        assertEquals(toRecipients, messages.getTo());
    }

    @Test
    void testGetSetTemplateID() {
        Messages messages = new Messages();
        int templateID = 123;
        messages.setTemplateID(templateID);
        assertEquals(templateID, messages.getTemplateID());
    }

    @Test
    void testGetSetTemplateLanguage() {
        Messages messages = new Messages();
        boolean templateLanguage = true;
        messages.setTemplateLanguage(templateLanguage);
        assertEquals(templateLanguage, messages.getTemplateLanguage());
    }

    @Test
    void testGetSetVar() {
        Messages messages = new Messages();
        MailjetVariables variables = new MailjetVariables();
        messages.setMailJetVar(variables);
        assertEquals(variables, messages.getMailJetVar());
    }
}