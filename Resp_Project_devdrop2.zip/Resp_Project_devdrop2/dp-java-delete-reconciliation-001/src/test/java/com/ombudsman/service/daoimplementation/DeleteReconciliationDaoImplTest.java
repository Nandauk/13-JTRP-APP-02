/*
 * package com.ombudsman.service.daoimplementation;
 * 
 * import static org.junit.jupiter.api.Assertions.assertEquals; import static
 * org.junit.jupiter.api.Assertions.assertTrue; import static
 * org.mockito.ArgumentMatchers.any; import static
 * org.mockito.ArgumentMatchers.anyList; import static
 * org.mockito.ArgumentMatchers.anyString; import static
 * org.mockito.ArgumentMatchers.eq; import static org.mockito.Mockito.doNothing;
 * import static org.mockito.Mockito.times; import static
 * org.mockito.Mockito.verify; import static org.mockito.Mockito.when;
 * 
 * import java.text.ParseException; import java.text.SimpleDateFormat; import
 * java.time.Instant; import java.util.ArrayList; import java.util.Date; import
 * java.util.List; import java.util.UUID;
 * 
 * import org.junit.jupiter.api.DisplayName; import org.junit.jupiter.api.Test;
 * import org.junit.jupiter.api.extension.ExtendWith; import
 * org.mockito.ArgumentCaptor; import org.mockito.InjectMocks; import
 * org.mockito.Mock; import org.mockito.Spy; import
 * org.mockito.junit.jupiter.MockitoExtension;
 * 
 * import com.ombudsman.service.delete.reconciliation.common.Constants; import
 * com.ombudsman.service.delete.reconciliation.daoimplementation.
 * DeleteReconciliationDaoImpl; import
 * com.ombudsman.service.delete.reconciliation.model.AccountData; import
 * com.ombudsman.service.delete.reconciliation.model.CaseconsiderationData;
 * import com.ombudsman.service.delete.reconciliation.model.CaselinkData; import
 * com.ombudsman.service.delete.reconciliation.model.ContactData; import
 * com.ombudsman.service.delete.reconciliation.model.CorrespondenceData; import
 * com.ombudsman.service.delete.reconciliation.model.CorrespondenceSourceData;
 * import com.ombudsman.service.delete.reconciliation.model.EmailData; import
 * com.ombudsman.service.delete.reconciliation.model.IncidentData; import
 * com.ombudsman.service.delete.reconciliation.model.IncreLoadAuditData; import
 * com.ombudsman.service.delete.reconciliation.model.IncreLoadErrorData; import
 * com.ombudsman.service.delete.reconciliation.model.LetterData; import
 * com.ombudsman.service.delete.reconciliation.model.OfferoutcomeData; import
 * com.ombudsman.service.delete.reconciliation.model.PhoneData; import
 * com.ombudsman.service.delete.reconciliation.model.PortalData; import
 * com.ombudsman.service.delete.reconciliation.model.TaskData; import
 * com.ombudsman.service.delete.reconciliation.model.UserData; import
 * com.ombudsman.service.delete.reconciliation.repository.AccountRepository;
 * import
 * com.ombudsman.service.delete.reconciliation.repository.CaseLinkRepository;
 * import com.ombudsman.service.delete.reconciliation.repository.
 * CaseconsiderationRepository; import
 * com.ombudsman.service.delete.reconciliation.repository.ContactRepository;
 * import com.ombudsman.service.delete.reconciliation.repository.
 * CorrespondenceRepository; import
 * com.ombudsman.service.delete.reconciliation.repository.
 * CorrespondenceSourceRepository; import
 * com.ombudsman.service.delete.reconciliation.repository.EmailRepository;
 * import
 * com.ombudsman.service.delete.reconciliation.repository.IncidentRepository;
 * import com.ombudsman.service.delete.reconciliation.repository.
 * IncrementalAuditRepository; import
 * com.ombudsman.service.delete.reconciliation.repository.
 * IncrementalLoadErrorRepository; import
 * com.ombudsman.service.delete.reconciliation.repository.JobMasterRepository;
 * import com.ombudsman.service.delete.reconciliation.repository.
 * KeyPairMasterRepository; import
 * com.ombudsman.service.delete.reconciliation.repository.LetterRepository;
 * import com.ombudsman.service.delete.reconciliation.repository.
 * OfferoutcomeRepository; import
 * com.ombudsman.service.delete.reconciliation.repository.PhoneRepository;
 * import
 * com.ombudsman.service.delete.reconciliation.repository.PortalRepository;
 * import com.ombudsman.service.delete.reconciliation.repository.TaskRepository;
 * import com.ombudsman.service.delete.reconciliation.repository.UserRepository;
 * 
 * @ExtendWith(MockitoExtension.class) class DeleteReconciliationDaoImplTest {
 * 
 * @InjectMocks
 * 
 * @Spy private DeleteReconciliationDaoImpl deleteReconciliationDaoImpl;
 * 
 * @Mock private JobMasterRepository jobMasterRepository;
 * 
 * @Mock private IncrementalAuditRepository incrementalAuditRepository;
 * 
 * @Mock private CaseLinkRepository caseLinkRepository;
 * 
 * @Mock private IncidentRepository incidentRepository;
 * 
 * @Mock private ContactRepository contactRepository;
 * 
 * @Mock private IncrementalLoadErrorRepository incrementalLoadErrorRepository;
 * 
 * @Mock private KeyPairMasterRepository keyPairMasterRepository;
 * 
 * @Mock private CorrespondenceRepository correspondenceRepository;
 * 
 * @Mock private CorrespondenceSourceRepository correspondenceSourceRepository;
 * 
 * @Mock private EmailRepository emailRepository;
 * 
 * @Mock private LetterRepository letterRepository;
 * 
 * @Mock private AccountRepository accountRepository;
 * 
 * @Mock private TaskRepository taskRepository;
 * 
 * @Mock private CaseconsiderationRepository caseconsiderationRepository;
 * 
 * @Mock private OfferoutcomeRepository offeroutcomeRepository;
 * 
 * @Mock private PhoneRepository phoneRepository;
 * 
 * @Mock private PortalRepository portalRepository;
 * 
 * @Mock private UserRepository userRepository;
 * 
 * private UUID sampleUUID = UUID.randomUUID();
 * 
 * @Test void testGetJobID() {
 * when(jobMasterRepository.getJobID(Constants.ACCOUNT_ENTITY)).thenReturn(1);
 * int jobId = deleteReconciliationDaoImpl.getJobID(Constants.ACCOUNT_ENTITY);
 * assertEquals(1, jobId); }
 * 
 * @Test void testGetCurrentStatusIPId() {
 * when(keyPairMasterRepository.getCurrentStatusIPId(Constants.DATASOURCE_NAME,
 * Constants.IN_PROGRESS)) .thenReturn(1); int currentStatusIPId =
 * deleteReconciliationDaoImpl.getCurrentStatusIPId(); assertEquals(1,
 * currentStatusIPId); }
 * 
 * @Test void testInsertToIncrementalAudit() throws ParseException { // Mock
 * input data
 * 
 * int jobId = 1; int currentStatusIdInprogress = 2; String entityName =
 * "TestEntity"; String startWebJobTime = "2025-02-04 20:19:00"; int totalCount
 * = 100; int failedCount = 5;
 * 
 * // Mock formatted date SimpleDateFormat format = new
 * SimpleDateFormat("yyyy-MM-dd HH:mm:ss"); Date date =
 * format.parse(startWebJobTime);
 * 
 * // Mock IncreLoadAuditData IncreLoadAuditData increLoadAuditData = new
 * IncreLoadAuditData(); increLoadAuditData.setJobId(jobId);
 * increLoadAuditData.setCurrentJobStatusId(currentStatusIdInprogress);
 * increLoadAuditData.setCreatedBy(entityName);
 * increLoadAuditData.setJobStartDatetime(startWebJobTime);
 * increLoadAuditData.setTotalNumberOfRecords(totalCount);
 * increLoadAuditData.setNumberOfFailedRecord(failedCount);
 * increLoadAuditData.setCreatedOn(date);
 * increLoadAuditData.setSource("DataSource");
 * 
 * // Call the method under test
 * deleteReconciliationDaoImpl.insertToIncrementalAudit(jobId,
 * currentStatusIdInprogress, entityName, startWebJobTime);
 * 
 * // Validate the results ArgumentCaptor<IncreLoadAuditData>
 * increLoadAuditDataCaptor = ArgumentCaptor.forClass(IncreLoadAuditData.class);
 * verify(incrementalAuditRepository,
 * times(1)).save(increLoadAuditDataCaptor.capture()); IncreLoadAuditData
 * savedIncreLoadAuditData = increLoadAuditDataCaptor.getValue();
 * 
 * assertEquals(jobId, savedIncreLoadAuditData.getJobId());
 * assertEquals(currentStatusIdInprogress,
 * savedIncreLoadAuditData.getCurrentJobStatusId()); assertEquals(entityName,
 * savedIncreLoadAuditData.getCreatedBy()); assertEquals(startWebJobTime,
 * savedIncreLoadAuditData.getJobStartDatetime());
 * 
 * }
 * 
 * @Test void testGetIncrementalDataLoadAuditId() {
 * when(incrementalAuditRepository.getIncrementalDataLoadAuditId(1,
 * "sourceName", "startTime", "entityName")) .thenReturn(sampleUUID); UUID
 * result = deleteReconciliationDaoImpl.getIncrementalDataLoadAuditId(1,
 * "startTime", "sourceName", "entityName"); assertEquals(sampleUUID, result); }
 * 
 * @Test void testInsertRecordCaseLink() { UUID fetchIncrementalDataLoadAuditId
 * = UUID.randomUUID(); CaselinkData caseLinkData = new CaselinkData();
 * caseLinkData.setFoscaselinkId(UUID.randomUUID());
 * caseLinkData.setDeleteDatetime(Instant.now().toString());
 * 
 * // Call the method under test
 * deleteReconciliationDaoImpl.insertRecordCaseLink(caseLinkData,
 * fetchIncrementalDataLoadAuditId, "SomeEntity");
 * 
 * // Validate the results ArgumentCaptor<CaselinkData> caseLinkDataCaptor =
 * ArgumentCaptor.forClass(CaselinkData.class); verify(caseLinkRepository,
 * times(1)).save(caseLinkDataCaptor.capture()); CaselinkData savedCaseLinkData
 * = caseLinkDataCaptor.getValue();
 * 
 * assertEquals(caseLinkData.getFoscaselinkId(),
 * savedCaseLinkData.getFoscaselinkId());
 * assertEquals(fetchIncrementalDataLoadAuditId,
 * savedCaseLinkData.getIncrementalDataLoadJobAuditId()); }
 * 
 * @SuppressWarnings("unchecked")
 * 
 * @Test void testInsertRecordIncident() {
 * 
 * UUID fetchIncrementalDataLoadAuditId = UUID.randomUUID(); List<IncidentData>
 * incidentDataList = new ArrayList<>(); IncidentData incidentData = new
 * IncidentData(); incidentData.setIncidentid(UUID.randomUUID());
 * incidentData.setDeleteDatetime(Instant.now().toString());
 * incidentDataList.add(incidentData);
 * 
 * // Call the method under test
 * deleteReconciliationDaoImpl.insertRecordIncident(incidentDataList,
 * fetchIncrementalDataLoadAuditId);
 * 
 * // Validate the results ArgumentCaptor<List<IncidentData>> incidentDataCaptor
 * = ArgumentCaptor.forClass(List.class); verify(incidentRepository,
 * times(1)).saveAll(incidentDataCaptor.capture()); List<IncidentData>
 * savedIncidentDataList = incidentDataCaptor.getValue();
 * 
 * assertEquals(1, savedIncidentDataList.size()); IncidentData savedIncidentData
 * = savedIncidentDataList.get(0); assertEquals(incidentData.getIncidentid(),
 * savedIncidentData.getIncidentid());
 * assertEquals(fetchIncrementalDataLoadAuditId,
 * savedIncidentData.getIncrementalDataLoadJobAuditId()); }
 * 
 * @SuppressWarnings("unchecked")
 * 
 * @Test void testInsertRecordContact() { UUID fetchIncrementalDataLoadAuditId =
 * UUID.randomUUID(); List<ContactData> contactDataList = new ArrayList<>();
 * ContactData contactData = new ContactData();
 * contactData.setContactid(UUID.randomUUID());
 * contactData.setDeleteDatetime(Instant.now().toString());
 * contactDataList.add(contactData);
 * 
 * // Call the method under test
 * deleteReconciliationDaoImpl.insertRecordContact(contactDataList,
 * fetchIncrementalDataLoadAuditId);
 * 
 * // Validate the results ArgumentCaptor<List<ContactData>> contactDataCaptor =
 * ArgumentCaptor.forClass(List.class); verify(contactRepository,
 * times(1)).saveAll(contactDataCaptor.capture()); List<ContactData>
 * savedContactDataList = contactDataCaptor.getValue();
 * 
 * assertEquals(1, savedContactDataList.size()); ContactData savedContactData =
 * savedContactDataList.get(0); assertEquals(contactData.getContactid(),
 * savedContactData.getContactid());
 * assertEquals(fetchIncrementalDataLoadAuditId,
 * savedContactData.getIncrementalDataLoadJobAuditId()); }
 * 
 * @Test void testInsertRecordUser() { UUID fetchIncrementalDataLoadAuditId =
 * UUID.randomUUID(); List<UserData> userDataList = new ArrayList<>(); UserData
 * userData = new UserData(); userData.setSystemuserid(UUID.randomUUID());
 * userDataList.add(userData);
 * 
 * // Call the method under test
 * deleteReconciliationDaoImpl.insertRecordUser(userDataList,
 * fetchIncrementalDataLoadAuditId);
 * 
 * // Validate the results verify(userRepository, times(1)).saveAll(anyList());
 * assertTrue(userDataList.contains(userData));
 * 
 * }
 * 
 * @Test void testInsertRecordAccount() { // Mock input data UUID
 * fetchIncrementalDataLoadAuditId = UUID.randomUUID(); List<AccountData>
 * accountDataList = new ArrayList<>(); AccountData accountData = new
 * AccountData(); accountData.setAccountid(UUID.randomUUID());
 * accountDataList.add(accountData);
 * 
 * // Call the method under test List<UUID> result =
 * deleteReconciliationDaoImpl.insertRecordAccount(accountDataList,
 * fetchIncrementalDataLoadAuditId);
 * 
 * // Validate the results assertEquals(1, result.size());
 * assertEquals(accountData.getAccountid(), result.get(0));
 * verify(accountRepository, times(1)).saveAll(anyList()); }
 * 
 * @SuppressWarnings("unchecked")
 * 
 * @Test void testInsertRecordCaseconsideration() { UUID
 * fetchIncrementalDataLoadAuditId = UUID.randomUUID();
 * List<CaseconsiderationData> caseconsiderationDataList = new ArrayList<>();
 * CaseconsiderationData caseconsiderationData = new CaseconsiderationData();
 * caseconsiderationData.setFosCaseconsiderationId(UUID.randomUUID());
 * caseconsiderationData.setDeleteDatetime(Instant.now().toString());
 * caseconsiderationDataList.add(caseconsiderationData);
 * 
 * // Call the method under test
 * deleteReconciliationDaoImpl.insertRecordCaseconsideration(
 * caseconsiderationDataList, fetchIncrementalDataLoadAuditId);
 * 
 * // Validate the results ArgumentCaptor<List<CaseconsiderationData>>
 * caseconsiderationDataCaptor = ArgumentCaptor.forClass(List.class);
 * verify(caseconsiderationRepository,
 * times(1)).saveAll(caseconsiderationDataCaptor.capture());
 * List<CaseconsiderationData> savedCaseconsiderationDataList =
 * caseconsiderationDataCaptor.getValue();
 * 
 * assertEquals(1, savedCaseconsiderationDataList.size()); CaseconsiderationData
 * savedCaseconsiderationData = savedCaseconsiderationDataList.get(0);
 * assertEquals(caseconsiderationData.getFosCaseconsiderationId(),
 * savedCaseconsiderationData.getFosCaseconsiderationId());
 * assertEquals(fetchIncrementalDataLoadAuditId,
 * savedCaseconsiderationData.getIncrementalDataLoadJobAuditId()); }
 * 
 * @SuppressWarnings("unchecked")
 * 
 * @Test void testInsertRecordOfferoutcome() { UUID
 * fetchIncrementalDataLoadAuditId = UUID.randomUUID(); List<OfferoutcomeData>
 * offeroutcomeDataList = new ArrayList<>(); OfferoutcomeData offeroutcomeData =
 * new OfferoutcomeData();
 * offeroutcomeData.setFosOfferoutcomeId(UUID.randomUUID());
 * offeroutcomeData.setDeleteDatetime(Instant.now().toString());
 * offeroutcomeDataList.add(offeroutcomeData);
 * 
 * // Call the method under test
 * deleteReconciliationDaoImpl.insertRecordOfferoutcome(offeroutcomeDataList,
 * fetchIncrementalDataLoadAuditId);
 * 
 * // Validate the results ArgumentCaptor<List<OfferoutcomeData>>
 * offeroutcomeDataCaptor = ArgumentCaptor.forClass(List.class);
 * verify(offeroutcomeRepository,
 * times(1)).saveAll(offeroutcomeDataCaptor.capture()); List<OfferoutcomeData>
 * savedOfferoutcomeDataList = offeroutcomeDataCaptor.getValue();
 * 
 * assertEquals(1, savedOfferoutcomeDataList.size()); OfferoutcomeData
 * savedOfferoutcomeData = savedOfferoutcomeDataList.get(0);
 * assertEquals(offeroutcomeData.getFosOfferoutcomeId(),
 * savedOfferoutcomeData.getFosOfferoutcomeId());
 * assertEquals(fetchIncrementalDataLoadAuditId,
 * savedOfferoutcomeData.getIncrementalDataLoadJobAuditId()); }
 * 
 * @SuppressWarnings("unchecked")
 * 
 * @Test void testInsertRecordPhone() {
 * 
 * // Mock input data UUID fetchIncrementalDataLoadAuditId = UUID.randomUUID();
 * List<PhoneData> phoneDataList = new ArrayList<>(); PhoneData phoneData = new
 * PhoneData(); phoneData.setActivityid(UUID.randomUUID());
 * phoneData.setDeleteDatetime(Instant.now().toString());
 * phoneDataList.add(phoneData);
 * 
 * // Call the method under test
 * deleteReconciliationDaoImpl.insertRecordPhone(phoneDataList,
 * fetchIncrementalDataLoadAuditId);
 * 
 * // Validate the results ArgumentCaptor<List<PhoneData>> phoneDataCaptor =
 * ArgumentCaptor.forClass(List.class); verify(phoneRepository,
 * times(1)).saveAll(phoneDataCaptor.capture()); List<PhoneData>
 * savedPhoneDataList = phoneDataCaptor.getValue();
 * 
 * assertEquals(1, savedPhoneDataList.size()); PhoneData savedPhoneData =
 * savedPhoneDataList.get(0); assertEquals(phoneData.getActivityid(),
 * savedPhoneData.getActivityid());
 * assertEquals(fetchIncrementalDataLoadAuditId,
 * savedPhoneData.getIncrementalDataLoadJobAuditId()); }
 * 
 * @Test
 * 
 * @DisplayName("Test insertCaseLink") void testInsertCaseLink() { // Given
 * List<CaselinkData> arrayListCaseLinkData = new ArrayList<>(); CaselinkData
 * data1 = new CaselinkData(); data1.setFoscaselinkId(UUID.randomUUID());
 * arrayListCaseLinkData.add(data1);
 * 
 * UUID fetchIncrementalDataLoadAuditId = UUID.randomUUID();
 * 
 * // Mock the insertRecordCaseLink method
 * doNothing().when(deleteReconciliationDaoImpl).insertRecordCaseLink(any(
 * CaselinkData.class), any(UUID.class), anyString());
 * 
 * // When deleteReconciliationDaoImpl.insertCaseLink(arrayListCaseLinkData,
 * fetchIncrementalDataLoadAuditId);
 * 
 * // Then verify(deleteReconciliationDaoImpl,
 * times(1)).insertRecordCaseLink(any(CaselinkData.class),
 * eq(fetchIncrementalDataLoadAuditId), eq(Constants.CASELINK_ENTITY)); }
 * 
 * @Test
 * 
 * @DisplayName("Test updateLatestDateCtlTbl") void testUpdateLatestDateCtlTbl()
 * { // Given String maxModifedOn = "2025-01-01"; String processName =
 * "TestProcess";
 * 
 * // When deleteReconciliationDaoImpl.updateLatestDateCtlTbl(maxModifedOn,
 * processName);
 * 
 * // Then verify(incrementalAuditRepository,
 * times(1)).updateLatestDateCtlTbl(maxModifedOn, processName); }
 * 
 * @Test
 * 
 * @DisplayName("Test insertRecordcorrespondenceSource") void
 * testInsertRecordcorrespondenceSource() { // Given
 * List<CorrespondenceSourceData> arrayListCorrespondenceSourceData = new
 * ArrayList<>(); CorrespondenceSourceData data1 = new
 * CorrespondenceSourceData();
 * data1.setFosCorespondencesourceId(UUID.randomUUID());
 * data1.setDeleteDatetime(Instant.now().toString());
 * arrayListCorrespondenceSourceData.add(data1);
 * 
 * UUID fetchIncrementalDataLoadAuditId = UUID.randomUUID();
 * 
 * // When deleteReconciliationDaoImpl.insertRecordcorrespondenceSource(
 * arrayListCorrespondenceSourceData, fetchIncrementalDataLoadAuditId);
 * 
 * // Then verify(correspondenceSourceRepository, times(1)).saveAll(anyList());
 * }
 * 
 * @Test
 * 
 * @DisplayName("Test insertRecordCorresponce") void
 * testInsertRecordCorresponce() { // Given List<CorrespondenceData>
 * arrayListCorrespondenceData = new ArrayList<>(); CorrespondenceData data1 =
 * new CorrespondenceData(); data1.setFosCorespondenceId(UUID.randomUUID());
 * data1.setDeleteDatetime(Instant.now().toString());
 * arrayListCorrespondenceData.add(data1);
 * 
 * UUID fetchIncrementalDataLoadAuditId = UUID.randomUUID();
 * 
 * // When deleteReconciliationDaoImpl.insertRecordCorresponce(
 * arrayListCorrespondenceData, fetchIncrementalDataLoadAuditId);
 * 
 * // Then verify(correspondenceRepository, times(1)).saveAll(anyList()); }
 * 
 * @Test
 * 
 * @DisplayName("Test updateIncrementAuditJobQuery") void
 * 
 * testUpdateIncrementAuditJobQuery() { // Given Long totalCount = 100L; Integer
 * 
 * failedCount = 10; int currentStatusId = 1; String date = "2025-01-01"; UUID
 * fetchIncrementalDataLoadAuditId = UUID.randomUUID(); String entity =
 * "TestEntity";
 * 
 * // When deleteReconciliationDaoImpl.updateIncrementAuditJobQuery(totalCount,
 * failedCount, currentStatusId, date, fetchIncrementalDataLoadAuditId, entity);
 * 
 * // Then verify(incrementalAuditRepository,
 * times(1)).updateIncrementDataLoadJobAudit(totalCount, failedCount,
 * currentStatusId, date, entity, fetchIncrementalDataLoadAuditId); }
 * 
 * @Test
 * 
 * @DisplayName("Test insertRecordIncrementalloadError") void
 * testInsertRecordIncrementalloadError() { // Given UUID
 * fetchIncrementalDataLoadAuditId = UUID.randomUUID(); String dataPayload =
 * "test payload"; int currentStatusIdFailed = 1; String errorLog =
 * "test error log"; String stackTrace = "test stack trace"; String createdBy =
 * "test creator"; String modifiedBy = "test modifier";
 * 
 * IncreLoadErrorData increLoadErrorData = new IncreLoadErrorData();
 * increLoadErrorData.setCreatedBy(createdBy);
 * increLoadErrorData.setCurrentErrorStatusId((long) currentStatusIdFailed);
 * increLoadErrorData.setIncrementalDataLoadAuditId(
 * fetchIncrementalDataLoadAuditId.toString());
 * increLoadErrorData.setDataPayLoad(dataPayload);
 * increLoadErrorData.setErrorLog(stackTrace);
 * increLoadErrorData.setModifiedBy(modifiedBy);
 * increLoadErrorData.setErrorCode(errorLog);
 * increLoadErrorData.setCreatedOn(new Date());
 * increLoadErrorData.setErrorCreatedDatetime(new Date());
 * 
 * // When deleteReconciliationDaoImpl.insertRecordIncrementalloadError(
 * fetchIncrementalDataLoadAuditId, dataPayload, currentStatusIdFailed,
 * errorLog, stackTrace, createdBy, modifiedBy);
 * 
 * // Then verify(incrementalLoadErrorRepository,
 * times(1)).save(any(IncreLoadErrorData.class)); }
 * 
 * @Test
 * 
 * @DisplayName("Test getCurrentStatusCId") void testGetCurrentStatusCId() { //
 * // Given String entity = "TestEntity"; String status = "TestStatus"; Integer
 * expectedStatusId = 1;
 * 
 * // Mock the repository method
 * when(keyPairMasterRepository.getCurrentStatusCId(entity,
 * status)).thenReturn(expectedStatusId);
 * 
 * // When Integer actualStatusId =
 * deleteReconciliationDaoImpl.getCurrentStatusCId(entity, status);
 * 
 * // Then assertEquals(expectedStatusId, actualStatusId);
 * verify(keyPairMasterRepository, times(1)).getCurrentStatusCId(entity,
 * status);
 * 
 * }
 * 
 * @Test
 * 
 * @DisplayName("Test insertRecordLetter") void testInsertRecordLetter() { //
 * Given List<LetterData> arrayListLetterData = new ArrayList<>(); LetterData
 * data1 = new LetterData(); data1.setActivityid(UUID.randomUUID());
 * data1.setDeleteDatetime(Instant.now().toString());
 * arrayListLetterData.add(data1);
 * 
 * UUID fetchIncrementalDataLoadAuditId = UUID.randomUUID();
 * 
 * // When deleteReconciliationDaoImpl.insertRecordLetter(arrayListLetterData,
 * fetchIncrementalDataLoadAuditId);
 * 
 * // Then verify(letterRepository, times(1)).saveAll(anyList());
 * 
 * }
 * 
 * @Test
 * 
 * @DisplayName("Test insertRecordEmail") void testInsertRecordEmail() { //
 * Given List<EmailData> arrayListEmailData = new ArrayList<>(); EmailData data1
 * = new EmailData(); data1.setActivityid(UUID.randomUUID());
 * data1.setDeleteDatetime(Instant.now().toString());
 * arrayListEmailData.add(data1);
 * 
 * UUID fetchIncrementalDataLoadAuditId = UUID.randomUUID();
 * 
 * // When deleteReconciliationDaoImpl.insertRecordEmail(arrayListEmailData,
 * fetchIncrementalDataLoadAuditId);
 * 
 * // Then verify(emailRepository, times(1)).saveAll(anyList()); }
 * 
 * @Test
 * 
 * @DisplayName("Test insertRecordTask") void testInsertRecordTask() { // Given
 * 
 * List<TaskData> arrayListTaskData = new ArrayList<>(); TaskData data1 = new
 * TaskData(); data1.setActivityid(UUID.randomUUID());
 * data1.setDeleteDatetime(Instant.now().toString());
 * arrayListTaskData.add(data1);
 * 
 * UUID fetchIncrementalDataLoadAuditId = UUID.randomUUID();
 * 
 * // When deleteReconciliationDaoImpl.insertRecordTask(arrayListTaskData,
 * fetchIncrementalDataLoadAuditId);
 * 
 * // Then verify(taskRepository, times(1)).saveAll(anyList()); }
 * 
 * @Test
 * 
 * @DisplayName("Test insertRecordPortal") void testInsertRecordPortal() { //
 * Given List<PortalData> arrayListPortalData = new ArrayList<>(); PortalData
 * data1 = new PortalData(); data1.setActivityid(UUID.randomUUID());
 * data1.setDeleteDatetime(Instant.now().toString());
 * arrayListPortalData.add(data1);
 * 
 * UUID fetchIncrementalDataLoadAuditId = UUID.randomUUID();
 * 
 * // When deleteReconciliationDaoImpl.insertRecordPortal(arrayListPortalData,
 * fetchIncrementalDataLoadAuditId);
 * 
 * // Then verify(portalRepository, times(1)).saveAll(anyList()); } }
 */