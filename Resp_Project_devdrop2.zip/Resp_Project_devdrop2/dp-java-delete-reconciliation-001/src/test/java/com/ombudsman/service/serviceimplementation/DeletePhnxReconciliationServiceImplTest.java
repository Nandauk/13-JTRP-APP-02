package com.ombudsman.service.serviceimplementation;

import static com.ombudsman.service.delete.reconciliation.common.Constants.DATASOURCE_NAME;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.text.ParseException;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.springframework.test.util.ReflectionTestUtils;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ombudsman.service.delete.reconciliation.common.Constants;
import com.ombudsman.service.delete.reconciliation.common.PhoenixHelper;
import com.ombudsman.service.delete.reconciliation.common.SendMailNotification;
import com.ombudsman.service.delete.reconciliation.dao.IDeleteReconciliationDao;
import com.ombudsman.service.delete.reconciliation.exception.JobFailedException;
import com.ombudsman.service.delete.reconciliation.helper.DataResponse;
import com.ombudsman.service.delete.reconciliation.model.AccountData;
import com.ombudsman.service.delete.reconciliation.model.CaseconsiderationData;
import com.ombudsman.service.delete.reconciliation.model.CaselinkData;
import com.ombudsman.service.delete.reconciliation.model.ContactData;
import com.ombudsman.service.delete.reconciliation.model.CorrespondenceData;
import com.ombudsman.service.delete.reconciliation.model.CorrespondenceSourceData;
import com.ombudsman.service.delete.reconciliation.model.CustomeraddressData;
import com.ombudsman.service.delete.reconciliation.model.DigitalMessageData;
import com.ombudsman.service.delete.reconciliation.model.EmailData;
import com.ombudsman.service.delete.reconciliation.model.ErrorMessageTemplate;
import com.ombudsman.service.delete.reconciliation.model.IncidentData;
import com.ombudsman.service.delete.reconciliation.model.LetterData;
import com.ombudsman.service.delete.reconciliation.model.OfferoutcomeData;
import com.ombudsman.service.delete.reconciliation.model.PhoneData;
import com.ombudsman.service.delete.reconciliation.model.PortalData;
import com.ombudsman.service.delete.reconciliation.model.TaskData;
import com.ombudsman.service.delete.reconciliation.model.UserData;
import com.ombudsman.service.delete.reconciliation.repository.CaseLinkRepository;
import com.ombudsman.service.delete.reconciliation.repository.JobMasterRepository;
import com.ombudsman.service.delete.reconciliation.repository.KeyPairMasterRepository;
import com.ombudsman.service.delete.reconciliation.serviceimplementation.DeletePhnxReconciliationServiceImpl;

import okhttp3.Call;
import okhttp3.HttpUrl;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.mockwebserver.MockResponse;
import okhttp3.mockwebserver.MockWebServer;

class DeletePhnxReconciliationServiceImplTest {

	@Mock
	private IDeleteReconciliationDao iDeleteReconciliationDao;

	@InjectMocks
	@Spy
	private DeletePhnxReconciliationServiceImpl deletePhnxReconciliationServiceImpl;

	@Mock
	private PhoenixHelper phoenixHelper;

	@Mock
	private OkHttpClient mockClient;

	@Mock
	HttpUrl.Builder mockHttpUrlBuilder;

	@Mock
	HttpUrl httpUrl;

	@Mock
	private Call mockCall;

	@Mock
	JobMasterRepository jobMasterRepository;

	@Mock
	CaseLinkRepository caseLinkRepository;

	@Mock
	private Response mockResponse;
	@Mock
	private DataResponse dataResponse;

	@Mock
	private KeyPairMasterRepository keyPairMasterRepository;

	@Mock
	private Request mockRequest;
	private MockWebServer mockWebServer;

	@Mock
	SendMailNotification sendMailNotification;

	private ObjectMapper mapper;

	Long total;
	String jobEndTime;
	String lastupdatedDate;
	String lastSevenDayDate;
	UUID fetchIncrementalDataLoadAuditId = null;
	int batch = 0;
    
	String pagingCookie = null;
	int page = 1;
	boolean moreRecords = false;

	@BeforeEach
	void setUp() throws IOException {
		MockitoAnnotations.openMocks(this);
		mockWebServer = new MockWebServer();
		mockWebServer.start();
		ReflectionTestUtils.setField(phoenixHelper, "pheonixHost", mockWebServer.url("/").host());
		mapper = new ObjectMapper();
		total = 0L;
		fetchIncrementalDataLoadAuditId = UUID.randomUUID();
		batch = 100;
		jobEndTime = "2025-06-05T21:00:00.0000000";
		lastupdatedDate = "2025-06-02T21:00:00.0000000";
		lastSevenDayDate = "2025-06-05T21:00:00.0000000";
	    
    	
	}

	@AfterEach
	void tearDown() throws IOException {
		mockWebServer.shutdown();
	}

	@Test
	@DisplayName("Test processAllJob for InsertToAccount with no data")
	void insertToAccount_noData() throws InterruptedException, ParseException, JobFailedException, IOException {
		List<AccountData> accountDataList = new ArrayList<>();

		int currentStatusIdFailed = 2;
		
		
		when(phoenixHelper.getEndTime()).thenReturn("NA");
		when(phoenixHelper.getStartTime()).thenReturn("NA");
		String mockFetchXml = "<fetch  version='1.0' mapping='logical' count='100' page='3'><entity name='audit'><attribute name='objecttypecode'/><attribute name='action'/><attribute name='createdon'/><attribute name='objectid'/><filter><condition attribute='objecttypecode' operator='eq' value='10383'/><condition attribute='action' operator='eq' value='3'/><condition attribute='createdon' operator='gt' value='2024-11-09T11:56:05.360143600Z'/></filter></entity></fetch>";

		String mockJsonResponse = "{\"value\": []}";
		when(phoenixHelper.getFetchRecord()).thenReturn(batch);
		when(phoenixHelper.getFetchXML(Constants.ACCOUNT_ENTITY, jobEndTime, lastupdatedDate,batch,pagingCookie,page)).thenReturn(mockFetchXml);
		HttpUrl mockHttpUrl = mockWebServer.url("/phoniex/account?fetchXml=test");
		mockRequest = new Request.Builder().url(mockHttpUrl).build();
		when(phoenixHelper.getPhoenixRequestBuild(anyString())).thenReturn(mockRequest);
		when(iDeleteReconciliationDao.getCurrentStatusIPId()).thenReturn(2);
		when(iDeleteReconciliationDao.getJobID(Constants.DATASOURCE_NAME)).thenReturn(4);
		when(iDeleteReconciliationDao.getIncrementalDataLoadAuditId(anyInt(), anyString(), anyString(),
				eq(Constants.DATASOURCE_NAME))).thenReturn(UUID.randomUUID());
		when(iDeleteReconciliationDao.getCurrentStatusCId(Constants.DATASOURCE_NAME, Constants.STATUS_READY_TO_PROCESS))
				.thenReturn(15);
		when(iDeleteReconciliationDao.getCountFailedJobsInLast7Days(DATASOURCE_NAME, lastSevenDayDate,
				currentStatusIdFailed)).thenReturn(total);
		when(dataResponse.getAccountData()).thenReturn(accountDataList);
		MockResponse mockRes = new MockResponse().setBody(mockJsonResponse).addHeader("Content-Type",
				"application/json");
		mockWebServer.enqueue(mockRes);

		doNothing().when(deletePhnxReconciliationServiceImpl).insertToContact();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToCaseLink();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToCaseconsideration();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToCorrepondenceSource();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToEmail();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToIncident();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToLetter();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToOfferoutcome();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToPhone();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToPortal();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToTask();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToUser();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToCorrespondence();

		/*
		 * deletePhnxReconciliationServiceImpl.processAllJob();
		 * 
		 * verify(iDeleteReconciliationDao, times(3)).getCurrentStatusIPId();
		 * verify(iDeleteReconciliationDao, times(1)).insertToIncrementalAudit(anyInt(),
		 * anyInt(), eq(Constants.DATASOURCE_NAME), anyString());
		 * verify(iDeleteReconciliationDao,
		 * times(1)).updateIncrementAuditJobQuery(anyLong(), anyInt(), anyInt(),
		 * anyString(), any(UUID.class), anyString());
		 */

	}

	@Test
	@DisplayName("Test processAllJob for insertToCaseconsideration( with valid data")
	void insertToCaseconsideration_Success()
			throws InterruptedException, IOException, JobFailedException, ParseException {
		List<CaseconsiderationData> caseconsiderationDataList = new ArrayList<>();
		UUID randomUuuid = UUID.randomUUID();
		int currentStatusIdFailed = 2;
		when(phoenixHelper.getEndTime()).thenReturn("NA");
		when(phoenixHelper.getStartTime()).thenReturn("NA");
		String mockFetchXml = "<fetch  version='1.0' mapping='logical' count='100' page='3'><entity name='audit'><attribute name='objecttypecode'/><attribute name='action'/><attribute name='createdon'/><attribute name='objectid'/><filter><condition attribute='objecttypecode' operator='eq' value='10383'/><condition attribute='action' operator='eq' value='3'/><condition attribute='createdon' operator='gt' value='2024-11-09T11:56:05.360143600Z'/></filter></entity></fetch>";
		String mockJsonResponse = "{\"value\": [{\"_objectid_value\": \"" + randomUuuid
				+ "\", \"createdon\": \"2025-01-02\"}]}";
		when(phoenixHelper.getFetchRecord()).thenReturn(batch);
		when(phoenixHelper.getFetchXML(Constants.CASECONSIDERATION_ENTITY,  jobEndTime, lastupdatedDate,batch,pagingCookie,page)).thenReturn(mockFetchXml);
		HttpUrl mockHttpUrl = mockWebServer.url("/phoniex/caseconsideration?fetchXml=test");
		mockRequest = new Request.Builder().url(mockHttpUrl).build();
		when(phoenixHelper.getPhoenixRequestBuild(anyString())).thenReturn(mockRequest);
		when(iDeleteReconciliationDao.getCurrentStatusIPId()).thenReturn(2);
		when(iDeleteReconciliationDao.getJobID(Constants.DATASOURCE_NAME)).thenReturn(4);
		when(iDeleteReconciliationDao.getIncrementalDataLoadAuditId(anyInt(), anyString(), anyString(),
				eq(Constants.DATASOURCE_NAME))).thenReturn(UUID.randomUUID());
		when(iDeleteReconciliationDao.getCurrentStatusCId(Constants.DATASOURCE_NAME, Constants.STATUS_READY_TO_PROCESS))
				.thenReturn(15);
		when(iDeleteReconciliationDao.getCountFailedJobsInLast7Days(DATASOURCE_NAME, lastSevenDayDate,
				currentStatusIdFailed)).thenReturn(total);
		when(dataResponse.getCaseconsiderationData()).thenReturn(caseconsiderationDataList);
		MockResponse mockRes = new MockResponse().setBody(mockJsonResponse).addHeader("Content-Type",
				"application/json");
		mockWebServer.enqueue(mockRes);

		doNothing().when(deletePhnxReconciliationServiceImpl).insertToContact();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToAccount();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToCaseLink();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToCorrepondenceSource();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToEmail();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToIncident();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToLetter();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToOfferoutcome();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToPhone();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToPortal();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToTask();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToUser();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToCorrespondence();

		/*
		 * deletePhnxReconciliationServiceImpl.processAllJob();
		 * 
		 * verify(iDeleteReconciliationDao, times(1)).getCurrentStatusIPId();
		 * verify(iDeleteReconciliationDao, times(1)).insertToIncrementalAudit(anyInt(),
		 * anyInt(), eq(Constants.DATASOURCE_NAME), anyString());
		 * verify(iDeleteReconciliationDao,
		 * times(1)).updateIncrementAuditJobQuery(anyLong(), anyInt(), anyInt(),
		 * anyString(), any(UUID.class), anyString());
		 */

	}

	@Test
	@DisplayName("Test processAllJob for insertToCaseconsideration with no data")
	void insertToCaseconsideration_noData()
			throws InterruptedException, ParseException, JobFailedException, IOException {
		List<CaseconsiderationData> caseconsiderationDataList = new ArrayList<>();

		int currentStatusIdFailed = 2;
		when(phoenixHelper.getEndTime()).thenReturn("NA");
		when(phoenixHelper.getStartTime()).thenReturn("NA");
		String mockFetchXml = "<fetch  version='1.0' mapping='logical' count='100' page='3'><entity name='audit'><attribute name='objecttypecode'/><attribute name='action'/><attribute name='createdon'/><attribute name='objectid'/><filter><condition attribute='objecttypecode' operator='eq' value='10383'/><condition attribute='action' operator='eq' value='3'/><condition attribute='createdon' operator='gt' value='2024-11-09T11:56:05.360143600Z'/></filter></entity></fetch>";
		String mockJsonResponse = "{\"value\": []}";
		when(phoenixHelper.getFetchRecord()).thenReturn(batch);
		when(phoenixHelper.getFetchXML(Constants.CASECONSIDERATION_ENTITY,  jobEndTime, lastupdatedDate,batch,pagingCookie,page)).thenReturn(mockFetchXml);
		HttpUrl mockHttpUrl = mockWebServer.url("/phoniex/caseconsideration?fetchXml=test");
		mockRequest = new Request.Builder().url(mockHttpUrl).build();
		when(phoenixHelper.getPhoenixRequestBuild(anyString())).thenReturn(mockRequest);
		when(iDeleteReconciliationDao.getCurrentStatusIPId()).thenReturn(2);
		when(iDeleteReconciliationDao.getJobID(Constants.DATASOURCE_NAME)).thenReturn(4);
		when(iDeleteReconciliationDao.getIncrementalDataLoadAuditId(anyInt(), anyString(), anyString(),
				eq(Constants.DATASOURCE_NAME))).thenReturn(UUID.randomUUID());
		when(iDeleteReconciliationDao.getCurrentStatusCId(Constants.DATASOURCE_NAME, Constants.STATUS_READY_TO_PROCESS))
				.thenReturn(15);
		when(iDeleteReconciliationDao.getCountFailedJobsInLast7Days(DATASOURCE_NAME, lastSevenDayDate,
				currentStatusIdFailed)).thenReturn(total);
		when(dataResponse.getCaseconsiderationData()).thenReturn(caseconsiderationDataList);
		MockResponse mockRes = new MockResponse().setBody(mockJsonResponse).addHeader("Content-Type",
				"application/json");
		mockWebServer.enqueue(mockRes);

		doNothing().when(deletePhnxReconciliationServiceImpl).insertToContact();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToAccount();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToCaseLink();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToCorrepondenceSource();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToEmail();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToIncident();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToLetter();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToOfferoutcome();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToPhone();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToPortal();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToTask();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToUser();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToCorrespondence();

		/*
		 * deletePhnxReconciliationServiceImpl.processAllJob();
		 * 
		 * verify(iDeleteReconciliationDao, times(1)).getCurrentStatusIPId();
		 * verify(iDeleteReconciliationDao, times(1)).insertToIncrementalAudit(anyInt(),
		 * anyInt(), eq(Constants.DATASOURCE_NAME), anyString());
		 * verify(iDeleteReconciliationDao,
		 * times(1)).updateIncrementAuditJobQuery(anyLong(), anyInt(), anyInt(),
		 * anyString(), any(UUID.class), anyString());
		 */
	}

	@Test
	@DisplayName("Test processAllJob for insertToCorrepondenceSource with valid data")
	void insertToCorrepondenceSource_Success()
			throws InterruptedException, ParseException, JobFailedException, IOException {
		List<CorrespondenceSourceData> correspondenceSourceDataList = new ArrayList<>();
		UUID randomUuuid = UUID.randomUUID();
		int currentStatusIdFailed = 2;
		when(phoenixHelper.getEndTime()).thenReturn("NA");
		when(phoenixHelper.getStartTime()).thenReturn("NA");
		String mockFetchXml = "<fetch  version='1.0' mapping='logical' count='100' page='3'><entity name='audit'><attribute name='objecttypecode'/><attribute name='action'/><attribute name='createdon'/><attribute name='objectid'/><filter><condition attribute='objecttypecode' operator='eq' value='10383'/><condition attribute='action' operator='eq' value='3'/><condition attribute='createdon' operator='gt' value='2024-11-09T11:56:05.360143600Z'/></filter></entity></fetch>";
		String mockJsonResponse = "{\"value\": [{\"_objectid_value\": \"" + randomUuuid
				+ "\", \"createdon\": \"2025-01-02\"}]}";
		when(phoenixHelper.getFetchRecord()).thenReturn(batch);
		when(phoenixHelper.getFetchXML(Constants.CORRESPONDENCE_SOURCE_ENTITY,  jobEndTime, lastupdatedDate,batch,pagingCookie,page))
				.thenReturn(mockFetchXml);
		HttpUrl mockHttpUrl = mockWebServer.url("/phoniex/correspondenceSource?fetchXml=test");
		mockRequest = new Request.Builder().url(mockHttpUrl).build();
		when(phoenixHelper.getPhoenixRequestBuild(anyString())).thenReturn(mockRequest);
		when(iDeleteReconciliationDao.getCurrentStatusIPId()).thenReturn(2);
		when(iDeleteReconciliationDao.getJobID(Constants.DATASOURCE_NAME)).thenReturn(4);
		when(iDeleteReconciliationDao.getIncrementalDataLoadAuditId(anyInt(), anyString(), anyString(),
				eq(Constants.DATASOURCE_NAME))).thenReturn(UUID.randomUUID());
		when(iDeleteReconciliationDao.getCurrentStatusCId(Constants.DATASOURCE_NAME, Constants.STATUS_READY_TO_PROCESS))
				.thenReturn(15);
		when(iDeleteReconciliationDao.getCountFailedJobsInLast7Days(DATASOURCE_NAME, lastSevenDayDate,
				currentStatusIdFailed)).thenReturn(total);
		when(dataResponse.getCorrespondenceSourceData()).thenReturn(correspondenceSourceDataList);
		MockResponse mockRes = new MockResponse().setBody(mockJsonResponse).addHeader("Content-Type",
				"application/json");
		mockWebServer.enqueue(mockRes);

		doNothing().when(deletePhnxReconciliationServiceImpl).insertToCaseLink();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToAccount();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToCaseconsideration();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToContact();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToEmail();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToIncident();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToLetter();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToOfferoutcome();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToPhone();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToPortal();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToTask();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToUser();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToCorrespondence();

		/*
		 * deletePhnxReconciliationServiceImpl.processAllJob();
		 * 
		 * verify(iDeleteReconciliationDao, times(1)).getCurrentStatusIPId();
		 * verify(iDeleteReconciliationDao, times(1)).insertToIncrementalAudit(anyInt(),
		 * anyInt(), eq(Constants.DATASOURCE_NAME), anyString());
		 * verify(iDeleteReconciliationDao,
		 * times(1)).updateIncrementAuditJobQuery(anyLong(), anyInt(), anyInt(),
		 * anyString(), any(UUID.class), anyString());
		 */
	}

	@Test
	@DisplayName("Test processAllJob for insertToCorrepondenceSource with no data")
	void insertToCorrepondenceSource_noData()
			throws InterruptedException, ParseException, JobFailedException, IOException {
		List<CorrespondenceSourceData> correspondenceSourceDataList = new ArrayList<>();

		int currentStatusIdFailed = 2;
		when(phoenixHelper.getEndTime()).thenReturn("NA");
		when(phoenixHelper.getStartTime()).thenReturn("NA");
		String mockFetchXml = "<fetch  version='1.0' mapping='logical' count='100' page='3'><entity name='audit'><attribute name='objecttypecode'/><attribute name='action'/><attribute name='createdon'/><attribute name='objectid'/><filter><condition attribute='objecttypecode' operator='eq' value='10383'/><condition attribute='action' operator='eq' value='3'/><condition attribute='createdon' operator='gt' value='2024-11-09T11:56:05.360143600Z'/></filter></entity></fetch>";

		String mockJsonResponse = "{\"value\": []}";
		when(phoenixHelper.getFetchRecord()).thenReturn(batch);
		when(phoenixHelper.getFetchXML(Constants.CORRESPONDENCE_SOURCE_ENTITY, jobEndTime, lastupdatedDate,batch,pagingCookie,page))
				.thenReturn(mockFetchXml);
		HttpUrl mockHttpUrl = mockWebServer.url("/phoniex/correpondenceSource?fetchXml=test");
		mockRequest = new Request.Builder().url(mockHttpUrl).build();
		when(phoenixHelper.getPhoenixRequestBuild(anyString())).thenReturn(mockRequest);
		when(iDeleteReconciliationDao.getCurrentStatusIPId()).thenReturn(2);
		when(iDeleteReconciliationDao.getJobID(Constants.DATASOURCE_NAME)).thenReturn(4);
		when(iDeleteReconciliationDao.getIncrementalDataLoadAuditId(anyInt(), anyString(), anyString(),
				eq(Constants.DATASOURCE_NAME))).thenReturn(UUID.randomUUID());
		when(iDeleteReconciliationDao.getCurrentStatusCId(Constants.DATASOURCE_NAME, Constants.STATUS_READY_TO_PROCESS))
				.thenReturn(15);
		when(iDeleteReconciliationDao.getCountFailedJobsInLast7Days(DATASOURCE_NAME, lastSevenDayDate,
				currentStatusIdFailed)).thenReturn(total);
		when(dataResponse.getCorrespondenceSourceData()).thenReturn(correspondenceSourceDataList);
		MockResponse mockRes = new MockResponse().setBody(mockJsonResponse).addHeader("Content-Type",
				"application/json");
		mockWebServer.enqueue(mockRes);

		doNothing().when(deletePhnxReconciliationServiceImpl).insertToCaseLink();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToAccount();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToCaseconsideration();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToContact();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToEmail();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToIncident();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToLetter();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToOfferoutcome();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToPhone();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToPortal();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToTask();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToUser();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToCorrespondence();

		/*
		 * deletePhnxReconciliationServiceImpl.processAllJob();
		 * 
		 * verify(iDeleteReconciliationDao, times(1)).getCurrentStatusIPId();
		 * verify(iDeleteReconciliationDao, times(1)).insertToIncrementalAudit(anyInt(),
		 * anyInt(), eq(Constants.DATASOURCE_NAME), anyString());
		 * verify(iDeleteReconciliationDao,
		 * times(1)).updateIncrementAuditJobQuery(anyLong(), anyInt(), anyInt(),
		 * anyString(), any(UUID.class), anyString());
		 */

	}

	@Test
	@DisplayName("Test processAllJob for InsertToCaseLink with valid data")
	void insertToCaselink_Success() throws InterruptedException, ParseException, JobFailedException, IOException {
		List<ContactData> contactDataList = new ArrayList<>();
		UUID randomUuuid = UUID.randomUUID();
		int currentStatusIdFailed = 2;
		when(phoenixHelper.getEndTime()).thenReturn("NA");
		when(phoenixHelper.getStartTime()).thenReturn("NA");
		String mockFetchXml = "<fetch  version='1.0' mapping='logical' count='100' page='3'><entity name='audit'><attribute name='objecttypecode'/><attribute name='action'/><attribute name='createdon'/><attribute name='objectid'/><filter><condition attribute='objecttypecode' operator='eq' value='10383'/><condition attribute='action' operator='eq' value='3'/><condition attribute='createdon' operator='gt' value='2024-11-09T11:56:05.360143600Z'/></filter></entity></fetch>";
		String mockJsonResponse = "{\"value\": [{\"_objectid_value\": \"" + randomUuuid
				+ "\", \"createdon\": \"2025-01-02\"}]}";
		when(phoenixHelper.getFetchRecord()).thenReturn(batch);
		when(phoenixHelper.getFetchXML(Constants.CASELINK_ENTITY,  jobEndTime, lastupdatedDate,batch,pagingCookie,page)).thenReturn(mockFetchXml);
		HttpUrl mockHttpUrl = mockWebServer.url("/phoniex/caselink?fetchXml=test");
		mockRequest = new Request.Builder().url(mockHttpUrl).build();
		when(phoenixHelper.getPhoenixRequestBuild(anyString())).thenReturn(mockRequest);
		when(iDeleteReconciliationDao.getCurrentStatusIPId()).thenReturn(2);
		when(iDeleteReconciliationDao.getJobID(Constants.DATASOURCE_NAME)).thenReturn(4);
		when(iDeleteReconciliationDao.getIncrementalDataLoadAuditId(anyInt(), anyString(), anyString(),
				eq(Constants.DATASOURCE_NAME))).thenReturn(UUID.randomUUID());
		when(iDeleteReconciliationDao.getCurrentStatusCId(Constants.DATASOURCE_NAME, Constants.STATUS_READY_TO_PROCESS))
				.thenReturn(15);
		when(iDeleteReconciliationDao.getCountFailedJobsInLast7Days(DATASOURCE_NAME, lastSevenDayDate,
				currentStatusIdFailed)).thenReturn(total);
		when(dataResponse.getContactData()).thenReturn(contactDataList);
		MockResponse mockRes = new MockResponse().setBody(mockJsonResponse).addHeader("Content-Type",
				"application/json");
		mockWebServer.enqueue(mockRes);

		doNothing().when(deletePhnxReconciliationServiceImpl).insertToContact();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToAccount();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToCaseconsideration();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToCorrepondenceSource();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToEmail();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToIncident();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToLetter();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToOfferoutcome();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToPhone();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToPortal();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToTask();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToUser();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToCorrespondence();

		/*
		 * deletePhnxReconciliationServiceImpl.processAllJob();
		 * 
		 * verify(iDeleteReconciliationDao, times(1)).getCurrentStatusIPId();
		 * verify(iDeleteReconciliationDao, times(1)).insertToIncrementalAudit(anyInt(),
		 * anyInt(), eq(Constants.DATASOURCE_NAME), anyString());
		 * verify(iDeleteReconciliationDao,
		 * times(1)).updateIncrementAuditJobQuery(anyLong(), anyInt(), anyInt(),
		 * anyString(), any(UUID.class), anyString());
		 */

	}

	@Test
	@DisplayName("Test processAllJob for InsertToCaselink with no data")
	void insertToCaselink_noData() throws InterruptedException, ParseException, JobFailedException, IOException {
		List<CaselinkData> caselinkDataList = new ArrayList<>();

		int currentStatusIdFailed = 2;
		when(phoenixHelper.getEndTime()).thenReturn("NA");
		when(phoenixHelper.getStartTime()).thenReturn("NA");
		String mockFetchXml = "<fetch  version='1.0' mapping='logical' count='100' page='3'><entity name='audit'><attribute name='objecttypecode'/><attribute name='action'/><attribute name='createdon'/><attribute name='objectid'/><filter><condition attribute='objecttypecode' operator='eq' value='10383'/><condition attribute='action' operator='eq' value='3'/><condition attribute='createdon' operator='gt' value='2024-11-09T11:56:05.360143600Z'/></filter></entity></fetch>";

		String mockJsonResponse = "{\"value\": []}";
		when(phoenixHelper.getFetchRecord()).thenReturn(batch);
		when(phoenixHelper.getFetchXML(Constants.CASELINK_ENTITY,  jobEndTime, lastupdatedDate,batch,pagingCookie,page)).thenReturn(mockFetchXml);
		HttpUrl mockHttpUrl = mockWebServer.url("/phoniex/caselink?fetchXml=test");
		mockRequest = new Request.Builder().url(mockHttpUrl).build();
		when(phoenixHelper.getPhoenixRequestBuild(anyString())).thenReturn(mockRequest);
		when(iDeleteReconciliationDao.getCurrentStatusIPId()).thenReturn(2);
		when(iDeleteReconciliationDao.getJobID(Constants.DATASOURCE_NAME)).thenReturn(4);
		when(iDeleteReconciliationDao.getIncrementalDataLoadAuditId(anyInt(), anyString(), anyString(),
				eq(Constants.DATASOURCE_NAME))).thenReturn(UUID.randomUUID());
		when(iDeleteReconciliationDao.getCurrentStatusCId(Constants.DATASOURCE_NAME, Constants.STATUS_READY_TO_PROCESS))
				.thenReturn(15);
		when(iDeleteReconciliationDao.getCountFailedJobsInLast7Days(DATASOURCE_NAME, lastSevenDayDate,
				currentStatusIdFailed)).thenReturn(total);
		when(dataResponse.getCaselinkData()).thenReturn(caselinkDataList);
		MockResponse mockRes = new MockResponse().setBody(mockJsonResponse).addHeader("Content-Type",
				"application/json");
		mockWebServer.enqueue(mockRes);

		doNothing().when(deletePhnxReconciliationServiceImpl).insertToContact();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToAccount();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToCaseconsideration();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToCorrepondenceSource();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToEmail();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToIncident();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToLetter();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToOfferoutcome();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToPhone();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToPortal();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToTask();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToUser();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToCorrespondence();

		/*
		 * deletePhnxReconciliationServiceImpl.processAllJob();
		 * 
		 * verify(iDeleteReconciliationDao, times(1)).getCurrentStatusIPId();
		 * verify(iDeleteReconciliationDao, times(1)).insertToIncrementalAudit(anyInt(),
		 * anyInt(), eq(Constants.DATASOURCE_NAME), anyString());
		 * verify(iDeleteReconciliationDao,
		 * times(1)).updateIncrementAuditJobQuery(anyLong(), anyInt(), anyInt(),
		 * anyString(), any(UUID.class), anyString());
		 */
	}

	@Test
	@DisplayName("Test processAllJob for InsertToContact with valid data")
	void insertToContact_Success() throws InterruptedException, ParseException, JobFailedException, IOException {
		List<CaselinkData> caselinkDataList = new ArrayList<>();
		UUID randomUuuid = UUID.randomUUID();
		int currentStatusIdFailed = 2;
		int batchsize = 150;
		when(phoenixHelper.getEndTime()).thenReturn("NA");
		when(phoenixHelper.getStartTime()).thenReturn("NA");
		String mockFetchXml = "<fetch version='1.0' mapping='logical' count='100' page='3' ><entity name='audit'><attribute name='objecttypecode'/><attribute name='action'/><attribute name='createdon'/><attribute name='objectid'/><filter><condition attribute='objecttypecode' operator='eq' value='10383'/><condition attribute='action' operator='eq' value='3'/><condition attribute='createdon' operator='gt' value='2024-11-09T11:56:05.360143600Z'/></filter></entity></fetch>";
		String mockJsonResponse = "{\"value\": [{\"_objectid_value\": \"" + randomUuuid
				+ "\", \"createdon\": \"2025-01-02\"}]}";
		when(phoenixHelper.getFetchRecord()).thenReturn(batch);
		when(phoenixHelper.getFetchXML(Constants.CONTACT_ENTITY,  jobEndTime, lastupdatedDate,batch,pagingCookie,page)).thenReturn(mockFetchXml);
		HttpUrl mockHttpUrl = mockWebServer.url("/phoniex/contact?fetchXml=test");
		mockRequest = new Request.Builder().url(mockHttpUrl).build();
		when(phoenixHelper.getPhoenixRequestBuild(anyString())).thenReturn(mockRequest);
		when(iDeleteReconciliationDao.getCurrentStatusIPId()).thenReturn(2);
		when(iDeleteReconciliationDao.getJobID(Constants.DATASOURCE_NAME)).thenReturn(4);
		when(iDeleteReconciliationDao.getIncrementalDataLoadAuditId(anyInt(), anyString(), anyString(),
				eq(Constants.DATASOURCE_NAME))).thenReturn(UUID.randomUUID());
		when(iDeleteReconciliationDao.getCurrentStatusCId(Constants.DATASOURCE_NAME, Constants.STATUS_READY_TO_PROCESS))
				.thenReturn(15);
		when(iDeleteReconciliationDao.getCountFailedJobsInLast7Days(DATASOURCE_NAME, lastSevenDayDate,
				currentStatusIdFailed)).thenReturn(total);
		when(dataResponse.getCaselinkData()).thenReturn(caselinkDataList);
		MockResponse mockRes = new MockResponse().setBody(mockJsonResponse).addHeader("Content-Type",
				"application/json");
		mockWebServer.enqueue(mockRes);

		doNothing().when(deletePhnxReconciliationServiceImpl).insertToCaseLink();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToAccount();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToCaseconsideration();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToCorrepondenceSource();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToEmail();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToIncident();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToLetter();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToOfferoutcome();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToPhone();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToPortal();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToTask();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToUser();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToCorrespondence();

		/*
		 * deletePhnxReconciliationServiceImpl.processAllJob();
		 * 
		 * verify(iDeleteReconciliationDao, times(1)).getCurrentStatusIPId();
		 * verify(iDeleteReconciliationDao, times(1)).insertToIncrementalAudit(anyInt(),
		 * anyInt(), eq(Constants.DATASOURCE_NAME), anyString());
		 * verify(iDeleteReconciliationDao,
		 * times(1)).updateIncrementAuditJobQuery(anyLong(), anyInt(), anyInt(),
		 * anyString(), any(UUID.class), anyString());
		 */

	}

	@Test
	@DisplayName("Test processAllJob for InsertToContact with no data")
	void insertToContact_noData() throws InterruptedException, ParseException, JobFailedException, IOException {
		List<ContactData> contactDataList = new ArrayList<>();

		int currentStatusIdFailed = 2;
		when(phoenixHelper.getEndTime()).thenReturn("NA");
		when(phoenixHelper.getStartTime()).thenReturn("NA");
		String mockFetchXml = "<fetch version='1.0' mapping='logical' count='100' page='3' > <entity name='audit'><attribute name='objecttypecode'/><attribute name='action'/><attribute name='createdon'/><attribute name='objectid'/><filter><condition attribute='objecttypecode' operator='eq' value='10383'/><condition attribute='action' operator='eq' value='3'/><condition attribute='createdon' operator='gt' value='2024-11-09T11:56:05.360143600Z'/></filter></entity></fetch>";

		String mockJsonResponse = "{\"value\": []}";
		when(phoenixHelper.getFetchRecord()).thenReturn(batch);
		when(phoenixHelper.getFetchXML(Constants.CONTACT_ENTITY,  jobEndTime, lastupdatedDate,batch,pagingCookie,page)).thenReturn(mockFetchXml);
		HttpUrl mockHttpUrl = mockWebServer.url("/phoniex/contact?fetchXml=test");
		mockRequest = new Request.Builder().url(mockHttpUrl).build();
		when(phoenixHelper.getPhoenixRequestBuild(anyString())).thenReturn(mockRequest);
		when(iDeleteReconciliationDao.getCurrentStatusIPId()).thenReturn(2);
		when(iDeleteReconciliationDao.getJobID(Constants.DATASOURCE_NAME)).thenReturn(4);
		when(iDeleteReconciliationDao.getIncrementalDataLoadAuditId(anyInt(), anyString(), anyString(),
				eq(Constants.DATASOURCE_NAME))).thenReturn(UUID.randomUUID());
		when(iDeleteReconciliationDao.getCurrentStatusCId(Constants.DATASOURCE_NAME, Constants.STATUS_READY_TO_PROCESS))
				.thenReturn(15);
		when(iDeleteReconciliationDao.getCountFailedJobsInLast7Days(DATASOURCE_NAME, lastSevenDayDate,
				currentStatusIdFailed)).thenReturn(total);
		when(dataResponse.getContactData()).thenReturn(contactDataList);
		MockResponse mockRes = new MockResponse().setBody(mockJsonResponse).addHeader("Content-Type",
				"application/json");
		mockWebServer.enqueue(mockRes);

		doNothing().when(deletePhnxReconciliationServiceImpl).insertToCaseLink();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToAccount();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToCaseconsideration();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToCorrepondenceSource();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToEmail();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToIncident();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToLetter();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToOfferoutcome();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToPhone();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToPortal();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToTask();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToUser();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToCorrespondence();

		/*
		 * deletePhnxReconciliationServiceImpl.processAllJob();
		 * 
		 * verify(iDeleteReconciliationDao, times(1)).getCurrentStatusIPId();
		 * verify(iDeleteReconciliationDao, times(1)).insertToIncrementalAudit(anyInt(),
		 * anyInt(), eq(Constants.DATASOURCE_NAME), anyString());
		 * verify(iDeleteReconciliationDao,
		 * times(1)).updateIncrementAuditJobQuery(anyLong(), anyInt(), anyInt(),
		 * anyString(), any(UUID.class), anyString());
		 */

	}

	@Test
	@DisplayName("Test processAllJob for InsertToEmail with valid data")
	void insertToEmail_Success() throws InterruptedException, ParseException, JobFailedException, IOException {
		List<EmailData> emailDataList = new ArrayList<>();
		UUID randomUuuid = UUID.randomUUID();
		int currentStatusIdFailed = 2;
		when(phoenixHelper.getEndTime()).thenReturn("NA");
		when(phoenixHelper.getStartTime()).thenReturn("NA");
		String mockFetchXml = "<fetch version='1.0' mapping='logical' count='100' page='3' ><entity name='audit'><attribute name='objecttypecode'/><attribute name='action'/><attribute name='createdon'/><attribute name='objectid'/><filter><condition attribute='objecttypecode' operator='eq' value='10383'/><condition attribute='action' operator='eq' value='3'/><condition attribute='createdon' operator='gt' value='2024-11-09T11:56:05.360143600Z'/></filter></entity></fetch>";
		String mockJsonResponse = "{\"value\": [{\"_objectid_value\": \"" + randomUuuid
				+ "\", \"createdon\": \"2025-01-02\"}]}";
		when(phoenixHelper.getFetchRecord()).thenReturn(batch);
		when(phoenixHelper.getFetchXML(Constants.EMAIL_ENTITY,  jobEndTime, lastupdatedDate,batch,pagingCookie,page)).thenReturn(mockFetchXml);
		HttpUrl mockHttpUrl = mockWebServer.url("/phoniex/email?fetchXml=test");
		mockRequest = new Request.Builder().url(mockHttpUrl).build();
		when(phoenixHelper.getPhoenixRequestBuild(anyString())).thenReturn(mockRequest);
		when(iDeleteReconciliationDao.getCurrentStatusIPId()).thenReturn(2);
		when(iDeleteReconciliationDao.getJobID(Constants.DATASOURCE_NAME)).thenReturn(4);
		when(iDeleteReconciliationDao.getIncrementalDataLoadAuditId(anyInt(), anyString(), anyString(),
				eq(Constants.DATASOURCE_NAME))).thenReturn(UUID.randomUUID());
		when(iDeleteReconciliationDao.getCurrentStatusCId(Constants.DATASOURCE_NAME, Constants.STATUS_READY_TO_PROCESS))
				.thenReturn(15);
		when(iDeleteReconciliationDao.getCountFailedJobsInLast7Days(DATASOURCE_NAME, lastSevenDayDate,
				currentStatusIdFailed)).thenReturn(total);
		when(dataResponse.getEmailData()).thenReturn(emailDataList);
		MockResponse mockRes = new MockResponse().setBody(mockJsonResponse).addHeader("Content-Type",
				"application/json");
		mockWebServer.enqueue(mockRes);

		doNothing().when(deletePhnxReconciliationServiceImpl).insertToCaseLink();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToAccount();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToCaseconsideration();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToCorrepondenceSource();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToContact();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToIncident();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToLetter();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToOfferoutcome();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToPhone();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToPortal();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToTask();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToUser();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToCorrespondence();

		/*
		 * deletePhnxReconciliationServiceImpl.processAllJob();
		 * 
		 * verify(iDeleteReconciliationDao, times(1)).getCurrentStatusIPId();
		 * verify(iDeleteReconciliationDao, times(1)).insertToIncrementalAudit(anyInt(),
		 * anyInt(), eq(Constants.DATASOURCE_NAME), anyString());
		 * verify(iDeleteReconciliationDao,
		 * times(1)).updateIncrementAuditJobQuery(anyLong(), anyInt(), anyInt(),
		 * anyString(), any(UUID.class), anyString());
		 */
	}

	@Test
	@DisplayName("Test processAllJob for InsertToEmail with no data")
	void insertToEmailt_noData() throws InterruptedException, ParseException, JobFailedException, IOException {
		List<EmailData> emailDataList = new ArrayList<>();

		int currentStatusIdFailed = 2;
		when(phoenixHelper.getEndTime()).thenReturn("NA");
		when(phoenixHelper.getStartTime()).thenReturn("NA");
		String mockFetchXml = "<fetch  version='1.0' mapping='logical'count='100' page='3'><entity name='audit'><attribute name='objecttypecode'/><attribute name='action'/><attribute name='createdon'/><attribute name='objectid'/><filter><condition attribute='objecttypecode' operator='eq' value='10383'/><condition attribute='action' operator='eq' value='3'/><condition attribute='createdon' operator='gt' value='2024-11-09T11:56:05.360143600Z'/></filter></entity></fetch>";

		String mockJsonResponse = "{\"value\": []}";
		when(phoenixHelper.getFetchRecord()).thenReturn(batch);
		when(phoenixHelper.getFetchXML(Constants.EMAIL_ENTITY,  jobEndTime, lastupdatedDate,batch,pagingCookie,page)).thenReturn(mockFetchXml);
		HttpUrl mockHttpUrl = mockWebServer.url("/phoniex/email?fetchXml=test");
		mockRequest = new Request.Builder().url(mockHttpUrl).build();
		when(phoenixHelper.getPhoenixRequestBuild(anyString())).thenReturn(mockRequest);
		when(iDeleteReconciliationDao.getCurrentStatusIPId()).thenReturn(2);
		when(iDeleteReconciliationDao.getJobID(Constants.DATASOURCE_NAME)).thenReturn(4);
		when(iDeleteReconciliationDao.getIncrementalDataLoadAuditId(anyInt(), anyString(), anyString(),
				eq(Constants.DATASOURCE_NAME))).thenReturn(UUID.randomUUID());
		when(iDeleteReconciliationDao.getCurrentStatusCId(Constants.DATASOURCE_NAME, Constants.STATUS_READY_TO_PROCESS))
				.thenReturn(15);
		when(iDeleteReconciliationDao.getCountFailedJobsInLast7Days(DATASOURCE_NAME, lastSevenDayDate,
				currentStatusIdFailed)).thenReturn(total);
		when(dataResponse.getEmailData()).thenReturn(emailDataList);
		MockResponse mockRes = new MockResponse().setBody(mockJsonResponse).addHeader("Content-Type",
				"application/json");
		mockWebServer.enqueue(mockRes);

		doNothing().when(deletePhnxReconciliationServiceImpl).insertToCaseLink();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToAccount();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToCaseconsideration();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToCorrepondenceSource();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToContact();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToIncident();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToLetter();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToOfferoutcome();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToPhone();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToPortal();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToTask();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToUser();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToCorrespondence();

		/*
		 * deletePhnxReconciliationServiceImpl.processAllJob();
		 * 
		 * verify(iDeleteReconciliationDao, times(1)).getCurrentStatusIPId();
		 * verify(iDeleteReconciliationDao, times(1)).insertToIncrementalAudit(anyInt(),
		 * anyInt(), eq(Constants.DATASOURCE_NAME), anyString());
		 * verify(iDeleteReconciliationDao,
		 * times(1)).updateIncrementAuditJobQuery(anyLong(), anyInt(), anyInt(),
		 * anyString(), any(UUID.class), anyString());
		 */

	}

	@Test
	@DisplayName("Test processAllJob for InsertToIncident with valid data")
	void insertToIncident_Success() throws InterruptedException, ParseException, JobFailedException, IOException {
		List<IncidentData> incidentDataList = new ArrayList<>();
		UUID randomUuuid = UUID.randomUUID();
		int currentStatusIdFailed = 2;
		when(phoenixHelper.getEndTime()).thenReturn("NA");
		when(phoenixHelper.getStartTime()).thenReturn("NA");
		String mockFetchXml = "<fetch  version='1.0' mapping='logical' count='100' page='3'><entity name='audit'><attribute name='objecttypecode'/><attribute name='action'/><attribute name='createdon'/><attribute name='objectid'/><filter><condition attribute='objecttypecode' operator='eq' value='10383'/><condition attribute='action' operator='eq' value='3'/><condition attribute='createdon' operator='gt' value='2024-11-09T11:56:05.360143600Z'/></filter></entity></fetch>";
		String mockJsonResponse = "{\"value\": [{\"_objectid_value\": \"" + randomUuuid
				+ "\", \"createdon\": \"2025-01-02\"}]}";
		when(phoenixHelper.getFetchRecord()).thenReturn(batch);
		when(phoenixHelper.getFetchXML(Constants.INCIDENT_ENTITY,  jobEndTime, lastupdatedDate,batch,pagingCookie,page)).thenReturn(mockFetchXml);
		HttpUrl mockHttpUrl = mockWebServer.url("/phoniex/contact?fetchXml=test");
		mockRequest = new Request.Builder().url(mockHttpUrl).build();
		when(phoenixHelper.getPhoenixRequestBuild(anyString())).thenReturn(mockRequest);
		when(iDeleteReconciliationDao.getCurrentStatusIPId()).thenReturn(2);
		when(iDeleteReconciliationDao.getJobID(Constants.DATASOURCE_NAME)).thenReturn(4);
		when(iDeleteReconciliationDao.getIncrementalDataLoadAuditId(anyInt(), anyString(), anyString(),
				eq(Constants.DATASOURCE_NAME))).thenReturn(UUID.randomUUID());
		when(iDeleteReconciliationDao.getCurrentStatusCId(Constants.DATASOURCE_NAME, Constants.STATUS_READY_TO_PROCESS))
				.thenReturn(15);
		when(iDeleteReconciliationDao.getCountFailedJobsInLast7Days(DATASOURCE_NAME, lastSevenDayDate,
				currentStatusIdFailed)).thenReturn(total);
		when(dataResponse.getIncidentData()).thenReturn(incidentDataList);
		MockResponse mockRes = new MockResponse().setBody(mockJsonResponse).addHeader("Content-Type",
				"application/json");
		mockWebServer.enqueue(mockRes);

		doNothing().when(deletePhnxReconciliationServiceImpl).insertToCaseLink();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToAccount();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToCaseconsideration();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToCorrepondenceSource();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToEmail();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToContact();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToLetter();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToOfferoutcome();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToPhone();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToPortal();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToTask();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToUser();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToCorrespondence();

		/*
		 * deletePhnxReconciliationServiceImpl.processAllJob();
		 * 
		 * verify(iDeleteReconciliationDao, times(1)).getCurrentStatusIPId();
		 * verify(iDeleteReconciliationDao, times(1)).insertToIncrementalAudit(anyInt(),
		 * anyInt(), eq(Constants.DATASOURCE_NAME), anyString());
		 * verify(iDeleteReconciliationDao,
		 * times(1)).updateIncrementAuditJobQuery(anyLong(), anyInt(), anyInt(),
		 * anyString(), any(UUID.class), anyString());
		 */

	}

	@Test
	@DisplayName("Test processAllJob for InsertToIncident with no data")
	void insertToIncident_noData() throws InterruptedException, ParseException, JobFailedException, IOException {
		List<IncidentData> incidentDataList = new ArrayList<>();

		int currentStatusIdFailed = 2;
		when(phoenixHelper.getEndTime()).thenReturn("NA");
		when(phoenixHelper.getStartTime()).thenReturn("NA");
		String mockFetchXml = "<fetch  version='1.0' mapping='logical'count='100' page='3'><entity name='audit'><attribute name='objecttypecode'/><attribute name='action'/><attribute name='createdon'/><attribute name='objectid'/><filter><condition attribute='objecttypecode' operator='eq' value='10383'/><condition attribute='action' operator='eq' value='3'/><condition attribute='createdon' operator='gt' value='2024-11-09T11:56:05.360143600Z'/></filter></entity></fetch>";

		String mockJsonResponse = "{\"value\": []}";
		when(phoenixHelper.getFetchRecord()).thenReturn(batch);
		when(phoenixHelper.getFetchXML(Constants.INCIDENT_ENTITY,  jobEndTime, lastupdatedDate,batch,pagingCookie,page)).thenReturn(mockFetchXml);
		HttpUrl mockHttpUrl = mockWebServer.url("/phoniex/incident?fetchXml=test");
		mockRequest = new Request.Builder().url(mockHttpUrl).build();
		when(phoenixHelper.getPhoenixRequestBuild(anyString())).thenReturn(mockRequest);
		when(iDeleteReconciliationDao.getCurrentStatusIPId()).thenReturn(2);
		when(iDeleteReconciliationDao.getJobID(Constants.DATASOURCE_NAME)).thenReturn(4);
		when(iDeleteReconciliationDao.getIncrementalDataLoadAuditId(anyInt(), anyString(), anyString(),
				eq(Constants.DATASOURCE_NAME))).thenReturn(UUID.randomUUID());
		when(iDeleteReconciliationDao.getCurrentStatusCId(Constants.DATASOURCE_NAME, Constants.STATUS_READY_TO_PROCESS))
				.thenReturn(15);
		when(iDeleteReconciliationDao.getCountFailedJobsInLast7Days(DATASOURCE_NAME, lastSevenDayDate,
				currentStatusIdFailed)).thenReturn(total);
		when(dataResponse.getIncidentData()).thenReturn(incidentDataList);
		MockResponse mockRes = new MockResponse().setBody(mockJsonResponse).addHeader("Content-Type",
				"application/json");
		mockWebServer.enqueue(mockRes);

		doNothing().when(deletePhnxReconciliationServiceImpl).insertToCaseLink();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToAccount();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToCaseconsideration();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToCorrepondenceSource();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToEmail();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToContact();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToLetter();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToOfferoutcome();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToPhone();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToPortal();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToTask();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToUser();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToCorrespondence();

		/*
		 * deletePhnxReconciliationServiceImpl.processAllJob();
		 * 
		 * verify(iDeleteReconciliationDao, times(1)).getCurrentStatusIPId();
		 * verify(iDeleteReconciliationDao, times(1)).insertToIncrementalAudit(anyInt(),
		 * anyInt(), eq(Constants.DATASOURCE_NAME), anyString());
		 * verify(iDeleteReconciliationDao,
		 * times(1)).updateIncrementAuditJobQuery(anyLong(), anyInt(), anyInt(),
		 * anyString(), any(UUID.class), anyString());
		 */

	}

	@Test
	@DisplayName("Test processAllJob for InsertToLetter with valid data")
	void insertToLetter_Success() throws InterruptedException, ParseException, JobFailedException, IOException {
		List<LetterData> letterDataList = new ArrayList<>();
		UUID randomUuuid = UUID.randomUUID();
		int currentStatusIdFailed = 2;
		when(phoenixHelper.getEndTime()).thenReturn("NA");
		when(phoenixHelper.getStartTime()).thenReturn("NA");
		String mockFetchXml = "<fetch  version='1.0' mapping='logical' count='100' page='3'><entity name='audit'><attribute name='objecttypecode'/><attribute name='action'/><attribute name='createdon'/><attribute name='objectid'/><filter><condition attribute='objecttypecode' operator='eq' value='10383'/><condition attribute='action' operator='eq' value='3'/><condition attribute='createdon' operator='gt' value='2024-11-09T11:56:05.360143600Z'/></filter></entity></fetch>";
		String mockJsonResponse = "{\"value\": [{\"_objectid_value\": \"" + randomUuuid
				+ "\", \"createdon\": \"2025-01-02\"}]}";
		when(phoenixHelper.getFetchRecord()).thenReturn(batch);
		when(phoenixHelper.getFetchXML(Constants.LETTER_ENTITY,  jobEndTime, lastupdatedDate,batch,pagingCookie,page)).thenReturn(mockFetchXml);
		HttpUrl mockHttpUrl = mockWebServer.url("/phoniex/letter?fetchXml=test");
		mockRequest = new Request.Builder().url(mockHttpUrl).build();
		when(phoenixHelper.getPhoenixRequestBuild(anyString())).thenReturn(mockRequest);
		when(iDeleteReconciliationDao.getCurrentStatusIPId()).thenReturn(2);
		when(iDeleteReconciliationDao.getJobID(Constants.DATASOURCE_NAME)).thenReturn(4);
		when(iDeleteReconciliationDao.getIncrementalDataLoadAuditId(anyInt(), anyString(), anyString(),
				eq(Constants.DATASOURCE_NAME))).thenReturn(UUID.randomUUID());
		when(iDeleteReconciliationDao.getCurrentStatusCId(Constants.DATASOURCE_NAME, Constants.STATUS_READY_TO_PROCESS))
				.thenReturn(15);
		when(iDeleteReconciliationDao.getCountFailedJobsInLast7Days(DATASOURCE_NAME, lastSevenDayDate,
				currentStatusIdFailed)).thenReturn(total);
		when(dataResponse.getLetterData()).thenReturn(letterDataList);
		MockResponse mockRes = new MockResponse().setBody(mockJsonResponse).addHeader("Content-Type",
				"application/json");
		mockWebServer.enqueue(mockRes);

		doNothing().when(deletePhnxReconciliationServiceImpl).insertToCaseLink();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToAccount();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToCaseconsideration();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToCorrepondenceSource();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToEmail();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToContact();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToIncident();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToOfferoutcome();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToPhone();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToPortal();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToTask();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToUser();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToCorrespondence();

		/*
		 * deletePhnxReconciliationServiceImpl.processAllJob();
		 * 
		 * verify(iDeleteReconciliationDao, times(1)).getCurrentStatusIPId();
		 * verify(iDeleteReconciliationDao, times(1)).insertToIncrementalAudit(anyInt(),
		 * anyInt(), eq(Constants.DATASOURCE_NAME), anyString());
		 * verify(iDeleteReconciliationDao,
		 * times(1)).updateIncrementAuditJobQuery(anyLong(), anyInt(), anyInt(),
		 * anyString(), any(UUID.class), anyString());
		 */

	}

	@Test
	@DisplayName("Test processAllJob for InsertToLetter with no data")
	void insertToLetter_noData() throws InterruptedException, ParseException, JobFailedException, IOException {
		List<LetterData> letterDataList = new ArrayList<>();

		int currentStatusIdFailed = 2;
		when(phoenixHelper.getEndTime()).thenReturn("NA");
		when(phoenixHelper.getStartTime()).thenReturn("NA");
		String mockFetchXml = "<fetch  version='1.0' mapping='logical' count='100' page='3'><entity name='audit'><attribute name='objecttypecode'/><attribute name='action'/><attribute name='createdon'/><attribute name='objectid'/><filter><condition attribute='objecttypecode' operator='eq' value='10383'/><condition attribute='action' operator='eq' value='3'/><condition attribute='createdon' operator='gt' value='2024-11-09T11:56:05.360143600Z'/></filter></entity></fetch>";

		String mockJsonResponse = "{\"value\": []}";
		when(phoenixHelper.getFetchRecord()).thenReturn(batch);
		when(phoenixHelper.getFetchXML(Constants.LETTER_ENTITY,  jobEndTime, lastupdatedDate,batch,pagingCookie,page)).thenReturn(mockFetchXml);
		HttpUrl mockHttpUrl = mockWebServer.url("/phoniex/letter?fetchXml=test");
		mockRequest = new Request.Builder().url(mockHttpUrl).build();
		when(phoenixHelper.getPhoenixRequestBuild(anyString())).thenReturn(mockRequest);
		when(iDeleteReconciliationDao.getCurrentStatusIPId()).thenReturn(2);
		when(iDeleteReconciliationDao.getJobID(Constants.DATASOURCE_NAME)).thenReturn(4);
		when(iDeleteReconciliationDao.getIncrementalDataLoadAuditId(anyInt(), anyString(), anyString(),
				eq(Constants.DATASOURCE_NAME))).thenReturn(UUID.randomUUID());
		when(iDeleteReconciliationDao.getCurrentStatusCId(Constants.DATASOURCE_NAME, Constants.STATUS_READY_TO_PROCESS))
				.thenReturn(15);
		when(iDeleteReconciliationDao.getCountFailedJobsInLast7Days(DATASOURCE_NAME, lastSevenDayDate,
				currentStatusIdFailed)).thenReturn(total);
		when(dataResponse.getLetterData()).thenReturn(letterDataList);
		MockResponse mockRes = new MockResponse().setBody(mockJsonResponse).addHeader("Content-Type",
				"application/json");
		mockWebServer.enqueue(mockRes);

		doNothing().when(deletePhnxReconciliationServiceImpl).insertToCaseLink();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToAccount();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToCaseconsideration();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToCorrepondenceSource();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToEmail();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToContact();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToIncident();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToOfferoutcome();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToPhone();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToPortal();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToTask();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToUser();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToCorrespondence();

		/*
		 * deletePhnxReconciliationServiceImpl.processAllJob();
		 * 
		 * verify(iDeleteReconciliationDao, times(1)).getCurrentStatusIPId();
		 * verify(iDeleteReconciliationDao, times(1)).insertToIncrementalAudit(anyInt(),
		 * anyInt(), eq(Constants.DATASOURCE_NAME), anyString());
		 * verify(iDeleteReconciliationDao,
		 * times(1)).updateIncrementAuditJobQuery(anyLong(), anyInt(), anyInt(),
		 * anyString(), any(UUID.class), anyString());
		 */

	}

	@Test
	@DisplayName("Test processAllJob for insertToOfferoutcome with valid data")
	void insertToOfferoutcome_Success() throws InterruptedException, IOException, JobFailedException, ParseException {
		List<OfferoutcomeData> offeroutcomeDataList = new ArrayList<>();
		UUID randomUuuid = UUID.randomUUID();
		int currentStatusIdFailed = 2;
		when(phoenixHelper.getEndTime()).thenReturn("NA");
		when(phoenixHelper.getStartTime()).thenReturn("NA");
		String mockFetchXml = "<fetch  version='1.0' mapping='logical' count='100' page='3'><entity name='audit'><attribute name='objecttypecode'/><attribute name='action'/><attribute name='createdon'/><attribute name='objectid'/><filter><condition attribute='objecttypecode' operator='eq' value='10383'/><condition attribute='action' operator='eq' value='3'/><condition attribute='createdon' operator='gt' value='2024-11-09T11:56:05.360143600Z'/></filter></entity></fetch>";
		String mockJsonResponse = "{\"value\": [{\"_objectid_value\": \"" + randomUuuid
				+ "\", \"createdon\": \"2025-01-02\"}]}";
		when(phoenixHelper.getFetchRecord()).thenReturn(batch);
		when(phoenixHelper.getFetchXML(Constants.OFFEROUTCOME_ENTITY,  jobEndTime, lastupdatedDate,batch,pagingCookie,page)).thenReturn(mockFetchXml);
		HttpUrl mockHttpUrl = mockWebServer.url("/phoniex/offeroutcome?fetchXml=test");
		mockRequest = new Request.Builder().url(mockHttpUrl).build();
		when(phoenixHelper.getPhoenixRequestBuild(anyString())).thenReturn(mockRequest);
		when(iDeleteReconciliationDao.getCurrentStatusIPId()).thenReturn(2);
		when(iDeleteReconciliationDao.getJobID(Constants.DATASOURCE_NAME)).thenReturn(4);
		when(iDeleteReconciliationDao.getIncrementalDataLoadAuditId(anyInt(), anyString(), anyString(),
				eq(Constants.DATASOURCE_NAME))).thenReturn(UUID.randomUUID());
		when(iDeleteReconciliationDao.getCurrentStatusCId(Constants.DATASOURCE_NAME, Constants.STATUS_READY_TO_PROCESS))
				.thenReturn(15);
		when(iDeleteReconciliationDao.getCountFailedJobsInLast7Days(DATASOURCE_NAME, lastSevenDayDate,
				currentStatusIdFailed)).thenReturn(total);
		when(dataResponse.getOfferoutcomeData()).thenReturn(offeroutcomeDataList);
		MockResponse mockRes = new MockResponse().setBody(mockJsonResponse).addHeader("Content-Type",
				"application/json");
		mockWebServer.enqueue(mockRes);

		doNothing().when(deletePhnxReconciliationServiceImpl).insertToContact();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToAccount();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToCaseLink();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToCorrepondenceSource();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToEmail();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToIncident();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToLetter();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToCaseconsideration();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToPhone();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToPortal();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToTask();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToUser();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToCorrespondence();

		/*
		 * deletePhnxReconciliationServiceImpl.processAllJob();
		 * 
		 * verify(iDeleteReconciliationDao, times(1)).getCurrentStatusIPId();
		 * verify(iDeleteReconciliationDao, times(1)).insertToIncrementalAudit(anyInt(),
		 * anyInt(), eq(Constants.DATASOURCE_NAME), anyString());
		 * verify(iDeleteReconciliationDao,
		 * times(1)).updateIncrementAuditJobQuery(anyLong(), anyInt(), anyInt(),
		 * anyString(), any(UUID.class), anyString());
		 */
	}

	@Test
	@DisplayName("Test processAllJob for insertToOfferoutcome with no data")
	void insertToOfferoutcome_noData() throws InterruptedException, ParseException, JobFailedException, IOException {
		List<OfferoutcomeData> offeroutcomeDataList = new ArrayList<>();

		int currentStatusIdFailed = 2;
		when(phoenixHelper.getEndTime()).thenReturn("NA");
		when(phoenixHelper.getStartTime()).thenReturn("NA");
		String mockFetchXml = "<fetch  version='1.0' mapping='logical' count='100' page='3'><entity name='audit'><attribute name='objecttypecode'/><attribute name='action'/><attribute name='createdon'/><attribute name='objectid'/><filter><condition attribute='objecttypecode' operator='eq' value='10383'/><condition attribute='action' operator='eq' value='3'/><condition attribute='createdon' operator='gt' value='2024-11-09T11:56:05.360143600Z'/></filter></entity></fetch>";
		String mockJsonResponse = "{\"value\": []}";
		when(phoenixHelper.getFetchRecord()).thenReturn(batch);
		when(phoenixHelper.getFetchXML(Constants.OFFEROUTCOME_ENTITY, jobEndTime, lastupdatedDate,batch,pagingCookie,page)).thenReturn(mockFetchXml);
		HttpUrl mockHttpUrl = mockWebServer.url("/phoniex/offeroutcome?fetchXml=test");
		mockRequest = new Request.Builder().url(mockHttpUrl).build();
		when(phoenixHelper.getPhoenixRequestBuild(anyString())).thenReturn(mockRequest);
		when(iDeleteReconciliationDao.getCurrentStatusIPId()).thenReturn(2);
		when(iDeleteReconciliationDao.getJobID(Constants.DATASOURCE_NAME)).thenReturn(4);
		when(iDeleteReconciliationDao.getIncrementalDataLoadAuditId(anyInt(), anyString(), anyString(),
				eq(Constants.DATASOURCE_NAME))).thenReturn(UUID.randomUUID());
		when(iDeleteReconciliationDao.getCurrentStatusCId(Constants.DATASOURCE_NAME, Constants.STATUS_READY_TO_PROCESS))
				.thenReturn(15);
		when(iDeleteReconciliationDao.getCountFailedJobsInLast7Days(DATASOURCE_NAME, lastSevenDayDate,
				currentStatusIdFailed)).thenReturn(total);
		when(dataResponse.getOfferoutcomeData()).thenReturn(offeroutcomeDataList);
		MockResponse mockRes = new MockResponse().setBody(mockJsonResponse).addHeader("Content-Type",
				"application/json");
		mockWebServer.enqueue(mockRes);

		doNothing().when(deletePhnxReconciliationServiceImpl).insertToContact();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToAccount();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToCaseLink();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToCorrepondenceSource();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToEmail();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToIncident();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToLetter();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToCaseconsideration();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToPhone();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToPortal();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToTask();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToUser();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToCorrespondence();

		/*
		 * deletePhnxReconciliationServiceImpl.processAllJob();
		 * 
		 * verify(iDeleteReconciliationDao, times(1)).getCurrentStatusIPId();
		 * verify(iDeleteReconciliationDao, times(1)).insertToIncrementalAudit(anyInt(),
		 * anyInt(), eq(Constants.DATASOURCE_NAME), anyString());
		 * verify(iDeleteReconciliationDao,
		 * times(1)).updateIncrementAuditJobQuery(anyLong(), anyInt(), anyInt(),
		 * anyString(), any(UUID.class), anyString());
		 */
	}

	@Test
	@DisplayName("Test processAllJob for insertToPhone with valid data")
	void insertToPhone_Success() throws InterruptedException, IOException, JobFailedException, ParseException {
		List<PhoneData> phoneDataList = new ArrayList<>();
		UUID randomUuuid = UUID.randomUUID();
		int currentStatusIdFailed = 2;
		when(phoenixHelper.getEndTime()).thenReturn("NA");
		when(phoenixHelper.getStartTime()).thenReturn("NA");
		String mockFetchXml = "<fetch  version='1.0' mapping='logical' count='100' page='3'><entity name='audit'><attribute name='objecttypecode'/><attribute name='action'/><attribute name='createdon'/><attribute name='objectid'/><filter><condition attribute='objecttypecode' operator='eq' value='10383'/><condition attribute='action' operator='eq' value='3'/><condition attribute='createdon' operator='gt' value='2024-11-09T11:56:05.360143600Z'/></filter></entity></fetch>";
		String mockJsonResponse = "{\"value\": [{\"_objectid_value\": \"" + randomUuuid
				+ "\", \"createdon\": \"2025-01-02\"}]}";
		when(phoenixHelper.getFetchRecord()).thenReturn(batch);
		when(phoenixHelper.getFetchXML(Constants.PHONE_ENTITY, jobEndTime, lastupdatedDate,batch,pagingCookie,page)).thenReturn(mockFetchXml);
		HttpUrl mockHttpUrl = mockWebServer.url("/phoniex/phone?fetchXml=test");
		mockRequest = new Request.Builder().url(mockHttpUrl).build();
		when(phoenixHelper.getPhoenixRequestBuild(anyString())).thenReturn(mockRequest);
		when(iDeleteReconciliationDao.getCurrentStatusIPId()).thenReturn(2);
		when(iDeleteReconciliationDao.getJobID(Constants.DATASOURCE_NAME)).thenReturn(4);
		when(iDeleteReconciliationDao.getIncrementalDataLoadAuditId(anyInt(), anyString(), anyString(),
				eq(Constants.DATASOURCE_NAME))).thenReturn(UUID.randomUUID());
		when(iDeleteReconciliationDao.getCurrentStatusCId(Constants.DATASOURCE_NAME, Constants.STATUS_READY_TO_PROCESS))
				.thenReturn(15);
		when(iDeleteReconciliationDao.getCountFailedJobsInLast7Days(DATASOURCE_NAME, lastSevenDayDate,
				currentStatusIdFailed)).thenReturn(total);
		when(dataResponse.getPhoneData()).thenReturn(phoneDataList);
		MockResponse mockRes = new MockResponse().setBody(mockJsonResponse).addHeader("Content-Type",
				"application/json");
		mockWebServer.enqueue(mockRes);

		doNothing().when(deletePhnxReconciliationServiceImpl).insertToContact();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToAccount();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToCaseLink();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToCorrepondenceSource();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToEmail();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToIncident();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToLetter();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToCaseconsideration();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToOfferoutcome();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToPortal();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToTask();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToUser();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToCorrespondence();

		/*
		 * deletePhnxReconciliationServiceImpl.processAllJob();
		 * 
		 * verify(iDeleteReconciliationDao, times(1)).getCurrentStatusIPId();
		 * verify(iDeleteReconciliationDao, times(1)).insertToIncrementalAudit(anyInt(),
		 * anyInt(), eq(Constants.DATASOURCE_NAME), anyString());
		 * verify(iDeleteReconciliationDao,
		 * times(1)).updateIncrementAuditJobQuery(anyLong(), anyInt(), anyInt(),
		 * anyString(), any(UUID.class), anyString());
		 */
	}

	@Test
	@DisplayName("Test processAllJob for insertToPhone with no data")
	void insertToPhone_noData() throws InterruptedException, ParseException, JobFailedException, IOException {
		List<PhoneData> phoneDataList = new ArrayList<>();

		int currentStatusIdFailed = 2;
		when(phoenixHelper.getEndTime()).thenReturn("NA");
		when(phoenixHelper.getStartTime()).thenReturn("NA");
		String mockFetchXml = "<fetch  version='1.0' mapping='logical' count='100' page='3'><entity name='audit'><attribute name='objecttypecode'/><attribute name='action'/><attribute name='createdon'/><attribute name='objectid'/><filter><condition attribute='objecttypecode' operator='eq' value='10383'/><condition attribute='action' operator='eq' value='3'/><condition attribute='createdon' operator='gt' value='2024-11-09T11:56:05.360143600Z'/></filter></entity></fetch>";
		String mockJsonResponse = "{\"value\": []}";
		when(phoenixHelper.getFetchRecord()).thenReturn(batch);
		when(phoenixHelper.getFetchXML(Constants.PHONE_ENTITY,  jobEndTime, lastupdatedDate,batch,pagingCookie,page)).thenReturn(mockFetchXml);
		HttpUrl mockHttpUrl = mockWebServer.url("/phoniex/phone?fetchXml=test");
		mockRequest = new Request.Builder().url(mockHttpUrl).build();
		when(phoenixHelper.getPhoenixRequestBuild(anyString())).thenReturn(mockRequest);
		when(iDeleteReconciliationDao.getCurrentStatusIPId()).thenReturn(2);
		when(iDeleteReconciliationDao.getJobID(Constants.DATASOURCE_NAME)).thenReturn(4);
		when(iDeleteReconciliationDao.getIncrementalDataLoadAuditId(anyInt(), anyString(), anyString(),
				eq(Constants.DATASOURCE_NAME))).thenReturn(UUID.randomUUID());
		when(iDeleteReconciliationDao.getCurrentStatusCId(Constants.DATASOURCE_NAME, Constants.STATUS_READY_TO_PROCESS))
				.thenReturn(15);
		when(iDeleteReconciliationDao.getCountFailedJobsInLast7Days(DATASOURCE_NAME, lastSevenDayDate,
				currentStatusIdFailed)).thenReturn(total);
		when(dataResponse.getPhoneData()).thenReturn(phoneDataList);
		MockResponse mockRes = new MockResponse().setBody(mockJsonResponse).addHeader("Content-Type",
				"application/json");
		mockWebServer.enqueue(mockRes);

		doNothing().when(deletePhnxReconciliationServiceImpl).insertToContact();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToAccount();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToCaseLink();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToCorrepondenceSource();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToEmail();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToIncident();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToLetter();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToCaseconsideration();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToOfferoutcome();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToPortal();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToTask();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToUser();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToCorrespondence();

		/*
		 * deletePhnxReconciliationServiceImpl.processAllJob();
		 * 
		 * verify(iDeleteReconciliationDao, times(1)).getCurrentStatusIPId();
		 * verify(iDeleteReconciliationDao, times(1)).insertToIncrementalAudit(anyInt(),
		 * anyInt(), eq(Constants.DATASOURCE_NAME), anyString());
		 * verify(iDeleteReconciliationDao,
		 * times(1)).updateIncrementAuditJobQuery(anyLong(), anyInt(), anyInt(),
		 * anyString(), any(UUID.class), anyString());
		 */
	}

	@Test
	@DisplayName("Test processAllJob for insertToPortal with valid data")
	void insertToPortal_Success() throws InterruptedException, IOException, JobFailedException, ParseException {
		List<PortalData> portalDataList = new ArrayList<>();
		UUID randomUuuid = UUID.randomUUID();
		int currentStatusIdFailed = 2;
		when(phoenixHelper.getEndTime()).thenReturn("NA");
		when(phoenixHelper.getStartTime()).thenReturn("NA");
		String mockFetchXml = "<fetch  version='1.0' mapping='logical' count='100' page='3'><entity name='audit'><attribute name='objecttypecode'/><attribute name='action'/><attribute name='createdon'/><attribute name='objectid'/><filter><condition attribute='objecttypecode' operator='eq' value='10383'/><condition attribute='action' operator='eq' value='3'/><condition attribute='createdon' operator='gt' value='2024-11-09T11:56:05.360143600Z'/></filter></entity></fetch>";
		String mockJsonResponse = "{\"value\": [{\"_objectid_value\": \"" + randomUuuid
				+ "\", \"createdon\": \"2025-01-02\"}]}";
		when(phoenixHelper.getFetchRecord()).thenReturn(batch);
		when(phoenixHelper.getFetchXML(Constants.PORTAL_ENTITY, jobEndTime, lastupdatedDate,batch,pagingCookie,page)).thenReturn(mockFetchXml);
		HttpUrl mockHttpUrl = mockWebServer.url("/phoniex/portal?fetchXml=test");
		mockRequest = new Request.Builder().url(mockHttpUrl).build();
		when(phoenixHelper.getPhoenixRequestBuild(anyString())).thenReturn(mockRequest);
		when(iDeleteReconciliationDao.getCurrentStatusIPId()).thenReturn(2);
		when(iDeleteReconciliationDao.getJobID(Constants.DATASOURCE_NAME)).thenReturn(4);
		when(iDeleteReconciliationDao.getIncrementalDataLoadAuditId(anyInt(), anyString(), anyString(),
				eq(Constants.DATASOURCE_NAME))).thenReturn(UUID.randomUUID());
		when(iDeleteReconciliationDao.getCurrentStatusCId(Constants.DATASOURCE_NAME, Constants.STATUS_READY_TO_PROCESS))
				.thenReturn(15);
		when(iDeleteReconciliationDao.getCountFailedJobsInLast7Days(DATASOURCE_NAME, lastSevenDayDate,
				currentStatusIdFailed)).thenReturn(total);
		when(dataResponse.getPortalData()).thenReturn(portalDataList);
		MockResponse mockRes = new MockResponse().setBody(mockJsonResponse).addHeader("Content-Type",
				"application/json");
		mockWebServer.enqueue(mockRes);

		doNothing().when(deletePhnxReconciliationServiceImpl).insertToContact();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToAccount();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToCaseLink();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToCorrepondenceSource();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToEmail();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToIncident();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToLetter();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToCaseconsideration();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToOfferoutcome();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToPhone();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToTask();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToUser();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToCorrespondence();

		/*
		 * deletePhnxReconciliationServiceImpl.processAllJob();
		 * 
		 * verify(iDeleteReconciliationDao, times(1)).getCurrentStatusIPId();
		 * verify(iDeleteReconciliationDao, times(1)).insertToIncrementalAudit(anyInt(),
		 * anyInt(), eq(Constants.DATASOURCE_NAME), anyString());
		 * verify(iDeleteReconciliationDao,
		 * times(1)).updateIncrementAuditJobQuery(anyLong(), anyInt(), anyInt(),
		 * anyString(), any(UUID.class), anyString());
		 */

	}

	@Test
	@DisplayName("Test processAllJob for insertToPortal with no data")
	void insertToPortal_noData() throws InterruptedException, ParseException, JobFailedException, IOException {
		List<PortalData> portalDataList = new ArrayList<>();

		int currentStatusIdFailed = 2;
		when(phoenixHelper.getEndTime()).thenReturn("NA");
		when(phoenixHelper.getStartTime()).thenReturn("NA");
		String mockFetchXml = "<fetch  version='1.0' mapping='logical' count='100' page='3'><entity name='audit'><attribute name='objecttypecode'/><attribute name='action'/><attribute name='createdon'/><attribute name='objectid'/><filter><condition attribute='objecttypecode' operator='eq' value='10383'/><condition attribute='action' operator='eq' value='3'/><condition attribute='createdon' operator='gt' value='2024-11-09T11:56:05.360143600Z'/></filter></entity></fetch>";
		String mockJsonResponse = "{\"value\": []}";
		when(phoenixHelper.getFetchRecord()).thenReturn(batch);
		when(phoenixHelper.getFetchXML(Constants.PORTAL_ENTITY,  jobEndTime, lastupdatedDate,batch,pagingCookie,page)).thenReturn(mockFetchXml);
		HttpUrl mockHttpUrl = mockWebServer.url("/phoniex/portal?fetchXml=test");
		mockRequest = new Request.Builder().url(mockHttpUrl).build();
		when(phoenixHelper.getPhoenixRequestBuild(anyString())).thenReturn(mockRequest);
		when(iDeleteReconciliationDao.getCurrentStatusIPId()).thenReturn(2);
		when(iDeleteReconciliationDao.getJobID(Constants.DATASOURCE_NAME)).thenReturn(4);
		when(iDeleteReconciliationDao.getIncrementalDataLoadAuditId(anyInt(), anyString(), anyString(),
				eq(Constants.DATASOURCE_NAME))).thenReturn(UUID.randomUUID());
		when(iDeleteReconciliationDao.getCurrentStatusCId(Constants.DATASOURCE_NAME, Constants.STATUS_READY_TO_PROCESS))
				.thenReturn(15);
		when(iDeleteReconciliationDao.getCountFailedJobsInLast7Days(DATASOURCE_NAME, lastSevenDayDate,
				currentStatusIdFailed)).thenReturn(total);
		when(dataResponse.getPortalData()).thenReturn(portalDataList);
		MockResponse mockRes = new MockResponse().setBody(mockJsonResponse).addHeader("Content-Type",
				"application/json");
		mockWebServer.enqueue(mockRes);

		doNothing().when(deletePhnxReconciliationServiceImpl).insertToContact();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToAccount();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToCaseLink();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToCorrepondenceSource();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToEmail();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToIncident();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToLetter();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToCaseconsideration();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToOfferoutcome();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToPhone();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToTask();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToUser();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToCorrespondence();

		/*
		 * deletePhnxReconciliationServiceImpl.processAllJob();
		 * 
		 * verify(iDeleteReconciliationDao, times(1)).getCurrentStatusIPId();
		 * verify(iDeleteReconciliationDao, times(1)).insertToIncrementalAudit(anyInt(),
		 * anyInt(), eq(Constants.DATASOURCE_NAME), anyString());
		 * verify(iDeleteReconciliationDao,
		 * times(1)).updateIncrementAuditJobQuery(anyLong(), anyInt(), anyInt(),
		 * anyString(), any(UUID.class), anyString());
		 */
	}

	@Test
	@DisplayName("Test processAllJob for insertToTask with valid data")
	void insertToTask_Success() throws InterruptedException, IOException, JobFailedException, ParseException {
		List<TaskData> taskDataList = new ArrayList<>();
		UUID randomUuuid = UUID.randomUUID();
		int currentStatusIdFailed = 2;
		when(phoenixHelper.getEndTime()).thenReturn("NA");
		when(phoenixHelper.getStartTime()).thenReturn("NA");
		String mockFetchXml = "<fetch  version='1.0' mapping='logical' count='100' page='3'><entity name='audit'><attribute name='objecttypecode'/><attribute name='action'/><attribute name='createdon'/><attribute name='objectid'/><filter><condition attribute='objecttypecode' operator='eq' value='10383'/><condition attribute='action' operator='eq' value='3'/><condition attribute='createdon' operator='gt' value='2024-11-09T11:56:05.360143600Z'/></filter></entity></fetch>";
		String mockJsonResponse = "{\"value\": [{\"_objectid_value\": \"" + randomUuuid
				+ "\", \"createdon\": \"2025-01-02\"}]}";
		when(phoenixHelper.getFetchRecord()).thenReturn(batch);
		when(phoenixHelper.getFetchXML(Constants.TASK_ENTITY,  jobEndTime, lastupdatedDate,batch,pagingCookie,page)).thenReturn(mockFetchXml);
		HttpUrl mockHttpUrl = mockWebServer.url("/phoniex/task?fetchXml=test");
		mockRequest = new Request.Builder().url(mockHttpUrl).build();
		when(phoenixHelper.getPhoenixRequestBuild(anyString())).thenReturn(mockRequest);
		when(iDeleteReconciliationDao.getCurrentStatusIPId()).thenReturn(2);
		when(iDeleteReconciliationDao.getJobID(Constants.DATASOURCE_NAME)).thenReturn(4);
		when(iDeleteReconciliationDao.getIncrementalDataLoadAuditId(anyInt(), anyString(), anyString(),
				eq(Constants.DATASOURCE_NAME))).thenReturn(UUID.randomUUID());
		when(iDeleteReconciliationDao.getCurrentStatusCId(Constants.DATASOURCE_NAME, Constants.STATUS_READY_TO_PROCESS))
				.thenReturn(15);
		when(iDeleteReconciliationDao.getCountFailedJobsInLast7Days(DATASOURCE_NAME, lastSevenDayDate,
				currentStatusIdFailed)).thenReturn(total);
		when(dataResponse.getTaskData()).thenReturn(taskDataList);
		MockResponse mockRes = new MockResponse().setBody(mockJsonResponse).addHeader("Content-Type",
				"application/json");
		mockWebServer.enqueue(mockRes);

		doNothing().when(deletePhnxReconciliationServiceImpl).insertToContact();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToAccount();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToCaseLink();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToCorrepondenceSource();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToEmail();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToIncident();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToLetter();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToCaseconsideration();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToOfferoutcome();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToPhone();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToPortal();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToUser();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToCorrespondence();

		/*
		 * deletePhnxReconciliationServiceImpl.processAllJob();
		 * 
		 * verify(iDeleteReconciliationDao, times(1)).getCurrentStatusIPId();
		 * verify(iDeleteReconciliationDao, times(1)).insertToIncrementalAudit(anyInt(),
		 * anyInt(), eq(Constants.DATASOURCE_NAME), anyString());
		 * verify(iDeleteReconciliationDao,
		 * times(1)).updateIncrementAuditJobQuery(anyLong(), anyInt(), anyInt(),
		 * anyString(), any(UUID.class), anyString());
		 */
	}

	@Test
	@DisplayName("Test processAllJob for insertToTask with no data")
	void insertToTask_noData() throws InterruptedException, ParseException, JobFailedException, IOException {
		List<TaskData> taskDataList = new ArrayList<>();

		int currentStatusIdFailed = 2;
		when(phoenixHelper.getEndTime()).thenReturn("NA");
		when(phoenixHelper.getStartTime()).thenReturn("NA");
		String mockFetchXml = "<fetch  version='1.0' mapping='logical' count='100' page='3'><entity name='audit'><attribute name='objecttypecode'/><attribute name='action'/><attribute name='createdon'/><attribute name='objectid'/><filter><condition attribute='objecttypecode' operator='eq' value='10383'/><condition attribute='action' operator='eq' value='3'/><condition attribute='createdon' operator='gt' value='2024-11-09T11:56:05.360143600Z'/></filter></entity></fetch>";
		String mockJsonResponse = "{\"value\": []}";
		when(phoenixHelper.getFetchRecord()).thenReturn(batch);
		when(phoenixHelper.getFetchXML(Constants.TASK_ENTITY,  jobEndTime, lastupdatedDate,batch,pagingCookie,page)).thenReturn(mockFetchXml);
		HttpUrl mockHttpUrl = mockWebServer.url("/phoniex/task?fetchXml=test");
		mockRequest = new Request.Builder().url(mockHttpUrl).build();
		when(phoenixHelper.getPhoenixRequestBuild(anyString())).thenReturn(mockRequest);
		when(iDeleteReconciliationDao.getCurrentStatusIPId()).thenReturn(2);
		when(iDeleteReconciliationDao.getJobID(Constants.DATASOURCE_NAME)).thenReturn(4);
		when(iDeleteReconciliationDao.getIncrementalDataLoadAuditId(anyInt(), anyString(), anyString(),
				eq(Constants.DATASOURCE_NAME))).thenReturn(UUID.randomUUID());
		when(iDeleteReconciliationDao.getCurrentStatusCId(Constants.DATASOURCE_NAME, Constants.STATUS_READY_TO_PROCESS))
				.thenReturn(15);
		when(iDeleteReconciliationDao.getCountFailedJobsInLast7Days(DATASOURCE_NAME, lastSevenDayDate,
				currentStatusIdFailed)).thenReturn(total);
		when(dataResponse.getTaskData()).thenReturn(taskDataList);
		MockResponse mockRes = new MockResponse().setBody(mockJsonResponse).addHeader("Content-Type",
				"application/json");
		mockWebServer.enqueue(mockRes);

		doNothing().when(deletePhnxReconciliationServiceImpl).insertToContact();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToAccount();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToCaseLink();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToCorrepondenceSource();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToEmail();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToIncident();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToLetter();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToCaseconsideration();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToOfferoutcome();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToPhone();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToPortal();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToUser();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToCorrespondence();

		/*
		 * deletePhnxReconciliationServiceImpl.processAllJob();
		 * 
		 * verify(iDeleteReconciliationDao, times(1)).getCurrentStatusIPId();
		 * verify(iDeleteReconciliationDao, times(1)).insertToIncrementalAudit(anyInt(),
		 * anyInt(), eq(Constants.DATASOURCE_NAME), anyString());
		 * verify(iDeleteReconciliationDao,
		 * times(1)).updateIncrementAuditJobQuery(anyLong(), anyInt(), anyInt(),
		 * anyString(), any(UUID.class), anyString());
		 */

	}

	@Test
	@DisplayName("Test processAllJob for insertToUser with valid data")
	void insertToUser_Success() throws InterruptedException, IOException, JobFailedException, ParseException {
		List<UserData> userDataList = new ArrayList<>();
		UUID randomUuuid = UUID.randomUUID();
		int currentStatusIdFailed = 2;
		when(phoenixHelper.getEndTime()).thenReturn("NA");
		when(phoenixHelper.getStartTime()).thenReturn("NA");
		String mockFetchXml = "<fetch  version='1.0' mapping='logical' count='100' page='3'><entity name='audit'><attribute name='objecttypecode'/><attribute name='action'/><attribute name='createdon'/><attribute name='objectid'/><filter><condition attribute='objecttypecode' operator='eq' value='10383'/><condition attribute='action' operator='eq' value='3'/><condition attribute='createdon' operator='gt' value='2024-11-09T11:56:05.360143600Z'/></filter></entity></fetch>";
		String mockJsonResponse = "{\"value\": [{\"_objectid_value\": \"" + randomUuuid
				+ "\", \"createdon\": \"2025-01-02\"}]}";
		when(phoenixHelper.getFetchRecord()).thenReturn(batch);
		when(phoenixHelper.getFetchXML(Constants.USER_ENTITY,  jobEndTime, lastupdatedDate,batch,pagingCookie,page)).thenReturn(mockFetchXml);
		HttpUrl mockHttpUrl = mockWebServer.url("/phoniex/user?fetchXml=test");
		mockRequest = new Request.Builder().url(mockHttpUrl).build();
		when(phoenixHelper.getPhoenixRequestBuild(anyString())).thenReturn(mockRequest);
		when(iDeleteReconciliationDao.getCurrentStatusIPId()).thenReturn(2);
		when(iDeleteReconciliationDao.getJobID(Constants.DATASOURCE_NAME)).thenReturn(4);
		when(iDeleteReconciliationDao.getIncrementalDataLoadAuditId(anyInt(), anyString(), anyString(),
				eq(Constants.DATASOURCE_NAME))).thenReturn(UUID.randomUUID());
		when(iDeleteReconciliationDao.getCurrentStatusCId(Constants.DATASOURCE_NAME, Constants.STATUS_READY_TO_PROCESS))
				.thenReturn(15);
		when(iDeleteReconciliationDao.getCountFailedJobsInLast7Days(DATASOURCE_NAME, lastSevenDayDate,
				currentStatusIdFailed)).thenReturn(total);
		when(dataResponse.getUserData()).thenReturn(userDataList);
		MockResponse mockRes = new MockResponse().setBody(mockJsonResponse).addHeader("Content-Type",
				"application/json");
		mockWebServer.enqueue(mockRes);

		doNothing().when(deletePhnxReconciliationServiceImpl).insertToContact();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToAccount();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToCaseLink();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToCorrepondenceSource();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToEmail();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToIncident();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToLetter();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToCaseconsideration();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToOfferoutcome();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToPhone();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToPortal();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToTask();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToCorrespondence();

		/*
		 * deletePhnxReconciliationServiceImpl.processAllJob();
		 * 
		 * verify(iDeleteReconciliationDao, times(1)).getCurrentStatusIPId();
		 * verify(iDeleteReconciliationDao, times(1)).insertToIncrementalAudit(anyInt(),
		 * anyInt(), eq(Constants.DATASOURCE_NAME), anyString());
		 * verify(iDeleteReconciliationDao,
		 * times(1)).updateIncrementAuditJobQuery(anyLong(), anyInt(), anyInt(),
		 * anyString(), any(UUID.class), anyString());
		 */

	}

	@Test
	@DisplayName("Test processAllJob for insertToUser with no data")
	void insertToUser_noData() throws InterruptedException, ParseException, JobFailedException, IOException {
		List<UserData> userDataList = new ArrayList<>();

		int currentStatusIdFailed = 2;
		when(phoenixHelper.getEndTime()).thenReturn("NA");
		when(phoenixHelper.getStartTime()).thenReturn("NA");
		String mockFetchXml = "<fetch  version='1.0' mapping='logical' count='100' page='3'><entity name='audit'><attribute name='objecttypecode'/><attribute name='action'/><attribute name='createdon'/><attribute name='objectid'/><filter><condition attribute='objecttypecode' operator='eq' value='10383'/><condition attribute='action' operator='eq' value='3'/><condition attribute='createdon' operator='gt' value='2024-11-09T11:56:05.360143600Z'/></filter></entity></fetch>";
		String mockJsonResponse = "{\"value\": []}";
		when(phoenixHelper.getFetchRecord()).thenReturn(batch);
		when(phoenixHelper.getFetchXML(Constants.USER_ENTITY, jobEndTime, lastupdatedDate,batch,pagingCookie,page)).thenReturn(mockFetchXml);
		HttpUrl mockHttpUrl = mockWebServer.url("/phoniex/user?fetchXml=test");
		mockRequest = new Request.Builder().url(mockHttpUrl).build();
		when(phoenixHelper.getPhoenixRequestBuild(anyString())).thenReturn(mockRequest);
		when(iDeleteReconciliationDao.getCurrentStatusIPId()).thenReturn(2);
		when(iDeleteReconciliationDao.getJobID(Constants.DATASOURCE_NAME)).thenReturn(4);
		when(iDeleteReconciliationDao.getIncrementalDataLoadAuditId(anyInt(), anyString(), anyString(),
				eq(Constants.DATASOURCE_NAME))).thenReturn(UUID.randomUUID());
		when(iDeleteReconciliationDao.getCurrentStatusCId(Constants.DATASOURCE_NAME, Constants.STATUS_READY_TO_PROCESS))
				.thenReturn(15);
		when(iDeleteReconciliationDao.getCountFailedJobsInLast7Days(DATASOURCE_NAME, lastSevenDayDate,
				currentStatusIdFailed)).thenReturn(total);
		when(dataResponse.getUserData()).thenReturn(userDataList);
		MockResponse mockRes = new MockResponse().setBody(mockJsonResponse).addHeader("Content-Type",
				"application/json");
		mockWebServer.enqueue(mockRes);

		doNothing().when(deletePhnxReconciliationServiceImpl).insertToContact();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToAccount();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToCaseLink();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToCorrepondenceSource();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToEmail();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToIncident();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToLetter();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToCaseconsideration();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToOfferoutcome();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToPhone();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToPortal();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToTask();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToCorrespondence();

		/*
		 * deletePhnxReconciliationServiceImpl.processAllJob();
		 * 
		 * verify(iDeleteReconciliationDao, times(1)).getCurrentStatusIPId();
		 * verify(iDeleteReconciliationDao, times(1)).insertToIncrementalAudit(anyInt(),
		 * anyInt(), eq(Constants.DATASOURCE_NAME), anyString());
		 * verify(iDeleteReconciliationDao,
		 * times(1)).updateIncrementAuditJobQuery(anyLong(), anyInt(), anyInt(),
		 * anyString(), any(UUID.class), anyString());
		 */

	}

	@Test
	@DisplayName("Test processAllJob for insertToCorrespondence with valid data")
	void insertToCorrespondence_Success() throws InterruptedException, IOException, JobFailedException, ParseException {
		List<CorrespondenceData> correspondenceDataList = new ArrayList<>();
		UUID randomUuuid = UUID.randomUUID();
		int currentStatusIdFailed = 2;
		when(phoenixHelper.getEndTime()).thenReturn("NA");
		when(phoenixHelper.getStartTime()).thenReturn("NA");
		String mockFetchXml = "<fetch  version='1.0' mapping='logical' count='100' page='3'><entity name='audit'><attribute name='objecttypecode'/><attribute name='action'/><attribute name='createdon'/><attribute name='objectid'/><filter><condition attribute='objecttypecode' operator='eq' value='10383'/><condition attribute='action' operator='eq' value='3'/><condition attribute='createdon' operator='gt' value='2024-11-09T11:56:05.360143600Z'/></filter></entity></fetch>";
		String mockJsonResponse = "{\"value\": [{\"_objectid_value\": \"" + randomUuuid
				+ "\", \"createdon\": \"2025-01-02\"}]}";
		when(phoenixHelper.getFetchRecord()).thenReturn(batch);
		when(phoenixHelper.getFetchXML(Constants.CORREPONDENCE_ENTITY,  jobEndTime, lastupdatedDate,batch,pagingCookie,page)).thenReturn(mockFetchXml);
		HttpUrl mockHttpUrl = mockWebServer.url("/phoniex/correspondence?fetchXml=test");
		mockRequest = new Request.Builder().url(mockHttpUrl).build();
		when(phoenixHelper.getPhoenixRequestBuild(anyString())).thenReturn(mockRequest);
		when(iDeleteReconciliationDao.getCurrentStatusIPId()).thenReturn(2);
		when(iDeleteReconciliationDao.getJobID(Constants.DATASOURCE_NAME)).thenReturn(4);
		when(iDeleteReconciliationDao.getIncrementalDataLoadAuditId(anyInt(), anyString(), anyString(),
				eq(Constants.DATASOURCE_NAME))).thenReturn(UUID.randomUUID());
		when(iDeleteReconciliationDao.getCurrentStatusCId(Constants.DATASOURCE_NAME, Constants.STATUS_READY_TO_PROCESS))
				.thenReturn(15);
		when(iDeleteReconciliationDao.getCountFailedJobsInLast7Days(DATASOURCE_NAME, lastSevenDayDate,
				currentStatusIdFailed)).thenReturn(total);
		when(dataResponse.getCorrespondenceData()).thenReturn(correspondenceDataList);
		MockResponse mockRes = new MockResponse().setBody(mockJsonResponse).addHeader("Content-Type",
				"application/json");
		mockWebServer.enqueue(mockRes);

		doNothing().when(deletePhnxReconciliationServiceImpl).insertToContact();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToAccount();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToCaseLink();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToCorrepondenceSource();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToEmail();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToIncident();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToLetter();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToCaseconsideration();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToOfferoutcome();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToPhone();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToPortal();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToTask();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToUser();

		/*
		 * deletePhnxReconciliationServiceImpl.processAllJob();
		 * 
		 * verify(iDeleteReconciliationDao, times(1)).getCurrentStatusIPId();
		 * verify(iDeleteReconciliationDao, times(1)).insertToIncrementalAudit(anyInt(),
		 * anyInt(), eq(Constants.DATASOURCE_NAME), anyString());
		 * verify(iDeleteReconciliationDao,
		 * times(1)).updateIncrementAuditJobQuery(anyLong(), anyInt(), anyInt(),
		 * anyString(), any(UUID.class), anyString());
		 */

	}

	@Test
	@DisplayName("Test processAllJob for insertToCorrespondence with no data")
	void insertToCorrespondence_noData() throws InterruptedException, ParseException, JobFailedException, IOException {
		List<CorrespondenceData> correspondenceDataList = new ArrayList<>();

		int currentStatusIdFailed = 2;
		when(phoenixHelper.getEndTime()).thenReturn("NA");
		when(phoenixHelper.getStartTime()).thenReturn("NA");
		String mockFetchXml = "<fetch  version='1.0' mapping='logical' count='100' page='3'><entity name='audit'><attribute name='objecttypecode'/><attribute name='action'/><attribute name='createdon'/><attribute name='objectid'/><filter><condition attribute='objecttypecode' operator='eq' value='10383'/><condition attribute='action' operator='eq' value='3'/><condition attribute='createdon' operator='gt' value='2024-11-09T11:56:05.360143600Z'/></filter></entity></fetch>";
		String mockJsonResponse = "{\"value\": []}";
		when(phoenixHelper.getFetchRecord()).thenReturn(batch);
		when(phoenixHelper.getFetchXML(Constants.CORREPONDENCE_ENTITY,  jobEndTime, lastupdatedDate,batch,pagingCookie,page)).thenReturn(mockFetchXml);
		HttpUrl mockHttpUrl = mockWebServer.url("/phoniex/correspondence?fetchXml=test");
		mockRequest = new Request.Builder().url(mockHttpUrl).build();
		when(phoenixHelper.getPhoenixRequestBuild(anyString())).thenReturn(mockRequest);
		when(iDeleteReconciliationDao.getCurrentStatusIPId()).thenReturn(2);
		when(iDeleteReconciliationDao.getJobID(Constants.DATASOURCE_NAME)).thenReturn(4);
		when(iDeleteReconciliationDao.getIncrementalDataLoadAuditId(anyInt(), anyString(), anyString(),
				eq(Constants.DATASOURCE_NAME))).thenReturn(UUID.randomUUID());
		when(iDeleteReconciliationDao.getCurrentStatusCId(Constants.DATASOURCE_NAME, Constants.STATUS_READY_TO_PROCESS))
				.thenReturn(15);
		when(iDeleteReconciliationDao.getCountFailedJobsInLast7Days(DATASOURCE_NAME, lastSevenDayDate,
				currentStatusIdFailed)).thenReturn(total);
		when(dataResponse.getCorrespondenceData()).thenReturn(correspondenceDataList);
		MockResponse mockRes = new MockResponse().setBody(mockJsonResponse).addHeader("Content-Type",
				"application/json");
		mockWebServer.enqueue(mockRes);

		doNothing().when(deletePhnxReconciliationServiceImpl).insertToContact();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToAccount();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToCaseLink();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToCorrepondenceSource();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToEmail();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToIncident();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToLetter();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToCaseconsideration();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToOfferoutcome();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToPhone();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToPortal();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToTask();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToUser();

		/*
		 * deletePhnxReconciliationServiceImpl.processAllJob();
		 * 
		 * verify(iDeleteReconciliationDao, times(1)).getCurrentStatusIPId();
		 * verify(iDeleteReconciliationDao, times(1)).insertToIncrementalAudit(anyInt(),
		 * anyInt(), eq(Constants.DATASOURCE_NAME), anyString());
		 * verify(iDeleteReconciliationDao,
		 * times(1)).updateIncrementAuditJobQuery(anyLong(), anyInt(), anyInt(),
		 * anyString(), any(UUID.class), anyString());
		 */
	}
	@Test
	@DisplayName("Test processAllJob for insertToDigitalMessage with valid data")
	void insertToDigitalMessage_Success() throws InterruptedException, IOException, JobFailedException, ParseException {
		List<DigitalMessageData> digitalMessageDataList = new ArrayList<>();
		UUID randomUuuid = UUID.randomUUID();
		int currentStatusIdFailed = 2;
		when(phoenixHelper.getEndTime()).thenReturn("NA");
		when(phoenixHelper.getStartTime()).thenReturn("NA");
		String mockFetchXml = "<fetch  version='1.0' mapping='logical' count='100' page='3'><entity name='audit'><attribute name='objecttypecode'/><attribute name='action'/><attribute name='createdon'/><attribute name='objectid'/><filter><condition attribute='objecttypecode' operator='eq' value='10383'/><condition attribute='action' operator='eq' value='3'/><condition attribute='createdon' operator='gt' value='2024-11-09T11:56:05.360143600Z'/></filter></entity></fetch>";
		String mockJsonResponse = "{\"value\": [{\"_objectid_value\": \"" + randomUuuid
				+ "\", \"createdon\": \"2025-01-02\"}]}";
		when(phoenixHelper.getFetchRecord()).thenReturn(batch);
		when(phoenixHelper.getFetchXML(Constants.DIGITALMESSAGE_ENTITY,  jobEndTime, lastupdatedDate,batch,pagingCookie,page)).thenReturn(mockFetchXml);
		HttpUrl mockHttpUrl = mockWebServer.url("/phoniex/digitalmessage?fetchXml=test");
		mockRequest = new Request.Builder().url(mockHttpUrl).build();
		when(phoenixHelper.getPhoenixRequestBuild(anyString())).thenReturn(mockRequest);
		when(iDeleteReconciliationDao.getCurrentStatusIPId()).thenReturn(2);
		when(iDeleteReconciliationDao.getJobID(Constants.DATASOURCE_NAME)).thenReturn(4);
		when(iDeleteReconciliationDao.getIncrementalDataLoadAuditId(anyInt(), anyString(), anyString(),
				eq(Constants.DATASOURCE_NAME))).thenReturn(UUID.randomUUID());
		when(iDeleteReconciliationDao.getCurrentStatusCId(Constants.DATASOURCE_NAME, Constants.STATUS_READY_TO_PROCESS))
				.thenReturn(15);
		when(iDeleteReconciliationDao.getCountFailedJobsInLast7Days(DATASOURCE_NAME, lastSevenDayDate,
				currentStatusIdFailed)).thenReturn(total);
		when(dataResponse.getDigitalMessageData()).thenReturn(digitalMessageDataList);
		MockResponse mockRes = new MockResponse().setBody(mockJsonResponse).addHeader("Content-Type",
				"application/json");
		mockWebServer.enqueue(mockRes);

		doNothing().when(deletePhnxReconciliationServiceImpl).insertToContact();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToAccount();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToCaseLink();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToCorrepondenceSource();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToEmail();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToIncident();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToLetter();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToCaseconsideration();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToOfferoutcome();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToPhone();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToPortal();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToTask();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToCorrespondence();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToUser();

		/*
		 * deletePhnxReconciliationServiceImpl.processAllJob();
		 * 
		 * verify(iDeleteReconciliationDao, times(1)).getCurrentStatusIPId();
		 * verify(iDeleteReconciliationDao, times(1)).insertToIncrementalAudit(anyInt(),
		 * anyInt(), eq(Constants.DATASOURCE_NAME), anyString());
		 * verify(iDeleteReconciliationDao,
		 * times(1)).updateIncrementAuditJobQuery(anyLong(), anyInt(), anyInt(),
		 * anyString(), any(UUID.class), anyString());
		 */

	}

	@Test
	@DisplayName("Test processAllJob for insertToDigitalMessage with no data")
	void insertToDigitalMessage_noData() throws InterruptedException, ParseException, JobFailedException, IOException {
		List<DigitalMessageData> digitalMessageDataList = new ArrayList<>();

		int currentStatusIdFailed = 2;
		when(phoenixHelper.getEndTime()).thenReturn("NA");
		when(phoenixHelper.getStartTime()).thenReturn("NA");
		String mockFetchXml = "<fetch  version='1.0' mapping='logical' count='100' page='3'><entity name='audit'><attribute name='objecttypecode'/><attribute name='action'/><attribute name='createdon'/><attribute name='objectid'/><filter><condition attribute='objecttypecode' operator='eq' value='10383'/><condition attribute='action' operator='eq' value='3'/><condition attribute='createdon' operator='gt' value='2024-11-09T11:56:05.360143600Z'/></filter></entity></fetch>";
		String mockJsonResponse = "{\"value\": []}";
		when(phoenixHelper.getFetchRecord()).thenReturn(batch);
		when(phoenixHelper.getFetchXML(Constants.DIGITALMESSAGE_ENTITY,  jobEndTime, lastupdatedDate,batch,pagingCookie,page)).thenReturn(mockFetchXml);
		HttpUrl mockHttpUrl = mockWebServer.url("/phoniex/digitalmessage?fetchXml=test");
		mockRequest = new Request.Builder().url(mockHttpUrl).build();
		when(phoenixHelper.getPhoenixRequestBuild(anyString())).thenReturn(mockRequest);
		when(iDeleteReconciliationDao.getCurrentStatusIPId()).thenReturn(2);
		when(iDeleteReconciliationDao.getJobID(Constants.DATASOURCE_NAME)).thenReturn(4);
		when(iDeleteReconciliationDao.getIncrementalDataLoadAuditId(anyInt(), anyString(), anyString(),
				eq(Constants.DATASOURCE_NAME))).thenReturn(UUID.randomUUID());
		when(iDeleteReconciliationDao.getCurrentStatusCId(Constants.DATASOURCE_NAME, Constants.STATUS_READY_TO_PROCESS))
				.thenReturn(15);
		when(iDeleteReconciliationDao.getCountFailedJobsInLast7Days(DATASOURCE_NAME, lastSevenDayDate,
				currentStatusIdFailed)).thenReturn(total);
		when(dataResponse.getDigitalMessageData()).thenReturn(digitalMessageDataList);
		MockResponse mockRes = new MockResponse().setBody(mockJsonResponse).addHeader("Content-Type",
				"application/json");
		mockWebServer.enqueue(mockRes);

		doNothing().when(deletePhnxReconciliationServiceImpl).insertToContact();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToAccount();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToCaseLink();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToCorrepondenceSource();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToEmail();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToIncident();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToLetter();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToCaseconsideration();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToOfferoutcome();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToPhone();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToPortal();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToTask();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToCorrespondence();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToUser();

		/*
		 * deletePhnxReconciliationServiceImpl.processAllJob();
		 * 
		 * verify(iDeleteReconciliationDao, times(1)).getCurrentStatusIPId();
		 * verify(iDeleteReconciliationDao, times(1)).insertToIncrementalAudit(anyInt(),
		 * anyInt(), eq(Constants.DATASOURCE_NAME), anyString());
		 * verify(iDeleteReconciliationDao,
		 * times(1)).updateIncrementAuditJobQuery(anyLong(), anyInt(), anyInt(),
		 * anyString(), any(UUID.class), anyString());
		 */
	}
	
	@Test
	@DisplayName("Test processAllJob for insertToCustomerAddress with valid data")
	void insertToCustomerAddress_Success() throws InterruptedException, IOException, JobFailedException, ParseException {
		List<CustomeraddressData> customeraddressDataList = new ArrayList<>();
		UUID randomUuuid = UUID.randomUUID();
		int currentStatusIdFailed = 2;
		when(phoenixHelper.getEndTime()).thenReturn("NA");
		when(phoenixHelper.getStartTime()).thenReturn("NA");
		String mockFetchXml = "<fetch  version='1.0' mapping='logical' count='100' page='3'><entity name='audit'><attribute name='objecttypecode'/><attribute name='action'/><attribute name='createdon'/><attribute name='objectid'/><filter><condition attribute='objecttypecode' operator='eq' value='10383'/><condition attribute='action' operator='eq' value='3'/><condition attribute='createdon' operator='gt' value='2024-11-09T11:56:05.360143600Z'/></filter></entity></fetch>";
		String mockJsonResponse = "{\"value\": [{\"_objectid_value\": \"" + randomUuuid
				+ "\", \"createdon\": \"2025-01-02\"}]}";
		when(phoenixHelper.getFetchRecord()).thenReturn(batch);
		when(phoenixHelper.getFetchXML(Constants.CUSTOMERADDRESS_ENTITY,  jobEndTime, lastupdatedDate,batch,pagingCookie,page)).thenReturn(mockFetchXml);
		HttpUrl mockHttpUrl = mockWebServer.url("/phoniex/customeraddress?fetchXml=test");
		mockRequest = new Request.Builder().url(mockHttpUrl).build();
		when(phoenixHelper.getPhoenixRequestBuild(anyString())).thenReturn(mockRequest);
		when(iDeleteReconciliationDao.getCurrentStatusIPId()).thenReturn(2);
		when(iDeleteReconciliationDao.getJobID(Constants.DATASOURCE_NAME)).thenReturn(4);
		when(iDeleteReconciliationDao.getIncrementalDataLoadAuditId(anyInt(), anyString(), anyString(),
				eq(Constants.DATASOURCE_NAME))).thenReturn(UUID.randomUUID());
		when(iDeleteReconciliationDao.getCurrentStatusCId(Constants.DATASOURCE_NAME, Constants.STATUS_READY_TO_PROCESS))
				.thenReturn(15);
		when(iDeleteReconciliationDao.getCountFailedJobsInLast7Days(DATASOURCE_NAME, lastSevenDayDate,
				currentStatusIdFailed)).thenReturn(total);
		when(dataResponse.getCustomeraddressData()).thenReturn(customeraddressDataList);
		MockResponse mockRes = new MockResponse().setBody(mockJsonResponse).addHeader("Content-Type",
				"application/json");
		mockWebServer.enqueue(mockRes);

		doNothing().when(deletePhnxReconciliationServiceImpl).insertToContact();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToAccount();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToCaseLink();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToCorrepondenceSource();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToEmail();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToIncident();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToLetter();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToCaseconsideration();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToOfferoutcome();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToPhone();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToPortal();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToTask();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToCorrespondence();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToUser();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToDigitalMessage();

		/*
		 * deletePhnxReconciliationServiceImpl.processAllJob();
		 * 
		 * verify(iDeleteReconciliationDao, times(1)).getCurrentStatusIPId();
		 * verify(iDeleteReconciliationDao, times(1)).insertToIncrementalAudit(anyInt(),
		 * anyInt(), eq(Constants.DATASOURCE_NAME), anyString());
		 * verify(iDeleteReconciliationDao,
		 * times(1)).updateIncrementAuditJobQuery(anyLong(), anyInt(), anyInt(),
		 * anyString(), any(UUID.class), anyString());
		 */

	}

	@Test
	@DisplayName("Test processAllJob for insertToCustomerAddress with no data")
	void insertToCustomerAddress_noData() throws InterruptedException, ParseException, JobFailedException, IOException {
		List<CustomeraddressData> customeraddressDataList = new ArrayList<>();

		int currentStatusIdFailed = 2;
		when(phoenixHelper.getEndTime()).thenReturn("NA");
		when(phoenixHelper.getStartTime()).thenReturn("NA");
		String mockFetchXml = "<fetch  version='1.0' mapping='logical' count='100' page='3'><entity name='audit'><attribute name='objecttypecode'/><attribute name='action'/><attribute name='createdon'/><attribute name='objectid'/><filter><condition attribute='objecttypecode' operator='eq' value='10383'/><condition attribute='action' operator='eq' value='3'/><condition attribute='createdon' operator='gt' value='2024-11-09T11:56:05.360143600Z'/></filter></entity></fetch>";
		String mockJsonResponse = "{\"value\": []}";
		when(phoenixHelper.getFetchRecord()).thenReturn(batch);
		when(phoenixHelper.getFetchXML(Constants.CUSTOMERADDRESS_ENTITY,  jobEndTime, lastupdatedDate,batch,pagingCookie,page)).thenReturn(mockFetchXml);
		HttpUrl mockHttpUrl = mockWebServer.url("/phoniex/customeraddress?fetchXml=test");
		mockRequest = new Request.Builder().url(mockHttpUrl).build();
		when(phoenixHelper.getPhoenixRequestBuild(anyString())).thenReturn(mockRequest);
		when(iDeleteReconciliationDao.getCurrentStatusIPId()).thenReturn(2);
		when(iDeleteReconciliationDao.getJobID(Constants.DATASOURCE_NAME)).thenReturn(4);
		when(iDeleteReconciliationDao.getIncrementalDataLoadAuditId(anyInt(), anyString(), anyString(),
				eq(Constants.DATASOURCE_NAME))).thenReturn(UUID.randomUUID());
		when(iDeleteReconciliationDao.getCurrentStatusCId(Constants.DATASOURCE_NAME, Constants.STATUS_READY_TO_PROCESS))
				.thenReturn(15);
		when(iDeleteReconciliationDao.getCountFailedJobsInLast7Days(DATASOURCE_NAME, lastSevenDayDate,
				currentStatusIdFailed)).thenReturn(total);
		when(dataResponse.getCustomeraddressData()).thenReturn(customeraddressDataList);
		MockResponse mockRes = new MockResponse().setBody(mockJsonResponse).addHeader("Content-Type",
				"application/json");
		mockWebServer.enqueue(mockRes);

		doNothing().when(deletePhnxReconciliationServiceImpl).insertToContact();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToAccount();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToCaseLink();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToCorrepondenceSource();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToEmail();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToIncident();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToLetter();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToCaseconsideration();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToOfferoutcome();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToPhone();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToPortal();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToTask();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToCorrespondence();
		doNothing().when(deletePhnxReconciliationServiceImpl).insertToDigitalMessage();

		/*
		 * deletePhnxReconciliationServiceImpl.processAllJob();
		 * 
		 * verify(iDeleteReconciliationDao, times(1)).getCurrentStatusIPId();
		 * verify(iDeleteReconciliationDao, times(1)).insertToIncrementalAudit(anyInt(),
		 * anyInt(), eq(Constants.DATASOURCE_NAME), anyString());
		 * verify(iDeleteReconciliationDao,
		 * times(1)).updateIncrementAuditJobQuery(anyLong(), anyInt(), anyInt(),
		 * anyString(), any(UUID.class), anyString());
		 */

	}
	
	
	
	@Test

	@DisplayName("Test successful fetching of Caselink records from PhoenixCall")
	void fetchRecordsFromPhnx_Success() throws InterruptedException, IOException {
		int batchsize = 100;
		String startJob = "2025-01-02";
		String lastupdatedDate = "2025-01-03";
		String pagingCookie = null;
		int page = 1;
		boolean moreRecords = false;
		
		when(phoenixHelper.getFetchRecord()).thenReturn(batchsize);
		when(phoenixHelper.getEndTime()).thenReturn("NA");
		when(phoenixHelper.getStartTime()).thenReturn("NA");
		UUID randomUuuid = UUID.randomUUID();
		DataResponse newdataRes = new DataResponse();
		String mockFetchXml = "<fetch  version='1.0' mapping='logical' count='100' page='3'><entity name='audit'><attribute name='objecttypecode'/><attribute name='action'/><attribute name='createdon'/><attribute name='objectid'/><filter><condition attribute='objecttypecode' operator='eq' value='10383'/><condition attribute='action' operator='eq' value='3'/><condition attribute='createdon' operator='gt' value='2024-11-09T11:56:05.360143600Z'/></filter></entity></fetch>";
		String mockJsonResponse = "{\"value\": [{\"_objectid_value\": \"" + randomUuuid
				+ "\", \"createdon\": \"2025-01-01\"}]}";
		when(phoenixHelper.getFetchXML(anyString(), anyString(), anyString(),anyInt(), anyString(), anyInt())).thenReturn(mockFetchXml);
		when(phoenixHelper.getFetchXML(Constants.CASELINK_CODE, startJob, lastupdatedDate,150,  pagingCookie,
				page)).thenReturn(mockFetchXml);
		when(phoenixHelper.getPheonixHost()).thenReturn("");
		HttpUrl mockHttpUrl = mockWebServer.url("/phoniex/caselink?fetchXml=test");
		mockRequest = new Request.Builder().url(mockHttpUrl).build();
		when(phoenixHelper.getPhoenixRequestBuild(anyString())).thenReturn(mockRequest);

		MockResponse mockRes = new MockResponse().setBody(mockJsonResponse).addHeader("Content-Type",
				"application/json");
		mockWebServer.enqueue(mockRes);
		String startdate = deletePhnxReconciliationServiceImpl.fetchRecordsFromPhnx(Constants.CASELINK_ENTITY,
				Constants.CASELINK_CODE, startJob, lastupdatedDate, randomUuuid,batch, newdataRes,moreRecords,pagingCookie,page);
		//assertNotNull(startdate);

	}

	@Test

	@DisplayName("Test  fetching of Caselink records from PhoenixCall when no records are returned")
	void fetchRecordsFromPhnx_emptyResponse() throws InterruptedException, IOException {
		UUID randomUuuid = UUID.randomUUID();
		int batchsize = 100;
		String startJob = "2025-01-02";
		String lastupdatedDate = "2025-01-03";
		String startDate = null;
		DataResponse newdataRes = new DataResponse();
		when(phoenixHelper.getFetchRecord()).thenReturn(batchsize);
		when(phoenixHelper.getEndTime()).thenReturn("NA");
		when(phoenixHelper.getStartTime()).thenReturn("NA");
		String mockFetchXml = "<fetch  version='1.0' mapping='logical' count='100' page='3'><entity name='audit'><attribute name='objecttypecode'/><attribute name='action'/><attribute name='createdon'/><attribute name='objectid'/><filter><condition attribute='objecttypecode' operator='eq' value='10383'/><condition attribute='action' operator='eq' value='3'/><condition attribute='createdon' operator='gt' value='2024-11-09T11:56:05.360143600Z'/></filter></entity></fetch>";
		String mockJsonResponse = "{\"value\": []}";

		when(phoenixHelper.getFetchXML(anyString(), anyString(), anyString(), anyInt(),anyString(), anyInt())).thenReturn(mockFetchXml);
		when(phoenixHelper.getFetchXML(Constants.CASELINK_CODE, startJob, lastupdatedDate,150,pagingCookie,page)).thenReturn(mockFetchXml);
		when(phoenixHelper.getPheonixHost()).thenReturn("");
		HttpUrl mockHttpUrl = mockWebServer.url("/phoniex/caselink?fetchXml=test");
		mockRequest = new Request.Builder().url(mockHttpUrl).build();
		when(phoenixHelper.getPhoenixRequestBuild(anyString())).thenReturn(mockRequest);

		MockResponse mockRes = new MockResponse().setBody(mockJsonResponse).addHeader("Content-Type",
				"application/json");
		mockWebServer.enqueue(mockRes);
		String responseStartdate = deletePhnxReconciliationServiceImpl.fetchRecordsFromPhnx(Constants.CASELINK_ENTITY,
				Constants.CASELINK_CODE, startJob, lastupdatedDate, randomUuuid, batch,newdataRes,moreRecords,pagingCookie,page);

		assertNull(startDate, responseStartdate);
	}

	@Test
	@DisplayName("Test fetchRecordsFromPhnx - handling Exception ")
	void fetchRecordsFromPhnx_handleException() throws InterruptedException, IOException {
		String mockJsonResponse = "{\"read\": []}";
		UUID randomUuuid = UUID.randomUUID();
		int batchsize = 100;
		String startJob = "2025-01-02";
		String lastupdatedDate = "2025-01-03";
		DataResponse newdataRes = new DataResponse();
		when(phoenixHelper.getFetchRecord()).thenReturn(batchsize);
		when(phoenixHelper.getEndTime()).thenReturn("NA");
		when(phoenixHelper.getStartTime()).thenReturn("NA");
		when(phoenixHelper.getPheonixHost()).thenReturn("");
		HttpUrl mockHttpUrl = mockWebServer.url("/api/data/v9.2/audits?fetchxml=test");
		mockRequest = new Request.Builder().url(mockHttpUrl).build();
		when(phoenixHelper.getPhoenixRequestBuild(anyString())).thenReturn(mockRequest);

		mockWebServer.enqueue(new MockResponse().setResponseCode(500).setBody(mockJsonResponse));
		try {
			deletePhnxReconciliationServiceImpl.fetchRecordsFromPhnx(Constants.CASELINK_ENTITY, Constants.CASELINK_CODE,
					startJob, lastupdatedDate, randomUuuid, 150,newdataRes,moreRecords,pagingCookie,page);
		} catch (Exception e) {

			assertTrue(e.getMessage().contains("JSONObject"));

		}
		assertEquals("/api/data/v9.2/audits?fetchxml=test", mockWebServer.takeRequest().getPath());
	}

	@Test
	void testProcessAccountEntity() throws IOException, InterruptedException {
		// Prepare mock data
		JSONArray jsonArray = new JSONArray();
		JSONObject jsonObject = new JSONObject();
		jsonObject.put(Constants.OBJECTID_VALUE, UUID.randomUUID().toString());
		jsonObject.put(Constants.CREATED_ON, "2025-01-01T00:00:00Z");
		jsonArray.put(jsonObject);
		List<UUID> accountIds = new ArrayList<>();
		accountIds.add(UUID.randomUUID());

		// Mock the DAO methods
		when(iDeleteReconciliationDao.insertRecordAccount(anyList(), any(UUID.class))).thenReturn(accountIds);

		// Call the method under test
	 deletePhnxReconciliationServiceImpl.processAccountEntity(jsonArray, true, UUID.randomUUID(),
				dataResponse, "2025-01-01T00:00:00Z", mapper, 0);

		// Verify interactions and assert results
		verify(iDeleteReconciliationDao, times(1)).insertRecordAccount(anyList(), any(UUID.class));

		verify(dataResponse, times(1)).setAccountData(anyList());

		//assertNotNull(result);
		//assertEquals("2025-01-01T00:00:00Z", result);
	}

	@Test
	void testProcessIncidentEntity() throws IOException, InterruptedException {
		// Prepare mock data
		JSONArray jsonArray = new JSONArray();
		JSONObject jsonObject = new JSONObject();
		jsonObject.put(Constants.OBJECTID_VALUE, UUID.randomUUID().toString());
		jsonObject.put(Constants.CREATED_ON, "2025-01-01T00:00:00Z");
		jsonArray.put(jsonObject);
		List<IncidentData> incidentDataList = new ArrayList<>();
		incidentDataList.add(new IncidentData());

		// Call the method under test
		 deletePhnxReconciliationServiceImpl.processIncidentEntity(jsonArray, true,
				fetchIncrementalDataLoadAuditId, dataResponse, "2025-01-01T00:00:00Z", mapper, 0);

		// Verify interactions and assert results
		verify(iDeleteReconciliationDao, times(1)).insertRecordIncident(anyList(), any(UUID.class));
		verify(dataResponse, times(1)).setIncidentData(anyList());

	//	assertNotNull(result);
		//assertEquals("2025-01-01T00:00:00Z", result);
	}

	@Test
	void testProcessCaseLinkEntity() throws IOException, InterruptedException {
		// Prepare mock data
		JSONArray jsonArray = new JSONArray();
		JSONObject jsonObject = new JSONObject();
		jsonObject.put(Constants.OBJECTID_VALUE, UUID.randomUUID().toString());
		jsonObject.put(Constants.CREATED_ON, "2025-01-01T00:00:00Z");
		jsonArray.put(jsonObject);
		List<CaselinkData> caselinkDataList = new ArrayList<>();
		caselinkDataList.add(new CaselinkData());

		// Call the method under test
		 deletePhnxReconciliationServiceImpl.processCaseLinkEntity(jsonArray, true,
				fetchIncrementalDataLoadAuditId, dataResponse, "2025-01-01T00:00:00Z", mapper, 0);

		// Verify interactions and assert results
		verify(iDeleteReconciliationDao, times(1)).insertCaseLink(anyList(), any(UUID.class));
		verify(dataResponse, times(1)).setCaselinkData(anyList());

	//	assertNotNull(result);
	//	assertEquals("2025-01-01T00:00:00Z", result);
	}

	@Test
	void testProcessContactEntity() throws IOException, InterruptedException {
		// Prepare mock data
		JSONArray jsonArray = new JSONArray();
		JSONObject jsonObject = new JSONObject();
		jsonObject.put(Constants.OBJECTID_VALUE, UUID.randomUUID().toString());
		jsonObject.put(Constants.CREATED_ON, "2025-01-01T00:00:00Z");
		jsonArray.put(jsonObject);
		List<ContactData> contactDataList = new ArrayList<>();
		contactDataList.add(new ContactData());

		// Call the method under test
		deletePhnxReconciliationServiceImpl.processContactEntity(jsonArray, true,
				fetchIncrementalDataLoadAuditId, dataResponse, "2025-01-01T00:00:00Z", mapper, 0);

		// Verify interactions and assert results
		verify(iDeleteReconciliationDao, times(1)).insertRecordContact(anyList(), any(UUID.class));
		verify(dataResponse, times(1)).setContactData(anyList());

		//assertNotNull(result);
		//assertEquals("2025-01-01T00:00:00Z", result);
	}

	@Test
	void testProcessEmailEntity() throws IOException, InterruptedException {
		// Prepare mock data
		JSONArray jsonArray = new JSONArray();
		JSONObject jsonObject = new JSONObject();
		jsonObject.put(Constants.OBJECTID_VALUE, UUID.randomUUID().toString());
		jsonObject.put(Constants.CREATED_ON, "2025-01-01T00:00:00Z");
		jsonArray.put(jsonObject);
		List<EmailData> emailDataList = new ArrayList<>();
		emailDataList.add(new EmailData());

		// Call the method under test
		 deletePhnxReconciliationServiceImpl.processEmailEntity(jsonArray, true,
				fetchIncrementalDataLoadAuditId, dataResponse, "2025-01-01T00:00:00Z", mapper, 0);

		// Verify interactions and assert results
		verify(iDeleteReconciliationDao, times(1)).insertRecordEmail(anyList(), any(UUID.class));
		verify(dataResponse, times(1)).setEmailData(anyList());

		//assertNotNull(result);
		//assertEquals("2025-01-01T00:00:00Z", result);
	}

	@Test
	void testProcessCorrespondenceEntity() throws IOException, InterruptedException {
		// Prepare mock data
		JSONArray jsonArray = new JSONArray();
		JSONObject jsonObject = new JSONObject();
		jsonObject.put(Constants.OBJECTID_VALUE, UUID.randomUUID().toString());
		jsonObject.put(Constants.CREATED_ON, "2025-01-01T00:00:00Z");
		jsonArray.put(jsonObject);
		List<CorrespondenceData> correspondenceDataList = new ArrayList<>();
		correspondenceDataList.add(new CorrespondenceData());

		// Call the method under test
		 deletePhnxReconciliationServiceImpl.processCorrespondenceEntity(jsonArray, true,
				fetchIncrementalDataLoadAuditId, dataResponse, "2025-01-01T00:00:00Z", mapper, 0);

		// Verify interactions and assert results
		verify(iDeleteReconciliationDao, times(1)).insertRecordCorresponce(anyList(), any(UUID.class));
		verify(dataResponse, times(1)).setCorrespondenceData(anyList());

		//assertNotNull(result);
		//assertEquals("2025-01-01T00:00:00Z", result);

	}
	@Test
	void testprocessDigitalMessageEntity() throws IOException, InterruptedException {
		// Prepare mock data
		JSONArray jsonArray = new JSONArray();
		JSONObject jsonObject = new JSONObject();
		jsonObject.put(Constants.OBJECTID_VALUE, UUID.randomUUID().toString());
		jsonObject.put(Constants.CREATED_ON, "2025-01-01T00:00:00Z");
		jsonArray.put(jsonObject);
		List<DigitalMessageData> digitalMessageDataList = new ArrayList<>();
		digitalMessageDataList.add(new DigitalMessageData());

		// Call the method under test
		 deletePhnxReconciliationServiceImpl.processDigitalMessageEntity(jsonArray, true,
				fetchIncrementalDataLoadAuditId, dataResponse, "2025-01-01T00:00:00Z", mapper, 0);

		// Verify interactions and assert results
		verify(iDeleteReconciliationDao, times(1)).insertRecordDigitalMessageData(anyList(), any(UUID.class));
		verify(dataResponse, times(1)).setDigitalMessageData(anyList());

		//assertNotNull(result);
		//assertEquals("2025-01-01T00:00:00Z", result);

	}
	@Test
	void testprocessCustomeraddressEntity() throws IOException, InterruptedException {
		// Prepare mock data
		JSONArray jsonArray = new JSONArray();
		JSONObject jsonObject = new JSONObject();
		jsonObject.put(Constants.OBJECTID_VALUE, UUID.randomUUID().toString());
		jsonObject.put(Constants.CREATED_ON, "2025-01-01T00:00:00Z");
		jsonArray.put(jsonObject);
		List<CustomeraddressData> customeraddressDataList = new ArrayList<>();
		customeraddressDataList.add(new CustomeraddressData());

		// Call the method under test
		 deletePhnxReconciliationServiceImpl.processCustomeraddressEntity(jsonArray, true,
				fetchIncrementalDataLoadAuditId, dataResponse, "2025-01-01T00:00:00Z", mapper, 0);

		// Verify interactions and assert results
		verify(iDeleteReconciliationDao, times(1)).insertRecordCustomerAddressData(anyList(), any(UUID.class));
		verify(dataResponse, times(1)).setCustomeraddressData(anyList());

		//assertNotNull(result);
		//assertEquals("2025-01-01T00:00:00Z", result);

	}
	@Test
	void testProcessCorrespondenceSourceEntity() throws IOException, InterruptedException {
		// Prepare mock data
		JSONArray jsonArray = new JSONArray();
		JSONObject jsonObject = new JSONObject();
		jsonObject.put(Constants.OBJECTID_VALUE, UUID.randomUUID().toString());
		jsonObject.put(Constants.CREATED_ON, "2025-01-01T00:00:00Z");
		jsonArray.put(jsonObject);
		List<CorrespondenceSourceData> correspondenceSourceDataList = new ArrayList<>();
		correspondenceSourceDataList.add(new CorrespondenceSourceData());

		// Call the method under test

	 deletePhnxReconciliationServiceImpl.processCorrespondenceSourceEntity(jsonArray, true,
				fetchIncrementalDataLoadAuditId, dataResponse, "2025-01-01T00:00:00Z", mapper, 0);

		// Verify interactions and assert results
		verify(iDeleteReconciliationDao, times(1)).insertRecordcorrespondenceSource(anyList(), any(UUID.class));
		verify(dataResponse, times(1)).setCorrespondenceSourceData(anyList());

		//assertNotNull(result);
		//assertEquals("2025-01-01T00:00:00Z", result);
	}

	@Test
	void testProcessLetterEntity() throws IOException, InterruptedException {
		// Prepare mock data
		JSONArray jsonArray = new JSONArray();
		JSONObject jsonObject = new JSONObject();
		jsonObject.put(Constants.OBJECTID_VALUE, UUID.randomUUID().toString());
		jsonObject.put(Constants.CREATED_ON, "2025-01-01T00:00:00Z");
		jsonArray.put(jsonObject);
		List<LetterData> letterDataList = new ArrayList<>();
		letterDataList.add(new LetterData());

		// Call the method under test
		 deletePhnxReconciliationServiceImpl.processLetterEntity(jsonArray, true,
				fetchIncrementalDataLoadAuditId, dataResponse, "2025-01-01T00:00:00Z", mapper, 0);

		// Verify interactions and assert results
		verify(iDeleteReconciliationDao, times(1)).insertRecordLetter(anyList(), any(UUID.class));
		verify(dataResponse, times(1)).setLetterData(anyList());

		//assertNotNull(result);
		//assertEquals("2025-01-01T00:00:00Z", result);
	}

	@Test
	void testProcessUserEntity() throws IOException, InterruptedException {
		// Prepare mock data
		JSONArray jsonArray = new JSONArray();
		JSONObject jsonObject = new JSONObject();
		jsonObject.put(Constants.OBJECTID_VALUE, UUID.randomUUID().toString());
		jsonObject.put(Constants.CREATED_ON, "2025-01-01T00:00:00Z");
		jsonArray.put(jsonObject);
		List<UserData> userDataList = new ArrayList<>();
		userDataList.add(new UserData());

		// Call the method under test
		 deletePhnxReconciliationServiceImpl.processUserEntity(jsonArray, true,
				fetchIncrementalDataLoadAuditId, dataResponse, "2025-01-01T00:00:00Z", mapper, 0);

		// Verify interactions and assert results
		verify(iDeleteReconciliationDao, times(1)).insertRecordUser(anyList(), any(UUID.class));
		verify(dataResponse, times(1)).setUserData(anyList());

		//assertNotNull(result);
		//assertEquals("2025-01-01T00:00:00Z", result);
	}

	@Test
	void testProcessCaseconsiderationEntity() throws IOException, InterruptedException {
		// Prepare mock data
		JSONArray jsonArray = new JSONArray();
		JSONObject jsonObject = new JSONObject();
		jsonObject.put(Constants.OBJECTID_VALUE, UUID.randomUUID().toString());
		jsonObject.put(Constants.CREATED_ON, "2025-01-01T00:00:00Z");
		jsonArray.put(jsonObject);
		List<CaseconsiderationData> caseconsiderationDataList = new ArrayList<>();
		caseconsiderationDataList.add(new CaseconsiderationData());

		// Call the method under test
		deletePhnxReconciliationServiceImpl.processCaseconsiderationEntity(jsonArray, true,
				fetchIncrementalDataLoadAuditId, dataResponse, "2025-01-01T00:00:00Z", mapper, 0);

		// Verify interactions and assert results
		verify(iDeleteReconciliationDao, times(1)).insertRecordCaseconsideration(anyList(), any(UUID.class));
		verify(dataResponse, times(1)).setCaseconsiderationData(anyList());

		//assertNotNull(result);
		//assertEquals("2025-01-01T00:00:00Z", result);
	}

	@Test
	void testProcessPortalEntity() throws IOException, InterruptedException {
		// Prepare mock data
		JSONArray jsonArray = new JSONArray();
		JSONObject jsonObject = new JSONObject();
		jsonObject.put(Constants.OBJECTID_VALUE, UUID.randomUUID().toString());
		jsonObject.put(Constants.CREATED_ON, "2025-01-01T00:00:00Z");
		jsonArray.put(jsonObject);
		List<PortalData> portalDataList = new ArrayList<>();
		portalDataList.add(new PortalData());

		// Call the method under test
		 deletePhnxReconciliationServiceImpl.processPortalEntity(jsonArray, true,
				fetchIncrementalDataLoadAuditId, dataResponse, "2025-01-01T00:00:00Z", mapper, 0);

		// Verify interactions and assert results
		verify(iDeleteReconciliationDao, times(1)).insertRecordPortal(anyList(), any(UUID.class));
		verify(dataResponse, times(1)).setPortalData(anyList());

		//assertNotNull(result);
		//assertEquals("2025-01-01T00:00:00Z", result);
	}

	@Test
	void testProcessOfferoutcomeEntity() throws IOException, InterruptedException {
		// Prepare mock data
		JSONArray jsonArray = new JSONArray();
		JSONObject jsonObject = new JSONObject();
		jsonObject.put(Constants.OBJECTID_VALUE, UUID.randomUUID().toString());
		jsonObject.put(Constants.CREATED_ON, "2025-01-01T00:00:00Z");
		jsonArray.put(jsonObject);
		List<OfferoutcomeData> offeroutcomeDataList = new ArrayList<>();
		offeroutcomeDataList.add(new OfferoutcomeData());

		// Call the method under test
	 deletePhnxReconciliationServiceImpl.processOfferoutcomeEntity(jsonArray, true,
				fetchIncrementalDataLoadAuditId, dataResponse, "2025-01-01T00:00:00Z", mapper, 0);

		// Verify interactions and assert results
		verify(iDeleteReconciliationDao, times(1)).insertRecordOfferoutcome(anyList(), any(UUID.class));
		verify(dataResponse, times(1)).setOfferoutcomeData(anyList());

		//assertNotNull(result);
		//assertEquals("2025-01-01T00:00:00Z", result);
	}

	@Test
	void testProcessPhoneEntity() throws IOException, InterruptedException {
		// Prepare mock data
		JSONArray jsonArray = new JSONArray();
		JSONObject jsonObject = new JSONObject();
		jsonObject.put(Constants.OBJECTID_VALUE, UUID.randomUUID().toString());
		jsonObject.put(Constants.CREATED_ON, "2025-01-01T00:00:00Z");
		jsonArray.put(jsonObject);
		List<PhoneData> phoneDataList = new ArrayList<>();
		phoneDataList.add(new PhoneData());

		// Call the method under test
		deletePhnxReconciliationServiceImpl.processPhoneEntity(jsonArray, true,
				fetchIncrementalDataLoadAuditId, dataResponse, "2025-01-01T00:00:00Z", mapper, 0);

		// Verify interactions and assert results
		verify(iDeleteReconciliationDao, times(1)).insertRecordPhone(anyList(), any(UUID.class));
		verify(dataResponse, times(1)).setPhoneData(anyList());

	//	assertNotNull(result);
		//assertEquals("2025-01-01T00:00:00Z", result);
	}

	@Test
	void testProcessTaskEntity() throws IOException, InterruptedException {
		// Prepare mock data
		JSONArray jsonArray = new JSONArray();
		JSONObject jsonObject = new JSONObject();
		jsonObject.put(Constants.OBJECTID_VALUE, UUID.randomUUID().toString());
		jsonObject.put(Constants.CREATED_ON, "2025-01-01T00:00:00Z");
		jsonArray.put(jsonObject);
		List<TaskData> taskDataList = new ArrayList<>();
		taskDataList.add(new TaskData());

		// Call the method under test
		 deletePhnxReconciliationServiceImpl.processTaskEntity(jsonArray, true,
				fetchIncrementalDataLoadAuditId, dataResponse, "2025-01-01T00:00:00Z", mapper, 0);

		// Verify interactions and assert results
		verify(iDeleteReconciliationDao, times(1)).insertRecordTask(anyList(), any(UUID.class));
		verify(dataResponse, times(1)).setTaskData(anyList());

		//assertNotNull(result);
		//assertEquals("2025-01-01T00:00:00Z", result);
	}

	@Test
	void testHandleException() {
		// Prepare mock data
		Instant startWebJob = Instant.now();
		Exception exception = new Exception("Test Exception");
		Long totalCount = 10L;
		int failedCount = 0;
		// Mock the DAO method
		when(iDeleteReconciliationDao.getCurrentStatusCId(Constants.DATASOURCE_NAME, Constants.FAILED)).thenReturn(1);
		doNothing().when(iDeleteReconciliationDao).insertRecordIncrementalloadError(any(UUID.class), anyString(),
				anyInt(), anyString(), anyString(), anyString(), anyString());
		doNothing().when(iDeleteReconciliationDao).updateIncrementAuditJobQuery(anyLong(), anyInt(), anyInt(),
				anyString(), any(UUID.class), anyString());
		doNothing().when(sendMailNotification).sendErrorNotificationToUserWebclient(any(ErrorMessageTemplate.class));
		// Call the method under test
		deletePhnxReconciliationServiceImpl.handleException(startWebJob, exception, fetchIncrementalDataLoadAuditId,
				totalCount, Constants.DATASOURCE_NAME, failedCount);

		// Verify interactions and assert results
		verify(iDeleteReconciliationDao, times(1)).insertRecordIncrementalloadError(any(UUID.class), anyString(),
				anyInt(), anyString(), anyString(), anyString(), anyString());
		verify(iDeleteReconciliationDao, times(1)).updateIncrementAuditJobQuery(anyLong(), anyInt(), anyInt(),
				anyString(), any(UUID.class), anyString());
	}

}
