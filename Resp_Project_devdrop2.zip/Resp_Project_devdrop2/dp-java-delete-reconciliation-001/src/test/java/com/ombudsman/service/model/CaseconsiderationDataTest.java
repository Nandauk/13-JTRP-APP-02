package com.ombudsman.service.model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.UUID;

import org.junit.jupiter.api.Test;

import com.ombudsman.service.delete.reconciliation.model.CaseconsiderationData;

class CaseconsiderationDataTest {

    @Test
    void testGetSetFosCaseconsiderationId() {
        CaseconsiderationData caseconsiderationData = new CaseconsiderationData();
        UUID fosCaseconsiderationId = UUID.randomUUID();
        caseconsiderationData.setFosCaseconsiderationId(fosCaseconsiderationId);
        assertEquals(fosCaseconsiderationId, caseconsiderationData.getFosCaseconsiderationId());
    }

    @Test
    void testGetSetDeleteDatetime() {
        CaseconsiderationData caseconsiderationData = new CaseconsiderationData();
        String deleteDatetime = "2025-02-04T20:19:00Z";
        caseconsiderationData.setDeleteDatetime(deleteDatetime);
        assertEquals(deleteDatetime, caseconsiderationData.getDeleteDatetime());
    }

    @Test
    void testGetSetIncrementalDataLoadJobAuditId() {
        CaseconsiderationData caseconsiderationData = new CaseconsiderationData();
        UUID incrementalDataLoadJobAuditId = UUID.randomUUID();
        caseconsiderationData.setIncrementalDataLoadJobAuditId(incrementalDataLoadJobAuditId);
        assertEquals(incrementalDataLoadJobAuditId, caseconsiderationData.getIncrementalDataLoadJobAuditId());
    }

   
}