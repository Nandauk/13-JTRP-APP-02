package com.ombudsman.service.model;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.UUID;

import org.junit.jupiter.api.Test;

import com.ombudsman.service.delete.reconciliation.model.TaskData;

class TaskDataTest {

    @Test
    void testGetSetActivityid() {
        TaskData taskData = new TaskData();
        UUID activityid = UUID.randomUUID();
        taskData.setActivityid(activityid);
        assertEquals(activityid, taskData.getActivityid());
    }

    @Test
    void testGetSetDeleteDatetime() {
        TaskData taskData = new TaskData();
        String deleteDatetime = "2025-02-04T20:19:00Z";
        taskData.setDeleteDatetime(deleteDatetime);
        assertEquals(deleteDatetime, taskData.getDeleteDatetime());
    }

    @Test
    void testGetSetIncrementalDataLoadJobAuditId() {
        TaskData taskData = new TaskData();
        UUID incrementalDataLoadJobAuditId = UUID.randomUUID();
        taskData.setIncrementalDataLoadJobAuditId(incrementalDataLoadJobAuditId);
        assertEquals(incrementalDataLoadJobAuditId, taskData.getIncrementalDataLoadJobAuditId());
    }

  
}
