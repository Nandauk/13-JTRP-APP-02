package com.ombudsman.service.model;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ombudsman.service.delete.reconciliation.model.MailjetResponseBody;

class MailjetResponseBodyTest {

	@Test
    @DisplayName("Test get and set Messages")
    void testGetAndSetMessages() {
        // Given
        MailjetResponseBody responseBody = new MailjetResponseBody();
        List<MailjetResponseBody.Message> messages = new ArrayList<>();
        MailjetResponseBody.Message message = new MailjetResponseBody.Message();
        message.setStatus("success");
        messages.add(message);

        // When
        responseBody.setMessages(messages);

        // Then
        assertEquals(messages, responseBody.getMessages());
    }

    @Test
    @DisplayName("Test Message toString")
    void testMessageToString() {
        // Given
        MailjetResponseBody.Message message = new MailjetResponseBody.Message();
        message.setStatus("success");
        message.setCustomID("123");
        List<MailjetResponseBody.Recipient> recipients = new ArrayList<>();
        MailjetResponseBody.Recipient recipient = new MailjetResponseBody.Recipient();
        recipient.setEmail("test@example.com");
        recipients.add(recipient);
        message.setTo(recipients);

        // When
        String messageString = message.toString();

        // Then
        assertTrue(messageString.contains("success"));
        assertTrue(messageString.contains("123"));
        assertTrue(messageString.contains("test@example.com"));
    }

    @Test
    @DisplayName("Test Recipient toString")
    void testRecipientToString() {
        // Given
        MailjetResponseBody.Recipient recipient = new MailjetResponseBody.Recipient();
        recipient.setEmail("test@example.com");
        recipient.setMessageUUID("uuid-123");
        recipient.setMessageID(12345L);
        recipient.setMessageHref("http://example.com");

        // When
        String recipientString = recipient.toString();

        // Then
        assertTrue(recipientString.contains("test@example.com"));
        assertTrue(recipientString.contains("uuid-123"));
        assertTrue(recipientString.contains("12345"));
        assertTrue(recipientString.contains("http://example.com"));
    }

    @Test
    @DisplayName("Test JSON serialization and deserialization")
    void testJsonSerializationDeserialization() throws JsonProcessingException {
        // Given
        ObjectMapper objectMapper = new ObjectMapper();
        MailjetResponseBody responseBody = new MailjetResponseBody();
        List<MailjetResponseBody.Message> messages = new ArrayList<>();
        MailjetResponseBody.Message message = new MailjetResponseBody.Message();
        message.setStatus("success");
        message.setCustomID("123");
        List<MailjetResponseBody.Recipient> recipients = new ArrayList<>();
        MailjetResponseBody.Recipient recipient = new MailjetResponseBody.Recipient();
        recipient.setEmail("test@example.com");
        recipient.setMessageUUID("uuid-123");
        recipient.setMessageID(12345L);
        recipient.setMessageHref("http://example.com");
        recipients.add(recipient);
        message.setTo(recipients);
        messages.add(message);
        responseBody.setMessages(messages);

        // When
        String json = objectMapper.writeValueAsString(responseBody);
        MailjetResponseBody deserializedResponseBody = objectMapper.readValue(json, MailjetResponseBody.class);

        // Then
        assertNotNull(deserializedResponseBody);
        assertEquals(responseBody.getMessages().size(), deserializedResponseBody.getMessages().size());
        assertEquals(responseBody.getMessages().get(0).getStatus(), deserializedResponseBody.getMessages().get(0).getStatus());
        assertEquals(responseBody.getMessages().get(0).getCustomID(), deserializedResponseBody.getMessages().get(0).getCustomID());
        assertEquals(responseBody.getMessages().get(0).getTo().get(0).getEmail(), deserializedResponseBody.getMessages().get(0).getTo().get(0).getEmail());
    }
    

        @Test
        @DisplayName("Test MailjetResponseBody toString method")
        void testMailjetResponseBodyToString() {
            // Given
            MailjetResponseBody responseBody = new MailjetResponseBody();
            List<MailjetResponseBody.Message> messages = new ArrayList<>();
            MailjetResponseBody.Message message = new MailjetResponseBody.Message();
            message.setStatus("success");
            messages.add(message);
            responseBody.setMessages(messages);

            // Expected output
            String expectedString = "Message :" + messages;

            // When
            String actualString = responseBody.toString();

            // Then
            assertEquals(expectedString, actualString);
        }
}