package com.ombudsman.service.model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.UUID;

import org.junit.jupiter.api.Test;

import com.ombudsman.service.delete.reconciliation.model.CorrespondenceData;

class CorrespondenceDataTest {

    @Test
    void testGetSetFosCorrespondenceId() {
        CorrespondenceData correspondenceData = new CorrespondenceData();
        UUID fosCorrespondenceId = UUID.randomUUID();
        correspondenceData.setFosCorespondenceId(fosCorrespondenceId);
        assertEquals(fosCorrespondenceId, correspondenceData.getFosCorespondenceId());
    }

    @Test
    void testGetSetDeleteDatetime() {
        CorrespondenceData correspondenceData = new CorrespondenceData();
        String deleteDatetime = "2025-02-04T20:19:00Z";
        correspondenceData.setDeleteDatetime(deleteDatetime);
        assertEquals(deleteDatetime, correspondenceData.getDeleteDatetime());
    }

    @Test
    void testGetSetIncrementalDataLoadJobAuditId() {
        CorrespondenceData correspondenceData = new CorrespondenceData();
        UUID incrementalDataLoadJobAuditId = UUID.randomUUID();
        correspondenceData.setIncrementalDataLoadJobAuditId(incrementalDataLoadJobAuditId);
        assertEquals(incrementalDataLoadJobAuditId, correspondenceData.getIncrementalDataLoadJobAuditId());
    }

   
}