package com.ombudsman.service.model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.UUID;

import org.junit.jupiter.api.Test;

import com.ombudsman.service.delete.reconciliation.model.PortalData;

class PortalDataTest {

    @Test
    void testGetSetActivityid() {
        PortalData portalData = new PortalData();
        UUID activityid = UUID.randomUUID();
        portalData.setActivityid(activityid);
        assertEquals(activityid, portalData.getActivityid());
    }

    @Test
    void testGetSetDeleteDatetime() {
        PortalData portalData = new PortalData();
        String deleteDatetime = "2025-02-04T20:19:00Z";
        portalData.setDeleteDatetime(deleteDatetime);
        assertEquals(deleteDatetime, portalData.getDeleteDatetime());
    }

    @Test
    void testGetSetIncrementalDataLoadJobAuditId() {
        PortalData portalData = new PortalData();
        UUID incrementalDataLoadJobAuditId = UUID.randomUUID();
        portalData.setIncrementalDataLoadJobAuditId(incrementalDataLoadJobAuditId);
        assertEquals(incrementalDataLoadJobAuditId, portalData.getIncrementalDataLoadJobAuditId());
    }

    
}