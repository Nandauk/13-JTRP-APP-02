package com.ombudsman.service.model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.UUID;

import org.junit.jupiter.api.Test;

import com.ombudsman.service.delete.reconciliation.model.OfferoutcomeData;

class OfferoutcomeDataTest {

    @Test
    void testGetSetFosOfferoutcomeId() {
        OfferoutcomeData offeroutcomeData = new OfferoutcomeData();
        UUID fosOfferoutcomeId = UUID.randomUUID();
        offeroutcomeData.setFosOfferoutcomeId(fosOfferoutcomeId);
        assertEquals(fosOfferoutcomeId, offeroutcomeData.getFosOfferoutcomeId());
    }

    @Test
    void testGetSetDeleteDatetime() {
        OfferoutcomeData offeroutcomeData = new OfferoutcomeData();
        String deleteDatetime = "2025-02-04T20:19:00Z";
        offeroutcomeData.setDeleteDatetime(deleteDatetime);
        assertEquals(deleteDatetime, offeroutcomeData.getDeleteDatetime());
    }

    @Test
    void testGetSetIncrementalDataLoadJobAuditId() {
        OfferoutcomeData offeroutcomeData = new OfferoutcomeData();
        UUID incrementalDataLoadJobAuditId = UUID.randomUUID();
        offeroutcomeData.setIncrementalDataLoadJobAuditId(incrementalDataLoadJobAuditId);
        assertEquals(incrementalDataLoadJobAuditId, offeroutcomeData.getIncrementalDataLoadJobAuditId());
    }

   }