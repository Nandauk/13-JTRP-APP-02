#! /bin/bash
if [ -z "$1" ]; then
  echo "Usage: $0 [dv2|prf|prf-dr]"
  exit 1
fi

stage="$1"
#ENVIRONMENT="$stage"

#Set subscription ID based on environment
if [ "$stage" = "dv2" ]; then 
  echo "deploying to dv2 environment"
  SUBSCRIPTION_ID="b70424dd-d53a-40a3-98a4-0cf1f27c11f0"
  ENVIRON=dev2
  ENVIRONMENT=dv2
  OFFBOARD_SERVICE_BUS_QUALIFIED_NAME="sb-dp-app-int-uks-${ENVIRONMENT}-001.servicebus.windows.net" 
  
elif [ "$stage" = "prf" ]; then
  echo "deploying to prf environment"
  SUBSCRIPTION_ID="07285016-701b-4617-9557-1cedc46548fb"
  ENVIRON=prf
  ENVIRONMENT=prf
  OFFBOARD_SERVICE_BUS_QUALIFIED_NAME="sb-dp-app-int-uks-${ENVIRONMENT}-001.servicebus.windows.net" 

elif [ "$stage" = "prf-dr" ]; then
  echo "deploying to prf-dr environment"
  SUBSCRIPTION_ID="07285016-701b-4617-9557-1cedc46548fb"
  ENVIRON=prf 
  ENVIRONMENT=prf 
  OFFBOARD_SERVICE_BUS_QUALIFIED_NAME="sb-dp-app-int-ukw-${ENVIRONMENT}-001.servicebus.windows.net"
else
   echo "Invalid environment. Use 'dv2' or 'prf'."
   exit 1
fi     

# Convert ENVIRONMENT to uppercase
ENVIRONMENT_UPPER=$(echo "$ENVIRONMENT" | tr '[:lower:]' '[:upper:]')

#Set the subscription
az account set --subscription "$SUBSCRIPTION_ID"

#Define Variables
REC_SPN_NAME="SPN-APP-FUNCAPP-INCR-UPDATE-${ENVIRONMENT}"

# Generate ConfigMap YAML
cat <<EOF > dp-api-delete-recon-${stage}-configmap.yaml
apiVersion: v1
kind: ConfigMap
metadata:
  name: dp-java-delete-reconciliation-nonprod-configmap
  namespace: var_namespace_respondent
data:
  SERVER_PORT: '8443'
  SQL_DRIVER: com.microsoft.sqlserver.jdbc.SQLServerDriver
  APIM_HOST: apim-${ENVIRON}.financial-ombudsman.org.uk
  SQL_CONNECT_TIMEOUT: '10000'
  SQL_READ_TIMEOUT: '5000'
  START_TIME: NA
  END_TIME: NA
  RUN_FLAG: 'ON'
  OFFBOARD_SERVICE_BUS_QUALIFIED_NAME: ${OFFBOARD_SERVICE_BUS_QUALIFIED_NAME}
  OFFBOARD_QUEUE_NAME: queue-dp-int-offboard-${ENVIRONMENT}
  SB_TENANTID: 3df253a5-1a74-47e7-a5e0-204525367f22
  SB_INT_CLIENTID: $(az ad sp list --display-name $REC_SPN_NAME --query "[0].appId" --output tsv)
  ENV: ${ENVIRONMENT_UPPER}
  FETCH_RECORD: '4000'
  CORN_JOB_TIME: 0 */15 * * * *
  TEMPLATE_ID: '6646610'
  TO_EMAIL: parbati.debnath@financial-ombudsman.org.uk
  MAILJET_URL: https://apim-${ENVIRON}.financial-ombudsman.org.uk/mailjet/send
  CONNECTION_TIMEOUT: '10'
  READ_TIMEOUT: '10'
EOF

echo "ConfigMap YAML generated: dp-api-delete-recon-${stage}-configmap.yaml"