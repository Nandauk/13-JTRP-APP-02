package com.ombudsman.service.organization.common;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.microsoft.applicationinsights.TelemetryClient;
import com.microsoft.applicationinsights.telemetry.MetricTelemetry;

import lombok.extern.slf4j.Slf4j;

@Component
@Service
@Slf4j
public class AuditProcessor {

	
	
	public void logEvent(String type)  {

		Map<String, String> auditTrace = new HashMap<>();

		TelemetryClient telemetryClient = new TelemetryClient();
		telemetryClient.getContext();
		MetricTelemetry benchmark = new MetricTelemetry();

		benchmark.setName("EventAction");

		auditTrace.put("EventType", type);
		/*
		 * auditTrace.put("oid", userbean.getUserObjectId());
		 * auditTrace.put("coRelationid", userbean.getCorrelationId());
		 * auditTrace.put("email", userbean.getEmail());
		 * 
		 * telemetryClient.trackEvent("EventAction", auditTrace, null);
		 */


	}


	/*
	 * public void addOpertionlDataLoadAudit(AuditEvent dataLoadAudit) {
	 * 
	 * var dataLoad = this.modelMapper.map(dataLoadAudit, AuditEvent.class);
	 * 
	 * onboardDataProcessDao.saveDataLoadAudit(dataLoad);
	 * 
	 * }
	 */

}
