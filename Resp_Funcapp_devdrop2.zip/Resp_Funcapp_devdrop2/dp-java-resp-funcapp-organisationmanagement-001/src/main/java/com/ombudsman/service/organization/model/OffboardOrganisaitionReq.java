package com.ombudsman.service.organization.model;

public class OffboardOrganisaitionReq {

	private String accountId;
	private String type;
	private String requestId;
	private String emailId;
	private String templateId;
	private String name;
	private String userEmailId;

	public String getName() {
		return name;
	}

	public void setName(final String name) {
		this.name = name;
	}

	public String getUserEmailId() {
		return userEmailId;
	}

	public void setUserEmailId(final String userEmailId) {
		this.userEmailId = userEmailId;
	}

	public String getAccountId() {
		return accountId;
	}

	public void setAccountId(final String accountId) {
		this.accountId = accountId;
	}

	public String getType() {
		return type;
	}

	public void setType(final String type) {
		this.type = type;
	}

	public String getRequestId() {
		return requestId;
	}

	public void setRequestId(final String requestId) {
		this.requestId = requestId;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(final String emailId) {
		this.emailId = emailId;
	}

	public String getTemplateId() {
		return templateId;
	}

	public void setTemplateId(final String templateId) {
		this.templateId = templateId;
	}

}
