package com.ombudsman.service.organization.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

import com.ombudsman.service.organization.model.Account;
import com.ombudsman.service.organization.model.OnboardMessage;
import com.ombudsman.service.organization.repository.OrganizationRepository;

public class OrganizationOnboardDataAccess {

	OrganizationRepository repository=new OrganizationRepository();  
  
	/*
	 * public OrganizationOnboardDataAccess() {
	 * 
	 * }
	 */

	public Optional<String> checkOrgPresentInAccount(String accId,OnboardMessage onboardMessage,JdbcTemplate jdbcTemplate) {

		return repository.getAccountId(accId,onboardMessage,jdbcTemplate);

	}
	public Optional<String> checkOrgPresentInADGroup(String accountId, JdbcTemplate jdbcTemplate) {
		Optional<String> res ;
		res = repository.checkADAccount(accountId, jdbcTemplate);
		return res;
	}
	public String checkOrgIsOrphan(String accId,  JdbcTemplate jdbcTemplate) {

		return repository.checkOrgIsOrphan(accId, jdbcTemplate);
		
	}
	public List<Account> getChildAccount(String accId,JdbcTemplate jdbcTemplate ) {

		return repository.getChildAccount(accId, jdbcTemplate);

	}
	
	


	public Optional<String> isParentPresentInAD(String parentAccId, JdbcTemplate jdbcTemplate) {

		return repository.checkParentPresentInAD(parentAccId, jdbcTemplate);

	}

	public Optional<String> checkOrgIsParent(String accId, JdbcTemplate jdbcTemplate) {

		return repository.checkOrganisationIsParent(accId, jdbcTemplate);

	}
	public List<Account> getParentAcc(String accId, NamedParameterJdbcTemplate namedJdbcTemplate){
		return repository.getParentAcc(accId, namedJdbcTemplate);		
		
	}
	public List<Account> checkIfAccoutIdIsParent(String accId, JdbcTemplate templateConnection){
		return repository.checkIfAccoutIdIsParent(accId, templateConnection);		
		
	}
	public List<Account> getAllAccounts(Account groups,  NamedParameterJdbcTemplate namedJdbcTemplate) {
		 
		return repository.getOrganisations(groups.getAccountId(), namedJdbcTemplate);

	}
	public Optional<String> getParentOfChildFromAccount(String accId,  JdbcTemplate jdbcTemplate) {
		return repository.getParentOfChild(accId, jdbcTemplate);
		
	}
	
	public String getParentAccountIdIfPresent(String accId,  JdbcTemplate jdbcTemplate) {
		return repository.getParentAccountIdIfPresent(accId, jdbcTemplate);
		
	}
	public Optional<String> checkIfParentAccountPresentInAdGroup(String accId,  JdbcTemplate jdbcTemplate) {
		return repository.checkIfParentAccountPresentInAdGroup(accId, jdbcTemplate);
		
	}
	public List<Account> getCompleteFamlyAccountId(String accId,  JdbcTemplate jdbcTemplate) {
		return repository.getCompleteFamlyAccountId(accId, jdbcTemplate);
		
	}
	public String getOidOfParentAccount(String accId,  JdbcTemplate jdbcTemplate) {
		return repository.getOidOfParentAccount(accId, jdbcTemplate);
		
	}
	
	
	
	
	
	
	


}
