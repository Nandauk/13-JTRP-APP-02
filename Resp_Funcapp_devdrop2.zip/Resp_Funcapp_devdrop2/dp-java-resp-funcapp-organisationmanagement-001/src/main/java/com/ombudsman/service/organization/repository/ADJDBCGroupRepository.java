package com.ombudsman.service.organization.repository;

import java.time.Instant;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.simple.SimpleJdbcInsert;

import com.ombudsman.service.organization.model.ADGroup;

public class ADJDBCGroupRepository {

	Logger logger = LogManager.getRootLogger();

	public void saveAdGroupDetails(ADGroup adGroup, JdbcTemplate jdbcConnection, String emailId) {

		SimpleJdbcInsert simpleJdbcInsert = new SimpleJdbcInsert(jdbcConnection).withTableName("dp_respondent_groups")
				.usingGeneratedKeyColumns("respondent_group_id");
		Map<String, Object> parameters = new HashMap<>();
		logger.info(String.format("attributes for group details  %s", adGroup.getPnxGroupId()));
		
	
		
		// parameters.put("id", adGroup.getId());
		parameters.put("group_name", adGroup.getAdGroupName());
		parameters.put("ad_group_id", adGroup.getAdGroupId());
		parameters.put("pnx_group_id", adGroup.getPnxGroupId());
		parameters.put("status", adGroup.getStatus());
		parameters.put("domain", adGroup.getDomain());
		parameters.put("type", adGroup.getType());
		parameters.put("created_on", LocalDate.now());
		parameters.put("created_by", emailId);
		simpleJdbcInsert.execute(parameters);

	}

	public Optional<String> checkParentPresentInDigitalPortal(String accountid, JdbcTemplate templateConnection) {
		logger.info("method::checkParentPresentInDigitalPortal accountid {}", accountid);
		String sql = "SELECT 1 FROM dp_respondent_groups where pnx_group_id=?";
		try {
			return Optional.of(templateConnection.queryForObject(sql, String.class, accountid));
		} catch (Exception e) {
			logger.error("exception accessing data::{}", e.getMessage());
			return Optional.empty();
		}

	}
}