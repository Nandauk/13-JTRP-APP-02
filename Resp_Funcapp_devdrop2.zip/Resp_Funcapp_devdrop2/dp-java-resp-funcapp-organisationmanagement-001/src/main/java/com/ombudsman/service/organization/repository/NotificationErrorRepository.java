package com.ombudsman.service.organization.repository;

import java.util.HashMap;
import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.simple.SimpleJdbcInsert;

import com.ombudsman.service.organization.model.OrganizationError;

public class NotificationErrorRepository {

	Logger logger = LogManager.getRootLogger();	
	public void saveAdGroupDetails(OrganizationError error,JdbcTemplate  templateConnection) {		

		SimpleJdbcInsert simpleJdbcInsert = new SimpleJdbcInsert(templateConnection).withTableName("dp_org_error")
				.usingGeneratedKeyColumns("org_error_id");
		Map<String, Object> parameters = new HashMap<>();		
		parameters.put("request_id", error.getRequestId());
		parameters.put("details", error.getDetails());
		parameters.put("action", error.getAction());
		parameters.put("group_id", error.getGroupId());
		parameters.put("remarks", error.getRemarks());
		
		simpleJdbcInsert.execute(parameters);

	}

}