package com.ombudsman.service.organization.repository;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.jdbc.core.JdbcTemplate;

import com.ombudsman.service.organization.model.Notification;



public class NotificationUpdateRepository {
	Logger logger = LogManager.getRootLogger();	

	
	public void notificationUpdateCall(Notification notification, JdbcTemplate jdbcConnection) {
		logger.info("notificationJdbcCall method started ");

		try {

			Object[] paramNotification = new Object[] { notification.getFileDownloadUrl(), notification.getModifiedOn(),
					notification.getNotificationStatusId(), notification.getNotificationStatusDescription(),
					notification.getRequestId() };
			logger.info("paramNotification {}", paramNotification);

			String sql = "update dp_user_notification set file_download_url= ?,modified_on= ?,notification_status_id= ?,notification_status_description= ? where request_id= ?";
			logger.info("sql : {}", sql);

			jdbcConnection.update(sql, paramNotification);
			logger.info("Notification data updated in Database : {}", jdbcConnection);

		} catch (Exception e) {
			logger.error("Error in notification {}", e.getMessage());
				}
		logger.info("notificationJdbcCall method Ended ");
	}
	

}
