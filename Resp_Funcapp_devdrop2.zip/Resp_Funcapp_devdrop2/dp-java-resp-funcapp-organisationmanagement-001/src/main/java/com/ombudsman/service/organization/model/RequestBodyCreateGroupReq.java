package com.ombudsman.service.organization.model;

public class RequestBodyCreateGroupReq {

	private String accountid;
	private String domainList;

	public String getAccountid() {
		return accountid;
	}

	public void setAccountid(String accountid) {
		this.accountid = accountid;
	}

	public String getDomainList() {
		return domainList;
	}

	public void setDomainList(String domainList) {
		this.domainList = domainList;
	}
	
	
}
