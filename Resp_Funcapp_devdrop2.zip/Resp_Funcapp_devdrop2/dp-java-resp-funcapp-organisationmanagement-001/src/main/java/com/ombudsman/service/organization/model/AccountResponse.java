package com.ombudsman.service.organization.model;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class AccountResponse implements RowMapper<Account> {

	private String accountId;
	private String fosFcareference;
	private String parentAccountId;
	private String name;
	private Long accountCategoryCode;
	private String fosHierarchylevelname;
	private String accountNumber;
	
	
		
	public AccountResponse() {
		// TODO Auto-generated constructor stub
	}


	@Override
	public Account mapRow(ResultSet rs, int rowNum) throws SQLException {
		return new Account(
	            rs.getString("accountid"),
	            rs.getString("fos_fcareference"),
	            rs.getString("parentaccountid"),
	            rs.getString("name"),
	            rs.getLong("accountcategorycode"),
	            rs.getString("fos_hierarchylevelname"),
	            rs.getString("accountnumber")
	    );
	}
	
	
}
