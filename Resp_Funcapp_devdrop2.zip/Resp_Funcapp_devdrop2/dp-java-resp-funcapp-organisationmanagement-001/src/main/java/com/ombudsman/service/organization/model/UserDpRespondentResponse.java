package com.ombudsman.service.organization.model;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.UUID;

import org.springframework.jdbc.core.RowMapper;

/**
 * @author pravichandran
 *
 */
public class UserDpRespondentResponse implements RowMapper<UserDpRespondent> {

	private UUID oid;
	private String fullname;
	private String firstname;
	private String lastname;
	private String email;
	private String usertype;
	private String invitedstatus;
	private String pnxflag;
	private UUID pnxuuid;
	private String useradstatus;
	private String invitedby;
	private String portal;
	private Integer onboardingorganisationid;
	private LocalDateTime createdon;
	private LocalDateTime lastupdated;

	public UserDpRespondentResponse() {
		// TODO Auto-generated constructor stub
	}

	public UUID getOid() {
		return oid;
	}

	public void setOid(UUID oid) {
		this.oid = oid;
	}

	public String getFullname() {
		return fullname;
	}

	public void setFullname(String fullname) {
		this.fullname = fullname;
	}

	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getUsertype() {
		return usertype;
	}

	public void setUsertype(String usertype) {
		this.usertype = usertype;
	}

	public String getInvitedstatus() {
		return invitedstatus;
	}

	public void setInvitedstatus(String invitedstatus) {
		this.invitedstatus = invitedstatus;
	}

	public String getPnxflag() {
		return pnxflag;
	}

	public void setPnxflag(String pnxflag) {
		this.pnxflag = pnxflag;
	}

	public UUID getPnxuuid() {
		return pnxuuid;
	}

	public void setPnxuuid(UUID pnxuuid) {
		this.pnxuuid = pnxuuid;
	}

	public String getUseradstatus() {
		return useradstatus;
	}

	public void setUseradstatus(String useradstatus) {
		this.useradstatus = useradstatus;
	}

	public String getInvitedby() {
		return invitedby;
	}

	public void setInvitedby(String invitedby) {
		this.invitedby = invitedby;
	}

	public String getPortal() {
		return portal;
	}

	public void setPortal(String portal) {
		this.portal = portal;
	}

	public Integer getOnboardingorganisationid() {
		return onboardingorganisationid;
	}

	public void setOnboardingorganisationid(Integer onboardingorganisationid) {
		this.onboardingorganisationid = onboardingorganisationid;
	}

	public LocalDateTime getCreatedon() {
		return createdon;
	}

	public void setCreatedon(LocalDateTime createdon) {
		this.createdon = createdon;
	}

	public LocalDateTime getLastupdated() {
		return lastupdated;
	}

	public void setLastupdated(LocalDateTime lastupdated) {
		this.lastupdated = lastupdated;
	}

	@Override
	public UserDpRespondent mapRow(ResultSet rs, int rowNum) throws SQLException {
		// TODO Auto-generated method stub
		return new UserDpRespondent(rs.getObject("oid", java.util.UUID.class));
	}

}
