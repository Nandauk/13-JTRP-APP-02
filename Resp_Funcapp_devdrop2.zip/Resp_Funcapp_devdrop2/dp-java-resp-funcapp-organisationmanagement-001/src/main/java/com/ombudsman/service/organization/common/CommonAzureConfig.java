package com.ombudsman.service.organization.common;

import org.springframework.context.annotation.Configuration;

@Configuration
public class CommonAzureConfig {
	
}
