package com.ombudsman.service.organization.model;


import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

/**
 * @author pravichandran
 *
 */
public class ADGroupResponse implements RowMapper<ADGroup> {

	private Integer id;
	private String adGroupName;
	private String adGroupId;
	private String pnxGroupId;
	private String status;
	private String domain;
	private String type;
	
		
	public ADGroupResponse() {
		// TODO Auto-generated constructor stub
	}

	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getAdGroupName() {
		return adGroupName;
	}
	public void setAdGroupName(String adGroupName) {
		this.adGroupName = adGroupName;
	}
	public String getAdGroupId() {
		return adGroupId;
	}
	public void setAdGroupId(String adGroupId) {
		this.adGroupId = adGroupId;
	}
	public String getPnxGroupId() {
		return pnxGroupId;
	}
	public void setPnxGroupId(String pnxGroupId) {
		this.pnxGroupId = pnxGroupId;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getDomain() {
		return domain;
	}
	public void setDomain(String domain) {
		this.domain = domain;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}

	@Override
	public ADGroup mapRow(ResultSet rs, int rowNum) throws SQLException {
		// TODO Auto-generated method stub
		return new ADGroup(
	            rs.getInt("id"),
	            rs.getString("ad_group_name"),
	            rs.getString("ad_group_id")	            						            
	    );
	}
	
	
}

