package com.ombudsman.service.organization.dao;

import java.time.Instant;

import org.springframework.jdbc.core.JdbcTemplate;

import com.ombudsman.service.organization.model.Notification;
import com.ombudsman.service.organization.repository.NotificationUpdateRepository;

public class NotificationDataUpdate {
	NotificationUpdateRepository notificationUpdateRepository=new NotificationUpdateRepository();
	
	public void updateNotificationData(String  message, String reqId, String notificationDesc, String statusId,JdbcTemplate jdbcTemplate) {
		Notification notification = new Notification();		
		notification.setMessage(message);
		notification.setModifiedOn(Instant.now().toString());
		notification.setRequestId(reqId);
		notification.setNotificationStatusId(statusId);//5 if failed
		notification.setNotificationStatusDescription(notificationDesc);//Failure
		notification.setRequestingActivityName("onboard_organisation");		
		notificationUpdateRepository.notificationUpdateCall(notification,jdbcTemplate);
		
	}
	


}
