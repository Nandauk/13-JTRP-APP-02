package com.ombudsman.service.organization.model;

public class Notification {

	public Notification() {
		super();
	}

	private Long notification_id;

	private String requestId; // notnull

	private String userOid; // notnull

	private String requestingActivityName; // notnull

	private String notificationStatusId; // notnull

	private String notificationStatusDescription; // notnull

	private String message;

	private String fileDownloadUrl;

	private String createdBy; // notnull

	private String modifiedOn;

	private String modifiedBy;

	public Notification(long notification_id, String requestId, String userOid, String requestingActivityName,
			String notificationStatusId, String notificationStatusDescription, String message, String fileDownloadUrl,
			String createdBy, String modifiedOn, String modifiedBy) {

		this.notification_id = notification_id;
		this.requestId = requestId;
		this.userOid = userOid;
		this.requestingActivityName = requestingActivityName;
		this.notificationStatusId = notificationStatusId;
		this.notificationStatusDescription = notificationStatusDescription;
		this.message = message;
		this.fileDownloadUrl = fileDownloadUrl;
		this.createdBy = createdBy;
		this.modifiedOn = modifiedOn;
		this.modifiedBy = modifiedBy;
	}

	public Long getNotification_id() {
		return notification_id;
	}

	public void setNotification_id(Long notification_id) {
		this.notification_id = notification_id;
	}

	public String getRequestId() {
		return requestId;
	}

	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}

	public String getUserOid() {
		return userOid;
	}

	public void setUserOid(String userOid) {
		this.userOid = userOid;
	}

	public String getRequestingActivityName() {
		return requestingActivityName;
	}

	public void setRequestingActivityName(String requestingActivityName) {
		this.requestingActivityName = requestingActivityName;
	}

	public String getNotificationStatusId() {
		return notificationStatusId;
	}

	public void setNotificationStatusId(String notificationStatusId) {
		this.notificationStatusId = notificationStatusId;
	}

	public String getNotificationStatusDescription() {
		return notificationStatusDescription;
	}

	public void setNotificationStatusDescription(String notificationStatusDescription) {
		this.notificationStatusDescription = notificationStatusDescription;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getFileDownloadUrl() {
		return fileDownloadUrl;
	}

	public void setFileDownloadUrl(String fileDownloadUrl) {
		this.fileDownloadUrl = fileDownloadUrl;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getModifiedOn() {
		return modifiedOn;
	}

	public void setModifiedOn(String modifiedOn) {
		this.modifiedOn = modifiedOn;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
}
