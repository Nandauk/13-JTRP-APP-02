package com.ombudsman.service.organization.repository;

import java.util.List;
import java.util.Optional;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;

import com.google.common.collect.Lists;
import com.ombudsman.service.organization.model.Account;
import com.ombudsman.service.organization.model.AccountResponse;
import com.ombudsman.service.organization.model.OnboardMessage;
import com.ombudsman.service.organization.model.OrganizationError;



public class OrganizationRepository {
	
	private static final String FAILED_FROM_ONNBOARDING = "Failed from Onboarding";
	private final Logger logger = LogManager.getRootLogger();	
	private final NotificationErrorRepository orgErrorRepo=new NotificationErrorRepository();
	private final OrganizationError errorDto= new OrganizationError();

	public Optional<String> getAccountId( String accountid, final OnboardMessage onboardMessage, JdbcTemplate templateConnection) {
		//accountid="c8994d7b-8c45-eb11-a812-000d3a0ca7c2";
		logger.info("getAccountId {}", accountid);
		String sql = "SELECT 1 FROM account where accountid=?";			
		try {
			return Optional.of(templateConnection.queryForObject(sql, String.class, accountid));
		} catch (Exception e) {
			logger.info("exception accessing data::{}", e.getMessage());
			errorDto.setDetails(FAILED_FROM_ONNBOARDING);
			errorDto.setRequestId(onboardMessage.getRequestId());
			errorDto.setRemarks("Query execution failure");
			errorDto.setGroupId(accountid);
			orgErrorRepo.saveAdGroupDetails(errorDto, templateConnection);
			return Optional.empty();
		}

	}
	public Optional<String> checkADAccount(String accountid,JdbcTemplate templateConnection) {
		logger.info("method::checkADAccount accountid {}", accountid);
		//accountid="AB87A7E2-7847-4048-AC25-00194A98C560";
		String sql = "SELECT 1 FROM dp_respondent_groups where pnx_group_id=?";
		try {
			return Optional.of(templateConnection.queryForObject(sql, String.class, accountid));
		} catch (Exception e) {
			logger.info("exception accessing data::{}", e.getMessage());
			
			return Optional.empty();
		}
		

	}
	public Optional<String> checkOrganisationIsParent( String accountid, JdbcTemplate templateConnection) {
		logger.info("method::checkOrganisationIsParent accountid {}", accountid);
		//accountid="AB87A7E2-7847-4048-AC25-00194A98C568";
		String sql = "select 1 from account where accountid=?  and fos_hierarchylevel=1";
		try {
			return Optional.of(templateConnection.queryForObject(sql, String.class, accountid));
		} catch (Exception e) {
			logger.info("exception accessing data::{}", e.getMessage());
			return Optional.empty();
		}
		

	}
	
	public List<Account> getAllChildOrganisation( String accountid, JdbcTemplate templateConnection) {
		logger.info("method::checkOrganisationIsParent accountid {}", accountid);
		
		String sql = "SELECT * FROM account where parentaccountid=? and fos_hierarchylevel='2'";
		try {
			return templateConnection.queryForObject(sql, List.class, accountid);
		} catch (Exception e) {
			logger.info("exception accessing data::{}", e.getMessage());
			return Lists.newArrayList();
		}	

	}
	public Optional<String> getParentOfChild(final String accountid,JdbcTemplate templateConnection) {
		logger.info("accountid {}", accountid);
		String sql = "SELECT parentaccountid FROM account where accountid=?";
		try {
		return Optional.ofNullable(templateConnection.queryForObject(sql, String.class, accountid));
		} catch (Exception e) {
			logger.info("exception accessing data::{}", e.getMessage());
			return Optional.empty();
		}

	}
	public Optional<Account> getParentAccountDetails(final String accountid,JdbcTemplate templateConnection) {
		logger.info("accountid {}", accountid);
		String sql = "SELECT parentaccountid FROM account where accountid=?";
		try {
		return Optional.of(templateConnection.queryForObject(sql, Account.class, accountid));
		} catch (Exception e) {
			logger.info("exception accessing data::{}", e.getMessage());
			return Optional.empty();
		}

	}
	public List<Account> checkIfAccoutIdIsParent(final String accountid,JdbcTemplate templateConnection) {
		logger.info("checkIfAccoutIdIsParent {}", accountid);
		String sql = "SELECT * FROM account where parentaccountid=?";
		try {
			return templateConnection.query(sql, new AccountResponse(),
					accountid);
		
		} catch (Exception e) {
			logger.info("exception accessing data::{}", e.getMessage());
			return Lists.newArrayList();
		}

	}
	public List<Account> getChildAccount(final String accountid, JdbcTemplate templateConnection) {
		logger.info("accountid {}", accountid);
		try {
		String sql = "SELECT * FROM account where accountid=?";
		return templateConnection.query(sql, new AccountResponse(),
				accountid);
		
	} catch (Exception e) {
		logger.info("exception accessing data::{}", e.getMessage());
		return Lists.newArrayList();
	}

	}

	public List<Account> getOrganisations(String accountid, NamedParameterJdbcTemplate  namedJdbcTemplate) {
		logger.info("accountid {}", accountid);
		//accountid="C97FD2E6-09E0-4A2E-B214-B9540C36EC2E";
		String sql = "SELECT * FROM account where parentaccountid =:accountid";
		final SqlParameterSource parameters = new MapSqlParameterSource("accountid", accountid);
		return namedJdbcTemplate.query(sql, parameters, (rs, rowNum) -> new Account(rs.getString("name"),
				rs.getString("parentaccountid"), rs.getString("fos_fcareference"), rs.getString("accountid"), rs.getString("accountnumber")));

	}

	public List<Account> getParentAcc(final String accountid,NamedParameterJdbcTemplate  namedJdbcTemplate) {
		logger.info("method::getParentAcc accountid {}", accountid);
		String sql = "SELECT * FROM account where accountid =:accountid";
		final SqlParameterSource parameters = new MapSqlParameterSource("accountid", accountid);
		return namedJdbcTemplate.query(sql, parameters, (rs, rowNum) -> new Account(rs.getString("name"),
				rs.getString("parentaccountid"), rs.getString("fos_fcareference"), rs.getString("accountid"),rs.getString("accountnumber")));

	}
	public Optional<String> checkParentPresentInAD(final String accountid,  JdbcTemplate templateConnection) {
		logger.info("method::checkParentPresentInAD accountid {}", accountid);
		String sql = "SELECT 1 FROM dp_respondent_groups where pnx_group_id=?";
		try {
		return Optional.of(templateConnection.queryForObject(sql, String.class, accountid));
		} catch (Exception e) {
			logger.info("exception accessing data::{}", e.getMessage());
			return Optional.empty();
		}

	}

	public String checkOrgIsOrphan(final String accountid,  JdbcTemplate templateConnection) {
		logger.info("method::checkOrgIsOrphan accountid {}", accountid);
		String sql = "select accountid from account where parentaccountid is null and fos_hierarchylevel is not null and accountid=?";
		try {
			return templateConnection.queryForObject(sql, String.class, accountid);
		} catch (Exception e) {
			logger.info("exception accessing data::{}", e.getMessage());
			return null;
		}

	}
	
	public String getOidOfParentAccount(final String accountid,  JdbcTemplate templateConnection) {
		logger.info("method::getOidOfParentAccount accountid {}", accountid);
		String sql = "select ad_group_id from dp_respondent_groups where pnx_group_id=?";
		try {
			return templateConnection.queryForObject(sql, String.class, accountid);
		} catch (Exception e) {
			logger.info("exception accessing data for getOidOfParentAccount::{}", e.getMessage());
			return null;
		}

	}
	
	public String getParentAccountIdIfPresent(final String accountid,  JdbcTemplate templateConnection) {
		logger.info("method::getParentAccountIdIfPresent accountid {}", accountid);
		String sql = "select parentaccountid from account where accountid=?";
		try {
			return templateConnection.queryForObject(sql, String.class, accountid);
		} catch (Exception e) {
			logger.info("exception accessing data for getParentAccountIdIfPresent::{}", e.getMessage());
			return null;
		}

	}
	public Optional<String> checkIfParentAccountPresentInAdGroup(final String accountid,  JdbcTemplate templateConnection) {
		logger.info("method::checkIfParentAccountPresentInAdGroup accountid {}", accountid);		
		try {
			return checkADAccount(accountid, templateConnection);
		} catch (Exception e) {
			logger.info("exception accessing data for checkIfParentAccountPresentInAdGroup::{}", e.getMessage());
			return Optional.empty();
		}

	}


	@SuppressWarnings("unchecked")
	public List<Account> getCompleteFamlyAccountId(final String accountid, JdbcTemplate templateConnection) {
		logger.info("getCompleteFamlyAccountId {}", accountid);
		String sql = "SELECT * FROM account where parentaccountid=?";
		try {
			return templateConnection.query(sql, new AccountResponse(),
					accountid);
			
		} catch (Exception e) {
			logger.info("exception accessing data::{}", e.getMessage());
			return Lists.newArrayList();
		}

	}
	
}
