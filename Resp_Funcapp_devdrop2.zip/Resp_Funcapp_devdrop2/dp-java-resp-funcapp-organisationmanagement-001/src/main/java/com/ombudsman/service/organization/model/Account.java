package com.ombudsman.service.organization.model;

public class Account {

	public Account(String name, String parentAccountId, String fosFcareference,

			String accountId,String accountNumber) {

		super();		
		this.name = name;
		this.parentAccountId = parentAccountId;
		this.fosFcareference = fosFcareference;
		this.accountId = accountId;
		this.accountNumber = accountNumber;
	}
	public Account(String accountId, String fosFcareference, String parentAccountId, String name, long accountCategoryCode, String fosHierarchylevelname,String accountNumber) {
		
		this.accountId = accountId;
		this.fosFcareference = fosFcareference;
		this.parentAccountId = parentAccountId;
		this.name = name;
		this.accountCategoryCode = accountCategoryCode;
		this.fosHierarchylevelname = fosHierarchylevelname;
		this.accountNumber = accountNumber;
		
	}

	public Account() {
		// TODO Auto-generated constructor stub
	}

	public String getFosHierarchylevelname() {
		return fosHierarchylevelname;
	}
	public void setFosHierarchylevelname(String fosHierarchylevelname) {
		this.fosHierarchylevelname = fosHierarchylevelname;
	}

	private Long accountCategoryCode;

	private String name;
	private String accountNumber;
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	private String fosHierarchylevelname;

	

	private String parentAccountId;

	private String fosFcareference;

	private String accountId;

	public Long getAccountCategoryCode() {
		return accountCategoryCode;
	}

	public void setAccountCategoryCode(Long accountCategoryCode) {
		this.accountCategoryCode = accountCategoryCode;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getParentAccountId() {
		return parentAccountId;
	}

	public void setParentAccountId(String parentAccountId) {
		this.parentAccountId = parentAccountId;
	}

	public String getFosFcareference() {
		return fosFcareference;
	}

	public void setFosFcareference(String fosFcareference) {
		this.fosFcareference = fosFcareference;
	}

	public String getAccountId() {
		return accountId;
	}

	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}

}
