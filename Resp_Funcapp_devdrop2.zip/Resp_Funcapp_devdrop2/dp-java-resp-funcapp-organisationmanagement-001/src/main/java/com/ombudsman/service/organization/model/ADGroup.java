package com.ombudsman.service.organization.model;

public class ADGroup {
	public ADGroup(int id, String adGroupName, String adGroupId) {
		this.id = id;
		this.adGroupName = adGroupName;
		this.adGroupId = adGroupId;
	}

	private Integer id;

	public ADGroup() {
		super();
	}

	private String adGroupName;

	private String adGroupId;

	private String pnxGroupId;

	private String status;

	private String domain;

	private String type;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getAdGroupName() {
		return adGroupName;
	}

	public void setAdGroupName(String adGroupName) {
		this.adGroupName = adGroupName;
	}

	public String getAdGroupId() {
		return adGroupId;
	}

	public void setAdGroupId(String adGroupId) {
		this.adGroupId = adGroupId;
	}

	public String getPnxGroupId() {
		return pnxGroupId;
	}

	public void setPnxGroupId(String pnxGroupId) {
		this.pnxGroupId = pnxGroupId;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getDomain() {
		return domain;
	}

	public void setDomain(String domain) {
		this.domain = domain;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

}
