package com.ombudsman.service.repondent.model;

public class SystemUserData {

	    private String systemuserid;
	    private String ownerid;

	    // Getters and setters
	    public String getSystemuserid() {
	        return systemuserid;
	    }

	    public void setSystemuserid(String systemuserid) {
	        this.systemuserid = systemuserid;
	    }

	    public String getOwnerid() {
	        return ownerid;
	    }

	    public void setOwnerid(String ownerid) {
	        this.ownerid = ownerid;
	    }

	    @Override
	    public String toString() {
	        return "User{" +
	                "systemuserid='" + systemuserid + '\'' +
	                ", ownerid='" + ownerid + '\'' +
	                '}';
	    }
}


