package com.ombudsman.service.respondent.serviceimpl;
 
 
public class IncidentInfoImpl  {
	public  String incidentId;
    public IncidentInfoImpl(String incidentId, String ticketNumber) {
		super();
		this.incidentId = incidentId;
		this.ticketNumber = ticketNumber;
	}
	public  String ticketNumber;
	public String getIncidentId() {
		return incidentId;
	}
	public void setIncidentId(String incidentId) {
		this.incidentId = incidentId;
	}
	public String getTicketNumber() {
		return ticketNumber;
	}
	public void setTicketNumber(String ticketNumber) {
		this.ticketNumber = ticketNumber;
	}
}
 