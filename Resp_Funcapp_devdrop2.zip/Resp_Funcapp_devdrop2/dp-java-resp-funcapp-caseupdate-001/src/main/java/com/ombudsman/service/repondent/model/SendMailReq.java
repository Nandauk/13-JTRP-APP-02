package com.ombudsman.service.repondent.model;


	import java.util.List;

import com.google.gson.annotations.SerializedName;

	   
	public class SendMailReq {

	   @SerializedName("Messages")
	   private List<Messages> messages;


	    public void setMessages(List<Messages> messages) {
	        this.messages = messages;
	    }
	    public List<Messages> getMessages() {
	        return messages;
	    }
	    
	}