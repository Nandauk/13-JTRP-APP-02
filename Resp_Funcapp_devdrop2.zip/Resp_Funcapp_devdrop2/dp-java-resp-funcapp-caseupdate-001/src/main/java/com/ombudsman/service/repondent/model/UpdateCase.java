package com.ombudsman.service.repondent.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.nimbusds.jose.shaded.gson.annotations.SerializedName;



public class UpdateCase  {
	
	//Coming from Sercvice bus
	@JsonProperty("field_dp_x_numberOfCases")
	private List<NumberOfCases> numberOfCases;
	@SerializedName("details")
	private String details;
	@SerializedName("reasonForChange")
	private int reasonForChange;
	private String userId;
    private List<String> usersAccountIds;
    private List<IncidentInfo> incidentInfo;
    private String packageIdReq;
    private Integer templateId;
    private String templateName;
   
	private List<String> caaseIdList;
    
    //Values to be added in message body
    private String digitalPortalUserName ;
	private String digitalPortalUserEmailAddress ;
	private String packageId;
	private String contactId ;
	private String isRespondent;

	 public String getTemplateName() {
			return templateName;
		}
		public void setTemplateName(String templateName) {
			this.templateName = templateName;
		}

	public List<String> getCaaseIdList() {
		return caaseIdList;
	}
	public void setCaaseIdList(List<String> caaseIdList) {
		this.caaseIdList = caaseIdList;
	}
	public String getPackageIdReq() {
		return packageIdReq;
	}
	public void setPackageIdReq(String packageIdReq) {
		this.packageIdReq = packageIdReq;
	}
	public Integer getTemplateId() {
		return templateId;
	}
	public void setTemplateId(Integer templateId) {
		this.templateId = templateId;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	
	public List<String> getUsersAccountIds() {
		return usersAccountIds;
	}
	public void setUsersAccountIds(List<String> usersAccountIds) {
		this.usersAccountIds = usersAccountIds;
	}
	public String getDigitalPortalUserName() {
		return digitalPortalUserName;
	}
	public void setDigitalPortalUserName(String digitalPortalUserName) {
		this.digitalPortalUserName = digitalPortalUserName;
	}
	public String getDigitalPortalUserEmailAddress() {
		return digitalPortalUserEmailAddress;
	}
	public void setDigitalPortalUserEmailAddress(String digitalPortalUserEmailAddress) {
		this.digitalPortalUserEmailAddress = digitalPortalUserEmailAddress;
	}
	public String getPackageId() {
		return packageId;
	}
	public void setPackageId(String packageId) {
		this.packageId = packageId;
	}
	public String getContactId() {
		return contactId;
	}
	public void setContactId(String contactId) {
		this.contactId = contactId;
	}
	public String getIsRespondent() {
		return isRespondent;
	}
	public void setIsRespondent(String isRespondent) {
		this.isRespondent = isRespondent;
	}
		public List<IncidentInfo> getIncidentInfo() {
		return incidentInfo;
	}
	public void setIncidentInfo(List<IncidentInfo> incidentInfo) {
		this.incidentInfo = incidentInfo;
	}
	public int getReasonForChange() {
		return reasonForChange;
	}
	public List<NumberOfCases> getNumberOfCases() {
		return numberOfCases;
	}
	public void setNumberOfCases(List<NumberOfCases> numberOfCases) {
		this.numberOfCases = numberOfCases;
	}
	public void setReasonForChange(int reasonForChange) {
		this.reasonForChange = reasonForChange;
	}
	public String getDetails() {
		return details;
	}
	public void setDetails(String details) {
		this.details = details;
	}
	
public static class NumberOfCases  {
		
		@SerializedName("comment")
		private String comment;
		@SerializedName("caseId")
		private String caseId;
		
		public String getComment() {
			return comment;
		}
		public void setComment(String comment) {
			this.comment = comment;
		}
		public String getCaseId() {
			return caseId;
		}
		public void setCaseId(String caseId) {
			this.caseId = caseId;
		}
		
		
	}
	
    
}
