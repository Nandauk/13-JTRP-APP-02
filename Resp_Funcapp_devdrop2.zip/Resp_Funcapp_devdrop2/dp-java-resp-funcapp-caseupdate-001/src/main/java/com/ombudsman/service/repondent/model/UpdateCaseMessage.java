package com.ombudsman.service.repondent.model;

import com.fasterxml.jackson.annotation.JsonInclude;

import com.fasterxml.jackson.annotation.JsonProperty;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

import java.util.List;
 
public class UpdateCaseMessage{
 
    @JsonProperty("activityid")
    private String activityId;
    @JsonProperty("ownerid@odata.bind")
    private String ownerId;
    @JsonProperty("regardingobjectid_incident_fos_portal@odata.bind")
    private String regardingObjectIdIncidentFosPortal;
    @JsonProperty("subject")
    private String subject;
    @JsonProperty("fos_otherreasonforchange")
    private String fosOtherReasonForChange;
    @JsonProperty("description")
    private String description;

    @JsonProperty("fos_capacity")
    private int fosCapacity;

    @JsonProperty("fos_categorycode")
    private int fosCategoryCode;
 
    @JsonProperty("fos_packageid")
    private String fosPackageId;
 
    @JsonProperty("fos_reasonforchange")
    private int fosReasonForChange;
 
    @JsonProperty("fos_businessresponse")
    private boolean fosBusinessResponse;
 
    @JsonProperty("fos_dpuseremailaddress")
    private String fosDpUserEmailAddress;

    @JsonProperty("fos_dpuserfullname")
    private String fosDpUserFullName;
 
    @JsonProperty("fos_portal_activity_parties")
    @JsonDeserialize(contentAs = FosPortalActivityParty.class)
    private List<FosPortalActivityParty> fosPortalActivityParties;
 
    

    // Getters and setters

 
    public String getActivityId() {

		return activityId;

	}
 
 
	public void setActivityId(String activityId) {

		this.activityId = activityId;

	}
 
 
	public String getOwnerId() {

		return ownerId;

	}
 
 
	public void setOwnerId(String ownerId) {

		this.ownerId = ownerId;

	}
 
 
	public String getRegardingObjectIdIncidentFosPortal() {

		return regardingObjectIdIncidentFosPortal;

	}
 
 
	public void setRegardingObjectIdIncidentFosPortal(String regardingObjectIdIncidentFosPortal) {

		this.regardingObjectIdIncidentFosPortal = regardingObjectIdIncidentFosPortal;

	}
 
 
	public String getSubject() {

		return subject;

	}
 
 
	public void setSubject(String subject) {

		this.subject = subject;

	}
 
 
	public String getFosOtherReasonForChange() {

		return fosOtherReasonForChange;

	}
 
 
	public void setFosOtherReasonForChange(String fosOtherReasonForChange) {

		this.fosOtherReasonForChange = fosOtherReasonForChange;

	}
 
 
	public String getDescription() {

		return description;

	}
 
 
	public void setDescription(String description) {

		this.description = description;

	}
 
 
	public int getFosCapacity() {

		return fosCapacity;

	}
 
 
	public void setFosCapacity(int fosCapacity) {

		this.fosCapacity = fosCapacity;

	}
 
 
	public int getFosCategoryCode() {

		return fosCategoryCode;

	}
 
 
	public void setFosCategoryCode(int fosCategoryCode) {

		this.fosCategoryCode = fosCategoryCode;

	}
 
 
	public String getFosPackageId() {

		return fosPackageId;

	}
 
 
	public void setFosPackageId(String fosPackageId) {

		this.fosPackageId = fosPackageId;

	}
 
 
	public int getFosReasonForChange() {

		return fosReasonForChange;

	}
 
 
	public void setFosReasonForChange(int fosReasonForChange) {

		this.fosReasonForChange = fosReasonForChange;

	}
 
 
	public boolean isFosBusinessResponse() {

		return fosBusinessResponse;

	}
 
 
	public void setFosBusinessResponse(boolean fosBusinessResponse) {

		this.fosBusinessResponse = fosBusinessResponse;

	}
 
 
	public String getFosDpUserEmailAddress() {

		return fosDpUserEmailAddress;

	}
 
 
	public void setFosDpUserEmailAddress(String fosDpUserEmailAddress) {

		this.fosDpUserEmailAddress = fosDpUserEmailAddress;

	}
 
 
	public String getFosDpUserFullName() {

		return fosDpUserFullName;

	}
 
 
	public void setFosDpUserFullName(String fosDpUserFullName) {

		this.fosDpUserFullName = fosDpUserFullName;

	}
 
 
	public List<FosPortalActivityParty> getFosPortalActivityParties() {

		return fosPortalActivityParties;

	}
 
 
	public void setFosPortalActivityParties(List<FosPortalActivityParty> fosPortalActivityParties) {

		this.fosPortalActivityParties = fosPortalActivityParties;

	}
 
	

	public static class FosPortalActivityParty {
 
    	@JsonProperty("@odata.type")
        private String type;
 
    	

        @JsonProperty("partyid_systemuser@odata.bind")
        @JsonInclude(com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL)
        private String partyIdSystemUser;
        @JsonProperty("partyid_queue@odata.bind")
        @JsonInclude(com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL)
        private String partyIdQueue;

        public String getPartyIdQueue() {

			return partyIdQueue;

		}
 
		public void setPartyIdQueue(String partyIdQueue) {

			this.partyIdQueue = partyIdQueue;

		}
 
		@JsonInclude(com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL)
        @JsonProperty("partyid_contact@odata.bind")
        private String partyIdContact;
 
        @JsonProperty("participationtypemask")
        private int participationTypeMask;
 
        

        public String getPartyIdContact() {

			return partyIdContact;

		}
 
		public void setPartyIdContact(String partyIdContact) {

			this.partyIdContact = partyIdContact;

		}
 
		public String getType() {

			return type;

		}
 
		public void setType(String type) {

			this.type = type;

		}
 
		public String getPartyIdSystemUser() {

			return partyIdSystemUser;

		}
 
		public void setPartyIdSystemUser(String partyIdSystemUser) {

			this.partyIdSystemUser = partyIdSystemUser;

		}
 
		public int getParticipationTypeMask() {

			return participationTypeMask;

		}
 
		public void setParticipationTypeMask(int participationTypeMask) {

			this.participationTypeMask = participationTypeMask;

		}
 
		


    }

}

 