package com.ombudsman.service.respondent.service;

public interface PhoenixProcessor {

	
//	public int createRecordPhnx(String accessToken, String entity,String jsonBody);
//	public String getToValue(String accessToken, String ownerId, String owningTeam, String owningUser);
//	public String getRecordFromQueue(String accessToken, String EntityName, String RecordIdentifier);
//	public String getRecordFromSystemUser(String accessToken, String EntityName, String RecordIdentifier);

	public int createRecordPhnx( String entity,String jsonBody);
	public String getToValue(String ownerId, String owningTeam, String owningUser);
	public String getRecordFromQueue( String EntityName, String RecordIdentifier);
	public String getRecordFromSystemUser( String EntityName, String RecordIdentifier);
	public String getOwnerValue( String owningTeam, String owningUser);
	
	
	
}
