package com.ombudsman.service.respondent.helper;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.stereotype.Service;

import com.ombudsman.service.repondent.model.EfileApiResponse.ReasonForChangeMapping;
import com.ombudsman.service.repondent.model.NotificationModel;
import com.ombudsman.service.repondent.model.RequestModel;
import com.ombudsman.service.repondent.model.SubjectAndCatCode;
import com.ombudsman.service.repondent.model.UpdateCaseDto;
import com.ombudsman.service.respondent.common.DataSourceSingleton;
import com.ombudsman.service.respondent.exception.RecordCreationException;
import com.ombudsman.service.respondent.exception.SQLDataAccessException;
import com.ombudsman.service.respondent.serviceimpl.IncidentInfoImpl;
import com.ombudsman.service.respondent.serviceimpl.PhoenixProcessorImpl;

@Service
public class CaseUpdateSqlHelper {

	private static final String INSERT_RECORD_REQUEST_TABLE = "INSERT INTO dp_user_request (user_oid, requesting_activity_name, request_status_id,request_status_description,request_processing_details,request_start_time,request_processing_counter,created_by,created_on) "
			+ "VALUES (?, ?, ?,?, ?, ?,?, ?, ?)";

	private static final String INSERT_RECORD_UPDATE_CASE_TABLE = "INSERT INTO dp_case_updates (case_id, comments, details,reason_for_change,user_id,created,package_id,status) "
			+ "VALUES (?, ?, ?,?, ?, ?,?,?)";

	private static final String INSERT_RECORD_NOTIFICATION_TABLE = "INSERT INTO dp_user_notification (request_id, user_oid, requesting_activity_name ,notification_status_id ,notification_status_description ,message ,created_on, created_by,modified_on, modified_by ) "
			+ "VALUES (?, ?, ?,?, ?, ?,?,?,?,?)";

	private static final String FETCH_INCIDENT_INFO = "SELECT incidentid,ticketnumber FROM incident WHERE incidentid = ? AND customerid in (?)";

	private static final String GET_OWNERID = "SELECT ownerid FROM incident WHERE incidentid = ?";

	private static final String GET_REQUESTID = "SELECT TOP 1 request_id, request_start_time FROM dp_user_request  WHERE requesting_activity_name= ? and user_oid = ? ORDER BY request_start_time DESC";

	private static final String GET_SUBJECT_CATCODE = "Select subject, category_code from dp_reason_for_change_subcat_map where reason_for_change_code = ? ";

	private static final String GET_OWNERID_TEAM_USER = "SELECT ownerid,owningteam,owninguser FROM [dbo].[incident] WHERE  incidentid = ? ";

	private static final String GET_NOTIFICATIO_ID = "Select notification_id from [dbo].[dp_user_notification] where request_id = ?";

	private static final String UPDATE_CASE_TABLE = "UPDATE [dbo].[dp_case_updates] SET status = ? WHERE case_id = ? ";

	private static final String UPDATE_NOTIFICATION_TABLE = "UPDATE [dbo].[dp_user_notification] SET notification_status_description = ? , notification_status_id = ?  WHERE request_id = ? AND notification_status_description = ? ";

	private static final String DELETEALL_MAPPINGTABLE = "DELETE FROM [dbo].[dp_reason_for_change_subcat_map]"; // record_type,

	private static final String INSERT_ALL_RECORDS = "INSERT INTO [dbo].[dp_reason_for_change_subcat_map] (reason_for_change_code, reason_for_change_text, subject,category_code,record_type,created_on,created_by,modified_on,modified_by) "
			+ "VALUES (?,?,?,?,?,?,?,?,?)";

	private static final String GET_REASON_FOR_UPDATE = "SELECT reason_for_change_text FROM [dbo].[dp_reason_for_change_subcat_map] WHERE reason_for_change_code = ?";

	private static final String GET_NAME_EMAIL = "Select full_name , email from dp_user_dprespondent where oid = ?";

	private static final String NAME = "Scheduler Job";

	private static final String sql = "SELECT incidentid,ticketnumber FROM incident WHERE incidentid =:incidentid AND customerid IN (:ids)";

	Logger log = LogManager.getRootLogger();

	@Autowired
	PhoenixProcessorImpl phoenixProcessorImpl;

	public CaseUpdateSqlHelper() {

	}

	public CaseUpdateSqlHelper(PhoenixProcessorImpl phoenixProcessorImpl) {

		this.phoenixProcessorImpl = phoenixProcessorImpl;

	}

	public void saveRecordUpdateCase(UpdateCaseDto req) {
		log.info(String.format("updateRequest Started :: with package ID  :-%s", req.getPackage_id()));

		try (Connection conn = DataSourceSingleton.getDataSource().getConnection();
				PreparedStatement pstmt = conn.prepareStatement(INSERT_RECORD_UPDATE_CASE_TABLE)) {
			// table dp_upload_requests
			// Connection conn = connectionjdbc();

			pstmt.setString(1, req.getCase_id());
			pstmt.setString(2, req.getComments());
			pstmt.setString(3, req.getDetails());
			pstmt.setLong(4, req.getReason_for_change());
			pstmt.setString(5, req.getUser_id());
			pstmt.setTimestamp(6, Timestamp.from(req.getCreated().toInstant()));
			pstmt.setString(7, req.getPackage_id());
			pstmt.setString(8, req.getStatus());

			int rowsInserted = pstmt.executeUpdate();
			if (rowsInserted > 0) {
				System.out.println("A new record was inserted successfully in Case Update table !");
			}

		} catch (Exception e) {
			log.info(String.format("Failed to create record in UpdateCase table {}", e.getMessage()));
		}

	}

	public void saveRecordRequestEntity(RequestModel request) {

		log.info("RequestEntity Sql method started : ");

		try (Connection conn = DataSourceSingleton.getDataSource().getConnection();
				PreparedStatement pstmt = conn.prepareStatement(INSERT_RECORD_REQUEST_TABLE)) {
			// Connection conn = connectionjdbc();

			pstmt.setString(1, request.getUserOid());
			pstmt.setString(2, request.getRequestingActivityName());
			pstmt.setInt(3, request.getRequestStatusId());
			pstmt.setString(4, request.getRequestStatusDescription());
			pstmt.setString(5, request.getRequestProcessingDetails());
			pstmt.setTimestamp(6, Timestamp.from(request.getRequestStartTime().toInstant()));
			pstmt.setInt(7, request.getRequestProcessingCounter());
			pstmt.setString(8, request.getCreatedBy());
			pstmt.setTimestamp(9, Timestamp.from(request.getCreatedOn().toInstant()));

			// Execute the update and save record
			int rowsInserted = pstmt.executeUpdate();
			if (rowsInserted > 0) {
				log.info("A new record was inserted successfully in Request Entity!");
			}

		} catch (Exception e) {
			request.setRequestStatusId(4);
			request.setRequestStatusDescription("Failed");
			log.info("Request Creation Failed. Please Try Again. {}", e.getStackTrace());
			log.info("Exception message is  {}", e.getMessage());
			throw new RecordCreationException("Request Creation Failed. Please Try Again. {}", e.getMessage(), null);
		}

	}

	public String saveRecordNotificationEntity(NotificationModel request) {

		log.info("Notification sql  method started ");

		try (Connection conn = DataSourceSingleton.getDataSource().getConnection();
				PreparedStatement pstmt = conn.prepareStatement(INSERT_RECORD_NOTIFICATION_TABLE)) {

			// Getting JDBC connection
			// Connection conn = connectionjdbc();

			// Setting coloumns values
			pstmt.setString(1, request.getRequest_id());
			pstmt.setString(2, request.getUser_oid());
			pstmt.setString(3, request.getRequesting_activity_name());
			pstmt.setString(4, request.getNotification_status_id());
			pstmt.setString(5, request.getNotification_status_description());
			pstmt.setString(6, request.getMessage());
			pstmt.setString(7, request.getCreated_on());
			pstmt.setString(8, request.getCreated_by());
			pstmt.setString(9, request.getModified_on());
			pstmt.setString(10, request.getModified_by());

			// Execute the update and save record
			int rowsInserted = pstmt.executeUpdate();
			if (rowsInserted > 0) {
				log.info("A new record was inserted successfully in Notification table!");
			}

			return getNotificationId(request.getRequest_id());

		} catch (Exception e) {
			request.setNotification_status_id("4");
			request.setNotification_status_description("Expired");
			log.info("Notification Creation Failed. Please Try Again. {}", e.getStackTrace());
			log.info("Exception message is  {}", e.getMessage());
			throw new RecordCreationException("Notification Request Creation Failed. Please Try Again. {}",
					e.getMessage(), null);
		}

	}

	private String getNotificationId(String requestId) {

		log.info("getNotificationId sql  method started ");

		try (Connection conn = DataSourceSingleton.getDataSource().getConnection();
				PreparedStatement pstmt = conn.prepareStatement(GET_NOTIFICATIO_ID)) {

			// Getting JDBC connection
			// Connection conn = connectionjdbc();
			pstmt.setString(1, requestId);

			ResultSet resultSet = pstmt.executeQuery();

			String notificationId = "";
			while (null != resultSet && resultSet.next()) {
				notificationId = resultSet.getString("notification_id");
			}

			return notificationId;
		} catch (Exception e) {
			log.info("NotificationID could not be retrieved. Please Try Again. {}", e.getStackTrace());
			log.info("Exception message is  {}", e.getMessage());
			throw new SQLDataAccessException("Could not fetch notificatioID {}", e.getMessage());
		}

	}

	public IncidentInfoImpl getIncident(String incidentId, List<String> account) throws SQLException {

		log.info("getIncident  method started ");

		final NamedParameterJdbcTemplate jdbcTemplate = new NamedParameterJdbcTemplate(
				DataSourceSingleton.getDataSource());
		// String customerIdsStr=account.stream().map(s -> "'" + s +
		// "'").collect(Collectors.joining(", "));
		String customerIdsStr = String.join(", ", account);
		log.info(String.format("customerIdsStr : %s ", customerIdsStr));

		// Connection conn = connectionjdbc();
		MapSqlParameterSource parameters = new MapSqlParameterSource();

		parameters.addValue("incidentid", incidentId);
		parameters.addValue("ids", account);
		// IncidentInfoImpl data = new IncidentInfoImpl(incidentId, incidentId);
		List<IncidentInfoImpl> incidentList = jdbcTemplate.query(sql, parameters,
				(rs, rowNum) -> new IncidentInfoImpl(rs.getString("incidentid"), rs.getString("ticketnumber")));
		log.info(String.format("incidentIdLog : %s ", incidentId));
		log.info(String.format("QueryOutput : %s ", sql));
		log.info(String.format("IncidentList : %s ", incidentList.get(0)));
		if (CollectionUtils.isNotEmpty(incidentList)) {
			return incidentList.get(0);
		}
		return null;
	}

	public String getOwnerId(String incidentId) throws SQLException {

		log.info("getOwner ID  method started ");

		String ownerId = "";
		try (Connection conn = DataSourceSingleton.getDataSource().getConnection();
				PreparedStatement pstmt = conn.prepareStatement(GET_OWNERID)) {

			// Connection conn = connectionjdbc();

			pstmt.setString(1, incidentId);

			ResultSet resultSet = pstmt.executeQuery();

			while (null != resultSet && resultSet.next()) {
				ownerId = resultSet.getString("ownerid");
			}
			return ownerId;

		} catch (SQLException ex) {
			log.info("Exception message is  {}", ex.getMessage());
			throw new SQLDataAccessException("Could not fetch ownerID {}", ex.getMessage());
		}

	}

	public String getRequestId(String oid) throws SQLException {

		log.info("getRequestId  method started ");

		String requestId = "";
		try (Connection conn = DataSourceSingleton.getDataSource().getConnection();
				PreparedStatement pstmt = conn.prepareStatement(GET_REQUESTID)) {

			// Connection conn = connectionjdbc();
			pstmt.setString(1, "CaseUpdate");
			pstmt.setString(2, oid);
			ResultSet resultSet = pstmt.executeQuery();

			while (resultSet.next() && resultSet != null) {
				requestId = resultSet.getString("request_id");
				return requestId;
			}
			return requestId;
		} catch (SQLException ex) {
			log.info("Exception message is  {}", ex.getMessage());
			throw new SQLDataAccessException("Could not fetch RequestID {}", ex.getMessage());
		}

	}

	public List<SubjectAndCatCode> getSubCategoryCode(int reasonForChange) throws SQLException {

		log.info("getSubCategoryCode  method started ");

		try (Connection conn = DataSourceSingleton.getDataSource().getConnection();
				PreparedStatement pstmt = conn.prepareStatement(GET_SUBJECT_CATCODE)) {

			// Connection conn = connectionjdbc();
			pstmt.setLong(1, reasonForChange);

			ResultSet resultSet = pstmt.executeQuery();
			List<SubjectAndCatCode> resList = new ArrayList<>();
			SubjectAndCatCode res = new SubjectAndCatCode();

			while (null != resultSet && resultSet.next()) {
				res.setSubject(resultSet.getString("subject"));
				res.setCategoryCode(resultSet.getInt("category_code"));
			}
			resList.add(res);

			return resList;
		} catch (SQLException ex) {
			log.info("Exception message is  {}", ex.getMessage());
			throw new SQLDataAccessException("Could not fetch Subject and Category Code : {}", ex.getMessage());
		}
	}

	public Map<String, String> getOwnerDetails(String caseId) throws SQLException {

		log.info("GetOwnerDetails  method started ");

		try (Connection conn = DataSourceSingleton.getDataSource().getConnection();
				PreparedStatement pstmt = conn.prepareStatement(GET_OWNERID_TEAM_USER);) {

			// Connection conn = connectionjdbc();

			pstmt.setString(1, caseId);

			ResultSet resultSet = pstmt.executeQuery();
			Map<String, String> data = new HashMap<String, String>();

			while (null != resultSet && resultSet.next()) {
				data.put("ownerId", resultSet.getString("ownerid"));
				data.put("owningTeam", resultSet.getString("owningteam"));
				data.put("owningUser", resultSet.getString("owninguser"));
			}

			return data;

		} catch (SQLException ex) {
			log.info("Exception message is  {}", ex.getMessage());
			throw new SQLDataAccessException("Could not fetch ownerID, team and User : ", ex.getMessage());
		}

	}

	public void updateCaseTable(String caseID, String Status) throws SQLException {

		log.info("updateCaseTable  method started ");

		try (Connection conn = DataSourceSingleton.getDataSource().getConnection();
				PreparedStatement pstmt = conn.prepareStatement(UPDATE_CASE_TABLE)) {

			// Connection conn = connectionjdbc();

			pstmt.setString(1, Status);
			pstmt.setString(2, caseID);

			int rowsInserted = pstmt.executeUpdate();
			if (rowsInserted > 0) {
				log.info("Status column of Case Update entity was set to SUCCESS ! {}");
			} else {
				log.info("Status column could not be updated ! {}");
			}
		} catch (SQLException ex) {
			log.info("Exception message is  {}", ex.getMessage());
			throw new SQLDataAccessException("Status column could not be updated ! {}", ex.getMessage());
		}

	}

	public void updateNotificationTable(String requestId, String updatedStatus, String updatedCode)
			throws SQLException {

		log.info("updateNotificationTable  method started ");

		try (Connection conn = DataSourceSingleton.getDataSource().getConnection();
				PreparedStatement pstmt = conn.prepareStatement(UPDATE_NOTIFICATION_TABLE)) {

			// Connection conn = connectionjdbc();

			pstmt.setString(1, updatedStatus);
			pstmt.setString(2, updatedCode);
			pstmt.setString(3, requestId);
			pstmt.setString(4, "Pending");

			int rowsInserted = pstmt.executeUpdate();
			if (rowsInserted > 0) {
				log.info("Notification Status column was set to SUCCESS ! {}");
			} else {
				log.info("Notification Status column could not be updated ! {}");
			}
		} catch (SQLException ex) {
			log.info("Exception message is  {}", ex.getMessage());
			throw new SQLDataAccessException("Notification Status column could not be updated ! {}", ex.getMessage());
		}

	}

	public String getReasonForChangeText(int reasonForChangeCode) throws SQLException {

		log.info("getReasonForChangeText  method started ");

		try (Connection conn = DataSourceSingleton.getDataSource().getConnection();
				PreparedStatement pstmt = conn.prepareStatement(GET_REASON_FOR_UPDATE)) {
			pstmt.setInt(1, reasonForChangeCode);

			ResultSet resultSet = pstmt.executeQuery();
			String reasonText = "";
			while (null != resultSet && resultSet.next()) {
				reasonText = resultSet.getString("reason_for_change_text");

			}
			log.info(String.format("ReasonTest obtained : %s", reasonText));
			return reasonText;

		} catch (SQLException ex) {
			log.info("Exception message is  {}", ex.getMessage());
			throw new SQLDataAccessException("Could not find reason for change text {}", ex.getMessage());
		}

	}

	public void deleteAllRecords() {

		try (Connection conn = DataSourceSingleton.getDataSource().getConnection();
				PreparedStatement pstmt = conn.prepareStatement(DELETEALL_MAPPINGTABLE)) {

			pstmt.executeUpdate();
			log.info("All recrods deleted successfullt ! {}");
		} catch (SQLException ex) {
			log.info("Exception message is  {}", ex.getMessage());
			throw new SQLDataAccessException("Records could not be deleted from Sql table {}", ex.getMessage());
		}
	}

	public void insertApiMappingInTable(Map<String, ReasonForChangeMapping> reasonForChangeMap, Set<String> commonKeys,
			List<ReasonForChangeMapping> respondentMappings) {
		// Insert new records into the database

		try (Connection conn = DataSourceSingleton.getDataSource().getConnection();
				PreparedStatement insertStatement = conn.prepareStatement(INSERT_ALL_RECORDS)) {

			for (String key : reasonForChangeMap.keySet()) {
				ReasonForChangeMapping mapping = reasonForChangeMap.get(key);
				String role;
				if (commonKeys.contains(key)) {
					role = "RespAndComp";
				} else if (respondentMappings.contains(mapping)) {
					role = "Respondent";
				} else {
					role = "Complainant";
				}

				insertStatement.setString(1, mapping.getReasonforchangecode());
				insertStatement.setString(2, mapping.getReasonforchangetext());
				insertStatement.setString(3, mapping.getSubjecttext());
				insertStatement.setString(4, mapping.getCategorycode());
				insertStatement.setString(5, role);
				insertStatement.setTimestamp(6, new Timestamp(System.currentTimeMillis()));
				insertStatement.setString(7, NAME);
				insertStatement.setTimestamp(8, new Timestamp(System.currentTimeMillis()));
				insertStatement.setString(9, NAME);

				insertStatement.addBatch(); // Add to batch for batch execution
			}
			int[] total = insertStatement.executeBatch();
			log.info(String.format("New records inserted into the table. : %s", total));

		} catch (SQLException ex) {
			log.info("Exception message is  {}", ex.getMessage());
			throw new SQLDataAccessException("Records could not be inserted into the table.{}", ex.getMessage());
		}

	}

	public List<String> getUserEmailName(String userOid) throws SQLException {

		log.info("getUserEmailName  method started ");

		try (Connection conn = DataSourceSingleton.getDataSource().getConnection();
				PreparedStatement pstmt = conn.prepareStatement(GET_NAME_EMAIL)) {

			pstmt.setString(1, userOid);

			ResultSet resultSet = pstmt.executeQuery();

			List<String> output = new ArrayList<>();
			while (null != resultSet && resultSet.next()) {
				output.add(resultSet.getString("full_name"));
				output.add(resultSet.getString("email"));
			}
			log.info(String.format("Name and email obtained from query in user table  : %s", output));

			return output;

		} catch (SQLException ex) {
			log.info("Exception message is  {}", ex.getMessage());
			throw new SQLDataAccessException("Could not find email and name of user  {}", ex.getMessage());
		}

	}

	public Map<String, Object> getContactId(Map<String, Object> reqParam, JdbcTemplate jdbcTemplate)
			throws SQLDataAccessException {
		log.info("Function calling stored procedure to get contactID started {}");

		final SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate).withProcedureName("prc_GetADContactid");

		SqlParameterSource in = new MapSqlParameterSource(reqParam);

		log.info("getCaseListDetails Method parameters passing to Store procedure");

		return simpleJdbcCall.execute(in);

	}

}
