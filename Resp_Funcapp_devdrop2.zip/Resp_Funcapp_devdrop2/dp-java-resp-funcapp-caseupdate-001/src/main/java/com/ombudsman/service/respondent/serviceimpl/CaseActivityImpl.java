package com.ombudsman.service.respondent.serviceimpl;

import java.time.OffsetDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ombudsman.service.repondent.model.NotificationModel;
import com.ombudsman.service.repondent.model.RequestModel;
import com.ombudsman.service.repondent.model.UpdateCase;
import com.ombudsman.service.respondent.common.WebClientData;
import com.ombudsman.service.respondent.exception.RecordCreationException;
import com.ombudsman.service.respondent.helper.CaseUpdateSqlHelper;
import com.ombudsman.service.respondent.service.CaseActivity;

@Service
public class CaseActivityImpl implements CaseActivity {

	private static final String API_ERROR_RECORD_CREATION_FAILED = "api.error.RecordCreationFailed";

	private static final Logger LOG = LoggerFactory.getLogger(CaseActivityImpl.class);

	CaseUpdateSqlHelper caseUpdateSqlHelper = new CaseUpdateSqlHelper();

	WebClientData webClientData =  new WebClientData();

	private static final String CASE_UPDATE = "caseUpdate";
	private static final String IN_PROGRESS = "InProgress";
	private static final String PENDING = "Pending";

	public String activity(UpdateCase dto, String ticketnumber, int index, int reasonForChange) {

		RequestModel request = new RequestModel();
		// Updating data in Request Entity
		String id = RequestEntity(request, index, dto, CASE_UPDATE);
		LOG.info("id from Request extity from CaseUpdate : {}", id);

		try {
			if (id != null) {
				NotificationModel notifyModel = new NotificationModel();

				String notificationId = notificationEntity(request, notifyModel, id, ticketnumber, reasonForChange);

				LOG.info("caseupdateNotification successful, NotificatioID is {}", notificationId);

			}
		} catch (Exception e) {

			request.setRequestStatusId(4);
			request.setRequestId(id);
			request.setRequestStatusDescription("Failed for Notification ");
			caseUpdateSqlHelper.saveRecordRequestEntity(request);
			LOG.info("Exception message {}", e.getMessage());
			LOG.info("Notification Creation Failed. Please Try Again. {}", e.getStackTrace());
			throw new RecordCreationException("Notification Creation Failed. Please Try Again.",
					e.getMessage(), null);
		}

		return id;
	}

	String RequestEntity(RequestModel request, int index, UpdateCase updateCase, String userEventName) {
		LOG.info("RequestEntity method started ");
		String requestId;

		try {

			ObjectMapper mapper = new ObjectMapper();
			String CaseIdAndComment = mapper.writeValueAsString(updateCase.getNumberOfCases().get(index));

			request.setUserOid(updateCase.getUserId());
			request.setRequestingActivityName(CASE_UPDATE);
			request.setRequestStatusId(1);
			request.setRequestStatusDescription(IN_PROGRESS);
			request.setRequestProcessingDetails(CaseIdAndComment);
			OffsetDateTime offsetdatetime = OffsetDateTime.now();
			request.setRequestStartTime(offsetdatetime);
			request.setRequestProcessingCounter(0);
			request.setCreatedBy("dp-java-resp-casemanagement-001");
			request.setCreatedOn(offsetdatetime);

			caseUpdateSqlHelper.saveRecordRequestEntity(request);
			// Fetch RequestID which will be set as PackageID
			requestId = caseUpdateSqlHelper.getRequestId(updateCase.getUserId());
			LOG.info("RequestEntity method ended and reqestID is {}", requestId);

		} catch (Exception e) {
			request.setRequestStatusId(4);
			request.setRequestStatusDescription("Failed");
			LOG.info("Exception message {}", e.getMessage());
			LOG.info("Request Creation Failed. Please Try Again. {}", e.getStackTrace());
			throw new RecordCreationException("Request Creation Failed. Please Try Again. ",
					e.getMessage(), null);
		}

		return requestId;
	}

	String notificationEntity(RequestModel request, NotificationModel notifyModel, String id, String ticketnumber,
			int reasonForChange) {

		try {
			LOG.info("notificationEntity method started ");
			notifyModel.setRequest_id(id);
			notifyModel.setUser_oid(request.getUserOid());
			notifyModel.setRequesting_activity_name(request.getRequestingActivityName());
			notifyModel.setNotification_status_id("1");
			notifyModel.setNotification_status_description(PENDING);
			notifyModel.setMessage(ticketnumber + "-" + String.valueOf(reasonForChange));
			notifyModel
					.setCreated_on(request.getCreatedOn().format(DateTimeFormatter.ofPattern("MM/dd/yyyy HH:mm:ss")));
			notifyModel.setCreated_by(request.getCreatedBy());
			notifyModel.setModified_on(request.getModifiedOn());
			notifyModel.setModified_by(request.getModifiedBy());

			String notificationId = caseUpdateSqlHelper.saveRecordNotificationEntity(notifyModel);
			LOG.info("Record successfully created in Notification table !! ");

			return notificationId;

		} catch (Exception e) {
			notifyModel.setNotification_status_id("4");
			notifyModel.setNotification_status_description("Expired");
			LOG.info("Setting data in Notification Failed. {}", e.getStackTrace());
			LOG.info("Exception message {}", e.getMessage());
			throw new RecordCreationException("Notification Creation Failed. Please Try Again.",
					e.getMessage(), null);
		}

	}

}
