package com.ombudsman.service.repondent.model;

import java.time.OffsetDateTime;


public class RequestModel {

	

	private String requestId;
	
	private String userOid; // notnull
	
	private String requestingActivityName; // notnull
	
	private Integer requestStatusId; // notnull
	
	private String requestStatusDescription; // notnull
	
	private String requestProcessingDetails;
	
	private OffsetDateTime requestStartTime;
	
	private OffsetDateTime requestFinishTime; // notnull

	private Integer requestProcessingCounter; // notnull
	
	private OffsetDateTime createdOn; // notnull
	
	private String createdBy; // notnull
	
	private String modifiedOn;

	private String modifiedBy;
	
	

	public OffsetDateTime getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(OffsetDateTime createdOn) {
		this.createdOn = createdOn;
	}

	

	public String getRequestId() {
		return requestId;
	}

	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}

	public String getUserOid() {
		return userOid;
	}

	public void setUserOid(String userOid) {
		this.userOid = userOid;
	}

	public String getRequestingActivityName() {
		return requestingActivityName;
	}

	public void setRequestingActivityName(String requestingActivityName) {
		this.requestingActivityName = requestingActivityName;
	}

	public Integer getRequestStatusId() {
		return requestStatusId;
	}

	public void setRequestStatusId(Integer requestStatusId) {
		this.requestStatusId = requestStatusId;
	}

	public String getRequestStatusDescription() {
		return requestStatusDescription;
	}

	public void setRequestStatusDescription(String requestStatusDescription) {
		this.requestStatusDescription = requestStatusDescription;
	}

	public String getRequestProcessingDetails() {
		return requestProcessingDetails;
	}

	public void setRequestProcessingDetails(String requestProcessingDetails) {
		this.requestProcessingDetails = requestProcessingDetails;
	}

	public OffsetDateTime getRequestStartTime() {
		return requestStartTime;
	}

	public void setRequestStartTime(OffsetDateTime requestStartTime) {
		this.requestStartTime = requestStartTime;
	}

	public OffsetDateTime getRequestFinishTime() {
		return requestFinishTime;
	}

	public void setRequestFinishTime(OffsetDateTime requestFinishTime) {
		this.requestFinishTime = requestFinishTime;
	}

	public Integer getRequestProcessingCounter() {
		return requestProcessingCounter;
	}

	public void setRequestProcessingCounter(Integer requestProcessingCounter) {
		this.requestProcessingCounter = requestProcessingCounter;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getModifiedOn() {
		return modifiedOn;
	}

	public void setModifiedOn(String modifiedOn) {
		this.modifiedOn = modifiedOn;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

}
