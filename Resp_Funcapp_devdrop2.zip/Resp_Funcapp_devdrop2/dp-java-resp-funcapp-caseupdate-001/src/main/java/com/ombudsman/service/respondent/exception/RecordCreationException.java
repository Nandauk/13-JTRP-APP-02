package com.ombudsman.service.respondent.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(HttpStatus.BAD_REQUEST)
public class RecordCreationException extends RespondentsServiceExceptions {

	private static final long serialVersionUID = 1L;

	public RecordCreationException(String message, String exceptionMessage, StackTraceElement[] stackTrace) {
		super(message, "RESPONDENT_RECORD_CREATION_FAILED_1004", exceptionMessage, stackTrace);
	}
}
