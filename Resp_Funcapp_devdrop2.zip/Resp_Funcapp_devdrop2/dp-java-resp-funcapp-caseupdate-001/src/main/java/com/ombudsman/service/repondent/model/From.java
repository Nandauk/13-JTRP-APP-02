package com.ombudsman.service.repondent.model;

import com.google.gson.annotations.SerializedName;

   
public class From {

   @SerializedName("Email")
   private String fromEmail;

   @SerializedName("Name")
   private String fromName;


    public void setFromEmail(String email) {
        this.fromEmail = email;
    }
    public String getFromEmail() {
        return fromEmail;
    }
    
    public void setFromName(String name) {
        this.fromName = name;
    }
    public String getFromName() {
        return fromName;
    }
    
}