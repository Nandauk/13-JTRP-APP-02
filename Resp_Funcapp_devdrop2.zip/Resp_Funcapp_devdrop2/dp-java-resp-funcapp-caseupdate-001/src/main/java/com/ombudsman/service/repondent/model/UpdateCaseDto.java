package com.ombudsman.service.repondent.model;

import java.time.OffsetDateTime;


public class UpdateCaseDto {
	
	private Integer id;
	private String case_id; 
	private String comments; 
	private String details; 
	private int reason_for_change; 
	private String user_id; 
	private String package_id; 
	private OffsetDateTime created;
	private String Status;
	
	public String getStatus() {
		return Status;
	}
	public void setStatus(String status) {
		Status = status;
	}
	public int getReason_for_change() {
		return reason_for_change;
	}
	public void setReason_for_change(int reason_for_change) {
		this.reason_for_change = reason_for_change;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getCase_id() {
		return case_id;
	}
	public void setCase_id(String case_id) {
		this.case_id = case_id;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	public String getDetails() {
		return details;
	}
	public void setDetails(String details) {
		this.details = details;
	}

	public String getUser_id() {
		return user_id;
	}
	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}
	public String getPackage_id() {
		return package_id;
	}
	public void setPackage_id(String package_id) {
		this.package_id = package_id;
	}
	public OffsetDateTime getCreated() {
		return created;
	}
	public void setCreated(OffsetDateTime created) {
		this.created = created;
	}
    
    
	
    
}
