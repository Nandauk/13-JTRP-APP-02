package com.ombudsman.service.repondent.model;

public class SubjectAndCatCode {

	private String subject;
	private int categoryCode;
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public int getCategoryCode() {
		return categoryCode;
	}
	public void setCategoryCode(int reasonForChange) {
		this.categoryCode = reasonForChange;
	}
	
	
	
}
