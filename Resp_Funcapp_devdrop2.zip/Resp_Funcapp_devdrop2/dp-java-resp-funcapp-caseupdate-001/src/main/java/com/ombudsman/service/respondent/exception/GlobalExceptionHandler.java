package com.ombudsman.service.respondent.exception;

import java.time.LocalDateTime;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import jakarta.servlet.http.HttpServletRequest;

@ControllerAdvice
public class GlobalExceptionHandler {
	
	private static final Logger LOG = LoggerFactory.getLogger(GlobalExceptionHandler.class);
	
	
	
	@ExceptionHandler({RecordCreationException.class})
	public ResponseEntity<ApiError> handleRecordCreationException(HttpServletRequest request, Exception ex) {
		
		LOG.info("Errors while creating phoenix portal activity records",
				request.getRequestURL(), ex.getMessage());
		
		ApiError err = new ApiError(LocalDateTime.now(), HttpStatus.PRECONDITION_FAILED ,
				String.valueOf(HttpStatus.PRECONDITION_FAILED.value()), "Phoenix record could not be created");
		
		return new ResponseEntity<>(err, HttpStatus.PRECONDITION_FAILED);
	}
	
	
	@ExceptionHandler({PhoenixServiceException.class})
	public ResponseEntity<ApiError> handlePhoenixServiceException(HttpServletRequest request, Exception ex) {
		
		LOG.info("Errors while creating phoenix portal activity records {}, complete errors::{}",
				request.getRequestURL(), ex.getMessage());
		
		ApiError err = new ApiError(LocalDateTime.now(), HttpStatus.PRECONDITION_FAILED ,
				String.valueOf(HttpStatus.PRECONDITION_FAILED.value()), "Phoenix connection failure");
		
		return new ResponseEntity<>(err, HttpStatus.PRECONDITION_FAILED);
	}

	@ExceptionHandler({SQLDataAccessException.class})
	public ResponseEntity<ApiError> handleSQLDataException(HttpServletRequest request, Exception ex) {
		LOG.info("SQLException Occured:: URL= {}, complete errors::{}", request.getRequestURL(), ex.getMessage());
		ApiError err = new ApiError(LocalDateTime.now(), HttpStatus.INTERNAL_SERVER_ERROR,
				HttpStatusCode.valueOf(HttpStatus.INTERNAL_SERVER_ERROR.value()).toString(),"RESPONDENT_DB_1001");
		return new ResponseEntity<>(err, HttpStatus.INTERNAL_SERVER_ERROR);
	}

}
