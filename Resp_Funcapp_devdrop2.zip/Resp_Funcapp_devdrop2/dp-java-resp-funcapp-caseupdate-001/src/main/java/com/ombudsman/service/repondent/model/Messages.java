package com.ombudsman.service.repondent.model;

import java.util.List;

import com.google.gson.annotations.SerializedName;

public class Messages {

	@SerializedName("From")
	private From from; //Write OBJ before objects name

	@SerializedName("To")
	private List<To> to;

	@SerializedName("TemplateID")
	private int templateID;

	@SerializedName("TemplateLanguage")
	private boolean templateLanguage;

	@SerializedName("Variables")
	private MailjetVariables variables;

	@SerializedName("Name")
	private String name;

	public From getFrom() {
		return from;
	}

	public void setFrom(From from) {
		this.from = from;
	}

	public List<To> getTo() {
		return to;
	}

	public void setTo(List<To> to) {
		this.to = to;
	}

	public int getTemplateID() {
		return templateID;
	}

	public void setTemplateID(int templateID) {
		this.templateID = templateID;
	}

	public boolean isTemplateLanguage() {
		return templateLanguage;
	}

	public void setTemplateLanguage(boolean templateLanguage) {
		this.templateLanguage = templateLanguage;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public MailjetVariables getVar() {
		return variables;
	}

	public void setVar(MailjetVariables variable) {
		this.variables = variable;
	}

}