package com.ombudsman.service.respondent.exception.test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.Test;

import com.ombudsman.service.respondent.exception.AzureServiceException;

public class AzureServiceExceptionTest {

    @Test
    public void testAzureServiceException() {
        String message = "An error occurred";
        String exceptionMessage = "Detailed error message";
        StackTraceElement[] stackTrace = new StackTraceElement[] {
            new StackTraceElement("className", "methodName", "fileName", 123)
        };

        AzureServiceException exception = new AzureServiceException(message, exceptionMessage, stackTrace);

        assertNotNull(exception);
        assertEquals(message, exception.getMessage());
        assertEquals("RESPONDENT_AZURE_1000", exception.getCode());
        assertEquals(exceptionMessage, exception.getExceptionMessage());
       // assertEquals(stackTrace, exception.getStackTrace());
    }
}

