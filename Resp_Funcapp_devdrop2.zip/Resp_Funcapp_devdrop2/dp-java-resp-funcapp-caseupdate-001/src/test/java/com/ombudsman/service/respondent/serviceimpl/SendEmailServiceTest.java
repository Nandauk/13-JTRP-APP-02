//package com.ombudsman.service.respondent.serviceimpl;
//
//import static org.junit.jupiter.api.Assertions.assertEquals;
//import static org.mockito.Mockito.doReturn;
//import static org.mockito.Mockito.when;
//
//import java.io.UnsupportedEncodingException;
//import java.text.ParseException;
//import java.util.ArrayList;
//import java.util.List;
//
//import org.json.JSONException;
//import org.junit.jupiter.api.BeforeEach;
//import org.junit.jupiter.api.Test;
//import org.junit.jupiter.api.extension.ExtendWith;
//import org.mockito.InjectMocks;
//import org.mockito.Mock;
//import org.mockito.MockitoAnnotations;
//import org.springframework.context.MessageSource;
//import org.springframework.test.context.junit.jupiter.SpringExtension;
//
//import com.ombudsman.service.repondent.model.EmailNotificationResponse;
//import com.ombudsman.service.repondent.model.From;
//import com.ombudsman.service.repondent.model.MailjetResponseBody;
//import com.ombudsman.service.repondent.model.MailjetResponseBody.Message;
//import com.ombudsman.service.repondent.model.MailjetResponseBody.Recipient;
//import com.ombudsman.service.repondent.model.Messages;
//import com.ombudsman.service.repondent.model.SendMailDetails;
//import com.ombudsman.service.repondent.model.SendMailReq;
//import com.ombudsman.service.repondent.model.To;
//import com.ombudsman.service.respondent.exception.InputValidationException;
//import com.ombudsman.service.respondent.exception.MailJetServiceException;
//import com.ombudsman.service.respondent.helper.RequestBodyHelper;
//
//@ExtendWith(SpringExtension.class)
//public class SendEmailServiceTest {
//
//	@InjectMocks
//	SendEmailService sendEmailService ;
//
//    @Mock
//    private RequestBodyHelper requestBodyHelper;
//
//    @Mock
//    private MessageSource messageSource;
//    
//    @Mock
//    SendMailReq sendMailReq ;
//   
//	@Mock
//	MailjetResponseBody response;
//	
//	
//	@Mock
//	Message message ;
//	
//	@Mock
//	From from ;
//	
//	@Mock
//	Messages mes;
//	
//	@Mock
//	Recipient r ;
//
//
//	  @BeforeEach
//	    public void setUp() {
//	        MockitoAnnotations.openMocks(this);
//	         sendEmailService = new SendEmailService(requestBodyHelper,sendMailReq);
//	    }
//
//    @Test
//    public void testSendInviteEmail_Success() throws InputValidationException, UnsupportedEncodingException, ParseException, JSONException, MailJetServiceException {
//        String templateName = "templateName";
//        String email = "test@example.com";
//        String fullName = "Test User";
//        int templateId = 1;
//        String ticketNumber = "123456";
//        String reasonForChange = "Test Reason";
//		
//		List<To> to = new ArrayList<>();
//		To to1 = new To();
//		to1.setToEmail(email);
//		to1.setToName(fullName);
//		to.add(to1);
//		
//		Messages mes = new Messages();
//		mes.setTemplateID(12345);
//		mes.setName("Mock TempName");
//		mes.setTo(to);
//		
//		From from = new From();
//		from.setFromEmail("fromMock@gmail.com");
//		from.setFromName("From Mock");
//		mes.setFrom(from);
//		List<Messages> sendmessage = new ArrayList<>();
//		sendmessage.add(mes);
//		SendMailReq sendMailReq = new SendMailReq();
//		sendMailReq.setMessages(sendmessage);
//		
//		
//        SendMailDetails request = new SendMailDetails();
//        request.setEmail(email);
//        request.setFullName(fullName);
//        request.setReasonForChange(reasonForChange);
//        request.setTemplateId(templateId);
//        request.setTemplateName(templateName);
//        request.setTicketNumber(ticketNumber);
//        when(requestBodyHelper.contructSendEmailBody(request)).thenReturn(sendMailReq);
//
//      //Mailjet Response body MOCK
//		
//      		MailjetResponseBody res = new MailjetResponseBody();
//      		Recipient r = new Recipient();
//      		r.setEmail("mockemail");
//              r.setMessageHref("wwee");
//              r.setMessageID(1);
//              r.setMessageUUID("messageUID");
//               
//               List<Recipient> toRecipient =  new ArrayList<>();
//               toRecipient.add(r);
//               
//      		Message msg1 = new Message();
//      		msg1.setStatus("success");
//      		msg1.setCustomID("1234");
//      		msg1.setTo(toRecipient);
//      		
//      		List<Message> messageList = new ArrayList<>();
//      		messageList.add(msg1);
//      		res.setMessages(messageList);
//              
//      		when(requestBodyHelper.send(sendMailReq)).thenReturn(res);
//       
//      		EmailNotificationResponse result = sendEmailService.sendInviteEmail(request);
//
//	       assertEquals("success", result.getStatus());
//	       assertEquals("MailJet API call success :{}", result.getMessage());
//    }
//
//    @Test
//    public void testSendInviteEmail_Failure() throws InputValidationException, UnsupportedEncodingException, ParseException, JSONException, MailJetServiceException {
//        String templateName = "templateName";
//        String email = "test@example.com";
//        String fullName = "Test User";
//        int templateId = 1;
//        String ticketNumber = "123456";
//        String reasonForChange = "Test Reason";
//       
//		
//		List<To> to = new ArrayList<>();
//		To to1 = new To();
//		to1.setToEmail(email);
//		to1.setToName(fullName);
//		to.add(to1);
//		
//		Messages mes = new Messages();
//		mes.setTemplateID(12345);
//		mes.setName("Mock TempName");
//		mes.setTo(to);
//		
//		From from = new From();
//		from.setFromEmail("fromMock@gmail.com");
//		from.setFromName("From Mock");
//		mes.setFrom(from);
//		List<Messages> sendmessage = new ArrayList<>();
//		sendmessage.add(mes);
//		SendMailReq sendMailReq = new SendMailReq();
//		sendMailReq.setMessages(sendmessage);
//		
//		SendMailDetails request = new SendMailDetails();
//        request.setEmail(email);
//        request.setFullName(fullName);
//        request.setReasonForChange(reasonForChange);
//        request.setTemplateId(templateId);
//        request.setTemplateName(templateName);
//        request.setTicketNumber(ticketNumber);
//      
//        when(requestBodyHelper.contructSendEmailBody(request)).thenReturn(sendMailReq);
//
//        MailjetResponseBody res = new MailjetResponseBody();
//  		Recipient r = new Recipient();
//  		r.setEmail("mockemail");
//          r.setMessageHref("wwee");
//          r.setMessageID(1);
//          r.setMessageUUID("messageUID");
//           
//           List<Recipient> toRecipient =  new ArrayList<>();
//           toRecipient.add(r);
//           
//  		Message msg1 = new Message();
//  		msg1.setStatus("failure");
//  		msg1.setCustomID("1234");
//  		msg1.setTo(toRecipient);
//  		
//  		List<Message> messageList = new ArrayList<>();
//  		messageList.add(msg1);
//  		res.setMessages(messageList);
//  		
//        doReturn(res).when(requestBodyHelper).send(sendMailReq);
//
//        EmailNotificationResponse result = sendEmailService.sendInviteEmail(request);
//
//      assertEquals("failure", result.getStatus());
//      assertEquals("MailJet API call failed :{}", result.getMessage());
//    }
//
//}
//
//    