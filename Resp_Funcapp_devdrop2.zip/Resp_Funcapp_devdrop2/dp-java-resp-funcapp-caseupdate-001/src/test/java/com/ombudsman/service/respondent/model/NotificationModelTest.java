package com.ombudsman.service.respondent.model;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.Test;

import com.ombudsman.service.repondent.model.NotificationModel;

public class NotificationModelTest {

    @Test
    public void testNotificationModel() {
        NotificationModel notification = new NotificationModel();
        
        Long notificationId = 12345L;
        String requestId = "req-67890";
        String userOid = "user-oid";
        String requestingActivityName = "activity-name";
        String message = "Test message";
        String notificationStatusId = "status-id";
        String notificationStatusDescription = "Status description";
        String fileDownloadUrl = "http://example.com/download";
        String modifiedBy = "user-mod";
        String createdOn = "2023-01-01";
        String createdBy = "user-create";
        String modifiedOn = "2023-01-02";

        notification.setNotification_id(notificationId);
        notification.setRequest_id(requestId);
        notification.setUser_oid(userOid);
        notification.setRequesting_activity_name(requestingActivityName);
        notification.setMessage(message);
        notification.setNotification_status_id(notificationStatusId);
        notification.setNotification_status_description(notificationStatusDescription);
        notification.setFile_download_url(fileDownloadUrl);
        notification.setModified_by(modifiedBy);
        notification.setCreated_on(createdOn);
        notification.setCreated_by(createdBy);
        notification.setModified_on(modifiedOn);

        assertNotNull(notification);
        assertEquals(notificationId, notification.getNotification_id());
        assertEquals(requestId, notification.getRequest_id());
        assertEquals(userOid, notification.getUser_oid());
        assertEquals(requestingActivityName, notification.getRequesting_activity_name());
        assertEquals(message, notification.getMessage());
        assertEquals(notificationStatusId, notification.getNotification_status_id());
        assertEquals(notificationStatusDescription, notification.getNotification_status_description());
        assertEquals(fileDownloadUrl, notification.getFile_download_url());
        assertEquals(modifiedBy, notification.getModified_by());
        assertEquals(createdOn, notification.getCreated_on());
        assertEquals(createdBy, notification.getCreated_by());
        assertEquals(modifiedOn, notification.getModified_on());
    }
}
