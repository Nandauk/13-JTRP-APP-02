package com.ombudsman.service.respondent.model;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.time.OffsetDateTime;

import org.junit.jupiter.api.Test;

import com.ombudsman.service.repondent.model.RequestModel;

public class RequestModelTest {

    @Test
    public void testRequestModel() {
        RequestModel requestModel = new RequestModel();

        String requestId = "req-12345";
        String userOid = "user-12345";
        String requestingActivityName = "activity-12345";
        Integer requestStatusId = 1;
        String requestStatusDescription = "Pending";
        String requestProcessingDetails = "Processing details";
        OffsetDateTime requestStartTime = OffsetDateTime.now();
        OffsetDateTime requestFinishTime = OffsetDateTime.now().plusHours(1);
        Integer requestProcessingCounter = 5;
        OffsetDateTime createdOn = OffsetDateTime.now();
        String createdBy = "creator-12345";
        String modifiedOn = "2025-01-10T18:13:00+01:00";
        String modifiedBy = "modifier-12345";

        requestModel.setRequestId(requestId);
        requestModel.setUserOid(userOid);
        requestModel.setRequestingActivityName(requestingActivityName);
        requestModel.setRequestStatusId(requestStatusId);
        requestModel.setRequestStatusDescription(requestStatusDescription);
        requestModel.setRequestProcessingDetails(requestProcessingDetails);
        requestModel.setRequestStartTime(requestStartTime);
        requestModel.setRequestFinishTime(requestFinishTime);
        requestModel.setRequestProcessingCounter(requestProcessingCounter);
        requestModel.setCreatedOn(createdOn);
        requestModel.setCreatedBy(createdBy);
        requestModel.setModifiedOn(modifiedOn);
        requestModel.setModifiedBy(modifiedBy);

        assertNotNull(requestModel);
        assertEquals(requestId, requestModel.getRequestId());
        assertEquals(userOid, requestModel.getUserOid());
        assertEquals(requestingActivityName, requestModel.getRequestingActivityName());
        assertEquals(requestStatusId, requestModel.getRequestStatusId());
        assertEquals(requestStatusDescription, requestModel.getRequestStatusDescription());
        assertEquals(requestProcessingDetails, requestModel.getRequestProcessingDetails());
        assertEquals(requestStartTime, requestModel.getRequestStartTime());
        assertEquals(requestFinishTime, requestModel.getRequestFinishTime());
        assertEquals(requestProcessingCounter, requestModel.getRequestProcessingCounter());
        assertEquals(createdOn, requestModel.getCreatedOn());
        assertEquals(createdBy, requestModel.getCreatedBy());
        assertEquals(modifiedOn, requestModel.getModifiedOn());
        assertEquals(modifiedBy, requestModel.getModifiedBy());
    }
}
