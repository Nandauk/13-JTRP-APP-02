package com.ombudsman.service.respondent.model;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.ombudsman.service.repondent.model.QueueData;

public class QueueDataTest {

    private QueueData queueData;

    @BeforeEach
    public void setUp() {
        queueData = new QueueData();
    }

    @Test
    public void testAll() {
        // Test queueid
        String queueid = "Q123";
        queueData.setQueueid(queueid);
        assertEquals(queueid, queueData.getQueueid());

        // Test description
        String description = "This is a description";
        queueData.setDescription(description);
        assertEquals(description, queueData.getDescription());

        // Test name
        String name = "Queue Name";
        queueData.setName(name);
        assertEquals(name, queueData.getName());

        // Test _ownerid_value
        String owneridValue = "Owner123";
        queueData.setOwneridValue(owneridValue);
        assertEquals(owneridValue, queueData.getOwneridValue());
        queueData.toString();
        
    }
}
