package com.ombudsman.service.respondent.model;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.List;

import org.apache.logging.log4j.Logger;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.ombudsman.service.repondent.model.From;
import com.ombudsman.service.repondent.model.MailjetVariables;
import com.ombudsman.service.repondent.model.Messages;
import com.ombudsman.service.repondent.model.SendMailDetails;
import com.ombudsman.service.repondent.model.SendMailReq;
import com.ombudsman.service.repondent.model.To;
import com.ombudsman.service.respondent.helper.RequestBodyHelper;

public class RequestBodyHelperTest {

    private RequestBodyHelper requestBodyHelper;

    @Mock
    private Logger log;
    
   

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
        requestBodyHelper = new RequestBodyHelper();
        
  
    }

   
//    @Test
//    public void testContructSendEmailBody() {
//        // Test constructing send email body
//        String templateName = "template";
//        String email = "test@example.com";
//        String fullName = "Test User";
//        int templateId = 123;
//        String ticketNumber = "PNX12345";
//        String reasonForChange = "System Update";
//        SendMailDetails request = new SendMailDetails();
//        request.setEmail(email);
//        request.setFullName(fullName);
//        request.setReasonForChange(reasonForChange);
//        request.setTemplateId(templateId);
//        request.setTemplateName(templateName);
//        request.setTicketNumber(ticketNumber);
//        
//        SendMailReq sendMailReq = requestBodyHelper.contructSendEmailBody(request);
//        
//        assertNotNull(sendMailReq);
//        List<Messages> messages = sendMailReq.getMessages();
//        assertNotNull(messages);
//        assertEquals(1, messages.size());
//
//        Messages message = messages.get(0);
//        assertEquals(templateId, message.getTemplateID());
//        assertEquals(templateName, message.getName());
//        assertTrue(message.isTemplateLanguage());
//        
//        From from = message.getFrom();
//        assertNotNull(from);
//        assertEquals(System.getenv("MAILJET_FROM_EMAIL"), from.getFromEmail());
//        assertEquals(System.getenv("MAILJET_SERVER_NAME"), from.getFromName());
//
//        MailjetVariables var = message.getVar();
//        assertNotNull(var);
//        assertEquals(ticketNumber, var.getTicketNumber());
//        assertEquals(reasonForChange, var.getReasonForChange());
//        
//        List<To> to = message.getTo();
//        assertNotNull(to);
//        assertEquals(1, to.size());
//        
//        To toEmailAddress = to.get(0);
//        assertEquals(email, toEmailAddress.getToEmail());
//        assertEquals(fullName, toEmailAddress.getToName());
//    }
//    
   
}
