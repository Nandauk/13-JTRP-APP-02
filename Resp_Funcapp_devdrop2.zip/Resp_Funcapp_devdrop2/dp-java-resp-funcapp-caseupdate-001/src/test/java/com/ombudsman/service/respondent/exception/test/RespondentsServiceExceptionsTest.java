package com.ombudsman.service.respondent.exception.test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.Test;

import com.ombudsman.service.respondent.exception.RespondentsServiceExceptions;

public class RespondentsServiceExceptionsTest {

    @Test
    public void testRespondentsServiceExceptions() {
        String message = "Service error";
        String code = "RESPONDENT_ERROR_CODE";
        String exceptionMessage = "Detailed error message";
        StackTraceElement[] stackTrace = new StackTraceElement[] {
            new StackTraceElement("className", "methodName", "fileName", 123)
        };

        RespondentsServiceExceptions exception = new RespondentsServiceExceptions(message, code, exceptionMessage, stackTrace);

        assertNotNull(exception);
        assertEquals(message, exception.getMessage());
        assertEquals(code, exception.getCode());
        assertEquals(exceptionMessage, exception.getExceptionMessage());
        assertEquals(stackTrace, exception.getStackTraceMessage());
    }
}
