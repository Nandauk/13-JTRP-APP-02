package com.ombudsman.service.respondent.model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.ombudsman.service.repondent.model.MailjetResponseBody;

public class MailjetResponseBodyTest {

    private MailjetResponseBody mailjetResponseBody;

    @BeforeEach
    public void setUp() {
        mailjetResponseBody = new MailjetResponseBody();
    }

    @Test
    public void testMessages() {
        MailjetResponseBody.Message message = new MailjetResponseBody.Message();
        message.setStatus("Delivered");
        message.setCustomID("custom123");
        
        List<MailjetResponseBody.Message> messages = new ArrayList<>();
        messages.add(message);
        
        mailjetResponseBody.setMessages(messages);
        assertEquals(messages, mailjetResponseBody.getMessages());
        assertEquals("Message :" + messages, mailjetResponseBody.toString());
    }

    @Test
    public void testMessageStatus() {
        MailjetResponseBody.Message message = new MailjetResponseBody.Message();
        String status = "Delivered";
        message.setStatus(status);
        assertEquals(status, message.getStatus());
    }

    @Test
    public void testMessageCustomID() {
        MailjetResponseBody.Message message = new MailjetResponseBody.Message();
        String customID = "custom123";
        message.setCustomID(customID);
        assertEquals(customID, message.getCustomID());
    }

    @Test
    public void testMessageRecipientsTo() {
        MailjetResponseBody.Message message = new MailjetResponseBody.Message();
        MailjetResponseBody.Recipient recipient = new MailjetResponseBody.Recipient();
        recipient.setEmail("to@example.com");
        
        List<MailjetResponseBody.Recipient> recipients = new ArrayList<>();
        recipients.add(recipient);
        
        message.setTo(recipients);
        assertEquals(recipients, message.getTo());
    }

    @Test
    public void testMessageRecipientsCc() {
        MailjetResponseBody.Message message = new MailjetResponseBody.Message();
        MailjetResponseBody.Recipient recipient = new MailjetResponseBody.Recipient();
        recipient.setEmail("cc@example.com");
        
        List<MailjetResponseBody.Recipient> recipients = new ArrayList<>();
        recipients.add(recipient);
        
        message.setCc(recipients);
        assertEquals(recipients, message.getCc());
    }

    @Test
    public void testMessageRecipientsBcc() {
        MailjetResponseBody.Message message = new MailjetResponseBody.Message();
        MailjetResponseBody.Recipient recipient = new MailjetResponseBody.Recipient();
        recipient.setEmail("bcc@example.com");
        
        List<MailjetResponseBody.Recipient> recipients = new ArrayList<>();
        recipients.add(recipient);
        
        message.setBcc(recipients);
        assertEquals(recipients, message.getBcc());
    }

    @Test
    public void testRecipientEmail() {
        MailjetResponseBody.Recipient recipient = new MailjetResponseBody.Recipient();
        String email = "recipient@example.com";
        recipient.setEmail(email);
        assertEquals(email, recipient.getEmail());
    }

    @Test
    public void testRecipientMessageUUID() {
        MailjetResponseBody.Recipient recipient = new MailjetResponseBody.Recipient();
        String messageUUID = "uuid123";
        recipient.setMessageUUID(messageUUID);
        assertEquals(messageUUID, recipient.getMessageUUID());
    }

    @Test
    public void testRecipientMessageID() {
        MailjetResponseBody.Recipient recipient = new MailjetResponseBody.Recipient();
        long messageID = 123456L;
        recipient.setMessageID(messageID);
        assertEquals(messageID, recipient.getMessageID());
    }

    @Test
    public void testRecipientMessageHref() {
        MailjetResponseBody.Recipient recipient = new MailjetResponseBody.Recipient();
        String messageHref = "href123";
        recipient.setMessageHref(messageHref);
        assertEquals(messageHref, recipient.getMessageHref());
    }

    @Test
    public void testMessageToString() {
        MailjetResponseBody.Message message = new MailjetResponseBody.Message();
        message.setStatus("Delivered");
        message.setCustomID("custom123");

        MailjetResponseBody.Recipient recipient = new MailjetResponseBody.Recipient();
        recipient.setEmail("to@example.com");
        
        List<MailjetResponseBody.Recipient> toRecipients = new ArrayList<>();
        toRecipients.add(recipient);
        message.setTo(toRecipients);

        List<MailjetResponseBody.Recipient> ccRecipients = new ArrayList<>();
        ccRecipients.add(recipient);
        message.setCc(ccRecipients);

        List<MailjetResponseBody.Recipient> bccRecipients = new ArrayList<>();
        bccRecipients.add(recipient);
        message.setBcc(bccRecipients);

        String expected = "Status: Delivered,CustomID: custom123,TO : " + toRecipients + " ,Cc : " + ccRecipients + " ,Bcc : " + bccRecipients;
        assertEquals(expected, message.toString());
    }

    @Test
    public void testRecipientToString() {
        MailjetResponseBody.Recipient recipient = new MailjetResponseBody.Recipient();
        recipient.setEmail("recipient@example.com");
        recipient.setMessageUUID("uuid123");
        recipient.setMessageID(123456L);
        recipient.setMessageHref("href123");

        String expected = " email: recipient@example.com, messageUUID: uuid123 ,messageID : 123456 ,messageHref : href123";
        assertEquals(expected, recipient.toString());
    }
}
