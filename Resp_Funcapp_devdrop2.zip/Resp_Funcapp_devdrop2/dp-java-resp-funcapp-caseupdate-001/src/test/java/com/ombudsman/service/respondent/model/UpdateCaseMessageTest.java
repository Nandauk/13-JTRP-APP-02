package com.ombudsman.service.respondent.model;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.ombudsman.service.repondent.model.UpdateCaseMessage;

public class UpdateCaseMessageTest {

    private UpdateCaseMessage updateCaseMessage;

    @BeforeEach
    public void setUp() {
        updateCaseMessage = new UpdateCaseMessage();
    }

    @Test
    public void testAll() {
        // Test activityId
        String activityId = "ACT123";
        updateCaseMessage.setActivityId(activityId);
        assertEquals(activityId, updateCaseMessage.getActivityId());

        // Test ownerId
        String ownerId = "OWNER123";
        updateCaseMessage.setOwnerId(ownerId);
        assertEquals(ownerId, updateCaseMessage.getOwnerId());

        // Test regardingObjectIdIncidentFosPortal
        String regardingObjectIdIncidentFosPortal = "REG123";
        updateCaseMessage.setRegardingObjectIdIncidentFosPortal(regardingObjectIdIncidentFosPortal);
        assertEquals(regardingObjectIdIncidentFosPortal, updateCaseMessage.getRegardingObjectIdIncidentFosPortal());

        // Test subject
        String subject = "Test Subject";
        updateCaseMessage.setSubject(subject);
        assertEquals(subject, updateCaseMessage.getSubject());

        // Test fosOtherReasonForChange
        String fosOtherReasonForChange = "Other Reason";
        updateCaseMessage.setFosOtherReasonForChange(fosOtherReasonForChange);
        assertEquals(fosOtherReasonForChange, updateCaseMessage.getFosOtherReasonForChange());

        // Test description
        String description = "Test Description";
        updateCaseMessage.setDescription(description);
        assertEquals(description, updateCaseMessage.getDescription());

        // Test fosCapacity
        int fosCapacity = 10;
        updateCaseMessage.setFosCapacity(fosCapacity);
        assertEquals(fosCapacity, updateCaseMessage.getFosCapacity());

        // Test fosCategoryCode
        int fosCategoryCode = 20;
        updateCaseMessage.setFosCategoryCode(fosCategoryCode);
        assertEquals(fosCategoryCode, updateCaseMessage.getFosCategoryCode());

        // Test fosPackageId
        String fosPackageId = "PKG123";
        updateCaseMessage.setFosPackageId(fosPackageId);
        assertEquals(fosPackageId, updateCaseMessage.getFosPackageId());

        // Test fosReasonForChange
        int fosReasonForChange = 30;
        updateCaseMessage.setFosReasonForChange(fosReasonForChange);
        assertEquals(fosReasonForChange, updateCaseMessage.getFosReasonForChange());

        // Test fosBusinessResponse
        boolean fosBusinessResponse = true;
        updateCaseMessage.setFosBusinessResponse(fosBusinessResponse);
        assertTrue(updateCaseMessage.isFosBusinessResponse());

        // Test fosDpUserEmailAddress
        String fosDpUserEmailAddress = "test@example.com";
        updateCaseMessage.setFosDpUserEmailAddress(fosDpUserEmailAddress);
        assertEquals(fosDpUserEmailAddress, updateCaseMessage.getFosDpUserEmailAddress());

        // Test fosDpUserFullName
        String fosDpUserFullName = "Test User";
        updateCaseMessage.setFosDpUserFullName(fosDpUserFullName);
        assertEquals(fosDpUserFullName, updateCaseMessage.getFosDpUserFullName());

        // Test fosPortalActivityParties
        UpdateCaseMessage.FosPortalActivityParty party = new UpdateCaseMessage.FosPortalActivityParty();
        party.setType("Type");
        party.setPartyIdSystemUser("SystemUser123");
        party.setPartyIdContact("Contact123");
        party.setParticipationTypeMask(40);
        List<UpdateCaseMessage.FosPortalActivityParty> parties = Arrays.asList(party);
        updateCaseMessage.setFosPortalActivityParties(parties);
        assertEquals(parties, updateCaseMessage.getFosPortalActivityParties());
    }
}
