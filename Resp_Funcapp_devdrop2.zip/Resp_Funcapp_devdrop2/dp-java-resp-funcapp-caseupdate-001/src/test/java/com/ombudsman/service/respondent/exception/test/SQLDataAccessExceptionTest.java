package com.ombudsman.service.respondent.exception.test;

import org.springframework.dao.DataAccessException;

import com.ombudsman.service.respondent.exception.SQLDataAccessException;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.Test;

public class SQLDataAccessExceptionTest {

    @Test
    public void testSQLDataAccessException() {
        String orgName = "Organization Name";

        SQLDataAccessException exception = new SQLDataAccessException(orgName,"Messsage");

        assertNotNull(exception);
        assertEquals(orgName, exception.getMessage());
    }
}
