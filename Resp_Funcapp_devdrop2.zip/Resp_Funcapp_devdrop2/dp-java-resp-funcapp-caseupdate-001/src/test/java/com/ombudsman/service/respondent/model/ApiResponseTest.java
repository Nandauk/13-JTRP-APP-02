package com.ombudsman.service.respondent.model;

import org.springframework.http.HttpStatusCode;

import com.ombudsman.service.repondent.model.ApiResponse;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class ApiResponseTest {

    private ApiResponse apiResponse;

    @BeforeEach
    public void setUp() {
        apiResponse = new ApiResponse();
    }

    @Test
    public void testAll() {
        // Test success
        apiResponse.setSuccess(true);
        assertTrue(apiResponse.isSuccess());

        apiResponse.setSuccess(false);
        assertFalse(apiResponse.isSuccess());

        // Test message
        String message = "This is a test message";
        apiResponse.setMessage(message);
        assertEquals(message, apiResponse.getMessage());

        // Test status
        HttpStatusCode status = HttpStatusCode.valueOf(200);
        apiResponse.setStatus(status);
        assertEquals(status, apiResponse.getStatus());

        // Test data
        Object data = new Object();
        apiResponse.setData(data);
        assertEquals(data, apiResponse.getData());
    }
}
