package com.ombudsman.service.respondent.model;


import com.ombudsman.service.repondent.model.MailjetVariables;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class MailjetVariablesTest {

    private MailjetVariables mailjetVariables;

    @BeforeEach
    public void setUp() {
        mailjetVariables = new MailjetVariables();
    }

    @Test
    public void testAll() {
        // Test ticketNumber
        String ticketNumber = "PNX12345";
        mailjetVariables.setTicketNumber(ticketNumber);
        assertEquals(ticketNumber, mailjetVariables.getTicketNumber());

        // Test reasonForChange
        String reasonForChange = "System Update";
        mailjetVariables.setReasonForChange(reasonForChange);
        assertEquals(reasonForChange, mailjetVariables.getReasonForChange());
    }
}

