package com.ombudsman.service.respondent.exception.test;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.ombudsman.service.respondent.exception.ApiError;
import com.ombudsman.service.respondent.exception.GlobalExceptionHandler;
import com.ombudsman.service.respondent.exception.PhoenixServiceException;
import com.ombudsman.service.respondent.exception.RecordCreationException;
import com.ombudsman.service.respondent.exception.SQLDataAccessException;

import jakarta.servlet.http.HttpServletRequest;

public class GlobalExceptionHandlerTest {

    private GlobalExceptionHandler globalExceptionHandler;

    @Mock
    private HttpServletRequest request;

 

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.initMocks(this);
        globalExceptionHandler = new GlobalExceptionHandler();
     
    }

    @Test
    public void testHandleRecordCreationException() {
        Exception ex = new RecordCreationException("Error", null, null);

        ResponseEntity<ApiError> response = globalExceptionHandler.handleRecordCreationException(request, ex);

        assertEquals(HttpStatus.PRECONDITION_FAILED, response.getStatusCode());
        assertEquals("Phoenix record could not be created", response.getBody().getErrorMessage());
    }

    @Test
    public void testHandlePhoenixServiceException() {
        Exception ex = new PhoenixServiceException("Error", null);

        ResponseEntity<ApiError> response = globalExceptionHandler.handlePhoenixServiceException(request, ex);

        assertEquals(HttpStatus.PRECONDITION_FAILED, response.getStatusCode());
        assertEquals("Phoenix connection failure", response.getBody().getErrorMessage());
    }

    @Test
    public void testHandleSQLDataException() {
        Exception ex = new SQLDataAccessException("Error","Message");

        ResponseEntity<ApiError> response = globalExceptionHandler.handleSQLDataException(request, ex);

        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
        assertEquals("RESPONDENT_DB_1001", response.getBody().getErrorMessage());
    }
}
