package com.ombudsman.service.respondent.exception.test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.Test;

import com.ombudsman.service.respondent.exception.OrganizationNotFoundException;

public class OrganizationNotFoundExceptionTest {

    @Test
    public void testOrganizationNotFoundException() {
        String orgName = "Nonexistent Organization";

        OrganizationNotFoundException exception = new OrganizationNotFoundException(orgName);

        assertNotNull(exception);
        assertEquals(orgName, exception.getMessage());
    }
}

