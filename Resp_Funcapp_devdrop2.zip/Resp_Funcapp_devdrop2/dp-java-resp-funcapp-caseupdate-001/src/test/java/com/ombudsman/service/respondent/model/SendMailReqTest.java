package com.ombudsman.service.respondent.model;


import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.ombudsman.service.repondent.model.Messages;
import com.ombudsman.service.repondent.model.SendMailReq;

public class SendMailReqTest {

    private SendMailReq sendMailReq;
    private Messages message;

    @BeforeEach
    public void setUp() {
        sendMailReq = new SendMailReq();
        message = new Messages();
    }

    @Test
    public void testAll() {
        // Test Messages
        message.setTemplateID(123);
        message.setName("Template Name");

        List<Messages> messagesList = Arrays.asList(message);
        sendMailReq.setMessages(messagesList);
        
        assertEquals(messagesList, sendMailReq.getMessages());
    }
}
