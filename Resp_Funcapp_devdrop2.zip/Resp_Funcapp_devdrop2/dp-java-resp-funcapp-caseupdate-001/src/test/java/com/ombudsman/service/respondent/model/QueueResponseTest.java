package com.ombudsman.service.respondent.model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.ombudsman.service.repondent.model.QueueData;
import com.ombudsman.service.repondent.model.QueueResponse;

public class QueueResponseTest {

    private QueueResponse queueResponse;
    private QueueData queueData;

    @BeforeEach
    public void setUp() {
        queueResponse = new QueueResponse();
        queueData = new QueueData();
    }

    @Test
    public void testAll() {
        // Test QueueData
        String queueid = "Q123";
        String description = "This is a description";
        String name = "Queue Name";
        String owneridValue = "Owner123";

        queueData.setQueueid(queueid);
        queueData.setDescription(description);
        queueData.setName(name);
        queueData.setOwneridValue(owneridValue);

        assertEquals(queueid, queueData.getQueueid());
        assertEquals(description, queueData.getDescription());
        assertEquals(name, queueData.getName());
        assertEquals(owneridValue, queueData.getOwneridValue());

        // Test QueueResponse
        List<QueueData> value = Arrays.asList(queueData);
        queueResponse.setValue(value);
        queueResponse.toString();
        assertEquals(value, queueResponse.getValue());
    }
}

