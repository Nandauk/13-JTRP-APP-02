package com.ombudsman.service.respondent.exception.test;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.ombudsman.service.respondent.exception.RecordCreationException;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.Test;

public class RecordCreationExceptionTest {

    @Test
    public void testRecordCreationException() {
        String message = "Record creation error";
        String exceptionMessage = "Detailed error message";
        StackTraceElement[] stackTrace = new StackTraceElement[] {
            new StackTraceElement("className", "methodName", "fileName", 123)
        };

        RecordCreationException exception = new RecordCreationException(message, exceptionMessage, stackTrace);

        assertNotNull(exception);
        assertEquals(message, exception.getMessage());
        assertEquals("RESPONDENT_RECORD_CREATION_FAILED_1004", exception.getCode());
        assertEquals(exceptionMessage, exception.getExceptionMessage());
       // assertEquals(stackTrace, exception.getStackTrace());
    }
}

