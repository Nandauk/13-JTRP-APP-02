package com.ombudsman.service.respondent.model;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.ombudsman.service.repondent.model.From;
import com.ombudsman.service.repondent.model.MailjetVariables;
import com.ombudsman.service.repondent.model.Messages;
import com.ombudsman.service.repondent.model.To;

public class MessagesTest {

    private Messages messages;
    private From from;
    private To to;
    private MailjetVariables var;

    @BeforeEach
    public void setUp() {
        messages = new Messages();
        from = new From();
        to = new To();
        var = new MailjetVariables();
    }

    @Test
    public void testAll() {
        // Test From
        String fromEmail = "from@example.com";
        String fromName = "From Name";
        from.setFromEmail(fromEmail);
        from.setFromName(fromName);
        messages.setFrom(from);
        assertEquals(from, messages.getFrom());

        // Test To
        List<To> toList = Arrays.asList(to);
        messages.setTo(toList);
        assertEquals(toList, messages.getTo());

        // Test TemplateID
        int templateID = 123;
        messages.setTemplateID(templateID);
        assertEquals(templateID, messages.getTemplateID());

        // Test TemplateLanguage
        boolean templateLanguage = true;
        messages.setTemplateLanguage(templateLanguage);
        assertTrue(messages.isTemplateLanguage());

        // Test Variables
        String ticketNumber = "PNX12345";
        String reasonForChange = "System Update";
        var.setTicketNumber(ticketNumber);
        var.setReasonForChange(reasonForChange);
        messages.setVar(var);
        assertEquals(var, messages.getVar());

        // Test Name
        String name = "Test Name";
        messages.setName(name);
        assertEquals(name, messages.getName());
    }
}
