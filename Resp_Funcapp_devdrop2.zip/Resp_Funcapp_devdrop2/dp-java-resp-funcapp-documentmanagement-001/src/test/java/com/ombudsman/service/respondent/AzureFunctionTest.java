package com.ombudsman.service.respondent;

import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.ArgumentMatchers;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ombudsman.service.respondent.model.dto.UploadCompletedMessageDto;
import com.ombudsman.service.respondent.model.dto.UploadFileInfoDto;
import com.ombudsman.service.respondent.serviceimpl.ValidationServiceImpl;
import com.ombudsman.service.respondent.serviceimpl.VirusScanServiceImpl;

@ExtendWith(SpringExtension.class)
class AzureFunctionTest { 
	
	@InjectMocks 
	AzureFunction orchestrator; 
	
	@Mock 
	VirusScanServiceImpl virusService;
	
	@Mock
	 ValidationServiceImpl validationService;

	
	@Mock
	UploadCompletedMessageDto mockDto;
	
	@Mock
	ObjectMapper obj;
	
	
	@Test 
	public void testRunDurableFunc_PositiveScenario() throws Exception { 
		
		UploadCompletedMessageDto testInstance = new UploadCompletedMessageDto();
		 
		 int uploadRequestId = 12;
		 String caseId = "caseId";
		 String contactId = "mockValue";
		 String packageId = "mockValue";
		 String pnx = "mockValue";
		 String comments = "mockValue";
		 String userId = "mockValue";
		 String orgId = "mockValue";
		 String userEmail = "mockValue";
		 String userName = "mockValue";
		 String[] usersAccountIds = {"mock1","mock2"};
		 String subject = "mockValue";
		 int reasonForChange =12;
		

		 List<UploadFileInfoDto> files = new ArrayList<>();
		 UploadFileInfoDto data = new UploadFileInfoDto();
		 data.setDocumentId("doc1");
		 data.setFileName("file1");
		 files.add(data);

		 boolean isBusinessResponse =true;
		 String digitalPortalUserName ="mock";
		 String digitalPortalUserEmailAddress = "mock";
		 
		 testInstance.setCaseId(caseId);
		 testInstance.setComments(comments);
		 testInstance.setContactId(contactId);
		 testInstance.setDigitalPortalUserEmailAddress(digitalPortalUserEmailAddress);
		 testInstance.setDigitalPortalUserName(digitalPortalUserName);
		 testInstance.setFiles(files);
		 testInstance.setIsBusinessResponse(isBusinessResponse);
		// testInstance.setPortalType("Respondent");
		 testInstance.setOrgId(orgId);
		 testInstance.setPackageId(packageId);
		 testInstance.setPnx(pnx);
		 testInstance.setReasonForChange(reasonForChange);
		 testInstance.setSubject(subject);
		 testInstance.setUploadRequestId(uploadRequestId);
		 testInstance.setUserEmail(userEmail);
		 testInstance.setUserId(userId);
		 testInstance.setUserName(userName);
		 testInstance.setUsersAccountIds(usersAccountIds);
		 
		 String jsonRequest = "{"
				    + "\"caseId\":\"" + caseId + "\","
				    + "\"comments\":\"" + comments + "\","
				    + "\"contactId\":\"" + contactId + "\","
				    + "\"digitalPortalUserEmailAddress\":\"" + digitalPortalUserEmailAddress + "\","
				    + "\"digitalPortalUserName\":\"" + digitalPortalUserName + "\","
				    + "\"files\":["
				    + "{"
				    + "\"documentId\":\"" + data.getDocumentId() + "\","
				    + "\"fileName\":\"" + data.getFileName() + "\""
				    + "}"
				    + "],"
				    + "\"isBusinessResponse\":" + isBusinessResponse + ","
				   // + "\"portalType\":" + "portalType" + ","
				    + "\"orgId\":\"" + orgId + "\","
				    + "\"packageId\":\"" + packageId + "\","
				    + "\"pnx\":\"" + pnx + "\","
				    + "\"reasonForChange\":" + reasonForChange + ","
				    + "\"subject\":\"" + subject + "\","
				    + "\"uploadRequestId\":" + uploadRequestId + ","
				    + "\"userEmail\":\"" + userEmail + "\","
				    + "\"userId\":\"" + userId + "\","
				    + "\"userName\":\"" + userName + "\","
				    + "\"usersAccountIds\":[\"mock1\",\"mock2\"]"
				    + "}";

		 
		 List<String> da = new ArrayList<>();
		 da.add("file1");
		 when(validationService.preScanning(testInstance)).thenReturn(da);
		 orchestrator.runDurableFunc(jsonRequest);

	}
	
}