package com.ombudsman.service.repondent.model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.test.context.junit.jupiter.SpringExtension;

@ExtendWith(SpringExtension.class)
public class FoundVirusTest {

	@Test
	public void  testFoundVirus() {
		
		FoundVirus testInstance = new FoundVirus();
		
		String FileName = "mockVal";
		String VirusName = "mockVal";
		
		testInstance.setFileName(FileName);
		testInstance.setVirusName(VirusName);
		assertEquals(testInstance.getFileName(),FileName);
		 assertEquals(testInstance.getVirusName(),VirusName);
	}
	
}
