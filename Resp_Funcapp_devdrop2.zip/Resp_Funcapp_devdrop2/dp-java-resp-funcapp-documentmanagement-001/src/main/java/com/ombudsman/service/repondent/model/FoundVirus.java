package com.ombudsman.service.repondent.model;

import java.io.Serializable;

public class FoundVirus implements Serializable {

	 /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	String FileName;
	 String VirusName;
	public String getFileName() {
		return FileName;
	}
	public void setFileName(String fileName) {
		FileName = fileName;
	}
	public String getVirusName() {
		return VirusName;
	}
	public void setVirusName(String virusName) {
		VirusName = virusName;
	}
	
}
