package com.ombudsman.service.respondent.model.dto;

import java.util.List;

public class UploadCompletedMessageDto {
	private int uploadRequestId;
	private String caseId;
	private String contactId;
	private String packageId;
	private String pnx;
	private String comments;
	private String userId;
	private String orgId;
	private String userEmail;
	private String userName;
	private String[] usersAccountIds;
	private String subject;
	private int reasonForChange;
	

	private List<UploadFileInfoDto> files;

	private boolean isBusinessResponse;
	private String portalType;
	private String digitalPortalUserName;
	private String digitalPortalUserEmailAddress;

	
	public int getReasonForChange() {
		return reasonForChange;
	}

	public void setReasonForChange(int reasonForChange) {
		this.reasonForChange = reasonForChange;
	}

	public int getUploadRequestId() {
		return uploadRequestId;
	}

	public void setUploadRequestId(int uploadRequestId) {
		this.uploadRequestId = uploadRequestId;
	}

	public String getCaseId() {
		return caseId;
	}

	public void setCaseId(String caseId) {
		this.caseId = caseId;
	}

	public String getContactId() {
		return contactId;
	}

	public void setContactId(String contactId) {
		this.contactId = contactId;
	}

	public String getPackageId() {
		return packageId;
	}

	public void setPackageId(String packageId) {
		this.packageId = packageId;
	}

	public String getPnx() {
		return pnx;
	}

	public void setPnx(String pnx) {
		this.pnx = pnx;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getOrgId() {
		return orgId;
	}

	public void setOrgId(String orgId) {
		this.orgId = orgId;
	}

	public String getUserEmail() {
		return userEmail;
	}

	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String[] getUsersAccountIds() {
		return usersAccountIds;
	}

	public void setUsersAccountIds(String[] usersAccountIds) {
		this.usersAccountIds = usersAccountIds;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	

	public List<UploadFileInfoDto> getFiles() {
		return files;
	}

	public void setFiles(List<UploadFileInfoDto> files) {
		this.files = files;
	}

	public boolean getIsBusinessResponse() {
		return isBusinessResponse;
	}

	public void setIsBusinessResponse(boolean isBusinessResponse) {
		this.isBusinessResponse = isBusinessResponse;
	}
	public String getPortalType() {
		return portalType;
	}

	public void setPortalType(String portalType) {
		this.portalType = portalType;
	}

	public String getDigitalPortalUserName() {
		return digitalPortalUserName;
	}

	public void setDigitalPortalUserName(String digitalPortalUserName) {
		this.digitalPortalUserName = digitalPortalUserName;
	}

	public String getDigitalPortalUserEmailAddress() {
		return digitalPortalUserEmailAddress;
	}

	public void setDigitalPortalUserEmailAddress(String digitalPortalUserEmailAddress) {
		this.digitalPortalUserEmailAddress = digitalPortalUserEmailAddress;
	}

}
