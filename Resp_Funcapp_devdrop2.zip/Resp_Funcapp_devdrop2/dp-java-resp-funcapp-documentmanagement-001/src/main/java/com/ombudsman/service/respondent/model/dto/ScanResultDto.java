package com.ombudsman.service.respondent.model.dto;

public class ScanResultDto {

	private String fileName ;
    private String documentId ;
    private boolean clean;
    private String comment ;
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public String getDocumentId() {
		return documentId;
	}
	public void setDocumentId(String documentId) {
		this.documentId = documentId;
	}
	public boolean getClean() {
		return clean;
	}
	public void setClean(boolean clean) {
		this.clean = clean;
	}
	public String getComment() {
		return comment;
	}
	public void setComment(String comment) {
		this.comment = comment;
	}
    
    
	
    
}
