package com.ombudsman.service.respondent.model.dto;

public class UploadFileInfoDto {

	private String documentId;
	private String fileName;
	private String confidentialFlag;

	public String getConfidentialFlag() {
		return confidentialFlag;
	}

	public void setConfidentialFlag(String confidentialFlag) {
		this.confidentialFlag = confidentialFlag;
	}

	public String getDocumentId() {
		return documentId;
	}

	public void setDocumentId(String documentId) {
		this.documentId = documentId;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	

}
