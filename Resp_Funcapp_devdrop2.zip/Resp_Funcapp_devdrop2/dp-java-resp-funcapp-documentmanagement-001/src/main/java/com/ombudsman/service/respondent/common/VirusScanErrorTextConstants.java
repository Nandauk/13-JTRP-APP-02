package com.ombudsman.service.respondent.common;

import java.util.HashMap;
import java.util.Map;

public class VirusScanErrorTextConstants {

	private static final Map<String, String> errorTextMap = new HashMap<>();
	static {
		errorTextMap.put(VirusScanConstants.CONTAINS_EXECUTABLE_FIELD_NAME, VirusScanConstants.CONTAINS_EXECUTABLE);
		errorTextMap.put(VirusScanConstants.CONTAINS_INVALID_FILE_FIELD_NAME, VirusScanConstants.CONTAINS_INVALID_FILE);
		errorTextMap.put(VirusScanConstants.CONTAINS_MACROS_FIELD_NAME, VirusScanConstants.CONTAINS_MACROS);
		errorTextMap.put(VirusScanConstants.CONTAINS_Ps_PROTECTED_FILE_FIELD_NAME,
				VirusScanConstants.CONTAINS_Ps_PROTECTED_FILE);
		errorTextMap.put(VirusScanConstants.CONTAINS_RESTRICTED_FILE_FORMAT_FIELD_NAME,
				VirusScanConstants.CONTAINS_RESTRICTED_FILE_FORMAT);

		errorTextMap.put(VirusScanConstants.CONTAINS_SCRIPT_FIELD_NAME, VirusScanConstants.CONTAINS_SCRIPT);

		errorTextMap.put(VirusScanConstants.CONTAINS_HTML_FIELD_NAME, VirusScanConstants.CONTAINS_HTML);
		errorTextMap.put(VirusScanConstants.CONTAINS_XML_EXTERNAL_ENTITIES_FIELD_NAME,
				VirusScanConstants.CONTAINS_XML_EXTERNAL_ENTITIES);
		errorTextMap.put(VirusScanConstants.CONTAINS_INSECURE_DESERIALIZATION_FIELD_NAME,
				VirusScanConstants.CONTAINS_INSECURE_DESERIALIZATION);
		errorTextMap.put(VirusScanConstants.CONTAINS_UNSAFE_ARCHIVE_FIELD_NAME,
				VirusScanConstants.CONTAINS_UNSAFE_ARCHIVE);
	}

	public static String getErrorText(String propertyName) {
		return errorTextMap.getOrDefault(propertyName, "unknown failure");
	}

}
