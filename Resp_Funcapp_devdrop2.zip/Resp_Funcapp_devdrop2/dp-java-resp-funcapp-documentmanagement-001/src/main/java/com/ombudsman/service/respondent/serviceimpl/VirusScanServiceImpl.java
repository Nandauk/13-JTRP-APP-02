package com.ombudsman.service.respondent.serviceimpl;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpRequest.BodyPublishers;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.concurrent.ExecutionException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ombudsman.service.repondent.model.CloudmersivePayload;
import com.ombudsman.service.repondent.model.ContentInformation;
import com.ombudsman.service.respondent.helper.VirusServiceHelper;
import com.ombudsman.service.respondent.model.dto.ScanResultDto;
import com.ombudsman.service.respondent.model.request.VirusScanResponse;
import com.ombudsman.service.respondent.service.VirusScanService;

@Service
public class VirusScanServiceImpl implements VirusScanService {
	private static final boolean TRUE = true;
	Logger log = LogManager.getRootLogger();
	VirusServiceHelper virusHelper =new VirusServiceHelper();

	@Override
	public ScanResultDto virusScanClientActivity(CloudmersivePayload payload)
			throws InterruptedException, ExecutionException, IOException {
		log.info(String.format("VirusScanClientActivity Method started  :-%s", payload));
		HttpClient client = HttpClient.newBuilder().connectTimeout(Duration.ofMillis(Long.parseLong("300000"))).build();
		log.info(String.format("Sending payload and client as a param to ScanBlob Method  :: client {}", client));
		return scanBlob(payload, client);
	}
	
	@Override
	public ScanResultDto scanBlob(CloudmersivePayload payload, HttpClient client)
			throws InterruptedException, ExecutionException, IOException {
		ScanResultDto scanResultDto = new ScanResultDto();
		scanResultDto.setDocumentId(payload.getDocumentId());
		log.info(String.format("scanBlob Method started  with document id :-%s", payload.getDocumentId()));
		if (!payload.isScanEnabled()) {
			log.info(String.format("scanBlob Method payload.isScanEnabled() :-%s", payload.isScanEnabled()));
			scanResultDto.setClean(true);
			return scanResultDto;
		}
		VirusScanResponse scanResponse = performScan(payload, client);
		scanResultDto.setClean(scanResponse.getCleanResult());
		scanResultDto.setComment(virusHelper.getResultInformation(scanResponse));
		log.info(String.format("scanBlob Method with Successful status  :-%s", scanResponse.getSuccessful()));
		log.info(String.format("scanBlob Method with Comment which getting from cloud mersive :-%s", scanResultDto.getComment()));
		log.info(String.format("scanBlob Method with clean status  :-%s", scanResultDto.getClean()));
		return scanResultDto;
	}
	
	@Override
	public CloudmersivePayload initializePayload() {

		log.info(String.format(" Start initializePayload with all clould mersive connectivity details "));
		CloudmersivePayload payload = new CloudmersivePayload();
		payload.setApikey(System.getenv("ApiKey"));
		payload.setConnectionString(System.getenv("Cloudmersive_ConnectionString"));
		payload.setContainerName(System.getenv("SCAN_CONTAINER"));
		payload.setScanUrl(System.getenv("ScanUrl"));// https://apim-dev.financial-ombudsman.org.uk/cloudmersive
		payload.setScanEnabled(TRUE);
		return payload;
	}


	public VirusScanResponse performScan(CloudmersivePayload payload, HttpClient client) {
		VirusScanResponse data = new VirusScanResponse();
		ContentInformation info = new ContentInformation();
		try {
			log.info(String.format("performScan method for clould mercive webClient is started "));
			log.info(" http clinet POST  ");
			URI url = URI.create(payload.getScanUrl());
			ObjectMapper objectMapper = new ObjectMapper();
			String json = objectMapper.writeValueAsString(payload);
			HttpRequest request = HttpRequest.newBuilder().uri(url).header("Content-Type", "application/json")
					.header("connectionString", payload.getConnectionString())
					.header("containerName", payload.getContainerName()).header("blobPath", payload.getBlobPath())
					.header("Apikey", payload.getApikey()).header("Ocp-Apim-Subscription-Key", System.getenv("Subscription_Key"))
					.POST(BodyPublishers.ofString(json)).build();

			HttpResponse<String> send = client.send(request, HttpResponse.BodyHandlers.ofString());
			String body = send.body();
			ObjectMapper mapper = new ObjectMapper();
			log.info("http client send success ");
			JsonNode readTree = mapper.readTree(body);
			log.info(String.format("readTree  :-%s", readTree));
			
			data.setSuccessful(readTree.get("Successful").asBoolean());
			log.info(String.format("successful  :-%s", readTree.get("Successful").asBoolean()));

			data.setCleanResult(readTree.get("CleanResult").asBoolean());
			log.info(String.format("cleanResult  :-%s", readTree.get("CleanResult").asBoolean()));

			data.setContainsExecutable(readTree.get("ContainsExecutable").asBoolean());
			log.info(String.format("containsExecutable  :-%s", readTree.get("ContainsExecutable").asBoolean()));

			data.setContainsInvalidFile(readTree.get("ContainsInvalidFile").asBoolean());
			log.info(String.format("containsInvalidFile  :-%s", readTree.get("ContainsInvalidFile").asBoolean()));

			data.setContainsScript(readTree.get("ContainsScript").asBoolean());
			log.info(String.format("containsScript  :-%s", readTree.get("ContainsScript").asBoolean()));

			data.setContainsPasswordProtectedFile(readTree.get("ContainsPasswordProtectedFile").asBoolean());
			log.info(String.format("containsPasswordProtectedFile  :-%s", readTree.get("ContainsPasswordProtectedFile").asBoolean()));

			data.setContainsRestrictedFileFormat(readTree.get("ContainsRestrictedFileFormat").asBoolean());
			log.info(String.format("containsRestrictedFileFormat  :-%s", readTree.get("ContainsRestrictedFileFormat").asBoolean()));

			data.setContainsMacros(readTree.get("ContainsMacros").asBoolean());
			log.info(String.format("containsMacros  :-%s", readTree.get("ContainsMacros").asBoolean()));

			data.setVerifiedFileFormat(readTree.get("VerifiedFileFormat").asText());
			log.info(String.format("verifiedFileFormat  :-%s", readTree.get("VerifiedFileFormat").asText()));

			data.setFoundViruses(readTree.get("FoundViruses").asText());
			log.info(String.format("foundViruses  :-%s", readTree.get("FoundViruses").asText()));

			data.setErrorDetailedDescription(readTree.get("ErrorDetailedDescription").asText());
			log.info(String.format("errorDetailedDescription  m:-%s", readTree.get("ErrorDetailedDescription").asText()));

			data.setFileSize(readTree.get("FileSize").asInt());
			log.info(String.format("fileSize  :-%s", readTree.get("FileSize").asInt()));

			data.setContentInformation(info);

			log.info(String.format("Posting getcloudMersive in Connectivity success with getSuccessful():-%s", data.getSuccessful()));
			log.info(String.format("Posting getcloudMersive in Connectivity success with cleanResult() :-%s", data.getCleanResult()));
			log.info(String.format("Posting getcloudMersive in Connectivity success with error mag() :-%s",
					data.getErrorDetailedDescription()));
			return data;
		}  catch (Exception e) {
			log.info(String.format("Posting getcloudMersive in Connectivity Failed:-%s ", e.getMessage()));
		}
		return data;
	}

}
