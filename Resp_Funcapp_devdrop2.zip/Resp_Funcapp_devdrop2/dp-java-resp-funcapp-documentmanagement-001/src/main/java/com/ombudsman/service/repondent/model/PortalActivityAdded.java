package com.ombudsman.service.repondent.model;

import com.sun.jna.platform.win32.Guid;

public class PortalActivityAdded {

	
	 private Guid recordId ;
	 private Guid packageId ;
	 private String[] usersAccountIds ;
	 private int reasonForChange ;
	 private boolean isBusinessResponse ;
	 private String portalType ;
	 private String comments ;
	 private Guid fromContactId ;
	 private String digitalPortalUserName ;
	 private String digitalPortalUserEmailAddress ;
	public Guid getRecordId() {
		return recordId;
	}
	public void setRecordId(Guid recordId) {
		this.recordId = recordId;
	}
	public Guid getPackageId() {
		return packageId;
	}
	public void setPackageId(Guid packageId) {
		this.packageId = packageId;
	}
	public String[] getUsersAccountIds() {
		return usersAccountIds;
	}
	public void setUsersAccountIds(String[] usersAccountIds) {
		this.usersAccountIds = usersAccountIds;
	}
	public int getReasonForChange() {
		return reasonForChange;
	}
	public void setReasonForChange(int reasonForChange) {
		this.reasonForChange = reasonForChange;
	}
	public boolean isBusinessResponse() {
		return isBusinessResponse;
	}
	public void setBusinessResponse(boolean isBusinessResponse) {
		this.isBusinessResponse = isBusinessResponse;
	}
	
	public String getPortalType() {
		return portalType;
	}
	public void setPortalType(String portalType) {
		this.portalType = portalType;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	public Guid getFromContactId() {
		return fromContactId;
	}
	public void setFromContactId(Guid fromContactId) {
		this.fromContactId = fromContactId;
	}
	public String getDigitalPortalUserName() {
		return digitalPortalUserName;
	}
	public void setDigitalPortalUserName(String digitalPortalUserName) {
		this.digitalPortalUserName = digitalPortalUserName;
	}
	public String getDigitalPortalUserEmailAddress() {
		return digitalPortalUserEmailAddress;
	}
	public void setDigitalPortalUserEmailAddress(String digitalPortalUserEmailAddress) {
		this.digitalPortalUserEmailAddress = digitalPortalUserEmailAddress;
	}
	 
	 
	
     
}
