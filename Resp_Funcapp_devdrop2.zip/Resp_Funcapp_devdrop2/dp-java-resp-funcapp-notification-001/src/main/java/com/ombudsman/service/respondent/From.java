package com.ombudsman.service.respondent;

import com.google.gson.annotations.SerializedName;

   
public class From {

   @SerializedName("Email")
   String Email;

   @SerializedName("Name")
   String Name;


    public void setEmail(String Email) {
        this.Email = Email;
    }
    public String getEmail() {
        return Email;
    }
    
    public void setName(String Name) {
        this.Name = Name;
    }
    public String getName() {
        return Name;
    }
    
}