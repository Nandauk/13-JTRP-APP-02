package com.ombudsman.service.respondent;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.test.context.junit.jupiter.SpringExtension;

@ExtendWith(SpringExtension.class)
public class MessagesTest {
	
	@InjectMocks
	Messages mMockMessages;
	
	@Test
	public void testGetterAndSetter() {
		List<To> tolist = new ArrayList<>();
		From from = new From();
		from.setEmail("email");
		from.setName("name");
		tolist.add(new To());
		mMockMessages.setTo(tolist);
		mMockMessages.setFrom(from);
		mMockMessages.setTemplateID(1);
		mMockMessages.setTemplateLanguage(false);
		mMockMessages.setName("name");
		
		assertEquals(tolist,mMockMessages.getTo());
		assertEquals(from,mMockMessages.getFrom());
		assertEquals(1,mMockMessages.getTemplateID());
		assertEquals(false,mMockMessages.getTemplateLanguage());
		assertEquals("name",mMockMessages.getName());
		
		
	}

}
