package com.ombudsman.service.respondent;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.Mockito.when;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.json.JSONException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.mockito.stubbing.OngoingStubbing;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.azure.storage.blob.BlobClient;
import com.azure.storage.blob.BlobContainerClient;
import com.microsoft.azure.functions.ExecutionContext;
import com.microsoft.azure.functions.annotation.TimerTrigger;
import com.sun.jdi.connect.spi.Connection;


import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;
import java.util.logging.Logger;



import java.sql.SQLException;
import java.util.Arrays;
import java.util.HashMap;



@ExtendWith(SpringExtension.class)
public class NotificationAzureFunctionTest {

	@InjectMocks
	NotificationAzureFunction mMockNotificationAzureFunction;

	@Mock
	ExecutionContext context;
	
    @Mock
    BlobContainerClient containerClient;

    @Mock
    BlobClient blobClient;

	@Mock
	JdbcTemplate jdbcTemplate;
	@Captor
	ArgumentCaptor<Object[]> objCap;
	@Captor
	ArgumentCaptor<int[]> intCap;
	

	    @Mock
	    private Connection mockConnection;

	    @Mock
	    private PreparedStatement mockPreparedStatement;

	    @Mock
	    private ResultSet mockResultSet;
	    
	   


	 
	@BeforeEach
	public void setUp() {
		MockitoAnnotations.openMocks(this);
	}

	@Spy
	private final NotificationAzureFunction testInstance = new NotificationAzureFunction() {

		@Override
		public void updateDownladRequest(NotificationDownloadRequest reqObject, JdbcTemplate jdbcTemplate,
				String downloadreqId) {

		}

		@Override
		public String send(SendMailReq req) throws JSONException {
			return "SUCCESS";
		}

		@Override
		public boolean delFile(List<String> fileNames, String sourceContainerName) {
			return true;
		}
	};

	@Test
	void notificationdownloadTest() {
		DocumentsListReq message = new DocumentsListReq();
		message.setInstanceId("testInstance");
		message.setRequestId("testRequestId");
		message.setNotificationId("testNotificationId");

		List<NotificationDownloadRequest> lst1 = new ArrayList<NotificationDownloadRequest>();
		NotificationDownloadRequest req1 = new NotificationDownloadRequest();
		req1.setDocumentId("testDocumentId");
		req1.setErrorMessage(null);
		req1.setFileName("testFile");
		req1.setIsSuccessful(true);
		req1.setUrl("testURL");
		lst1.add(req1);
		message.setDocuments(lst1);
		ExecutionContext context = mock(ExecutionContext.class);

		Object[] paramToCheckNullCount = new Object[] { "testRequestId" };

		String sqlGetDownloadFortatusNull = "select count(*) from dp_download_request_items where status is NULL and download_request_id = ?";
		String sqlGetTotalFilesCount = "select count(*) from dp_download_request_items where download_request_id = ?";
		String sqlRequestProcessingCounter = "select request_processing_counter from [dbo].[dp_user_request] where request_id = ?";
		String sqlGetDownloadStatus = "select count(*) from dp_download_request_items where status != 'SUCCESS' and download_request_id = ?";
		when(jdbcTemplate.queryForObject(sqlGetDownloadFortatusNull, Integer.class, paramToCheckNullCount))
				.thenReturn(0);
		when(jdbcTemplate.queryForObject(sqlGetTotalFilesCount, Integer.class, paramToCheckNullCount)).thenReturn(1);
		when(jdbcTemplate.queryForObject(sqlRequestProcessingCounter, Integer.class, paramToCheckNullCount))
				.thenReturn(0);
		when(jdbcTemplate.queryForObject(sqlGetDownloadStatus, Integer.class, paramToCheckNullCount)).thenReturn(0);

		when(jdbcTemplate.update(Mockito.anyString(), objCap.capture())).thenReturn(1);

		testInstance.notificationdownload(message, context);
	}

	@Test
	void notificationdownloadTest1() {
		DocumentsListReq message = new DocumentsListReq();
		message.setInstanceId("testInstance");
		message.setRequestId("testRequestId");
		message.setNotificationId("testNotificationId");

		List<NotificationDownloadRequest> lst1 = new ArrayList<NotificationDownloadRequest>();
		NotificationDownloadRequest req1 = new NotificationDownloadRequest();
		req1.setDocumentId("testDocumentId");
		req1.setErrorMessage(null);
		req1.setFileName("testFile");
		req1.setIsSuccessful(true);
		req1.setUrl("testURL");
		lst1.add(req1);
		message.setDocuments(lst1);
		ExecutionContext context = mock(ExecutionContext.class);

		Object[] paramToCheckNullCount = new Object[] { "testRequestId" };

		String sqlGetDownloadFortatusNull = "select count(*) from dp_download_request_items where status is NULL and download_request_id = ?";
		String sqlGetTotalFilesCount = "select count(*) from dp_download_request_items where download_request_id = ?";
		String sqlRequestProcessingCounter = "select request_processing_counter from [dbo].[dp_user_request] where request_id = ?";
		String sqlGetDownloadStatus = "select count(*) from dp_download_request_items where status != 'SUCCESS' and download_request_id = ?";
		when(jdbcTemplate.queryForObject(sqlGetDownloadFortatusNull, Integer.class, paramToCheckNullCount))
				.thenReturn(0);
		when(jdbcTemplate.queryForObject(sqlGetTotalFilesCount, Integer.class, paramToCheckNullCount)).thenReturn(1);
		when(jdbcTemplate.queryForObject(sqlRequestProcessingCounter, Integer.class, paramToCheckNullCount))
				.thenReturn(0);
		when(jdbcTemplate.queryForObject(sqlGetDownloadStatus, Integer.class, paramToCheckNullCount)).thenReturn(0);

		when(jdbcTemplate.update(Mockito.anyString(), objCap.capture())).thenReturn(1);

		try {
			mMockNotificationAzureFunction.notificationdownload(message, context);
		} catch (Exception ex) {

		}
	}

	@Test
	void testPostAuditEntries() {
		String response = "SUCCESS";
		when(jdbcTemplate.update(Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(), Mockito.anyString(),
				Mockito.anyString())).thenReturn(1);

		mMockNotificationAzureFunction.postAuditEntries(jdbcTemplate);

		assertEquals("SUCCESS", response);
	}

	@Test
	void sendInviteToUserWebclient() {
		when(jdbcTemplate.queryForObject(Mockito.anyString(), Mockito.eq(String.class), objCap.capture()))
				.thenReturn("userEmail");

		// when(mMockSystem.getenv("Template_Id")).thenReturn("1234");

		mMockNotificationAzureFunction.sendInviteToUserWebclient("testRequestId", "2",jdbcTemplate);
	}
	 

	@Test
	void testUpdateDownloadJdbcCall() {
		String response = "SUCCESS";
		when(jdbcTemplate.update(Mockito.anyString(), objCap.capture())).thenReturn(1);

		mMockNotificationAzureFunction.updateDownloadJdbcCall(jdbcTemplate, "readyForDelivery", "testReuestID");
		assertEquals("SUCCESS", response);
	}

	@Test
	void testUpdateDownladRequest_SUCCESS() {
		NotificationDownloadRequest reqObject = new NotificationDownloadRequest();
		reqObject.setIsSuccessful(true);
		reqObject.setFileName("testFile");
		reqObject.setUrl("testURL");
		reqObject.setDocumentId("testDocument");

		String response = "SUCCESS";

		when(jdbcTemplate.update(Mockito.anyString(), objCap.capture())).thenReturn(1);
		mMockNotificationAzureFunction.updateDownladRequest(reqObject, jdbcTemplate, "testRequestId");

		assertEquals("SUCCESS", response);
	}

	@Test
	void testUpdateDownladRequest_FAILURE() {
		NotificationDownloadRequest reqObject = new NotificationDownloadRequest();
		reqObject.setIsSuccessful(false);
		reqObject.setErrorMessage("Error Occured");
		reqObject.setDocumentId("testDocument");

		String response = "SUCCESS";

		when(jdbcTemplate.update(Mockito.anyString(), objCap.capture())).thenReturn(1);
		mMockNotificationAzureFunction.updateDownladRequest(reqObject, jdbcTemplate, "testRequestId");

		assertEquals("SUCCESS", response);
	}

	@Test
	void testNotificationJdbcCall() {
		Notification notification = new Notification();
		notification.setNotificationStatusId("testStatusId");
		notification.setNotificationStatusDescription("testDescription");
		notification.setRequestId("testRequest");
		notification.setNotificationId(123L);
		String response = "SUCCESS";

		when(jdbcTemplate.update(Mockito.anyString(), objCap.capture())).thenReturn(1);
		mMockNotificationAzureFunction.notificationJdbcCall(jdbcTemplate, notification);

		assertEquals("SUCCESS", response);
	}
	
	@Test
	void testNotificationJdbcCallFrFailedFiles() {
		Notification notification = new Notification();
		notification.setNotificationStatusId("testStatusId");
		notification.setNotificationStatusDescription("testDescription");
		notification.setMessage("testMessage");
		notification.setRequestId("testRequest");
		notification.setNotificationId(123L);
		String response = "SUCCESS";

		when(jdbcTemplate.update(Mockito.anyString(), objCap.capture())).thenReturn(1);
		mMockNotificationAzureFunction.notificationJdbcCallFrFailedFiles(jdbcTemplate, notification);

		assertEquals("SUCCESS", response);
	}

	@Test
	void testApitoServiceBus_SUCCESS() {
		NotificationUploadRequest message = new NotificationUploadRequest();
		message.setIsSuccessful("true");
		message.setPackageId("testPackage");
		String response = "success";

		when(jdbcTemplate.update(Mockito.anyString(), objCap.capture())).thenReturn(1);
		//mMockNotificationAzureFunction.apitoServiceBus(message, context);

		//assertEquals("success", response);
	}

	@Test
	void testApitoServiceBus_fail() {
		NotificationUploadRequest message = new NotificationUploadRequest();
		message.setIsSuccessful("false");
		message.setPackageId("testPackage");
		String response = "fail";

		when(jdbcTemplate.update(Mockito.anyString(), objCap.capture())).thenReturn(1);
		//mMockNotificationAzureFunction.apitoServiceBus(message, context);

		//assertEquals("fail", response);
	}

	@Test
	void testDeleteFilesfromContainer() {
		String response = "fail";
		testInstance.deleteFilesfromContainer(Mockito.anyString(), Mockito.anyString(), Mockito.anyString());

		assertEquals("fail", response);
	}
	
    @Test
     void testDeleteBlob() {
        String blobName = "test-blob";
        
        when(containerClient.getBlobClient(blobName)).thenReturn(blobClient);

        mMockNotificationAzureFunction.deleteBlob(blobName, containerClient);
        verify(containerClient).getBlobClient(blobName);
        verify(blobClient).delete();

    }
 
       

        @Test
        public void testRun_success() throws Exception {
           
            String mockPackageId = "mockPackageId";
            when(context.getLogger()).thenReturn(mock(Logger.class));
        	java.sql.Connection conn = mock(java.sql.Connection.class);
        	when(conn.prepareStatement(anyString())).thenReturn(mockPreparedStatement);


        	when(conn.prepareStatement(anyString())).thenThrow(new SQLException("Mock SQL exception"));
            when(mockResultSet.next()).thenReturn(true, false); // Single record
            when(mockResultSet.getInt("upload_request_id")).thenReturn(123);
            when(mockResultSet.getString("document_id")).thenReturn("doc123");

            // Act
            (mMockNotificationAzureFunction).run("dummy", context);

            // Assert
//            verify(mockPreparedStatement, times(1)).setString(1, "true");
//            verify(mockResultSet, times(2)).next();
//            verify(jdbcTemplate, times(1)).queryForObject(toString(), eq(String.class), anyInt());
        }

        @Test
        public void testRun_noResults() throws Exception {
            // Arrange
            when(context.getLogger()).thenReturn(mock(Logger.class));
        	java.sql.Connection conn = mock(java.sql.Connection.class);
        	when(conn.prepareStatement(anyString())).thenReturn(mockPreparedStatement);


        	when(conn.prepareStatement(anyString())).thenThrow(new SQLException("Mock SQL exception"));

            when(mockResultSet.next()).thenReturn(false);

          
            ( mMockNotificationAzureFunction).run("dummy", context);

      
            
            verifyNoInteractions(jdbcTemplate); 
        }

        @Test
        public void testRun_exceptionHandling() throws Exception {
            // Arrange
        	// Mock logger
        	Logger mockLogger = mock(Logger.class);
        	when(context.getLogger()).thenReturn(mockLogger);
        	java.sql.Connection conn = mock(java.sql.Connection.class);
        	when(conn.prepareStatement(anyString())).thenReturn(mockPreparedStatement);


        	
        	// Mock exception for prepared statement to simulate failure
        	when(conn.prepareStatement(anyString())).thenThrow(new SQLException("Mock SQL exception"));

            // Act
            (mMockNotificationAzureFunction).run("dummy", context);

            // Assert
           
        }
        @Test
        void testSendInviteToUserWebclient_switchCoverage_withDI() {
           
            String reqId = "123";
            String downloadStatus = "TWO";
            String emailFromDownloadRequest = "test@example.com";
            when(jdbcTemplate.queryForObject(anyString(), eq(String.class), any(Object[].class)))
                .thenReturn(emailFromDownloadRequest);
            
            Map<String, String> mockEnv = new HashMap<>();
            mockEnv.put("Template_Id", "101");
            mockEnv.put("From_Email", "no-reply@example.com");

           
            mMockNotificationAzureFunction.sendInviteToUserWebclient(reqId, downloadStatus, jdbcTemplate);

          
            verify(jdbcTemplate, times(1)).queryForObject(anyString(), eq(String.class), objCap.capture());
            assertEquals(reqId, objCap.getValue()[0]);
        }


		
    
}
