package com.ombudsman.service.respondent;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.springframework.test.context.junit.jupiter.SpringExtension;

@ExtendWith(SpringExtension.class)
public class NotificationDownloadRequestTest {
	
	@InjectMocks
	NotificationDownloadRequest mMockNotificationDownloadRequest;
	
	@Test
	public void testGetterAndSetter() {
		
		mMockNotificationDownloadRequest.setDocumentId("docid");
		mMockNotificationDownloadRequest.setErrorMessage("Error");
		mMockNotificationDownloadRequest.setFileName("File123");
		mMockNotificationDownloadRequest.setIsSuccessful(true);
		mMockNotificationDownloadRequest.setUrl("URL");
		
		assertEquals("docid",mMockNotificationDownloadRequest.getDocumentId());
		assertEquals("Error", mMockNotificationDownloadRequest.getErrorMessage());
		assertEquals("File123",mMockNotificationDownloadRequest.getFileName());
		assertEquals(true,mMockNotificationDownloadRequest.isIsSuccessful());
		assertEquals("URL",mMockNotificationDownloadRequest.getUrl());
				
	}

}
