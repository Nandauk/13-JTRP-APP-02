package com.ombudsman.service.model;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

import java.lang.reflect.Field;
import java.util.UUID;

public class CorrespondenceDataTest {

    @Test
    public void testGetFos_correspondenceid() throws NoSuchFieldException, IllegalAccessException {
        UUID expectedUUID = UUID.randomUUID();
        CorrespondenceData correspondenceData = new CorrespondenceData();

        Field field = CorrespondenceData.class.getDeclaredField("fos_correspondenceid");
        field.setAccessible(true);
        field.set(correspondenceData, expectedUUID);

        assertEquals(expectedUUID, correspondenceData.getFos_correspondenceid());
    }
}
