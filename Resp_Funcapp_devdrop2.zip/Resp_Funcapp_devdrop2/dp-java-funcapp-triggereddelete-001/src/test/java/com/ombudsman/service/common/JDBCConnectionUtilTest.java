//package com.ombudsman.service.common;
//
//import org.junit.jupiter.api.Test;
//import org.junit.jupiter.api.BeforeEach;
//import org.mockito.InjectMocks;
//import org.mockito.MockitoAnnotations;
//import org.springframework.jdbc.core.JdbcTemplate;
//import org.springframework.jdbc.datasource.DriverManagerDataSource;
//
//import static org.junit.jupiter.api.Assertions.assertNotNull;
//import static org.junit.jupiter.api.Assertions.assertEquals;
//import static org.mockito.Mockito.mock;
//import static org.mockito.Mockito.when;
//
//public class JDBCConnectionUtilTest {
//
//    @InjectMocks
//    private JDBCConnectionUtil jdbcConnectionUtil;
//    
//    @BeforeEach
//    public void setUp() {
//        MockitoAnnotations.initMocks(this);
//    }
//
//    @Test
//    public void testJdbcConnection() {
//        // Arrange
//        System.setProperty("SQL_DATASOURCE_URL", "jdbc:sqlserver://localhost:1433;databaseName=TestDB");
//        System.setProperty("SQL_DATASOURCE_USERNAME", "testUser");
//        System.setProperty("SQL_DATASOURCE_PASSWORD", "testPassword");
//
//        // Act
//        JdbcTemplate jdbcTemplate = jdbcConnectionUtil.jdbcConnection();
//
//        // Assert
//        assertNotNull(jdbcTemplate);
//        DriverManagerDataSource dataSource = (DriverManagerDataSource) jdbcTemplate.getDataSource();
//        assertEquals("jdbc:sqlserver://localhost:1433;databaseName=TestDB", dataSource.getUrl());
//        assertEquals("testUser", dataSource.getUsername());
//        assertEquals("testPassword", dataSource.getPassword());
//    }
//}
