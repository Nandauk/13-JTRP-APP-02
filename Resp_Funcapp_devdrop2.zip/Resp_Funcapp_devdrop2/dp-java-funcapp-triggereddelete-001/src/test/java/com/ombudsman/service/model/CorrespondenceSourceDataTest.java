package com.ombudsman.service.model;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

import java.lang.reflect.Field;
import java.util.UUID;

public class CorrespondenceSourceDataTest {

    @Test
    public void testGetFos_correspondencesourceid() throws NoSuchFieldException, IllegalAccessException {
        UUID expectedUUID = UUID.randomUUID();
        CorrespondenceSourceData correspondenceSourceData = new CorrespondenceSourceData();

        Field field = CorrespondenceSourceData.class.getDeclaredField("fos_correspondencesourceid");
        field.setAccessible(true);
        field.set(correspondenceSourceData, expectedUUID);

        assertEquals(expectedUUID, correspondenceSourceData.getFos_correspondencesourceid());
    }
}
