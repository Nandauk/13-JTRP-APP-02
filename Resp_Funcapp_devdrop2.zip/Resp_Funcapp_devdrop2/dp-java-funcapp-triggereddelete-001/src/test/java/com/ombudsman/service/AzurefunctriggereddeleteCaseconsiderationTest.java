//package com.ombudsman.service;
//
//import static org.mockito.ArgumentMatchers.any;
//import static org.mockito.Mockito.*;
//
//import java.lang.reflect.Field;
//import java.util.UUID;
//
//import org.junit.jupiter.api.BeforeEach;
//import org.junit.jupiter.api.Test;
//import org.mockito.InjectMocks;
//import org.mockito.Mock;
//import org.mockito.MockitoAnnotations;
//import org.springframework.jdbc.core.JdbcTemplate;
//
//import com.fasterxml.jackson.databind.DeserializationFeature;
//import com.fasterxml.jackson.databind.ObjectMapper;
//import com.microsoft.azure.functions.ExecutionContext;
//import com.ombudsman.service.common.ConstantsConfig;
//import com.ombudsman.service.model.CaseconsiderationData;
//import com.ombudsman.serviceimpl.EmailHelper;
//import com.ombudsman.serviceimpl.TriggeredImpl;
//
//public class AzurefunctriggereddeleteCaseconsiderationTest {
//
//    @InjectMocks
//    private AzurefunctriggereddeleteCaseconsideration azurefunctriggereddeleteCaseconsideration;
//
//    @Mock
//    private TriggeredImpl triggerimpl;
//
//    @Mock
//    private ConstantsConfig constant;
//
//    @Mock
//    private JdbcTemplate jdbcTemplate;
//
//    @Mock
//    private EmailHelper emailhelper;
//
//    @Mock
//    private ExecutionContext context;
//
//    private ObjectMapper mapper;
//
//    @BeforeEach
//    public void setUp() {
//        MockitoAnnotations.initMocks(this);
//        mapper = new ObjectMapper();
//        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
//        azurefunctriggereddeleteCaseconsideration.LOG = mock(org.apache.logging.log4j.Logger.class);
//    }
//
//    @Test
//    public void testServiceBusProcessCaseconsideration_Success() throws Exception {
//        String message = "{\"fos_caseconsiderationid\": \"123e4567-e89b-12d3-a456-426614174000\"}";
//
//        CaseconsiderationData caseconsiderationData = new CaseconsiderationData();
//        setField(caseconsiderationData, "fos_caseconsiderationid", UUID.fromString("123e4567-e89b-12d3-a456-426614174000"));
//
//        when(triggerimpl.getJobID(anyString(), any(JdbcTemplate.class))).thenReturn(1);
//        when(triggerimpl.getCurrentStatusIPId(anyString(), any(JdbcTemplate.class))).thenReturn(1);
//        when(triggerimpl.getCurrentStatusRTPId(anyString(), any(JdbcTemplate.class))).thenReturn(1);
//        doNothing().when(triggerimpl).InsertQuery(anyInt(), anyString(), anyInt(), anyInt(), anyInt(), anyInt(), anyString(), anyString(), anyString(), any(JdbcTemplate.class),any(UUID.class));
//        when(triggerimpl.getIncrementalDataLoadAuditId(anyString(), anyInt(), anyString(), anyString(), any(JdbcTemplate.class),any(UUID.class))).thenReturn(UUID.randomUUID());
//        doNothing().when(triggerimpl).insertRecordcaseconsideration(any(UUID.class), any(JdbcTemplate.class), anyString());
//        doNothing().when(triggerimpl).UpdateQuery(anyInt(), anyInt(), anyInt(), anyInt(), anyString(), any(UUID.class), anyString(), any(JdbcTemplate.class));
//
//        azurefunctriggereddeleteCaseconsideration.serviceBusProcessCaseconsideration(message, context);
//
//        verify(triggerimpl, times(1)).InsertQuery(anyInt(), anyString(), anyInt(), anyInt(), anyInt(), anyInt(), anyString(), anyString(), anyString(), any(JdbcTemplate.class),any(UUID.class));
//        verify(triggerimpl, times(1)).insertRecordcaseconsideration(any(UUID.class),  any(JdbcTemplate.class), anyString());
//      //  verify(triggerimpl, times(1)).UpdateQuery(anyInt(), anyInt(), anyInt(), anyInt(), null, any(UUID.class), anyString(), any(JdbcTemplate.class));
//    }
//
//    @Test
//    public void testServiceBusProcessCaseconsideration_Failure() throws Exception {
//        String message = "{\"fos_caseconsiderationid\": \"123e4567-e89b-12d3-a456-426614174000\"}";
//        Exception exception = new RuntimeException("Test Exception");
//
//        when(triggerimpl.getJobID(anyString(), any(JdbcTemplate.class))).thenReturn(1);
//        when(triggerimpl.getCurrentStatusIPId(anyString(), any(JdbcTemplate.class))).thenReturn(1);
//        when(triggerimpl.getCurrentStatusRTPId(anyString(), any(JdbcTemplate.class))).thenReturn(1);
//        when(triggerimpl.getIncrementalDataLoadAuditId(anyString(), anyInt(), anyString(), anyString(), any(JdbcTemplate.class),any(UUID.class))).thenReturn(UUID.randomUUID());
//
//        // Simulate the exception
//        doThrow(exception).when(triggerimpl).insertRecordcaseconsideration(any(UUID.class),  any(JdbcTemplate.class), anyString());
//
//        when(triggerimpl.getCurrentStatusFId(anyString(), any(JdbcTemplate.class))).thenReturn(1);
//        doNothing().when(triggerimpl).InsertQueryErrorTable(any(UUID.class), anyString(), anyInt(), anyString(), anyString(), anyString(), anyString(), any(JdbcTemplate.class));
//        doNothing().when(triggerimpl).UpdateQuery(anyInt(), anyInt(), anyInt(), anyInt(), anyString(), any(UUID.class), anyString(), any(JdbcTemplate.class));
//        doNothing().when(emailhelper).NotificationWebclient(anyString(), any(UUID.class), anyString(), anyString(), anyString());
//
//        try {
//            azurefunctriggereddeleteCaseconsideration.serviceBusProcessCaseconsideration(message, context);
//        } catch (RuntimeException e) {
//            // Exception is expected
//        }
//
//        verify(triggerimpl, times(1)).InsertQueryErrorTable(any(UUID.class), anyString(), anyInt(), anyString(), anyString(), anyString(), anyString(), any(JdbcTemplate.class));
//        verify(triggerimpl, times(1)).UpdateQuery(anyInt(), anyInt(), anyInt(), anyInt(), anyString(), any(UUID.class), anyString(), any(JdbcTemplate.class));
//        verify(emailhelper, times(1)).NotificationWebclient(anyString(), any(UUID.class), anyString(), anyString(), anyString());
//    }
//
//    // Helper method to set private field value using reflection
//    private void setField(Object targetObject, String fieldName, Object fieldValue) throws Exception {
//        Field field = targetObject.getClass().getDeclaredField(fieldName);
//        field.setAccessible(true);
//        field.set(targetObject, fieldValue);
//    }
//}
