package com.ombudsman.service.model;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

import java.lang.reflect.Field;
import java.util.UUID;

public class AccountDataTest {

    @Test
    public void testGetAccountid() throws NoSuchFieldException, IllegalAccessException {
        UUID expectedUUID = UUID.randomUUID();
        AccountData accountData = new AccountData();

        Field field = AccountData.class.getDeclaredField("accountid");
        field.setAccessible(true);
        field.set(accountData, expectedUUID);

        assertEquals(expectedUUID, accountData.getAccountid());
    }
}
