package com.ombudsman.service.model;

import java.util.UUID;

import jakarta.persistence.Id;

public class UserData {

	@Id
	private UUID systemuserid;

	public UUID getSystemuserid() {
		return systemuserid;
	}

}
