package com.ombudsman.service.model;

import java.util.UUID;

import jakarta.persistence.Id;

public class CorrespondenceSourceData {

	@Id
	private UUID fos_correspondencesourceid;

	public UUID getFos_correspondencesourceid() {
		return fos_correspondencesourceid;
	}

}
