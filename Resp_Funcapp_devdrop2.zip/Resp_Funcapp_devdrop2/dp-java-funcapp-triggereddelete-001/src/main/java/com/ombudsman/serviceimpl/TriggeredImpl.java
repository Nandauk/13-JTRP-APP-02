package com.ombudsman.serviceimpl;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.UUID;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;

import com.ombudsman.service.common.ConstantsConfig;

public class TriggeredImpl {

	Logger LOG = LogManager.getRootLogger();

	CallableStatement callablestatement = null;
	ConstantsConfig constant = new ConstantsConfig();
	PreparedStatement pstmt = null;
	Connection conn = null;
	ResultSet rs = null;

	public int getJobID(String entity, JdbcTemplate jdbcTemplate) throws SQLException {

		String Entity = entity;
		LOG.info(String.format("Azure func app for %s  started to get getJobID ", Entity));
		int JobId = 0;
		try {
			String sqlgetJobID = "select job_id from dp_job_master where created_by=?";
			Integer jobid = jdbcTemplate.queryForObject(sqlgetJobID, Integer.class, entity);
			if (jobid != null) {
				JobId = jobid;
			}
			LOG.info(String.format("Azure func app for %s got Jobid as : %s ", Entity, JobId));
		} catch (EmptyResultDataAccessException e) {
			LOG.info("exception accessing data::{}", e.getMessage());

		}
		return JobId;
	}

	public int getCurrentStatusIPId(String entity, JdbcTemplate jdbcTemplate) throws SQLException {

		String Entity = entity;
		LOG.info(String.format("Azure func app for %s  started to  getCurrentStatusIPId ", Entity));
		int inprogressId = 0;
		try {
			String sqlgetCurrentStatusIPId = "select id from dp_key_pair_master_data where data_source_name=? and item_value=?";
			Integer inprogressid = jdbcTemplate.queryForObject(sqlgetCurrentStatusIPId, Integer.class,
					constant.DataSourceName, constant.In_Progress);
			if (inprogressid != null) {
				inprogressId = inprogressid;
			}
			LOG.info(String.format("Azure func app for %s  got  inprogressid as : %s ", Entity, inprogressId));
		} catch (EmptyResultDataAccessException e) {
			LOG.info("exception accessing data::{}", e.getMessage());

		}
		return inprogressId;

	}

	public int getCurrentStatusRTPId(String entity, JdbcTemplate jdbcTemplate) throws SQLException {

		String Entity = entity;
		LOG.info(String.format("Azure func app for %s  started to  getCurrentStatusRTPId ", Entity));
		int readytoprocessId = 0;
		try {
			String sqlgetCurrentStatusRTPId = "select id from dp_key_pair_master_data where data_source_name=? and item_value=?";
			Integer readytoprocessid = jdbcTemplate.queryForObject(sqlgetCurrentStatusRTPId, Integer.class,
					constant.DataSourceName, constant.Ready_To_Process);
			if (readytoprocessid != null) {
				readytoprocessId = readytoprocessid;
			}
			LOG.info(String.format("Azure func app for %s got  readytoprocessid as : %s ", Entity, readytoprocessId));
		} catch (EmptyResultDataAccessException e) {
			LOG.info("exception accessing data::{}", e.getMessage());

		}
		return readytoprocessId;

	}

	public void InsertQuery(int jobId, String startWebJob_formatted, Integer totalCount, Integer totalSuccessCount,
			Integer failedCount, int current_status_id_inprogress, String dataSourceName, String entity_Contact,
			String entity_Contact2, JdbcTemplate jdbcTemplate, UUID incremental_data_load_funcapp_id) {

		LOG.info(String.format("Azure func app Insert into Audit table for %s  started ", constant.Entity_Incident));

		String sql = "INSERT INTO dp_incremental_data_load_job_audit (job_id,job_start_date_time,total_number_of_records,number_of_processed_record,number_of_failed_record,current_job_status_id,source,created_by,modified_by,incremental_data_load_funcapp_id) VALUES (?,?,?,?,?,?,?,?,?,?);";
		LOG.info("sql query insert audit: {}", sql);

		jdbcTemplate.update(sql, jobId, startWebJob_formatted, totalCount, totalSuccessCount, failedCount,
				current_status_id_inprogress, dataSourceName, entity_Contact, entity_Contact2,
				incremental_data_load_funcapp_id);
		LOG.info(String.format("Azure func app Insert into Audit table for %s  completed ", constant.Entity_Incident));

	}

	public UUID getIncrementalDataLoadAuditId(String startWebJob_formatted, int current_status_id_inprogress,
			String dataSourceName, String entity, JdbcTemplate jdbcTemplate, UUID incremental_data_load_funcapp_id)
			throws SQLException {

		String Entity = entity;
		LOG.info(String.format("Azure func app for %s  started to  getIncrementalDataLoadAuditId ", Entity));
		UUID fetchincrementalauditId = null;

		String sqlgetIncrementalDataLoadAuditId = "select incremental_data_load_audit_id from dp_incremental_data_load_job_audit where current_job_status_id=? and source=? and job_start_date_time=? and created_by=? and incremental_data_load_funcapp_id=?";
		fetchincrementalauditId = jdbcTemplate.queryForObject(sqlgetIncrementalDataLoadAuditId, UUID.class,
				current_status_id_inprogress, dataSourceName, startWebJob_formatted, Entity,
				incremental_data_load_funcapp_id);

		LOG.info(String.format("Azure func app for %s  got fetchincrementalauditId as : %s ", Entity,
				fetchincrementalauditId));

		return fetchincrementalauditId;

	}

	public int getCurrentStatusFId(String entity, JdbcTemplate jdbcTemplate) throws SQLException {

		String Entity = entity;
		LOG.info(String.format("Azure func app for %s  started to  getCurrentStatusFId ", Entity));
		int failedId = 0;
		try {
			String sqlgetCurrentStatusFId = "select id from dp_key_pair_master_data where data_source_name=? and item_value=?";
			Integer failedid = jdbcTemplate.queryForObject(sqlgetCurrentStatusFId, Integer.class,
					constant.DataSourceName, constant.Failed);
			if (failedid != null) {
				failedId = failedid;
			}
			LOG.info(String.format("Azure func app for %s  got failedid as : %s ", Entity, failedId));
		} catch (EmptyResultDataAccessException e) {
			LOG.info("exception accessing data::{}", e.getMessage());

		}

		return failedId;

	}

	public void InsertQueryErrorTable(UUID fetch_IncrementalDataLoadAuditId, String dataPayload,
			int current_status_id_failed, String error_log, String stackTrace, String entity, String entity1,
			JdbcTemplate jdbcTemplate) {

		String Entity = entity;
		LOG.info(String.format("Azure func app Insert into Error table for %s  started ", Entity));

		Object[] paramInsertQuery = new Object[] { fetch_IncrementalDataLoadAuditId, dataPayload,
				current_status_id_failed, error_log, stackTrace, entity, entity1 };
		LOG.info("paramInsertQuery {}", paramInsertQuery);

		String sql = "INSERT INTO dp_incremental_load_error (incremental_data_load_audit_id,data_pay_load,current_error_status_id,error_code,error_log,created_by,modified_by) VALUES (?,?,?,?,?,?,?);";
		LOG.info("sql query insert audit: {}", sql);

		jdbcTemplate.update(sql, paramInsertQuery);
		LOG.info(String.format("Azure func app Insert into Error table for %s  completed ", Entity));

	}

	public void UpdateQuery(Integer totalCount, Integer totalSuccessCount, Integer failedCount, int current_status_id,
			String string, UUID fetch_IncrementalDataLoadAuditId, String entity, JdbcTemplate jdbcTemplate) {

		String Entity = entity;
		LOG.info(String.format("Azure func app Update into Audit table for %s  started ", Entity));

		Object[] paramUpdateQuery = new Object[] { totalCount, totalSuccessCount, failedCount, current_status_id,
				string, entity, fetch_IncrementalDataLoadAuditId, };
		LOG.info("paramUpdateQuery {}", paramUpdateQuery);

		String sql = "Update dp_incremental_data_load_job_audit set total_number_of_records=?,number_of_processed_record=?,number_of_failed_record=?,current_job_status_id=?,job_close_datetime=?,modified_by=? where incremental_data_load_audit_id=?";
		LOG.info("sql query insert audit: {}", sql, totalCount, totalSuccessCount, failedCount, current_status_id,
				string, entity, fetch_IncrementalDataLoadAuditId);

		jdbcTemplate.update(sql, paramUpdateQuery);
		LOG.info(String.format("Azure func app Update into Audit table for %s  completed ", Entity));

	}

	public void insertRecordcontact(UUID uuid, JdbcTemplate jdbcTemplate,
			String entity) {

		String Entity = entity;
		LOG.info(String.format("Azure func app record insert into stg  table for %s  started ", Entity));

		String sql = "INSERT INTO d_contact(contactid) VALUES(?)";
		LOG.info("sql query insert in stg table: {}", sql, uuid);

		jdbcTemplate.update(sql, uuid);
		LOG.info(String.format("Azure func app record insert into stg  table for %s  completed ", Entity));

	}

	public void insertRecordincident(UUID uuid, JdbcTemplate jdbcTemplate,
			String entity) {

		String Entity = entity;
		LOG.info(String.format("Azure func app record insert into stg  table for %s  started ", Entity));

		String sql = "INSERT INTO d_incident(incidentid) VALUES(?)";
		LOG.info("sql query insert in stg table: {}", sql, uuid);

		jdbcTemplate.update(sql, uuid);
		LOG.info(String.format("Azure func app record insert into stg  table for %s  completed ", Entity));

	}

	public void insertRecordcaselink(UUID uuid, JdbcTemplate jdbcTemplate,
			String entity) {

		String Entity = entity;
		LOG.info(String.format("Azure func app record insert into stg  table for %s  started ", Entity));

		String sql = "INSERT INTO d_caselink(fos_caselinkid) VALUES(?)";
		LOG.info("sql query insert in stg table: {}", sql, uuid);

		jdbcTemplate.update(sql, uuid);
		LOG.info(String.format("Azure func app record insert into stg  table for %s  completed ", Entity));

	}

	public void insertRecordaccount(UUID uuid,JdbcTemplate jdbcTemplate,
			String entity) {

		String Entity = entity;
		LOG.info(String.format("Azure func app record insert into stg  table for %s  started ", Entity));

		String sql = "INSERT INTO d_account(accountid) VALUES(?)";
		LOG.info("sql query insert in stg table: {}", sql, uuid);

		jdbcTemplate.update(sql, uuid);
		LOG.info(String.format("Azure func app record insert into stg  table for %s  completed ", Entity));

	}

	public void insertRecordemail(UUID uuid,  JdbcTemplate jdbcTemplate,
			String entity) {
		String Entity = entity;
		LOG.info(String.format("Azure func app record insert into stg  table for %s  started ", Entity));

		String sql = "INSERT INTO d_email(activityid) VALUES(?)";
		LOG.info("sql query insert in stg table: {}", sql, uuid);

		jdbcTemplate.update(sql, uuid);
		LOG.info(String.format("Azure func app record insert into stg  table for %s  completed ", Entity));

	}

	public void insertRecordletter(UUID uuid,  JdbcTemplate jdbcTemplate,
			String entity) {
		String Entity = entity;
		LOG.info(String.format("Azure func app record insert into stg  table for %s  started ", Entity));

		String sql = "INSERT INTO d_letter(activityid) VALUES(?)";
		LOG.info("sql query insert in stg table: {}", sql, uuid);

		jdbcTemplate.update(sql, uuid);
		LOG.info(String.format("Azure func app record insert into stg  table for %s  completed ", Entity));

	}

	public void insertRecordtask(UUID uuid, JdbcTemplate jdbcTemplate,
			String entity) {
		String Entity = entity;
		LOG.info(String.format("Azure func app record insert into stg  table for %s  started ", Entity));

		String sql = "INSERT INTO d_task(activityid) VALUES(?)";
		LOG.info("sql query insert in stg table: {}", sql, uuid);

		jdbcTemplate.update(sql, uuid);
		LOG.info(String.format("Azure func app record insert into stg  table for %s  completed ", Entity));

	}

	public void insertRecordphone(UUID uuid, JdbcTemplate jdbcTemplate,
			String entity) {
		String Entity = entity;
		LOG.info(String.format("Azure func app record insert into stg  table for %s  started ", Entity));

		String sql = "INSERT INTO d_phone(activityid) VALUES(?)";
		LOG.info("sql query insert in stg table: {}", sql, uuid);

		jdbcTemplate.update(sql, uuid);
		LOG.info(String.format("Azure func app record insert into stg  table for %s  completed ", Entity));

	}

	public void insertRecordportal(UUID uuid, JdbcTemplate jdbcTemplate,
			String entity) {
		String Entity = entity;
		LOG.info(String.format("Azure func app record insert into stg  table for %s  started ", Entity));

		String sql = "INSERT INTO d_portal(activityid) VALUES(?)";
		LOG.info("sql query insert in stg table: {}", sql, uuid);

		jdbcTemplate.update(sql, uuid);
		LOG.info(String.format("Azure func app record insert into stg  table for %s  completed ", Entity));

	}

	public void insertRecorduser(UUID uuid, JdbcTemplate jdbcTemplate,
			String entity) {
		String Entity = entity;
		LOG.info(String.format("Azure func app record insert into stg  table for %s  started ", Entity));

		String sql = "INSERT INTO d_user(systemuserid) VALUES(?)";
		LOG.info("sql query insert in stg table: {}", sql, uuid);

		jdbcTemplate.update(sql, uuid);
		LOG.info(String.format("Azure func app record insert into stg  table for %s  completed ", Entity));

	}

	public void insertRecordofferoutcome(UUID uuid, JdbcTemplate jdbcTemplate,
			String entity) {
		String Entity = entity;
		LOG.info(String.format("Azure func app record insert into stg  table for %s  started ", Entity));

		String sql = "INSERT INTO d_offeroutcome(fos_offeroutcomeid) VALUES(?)";
		LOG.info("sql query insert in stg table: {}", sql, uuid);

		jdbcTemplate.update(sql, uuid);
		LOG.info(String.format("Azure func app record insert into stg  table for %s  completed ", Entity));

	}

	public void insertRecordcaseconsideration(UUID uuid, JdbcTemplate jdbcTemplate, String entity) {
		String Entity = entity;
		LOG.info(String.format("Azure func app record insert into stg  table for %s  started ", Entity));

		String sql = "INSERT INTO d_caseconsideration(fos_caseconsiderationid) VALUES(?)";
		LOG.info("sql query insert in stg table: {}", sql, uuid);

		jdbcTemplate.update(sql, uuid);
		LOG.info(String.format("Azure func app record insert into stg  table for %s  completed ", Entity));

	}

	public void insertRecordcorrespondence(UUID uuid, JdbcTemplate jdbcTemplate,
			String entity) {
		String Entity = entity;
		LOG.info(String.format("Azure func app record insert into stg  table for %s  started ", Entity));

		String sql = "INSERT INTO d_correspondence(fos_corespondenceid) VALUES(?)";
		LOG.info("sql query insert in stg table: {}", sql, uuid);

		jdbcTemplate.update(sql, uuid);
		LOG.info(String.format("Azure func app record insert into stg  table for %s  completed ", Entity));

	}

	public void insertRecordcorrespondenceSource(UUID uuid, JdbcTemplate jdbcTemplate, String entity) {
		String Entity = entity;
		LOG.info(String.format("Azure func app record insert into stg  table for %s  started ", Entity));

		String sql = "INSERT INTO d_correspondencesource(fos_corespondencesourceid) VALUES(?)";
		LOG.info("sql query insert in stg table: {}", sql, uuid);

		jdbcTemplate.update(sql, uuid);
		LOG.info(String.format("Azure func app record insert into stg  table for %s  completed ", Entity));

	}

}
