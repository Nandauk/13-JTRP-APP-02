package com.ombudsman.service.model;

import java.util.UUID;

import jakarta.persistence.Id;

public class IncidentData {

	@Id
	private UUID incidentid;

	public UUID getIncidentid() {
		return incidentid;
	}

}
