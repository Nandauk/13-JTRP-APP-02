package com.ombudsman.service;

import java.beans.Transient;
import java.sql.SQLException;
import java.time.Instant;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.jdbc.core.JdbcTemplate;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.microsoft.azure.functions.ExecutionContext;
import com.microsoft.azure.functions.annotation.FunctionName;
import com.microsoft.azure.functions.annotation.ServiceBusQueueTrigger;
import com.ombudsman.service.common.ConstantsConfig;
import com.ombudsman.service.common.JDBCConnectionUtil;
import com.ombudsman.service.model.EmailData;
import com.ombudsman.serviceimpl.EmailHelper;
import com.ombudsman.serviceimpl.TriggeredImpl;

public class AzurefunctriggereddeleteEmail {

	Integer failedCount = 0, totalSuccessCount = 0, totalCount = 0;
	Logger LOG = LogManager.getRootLogger();

	TriggeredImpl triggerimpl = new TriggeredImpl();
	ConstantsConfig constant = new ConstantsConfig();
	JdbcTemplate jdbcTemplate = JDBCConnectionUtil.jdbcConnection();
	EmailHelper emailhelper = new EmailHelper();

	@FunctionName("EmailTriggerDelete")
	@Transient(true)
	public void serviceBusProcessEmail(
			@ServiceBusQueueTrigger(name = "Emailmsg", queueName = "%QueueNameEmail%", connection = "AzureWebJobsServiceBus") String message,
			final ExecutionContext context) throws SQLException {
		LOG.info("Message from email service bus queue : {}", message);

		ObjectMapper mapper = new ObjectMapper();
		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

		// Parse the JSON message into EmailData object
		try {
			LOG.info("AZURE STARTED in TRY BLOCK for : {}", constant.Entity_Email);
			EmailData emailData = mapper.readValue(message, EmailData.class);

			LOG.info("Activity ID : {} ", emailData.getActivityid());

			// entry in Email table
			triggerimpl.insertRecordemail(emailData.getActivityid(), jdbcTemplate, constant.Entity_Email);

		} catch (Exception e) {
			LOG.info("AZURE STARTED in CATCH BLOCK for : {}", constant.Entity_Email);
			String emailTime = Instant.now().toString();
			// Send email to support team
			emailhelper.NotificationWebclient(constant.Entity_Email, null, constant.DataSourceName, e.getMessage(),
					emailTime);
			//
			throw new RuntimeException(
					String.format("Job failed for %s entity with Error : %s", constant.Entity_Email, e.getMessage()));
		}
	}

}
