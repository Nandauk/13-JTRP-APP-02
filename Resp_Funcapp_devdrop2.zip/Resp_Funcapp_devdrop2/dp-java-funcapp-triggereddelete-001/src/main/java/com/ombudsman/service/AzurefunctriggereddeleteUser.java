package com.ombudsman.service;

import java.beans.Transient;
import java.sql.SQLException;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.UUID;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.jdbc.core.JdbcTemplate;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.microsoft.azure.functions.ExecutionContext;
import com.microsoft.azure.functions.annotation.FunctionName;
import com.microsoft.azure.functions.annotation.ServiceBusQueueTrigger;
import com.ombudsman.service.common.ConstantsConfig;
import com.ombudsman.service.common.JDBCConnectionUtil;
import com.ombudsman.service.model.UserData;
import com.ombudsman.serviceimpl.EmailHelper;
import com.ombudsman.serviceimpl.TriggeredImpl;

public class AzurefunctriggereddeleteUser {
	Integer failedCount = 0, totalSuccessCount = 0, totalCount = 0;
	Logger LOG = LogManager.getRootLogger();
	TriggeredImpl triggerimpl = new TriggeredImpl();
	ConstantsConfig constant = new ConstantsConfig();
	JdbcTemplate jdbcTemplate = JDBCConnectionUtil.jdbcConnection();
	EmailHelper emailhelper = new EmailHelper();

	@FunctionName("UserTriggerDelete")
	@Transient(true)
	public void serviceBusProcessUser(
			@ServiceBusQueueTrigger(name = "Usermsg", queueName = "%QueueNameUser%", connection = "AzureWebJobsServiceBus") String message,
			final ExecutionContext context) throws SQLException {

		LOG.info("Message from User service bus queue : {}", message);

		ObjectMapper mapper = new ObjectMapper();
		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

		// Parse the JSON message into UserData object
		try {
			LOG.info("AZURE STARTED in TRY BLOCK for : {}", constant.Entity_User);
			UserData userData = mapper.readValue(message, UserData.class);

			LOG.info("User ID : {} ", userData.getSystemuserid());

			// entry in User table
			triggerimpl.insertRecorduser(userData.getSystemuserid(), jdbcTemplate, constant.Entity_User);

		} catch (Exception e) {
			LOG.info("AZURE STARTED in CATCH BLOCK for : {}", constant.Entity_User);
			String emailTime = Instant.now().toString();

			// Send email to support team
			emailhelper.NotificationWebclient(constant.Entity_User, null,
					constant.DataSourceName, e.getMessage(), emailTime);
			//
			throw new RuntimeException(
					String.format("Job failed for %s entity with Error : %s", constant.Entity_User, e.getMessage()));
		}
	}

}
