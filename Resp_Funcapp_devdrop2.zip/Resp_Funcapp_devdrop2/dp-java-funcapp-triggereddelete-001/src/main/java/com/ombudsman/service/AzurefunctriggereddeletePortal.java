package com.ombudsman.service;

import java.beans.Transient;
import java.sql.SQLException;
import java.time.Instant;
import java.time.temporal.ChronoUnit;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.jdbc.core.JdbcTemplate;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.microsoft.azure.functions.ExecutionContext;
import com.microsoft.azure.functions.annotation.FunctionName;
import com.microsoft.azure.functions.annotation.ServiceBusQueueTrigger;
import com.ombudsman.service.common.ConstantsConfig;
import com.ombudsman.service.common.JDBCConnectionUtil;
import com.ombudsman.service.model.PortalData;
import com.ombudsman.serviceimpl.EmailHelper;
import com.ombudsman.serviceimpl.TriggeredImpl;

public class AzurefunctriggereddeletePortal {

	Integer failedCount = 0, totalSuccessCount = 0, totalCount = 0;
	Logger LOG = LogManager.getRootLogger();
	TriggeredImpl triggerimpl = new TriggeredImpl();
	ConstantsConfig constant = new ConstantsConfig();
	JdbcTemplate jdbcTemplate = JDBCConnectionUtil.jdbcConnection();
	EmailHelper emailhelper = new EmailHelper();

	@FunctionName("PortalTriggerDelete")
	@Transient(true)
	public void serviceBusProcessPortal(
			@ServiceBusQueueTrigger(name = "Portalmsg", queueName = "%QueueNamePortal%", connection = "AzureWebJobsServiceBus") String message,
			final ExecutionContext context) throws SQLException {

		LOG.info("Message from Portal service bus queue : {}", message);

		ObjectMapper mapper = new ObjectMapper();
		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

		Instant startWebJob = Instant.now();
		String startWebJob_formatted = startWebJob.truncatedTo(ChronoUnit.MILLIS).toString().replaceAll("[TZ]", " ");

		// Parse the JSON message into PortalData object
		try {
			LOG.info("AZURE STARTED in TRY BLOCK for : {}", constant.Entity_Portal);
			PortalData portalData = mapper.readValue(message, PortalData.class);

			LOG.info("Portal ID : {} ", portalData.getActivityid());

			// entry in Portal table
			triggerimpl.insertRecordportal(portalData.getActivityid(), jdbcTemplate, constant.Entity_Portal);

		} catch (Exception e) {
			LOG.info("AZURE STARTED in CATCH BLOCK for : {}", constant.Entity_Portal);
			String emailTime = Instant.now().toString();

			// Send email to support team
			emailhelper.NotificationWebclient(constant.Entity_Portal, null,
					constant.DataSourceName, e.getMessage(), emailTime);
			//
			throw new RuntimeException(
					String.format("Job failed for %s entity with Error : %s", constant.Entity_Portal, e.getMessage()));
		}
	}

}
