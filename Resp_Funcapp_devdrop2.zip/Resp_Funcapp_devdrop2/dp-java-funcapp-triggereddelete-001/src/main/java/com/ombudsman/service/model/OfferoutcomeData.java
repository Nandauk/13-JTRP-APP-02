package com.ombudsman.service.model;

import java.util.UUID;

import jakarta.persistence.Id;

public class OfferoutcomeData {

	@Id
	private UUID fos_offeroroutcomeid;

	public UUID getFos_offeroroutcomeid() {
		return fos_offeroroutcomeid;
	}

}
