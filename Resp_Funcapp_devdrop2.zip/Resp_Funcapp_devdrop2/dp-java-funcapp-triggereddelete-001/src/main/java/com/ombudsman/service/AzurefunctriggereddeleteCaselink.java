package com.ombudsman.service;

import java.beans.Transient;
import java.sql.SQLException;
import java.time.Instant;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.jdbc.core.JdbcTemplate;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.microsoft.azure.functions.ExecutionContext;
import com.microsoft.azure.functions.annotation.FunctionName;
import com.microsoft.azure.functions.annotation.ServiceBusQueueTrigger;
import com.ombudsman.service.common.ConstantsConfig;
import com.ombudsman.service.common.JDBCConnectionUtil;
import com.ombudsman.service.model.CaselinkData;
import com.ombudsman.serviceimpl.EmailHelper;
import com.ombudsman.serviceimpl.TriggeredImpl;

public class AzurefunctriggereddeleteCaselink {

	Integer failedCount = 0, totalSuccessCount = 0, totalCount = 0;
	Logger LOG = LogManager.getRootLogger();

	TriggeredImpl triggerimpl = new TriggeredImpl();
	ConstantsConfig constant = new ConstantsConfig();
	JdbcTemplate jdbcTemplate = JDBCConnectionUtil.jdbcConnection();
	EmailHelper emailhelper = new EmailHelper();

	@FunctionName("CaselinkTriggerDelete")
	@Transient(true)
	public void serviceBusProcessCaselink(
			@ServiceBusQueueTrigger(name = "Caselinkmsg", queueName = "%QueueNameCaselink%", connection = "AzureWebJobsServiceBus") String message,
			final ExecutionContext context) throws SQLException {
		LOG.info("Message from caselink service bus queue : {}", message);

		ObjectMapper mapper = new ObjectMapper();
		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

		// Parse the JSON message into CaselinkData object
		try {
			LOG.info("AZURE STARTED in TRY BLOCK for : {}", constant.Entity_Caselink);
			CaselinkData caselinkData = mapper.readValue(message, CaselinkData.class);

			LOG.info("Caselink ID : {} ", caselinkData.getFos_caselinkid());

			// entry in Caselink table
			triggerimpl.insertRecordcaselink(caselinkData.getFos_caselinkid(), jdbcTemplate, constant.Entity_Caselink);

		} catch (Exception e) {
			LOG.info("AZURE STARTED in CATCH BLOCK for : {}", constant.Entity_Caselink);
			String emailTime = Instant.now().toString();

			// Send email to support team
			emailhelper.NotificationWebclient(constant.Entity_Caselink, null, constant.DataSourceName, e.getMessage(),
					emailTime);
			//
			throw new RuntimeException(String.format("Job failed for %s entity with Error : %s",
					constant.Entity_Caselink, e.getMessage()));
		}
	}

}
