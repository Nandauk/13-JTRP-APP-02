package com.ombudsman.service.model;

import java.util.UUID;

import jakarta.persistence.Id;

public class CaseconsiderationData {

	@Id
	private UUID fos_caseconsiderationid;

	public UUID getFos_caseconsiderationid() {
		return fos_caseconsiderationid;
	}

}
