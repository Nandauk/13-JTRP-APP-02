package com.ombudsman.service;

import java.beans.Transient;
import java.sql.SQLException;
import java.time.Instant;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.jdbc.core.JdbcTemplate;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.microsoft.azure.functions.ExecutionContext;
import com.microsoft.azure.functions.annotation.FunctionName;
import com.microsoft.azure.functions.annotation.ServiceBusQueueTrigger;
import com.ombudsman.service.common.ConstantsConfig;
import com.ombudsman.service.common.JDBCConnectionUtil;
import com.ombudsman.service.model.CorrespondenceData;
import com.ombudsman.serviceimpl.EmailHelper;
import com.ombudsman.serviceimpl.TriggeredImpl;

public class AzurefunctriggereddeleteCorrespondence {

	Integer failedCount = 0, totalSuccessCount = 0, totalCount = 0;
	Logger LOG = LogManager.getRootLogger();

	TriggeredImpl triggerimpl = new TriggeredImpl();
	ConstantsConfig constant = new ConstantsConfig();
	JdbcTemplate jdbcTemplate = JDBCConnectionUtil.jdbcConnection();
	EmailHelper emailhelper = new EmailHelper();

	@FunctionName("CorrespondenceTriggerDelete")
	@Transient(true)
	public void serviceBusProcessCorrespondence(
			@ServiceBusQueueTrigger(name = "Correspondencemsg", queueName = "%QueueNameCorrespondence%", connection = "AzureWebJobsServiceBus") String message,
			final ExecutionContext context) throws SQLException {

		LOG.info("Message from Correspondence service bus queue : {}", message);

		ObjectMapper mapper = new ObjectMapper();
		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

		// Parse the JSON message into CorrespondenceData object
		try {
			LOG.info("AZURE STARTED in TRY BLOCK for : {}", constant.Entity_Correspondence);
			CorrespondenceData correspondenceData = mapper.readValue(message, CorrespondenceData.class);

			LOG.info("Correspondence ID : {} ", correspondenceData.getFos_correspondenceid());

			// entry in Correspondence table
			triggerimpl.insertRecordcorrespondence(correspondenceData.getFos_correspondenceid(), jdbcTemplate,
					constant.Entity_Correspondence);

		} catch (Exception e) {
			LOG.info("AZURE STARTED in CATCH BLOCK for : {}", constant.Entity_Correspondence);
			String emailTime = Instant.now().toString();

			// Send email to support team
			emailhelper.NotificationWebclient(constant.Entity_Correspondence, null, constant.DataSourceName,
					e.getMessage(), emailTime);
			//
			throw new RuntimeException(String.format("Job failed for %s entity with Error : %s",
					constant.Entity_Correspondence, e.getMessage()));
		}
	}
}
