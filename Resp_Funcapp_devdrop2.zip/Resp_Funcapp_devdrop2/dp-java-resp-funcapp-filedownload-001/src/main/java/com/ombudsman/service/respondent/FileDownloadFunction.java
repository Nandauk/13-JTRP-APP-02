package com.ombudsman.service.respondent;

import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.MediaType;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.util.CollectionUtils;
import org.springframework.web.reactive.function.client.WebClient;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.microsoft.azure.functions.ExecutionContext;
import com.microsoft.azure.functions.annotation.FunctionName;
import com.microsoft.azure.functions.annotation.TimerTrigger;
import com.ombudsman.service.respondent.daoimpl.DownloadRequestDaoimpl;
import com.ombudsman.service.respondent.exception.DocumentException;
import com.ombudsman.service.respondent.model.AuditMaster;
import com.ombudsman.service.respondent.model.CheckStatusResponseDto;
import com.ombudsman.service.respondent.model.DownloadFileEFileReq;
import com.ombudsman.service.respondent.model.DownloadRequestItem;
import com.ombudsman.service.respondent.model.FailedDownloadRequest;
import com.ombudsman.service.respondent.model.FailedDownloadRequestFiles;
import com.ombudsman.service.respondent.model.NotificationModel;
import com.ombudsman.service.respondent.repository.JDBCConnectionUtil;

import reactor.core.publisher.Mono;

/**
 * Azure Functions with HTTP Trigger.
 */
public class FileDownloadFunction {

	Logger log = LogManager.getRootLogger();
	DownloadRequestDaoimpl downloadRequestDao = new DownloadRequestDaoimpl();
	WebClient webclient;
	JDBCConnectionUtil jdbcConnectionUtil = new JDBCConnectionUtil();
	public static final String Prepare_Files_For_Download = System.getenv("APIM_URL_EFILE");
	final JdbcTemplate jdbcTemplate = jdbcConnectionUtil.getJdbcTemplate();
	NotificationModel notifyModel = new NotificationModel();

	
	/** * This function runs once every 20 mins. */
	@FunctionName("TimerTriggerFunction")
	public void processFailedFiles(@TimerTrigger(name = "timerInfo", schedule = "0 */20 * * * *") String packgid,
			final ExecutionContext context) {
		//context.getLogger().info("Processing the failed files task.");
		log.info("Starting the trigger function to process failed files");
	// public void test()
		// {
		List<FailedDownloadRequest> requests = new ArrayList<>();
	
		try {
			/*********
			 * Checking timezone for the 24 hour check for the requests to be prcessed
			 ********/
			boolean flag = getDateUtcToBstDiff();
			log.info("Flag to check the time zone" + flag);

			/*********
			 * Getting the requests with Failed files for the porcessing
			 *************/
			log.info("Getting the requests with Failed files for the porcessing");
			requests = downloadRequestDao.getFailedRequests(flag,jdbcTemplate);

			if (!CollectionUtils.isEmpty(requests)) {
				log.info("Data found to process failed files");
				for (FailedDownloadRequest downloadRequest : requests) {
					
					// Getting the failed files detail
					log.info("Getting Failed Files detail for request "+downloadRequest.getRequestId());
					List<FailedDownloadRequestFiles> filesDetail = downloadRequestDao
							.getFailedRequestFilesDetail(downloadRequest.getRequestId(),jdbcTemplate);
					
					if(!CollectionUtils.isEmpty(filesDetail))
					{
						log.info("Data found for failed files");
						String ticketNumber = filesDetail.get(0).getTicketNumber();
					// Posting Notification Entry
						log.info("Posting Notification Entity Record");
					String notificationId = postNotificationEntity(downloadRequest.getRequestId(),downloadRequest.getUserId(),ticketNumber);
					log.info("Notification Entity Record added with notificationId"+notificationId);
					// Posting download
					log.info("Posting eFile Request for Download");
					CheckStatusResponseDto statusCheck = postEfileDownloadRequest(filesDetail,
							downloadRequest.getRequestId(), notificationId);

					if (statusCheck != null && !(statusCheck.getId().isEmpty())) {
						log.info("Instance Id from E-File"+ statusCheck.getId());
						// Updating Request Processing Counter
						updateRequestProcessingCounter(downloadRequest.getRequestId(),
								downloadRequest.getRequestProcessingCounter());
						log.info("Processing counter updated");
					}
					}
				}
			} else {
				log.info("No records found to process.. Exiting the function.");
			}

		} catch (Exception e) {
			log.error(String.format("Error in TimerTriggerFunction %s", e.getMessage()));
		}
	}

	private boolean getDateUtcToBstDiff() {

		ZoneId zone1 = ZoneId.of("UTC");
		ZoneId zone2 = ZoneId.of("Europe/London");
		LocalDateTime dateTime = LocalDateTime.of(2019, 04, 11, 10, 5);
		ZonedDateTime panamaDateTime = ZonedDateTime.of(dateTime, zone1);
		ZonedDateTime taipeiDateTime = panamaDateTime.withZoneSameInstant(zone2);
		log.info("Difference between two time zones in seconds ={} " + taipeiDateTime.getOffset().getTotalSeconds());
		if (taipeiDateTime.getOffset().getTotalSeconds() > 0) {
			return true;
		} else {
			return false;
		}

	}

	public String postNotificationEntity(String requestId,String userId,String ticketNumber) throws Exception {

		int notificationId=0;
		try {
			log.info("postNotificationEntity method started ");
			notifyModel.setRequest_id(requestId);
			notifyModel.setUser_oid(userId); 
			notifyModel.setRequesting_activity_name("caseDownload");
			notifyModel.setMessage(ticketNumber);
			notifyModel.setNotification_status_id("1");
			notifyModel.setNotification_status_description("Pending");
			// UTC time
			ZonedDateTime utcTime = ZonedDateTime.now(ZoneId.of("UTC"));
			// BST timezone
			ZoneId bstzoneId = ZoneId.of("Europe/London");
			// Convert UTC time to BST , taking DST into account
			ZonedDateTime bsttime = utcTime.withZoneSameInstant(bstzoneId);
			notifyModel.setCreated_on(bsttime.format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));
			notifyModel.setCreated_by("FileDownloadFunctionApp");
		    notificationId = downloadRequestDao.postNotification(notifyModel,jdbcTemplate);
			log.info("Notification ID :" + notificationId);

			// creating audit for Notification
			AuditMaster audit = new AuditMaster();
			audit.setUserOID("Download Function App");
			OffsetDateTime offsetdatetime = OffsetDateTime.now();
			audit.setAuditEventTimestamp(offsetdatetime);
			audit.setAuditEventName("Failed Files Download Function App");
			audit.setPrimaryAuditEntity("dp_user_notification");
			audit.setPrimaryAuditEntityIdentifier("notification_id");
			audit.setPostAuditSnapshot("Notification_id=" + notificationId);
			audit.setCreatedOn(offsetdatetime);
			audit.setCreatedBy("Download Function App");
			downloadRequestDao.postAudityEntity(audit,jdbcTemplate);
			log.info("postNotificationEntity method ended ");
		} catch (Exception e) {
			log.error("Exception Occurred while Setting data in Notification Failed. {}", e.getMessage());
		}
		return String.valueOf(notificationId);
	}

	public CheckStatusResponseDto postEfileDownloadRequest(List<FailedDownloadRequestFiles> filesDetail,
			String requestId, String notificationId) {
		DownloadFileEFileReq eFileCallObj = new DownloadFileEFileReq();
		eFileCallObj.setIsRespondent(true);
		eFileCallObj.setCaseId(filesDetail.get(0).getCaseId());
		final ObjectMapper mapper = new ObjectMapper();
		List<DownloadRequestItem> files = filesDetail.stream()
				.map(i -> mapper.convertValue(i.getDocumentId(), DownloadRequestItem.class))
				.collect(Collectors.toList());
		eFileCallObj.setFiles(files);
		eFileCallObj.setRequestId(requestId);
		eFileCallObj.setNotificationId(notificationId);

		//String url = Prepare_Files_For_Download;
		log.info(String.format("fetching url from apim succesfully- for PrepareFilesForDownload :-%s", Prepare_Files_For_Download));
		CheckStatusResponseDto statusCheck = callPostApi(Prepare_Files_For_Download, eFileCallObj);
		return statusCheck;
	}

	public CheckStatusResponseDto callPostApi(String url, DownloadFileEFileReq eFileReqObj) {

		log.info("callGetApi method started ");
		try {

			CheckStatusResponseDto posturl = WebClient.create().post().uri(url)
					// .header(url, Authorization, Bearer + userbean.getAuthToken())
					.body(Mono.just(eFileReqObj), DownloadFileEFileReq.class).accept(MediaType.APPLICATION_JSON)
					.retrieve().bodyToMono(CheckStatusResponseDto.class).block();
		//CheckStatusResponseDto posturl = new CheckStatusResponseDto();
		//posturl.setId("testInstance2");
			log.info("callGetApi method :: post the url to apim ");

			return posturl;
		} catch (Exception ex) {
			log.error("Data sending failed from case download while posting to APIM {} {}",ex.getMessage(),ex.getStackTrace());
			throw new DocumentException(
					"Data sending failed from casedownload while posting to APIM. Please Try Again.", ex.getMessage(),
					ex.getStackTrace());
		}
	}

	public void updateRequestProcessingCounter(String requestId, String requestProcessingCounter) throws SQLException {
		int processingCounter = Integer.valueOf(requestProcessingCounter);
		processingCounter += 1;
		downloadRequestDao.updateProcessingCounter(UUID.fromString(requestId), processingCounter,jdbcTemplate);

		// creating audit for Notification
		AuditMaster audit = new AuditMaster();
		audit.setUserOID("Download Function App");
		OffsetDateTime offsetdatetime = OffsetDateTime.now();
		audit.setAuditEventTimestamp(offsetdatetime);
		audit.setAuditEventName("Failed Files Download Function App");
		audit.setPrimaryAuditEntity("dp_user_request");
		audit.setPrimaryAuditEntityIdentifier("request_id");
		audit.setPreAuditSnapshot("Pre Request Processing Counter :" + processingCounter);
		audit.setPostAuditSnapshot("Post Request Processing Counter=" + processingCounter + 1);
		audit.setCreatedBy("Download Function App");
		audit.setCreatedOn(offsetdatetime);
		downloadRequestDao.postAudityEntity(audit,jdbcTemplate);
	}
}
