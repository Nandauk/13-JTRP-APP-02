package com.ombudsman.service.respondent.model;

public class CheckStatusResponseDto {
	private String id ;
	private String statusQueryGetUri ;
	private String sendEventPostUri ;
	private String terminatePostUri ;
	private String purgeHistoryDeleteUri ;
	private String restartPostUri ;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getStatusQueryGetUri() {
		return statusQueryGetUri;
	}
	public void setStatusQueryGetUri(String statusQueryGetUri) {
		this.statusQueryGetUri = statusQueryGetUri;
	}
	public String getSendEventPostUri() {
		return sendEventPostUri;
	}
	public void setSendEventPostUri(String sendEventPostUri) {
		this.sendEventPostUri = sendEventPostUri;
	}
	public String getTerminatePostUri() {
		return terminatePostUri;
	}
	public void setTerminatePostUri(String terminatePostUri) {
		this.terminatePostUri = terminatePostUri;
	}
	public String getPurgeHistoryDeleteUri() {
		return purgeHistoryDeleteUri;
	}
	public void setPurgeHistoryDeleteUri(String purgeHistoryDeleteUri) {
		this.purgeHistoryDeleteUri = purgeHistoryDeleteUri;
	}
	public String getRestartPostUri() {
		return restartPostUri;
	}
	public void setRestartPostUri(String restartPostUri) {
		this.restartPostUri = restartPostUri;
	}
    
    
}
