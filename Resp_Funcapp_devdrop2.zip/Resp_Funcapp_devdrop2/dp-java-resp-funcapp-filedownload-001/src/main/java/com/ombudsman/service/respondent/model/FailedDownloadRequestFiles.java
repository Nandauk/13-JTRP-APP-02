package com.ombudsman.service.respondent.model;

public class FailedDownloadRequestFiles {
	
	String caseId;
	String documentId;
	String ticketNumber;
	public String getCaseId() {
		return caseId;
	}
	public void setCaseId(String caseId) {
		this.caseId = caseId;
	}
	public String getDocumentId() {
		return documentId;
	}
	public void setDocumentId(String documentId) {
		this.documentId = documentId;
	}
	public String getTicketNumber() {
		return ticketNumber;
	}
	public void setTicketNumber(String ticketNumber) {
		this.ticketNumber = ticketNumber;
	}
	public FailedDownloadRequestFiles(String caseId,String documentId,String ticketNumber)
	{
		super();
		this.setCaseId(caseId);
		this.setDocumentId(documentId);
		this.setTicketNumber(ticketNumber);
	}
}
