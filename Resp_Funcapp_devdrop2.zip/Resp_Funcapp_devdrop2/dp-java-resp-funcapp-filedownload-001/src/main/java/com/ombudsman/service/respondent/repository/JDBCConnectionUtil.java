package com.ombudsman.service.respondent.repository;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;


public class JDBCConnectionUtil {
	public static final Logger logger = LogManager.getRootLogger();
	
	public  static final String GET_FAILED_REQUEST_UTC="select ntc.request_id requestId from dp_user_notification ntc,dp_user_request user_req where ntc.request_id = user_req.request_id and ntc.requesting_activity_name='caseDownload' and notification_status_description='Failed' and DATEDIFF(second,ntc.created_on,GETDATE())<82800 and request_processing_counter <=3";
	public static final String GET_FAILED_REQUEST ="select ntc.request_id requestId from dp_user_notification ntc,dp_user_request user_req where ntc.request_id = user_req.request_id and ntc.requesting_activity_name='caseDownload' and notification_status_description='Failed' and DATEDIFF(second,ntc.created_on,GETDATE())<86400 and request_processing_counter <=3";
	
	public static Connection jdbcConnection() throws SQLException {
		return DriverManager.getConnection(System.getenv("SQL_DATASOURCE_URL"), System.getenv("SQL_DATASOURCE_USERNAME"),
				System.getenv("SQL_DATASOURCE_PASSWORD"));
	}
	
	
	public static JdbcTemplate getJdbcConnection() {
		JdbcTemplate con;
		DriverManagerDataSource dataSource = getDataSource();
		con = new JdbcTemplate(dataSource);
		logger.info("connection to jdbc:: {} ", con);
		return con;
	}
	
	public JdbcTemplate getJdbcTemplate() {
		JdbcTemplate jdbcTemplate = new JdbcTemplate();
		DriverManagerDataSource dataSource = new DriverManagerDataSource();
		dataSource.setDriverClassName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
		dataSource.setUrl(System.getenv("SQL_DATASOURCE_URL"));
		dataSource.setUsername(System.getenv("SQL_DATASOURCE_USERNAME"));
		dataSource.setPassword(System.getenv("SQL_DATASOURCE_PASSWORD"));
		jdbcTemplate = new JdbcTemplate(dataSource);
		return jdbcTemplate;
	}
	
	private static  DriverManagerDataSource getDataSource() {
		//logger.info("dataSource:: {}", System.getenv("SQL_DATASOURCE_URL"));
		DriverManagerDataSource dataSource = new DriverManagerDataSource();
		dataSource.setDriverClassName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
		dataSource.setUrl(System.getenv("SQL_DATASOURCE_URL"));
		dataSource.setUsername(System.getenv("SQL_DATASOURCE_USERNAME"));
		dataSource.setPassword(System.getenv("SQL_DATASOURCE_PASSWORD"));
		return dataSource;
	}
}
