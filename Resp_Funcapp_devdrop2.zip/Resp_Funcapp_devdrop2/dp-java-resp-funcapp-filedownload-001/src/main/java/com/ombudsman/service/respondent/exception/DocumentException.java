package com.ombudsman.service.respondent.exception;

public class DocumentException  extends RespondentsServiceExceptions{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public DocumentException(String message,String exceptionMessage,StackTraceElement[] stackTrace) {
		super(message, "DOCUMENTMANAGEMENT_UPLOAD_DOWNLOAD_INVALID_APIMURL_1004",exceptionMessage,stackTrace);
	}
}
