package com.ombudsman.service.respondent.model;

public class FailedDownloadRequest {
	
	private String requestId;
	private String requestProcessingCounter;
	private String notificationId;
	private String userId;

	public String getRequestId() {
		return requestId;
	}

	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}
	public String getRequestProcessingCounter() {
		return requestProcessingCounter;
	}

	public void setRequestProcessingCounter(String requestProcessingCounter) {
		this.requestProcessingCounter = requestProcessingCounter;
	}

	public String getNotificationId() {
		return notificationId;
	}

	public void setNotificationId(String notificationId) {
		this.notificationId = notificationId;
	}
	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public FailedDownloadRequest(String requestId,String requestProcessingCounter,String notificationId,String userId)
	{
		super();
		this.setRequestId(requestId);
		this.setRequestProcessingCounter(requestProcessingCounter);
		this.setNotificationId(notificationId);
		this.setUserId(userId);
	}
}
