package com.ombudsman.service.respondent.model;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class FailedDownloadRequestTest {
    
    private FailedDownloadRequest failedDownloadRequest;

    @BeforeEach
    void setUp() {
        failedDownloadRequest = new FailedDownloadRequest("Req123", "Counter1", "Notif123","UserId");
    }

    @Test
    void testConstructor() {
        assertEquals("Req123", failedDownloadRequest.getRequestId());
        assertEquals("Counter1", failedDownloadRequest.getRequestProcessingCounter());
        assertEquals("Notif123", failedDownloadRequest.getNotificationId());
        assertEquals("UserId", failedDownloadRequest.getUserId());
    }

    @Test
    void testSetRequestId() {
        String requestId = "Req456";
        failedDownloadRequest.setRequestId(requestId);
        assertEquals(requestId, failedDownloadRequest.getRequestId());
    }

    @Test
    void testSetRequestProcessingCounter() {
        String requestProcessingCounter = "Counter2";
        failedDownloadRequest.setRequestProcessingCounter(requestProcessingCounter);
        assertEquals(requestProcessingCounter, failedDownloadRequest.getRequestProcessingCounter());
    }

    @Test
    void testSetNotificationId() {
        String notificationId = "Notif456";
        failedDownloadRequest.setNotificationId(notificationId);
        assertEquals(notificationId, failedDownloadRequest.getNotificationId());
    }
    
    @Test
    void testSetUserId() {
        String userId = "UserId";
        failedDownloadRequest.setUserId(userId);
        assertEquals(userId, failedDownloadRequest.getUserId());
    }
}

