package com.ombudsman.service.respondent.model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

class CheckStatusResponseDtoTest {

	@Test
     void testGettersAndSetters() {
		CheckStatusResponseDto checkStatusResponseDtoTest = new CheckStatusResponseDto();
		 String id ="id" ;
		 String statusQueryGetUri ="statusQueryGetUri" ;
		 String sendEventPostUri ="sendEventPostUri" ;
		 String terminatePostUri ="terminatePostUri" ;
		 String purgeHistoryDeleteUri ="purgeHistoryDeleteUri" ;
		 String restartPostUri ="restartPostUri" ;
		 
		 checkStatusResponseDtoTest.setId(id);
		 checkStatusResponseDtoTest.setStatusQueryGetUri(statusQueryGetUri);
		 checkStatusResponseDtoTest.setSendEventPostUri(sendEventPostUri);
		 checkStatusResponseDtoTest.setTerminatePostUri(terminatePostUri);
		 checkStatusResponseDtoTest.setPurgeHistoryDeleteUri(purgeHistoryDeleteUri);
		 checkStatusResponseDtoTest.setRestartPostUri(restartPostUri);

		 assertEquals(id,checkStatusResponseDtoTest.getId());
		 assertEquals(statusQueryGetUri,checkStatusResponseDtoTest.getStatusQueryGetUri());
		 assertEquals(sendEventPostUri,checkStatusResponseDtoTest.getSendEventPostUri());
		 assertEquals(terminatePostUri,checkStatusResponseDtoTest.getTerminatePostUri());
		 assertEquals(purgeHistoryDeleteUri,checkStatusResponseDtoTest.getPurgeHistoryDeleteUri());
		 assertEquals(restartPostUri,checkStatusResponseDtoTest.getRestartPostUri());
	}
}
