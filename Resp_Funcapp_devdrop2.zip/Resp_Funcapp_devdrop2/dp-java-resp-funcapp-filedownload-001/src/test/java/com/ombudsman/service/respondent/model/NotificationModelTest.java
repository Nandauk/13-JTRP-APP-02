package com.ombudsman.service.respondent.model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

public class NotificationModelTest {
	@Test
    public void testGettersAndSetters() {
        NotificationModel notificationModel = new NotificationModel();
        
        Long notificationId = 1L;
        String requestId = "req123";
        String userOid = "user456";
        String requestingActivityName = "activityName";
        String message = "Test message";
        String notificationStatusId = "statusId";
        String notificationStatusDescription = "statusDescription";
        String fileDownloadUrl = "http://example.com/download";
        String modifiedBy = "modifier";
        String createdOn = "2025-01-03";
        String createdBy = "creator";
        String modifiedOn = "2025-01-03";
        
        notificationModel.setNotification_id(notificationId);
        notificationModel.setRequest_id(requestId);
        notificationModel.setUser_oid(userOid);
        notificationModel.setRequesting_activity_name(requestingActivityName);
        notificationModel.setMessage(message);
        notificationModel.setNotification_status_id(notificationStatusId);
        notificationModel.setNotification_status_description(notificationStatusDescription);
        notificationModel.setFile_download_url(fileDownloadUrl);
        notificationModel.setModified_by(modifiedBy);
        notificationModel.setCreated_on(createdOn);
        notificationModel.setCreated_by(createdBy);
        notificationModel.setModified_on(modifiedOn);

        assertEquals(notificationId, notificationModel.getNotification_id());
        assertEquals(requestId, notificationModel.getRequest_id());
        assertEquals(userOid, notificationModel.getUser_oid());
        assertEquals(requestingActivityName, notificationModel.getRequesting_activity_name());
        assertEquals(message, notificationModel.getMessage());
        assertEquals(notificationStatusId, notificationModel.getNotification_status_id());
        assertEquals(notificationStatusDescription, notificationModel.getNotification_status_description());
        assertEquals(fileDownloadUrl, notificationModel.getFile_download_url());
        assertEquals(modifiedBy, notificationModel.getModified_by());
        assertEquals(createdOn, notificationModel.getCreated_on());
        assertEquals(createdBy, notificationModel.getCreated_by());
        assertEquals(modifiedOn, notificationModel.getModified_on());
    }

}
