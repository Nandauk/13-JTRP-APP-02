package com.ombudsman.service.respondent.model;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class FailedDownloadRequestFilesTest {
    
    private FailedDownloadRequestFiles failedDownloadRequestFiles;

    @BeforeEach
    void setUp() {
        failedDownloadRequestFiles = new FailedDownloadRequestFiles("Case123", "Doc456","TicketNumber789");
    }

    @Test
    void testConstructor() {
        assertEquals("Case123", failedDownloadRequestFiles.getCaseId());
        assertEquals("Doc456", failedDownloadRequestFiles.getDocumentId());
        assertEquals("TicketNumber789", failedDownloadRequestFiles.getTicketNumber());
    }

    @Test
    void testSetCaseId() {
        String caseId = "Case789";
        failedDownloadRequestFiles.setCaseId(caseId);
        assertEquals(caseId, failedDownloadRequestFiles.getCaseId());
    }

    @Test
    void testSetDocumentId() {
        String documentId = "Doc789";
        failedDownloadRequestFiles.setDocumentId(documentId);
        assertEquals(documentId, failedDownloadRequestFiles.getDocumentId());
    }
    
    @Test
    void testSetTicketNumber() {
        String ticketNumber = "TicketNumber789";
        failedDownloadRequestFiles.setTicketNumber(ticketNumber);
        assertEquals(ticketNumber, failedDownloadRequestFiles.getTicketNumber());
    }
}

