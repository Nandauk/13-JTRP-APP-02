package com.ombudsman.service.respondent;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.springframework.http.MediaType;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;

import com.microsoft.azure.functions.ExecutionContext;
import com.ombudsman.service.respondent.daoimpl.DownloadRequestDaoimpl;
import com.ombudsman.service.respondent.exception.DocumentException;
import com.ombudsman.service.respondent.model.AuditMaster;
import com.ombudsman.service.respondent.model.CheckStatusResponseDto;
import com.ombudsman.service.respondent.model.DownloadFileEFileReq;
import com.ombudsman.service.respondent.model.FailedDownloadRequest;
import com.ombudsman.service.respondent.model.FailedDownloadRequestFiles;
import com.ombudsman.service.respondent.model.NotificationModel;
import com.ombudsman.service.respondent.repository.JDBCConnectionUtil;

import reactor.core.publisher.Mono;

@ExtendWith(SpringExtension.class)
class FileDownloadFunctionTest {
	
	@InjectMocks
	FileDownloadFunction mockFileDownloadFunction;
	
	@Mock
	DownloadRequestDaoimpl mockDownloadRequestDao;
	
    @Mock 
    JDBCConnectionUtil jdbcConnectionUtil;
    
	@Mock
	JdbcTemplate jdbcTemplate;
	
	@Mock
    private WebClient webClient;

    @Mock
    private WebClient.RequestBodyUriSpec requestBodyUriSpec;

    @Mock
    private WebClient.RequestBodySpec requestBodySpec;

    @Mock
    private WebClient.RequestHeadersSpec requestHeadersSpec;

    @Mock
    private WebClient.ResponseSpec responseSpec;
    
    @Mock
    NotificationModel notifyModel;
    
    @Mock
    ExecutionContext context;
    
    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
        when(jdbcConnectionUtil.getJdbcTemplate()).thenReturn(jdbcTemplate);
    }
	
	@Spy
	private final FileDownloadFunction spyInstance = new FileDownloadFunction() {
		
		@Override
		public CheckStatusResponseDto callPostApi(String url, DownloadFileEFileReq eFileReqObj) {
			CheckStatusResponseDto testStatusCheck = new CheckStatusResponseDto();
			
			testStatusCheck.setId("testInstance");
			return testStatusCheck;
		}
	};
	
	@Test
	void testUpdateRequestProcessingCounter() throws SQLException
	{
		UUID requestId = UUID.randomUUID();
		String requestProcessingCounter="1";
		
		Mockito.doNothing().when(mockDownloadRequestDao).updateProcessingCounter(Mockito.any(),Mockito.anyInt(),Mockito.any());
		Mockito.doNothing().when(mockDownloadRequestDao).postAudityEntity(Mockito.any(),Mockito.any());
		
		mockFileDownloadFunction.updateRequestProcessingCounter(requestId.toString(), requestProcessingCounter);
		
		assertNotNull(requestProcessingCounter);
		
	}

	@Test 
	void testPostEfileDownloadRequest()
	{
		List<FailedDownloadRequestFiles> testFilesDetail = new ArrayList<>();
		FailedDownloadRequestFiles mockFailedDownloadRequestFiles = new FailedDownloadRequestFiles("testCaseId","testDocumentId","testTicketNumber");
		testFilesDetail.add(mockFailedDownloadRequestFiles);
		
		CheckStatusResponseDto testStatusCheck = new CheckStatusResponseDto();
		
		testStatusCheck.setId("testInstance");
		
		String testRequestId = "testRequestId";
		String testNotificationId = "testNotificationId";
		
		//FileDownloadFunction mFileDownloadFunction = new FileDownloadFunction();
		//FileDownloadFunction spyFileDownloadFunction = Mockito.spy(mFileDownloadFunction);
		
		//Mockito.doReturn(testStatusCheck).when(spyFileDownloadFunction).callPostApi(Mockito.anyString(), Mockito.any(DownloadFileEFileReq.class));
		
		Mockito.doReturn(testStatusCheck).when(spyInstance).callPostApi(Mockito.anyString(), Mockito.any(DownloadFileEFileReq.class));
		
		assertNotNull(spyInstance.postEfileDownloadRequest(testFilesDetail, testRequestId, testNotificationId));
	}
	
	@Test
	void testProcessFailedFiles() throws SQLException
	{
		List<FailedDownloadRequest> requests = new ArrayList<>();
		FailedDownloadRequest testRequest = new FailedDownloadRequest("testRequestId","0","testNotificationId","testUserId");
		requests.add(testRequest);
		List<FailedDownloadRequestFiles> filesDetail = new ArrayList<>();
		FailedDownloadRequestFiles testFailedFile = new FailedDownloadRequestFiles("testCaseId","testDocumentId","testTicketNumber");
		filesDetail.add(testFailedFile);
		CheckStatusResponseDto testStatusCheck = new CheckStatusResponseDto();
		testStatusCheck.setId("testInstanceId");
		
		when(mockDownloadRequestDao.getFailedRequests(Mockito.anyBoolean(),Mockito.any())).thenReturn(requests);
		when(mockDownloadRequestDao.postNotification(Mockito.any(NotificationModel.class),Mockito.any())).thenReturn(1);
		Mockito.doNothing().when(mockDownloadRequestDao).postAudityEntity(Mockito.any(AuditMaster.class),Mockito.any());
		when(mockDownloadRequestDao.getFailedRequestFilesDetail(Mockito.anyString(),Mockito.any())).thenReturn(filesDetail);
		
		//when(mockFileDownloadFunction.callPostApi(Mockito.any(),Mockito.any())).thenReturn(testStatusCheck);
		//Mockito.doNothing().when(mockDownloadRequestDao).updateProcessingCounter(Mockito.any(), Mockito.anyInt(), Mockito.any());
		
		mockFileDownloadFunction.processFailedFiles("testPackageId", context);
		
	}

    @Test
     void testGetDateUtcToBstDiff() {
        ZoneId zone1 = ZoneId.of("UTC");
        ZoneId zone2 = ZoneId.of("Europe/London");
        LocalDateTime dateTime = LocalDateTime.of(2019, 4, 11, 10, 5);
        ZonedDateTime panamaDateTime = ZonedDateTime.of(dateTime, zone1);
        ZonedDateTime taipeiDateTime = panamaDateTime.withZoneSameInstant(zone2);
        int offsetInSeconds = taipeiDateTime.getOffset().getTotalSeconds();

        boolean result = offsetInSeconds > 0;
        
        assertTrue(result, "Offset in seconds should be greater than 0");
    }
	
    @Test
     void testCallPostApiSuccess() {
        String url = "http://example.com";
        DownloadFileEFileReq eFileReqObj = new DownloadFileEFileReq();
        CheckStatusResponseDto responseDto = new CheckStatusResponseDto();

        when(webClient.post()).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.uri(url)).thenReturn(requestBodySpec);
        when(requestBodySpec.body(any(Mono.class), eq(DownloadFileEFileReq.class))).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.accept(MediaType.APPLICATION_JSON)).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.bodyToMono(CheckStatusResponseDto.class)).thenReturn(Mono.just(responseDto));

        /*CheckStatusResponseDto result = mockFileDownloadFunction.callPostApi(url, eFileReqObj);

        assertNotNull(result);
        assertEquals(responseDto, result);*/
    }

    @Test
    void testCallPostApiFailure() {
        String url = "http://example.com";
        DownloadFileEFileReq eFileReqObj = new DownloadFileEFileReq();

        when(webClient.post()).thenReturn(requestBodyUriSpec);
        when(requestBodyUriSpec.uri(url)).thenReturn(requestBodySpec);
        when(requestBodySpec.body(any(Mono.class), eq(DownloadFileEFileReq.class))).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.accept(MediaType.APPLICATION_JSON)).thenReturn(requestHeadersSpec);
        when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
        when(responseSpec.bodyToMono(CheckStatusResponseDto.class)).thenReturn(Mono.error(new WebClientResponseException("Error", 500, "Internal Server Error", null, null, null)));

        assertThrows(DocumentException.class, () -> mockFileDownloadFunction.callPostApi(url, eFileReqObj));
    }
}
