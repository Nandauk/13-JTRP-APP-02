package com.ombudsman.service.respondent.daoimpl;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.when;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.ombudsman.service.respondent.model.AuditMaster;
import com.ombudsman.service.respondent.model.FailedDownloadRequest;
import com.ombudsman.service.respondent.model.FailedDownloadRequestFiles;
import com.ombudsman.service.respondent.repository.JDBCConnectionUtil;

@ExtendWith(SpringExtension.class)
class DownloadRequestDaoimplTest{
	
	@InjectMocks
     DownloadRequestDaoimpl testDownloadRequestDaoimpl;
	
	@Mock 
	JDBCConnectionUtil jdbcConnectionUtil;

	Logger log = LogManager.getRootLogger();
	
	@Mock
	JdbcTemplate jdbcTemplate;
	
    @Mock
    Connection connection;

    @Mock
    PreparedStatement preparedStatement;

    @Mock
    private KeyHolder keyHolder;
	
    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
        when(jdbcConnectionUtil.getJdbcTemplate()).thenReturn(jdbcTemplate);
    }

	@DisplayName("testGetFailedRequests_UTC")
	@Test
	void testGetFailedRequests_UTC() throws SQLException {
		log.info("Inside method");
		
		  Boolean timeZone = true;
		  List<FailedDownloadRequest> requests = new ArrayList<>();
		  FailedDownloadRequest testFailedDownloadRequest= new FailedDownloadRequest("testRequest", "2","testNotificationId","testUserId");
		  requests.add(testFailedDownloadRequest);

		  when(jdbcTemplate.query(Mockito.anyString(), Mockito.any(RowMapper.class))).thenReturn(requests);
		  
		  List<FailedDownloadRequest> requestsOutput = testDownloadRequestDaoimpl.getFailedRequests(timeZone,jdbcTemplate);
		  
		  assertNotNull(requestsOutput);
		 }

	@DisplayName("testGetFailedRequests")
	@Test
	void testGetFailedRequests() throws SQLException {
		log.info("Inside method");
		
		  Boolean timeZone = false;
		  List<FailedDownloadRequest> requests = new ArrayList<>();
		  FailedDownloadRequest testFailedDownloadRequest= new FailedDownloadRequest("testRequest", "2","testNotificationId","testUserId");
		  requests.add(testFailedDownloadRequest);

		  when(jdbcTemplate.query(Mockito.anyString(), Mockito.any(RowMapper.class))).thenReturn(requests);
		  
		  List<FailedDownloadRequest> requestsOutput = testDownloadRequestDaoimpl.getFailedRequests(timeZone,jdbcTemplate);
		  
		  assertNotNull(requestsOutput);
		 }
	
	@Test
	void testgetFailedRequestFilesDetail() throws DataAccessException, SQLException {
		
		List<FailedDownloadRequestFiles> failedFilesDetail = new ArrayList<>(); 
		FailedDownloadRequestFiles testFailedDownloadRequestFile = new FailedDownloadRequestFiles("testCaseId", "testDocumentId","testTicketNumber");
		failedFilesDetail.add(testFailedDownloadRequestFile);
		
		String testRequestId = "testRequestId";
		
		when(jdbcTemplate.query(Mockito.anyString(), Mockito.any(RowMapper.class),Mockito.anyString())).thenReturn(failedFilesDetail);
		
		List<FailedDownloadRequestFiles> failedFilesDetailOutput = testDownloadRequestDaoimpl.getFailedRequestFilesDetail(testRequestId,jdbcTemplate);
				
		assertNotNull(failedFilesDetailOutput);
	}
	
	@Test
	void testPostAudityEntity() throws SQLException {
		
		AuditMaster auditMaster = new AuditMaster();
		String response = "success";
		
		when(jdbcTemplate.update(Mockito.anyString(),Mockito.anyString(),Mockito.anyString(),Mockito.anyString(),Mockito.anyString(),Mockito.anyString()
				,Mockito.anyString(),Mockito.anyString(),Mockito.anyString(),Mockito.anyString())).thenReturn(1);
		
		testDownloadRequestDaoimpl.postAudityEntity(auditMaster,jdbcTemplate);
		
		assertEquals("success", response);
	}
	
	@Test
	void testUpdateProcessingCounter() throws SQLException {
		
		UUID testRequestId = UUID.randomUUID();
		int processingCounetr = 1;
		
		String response = "success";
		
		when(jdbcTemplate.update(Mockito.anyString(),Mockito.anyString(),Mockito.any())).thenReturn(1);
		
		testDownloadRequestDaoimpl.updateProcessingCounter(testRequestId, processingCounetr,jdbcTemplate);
		
		assertEquals("success", response);
	}
	
   /* @Test
    void testPostNotification() throws SQLException {
    	
    	NotificationModel notifyModel = new NotificationModel();
    	
    	notifyModel.setRequest_id("testRequest");
    	notifyModel.setUser_oid("testOid");
    	notifyModel.setRequesting_activity_name("testRequest");
    	notifyModel.setNotification_status_id("testStatusId");
    	notifyModel.setNotification_status_description("testStatus");
    	notifyModel.setMessage("testMessage");
    	notifyModel.setCreated_on("createdOn");
    	notifyModel.setCreated_by("createdBy");
    	
    	when(jdbcConnectionUtil.jdbcConnection()).thenReturn(connection);
        when(connection.prepareStatement(Mockito.any(String.class), Mockito.any(int.class))).thenReturn(preparedStatement);
        when(preparedStatement.getGeneratedKeys()).thenReturn(Mockito.mock(java.sql.ResultSet.class));
        when(keyHolder.getKey()).thenReturn(1);
        
        when(jdbcTemplate.update(Mockito.any(PreparedStatementCreator.class), Mockito.any(KeyHolder.class))).thenAnswer(invocation -> {
            PreparedStatementCreator psc = invocation.getArgument(0);
            psc.createPreparedStatement(connection);
            KeyHolder kh = invocation.getArgument(1);
            kh.getKeyList().add(Map.of("GENERATED_KEY", 1));
            return 1;
        });

        int result = testDownloadRequestDaoimpl.postNotification(notifyModel, jdbcTemplate);
        assertEquals(1, result);
    }*/
}
