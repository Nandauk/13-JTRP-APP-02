package com.ombudsman.service.respondent.test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.logging.log4j.Logger;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.microsoft.azure.functions.ExecutionContext;
import com.ombudsman.service.respondent.AzureWorkerServiceBus;
import com.ombudsman.service.respondent.common.CaseExportWorkerImpl;
import com.ombudsman.service.respondent.exception.SQLDataAccessException;
import com.ombudsman.service.respondent.model.Attributes;
import com.ombudsman.service.respondent.model.Case;
import com.ombudsman.service.respondent.model.CaseExport;
import com.ombudsman.service.respondent.model.CaseListDto;
import com.ombudsman.service.respondent.model.Filters;
import com.ombudsman.service.respondent.model.GetCasesByRespondentRes;
import com.ombudsman.service.respondent.model.Users;

@ExtendWith(SpringExtension.class)
class AzureWorkerServiceBusTest {

	@Mock
	CaseExport mMockcaseExport;

	@Mock
	Attributes mMockAttributes;
	@Mock
	CaseExportWorkerImpl mMockCaseExportWorkerImpl;

	@Mock
	Users mMockusers;

	@Mock
	Filters mMockfilters;
	@Mock
	ObjectMapper mapper;

	@InjectMocks
	AzureWorkerServiceBus testInstance;

	@Mock
	CaseListDto mMockdto;

	@Mock
	JdbcTemplate jdbcTemplate;

	@Mock
	Case mMockCase;

	@Test
	void testAzureWorkerServiceBus() throws IOException {
		final Map<String, Object> caseList1 = new HashMap<>();
		final Map<String, Object> caseList2 = new HashMap<>();

		mMockdto.setBusinessname("gt987");
		mMockdto.setCustomerid("gt987");
		mMockdto.setTicketnumber("PNX-102");
		mMockdto.setStatuscode("0");

		caseList1.put("#result-set-2", mMockdto);

		List<String> role = new ArrayList<String>();
		role.add("Respondent Admin");

		List<String> orgs = new ArrayList<String>();
		orgs.add("2345pqrs");

		mMockfilters.setStartdate("");
		mMockfilters.setEnddate("");
		mMockfilters.setSearchBy("");

		Mockito.when(mMockcaseExport.getAttributes()).thenReturn(mMockAttributes);
		Mockito.when(mMockAttributes.getUsers()).thenReturn(mMockusers);
		Mockito.when(mMockcaseExport.getAttributes().getFilters()).thenReturn(mMockfilters);
		Mockito.when(mMockcaseExport.getMessageId()).thenReturn("1234");
		Mockito.when(mapper.readValue(Mockito.anyString(), Mockito.eq(CaseExport.class))).thenReturn(mMockcaseExport);
		Mockito.when(mMockAttributes.getOrganisations()).thenReturn(orgs);
		final ExecutionContext context = mock(ExecutionContext.class);

		try {
			testInstance.caseExportWorkerFunction(mMockcaseExport.toString(), context);
			// Verify
			assertNotNull(mMockcaseExport);
		} catch (Exception e) {

		}

	}

	@Test
	void testAzureWorkerServiceBusFail() throws IOException {
		final Map<String, Object> caseList1 = new HashMap<>();
		final Map<String, Object> caseList2 = new HashMap<>();

		mMockdto.setBusinessname("gt987");
		mMockdto.setCustomerid("gt987");
		mMockdto.setTicketnumber("PNX-102");
		mMockdto.setStatuscode("0");

		caseList1.put("#result-set-2", mMockdto);

		List<String> role = new ArrayList<String>();
		role.add("Respondent Admin");

		List<String> orgs = new ArrayList<String>();
		orgs.add("2345pqrs");

		mMockfilters.setStartdate("");
		mMockfilters.setEnddate("");
		mMockfilters.setSearchBy("");

		Mockito.when(mMockcaseExport.getAttributes()).thenReturn(mMockAttributes);
		Mockito.when(mMockAttributes.getUsers()).thenReturn(mMockusers);
		Mockito.when(mMockcaseExport.getAttributes().getFilters()).thenReturn(mMockfilters);
		Mockito.when(mMockcaseExport.getMessageId()).thenReturn("1234");
		Mockito.when(mapper.readValue(Mockito.anyString(), Mockito.eq(CaseExport.class))).thenReturn(mMockcaseExport);
		Mockito.when(mMockAttributes.getOrganisations()).thenReturn(orgs);

		final ExecutionContext context = mock(ExecutionContext.class);

		try {
			testInstance.caseExportWorkerFunction(mMockcaseExport.toString(), context);
			assertNotNull(mMockcaseExport);
		} catch (Exception e) {

		}

	}

	@Test
	 void testValidSearchRequestWithGroups() throws ParseException {
		// Setup
		CaseExport exportReqModel = mock(CaseExport.class);
		Attributes mockattribute = new Attributes();
		Filters mockfilter = new Filters();
		mockfilter.setSearchBy("test");
		mockattribute.setFilters(mockfilter);
		mockattribute.setOpencasesonly("openCase");
		mockattribute.setOrganisations(Arrays.asList("test1", "test2"));
		exportReqModel.setAttributes(mockattribute);
		GetCasesByRespondentRes getCasesByRespondentRes = new GetCasesByRespondentRes();
		getCasesByRespondentRes.setCases(new ArrayList<CaseListDto>());
		Map<String, Object> mockRequestData = new HashMap<>();
		mockRequestData.put("key", "value");
		Map<String, Object> mockCaseList = new HashMap<>();
		mockCaseList.put("RESULT_SET_2", new ArrayList<>());
		when(mMockCaseExportWorkerImpl.getRequestData(Mockito.any(), Mockito.any(), Mockito.any()))
				.thenReturn(mockRequestData);
		// Verify
		assertNotNull(getCasesByRespondentRes);
		assertEquals(0, getCasesByRespondentRes.getCases().size());
	}

	@Test
	 void testSearchRequestWithNoGroupsThrowsException() throws IOException {
		// Setup
		CaseExport exportReqModel = new CaseExport();
		Attributes mockattribute = new Attributes();
		Filters mockfilter = new Filters();
		mockfilter.setSearchBy("test");
		mockattribute.setFilters(mockfilter);
		mockattribute.setOpencasesonly("openCase");
		mockattribute.setOrganisations(Arrays.asList("test1", "test2"));
		exportReqModel.setAttributes(mockattribute);

		GetCasesByRespondentRes getCasesByRespondentRes = new GetCasesByRespondentRes();
		// Execute & Verify
		testInstance.caseExportWorkerFunction(
				"{\"version\":\"v1\",\"messageId\":\"\",\"entityName\":\"Caselist\",\"templateId\":\"\",\"attributes\":{\"opencasesonly\":\"true\",\"organisations\":[],\"users\":{\"oid\":\"\",\"fullName\":\"\",\"email\":\"\",\"roles\":[]},\"filters\":{\"complaintissue\":[],\"casestatus\":[],\"awaitingactionbusiness\":[],\"producttype\":[],\"casestage\":[{\"id\":\"140000003\",\"value\":\"View\"}],\"businessname\":[],\"tradingname\":[],\"caseowner\":[],\"caseage\":[],\"closeroutcome\":[],\"prioritycases\":[],\"oldcasestatus\":[],\"agecaseflag\":[],\"startdate\":null,\"enddate\":null,\"page\":1,\"pagesize\":10,\"searchBy\":\"\",\"sortby\":\"fos_dateofconversion\",\"sorttype\":\"desc\"}},\"numberOfCases\":[\"58F37588-B575-EF11-A670-6045BD0CE8C9\",\"1EEE8575-DE7C-EB11-A812-0022481A6B91\"]}",
				null);
		assertNotNull(exportReqModel);
	}

	@Mock
	private Logger logger;
	@Mock
	private SimpleJdbcCall simpleJdbcCall;

	@Test
	 void testGetCasesByRespondent_ValidInput() throws SQLDataAccessException {
		// Given
		Map<String, Object> expectedData = new HashMap<>();
		String stringofgroups = "group1,group2";
		Map<String, Object> caseList = new HashMap<>();
		caseList.put("caseKey", "caseValue");
		Map<String, Object> caseListmap = new HashMap<>();
		caseListmap.put("caseKey", "caseValue");
		expectedData.put("searchby", "");
		expectedData.put("pagesize", 100);
		expectedData.put("pagecount", 1);
		expectedData.put("fromdate", "2024-09-01");

		expectedData.put("todate", "2024-12-01");
		expectedData.put("sortby", "fos_dateofconversion");
		expectedData.put("sorttype", "desc");
		expectedData.put("isOpenCases", true);
		expectedData.put("complainantissue", "#");
		expectedData.put("casestatus", "#");
		expectedData.put("producttype", "#");
		expectedData.put("casestage", "#");
		expectedData.put("tradingname", "#");
		expectedData.put("caseowner", "#");
		expectedData.put("caseage", "#");
		expectedData.put("prioritycase", "#");
		expectedData.put("livecaseage", "#");
		expectedData.put("accountid", "#");
		expectedData.put("accountids", "FC412CFE-8089-4832-ABC4-6854948ED423");
		expectedData.put("resolvingoutcome", "#");
		expectedData.put("awaitingactionfilter", "#");
		expectedData.put("incidentid", "#");
		when(simpleJdbcCall.execute(Mockito.any(SqlParameterSource.class))).thenReturn(caseList);
		assertEquals(caseListmap, caseList);
	}

	@Test
	void testGetCasesByRespondent_InvalidInput() throws SQLDataAccessException {
		// Given
		Map<String, Object> expectedData = new HashMap<>();
		String stringofgroups = "";
		JdbcTemplate jdbcTemplate = testInstance.jdbcConnection();
		// When
		Map<String, Object> result = testInstance.getCasesByRespondent(expectedData, stringofgroups, jdbcTemplate);
		// Then
		assertNull(result);
	}

}
