package com.ombudsman.service.respondent.test.exception;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.Test;

import com.ombudsman.service.respondent.exception.CaseFilterNotFoundException;

class CaseFilterNotFoundExceptionTest {

	@Test
	void testConstructor_ValidInput() {
// Prepare input value
		String orgName = "Test Organization";

// Create the exception instance
		CaseFilterNotFoundException exception = new CaseFilterNotFoundException(orgName);

// Validate that the exception was created with the correct message
		assertNotNull(exception, "Exception should not be null");
		assertEquals(orgName, exception.getMessage(), "The exception message should match the input orgName");
	}

}
