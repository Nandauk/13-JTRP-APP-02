package com.ombudsman.service.respondent.test.exception;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.Test;

import com.ombudsman.service.respondent.exception.RespondentsServiceExceptions;

class RespondentsServiceExceptionsTest {

	@Test
	void testConstructor_ValidInput() {
// Prepare input values
		String message = "Test message";
		String code = "TEST_CODE_001";
		String exceptionMessage = "Test exception message";
		StackTraceElement[] stackTraceElements = new StackTraceElement[] {
				new StackTraceElement("ClassName", "methodName", "fileName", 10) };

// Create the RespondentsServiceExceptions instance
		RespondentsServiceExceptions exception = new RespondentsServiceExceptions(message, code, exceptionMessage,
				stackTraceElements);

// Validate that the exception was correctly initialized
		assertNotNull(exception, "The exception should not be null");

// Check the message
		assertEquals(message, exception.getMessage(), "The exception message should match the input message");

// Check the code
		assertEquals(code, exception.getCode(), "The exception code should match the input code");

// Check the exception message
		assertEquals(exceptionMessage, exception.getExceptionMessage(),
				"The exception message should match the input exceptionMessage");

// Check the stack trace
		assertArrayEquals(stackTraceElements, exception.getStackTraceMessage(),
				"The stack trace should match the input stack trace");
	}

	@Test

	void testGetCode() {
// Prepare input values
		String code = "TEST_CODE_002";

// Create the RespondentsServiceExceptions instance
		RespondentsServiceExceptions exception = new RespondentsServiceExceptions("Test message", code,
				"Test exception message", new StackTraceElement[0]);

// Validate that the code is correctly returned
		assertEquals(code, exception.getCode(), "The code should match the expected value");
	}

	@Test
	void testGetExceptionMessage() {
// Prepare input values
		String exceptionMessage = "Test exception message";

// Create the RespondentsServiceExceptions instance
		RespondentsServiceExceptions exception = new RespondentsServiceExceptions("Test message", "TEST_CODE_003",
				exceptionMessage, new StackTraceElement[0]);

// Validate that the exception message is correctly returned
		assertEquals(exceptionMessage, exception.getExceptionMessage(),
				"The exception message should match the expected value");
	}

	@Test
	void testGetStackTraceMessage() {
// Prepare input values

		StackTraceElement[] stackTraceElements = new StackTraceElement[] {
				new StackTraceElement("ClassName", "methodName", "fileName", 10) };

// Create the RespondentsServiceExceptions instance
		RespondentsServiceExceptions exception = new RespondentsServiceExceptions("Test message", "TEST_CODE_004",
				"Test exception message", stackTraceElements);

// Validate that the stack trace is correctly returned
		assertArrayEquals(stackTraceElements, exception.getStackTraceMessage(),
				"The stack trace should match the expected value");
	}
}
