package com.ombudsman.service.respondent.model.test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;

import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import com.ombudsman.service.respondent.model.Attributes;
import com.ombudsman.service.respondent.model.CaseFilterData;
import com.ombudsman.service.respondent.model.Filters;
import com.ombudsman.service.respondent.model.Users;

import jakarta.validation.Validation;
import jakarta.validation.Validator;
import jakarta.validation.ValidatorFactory;
@ExtendWith(MockitoExtension.class)
class ModelTest {
	private Validator validator;
	private Attributes attributes;
	private Users users;
	private Filters filters;
	private CaseFilterData caseFilterData;

	private List<String> organisations;

	@BeforeEach
	public void setUp() {
	// Set up the Validator for @NotNull and @NotEmpty validation
	ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
	validator = factory.getValidator();

	// Initialize model objects
	attributes = new Attributes();
	users = new Users();
	filters = new Filters();
	caseFilterData = new CaseFilterData();
	organisations = Arrays.asList("Org1", "Org2");

	// Set up Users object
	users.setOid("123");
	users.setFullName("John Doe");
	users.setEmail("john.doe@example.com");
	users.setRoles(Arrays.asList("Admin", "User"));

	// Set up CaseFilterData
	caseFilterData.setId("filter1");
	caseFilterData.setValue("Test Filter");

	// Set up Filters object
	filters.setBusinessname(Arrays.asList(caseFilterData));
	filters.setComplaintissue(Arrays.asList(caseFilterData));

	}

	@Test
	public void testSetAndGetUsers() {
	// Test setter and getter for users
	attributes.setUsers(users);
	assertEquals(users, attributes.getUsers(), "The users object should be correctly set and retrieved.");
	}

	@Test
	public void testSetAndGetFilters() {
	// Test setter and getter for filters
	attributes.setFilters(filters);
	assertEquals(filters, attributes.getFilters(), "The filters object should be correctly set and	retrieved.");
	}

	@Test
	public void testSetAndGetOpencasesonly() {
	// Test setter and getter for opencasesonly
	String opencasesonly = "true";
	attributes.setOpencasesonly(opencasesonly);
	assertEquals(opencasesonly, attributes.getOpencasesonly(), "The opencasesonly field should be correctly set and retrieved.");
	}

	@Test
	public void testSetAndGetOrganisations() {

	// Test setter and getter for organisations
	attributes.setOrganisations(organisations);
	assertEquals(organisations, attributes.getOrganisations(), "The organisations list should be correctly set and retrieved.");
	}

	@Test
	public void testOpencasesonlyNotNullAndNotEmpty() {
		// Test @NotNull and @NotEmpty validation on opencasesonly
		attributes.setOpencasesonly(null);
		var violations = validator.validate(attributes);
		assertFalse(violations.isEmpty(), "The opencasesonly field should not be null.");

		attributes.setOpencasesonly("");
		violations = validator.validate(attributes);
		assertFalse(violations.isEmpty(), "The opencasesonly field should not be empty.");
	}

	@Test
	public void testCaseFilterDataSettersAndGetters() {
	// Test setter and getter for CaseFilterData inside Filters
	filters.setBusinessname(Arrays.asList(caseFilterData));
	assertEquals(caseFilterData, filters.getBusinessname().get(0), "CaseFilterData for businessname	should be correctly set and retrieved.");
	}

	@Test
	public void testUsersSettersAndGetters() {

	// Test getters and setters for Users class
	users.setOid("123");
	assertEquals("123", users.getOid(), "The OID should be correctly set and retrieved.");

	users.setFullName("John Smith");
	assertEquals("John Smith", users.getFullName(), "The full name should be correctly set and	retrieved.");

	users.setEmail("john.smith@example.com");
	assertEquals("john.smith@example.com", users.getEmail(), "The email should be correctly set	and retrieved.");

	users.setRoles(Arrays.asList("Manager", "Editor"));
	assertEquals(Arrays.asList("Manager", "Editor"), users.getRoles(), "The roles list should be correctly set and retrieved.");
	}

	@Test
	public void testFiltersSettersAndGetters() {
	// Test setting and getting filters fields
	filters.setSearchBy("caseId");
	assertEquals("caseId", filters.getSearchBy(), "The searchBy field should be correctly set and	retrieved.");

	filters.setStartdate("2021-01-01");
	assertEquals("2021-01-01", filters.getStartdate(), "The startdate should be correctly set and	retrieved.");

	filters.setEnddate("2021-12-31");

	assertEquals("2021-12-31", filters.getEnddate(), "The enddate should be correctly set and	retrieved.");

	filters.setPage(1);
	assertEquals(1, filters.getPage(), "The page should be correctly set and retrieved.");

	filters.setPagesize(20);
	assertEquals(20, filters.getPagesize(), "The pagesize should be correctly set and retrieved.");
	}

	@Test
	public void testCaseFilterDataIdAndValue() {
	// Test CaseFilterData getters and setters
	assertEquals("filter1", caseFilterData.getId(), "The filter ID should be correctly set and	retrieved.");
	assertEquals("Test Filter", caseFilterData.getValue(), "The filter value should be correctly set and	retrieved.");
	}
}
