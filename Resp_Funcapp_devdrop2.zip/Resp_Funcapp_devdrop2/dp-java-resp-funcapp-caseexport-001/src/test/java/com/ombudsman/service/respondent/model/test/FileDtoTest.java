package com.ombudsman.service.respondent.model.test;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import com.ombudsman.service.respondent.model.FileDto;
@ExtendWith(MockitoExtension.class)
class FileDtoTest {
	private FileDto fileDto;

	@BeforeEach
	void setUp() {
		fileDto = new FileDto();
	}

	@Test
	void testGetSetUrl() {
		String url = "http://example.com";
		fileDto.setUrl(url);
		assertEquals(url, fileDto.getUrl());
	}

	@Test
	void testGetSetDocumentId() {
		String documentId = "doc123";
		fileDto.setDocumentId(documentId);
		assertEquals(documentId, fileDto.getDocumentId());
	}

	@Test
	void testGetSetFileName() {
		String fileName = "file.txt";
		fileDto.setFileName(fileName);
		assertEquals(fileName, fileDto.getFileName());
	}

	@Test
	void testGetSetFileType() {
		String fileType = "text/plain";
		fileDto.setFileType(fileType);
		assertEquals(fileType, fileDto.getFileType());
	}
}
