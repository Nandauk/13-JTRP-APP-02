package com.ombudsman.service.respondent.model.test;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import com.ombudsman.service.respondent.model.GetResponseMessage;
@ExtendWith(MockitoExtension.class)
class GetResponseMessageTest {

	private GetResponseMessage responseMessage;

	@BeforeEach
	void setUp() {
		responseMessage = new GetResponseMessage();
	}

	@Test
	void testGetSetMessage() {
		String message = "Hello, this is a test message!";
		responseMessage.setMessage(message);
		assertEquals(message, responseMessage.getMessage());
	}
}
