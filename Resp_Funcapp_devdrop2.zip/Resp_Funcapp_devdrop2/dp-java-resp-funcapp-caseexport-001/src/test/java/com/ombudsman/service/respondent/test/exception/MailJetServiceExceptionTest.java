package com.ombudsman.service.respondent.test.exception;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.Test;

import com.ombudsman.service.respondent.exception.MailJetServiceException;

class MailJetServiceExceptionTest {

	@Test
	void testConstructor_ValidInput() {
// Prepare input values
		String message = "Test message";
		String exceptionMessage = "Test exception message";
		StackTraceElement[] stackTraceElements = new StackTraceElement[] {
				new StackTraceElement("ClassName", "methodName", "fileName", 10) };

// Create the MailJetServiceException instance
		MailJetServiceException exception = new MailJetServiceException(message, exceptionMessage, stackTraceElements);

// Validate that the exception was correctly initialized
		assertNotNull(exception, "The exception should not be null");

		assertEquals(message, exception.getMessage(), "The exception message should match the input message");
		assertEquals("RESPONDENT_AZURE_1000", exception.getCode(),
				"The error code shouldbe &#39;RESPONDENT_AZURE_1000&#39;");
		assertEquals(exceptionMessage, exception.getExceptionMessage(),
				"The exception message should match the input exceptionMessage");
	}

	@Test
	void testMailJetServiceExceptionParentConstructor() {
// Test to ensure the parent constructor is called with the correct arguments
		String message = "Test message";
		String exceptionMessage = "Test exception message";
		StackTraceElement[] stackTraceElements = new StackTraceElement[] {
				new StackTraceElement("ClassName", "methodName", "fileName", 10) };

// Create the MailJetServiceException instance

		MailJetServiceException exception = new MailJetServiceException(message, exceptionMessage, stackTraceElements);

// Check that the exception is not null and has the correct message
		assertNotNull(exception);
		assertEquals(message, exception.getMessage(),
				"The message passed to the parent constructor should be set correctly");
	}
}
