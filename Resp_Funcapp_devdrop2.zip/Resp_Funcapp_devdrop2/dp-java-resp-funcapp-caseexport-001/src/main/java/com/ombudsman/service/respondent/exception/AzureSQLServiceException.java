package com.ombudsman.service.respondent.exception;

public class AzureSQLServiceException extends RespondentsServiceExceptions {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public AzureSQLServiceException(String message,String exceptionMessage,StackTraceElement[] stackTraceElements) {
		super(message, "RESPONDENT_PHOENIX_1001",exceptionMessage,stackTraceElements);
	}
	
	

}
