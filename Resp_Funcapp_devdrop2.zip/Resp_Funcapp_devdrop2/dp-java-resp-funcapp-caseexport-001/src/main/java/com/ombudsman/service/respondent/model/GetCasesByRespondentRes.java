package com.ombudsman.service.respondent.model;

import java.util.List;

import com.ombudsman.service.respondent.model.Case;

public class GetCasesByRespondentRes {
	private List<CaseListDto> cases;
	private String message;
	private String counttotalcases;
	private String countprioritycases;
	private String countawaitingresponse;
	private String countnotassessed;
	private String countoverduecases;
	private String lastUpdatedOn;


	public String getMessage() {
		return message;
	}

	public List<CaseListDto> getCases() {
		return cases;
	}

	public void setCases(final List<CaseListDto> cases) {
		this.cases = cases;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getCounttotalcases() {
		return counttotalcases;
	}

	public void setCounttotalcases(String counttotalcases) {
		this.counttotalcases = counttotalcases;
	}

	public String getCountprioritycases() {
		return countprioritycases;
	}

	public void setCountprioritycases(String countprioritycases) {
		this.countprioritycases = countprioritycases;
	}

	public String getCountawaitingresponse() {
		return countawaitingresponse;
	}

	public void setCountawaitingresponse(String countawaitingresponse) {
		this.countawaitingresponse = countawaitingresponse;
	}

	public String getCountnotassessed() {
		return countnotassessed;
	}

	public void setCountnotassessed(String countnotassessed) {
		this.countnotassessed = countnotassessed;
	}

	public String getCountoverduecases() {
		return countoverduecases;
	}

	public void setCountoverduecases(String countoverduecases) {
		this.countoverduecases = countoverduecases;
	}

	public String getLastUpdatedOn() {
		return lastUpdatedOn;
	}

	public void setLastUpdatedOn(String lastUpdatedOn) {
		this.lastUpdatedOn = lastUpdatedOn;
	}


}
