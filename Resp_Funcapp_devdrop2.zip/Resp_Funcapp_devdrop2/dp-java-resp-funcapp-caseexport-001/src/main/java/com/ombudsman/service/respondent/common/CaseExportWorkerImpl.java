package com.ombudsman.service.respondent.common;

import static com.ombudsman.service.respondent.common.Constants.ACCOUNT_ID;
import static com.ombudsman.service.respondent.common.Constants.CASE_AGE;
import static com.ombudsman.service.respondent.common.Constants.CASE_OWNER;
import static com.ombudsman.service.respondent.common.Constants.CASE_STAGE;
import static com.ombudsman.service.respondent.common.Constants.CASE_STATUS;
import static com.ombudsman.service.respondent.common.Constants.COMPLAINANT_ISSUE;
import static com.ombudsman.service.respondent.common.Constants.IS_OPEN_CASE;
import static com.ombudsman.service.respondent.common.Constants.LIVE_CASE_AGE;
import static com.ombudsman.service.respondent.common.Constants.PAGE_COUNT;
import static com.ombudsman.service.respondent.common.Constants.PAGE_SIZE;
import static com.ombudsman.service.respondent.common.Constants.PERIORITY_CASE;
import static com.ombudsman.service.respondent.common.Constants.PRODUCT_TYPE;
import static com.ombudsman.service.respondent.common.Constants.RESOLVING_OUTCOME;
import static com.ombudsman.service.respondent.common.Constants.TRADE_NAME;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONException;
import org.springframework.http.MediaType;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.WebClient;

import com.azure.storage.blob.BlobClient;
import com.azure.storage.blob.BlobContainerClient;
import com.azure.storage.blob.sas.BlobContainerSasPermission;
import com.azure.storage.blob.sas.BlobServiceSasSignatureValues;
import com.azure.storage.common.sas.SasProtocol;
import com.google.gson.Gson;
import com.ombudsman.service.respondent.exception.MailJetServiceException;
import com.ombudsman.service.respondent.exception.RespondentsServiceExceptions;
import com.ombudsman.service.respondent.model.CaseExport;
import com.ombudsman.service.respondent.model.CaseFilterData;
import com.ombudsman.service.respondent.model.CaseListDto;
import com.ombudsman.service.respondent.model.FileDto;
import com.ombudsman.service.respondent.model.Filters;
import com.ombudsman.service.respondent.model.From;
import com.ombudsman.service.respondent.model.GetCasesByRespondentRes;
import com.ombudsman.service.respondent.model.GetResponseMessage;
import com.ombudsman.service.respondent.model.MailjetResponseBody;
import com.ombudsman.service.respondent.model.Messages;
import com.ombudsman.service.respondent.model.Notification;
import com.ombudsman.service.respondent.model.SendMailReq;
import com.ombudsman.service.respondent.model.To;
import com.opencsv.CSVWriter;

public class CaseExportWorkerImpl {
	
	private static final String FAILED_TO_UPDATE_DOWNLOAD_URL = "Failed to update Download URL";
	private static final String SEARCHBY = "searchby";
	private static final String SUCCESS = "success";
	private static final String DOWNLOAD_NOTIFICATION = "DownloadNotification";
	private static final String READY_FOR_DELIVERY = "ReadyForDelivery";
	private static final int PAGE_COUNT_VALUE = 1;
	private static final int PAGE_SIZE_VALUE = 1000000;
	private static final boolean TRUE = true;
	private static final String SORTTYPE = "sorttype";
	private static final String SORTBY = "sortby";
	private static final String TODATE = "todate";
	private static final String INCIDENTID = "incidentid";
	private static final String FROMDATE = "fromdate";
	private static final String CASE_EXPORT_CSV = "CaseExport.csv";
	private static final String AWAITINGACTIONFILTER = "awaitingactionfilter";
	private static final String URI = "/mailjet/send";
	private static final String HASH = "#";
	private static final String COMMA = ",";
	private static final String EMAILID = "emailid";
	public static final String CASE_PROGRESS="caseprogress";
	public static final String BUSINESS_FILE_OVERDUE="bfileoverdue";
	public static final String OUTCOME_LAST_SEVENDAYS="outcome7days";
	Logger logger = LogManager.getRootLogger();
	
	public InputStream exportDatainInputStream(GetCasesByRespondentRes getCasesByRespondentRes) throws IOException {
		
		logger.info("exportDatainInputStream Method Started ");
		List<CaseListDto> model = getCasesByRespondentRes.getCases();

		StringWriter strwriter = new StringWriter();
		CSVWriter writer = new CSVWriter(strwriter); // to chk for libraries, try to optimize code

		logger.info("setting headervalues start : {}", writer);

		
		//BUG FIX-15832 - Removed "Case status"
		writer.writeNext(new String[] { "Case reference", "Migrated reference", "Business name", "Trading name",
				"Business reference", "Complaint issue", "Product type", "Case stage","Case Progress" , "Enquiry date",
				"Professional representative name", "Date moved to investigation", "Business file required by date",
				"Business File Received Date", "Latest Outcome date", "Latest Outcome", 
				"Action Required", "6mnth+ Case Flag", "Our case owner once allocated", "Your Case Owner","Respondent Contact Email Address","Case age", "Event date",
				"Priority Case flag", "Final response date", "Closure date", "Closure outcome","No final response progression flag",
				 }); // constants


		logger.info("setting headervalues end ");

		logger.info("setting grid values start ");
		

		for (CaseListDto export : model) {
		    logger.info("No final response progression flag--export.getDeadlockcases()::{}", export.getDeadlockcases());            

		    writer.writeNext(new String[] {
		        export.getTicketnumber(), // Case reference
		        export.getFos_crn(), // Migrated reference
		        export.getBusinessname(), // Business name
		        export.getFos_tradingnamename(), // Trading name
		        export.getFos_reference(), // Business reference
		        export.getFos_complaintissuename(), // Complaint issue
		        export.getFos_productorproductfamilyname(), // Product type
		        export.getFos_casestagename(), // Case stage
		        export.getFos_caseprogress_name(), // Case Progress
		        export.getFos_dateofreferral(), // Enquiry date
		        export.getFos_representatives(), // Professional representative name
		        export.getFos_dateofconversion(), // Date moved to investigation
		        export.getBr_required(), // Business file required by date
		        export.getFos_datebusinessfilereceived(), // Business File Received Date
		        export.getFos_outcomedispatcheddate(), // Latest Outcome date
		        export.getFos_typename(), // Latest Outcome
		        export.getAwaitingaction(), // Action Required
		        export.getAgecaseflag(), // 6mnth+ Case Flag
		        export.getFos_caseworker(), // Our case owner once allocated
		        export.getFos_individualidname(), // Your Case Owner
		        export.getEmailid(), // Respondent Contact Email Address
		        export.getCaseagebanding(), // Case age
		        export.getFos_dateofevent(), // Event date
		        export.getFos_prioritycodename(), // Priority Case flag
		        export.getFos_dateoffinalresponse(), // Final response date
		        export.getFos_offeroutcome(), // Closure date
		        export.getFos_changeinoutcomename(), // Closure outcome
		        export.getDeadlockcases(), // No final response progression flag
		    });
		}

		String csvContent = strwriter.toString();
		InputStream inputStream = new ByteArrayInputStream(csvContent.getBytes());
		logger.info("setting grid values into streamToUploadToBlob  {}", inputStream);
		logger.info("csvContent..................  {}", csvContent);

		writer.close();
		logger.info("exportDatainInputStream Method Ended ");
		return inputStream;

	}
	
	public void blobStorageOperation(CaseExport exportReqModel, InputStream streamToUploadToBlob, BlobContainerClient containerClient,
			GetResponseMessage responseMessage, JdbcTemplate jdbcTemplate) {

		logger.info("blobStorageOperation method started "); // debug for all logs

		FileDto fileDto = new FileDto();
		Notification notification = new Notification();
		String blobName = CASE_EXPORT_CSV;
		logger.info("blobName  {}", blobName);

		try {
			BlobClient blobClient = containerClient.getBlobClient(exportReqModel.getAttributes().getUsers().getOid()
					+ "_CaseExport_" + exportReqModel.getMessageId() + "/" + blobName);
			logger.info("blobClient  {}", blobClient);

			OffsetDateTime expiryTime = OffsetDateTime.now().plusHours(24); // configurable in file storage
			logger.info("expiry in 24 hours {}", expiryTime);

			boolean frontDoorEnabled = Boolean.parseBoolean(System.getenv("FrontdoorEnabled"));
			logger.info("frontDoorEnabled {}", frontDoorEnabled);

			logger.info("before uploading the file using blobclient {}", blobClient);
			blobClient.upload(streamToUploadToBlob);
			logger.info("blob storage blobclient after uploading a file {}", blobClient);

			String createSasUri = createSasUri(expiryTime, blobClient, containerClient);
			logger.info("createSasUri :  {}", createSasUri );
			fileDto.setUrl(applyFrontDoorMasking(createSasUri, frontDoorEnabled));
			fileDto.setDocumentId(blobClient.getBlobName());
			logger.info("fileDto url :  {}", fileDto.getUrl() );
			logger.info("documentId : {}",  fileDto.getDocumentId());

			logger.info("Notification Update Started in Azure Function ");
			notification.setFileDownloadUrl(fileDto.getUrl());
			notification.setModifiedOn(Instant.now().toString());
			notification.setRequestId(exportReqModel.getMessageId());
			notification.setNotificationStatusId("2");
			notification.setNotificationStatusDescription(READY_FOR_DELIVERY);
			notificationJdbcCall(notification, jdbcTemplate); // custom exception
			logger.info("Notification Update Ended in Azure Function ");
			
			sendInviteToUserWebclient(exportReqModel, responseMessage);

		} catch (Exception e) {

			logger.error(" Sending data to notification has failed {}", e.getMessage());
			notification.setFileDownloadUrl(FAILED_TO_UPDATE_DOWNLOAD_URL);
			notification.setMessage(FAILED_TO_UPDATE_DOWNLOAD_URL);
			notification.setModifiedOn(Instant.now().toString());
			notification.setRequestId(exportReqModel.getMessageId());
			notification.setNotificationStatusId("5");
			notification.setNotificationStatusDescription("Failed");
			notificationJdbcCall(notification, jdbcTemplate);

		}

		logger.info("blobStorageOperation Method ended ");
	}

	public void sendInviteToUserWebclient(CaseExport exportReqModel, GetResponseMessage responseMessage) {

		logger.info("SendMailReq code started ");
		try {
			SendMailReq sendMailReq = new SendMailReq();
			List<To> to = new ArrayList<>();
			List<Messages> sendmessage = new ArrayList<>();
			To to1 = new To();
			to1.setEmail(exportReqModel.getAttributes().getUsers().getEmail());
			to1.setName(exportReqModel.getAttributes().getUsers().getFullName());
			to.add(to1);

			Messages message = new Messages();
			message.setTemplateID(exportReqModel.getTemplateId());
			message.setName(READY_FOR_DELIVERY);
			message.setTemplateLanguage(TRUE);
			message.setTo(to);

			From from = new From();
			from.setEmail(System.getenv("From_Email"));
			from.setName(DOWNLOAD_NOTIFICATION);
			message.setFrom(from);
			sendmessage.add(message);
			sendMailReq.setMessages(sendmessage);

			String response = send(sendMailReq);
			logger.info("sendMailReq response {}", response);

			if (response.equals(SUCCESS)) {
				responseMessage.setMessage("MailJet API call success :" + response);
			} else {
				responseMessage.setMessage("MailJet API call failed :" + response);
			}
			logger.info("SendMailReq code  ended ");
		} catch (Exception e) {
			logger.error("Error in Method SendMailReq {}", e.getMessage());
		}
	}

	public void notificationJdbcCall(Notification notification, JdbcTemplate jdbcTemplate) {
		logger.info("notificationJdbcCall method started ");

		try {

			Object[] paramNotification = new Object[] { notification.getFileDownloadUrl(), notification.getModifiedOn(),
					notification.getNotificationStatusId(), notification.getNotificationStatusDescription(),
					notification.getRequestId() };
			logger.info("paramNotification {}", paramNotification);

			String sql = "update dp_user_notification set file_download_url= ?,modified_on= ?,notification_status_id= ?,notification_status_description= ? where request_id= ?";
			logger.info("sql : {}", sql);

			jdbcTemplate.update(sql, paramNotification);
			logger.info("Notification data updated in Database : {}", jdbcTemplate);

		} catch (Exception e) {
			logger.error("Error in notification {}", e.getMessage());
		}
		logger.info("notificationJdbcCall method Ended ");
	}

	public String send(SendMailReq req) throws JSONException {
		logger.info("Mailjet Send request method started");
		Gson gson = new Gson();
		String json = gson.toJson(req);
		MailjetResponseBody responseBody = new MailjetResponseBody();
		String status = null;
		logger.info("Request data for Send API {}" , json);
		String url= System.getenv("APIM_URL") + URI;
		logger.info("Send API Url : {}", url);

		try {
			responseBody = WebClient.create().post().uri(url).body(BodyInserters.fromValue(json))
					.accept(MediaType.APPLICATION_JSON).retrieve().bodyToMono(MailjetResponseBody.class).block();
			if (responseBody != null) {
				status = responseBody.getMessages().get(0).getStatus();
				logger.info("Response : {}" , status);
			}
		} catch (Exception ex) {
			logger.error("Webclient call failed {}" , ex.getMessage());
			throw new MailJetServiceException("Mailjet Exception occured {}", ex.getMessage(), ex.getStackTrace());
		}

		logger.info("Response : {}" , responseBody);
		if(null != responseBody) {
		status = responseBody.getMessages().get(0).getStatus();
		}

		return status;

	}

	public String applyFrontDoorMasking(String createSasUri, boolean frontDoorEnabled) {
		logger.info("applyFrontDoorMasking starting ");
		if (frontDoorEnabled) {
			logger.info("applyFrontDoorMasking start ");
			return createSasUri.replace(System.getenv("APP_STORAGE_URL"), System.getenv("DOWNLOAD_APIM_URL"));

		} else {
			logger.error("applyFrontDoorMasking end {}", createSasUri);
			return createSasUri;
		}
		
	}
	
	public Map<String, Object> getRequestData(CaseExport exportReqModel, Filters filters, String openCaseOnlyFlag) {
		logger.info("getRequestData Method Started ");
		final Map<String, Object> data = new HashMap<>();
		
		filters.setPagesize(PAGE_SIZE_VALUE);
		filters.setPage(PAGE_COUNT_VALUE);
		data.put(SEARCHBY, filters.getSearchBy());
		data.put(PAGE_SIZE, filters.getPagesize());
		data.put(PAGE_COUNT, filters.getPage());
		data.put(FROMDATE, getDateForCaseList(filters.getStartdate()));
		data.put(TODATE, getDateForCaseList(filters.getEnddate()));
		data.put(SORTBY, filters.getSortby());
		data.put(SORTTYPE, filters.getSorttype());
		data.put(IS_OPEN_CASE, openCaseOnlyFlag);
		data.put(COMPLAINANT_ISSUE, getRequestValues(filters.getComplaintissue(),exportReqModel));
		//data.put(CASE_STATUS, getRequestValues(filters.getCasestatus(),exportReqModel));
		data.put(PRODUCT_TYPE, getRequestValues(filters.getProducttype(),exportReqModel));
		data.put(CASE_STAGE, getRequestValues(filters.getCasestage(),exportReqModel));
		data.put(TRADE_NAME, getRequestValues(filters.getTradingname(),exportReqModel));
		data.put(CASE_OWNER, getRequestValues(filters.getCaseowner(),exportReqModel));
		data.put(CASE_AGE, getRequestValues(filters.getCaseage(),exportReqModel));
		data.put(PERIORITY_CASE, getRequestValues(filters.getPrioritycases(),exportReqModel));
		data.put(LIVE_CASE_AGE, getRequestValues(filters.getAgecaseflag(),exportReqModel));
		data.put(ACCOUNT_ID, getRequestValues(filters.getBusinessname(),exportReqModel));
		data.put(RESOLVING_OUTCOME, getRequestValues(filters.getAwaitingactionbusiness(),exportReqModel));
		data.put(AWAITINGACTIONFILTER, getRequestAwitingAction(filters.getAwaitingactionfilter(),exportReqModel));
		data.put(EMAILID, getRequestValues(filters.getEmailid(),exportReqModel));
		data.put(CASE_PROGRESS, getRequestValues(filters.getCaseprogress(),exportReqModel));
		data.put(BUSINESS_FILE_OVERDUE, getRequestValues(filters.getBfileoverdue(),exportReqModel));
		data.put(OUTCOME_LAST_SEVENDAYS, getRequestValues(filters.getOutcome7days(),exportReqModel));
		data.put(INCIDENTID,getRequestValuesforincident(exportReqModel.getNumberOfCases()));
		logger.info("getRequestData Method Ended ");
		return data;

	}
	
//	private String getYesorNo(final List<CaseFilterData> caseData) {
//		if (caseData != null) {			
//			return caseData.stream().map(CaseFilterData::getValue).anyMatch("YES"::equals) ? "YES" : "NO";
//		} else {
//			return "NO";
//		}
//	}

	public String getRequestValues(final List<CaseFilterData> caseData,CaseExport exportReqModel) {
		if (caseData != null && CollectionUtils.isEmpty(exportReqModel.getNumberOfCases())) {			
			return caseData.stream().filter(n -> n.getId() != null).map(CaseFilterData::getId)
					.collect(Collectors.joining(COMMA)).lines().findAny().orElse(HASH);
		} else {
			return HASH;
		}

	}
	public String getRequestValuesforincident(final List<String> caseData) {
		if (caseData.size() <= 100) {
			if (CollectionUtils.isNotEmpty(caseData)) {
				logger.info("selected case not null ::{}", caseData.size());
				return String.join(COMMA, caseData);
			} else {
				logger.info("selected case null ::{}", caseData.size());
				return HASH;
			}
		} else {
			logger.error("selected case size more then 100 ::{}", caseData.size());
			throw new RespondentsServiceExceptions("selected cases size more then 100", "", "", null);
		}

	}
	
	public String getRequestAwitingAction(final List<CaseFilterData> caseData,CaseExport exportReqModel) {
		if (caseData != null && CollectionUtils.isEmpty(exportReqModel.getNumberOfCases())) {
			logger.info("caseData null ::{}", caseData.size());
			return caseData.stream().filter(n -> n.getId() != null).map(CaseFilterData::getValue)
					.collect(Collectors.joining(COMMA)).lines().findAny().orElse(HASH);
		} else {
			return HASH;
		}

	}

	public Date getDateForCaseList(final String stEndDate) {
		logger.info("getDateForCaseList Method Started ");
		String pattern = "mm/dd/yyyy";
		SimpleDateFormat sdf = new SimpleDateFormat(pattern);
		try {
			if (StringUtils.isNotEmpty(stEndDate)) {
				return sdf.parse(stEndDate);
			} else {
				return sdf.parse("01/01/1900");
			}
		} catch (ParseException e) {
			logger.error("Unable to parse the date: {}", e.getMessage());
		}
		logger.info("getDateForCaseList Method Ended ");
		return null;
	}


	public String createSasUri(OffsetDateTime expiryTime, BlobClient blobClient, BlobContainerClient bc) {
		logger.info("createSasUri Method Started ");
		BlobContainerSasPermission blobContainerSasPermission = new BlobContainerSasPermission().setReadPermission(true);
		logger.info("blob storage blobContainerSasPermission :  {}", blobContainerSasPermission);

		BlobServiceSasSignatureValues builder = new BlobServiceSasSignatureValues(expiryTime,
				blobContainerSasPermission).setProtocol(SasProtocol.HTTPS_ONLY);

		logger.info("createSasUri end {}", builder);
		return blobClient.getBlobUrl() + "?" + bc.generateSas(builder);

	}
}
