package com.ombudsman.service.respondent;

import java.beans.Transient;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

import com.azure.storage.blob.BlobContainerClient;
import com.azure.storage.blob.BlobServiceClient;
import com.azure.storage.blob.BlobServiceClientBuilder;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.microsoft.azure.functions.ExecutionContext;
import com.microsoft.azure.functions.annotation.FunctionName;
import com.microsoft.azure.functions.annotation.ServiceBusQueueTrigger;
import com.ombudsman.service.respondent.common.CaseExportWorkerImpl;
import com.ombudsman.service.respondent.exception.CaseListNotFoundException;
import com.ombudsman.service.respondent.exception.RespondentsServiceExceptions;
import com.ombudsman.service.respondent.exception.SQLDataAccessException;
import com.ombudsman.service.respondent.model.CaseExport;
import com.ombudsman.service.respondent.model.CaseListDto;
import com.ombudsman.service.respondent.model.GetCasesByRespondentRes;
import com.ombudsman.service.respondent.model.GetResponseMessage;

public class AzureWorkerServiceBus {

	private static final String SUCCESS = "Success";
	private static final String SEARCH_BY_REQUEST_LENGTH_IS_NOT_VALID = "Search By Request Length is not Valid";
	private static final String RESULT_SET_2 = "#result-set-2";
	private static final String USER_IS_NOT_TAGGED_WITH_ANY_ORGANISATION = "User is not tagged with any organisation.";
	private static final String CASE_LIST_NOT_FOUND = "Case List not found";
	private static final String ACCOUNT_IDS = "accountids";

	Logger logger = LogManager.getRootLogger();
	ObjectMapper objectMapper = new ObjectMapper();

	@FunctionName("caseExportWorker")
	@Transient(true)
	public void caseExportWorkerFunction(
			@ServiceBusQueueTrigger(name = "message", queueName = "%QueueName%", connection = "AzureWebJobsServiceBus") String message,
			final ExecutionContext context) throws IOException {

		logger.info("caseExportWorkerFunction Azure Fuction Started. ");
		logger.info("Request Received from service bus : {}", message);

		try {
			CaseExport exportReqModel = new CaseExport();
			
			// String to json conversion of case Export Request
			objectMapper.enable(JsonParser.Feature.INCLUDE_SOURCE_IN_LOCATION);
			exportReqModel = objectMapper.readValue(message, CaseExport.class);
			logger.info("Request Extracted from Object Mapper : {}", exportReqModel.getMessageId());

			// DB connection
			JdbcTemplate jdbcTemplate = jdbcConnection(); // optimize methods

			// BlobStorage connection including container name
			BlobServiceClient blobServiceClient = BlobServiceClientMethod(); // optimize
			BlobContainerClient containerClient = BlobClientContainerMethod(blobServiceClient);

			// Initializing data
			GetResponseMessage responseMessage = new GetResponseMessage();
			CaseExportWorkerImpl exportdata = new CaseExportWorkerImpl();
			GetCasesByRespondentRes getCasesByRespondentRes = new GetCasesByRespondentRes();
			List<Object> caseListDtl = null;
			String stringofgroups = "";
			String openCaseOnlyFlag = exportReqModel.getAttributes().getOpencasesonly();
			List<String> groups = exportReqModel.getAttributes().getOrganisations();
			stringofgroups = String.join(",", groups);
			logger.info("Groups in String : {}", stringofgroups);

			boolean validSeachRequestAttribute = StringUtils.isEmpty(exportReqModel.getAttributes().getFilters().getSearchBy());
			if(!validSeachRequestAttribute) {
				validSeachRequestAttribute= exportReqModel.getAttributes().getFilters().getSearchBy().length() >= 3;
			}

			if (validSeachRequestAttribute) {

				// Caselist Operation started
				if (CollectionUtils.isNotEmpty(groups)) {

					final Map<String, Object> getRequestData = exportdata
							.getRequestData(exportReqModel, exportReqModel.getAttributes().getFilters(),openCaseOnlyFlag);
						logger.info("CaseList getRequestData Received ::{} ",getRequestData);
					final Map<String, Object> caseList = Optional
							.ofNullable(getCasesByRespondent(getRequestData, stringofgroups, jdbcTemplate))
							.orElseThrow(() -> new CaseListNotFoundException(CASE_LIST_NOT_FOUND));
					logger.info("CaseList response Received ::{} ",caseList);

					if (null != caseList.get(RESULT_SET_2)) {
						caseListDtl = (List<Object>) caseList.get(RESULT_SET_2);
					} else {
						getCasesByRespondentRes.setMessage(CASE_LIST_NOT_FOUND);
						logger.error("Error in GetCasesByRespondent caselist grid response ");
						throw new CaseListNotFoundException(CASE_LIST_NOT_FOUND);
					}

					logger.info("Data Received from Stored Procedure and storing in Model Class Started ");
					final ObjectMapper mapper = new ObjectMapper();
					final List<CaseListDto> caseDtl = caseListDtl.stream().map(i -> mapper.convertValue(i, CaseListDto.class))
							.collect(Collectors.toList());
					getCasesByRespondentRes.setCases(caseDtl); // same model class for msg

					logger.info("Caselist Data Set in Model class Ended ::{}",getCasesByRespondentRes);

				} else {
					logger.error(USER_IS_NOT_TAGGED_WITH_ANY_ORGANISATION);
					getCasesByRespondentRes.setMessage(USER_IS_NOT_TAGGED_WITH_ANY_ORGANISATION);
					throw new RespondentsServiceExceptions(USER_IS_NOT_TAGGED_WITH_ANY_ORGANISATION, "", "", null);
				}
			} else {
				logger.error(SEARCH_BY_REQUEST_LENGTH_IS_NOT_VALID);
				getCasesByRespondentRes.setMessage(SEARCH_BY_REQUEST_LENGTH_IS_NOT_VALID);

			}

//		CSV Export code Started
		InputStream streamToUploadToBlob = exportdata.exportDatainInputStream(getCasesByRespondentRes);
		logger.debug("streamToUploadToBlob {}", streamToUploadToBlob);
		
		try {
//			Store file in Blob Storage Code Started
			exportdata.blobStorageOperation(exportReqModel, streamToUploadToBlob, containerClient,
					responseMessage, jdbcTemplate);
			responseMessage.setMessage(SUCCESS);
		} catch (Exception e) {
			responseMessage.setMessage("Failed blobStorageOperation method ");
			logger.error("Failed blobStorageOperation method  {}", e.getMessage());
		}
			
		} catch (Exception e) {
			logger.error("Error in Export Azure function {}", e.getMessage());
		}
		logger.info("caseExportWorkerFunction Azure Fuction Ended. ");
	}

	public BlobContainerClient BlobClientContainerMethod(BlobServiceClient blobServiceClient) {
		return blobServiceClient.getBlobContainerClient(System.getenv("CONTAINER_NAME"));
	}

	public BlobServiceClient BlobServiceClientMethod() {
		BlobServiceClient blobServiceClient = new BlobServiceClientBuilder()
				.connectionString(System.getenv("BLOB_STORAGE_CONNECTION_STRING")).buildClient();
		logger.debug("Blob storage connection string : {}", blobServiceClient);
		return blobServiceClient;
	}

	public JdbcTemplate jdbcConnection() {
		JdbcTemplate jdbcTemplateConn = new JdbcTemplate();
		DriverManagerDataSource dataSource = new DriverManagerDataSource();
		dataSource.setDriverClassName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
		dataSource.setUrl(System.getenv("SQL_DATASOURCE_URL"));
		dataSource.setUsername(System.getenv("SQL_DATASOURCE_USERNAME"));
		dataSource.setPassword(System.getenv("SQL_DATASOURCE_PASSWORD"));
		jdbcTemplateConn = new JdbcTemplate(dataSource);
		return jdbcTemplateConn;
	}

	public Map<String, Object> getCasesByRespondent(final Map<String, Object> reqParam, String stringofgroups,
			JdbcTemplate jdbcTemplate) throws SQLDataAccessException {
		logger.info("getCasesByRespondent Method started {}", stringofgroups);
		this.setAccountIds(reqParam, stringofgroups);
		logger.info("setAccountId: {}", stringofgroups);

		Map<String, Object> caseList = null;

		logger.info("reqParam: {}", reqParam);
		if (StringUtils.isNotEmpty(stringofgroups)) {
			caseList = getCaseListDetails(reqParam, jdbcTemplate);
			logger.info("getCaseListDetails Method ended ");
		}
		logger.info("getCasesByRespondent Method ended ");
		return caseList;
	}

	public void setAccountIds(Map<String, Object> paramReq, final String accountIds) {
		paramReq.put(ACCOUNT_IDS, accountIds);
	}

	public Map<String, Object> getCaseListDetails(Map<String, Object> reqParam, JdbcTemplate jdbcTemplate)
			throws SQLDataAccessException {
		logger.info("getCaseListDetails Method Started ");

		final SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate)
				.withProcedureName("prc_GetCaselistDetails_Incident");

		SqlParameterSource in = new MapSqlParameterSource(reqParam);

		logger.info("getCaseListDetails Method parameters passing to Store procedure");
		return simpleJdbcCall.execute(in);

	}

}
