package com.ombudsman.service.respondent.common;

public class Constants {
	public static final String PAGE_SIZE="pagesize";
	public static final String PAGE_COUNT="pagecount";
	public static final String IS_OPEN_CASE="isOpenCases";
	public static final String COMPLAINANT_ISSUE="complainantissue";
	public static final String CASE_STATUS="casestatus";
	public static final String PRODUCT_TYPE="producttype";
	public static final String CASE_STAGE="casestage";
	public static final String ACCOUNT_ID="accountid";
	public static final String CASE_OWNER="caseowner";
	public static final String CASE_AGE="caseage";
	public static final String RESOLVING_OUTCOME="resolvingoutcome";	
	public static final String LIVE_CASE_AGE="livecaseage";
	public static final String TRADE_NAME="tradingname";
	public static final String PERIORITY_CASE="prioritycase";
	public static final String ACCOUNT_IDS="accountids";
	private Constants() {
	      //not called
	   }
	
	
}
