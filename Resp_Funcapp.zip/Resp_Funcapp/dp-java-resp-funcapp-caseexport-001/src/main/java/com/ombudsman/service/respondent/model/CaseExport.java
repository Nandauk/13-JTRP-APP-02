package com.ombudsman.service.respondent.model;

import java.io.Serializable;
import java.util.List;

public class CaseExport implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String version;
	private String messageId;
	private String entityName;
	private Integer templateId;
	private Attributes attributes;
    private List<String> numberOfCases;

	public List<String> getNumberOfCases() {
		return numberOfCases;
	}

	public void setNumberOfCases(List<String> numberOfCases) {
		this.numberOfCases = numberOfCases;
	}

	public Integer getTemplateId() {
		return templateId;
	}

	public void setTemplateId(Integer templateId) {
		this.templateId = templateId;
	}

	public Attributes getAttributes() {
		return attributes;
	}

	public void setAttributes(Attributes attributes) {
		this.attributes = attributes;
	}

	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	public String getMessageId() {
		return messageId;
	}

	public void setMessageId(String messageId) {
		this.messageId = messageId;
	}

	public String getEntityName() {
		return entityName;
	}

	public void setEntityName(String entityName) {
		this.entityName = entityName;
	}

	
}
