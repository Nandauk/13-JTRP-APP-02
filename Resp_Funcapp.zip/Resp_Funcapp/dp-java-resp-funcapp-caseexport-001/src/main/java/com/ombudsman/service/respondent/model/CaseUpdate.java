package com.ombudsman.service.respondent.model;

import java.util.List;

public class CaseUpdate {

	private String version;
	private String messageId;
	private String entityName;
	private List<RequestModel> details;

	public List<RequestModel> getDetails() {
		return details;
	}

	public void setDetails(List<RequestModel> details) {
		this.details = details;
	}

	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	public String getMessageId() {
		return messageId;
	}

	public void setMessageId(String messageId) {
		this.messageId = messageId;
	}

	public String getEntityName() {
		return entityName;
	}

	public void setEntityName(String entityName) {
		this.entityName = entityName;
	}

}
