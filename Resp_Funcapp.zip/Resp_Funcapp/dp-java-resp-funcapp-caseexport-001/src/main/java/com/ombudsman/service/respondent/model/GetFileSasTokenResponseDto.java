package com.ombudsman.service.respondent.model;

import org.springframework.stereotype.Component;

@Component
public class GetFileSasTokenResponseDto {
	 String documentId;
     String url ;
	public String getDocumentId() {
		return documentId;
	}
	public void setDocumentId(String documentId) {
		this.documentId = documentId;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	
    
    
}
