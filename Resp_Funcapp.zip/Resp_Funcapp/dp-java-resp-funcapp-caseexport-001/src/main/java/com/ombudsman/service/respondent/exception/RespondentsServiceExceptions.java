package com.ombudsman.service.respondent.exception;

public class RespondentsServiceExceptions extends RuntimeException {
	/**
	* 
	*/
	private static final long serialVersionUID = 1L;
	private final String code;
	private final String message;
	private final String exceptionMessage;
	private final StackTraceElement[] stackTraceMessage;

	public RespondentsServiceExceptions(String message, String code, String exceptionMessage,
			StackTraceElement[] stackTraceElements) {
		super(message);

		this.code = code;
		this.message = message;
		this.exceptionMessage = exceptionMessage;
		this.stackTraceMessage = stackTraceElements;
	}

	public StackTraceElement[] getStackTraceMessage() {
		return stackTraceMessage;
	}

	public String getCode() {
		return code;
	}

	@Override
	public String getMessage() {
		return message;
	}

	public String getExceptionMessage() {
		return exceptionMessage;
	}

}
