package com.ombudsman.service.respondent.model.test;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.time.OffsetDateTime;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import com.ombudsman.service.respondent.model.RequestModel;
@ExtendWith(MockitoExtension.class)
class RequestModelTest {

	private RequestModel requestModel;

	@BeforeEach
	void setUp() {
		requestModel = new RequestModel();
	}

	@Test
	void testGetSetRequestId() {
		Integer requestId = 1;
		requestModel.setRequestId(requestId);
		assertEquals(requestId, requestModel.getRequestId());
	}

	@Test
	void testGetSetUserOid() {
		String userOid = "user123";
		requestModel.setUserOid(userOid);
		assertEquals(userOid, requestModel.getUserOid());
	}

	@Test
	void testGetSetRequestingActivityName() {
		String requestingActivityName = "ActivityName";
		requestModel.setRequestingActivityName(requestingActivityName);
		assertEquals(requestingActivityName, requestModel.getRequestingActivityName());
	}

	@Test
	void testGetSetRequestStatusId() {
		Integer requestStatusId = 1;
		requestModel.setRequestStatusId(requestStatusId);
		assertEquals(requestStatusId, requestModel.getRequestStatusId());
	}

	@Test
	void testGetSetRequestStatusDescription() {
		String requestStatusDescription = "Description";
		requestModel.setRequestStatusDescription(requestStatusDescription);
		assertEquals(requestStatusDescription, requestModel.getRequestStatusDescription());
	}

	@Test
	void testGetSetRequestProcessingDetails() {
		String requestProcessingDetails = "Details";
		requestModel.setRequestProcessingDetails(requestProcessingDetails);
		assertEquals(requestProcessingDetails, requestModel.getRequestProcessingDetails());
	}

	@Test
	void testGetSetRequestStartTime() {
		OffsetDateTime requestStartTime = OffsetDateTime.now();
		requestModel.setRequestStartTime(requestStartTime);
		assertEquals(requestStartTime, requestModel.getRequestStartTime());
	}

	@Test
	void testGetSetRequestFinishTime() {
		OffsetDateTime requestFinishTime = OffsetDateTime.now();
		requestModel.setRequestFinishTime(requestFinishTime);
		assertEquals(requestFinishTime, requestModel.getRequestFinishTime());
	}

	@Test
	void testGetSetRequestProcessingCounter() {
		Integer requestProcessingCounter = 5;
		requestModel.setRequestProcessingCounter(requestProcessingCounter);
		assertEquals(requestProcessingCounter, requestModel.getRequestProcessingCounter());
	}

	@Test
	void testGetSetCreatedBy() {
		String createdBy = "creator";
		requestModel.setCreatedBy(createdBy);
		assertEquals(createdBy, requestModel.getCreatedBy());
	}

	@Test
	void testGetSetModifiedOn() {
		String modifiedOn = "2024-01-01";
		requestModel.setModifiedOn(modifiedOn);
		assertEquals(modifiedOn, requestModel.getModifiedOn());
	}

	@Test
	void testGetSetModifiedBy() {
		String modifiedBy = "modifier";
		requestModel.setModifiedBy(modifiedBy);
		assertEquals(modifiedBy, requestModel.getModifiedBy());
	}
}
