package com.ombudsman.service.respondent.test.exception;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.Test;

import com.ombudsman.service.respondent.exception.CaseListNotFoundException;

class CaseListNotFoundExceptionTest {

	@Test
	void testConstructor_ValidInput() {
// Prepare input value
		String orgName = "Test Organization";

// Create the exception instance
		CaseListNotFoundException exception = new CaseListNotFoundException(orgName);

// Validate that the exception was created with the correct message
		assertNotNull(exception, "Exception should not be null");
		assertEquals(orgName, exception.getMessage(), "The exception message should match the input orgName");
	}

}
