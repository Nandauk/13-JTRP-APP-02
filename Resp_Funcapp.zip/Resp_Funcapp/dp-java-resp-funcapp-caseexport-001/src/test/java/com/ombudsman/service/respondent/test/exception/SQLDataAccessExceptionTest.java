package com.ombudsman.service.respondent.test.exception;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.Test;

import com.ombudsman.service.respondent.exception.SQLDataAccessException;

class SQLDataAccessExceptionTest {

	@Test
	void testConstructor_ValidInput() {
// Prepare input values
		String orgName = "Test Organization";

// Create the SQLDataAccessException instance
		SQLDataAccessException exception = new SQLDataAccessException(orgName);

// Validate that the exception was correctly initialized
		assertNotNull(exception, "The exception should not be null");

// Check the message passed to the parent constructor (super(orgName))
		assertEquals(orgName, exception.getMessage(),
				"The message passed to the parent constructor should match the input orgName");
	}

	@Test
	void testSQLDataAccessExceptionParentConstructor() {
// Prepare input value
		String orgName = "Test Organization";

// Create the SQLDataAccessException instance
		SQLDataAccessException exception = new SQLDataAccessException(orgName);

// Validate that the parent constructor is called and message is correctly set
		assertNotNull(exception, "The exception should not be null");

		assertEquals(orgName, exception.getMessage(),
				"The message should match the input orgName passed to the parent constructor");
	}
}
