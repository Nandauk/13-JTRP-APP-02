package com.ombudsman.service.respondent.model.test;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.ombudsman.service.respondent.model.CaseUpdate;
import com.ombudsman.service.respondent.model.RequestModel;
@ExtendWith(MockitoExtension.class)
class CaseUpdateTest {
	@InjectMocks
	private CaseUpdate caseUpdate;
	@Mock
	private List<RequestModel> requestModels;

	@BeforeEach
	void setUp() {
		caseUpdate = new CaseUpdate();
		requestModels = Arrays.asList(new RequestModel(), new RequestModel());
	}

	@Test
	void testGetSetDetails() {
		caseUpdate.setDetails(requestModels);
		assertEquals(requestModels, caseUpdate.getDetails());
	}

	@Test
	void testGetSetVersion() {
		String version = "1.0";
		caseUpdate.setVersion(version);
		assertEquals(version, caseUpdate.getVersion());
	}

	@Test
	void testGetSetMessageId() {
		String messageId = "message123";

		caseUpdate.setMessageId(messageId);
		assertEquals(messageId, caseUpdate.getMessageId());
	}

	@Test
	void testGetSetEntityName() {
		String entityName = "entityName123";
		caseUpdate.setEntityName(entityName);
		assertEquals(entityName, caseUpdate.getEntityName());
	}
}
