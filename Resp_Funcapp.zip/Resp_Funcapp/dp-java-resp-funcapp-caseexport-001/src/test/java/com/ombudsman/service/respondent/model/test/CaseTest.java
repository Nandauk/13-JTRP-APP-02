package com.ombudsman.service.respondent.model.test;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import com.ombudsman.service.respondent.model.Case;
@ExtendWith(MockitoExtension.class)
class CaseTest {
	private Case caseInstance;

	@BeforeEach
	void setUp() {
		caseInstance = new Case();
	}

	@Test
	void testGetSetIncidentid() {
		String incidentid = "incident123";
		caseInstance.setIncidentid(incidentid);
		assertEquals(incidentid, caseInstance.getIncidentid());
	}

	@Test
	void testGetSetTicketnumber() {
		String ticketnumber = "ticket123";
		caseInstance.setTicketnumber(ticketnumber);
		assertEquals(ticketnumber, caseInstance.getTicketnumber());
	}

	@Test
	void testGetSetFos_crn() {
		String crn = "crn123";
		caseInstance.setFos_crn(crn);
		assertEquals(crn, caseInstance.getFos_crn());
	}

	@Test
	void testGetSetCustomerIdValue() {
		String customerIdValue = "customer123";
		caseInstance.set_customerid_value(customerIdValue);
		assertEquals(customerIdValue, caseInstance.get_customerid_value());
	}

	@Test
	void testGetSetBusinessname() {
		String businessname = "AXA Insurance UK Plc";
		caseInstance.setBusinessname(businessname);
		assertEquals(businessname, caseInstance.getBusinessname());
	}

	@Test
	void testGetSetFosReference() {
		String fosReference = "fos123";
		caseInstance.setFos_reference(fosReference);
		assertEquals(fosReference, caseInstance.getFos_reference());
	}

	@Test
	void testGetSetFosExtendedReference() {
		String fosExtendedReference = "fosExt123";
		caseInstance.setFos_extendedreference(fosExtendedReference);
		assertEquals(fosExtendedReference, caseInstance.getFos_extendedreference());
	}

	@Test
	void testGetSetFosComplaintIssueValue() {
		String fosComplaintIssueValue = "issue123";
		caseInstance.set_fos_complaintissue_value(fosComplaintIssueValue);
		assertEquals(fosComplaintIssueValue, caseInstance.get_fos_complaintissue_value());
	}

	@Test
	void testGetSetFosComplaintIssueValueTxt() {
		String fosComplaintIssueValueTxt = "Breach of Confidentiality";
		caseInstance.set_fos_complaintissue_value_txt(fosComplaintIssueValueTxt);
		assertEquals(fosComplaintIssueValueTxt, caseInstance.get_fos_complaintissue_value_txt());
	}

	@Test
	void testGetSetFosProductOrProductFamilyValue() {
		String fosProductOrProductFamilyValue = "product123";
		caseInstance.set_fos_productorproductfamily_value(fosProductOrProductFamilyValue);
		assertEquals(fosProductOrProductFamilyValue, caseInstance.get_fos_productorproductfamily_value());
	}

	@Test
	void testGetSetFosProductOrProductFamilyValueTxt() {
		String fosProductOrProductFamilyValueTxt = "Balance Transfers";
		caseInstance.set_fos_productorproductfamily_value_txt(fosProductOrProductFamilyValueTxt);
		assertEquals(fosProductOrProductFamilyValueTxt, caseInstance.get_fos_productorproductfamily_value_txt());
	}

	@Test
	void testGetSetFosCasestage() {
		String fosCasestage = "Investigation";
		caseInstance.setFos_casestage(fosCasestage);
		assertEquals(fosCasestage, caseInstance.getFos_casestage());
	}

	@Test
	void testGetSetFosCasestageTxt() {
		String fosCasestageTxt = "Investigation";
		caseInstance.setFos_casestage_txt(fosCasestageTxt);
		assertEquals(fosCasestageTxt, caseInstance.getFos_casestage_txt());
	}

	@Test
	void testGetSetStatuscode() {
		String statuscode = "Awaiting Action";
		caseInstance.setStatuscode(statuscode);
		assertEquals(statuscode, caseInstance.getStatuscode());
	}

	@Test
	void testGetSetStatuscodeTxt() {
		String statuscodeTxt = "Awaiting Action";
		caseInstance.setStatuscode_txt(statuscodeTxt);
		assertEquals(statuscodeTxt, caseInstance.getStatuscode_txt());
	}

	@Test
	void testGetSetFosDateOfReferral() {
		String fosDateOfReferral = "2024-01-01";
		caseInstance.setFos_dateofreferral(fosDateOfReferral);
		assertEquals(fosDateOfReferral, caseInstance.getFos_dateofreferral());
	}

	@Test
	void testGetSetAgecaseflag() {
		String agecaseflag = "flag123";
		caseInstance.setAgecaseflag(agecaseflag);
		assertEquals(agecaseflag, caseInstance.getAgecaseflag());
	}

	@Test
	void testGetSetFosRepresentatives() {
		String fosRepresentatives = "John Doe";
		caseInstance.setFos_representatives(fosRepresentatives);
		assertEquals(fosRepresentatives, caseInstance.getFos_representatives());
	}

	@Test
	void testGetSetFosDateCaseFirstMovedToInvestigation() {
		String fosDateCaseFirstMovedToInvestigation = "2024-02-01";
		caseInstance.setFos_datecasefirstmovedtoinvestigation(fosDateCaseFirstMovedToInvestigation);
		assertEquals(fosDateCaseFirstMovedToInvestigation, caseInstance.getFos_datecasefirstmovedtoinvestigation());
	}

	@Test
	void testGetSetFosDateOfConversion() {
		String fosDateOfConversion = "2024-02-01";
		caseInstance.setFos_dateofconversion(fosDateOfConversion);
		assertEquals(fosDateOfConversion, caseInstance.getFos_dateofconversion());
	}

	@Test
	void testGetSetFosDateBusinessFileReceived() {
		String fosDateBusinessFileReceived = "2024-02-01";
		caseInstance.setFos_datebusinessfilereceived(fosDateBusinessFileReceived);
		assertEquals(fosDateBusinessFileReceived, caseInstance.getFos_datebusinessfilereceived());
	}

	@Test
	void testGetSetFosDispatchDate() {
		String fosDispatchDate = "2024-02-01";
		caseInstance.setFos_dispatcheddate(fosDispatchDate);
		assertEquals(fosDispatchDate, caseInstance.getFos_dispatcheddate());
	}

	@Test
	void testGetSetFosType() {
		String fosType = "Type";
		caseInstance.setFos_type(fosType);
		assertEquals(fosType, caseInstance.getFos_type());
	}

	@Test
	void testGetSetFosCategoryCode() {
		String fosCategoryCode = "Category";
		caseInstance.setFos_categorycode(fosCategoryCode);
		assertEquals(fosCategoryCode, caseInstance.getFos_categorycode());
	}

	@Test
	void testGetSetFosOlderCaseStatus() {
		String fosOlderCaseStatus = "Status";
		caseInstance.setFos_oldercasestatus(fosOlderCaseStatus);
		assertEquals(fosOlderCaseStatus, caseInstance.getFos_oldercasestatus());
	}

	@Test
	void testGetSetFosCaseworkerValue() {
		String fosCaseworkerValue = "worker123";
		caseInstance.set_fos_caseworker_value(fosCaseworkerValue);
		assertEquals(fosCaseworkerValue, caseInstance.get_fos_caseworker_value());
	}

	@Test
	void testGetSetFosIndividualId() {
		String fosIndividualId = "individual123";
		caseInstance.setFos_individualid(fosIndividualId);
		assertEquals(fosIndividualId, caseInstance.getFos_individualid());
	}

	@Test
	void testGetSetCaseAgeBanding() {
		String caseAgeBanding = "Banding";
		caseInstance.setCaseagebanding(caseAgeBanding);
		assertEquals(caseAgeBanding, caseInstance.getCaseagebanding());
	}

	@Test
	void testGetSetNoOfEfile() {
		String noOfEfile = "5";
		caseInstance.setNoofefile(noOfEfile);
		assertEquals(noOfEfile, caseInstance.getNoofefile());
	}

	@Test
	void testGetSetNoOfCorrespondet() {
		String noOfCorrespondet = "5";
		caseInstance.setNoofcorrespondet(noOfCorrespondet);
		assertEquals(noOfCorrespondet, caseInstance.getNoofcorrespondet());
	}

	@Test
	void testGetSetFosDateOfEvent() {
		String fosDateOfEvent = "2024-02-01";
		caseInstance.setFos_dateofevent(fosDateOfEvent);
		assertEquals(fosDateOfEvent, caseInstance.getFos_dateofevent());
	}

	@Test
	void testGetSetVulnerable() {
		String vulnerable = "Yes";
		caseInstance.setVulnerable(vulnerable);
		assertEquals(vulnerable, caseInstance.getVulnerable());
	}

	@Test
	void testGetSetFosDateOfFinalResponse() {
		String fosDateOfFinalResponse = "2024-03-01";
		caseInstance.setFos_dateoffinalresponse(fosDateOfFinalResponse);
		assertEquals(fosDateOfFinalResponse, caseInstance.getFos_dateoffinalresponse());
	}

	@Test
	void testGetSetFosOfferOutcome() {
		String fosOfferOutcome = "Offer Accepted";
		caseInstance.setFos_offeroutcome(fosOfferOutcome);
		assertEquals(fosOfferOutcome, caseInstance.getFos_offeroutcome());
	}

	@Test
	void testGetSetFosChangeInOutcome() {
		String fosChangeInOutcome = "Changed";
		caseInstance.setFos_changeinoutcome(fosChangeInOutcome);
		assertEquals(fosChangeInOutcome, caseInstance.getFos_changeinoutcome());
	}

	@Test
	void testGetSetDeadlockCases() {
		String deadlockCases = "Yes";
		caseInstance.setDeadlockcases(deadlockCases);
		assertEquals(deadlockCases, caseInstance.getDeadlockcases());
	}

	@Test
	void testGetSetFosTradingName() {
		String fosTradingName = "TradingName123";
		caseInstance.setFos_tradingname(fosTradingName);
		assertEquals(fosTradingName, caseInstance.getFos_tradingname());
	}

	@Test
	void testGetSetFosPriorityCode() {
		String fosPriorityCode = "Priority123";
		caseInstance.setFos_prioritycode(fosPriorityCode);
		assertEquals(fosPriorityCode, caseInstance.getFos_prioritycode());
	}

	@Test
	void testGetSetFosPriorityCodeTxt() {
		String fosPriorityCodeTxt = "High Priority";
		caseInstance.setFos_prioritycode_txt(fosPriorityCodeTxt);
		assertEquals(fosPriorityCodeTxt, caseInstance.getFos_prioritycode_txt());
	}

	@Test
	void testGetSetOwningUserValue() {
		String owningUserValue = "user123";
		caseInstance.set_owninguser_value(owningUserValue);
		assertEquals(owningUserValue, caseInstance.get_owninguser_value());
	}

	@Test
	void testGetSetDescription() {
		String description = "Description of the case";
		caseInstance.setDescription(description);
		assertEquals(description, caseInstance.getDescription());
	}

	@Test
	void testGetSetBrRequired() {
		String brRequired = "BR Required";
		caseInstance.setBr_required(brRequired);
		assertEquals(brRequired, caseInstance.getBr_required());
	}

	@Test
	void testGetSetStateCode() {
		String stateCode = "State123";
		caseInstance.setStatecode(stateCode);
		assertEquals(stateCode, caseInstance.getStatecode());
	}

	@Test
	void testGetSetAwaitingAction() {
		String awaitingAction = "Awaiting";
		caseInstance.setAwaitingaction(awaitingAction);
		assertEquals(awaitingAction, caseInstance.getAwaitingaction());
	}

	@Test
	void testGetSetFosOutcomeDispatchDate() {
		String fosOutcomeDispatchDate = "2024-04-01";
		caseInstance.setFos_outcomedispatcheddate(fosOutcomeDispatchDate);
		assertEquals(fosOutcomeDispatchDate, caseInstance.getFos_outcomedispatcheddate());
	}

	@Test
	void testGetSetFosResolvingOutcomeId() {
		String fosResolvingOutcomeId = "outcome123";
		caseInstance.setFos_resolvingoutcomeid(fosResolvingOutcomeId);
		assertEquals(fosResolvingOutcomeId, caseInstance.getFos_resolvingoutcomeid());
	}
}
