package com.ombudsman.service.respondent.model.test;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import com.ombudsman.service.respondent.model.UserMailjetRequest;
@ExtendWith(MockitoExtension.class)
class UserMailjetRequestTest {

	private UserMailjetRequest userMailjetRequest;

	@BeforeEach
	void setUp() {
		userMailjetRequest = new UserMailjetRequest();
	}

	@Test
	void testGetSetEmailid() {
		String emailid = "test@example.com";
		userMailjetRequest.setEmailid(emailid);
		assertEquals(emailid, userMailjetRequest.getEmailid());
	}

	@Test
	void testGetSetFullname() {
		String fullname = "John Doe";
		userMailjetRequest.setFullname(fullname);
		assertEquals(fullname, userMailjetRequest.getFullname());
	}

	@Test
	void testGetSetTemplateid() {
		int templateid = 123;
		userMailjetRequest.setTemplateid(templateid);
		assertEquals(templateid, userMailjetRequest.getTemplateid());
	}

	@Test
	void testGetSetTemplateName() {
		String templateName = "Welcome Template";
		userMailjetRequest.setTemplateName(templateName);
		assertEquals(templateName, userMailjetRequest.getTemplateName());
	}
}
