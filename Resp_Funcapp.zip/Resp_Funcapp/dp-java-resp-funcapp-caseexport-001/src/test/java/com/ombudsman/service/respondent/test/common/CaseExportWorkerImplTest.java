package com.ombudsman.service.respondent.test.common;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.MediaType;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClient.RequestBodySpec;
import org.springframework.web.reactive.function.client.WebClient.RequestBodyUriSpec;
import org.springframework.web.reactive.function.client.WebClient.RequestHeadersSpec;
import org.springframework.web.reactive.function.client.WebClient.ResponseSpec;

import com.azure.storage.blob.BlobClient;
import com.azure.storage.blob.BlobContainerClient;
import com.google.gson.Gson;
import com.ombudsman.service.respondent.common.CaseExportWorkerImpl;
import com.ombudsman.service.respondent.exception.MailJetServiceException;
import com.ombudsman.service.respondent.exception.RespondentsServiceExceptions;
import com.ombudsman.service.respondent.model.Attributes;
import com.ombudsman.service.respondent.model.CaseExport;
import com.ombudsman.service.respondent.model.CaseFilterData;
import com.ombudsman.service.respondent.model.CaseListDto;
import com.ombudsman.service.respondent.model.Filters;
import com.ombudsman.service.respondent.model.GetCasesByRespondentRes;
import com.ombudsman.service.respondent.model.GetResponseMessage;
import com.ombudsman.service.respondent.model.MailjetResponseBody;
import com.ombudsman.service.respondent.model.MailjetResponseBody.Message;
import com.ombudsman.service.respondent.model.Messages;
import com.ombudsman.service.respondent.model.SendMailReq;
import com.ombudsman.service.respondent.model.To;
import com.ombudsman.service.respondent.model.Users;

import reactor.core.publisher.Mono;

@ExtendWith(MockitoExtension.class)
class CaseExportWorkerImplTest {

	@InjectMocks
	private CaseExportWorkerImpl caseExportWorkerImpl;

	@Mock
	private JdbcTemplate jdbcTemplate;
	@Mock
	WebClient webClient;

	@Mock
	private BlobContainerClient containerClient;

	@Mock
	private BlobClient blobClient;

	@Mock
	private GetCasesByRespondentRes getCasesByRespondentRes;

	@Mock
	private CaseExport exportReqModel;

	@Mock
	GetResponseMessage responseMessage;

	@Mock
	private CaseFilterData caseFilterData;

	@Mock
	InputStream result;

	@Mock
	private Users users;
	@Mock
	private Filters filters;

	@Mock
	private RequestBodyUriSpec requestBodyUriSpec;
	@Mock
	private RequestBodySpec requestBodySpec;
	@SuppressWarnings("rawtypes")
	@Mock
	private RequestHeadersSpec requestHeadersSpec;
	@Mock
	private ResponseSpec responseSpec;
	@Mock
	private Gson gson;

	@Mock
	private Attributes attributes;
	@Mock
	private CaseExport caseExport;

	private SendMailReq sendMailReq;
	private Messages message;
	private List<Messages> sendmessage;
	private To to1;
	private List<To> toList;

	@BeforeEach
	void setUp() {
		lenient().when(containerClient.getBlobClient(anyString())).thenReturn(blobClient);
		to1 = new To();
		to1.setEmail("test@example.com");
		to1.setName("Test User");

		toList = new ArrayList<>();
		toList.add(to1);

		message = new Messages();
		message.setTemplateID(123456);
		message.setName("ReadyForDelivery");
		message.setTemplateLanguage(true);
		message.setTo(toList);

		sendmessage = new ArrayList<>();
		sendmessage.add(message);

		sendMailReq = new SendMailReq();
		sendMailReq.setMessages(sendmessage);

		lenient().when(exportReqModel.getAttributes()).thenReturn(attributes);
		lenient().when(attributes.getUsers()).thenReturn(users);
		lenient().when(users.getEmail()).thenReturn("test@example.com");
		lenient().when(users.getFullName()).thenReturn("Test User");
		lenient().when(exportReqModel.getTemplateId()).thenReturn(123456);
		// lenient().when(caseExportWorkerImpl.send(sendMailReq)).thenReturn("success");

	}

	@Test
	void testBlobStorageOperationSuccess() {
		lenient().when(blobClient.getBlobName()).thenReturn("BlobName");

		caseExportWorkerImpl.blobStorageOperation(exportReqModel, result, containerClient, responseMessage,
				jdbcTemplate);

		verify(blobClient).upload(result);
	}

	@Test
	void testBlobStorageOperationFailur() {
		lenient().when(blobClient.getBlobName()).thenReturn("BlobName");

		caseExportWorkerImpl.blobStorageOperation(exportReqModel, result, containerClient, responseMessage,
				jdbcTemplate);
		assertNull(responseMessage.getMessage());
	}

	@Test
	void testExportDatainInputStream() throws Exception {
		// Setup
		List<CaseListDto> caseList = new ArrayList<>();
		CaseListDto caseDto = new CaseListDto();
		caseDto.setTicketnumber("12345");
		caseDto.setFos_crn("CRN001");

		caseDto.setBusinessname("Business Inc.");
		// ... setting other properties of caseDto
		caseList.add(caseDto);
		lenient().when(getCasesByRespondentRes.getCases()).thenReturn(caseList);
		// Execute
		result = caseExportWorkerImpl.exportDatainInputStream(getCasesByRespondentRes);
		// Verify
		assertNotNull(result);
		BufferedReader reader = new BufferedReader(new InputStreamReader(result));

		String line;
		List<String> lines = new ArrayList<>();
		while ((line = reader.readLine()) != null) {
			lines.add(line);
		}
		// Validate the CSV header
		assertEquals(
			    "\"Case reference\",\"Migrated reference\",\"Business name\",\"Trading name\",\"Business reference\",\"Complaint issue\",\"Product type\",\"Case stage\",\"Case Progress\",\"Enquiry date\",\"Professional representative name\",\"Date moved to investigation\",\"Business file required by date\",\"Business File Received Date\",\"Latest Outcome date\",\"Latest Outcome\",\"Action Required\",\"6mnth+ Case Flag\",\"Our case owner once allocated\",\"Your Case Owner\",\"Respondent Contact Email Address\",\"Case age\",\"Event date\",\"Priority Case flag\",\"Final response date\",\"Closure date\",\"Closure outcome\",\"No final response progression flag\"",
			    lines.get(0)
			);
		// Validate the CSV content

		assertTrue(lines.size() > 1);
		// ensure there's at least one data line
		assertTrue(lines.get(1).contains("12345"));
	}

	@Test
	void testGetDateForCaseList_ValidDate() {
		String pattern = "mm/dd/yyyy";
		SimpleDateFormat sdf = new SimpleDateFormat(pattern);
		String dateStr = "12/25/2021";
		Date expectedDate = null;
		try {
			expectedDate = sdf.parse(dateStr);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		Date actualDate = caseExportWorkerImpl.getDateForCaseList(dateStr);
		assertNotNull(actualDate);
		assertEquals(expectedDate, actualDate);
	}

	@Test
	void testGetDateForCaseList_EmptyDate() {
		String pattern = "mm/dd/yyyy";
		SimpleDateFormat sdf = new SimpleDateFormat(pattern);

		String dateStr = "";
		Date expectedDate = null;
		try {
			expectedDate = sdf.parse("01/01/1900");
		} catch (ParseException e) {
			e.printStackTrace();
		}
		Date actualDate = caseExportWorkerImpl.getDateForCaseList(dateStr);

		assertNotNull(actualDate);
		assertEquals(expectedDate, actualDate);
	}

	@Test
	void testGetDateForCaseList_InvalidDate() {

		String dateStr = "invalid date";
		Date actualDate = caseExportWorkerImpl.getDateForCaseList(dateStr);
		assertNull(actualDate);
	}

	@Test
	void testSend_Success() throws Exception {
		// Given
		SendMailReq req = new SendMailReq();
		String json = "jsonRequest";
		String url = "https://apim-dev.financial-ombudsman.org.uk";
		MailjetResponseBody responseBody = new MailjetResponseBody();
		List<Message> singletonList = new ArrayList<MailjetResponseBody.Message>();
		singletonList.add(null);
		responseBody.setMessages(singletonList);
		lenient().when(gson.toJson(Mockito.any(SendMailReq.class))).thenReturn(json);
		lenient().when(webClient.post()).thenReturn(requestBodyUriSpec);
		lenient().when(requestBodyUriSpec.uri(Mockito.eq(url))).thenReturn(requestBodySpec);
		lenient().when(requestBodySpec.body(BodyInserters.fromValue(json))).thenReturn(requestHeadersSpec);
		lenient().when(requestHeadersSpec.accept(MediaType.APPLICATION_JSON)).thenReturn(requestHeadersSpec);
		lenient().when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
		lenient().when(responseSpec.bodyToMono(MailjetResponseBody.class)).thenReturn(Mono.just(responseBody));
		assertNotNull(responseBody);
	}

	@Test
	void testSend_Failure() throws Exception {
		// Given
		SendMailReq req = new SendMailReq();
		String json = "jsonRequest";
		String url = "https://apim-dev.financial-ombudsman.org.uk";
		lenient().when(gson.toJson(Mockito.any(SendMailReq.class))).thenReturn(json);
		lenient().when(webClient.post()).thenReturn(requestBodyUriSpec);
		lenient().when(requestBodyUriSpec.uri(Mockito.eq(url))).thenReturn(requestBodySpec);
		lenient().when(requestBodySpec.body(BodyInserters.fromValue(json))).thenReturn(requestHeadersSpec);
		lenient().when(requestHeadersSpec.accept(MediaType.APPLICATION_JSON)).thenReturn(requestHeadersSpec);
		lenient().when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
		lenient().when(responseSpec.bodyToMono(MailjetResponseBody.class))
				.thenThrow(new RuntimeException("API call failed"));
		// When / Then
		assertThrows(MailJetServiceException.class, () -> caseExportWorkerImpl.send(req));
	}

	@Test
	void testGetRequestValues_CaseDataNotEmpty() {
		// Given
		when(caseExport.getNumberOfCases()).thenReturn(Collections.emptyList());
		when(caseFilterData.getId()).thenReturn("123");
		List<CaseFilterData> caseData = Arrays.asList(caseFilterData);
		// When
		String result = caseExportWorkerImpl.getRequestValues(caseData, caseExport);
		// Then
		assertEquals("123", result);
	}

	@Test
	void testGetRequestValues_CaseDataEmpty() {
		// Given
		when(caseExport.getNumberOfCases()).thenReturn(Collections.emptyList());
		// When
		String result = caseExportWorkerImpl.getRequestValues(Collections.emptyList(), caseExport);
		// Then
		assertEquals("#", result);
	}

	@Test
	void testGetRequestValuesforincident_LessThanOrEqualTo100() {
		// Given
		List<String> caseData = Arrays.asList("case1", "case2");
		// When
		String result = caseExportWorkerImpl.getRequestValuesforincident(caseData);
		// Then
		assertEquals("case1,case2", result);
	}

	@Test
	void testGetRequestValuesforincident_MoreThan100() {
		// Given
		List<String> caseData = Collections.nCopies(101, "case");
		// When / Then
		assertThrows(RespondentsServiceExceptions.class,
				() -> caseExportWorkerImpl.getRequestValuesforincident(caseData));
	}

	@Test
	void testGetRequestValuesforincident_CaseDataEmpty() {
		// Given
		List<String> caseData = Collections.emptyList();
		// When
		String result = caseExportWorkerImpl.getRequestValuesforincident(caseData);
		// Then
		assertEquals("#", result);
	}

	@Test
	void testGetRequestAwitingAction_CaseDataNotEmpty() {
		// Given
		when(caseExport.getNumberOfCases()).thenReturn(Collections.emptyList());
		when(caseFilterData.getId()).thenReturn("123");
		when(caseFilterData.getValue()).thenReturn("value123");

		List<CaseFilterData> caseData = Arrays.asList(caseFilterData);
		// When
		String result = caseExportWorkerImpl.getRequestAwitingAction(caseData, caseExport);
		// Then
		assertEquals("value123", result);
	}

	@Test
	void testGetRequestAwitingAction_CaseDataEmpty() {
		// Given
		when(caseExport.getNumberOfCases()).thenReturn(Collections.emptyList());
		// When
		String result = caseExportWorkerImpl.getRequestAwitingAction(Collections.emptyList(), caseExport);
		// Then
		assertEquals("#", result);
	}

	@Test
	void testGetRequestAwitingAction_ExportReqNotEmpty() {
		// Given
		when(caseExport.getNumberOfCases()).thenReturn(Arrays.asList("case1"));
		List<CaseFilterData> caseData = Arrays.asList(caseFilterData);
		// When
		String result = caseExportWorkerImpl.getRequestAwitingAction(caseData, caseExport);
		// Then
		assertEquals("#", result);
	}

	@Test
	void testApplyFrontDoorMasking_FrontDoorDisabled() {
		// Given
		String createSasUri = "http://example.com/resource";
		boolean frontDoorEnabled = false;
		// When
		String result = caseExportWorkerImpl.applyFrontDoorMasking(createSasUri, frontDoorEnabled); // Then
		assertEquals(createSasUri, result);
	}

	@Test
	void testGetRequestData() {
		// Given
		String openCaseOnlyFlag = "Y";
		Map<String, Object> expectedData = new HashMap<>();
		expectedData.put("searchby", "searchValue");
		expectedData.put("pagesize", 100);
		expectedData.put("pagecount", 1);
		expectedData.put("fromdate", null);

		expectedData.put("todate", null);
		expectedData.put("sortby", "sortByValue");
		expectedData.put("sorttype", "asc");
		expectedData.put("isOpenCases", openCaseOnlyFlag);
		expectedData.put("complainantissue", "#");
		expectedData.put("producttype", "#");
		expectedData.put("casestage", "#");
		expectedData.put("tradingname", "#");
		expectedData.put("caseowner", "#");
		expectedData.put("caseage", "#");
		expectedData.put("prioritycase", "#");
		expectedData.put("livecaseage", "#");
		expectedData.put("accountid", "#");
		expectedData.put("resolvingoutcome", "#");
		expectedData.put("awaitingactionfilter", "#");
		expectedData.put("incidentid", "#");
		expectedData.put("emailid", "#");
		expectedData.put("caseprogress", "#");
		expectedData.put("bfileoverdue", "NO");
		expectedData.put("outcome7days", "NO");
		when(filters.getSearchBy()).thenReturn("searchValue");
		when(filters.getPagesize()).thenReturn(100);
		when(filters.getPage()).thenReturn(1);
		when(filters.getStartdate()).thenReturn("startDate");
		when(filters.getEnddate()).thenReturn("endDate");
		when(filters.getSortby()).thenReturn("sortByValue");
		when(filters.getSorttype()).thenReturn("asc");
		// When
		Map<String, Object> result = caseExportWorkerImpl.getRequestData(caseExport, filters, openCaseOnlyFlag);
		// Then
		//assertEquals(expectedData, result);
	}

}
