package com.ombudsman.service.respondent.test.exception;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import com.ombudsman.service.respondent.exception.CryptoServiceException;
import com.ombudsman.service.respondent.exception.RespondentsServiceExceptions;

class CryptoServiceExceptionTest {

	@Test
	void testConstructor_ValidInput() {
// Prepare input values
		String message = "Test message";
		String exceptionMessage = "Test exception message";
		StackTraceElement[] stackTraceElements = new StackTraceElement[] {
				new StackTraceElement("ClassName", "methodName", "fileName", 10) };

// Create the CryptoServiceException instance
		CryptoServiceException exception = new CryptoServiceException(message, exceptionMessage, stackTraceElements);

// Validate that the exception was correctly initialized
		assertNotNull(exception, "The exception should not be null");
		assertEquals(message, exception.getMessage(), "The exception message should match the input message");
		assertEquals("RESPONDENT_CRYPTO_1003", exception.getCode(), "The error code should match the expected value");
		assertEquals(exceptionMessage, exception.getExceptionMessage(),
				"The exception message should match the input exceptionMessage");

	}

	@Test
	void testCryptoServiceExceptionParentConstructor() {
// Mocking the superclass constructor
		RespondentsServiceExceptions mockParent = Mockito.mock(RespondentsServiceExceptions.class);

// Prepare input values
		String message = "Test message";
		String exceptionMessage = "Test exception message";
		StackTraceElement[] stackTraceElements = new StackTraceElement[] {
				new StackTraceElement("ClassName", "methodName", "fileName", 10) };

// Create the CryptoServiceException instance
		CryptoServiceException exception = new CryptoServiceException(message, exceptionMessage, stackTraceElements);

// Check that the parent constructor is called with the expected parameters
		assertNotNull(exception);
		assertEquals(message, exception.getMessage(),
				"The message passed to the parent constructor should be set correctly");
	}
}
