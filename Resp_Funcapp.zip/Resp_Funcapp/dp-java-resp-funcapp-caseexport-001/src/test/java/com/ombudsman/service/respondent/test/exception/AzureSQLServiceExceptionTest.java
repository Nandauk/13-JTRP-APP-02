package com.ombudsman.service.respondent.test.exception;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import com.ombudsman.service.respondent.exception.AzureSQLServiceException;
import com.ombudsman.service.respondent.exception.RespondentsServiceExceptions;

class AzureSQLServiceExceptionTest {
	@Test
	void testConstructor_ValidInputs() {
		// Prepare input values
		String message = "Test message";
		String exceptionMessage = "Test exception message";
		StackTraceElement[] stackTraceElements = new StackTraceElement[] {
				new StackTraceElement("ClassName", "methodName", "fileName", 10) };

		// Create AzureSQLServiceException instance
		AzureSQLServiceException exception = new AzureSQLServiceException(message, exceptionMessage,
				stackTraceElements);

		// Validate that the exception was correctly initialized
		assertNotNull(exception);
		assertEquals(message, exception.getMessage());
		assertEquals("RESPONDENT_PHOENIX_1001", exception.getCode());
		assertEquals(exceptionMessage, exception.getExceptionMessage());
		// assertArrayEquals(stackTraceElements, exception.getStackTrace());
	}

	@Test
	void testAzureSQLServiceExceptionParentConstructor() {
		// Mocking the superclass
		RespondentsServiceExceptions mockParent = Mockito.mock(RespondentsServiceExceptions.class);

		// Prepare input values
		String message = "Test message";
		String exceptionMessage = "Test exception message";
		StackTraceElement[] stackTraceElements = new StackTraceElement[] {
				new StackTraceElement("ClassName", "methodName", "fileName", 10) };

		// Check that the parent constructor is called with expected values
		AzureSQLServiceException exception = new AzureSQLServiceException(message, exceptionMessage,
				stackTraceElements);
		assertNotNull(exception);
		assertEquals(message, exception.getMessage());
	}
}
