package com.ombudsman.service.respondent;

public class NotificationDownloadRequest {
	private String DocumentId;
	private String Url;
	private String FileName;
	private String ErrorMessage;
	private boolean IsSuccessful;

	public String getErrorMessage() {
		return ErrorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		ErrorMessage = errorMessage;
	}

	public boolean isIsSuccessful() {
		return IsSuccessful;
	}

	public void setIsSuccessful(boolean isSuccessful) {
		IsSuccessful = isSuccessful;
	}

	public String getDocumentId() {
		return DocumentId;
	}

	public void setDocumentId(String documentId) {
		DocumentId = documentId;
	}

	public String getUrl() {
		return Url;
	}

	public void setUrl(String url) {
		Url = url;
	}

	public String getFileName() {
		return FileName;
	}

	public void setFileName(String fileName) {
		FileName = fileName;
	}

}
