package com.ombudsman.service.respondent;

import java.beans.Transient;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONException;
import org.springframework.http.MediaType;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.WebClient;

import com.azure.storage.blob.BlobClient;
import com.azure.storage.blob.BlobContainerClient;
import com.azure.storage.blob.BlobServiceClientBuilder;
import com.google.gson.Gson;
import com.microsoft.azure.functions.ExecutionContext;
import com.microsoft.azure.functions.annotation.FunctionName;
import com.microsoft.azure.functions.annotation.ServiceBusQueueTrigger;
import com.microsoft.azure.functions.annotation.TimerTrigger;
import com.ombudsman.service.respondent.exception.MailJetServiceException;

public class NotificationAzureFunction {

	private static final String SUCCESS = "Success";
	private static final String FAILED = "Failed";
	private static final String READY_FOR_DELIVERY = "ReadyForDelivery";
	private static final String TRUE = "true";
	private static final boolean TRUEE = true;
	private static final String FALSE = "false";
	private static final String URI = "/mailjet/send";
	private static final String TWO = "2";
	private static final String FIVE = "5";
	private static final String TEN = "10";
	private static final String READY_FOR_DELIVERY_PS = "ReadyForDelivery_PS";
	private static final String TWELVE = "12";
	private static final String FOURTEEN = "14";
	private static final String TO_BE_PROCESSED_BY_JOB = "ToBeProcessedByJob";
	private static final String TEMPLATE_DOWNLOAD_FAILURE = "Download Failure";
	private static final String TEMPLATE_PARTIAL_DOWNLOAD = "Partial Download";
	private static final String TEMPLATE_INTERIM_NOTIFY = "Intermediate Download";
	private static final String FAILED_INTERIM_NOTIFY = "FailedInterimNotify";
	private static final String FAILED_NOT_TO_BE_SENT = "FailedNotToBeSent";
	private static final String DP_AUDIT_EVENT_INSERT = "INSERT INTO DP_AUDIT_EVENT (user_oid,audit_event_timestamp,audit_event_name,primary_audit_entity,primary_audit_entity_identifier,pre_audit_snapshot,post_audit_snapshot,created_on,created_by) VALUES (?,?,?,?,?,?,?,?,?)";

	Logger log = LogManager.getRootLogger();

	// DB connection
	final JdbcTemplate jdbcTemplate = jdbcConnection();

	/*
	 * @FunctionName("notificationUpload")
	 * 
	 * @Transient(true) public String apitoServiceBus(
	 * 
	 * @ServiceBusQueueTrigger(name = "message", queueName = "%QueueNameUpload%",
	 * connection = "AzureWebJobsServiceBus") NotificationUploadRequest message,
	 * final ExecutionContext context) {
	 * 
	 * log.info(String.format("Request message for Upload : %s",
	 * message.getPackageId()));
	 * 
	 * try { if (FALSE.equalsIgnoreCase(message.getIsSuccessful())) { Object[]
	 * paramNotification = new Object[] { message.getPackageId() };
	 * log.info(String.format("Failed for package id : %s",
	 * message.getPackageId()));
	 * 
	 * String sql =
	 * "update dp_upload_request_files set is_uploaded ='false' where upload_request_id IN (select id from dp_upload_requests where package_id=?) and status='Passed'"
	 * ; log.info(String.format("sql to update is uploaded is false : %s", sql));
	 * 
	 * jdbcTemplate.update(sql, paramNotification);
	 * log.info(String.format("Failed :: IsSuccessfull Message: %s",
	 * message.getIsSuccessful())); log.info(String.
	 * format("Notification data updated is_uploaded as false in Database for package Id : %s"
	 * , message.getPackageId()));
	 * 
	 * return "Fail";
	 * 
	 * } else if (TRUE.equalsIgnoreCase(message.getIsSuccessful())) {
	 * 
	 * Object[] paramNotification = new Object[] { message.getPackageId() };
	 * log.info(String.format("Passed for package id : %s",
	 * message.getPackageId()));
	 * 
	 * String sql =
	 * "update dp_upload_request_files set is_uploaded ='true' where upload_request_id IN (select id from dp_upload_requests where package_id=?) and status='Passed'"
	 * ; log.info(String.format("sql to update is uploaded is true : %s", sql));
	 * 
	 * jdbcTemplate.update(sql, paramNotification); log.info(String.format(
	 * "In Upload Request Files data updated for is_uploaded as true for package Id : %s"
	 * , message.getPackageId())); } } catch (Exception e) {
	 * log.error(String.format("Error in notification %s", e.getMessage())); }
	 * 
	 * return "success"; }
	 */

	// 0 0 0 * * *
	/** * This function runs once every 24 hours. */
	@FunctionName("TimerTriggerFunction")
	public void run(@TimerTrigger(name = "timerInfo", schedule = "0 0 0 * * *") String packgid,
			final ExecutionContext context) {
		log.info("Java Timer Trigger function App Started");
		log.info(String.format("Java Timer trigger function executed at: %s", java.time.LocalDateTime.now()));

		try {

			List<UploadRequestFile> fileQuery = new ArrayList<>();
			UploadRequestFile file = new UploadRequestFile();

			Connection conn = connectionjdbc();
			PreparedStatement pstmt = conn.prepareStatement(
					"select document_id , upload_request_id from dp_upload_request_files where is_uploaded=?");
			pstmt.setString(1, "true");

			try (ResultSet rs = pstmt.executeQuery()) {

				while (rs.next()) {
					file.setUploadRequestId(rs.getInt("upload_request_id"));
					file.setStatus(rs.getString("document_id"));
					fileQuery.add(file);
					log.info(String.format("updateRequest RS :: get status from Uploadrequestsfile table :: %s",
							file.getStatus()));
					log.info(
							String.format("updateRequest RS :: get UploadRequestId from Uploadrequestsfile table :: %s",
									file.getUploadRequestId()));
				}
			} catch (Exception e) {
				log.error(String.format("catch block one :: %s ", e.getMessage()));
			}

			for (UploadRequestFile uploaddto : fileQuery) {

				Integer reqId = uploaddto.getUploadRequestId();
				Object[] id = new Object[] { reqId };
				log.info(String.format("id: %d", id));

				String getidsql = "select package_id from dp_upload_requests where id=?";
				log.info(String.format("getidsql: %s", getidsql));

				String packageid = jdbcTemplate.queryForObject(getidsql, String.class, reqId);
				log.info(String.format("packageid : %s", packageid));

				deleteFilesfromContainer(packageid, uploaddto.getDocumentId(), System.getenv("DPFILE_CONTAINER"));
				deleteFilesfromContainer(packageid, uploaddto.getDocumentId(), System.getenv("UPLOAD_CONTAINER"));

			}

		} catch (Exception e) {
			log.error(String.format("Error in TimerTriggerFunction %s", e.getMessage()));
		}
		context.getLogger().info("Processing the 24-hour task.");
	}

	@FunctionName("notificationDownload")
	@Transient(true)
	public String notificationdownload(
			@ServiceBusQueueTrigger(name = "message", queueName = "%QueueNameDownload%", connection = "AzureWebJobsServiceBus") DocumentsListReq message,
			final ExecutionContext context) {
	//public String downloadFunction( DocumentsListReq message)
	//{
		log.info("Download Funcapp started ");
		Notification notification = new Notification();
		Integer countofNull = -1;
		Integer failedFilesCount = -1;
		Integer totalFilesCount = 0;
		Integer reProcessingCount = -1;
		List<String> listOfDownloadReqId = new ArrayList<>();

		log.info(String.format("Request Received for Download Function App is : %s", message));

		String instanceid = message.getInstanceId();
		String notificationId = message.getNotificationId();
		log.info(String.format("Instance Id received from request : %s", instanceid));
		if (!message.getDocuments().isEmpty() && !instanceid.isEmpty()) {

			// Post Audit Entry
			postAuditEntries(jdbcTemplate);

			String downloadreqId = message.getRequestId();
															
			log.info(String.format("Value of download_request_id to be added in list :: %s", downloadreqId));

			listOfDownloadReqId.add(downloadreqId);
			for (NotificationDownloadRequest document : message.getDocuments()) {

				log.info(String.format("Document Id received from request : %s", document.getDocumentId()));
				log.info(String.format("file name received from request : %s", document.getFileName()));
				log.info(String.format("Url received from request : %s", document.getUrl()));
				log.info(String.format("Error Message received from request : %s", document.getErrorMessage()));
				log.info(String.format("Is Successfull received from request : %s", document.isIsSuccessful()));

				updateDownladRequest(document, jdbcTemplate, downloadreqId);

			}

			try {

				for (String listofId : listOfDownloadReqId) {

					log.info(String.format("loop started for listofId :: %s", listofId));
//					to get the count of download request id where status is null 
					Object[] paramToCheckNullCount = new Object[] { listofId };

					String sqlGetDownloadFortatusNull = "select count(*) from dp_download_request_items where status is NULL and download_request_id = ?";
					countofNull = jdbcTemplate.queryForObject(sqlGetDownloadFortatusNull, Integer.class,
							paramToCheckNullCount);
					log.info(String.format("sqlGetDownloadFortatusNull :: countofNull : %d", countofNull));

					if (countofNull > 0) {
						log.info(String.format(
								"Request is Pending for Download Request Id : %s in response because countofNull is greater than 0 : %d",
								listofId, countofNull));
						return SUCCESS; // request pending to be completed in dp_download_request
					}

					String sqlGetDownloadStatus = "select count(*) from dp_download_request_items where status != 'SUCCESS' and download_request_id = ?"; // Id
					failedFilesCount = jdbcTemplate.queryForObject(sqlGetDownloadStatus, Integer.class, paramToCheckNullCount);
					log.info(String.format("sqlGetDownloadStatus :: count : %d", failedFilesCount));

					String sqlGetTotalFilesCount = "select count(*) from dp_download_request_items where download_request_id = ?";
					totalFilesCount = jdbcTemplate.queryForObject(sqlGetTotalFilesCount, Integer.class,
							paramToCheckNullCount);
					log.info(String.format("Total Number Of files for given requestId :: count : %d", totalFilesCount));

//					Set DownloadRequestId in Notification Model
					notification.setRequestId(listofId);

					log.info(String.format("RequestId to be set in Notification: %s", notification.getRequestId()));

					String sqlRequestProcessingCounter = "select request_processing_counter from [dbo].[dp_user_request] where request_id = ?";
					reProcessingCount = jdbcTemplate.queryForObject(sqlRequestProcessingCounter, Integer.class,
							paramToCheckNullCount);
					log.info(String.format("Re-Processing Count for given requestId :: count : %d", reProcessingCount));

					if (reProcessingCount == 3 || (failedFilesCount == 0)) // Check To Verify if All Files are successfully
																// downloaded or 3 retries are done
					{
						if (failedFilesCount > 0) {
							
							//Getting Message from notification record to update with number of failed files
							notification.setNotificationId(Long.valueOf(notificationId));
							String sqlGetMessage = "select message from [dbo].[dp_user_notification] where notification_id= ?";
							Object[] params = new Object[]  {notification.getNotificationId()};
							
							String messageNotification = jdbcTemplate.queryForObject(sqlGetMessage, String.class,params);

							if (failedFilesCount.equals(totalFilesCount)) // Complete Failure Scenario
							{
								notification.setNotificationStatusId(FIVE);
								notification.setNotificationStatusDescription(FAILED);
								notification.setMessage(new StringBuilder().append(messageNotification).append("-").append(failedFilesCount).toString());

								updateDownloadJdbcCall(jdbcTemplate, FAILED, listofId);
								notificationJdbcCallFrFailedFiles(jdbcTemplate, notification);
								sendInviteToUserWebclient(notification.getRequestId(), FIVE,jdbcTemplate);
							} else // Partial Success Scenario
							{
								notification.setNotificationStatusId(TEN);
								notification.setNotificationStatusDescription(READY_FOR_DELIVERY_PS);
								notification.setMessage(new StringBuilder().append(messageNotification).append("-").append(failedFilesCount).toString());

//							Download Table update for ReadyforDelivery
								updateDownloadJdbcCall(jdbcTemplate, READY_FOR_DELIVERY_PS, listofId);
								notificationJdbcCallFrFailedFiles(jdbcTemplate, notification);
								sendInviteToUserWebclient(notification.getRequestId(), TEN,jdbcTemplate);
							}
						} else {

							// successCount++;
							// log.info(String.format("Success Count : %d", successCount));

//						Notification Table update for Ready for delivery
							notification.setNotificationStatusId(TWO);
							notification.setNotificationStatusDescription(READY_FOR_DELIVERY);
							notification.setNotificationId(Long.valueOf(notificationId));

//						Download Table update for ReadyforDelivery
							updateDownloadJdbcCall(jdbcTemplate, READY_FOR_DELIVERY, listofId);
							notificationJdbcCall(jdbcTemplate, notification);
							sendInviteToUserWebclient(notification.getRequestId(), TWO,jdbcTemplate);
						}
					} else if (failedFilesCount > 0) {
						if (reProcessingCount == 0)// Need to send intermediate Notification
						{
							notification.setNotificationStatusId(TWELVE);
							notification.setNotificationStatusDescription(FAILED_INTERIM_NOTIFY);
							notification.setNotificationId(Long.valueOf(notificationId));
							notificationJdbcCall(jdbcTemplate, notification);
							sendInviteToUserWebclient(notification.getRequestId(), TWELVE,jdbcTemplate);
							updateDownloadJdbcCall(jdbcTemplate, TO_BE_PROCESSED_BY_JOB, listofId);
						}else
						{
							notification.setNotificationStatusId(FOURTEEN);
							notification.setNotificationStatusDescription(FAILED_NOT_TO_BE_SENT);
							notification.setNotificationId(Long.valueOf(notificationId));
							notificationJdbcCall(jdbcTemplate, notification);
						}
					}
				}
			} catch (Exception e) {
				log.error(String.format("Error while updating data in Notification / dp_download_requests table  %s",
						e.getMessage()));
			}

		}
		log.info("Download Funcapp Ended ");
		return SUCCESS;

	}

	public void sendInviteToUserWebclient(String reqId, String downloadStatus, JdbcTemplate jdbcTemplate) {
		log.info("SendMailReq code started ");
		GetResponseMessage responseMessage = new GetResponseMessage();
		try {

			Object[] reqParam = new Object[] { reqId };
			String sqlForEmailFromDownloadReq = "SELECT user_email FROM dp_download_requests where id =?";
			String emailFromDownloadRequest = jdbcTemplate.queryForObject(sqlForEmailFromDownloadReq, String.class,
					reqParam);
			log.info(String.format("Email fetched from query of download Request %s", emailFromDownloadRequest));

			SendMailReq sendMailReq = new SendMailReq();
			List<To> to = new ArrayList<>();
			List<Messages> sendmessage = new ArrayList<>();
			To to1 = new To();
			to1.setEmail(emailFromDownloadRequest);
			to1.setName("");
			to.add(to1);

			Messages message = new Messages();
			switch (downloadStatus) {
			case TWO:
				message.setTemplateID(Integer.parseInt(System.getenv("Template_Id")));
				message.setName(READY_FOR_DELIVERY);
				break;
			case FIVE:
				message.setTemplateID(Integer.parseInt(System.getenv("Template_Id_Failure")));
				message.setName(TEMPLATE_DOWNLOAD_FAILURE);
				break;
			case TEN:
				message.setTemplateID(Integer.parseInt(System.getenv("Template_Id_PartialSuccess")));
				message.setName(TEMPLATE_PARTIAL_DOWNLOAD);
				break;
			case TWELVE:
				message.setTemplateID(Integer.parseInt(System.getenv("Template_Id_Intermediate")));
				message.setName(TEMPLATE_INTERIM_NOTIFY);
				break;
			}
			message.setTemplateLanguage(TRUEE);
			message.setTo(to);

			From from = new From();
			from.setEmail(System.getenv("From_Email"));
			from.setName("Download Notification");
			message.setFrom(from);
			sendmessage.add(message);
			sendMailReq.setMessages(sendmessage);

			String response = send(sendMailReq);
			log.info(String.format("sendMailReq response %s", response));

			if (response.equals(SUCCESS)) {
				responseMessage.setMessage(String.format("MailJet API call success : %s", response));
			} else {
				responseMessage.setMessage(String.format("MailJet API call failed : %s" + response));
			}
			log.info("SendMailReq code  ended ");
		} catch (Exception e) {
			log.error(String.format("Error in Method SendMailReq %s", e.getMessage()));
		}

	}

	public String send(SendMailReq req) throws JSONException {
		log.info("Mailjet Send request method started");
		Gson gson = new Gson();
		String json = gson.toJson(req);
		MailjetResponseBody responseBody = new MailjetResponseBody();
		String status = null;
		log.info(String.format("Request data for Send API %s", json));
		String url = System.getenv("APIM_URL") + URI;
		log.info(String.format("Send API Url : %s", url));

		try {
			responseBody = WebClient.create().post().uri(url).body(BodyInserters.fromValue(json))
					.accept(MediaType.APPLICATION_JSON).retrieve().bodyToMono(MailjetResponseBody.class).block();
			if (responseBody != null) {
				status = responseBody.getMessages().get(0).getStatus();
				log.info(String.format("Response : %s", status));
			}
		} catch (Exception ex) {
			log.error(String.format("Webclient call failed %s", ex.getMessage()));
			throw new MailJetServiceException("Mailjet Exception occured %s", ex.getMessage(), ex.getStackTrace());
		}

		log.info(String.format("Response : %s", responseBody));
		if (null != responseBody) {
			status = responseBody.getMessages().get(0).getStatus();
		}

		return status;

	}

	public void notificationJdbcCall(JdbcTemplate jdbcTemplate, Notification notification) {
		log.info("notificationJdbcCall Method Started ");
		try {

			Object[] notificationParams = new Object[] {OffsetDateTime.now(), notification.getNotificationStatusId(),
					notification.getNotificationStatusDescription(), notification.getRequestId() ,notification.getNotificationId()};
			log.info(String.format("data to be saved in Notification for request id  : %s",
					notification.getRequestId()));
			log.info(String.format("Notification Description : %s", notification.getNotificationStatusDescription()));

			String notificationSql = "update dp_user_notification set modified_on=?, notification_status_id= ?,notification_status_description= ? where request_id= ? and notification_id=?";
			log.info(String.format("notificationSql : %s", notificationSql));

			jdbcTemplate.update(notificationSql, notificationParams);
			log.info("Notification data updated in Database ");
			log.info("notificationJdbcCall Method Ended ");

		} catch (Exception e) {
			log.error(String.format("Error while updating data or Records not found in Notification table %s",
					e.getMessage()));
		}
	}
	
	public void notificationJdbcCallFrFailedFiles(JdbcTemplate jdbcTemplate, Notification notification) {
		log.info("notificationJdbcCallFrFailedFiles Method Started ");
		try {

			Object[] notificationParams = new Object[] {OffsetDateTime.now(), notification.getNotificationStatusId(),
					notification.getNotificationStatusDescription(), notification.getMessage(), notification.getRequestId() ,notification.getNotificationId()};
			log.info(String.format("data to be saved in Notification for request id  : %s",
					notification.getRequestId()));
			log.info(String.format("Notification Description : %s", notification.getNotificationStatusDescription()));

			String notificationSql = "update dp_user_notification set modified_on=? notification_status_id= ?,notification_status_description= ?, message= ? where request_id= ? and notification_id=?";
			log.info(String.format("notificationSql : %s", notificationSql));

			jdbcTemplate.update(notificationSql, notificationParams);
			log.info("Notification data updated in Database ");
			log.info("notificationJdbcCall Method Ended ");

		} catch (Exception e) {
			log.error(String.format("Error while updating data or Records not found in Notification table %s",
					e.getMessage()));
		}
	}

	public void updateDownloadJdbcCall(JdbcTemplate jdbcTemplate, String readyForDel, String id) {
		log.info("updateDownloadJdbcCall Method Started ");
		try {

			Object[] updateDownloadParams = new Object[] { readyForDel, id };
			log.info(String.format("params for update Download  : %s and %s ", readyForDel, id));

			String downloadSql = "update dp_download_requests set status= ? where id= ?";
			log.info(String.format("downloadSql : %s ", downloadSql));

			jdbcTemplate.update(downloadSql, updateDownloadParams);
			log.info("updateDownloadJdbcCall data updated in Database ");

			log.info("updateDownloadJdbcCall Method Ended ");

		} catch (Exception e) {
			log.error(String.format("Error while updating data or Records not found in dp_download_requests table : %s",
					e.getMessage()));
		}
	}

	private JdbcTemplate jdbcConnection() {
		JdbcTemplate jdbcTemplateConn;
		DriverManagerDataSource dataSource = new DriverManagerDataSource();
		dataSource.setDriverClassName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
		dataSource.setUrl(System.getenv("SQL_DATASOURCE_URL"));
		dataSource.setUsername(System.getenv("SQL_DATASOURCE_USERNAME"));
		dataSource.setPassword(System.getenv("SQL_DATASOURCE_PASSWORD"));
		jdbcTemplateConn = new JdbcTemplate(dataSource);
		return jdbcTemplateConn;
	}

	public void updateDownladRequest(NotificationDownloadRequest reqObject, JdbcTemplate jdbcTemplate,
			String downloadreqId) {

		log.info("updateDownladRequest Method Started ");

		log.info(String.format("paramNotification in updateDownladRequest for download Req Id : %s", downloadreqId));

		if (reqObject.isIsSuccessful()) {
			Object[] paramNotification = new Object[] { reqObject.getFileName(), reqObject.getUrl(),
					reqObject.getDocumentId(), downloadreqId };
			
			String sql = "update dp_download_request_items set status ='SUCCESS', file_name = ?, url = ? where document_id =? and download_request_id =?";
			jdbcTemplate.update(sql, paramNotification);
			log.info(String.format("sql for updateDownladRequest Method : %s", sql));

		} else if (!reqObject.isIsSuccessful()) {
			Object[] paramNotification = new Object[] { reqObject.getFileName(),reqObject.getErrorMessage(), reqObject.getDocumentId(), downloadreqId };
			String sql = "update dp_download_request_items set status ='FAILED', file_name = ?,reason_for_failure = ? where document_id =? and download_request_id =?";
			jdbcTemplate.update(sql, paramNotification);
			log.error(String.format("Failed from E-File where Document Id is %s and Error Message is %s",
					reqObject.getDocumentId(), reqObject.getErrorMessage()));
		} else {

			log.error(String.format("Invalid Input for Document Id : %s for is Successfull Value : %s ",
					reqObject.getDocumentId(), reqObject.isIsSuccessful()));
		}
		log.info("updateDownladRequest Method Ended ");
	}

	public int deleteFilesfromContainer(String packagid, String documentid, String container) {
		log.info(String.format("deleteFilesfromContainer Started with package id  :: %s", packagid));
		List<String> lst = new ArrayList<>();
		lst.add(packagid + "/" + documentid);

		if (!lst.isEmpty()) {
			log.info(String.format(
					"deleteFilesfromContainer Method list is not empty- proceeding to Move file Method :: %s", lst));
			delFile(lst, container);
		}
		return lst.size();
	}

	public boolean delFile(List<String> fileNames, String sourceContainerName) {
		log.info(String.format("delFile Method started :: %s", fileNames));
		BlobServiceClientBuilder b = new BlobServiceClientBuilder()
				.connectionString(System.getenv("CONNECTION_STRING"));
		BlobContainerClient sourceContainerClient = b.buildClient().getBlobContainerClient(sourceContainerName);
		if (!sourceContainerClient.exists()) {
			return false;
		}

		for (String fileName : fileNames) {
			log.info(String.format("fileName :: %s", fileName));
			deleteBlob(fileName, sourceContainerClient);
		}
		log.info(String.format("delFile Method ended :: %s", fileNames));
		return true;
	}

	public void deleteBlob(String blobName, BlobContainerClient containerClient) {
		log.info(String.format("deleteBlob method started %s", blobName));
		BlobClient blobClient = containerClient.getBlobClient(blobName);
		blobClient.delete();
		log.info(String.format("deleteBlob method ended %s", blobName));
	}

	public Connection connectionjdbc() throws SQLException {
		log.info("inside Connectionjdbc ");
		return DriverManager.getConnection(System.getenv("SQL_DATASOURCE_URL"), System.getenv("SQL_DATASOURCE_USERNAME"),
				System.getenv("SQL_DATASOURCE_PASSWORD"));
	}

	public void postAuditEntries(JdbcTemplate jdbcTemplate) {
		log.info("postAuditEntries method started ");
		AuditMaster audit = new AuditMaster();
		try {

			audit.setUserOID("Function App");
			OffsetDateTime offsetdatetime = OffsetDateTime.now();
			audit.setAuditEventTimestamp(offsetdatetime);
			audit.setAuditEventName("caseDownloadNotification");
			audit.setCreatedBy("Notification Function App");
			audit.setCreatedOn(offsetdatetime);
			
			jdbcTemplate.update(DP_AUDIT_EVENT_INSERT, audit.getUserOID(), audit.getAuditEventTimestamp(),
					audit.getAuditEventName(), audit.getPrimaryAuditEntity(), audit.getPrimaryAuditEntityIdentifier(),
					audit.getPreAuditSnapshot(), audit.getPostAuditSnapshot(), audit.getCreatedOn(),
					audit.getCreatedBy());

			log.info("postAuditEntries method ended ");

		} catch (Exception e) {
			log.error(String.format("Error while updating data or Records not found in Notification table %s",
					e.getMessage()));

		}

	}
}
