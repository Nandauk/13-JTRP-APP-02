package com.ombudsman.service.respondent;

import java.util.List;

public class DocumentsListReq {
	private List<NotificationDownloadRequest> Documents;

	private String instanceId;
	private String requestId;
	private String notificationId;
	
	public String getInstanceId() {
		return instanceId;
	}

	public String getRequestId() {
		return requestId;
	}

	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}

	public void setInstanceId(String instanceId) {
		this.instanceId = instanceId;
	}

	public List<NotificationDownloadRequest> getDocuments() {
		return Documents;
	}
	public void setDocuments(List<NotificationDownloadRequest> documents) {
		Documents = documents;
	}
	public String getNotificationId() {
		return notificationId;
	}

	public void setNotificationId(String notificationId) {
		this.notificationId = notificationId;
	}

}
