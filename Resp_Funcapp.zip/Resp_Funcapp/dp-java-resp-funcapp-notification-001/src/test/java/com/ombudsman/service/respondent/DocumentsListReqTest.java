package com.ombudsman.service.respondent;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.test.context.junit.jupiter.SpringExtension;

@ExtendWith(SpringExtension.class)
public class DocumentsListReqTest {
	
	@InjectMocks
	private DocumentsListReq mMockDocumentsListReq;
	
	@Mock
	private NotificationDownloadRequest mockNotificationDownloadRequest;
	
	@Test
	public void testGettersAndSetters() {
		
		List<NotificationDownloadRequest> notifDownloadReq = new ArrayList<>();
		notifDownloadReq.add(mockNotificationDownloadRequest);
		
		//Set values
		mMockDocumentsListReq.setDocuments(notifDownloadReq);
		mMockDocumentsListReq.setInstanceId("1234");
		mMockDocumentsListReq.setNotificationId("notfid");
		mMockDocumentsListReq.setRequestId("reqid");
		
		//Get values and assert it
		assertEquals("1234",mMockDocumentsListReq.getInstanceId());
		assertEquals(notifDownloadReq , mMockDocumentsListReq.getDocuments());
		assertEquals("notfid",mMockDocumentsListReq.getNotificationId());
		assertEquals("reqid",mMockDocumentsListReq.getRequestId());
		
	}
	
	

}
