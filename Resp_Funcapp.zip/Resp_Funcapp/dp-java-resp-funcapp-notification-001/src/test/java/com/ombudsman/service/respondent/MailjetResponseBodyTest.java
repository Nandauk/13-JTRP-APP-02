package com.ombudsman.service.respondent;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import com.fasterxml.jackson.databind.ObjectMapper;

@ExtendWith(MockitoExtension.class)
public class MailjetResponseBodyTest {

    private ObjectMapper objectMapper;

    @BeforeEach
    public void setUp() {
        objectMapper = new ObjectMapper();
    }

    @Test
    public void testMailjetResponseBodySerialization() throws Exception {
        MailjetResponseBody mailjetResponseBody = new MailjetResponseBody();
        MailjetResponseBody.Message message = new MailjetResponseBody.Message();
        message.setStatus("success");
        message.setCustomID("12345");
        
        List<MailjetResponseBody.Recipient> toRecipients = new ArrayList<>();
        MailjetResponseBody.Recipient recipient = new MailjetResponseBody.Recipient();
        recipient.setEmail("example@example.com");
        toRecipients.add(recipient);

        message.setTo(toRecipients);
        
        List<MailjetResponseBody.Message> messages = new ArrayList<>();
        messages.add(message);

        mailjetResponseBody.setMessages(messages);

        String json = objectMapper.writeValueAsString(mailjetResponseBody);
        assertNotNull(json);
        assertTrue(json.contains("Messages"));
        assertTrue(json.contains("Status"));
    }

    @Test
    public void testMailjetResponseBodyDeserialization() throws Exception {
        String json = "{ \"Messages\": [{ \"Status\": \"success\", \"CustomID\": \"12345\", \"To\": [{ \"Email\": \"example@example.com\" }] }] }";

        MailjetResponseBody mailjetResponseBody = objectMapper.readValue(json, MailjetResponseBody.class);
        assertNotNull(mailjetResponseBody);
        assertNotNull(mailjetResponseBody.getMessages());
        assertEquals(1, mailjetResponseBody.getMessages().size());
        assertEquals("success", mailjetResponseBody.getMessages().get(0).getStatus());
        assertEquals("12345", mailjetResponseBody.getMessages().get(0).getCustomID());
        assertEquals("example@example.com", mailjetResponseBody.getMessages().get(0).getTo().get(0).getEmail());
    }

    @Test
    public void testMailjetResponseBodyGettersSetters() {
        MailjetResponseBody mailjetResponseBody = new MailjetResponseBody();
        List<MailjetResponseBody.Message> messages = new ArrayList<>();
        mailjetResponseBody.setMessages(messages);
        assertEquals(messages, mailjetResponseBody.getMessages());

        MailjetResponseBody.Message message = new MailjetResponseBody.Message();
        String status = "sent";
        String customID = "abc123";
        List<MailjetResponseBody.Recipient> to = new ArrayList<>();
        List<MailjetResponseBody.Recipient> cc = new ArrayList<>();
        List<MailjetResponseBody.Recipient> bcc = new ArrayList<>();
        message.setStatus(status);
        message.setCustomID(customID);
        message.setTo(to);
        message.setCc(cc);
        message.setBcc(bcc);

        assertEquals(status, message.getStatus());
        assertEquals(customID, message.getCustomID());
        assertEquals(to, message.getTo());
        assertEquals(cc, message.getCc());
        assertEquals(bcc, message.getBcc());

        MailjetResponseBody.Recipient recipient = new MailjetResponseBody.Recipient();
        String email = "test@example.com";
        String messageUUID = "uuid123";
        long messageID = 123;
        String messageHref = "href123";
        recipient.setEmail(email);
        recipient.setMessageUUID(messageUUID);
        recipient.setMessageID(messageID);
        recipient.setMessageHref(messageHref);

        assertEquals(email, recipient.getEmail());
        assertEquals(messageUUID, recipient.getMessageUUID());
        assertEquals(messageID, recipient.getMessageID());
        assertEquals(messageHref, recipient.getMessageHref());
    }

    @Test
    public void testMailjetResponseBodyToString() {
        MailjetResponseBody mailjetResponseBody = new MailjetResponseBody();
        List<MailjetResponseBody.Message> messages = new ArrayList<>();
        MailjetResponseBody.Message message = new MailjetResponseBody.Message();
        message.setStatus("sent");
        message.setCustomID("abc123");
        messages.add(message);
        mailjetResponseBody.setMessages(messages);

        String expectedString = "Message :[Status: sent,CustomID: abc123,TO : null ,Cc : null ,Bcc : null]";
        assertEquals(expectedString, mailjetResponseBody.toString());
    }
}
