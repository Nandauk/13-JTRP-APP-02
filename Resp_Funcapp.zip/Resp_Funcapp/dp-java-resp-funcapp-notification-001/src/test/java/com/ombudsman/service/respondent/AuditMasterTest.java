package com.ombudsman.service.respondent;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.time.OffsetDateTime;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.springframework.test.context.junit.jupiter.SpringExtension;

@ExtendWith(SpringExtension.class)
public class AuditMasterTest {
	
	@InjectMocks
	AuditMaster mMockAuditMaster;
	OffsetDateTime now = OffsetDateTime.now();
	
	@Test
	public void testGetterAndSetter() {
		
		mMockAuditMaster.setAuditEventName("AEN");
		mMockAuditMaster.setAuditEventTimestamp(now);
		mMockAuditMaster.setAuditRecordID(12);
		mMockAuditMaster.setCreatedBy("creby");
		mMockAuditMaster.setCreatedOn(now);
		mMockAuditMaster.setModifiedBy("modby");
		mMockAuditMaster.setModifiedOn(now);
		mMockAuditMaster.setPostAuditSnapshot("pass");
		mMockAuditMaster.setPreAuditSnapshot("AUD1");
		mMockAuditMaster.setPrimaryAuditEntity("audent");
		mMockAuditMaster.setPrimaryAuditEntityIdentifier("test1");
		mMockAuditMaster.setUserOID("oid");
		
		assertEquals("AEN",mMockAuditMaster.getAuditEventName());
		assertEquals(now,mMockAuditMaster.getAuditEventTimestamp());
		assertEquals(12,mMockAuditMaster.getAuditRecordID());
		assertEquals("creby",mMockAuditMaster.getCreatedBy());
		assertEquals(now,mMockAuditMaster.getCreatedOn());
		assertEquals("modby",mMockAuditMaster.getModifiedBy());
		assertEquals(now,mMockAuditMaster.getModifiedOn());
		assertEquals("pass",mMockAuditMaster.getPostAuditSnapshot());
		assertEquals("AUD1",mMockAuditMaster.getPreAuditSnapshot());
		assertEquals("audent",mMockAuditMaster.getPrimaryAuditEntity());
		assertEquals("test1",mMockAuditMaster.getPrimaryAuditEntityIdentifier());
		assertEquals("oid",mMockAuditMaster.getUserOID());
	}

}
