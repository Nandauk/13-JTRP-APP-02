package com.ombudsman.service.respondent.exception;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.test.context.junit.jupiter.SpringExtension;

@ExtendWith(SpringExtension.class)
class RespondentsServiceExceptionsTest {
	
	
	 @Test
	    void testConstructor() {
	        String message = "Test exception";
	        String code = "123";
	        String exceptionMessage = "Test exception message";
	        StackTraceElement[] stackTraceElements = new StackTraceElement[0];

	        RespondentsServiceExceptions exception = new RespondentsServiceExceptions(message, code, exceptionMessage, stackTraceElements);

	        assertEquals(message, exception.getMessage());
	        assertEquals(code, exception.getCode());
	        assertEquals(exceptionMessage, exception.getExceptionMessage());
	        assertEquals(stackTraceElements,exception.getStackTraceMessage());
	    }

}
