package com.ombudsman.service.respondent;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.time.OffsetDateTime;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.springframework.test.context.junit.jupiter.SpringExtension;

@ExtendWith(SpringExtension.class)
public class UploadRequestsTest {
	
	@InjectMocks
	Uploadrequests mMockUploadrequests;
	OffsetDateTime now = OffsetDateTime.now();
	
	@Test
	public void testGetterAndSetter() {
		mMockUploadrequests.setCaseid("caseid");
		mMockUploadrequests.setComments("comment123");
		mMockUploadrequests.setCreated(now);
		mMockUploadrequests.setId(12);
		mMockUploadrequests.setPackageid("pkgid");
		mMockUploadrequests.setPnx("pnx");
		mMockUploadrequests.setStatus("status123");
		mMockUploadrequests.setUserid("user123");
		
		assertEquals("caseid",mMockUploadrequests.getCaseid());
		assertEquals("comment123",mMockUploadrequests.getComments());
		assertEquals(now,mMockUploadrequests.getCreated());
		assertEquals(12,mMockUploadrequests.getId());
		assertEquals("pkgid",mMockUploadrequests.getPackageid());
		assertEquals("pnx",mMockUploadrequests.getPnx());
		assertEquals("status123",mMockUploadrequests.getStatus());
		assertEquals("user123",mMockUploadrequests.getUserid());
		
	}

}
