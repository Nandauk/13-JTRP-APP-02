package com.ombudsman.service.respondent;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.springframework.test.context.junit.jupiter.SpringExtension;

@ExtendWith(SpringExtension.class)
public class FromTest {
	
	@InjectMocks
	From mMockFrom;
	
	@Test
	public void testGetterAndSetter() {
		
		mMockFrom.setEmail("email@xyz.com");
		mMockFrom.setName("Name");
		
		assertEquals("email@xyz.com",mMockFrom.getEmail());
		assertEquals("Name",mMockFrom.getName());
		
	}

}
