package com.ombudsman.service.respondent;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.springframework.test.context.junit.jupiter.SpringExtension;

@ExtendWith(SpringExtension.class)
public class NotificationTest {
	
	@InjectMocks
	Notification mMockNotification;
	
	@Test
	public void testGetterAndSetter() {
		
		mMockNotification.setCreatedBy("CretBy");
		mMockNotification.setFileDownloadUrl("URL");
		mMockNotification.setMessage("Msg1");
		mMockNotification.setModifiedBy("MdfBy");
		mMockNotification.setModifiedOn("modon");
		mMockNotification.setNotificationId(1L);
		mMockNotification.setNotificationStatusDescription("notdesc");
		mMockNotification.setNotificationStatusId("sts123");
		mMockNotification.setRequestId("req123");
		mMockNotification.setRequestingActivityName("RAN123");
		mMockNotification.setUserOid("UserOID");
		
		assertEquals("CretBy",mMockNotification.getCreatedBy());
		assertEquals("URL",mMockNotification.getFileDownloadUrl());
		assertEquals("Msg1",mMockNotification.getMessage());
		assertEquals("MdfBy",mMockNotification.getModifiedBy());
		assertEquals("modon",mMockNotification.getModifiedOn());
		assertEquals(1L,mMockNotification.getNotificationId());
		assertEquals("notdesc",mMockNotification.getNotificationStatusDescription());
		assertEquals("sts123",mMockNotification.getNotificationStatusId());
		assertEquals("req123",mMockNotification.getRequestId());
		assertEquals("RAN123",mMockNotification.getRequestingActivityName());
		assertEquals("UserOID",mMockNotification.getUserOid());
	}

}
