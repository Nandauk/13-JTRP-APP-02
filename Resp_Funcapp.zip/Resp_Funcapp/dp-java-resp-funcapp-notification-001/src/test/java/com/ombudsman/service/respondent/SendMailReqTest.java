package com.ombudsman.service.respondent;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.springframework.test.context.junit.jupiter.SpringExtension;

@ExtendWith(SpringExtension.class)
public class SendMailReqTest {
	
	@InjectMocks
	SendMailReq mMockSendMailReq;
	
	
	@Test
	public void testGetterAndSetter() {
		
		List<Messages> messageList = new ArrayList<>();
		messageList.add(new Messages());
		mMockSendMailReq.setMessages(messageList);
		assertEquals(messageList,mMockSendMailReq.getMessages());
			
	}
	

}
