//
//        package com.ombudsman.service.respondent.common;
//
//import static org.mockito.ArgumentMatchers.any;
//import static org.mockito.Mockito.*;
//
//import java.util.*;
//import java.util.stream.Collectors;
//
//import org.junit.jupiter.api.BeforeEach;
//import org.junit.jupiter.api.Test;
//import org.mockito.InjectMocks;
//import org.mockito.Mock;
//import org.mockito.MockitoAnnotations;
//import org.springframework.http.MediaType;
//import org.springframework.web.reactive.function.client.WebClient;
//import reactor.core.publisher.Flux;
//
//import com.microsoft.azure.functions.ExecutionContext;
//import com.ombudsman.service.repondent.model.EfileApiResponse;
//import com.ombudsman.service.respondent.DpSqlTableUpdate;
//import com.ombudsman.service.respondent.helper.CaseUpdateSqlHelper;
//
//public class DpSqlTableUpdateTest {
//
//    @Mock
//    private CaseUpdateSqlHelper caseUpdateSqlHelper;
//
//    @Mock
//    private WebClient webClientMock;
//
//    @Mock
//    private WebClient.RequestHeadersUriSpec requestHeadersUriSpecMock;
//
//    @Mock
//    private WebClient.RequestHeadersSpec requestHeadersSpecMock;
//
//    @Mock
//    private WebClient.ResponseSpec responseSpecMock;
//
//    @Mock
//    private ExecutionContext executionContextMock;
//
//    @InjectMocks
//    private DpSqlTableUpdate dpSqlTableUpdate;
//
//    @BeforeEach
//    public void setUp() {
//        MockitoAnnotations.openMocks(this);
//    }
//
//    @Test
//    public void testDpTable_Update() {
//        // Arrange
//        EfileApiResponse response1 = new EfileApiResponse();
//        response1.setForAttribute("complainant");
//        EfileApiResponse.ReasonForChangeMapping mapping1 = new EfileApiResponse.ReasonForChangeMapping();
//        mapping1.setReasonforchangecode("code1");
//        mapping1.setReasonforchangetext("text1");
//        mapping1.setCategorycode("category1");
//        mapping1.setSubjecttext("subject1");
//        response1.setReasonForChangeMapping(Collections.singletonList(mapping1));
//
//        EfileApiResponse response2 = new EfileApiResponse();
//        response2.setForAttribute("respondent");
//        EfileApiResponse.ReasonForChangeMapping mapping2 = new EfileApiResponse.ReasonForChangeMapping();
//        mapping2.setReasonforchangecode("code2");
//        mapping2.setReasonforchangetext("text2");
//        mapping2.setCategorycode("category2");
//        mapping2.setSubjecttext("subject2");
//        response2.setReasonForChangeMapping(Collections.singletonList(mapping2));
//
//        List<EfileApiResponse> responses = Arrays.asList(response1, response2);
//
//        when(webClientMock.get()).thenReturn(requestHeadersUriSpecMock);
//        when(requestHeadersUriSpecMock.uri(any(String.class))).thenReturn(requestHeadersSpecMock);
//        when(requestHeadersSpecMock.accept(MediaType.APPLICATION_JSON)).thenReturn(requestHeadersSpecMock);
//        when(requestHeadersSpecMock.retrieve()).thenReturn(responseSpecMock);
//        when(responseSpecMock.bodyToFlux(EfileApiResponse.class)).thenReturn(Flux.fromIterable(responses));
//        doNothing().when(caseUpdateSqlHelper).deleteAllRecords(); 
//        doNothing().when(caseUpdateSqlHelper).insertApiMappingInTable(anyMap(), anySet(), anyList());
//        // Act
//        dpSqlTableUpdate.dpTableUpdate(executionContextMock);
//
//        // Assert
//        verify(caseUpdateSqlHelper, times(1)).deleteAllRecords();
//        //verify(caseUpdateSqlHelper, times(1)).insertApiMappingInTable(anyMap(), anySet(), anyList());
//    }
//}
//
