package com.ombudsman.service.respondent.serviceimpl;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

import java.sql.SQLException;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.context.MessageSource;

import com.ombudsman.service.repondent.model.NotificationModel;
import com.ombudsman.service.repondent.model.RequestModel;
import com.ombudsman.service.repondent.model.UpdateCase;
import com.ombudsman.service.repondent.model.UpdateCase.NumberOfCases;
import com.ombudsman.service.respondent.common.WebClientData;
import com.ombudsman.service.respondent.exception.RecordCreationException;
import com.ombudsman.service.respondent.helper.CaseUpdateSqlHelper;
import static org.mockito.Mockito.*;


public class CaseActivityImplTest {

	@InjectMocks
    private CaseActivityImpl caseActivityImpl;

    @Mock
    private CaseUpdateSqlHelper caseUpdateSqlHelper;


    @Mock
    private WebClientData webClientData;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
        caseActivityImpl = new CaseActivityImpl();
        caseActivityImpl.caseUpdateSqlHelper = caseUpdateSqlHelper;
   
        caseActivityImpl.webClientData = webClientData;
    }

    @Test
    public void testActivity() throws SQLException {
    	NumberOfCases cases = new NumberOfCases();
    	cases.setCaseId("Case1");
    	cases.setComment("Comment1");
    	
    	List<NumberOfCases> numberOfCases = new ArrayList<>();
    	numberOfCases.add(cases);
    	
        UpdateCase dto = new UpdateCase();
        dto.setUserId("UserID");
        dto.setNumberOfCases(numberOfCases);
        
        String ticketNumber = "ticket-123";
        int index = 0;
        int reasonForChange = 123;

        RequestModel request = new RequestModel();
        String requestId = "request-123";

        when(caseUpdateSqlHelper.getRequestId(anyString())).thenReturn(requestId);

        String result = caseActivityImpl.activity(dto, ticketNumber, index, reasonForChange);

        assertNotNull(result);
        assertEquals(requestId, result);
    }

    @Test
    public void testRequestEntity() throws SQLException {
        
    	RequestModel request = new RequestModel();
    	
    	NumberOfCases cases = new NumberOfCases();
    	cases.setCaseId("Case1");
    	cases.setComment("Comment1");
    	
    	List<NumberOfCases> numberOfCases = new ArrayList<>();
    	numberOfCases.add(cases);
    	
        UpdateCase updateCase = new UpdateCase();
        updateCase.setUserId("UserID");
        updateCase.setNumberOfCases(numberOfCases);
        int index = 0;
        String userEventName = "User Event";

        String requestId = "request-123";

        when(caseUpdateSqlHelper.getRequestId(anyString())).thenReturn(requestId);

        String result = caseActivityImpl.RequestEntity(request, index, updateCase, userEventName);

        assertNotNull(result);
        assertEquals(requestId, result);
    }

    @Test
    public void testNotificationEntity() {
        RequestModel request = new RequestModel();
        request.setUserOid("OID12");
        request.setCreatedBy("Name");
        request.setCreatedOn(OffsetDateTime.parse("2021-09-30T15:30:00+01:00"));
        request.setModifiedBy("ModiefiedByName");
        request.setModifiedOn("");
        NotificationModel notifyModel = new NotificationModel();
        String id = "request-123";
        String ticketNumber = "ticket-123";
        int reasonForChange = 123;

        String notificationId = "notification-123";

        when(caseUpdateSqlHelper.saveRecordNotificationEntity(any(NotificationModel.class))).thenReturn(notificationId);

        String result = caseActivityImpl.notificationEntity(request, notifyModel, id, ticketNumber, reasonForChange);

        assertNotNull(result);
        assertEquals(notificationId, result);
    }
    
    @Test
    public void RequestBlockExceptio() throws SQLException {
    	
    	
    	NumberOfCases cases = new NumberOfCases();
    	cases.setCaseId("Case1");
    	cases.setComment("Comment1");
    	
    	List<NumberOfCases> numberOfCases = new ArrayList<>();
    	numberOfCases.add(cases);
    	
        UpdateCase updateCase = new UpdateCase();
        updateCase.setUserId("UserID");
        updateCase.setNumberOfCases(numberOfCases);
        int index = 0;
       

        String requestId = "request-123";

        String ticketNumber = "ticket-123";
       
        int reasonForChange = 123;
        
        when(caseUpdateSqlHelper.getRequestId(anyString())).thenReturn(requestId);

         doThrow(new RuntimeException("Test Exception")).when(caseUpdateSqlHelper).getRequestId(anyString());
       
        // When
        Exception exception = assertThrows(RecordCreationException.class, () -> {
        	caseActivityImpl.activity(updateCase, ticketNumber, index, reasonForChange);
        });

        // Then
        assertEquals("Request Creation Failed. Please Try Again. ", exception.getMessage());
         }
    
    
    @Test
    public void NotificationBlockException() throws SQLException {
    	
    	
    	NumberOfCases cases = new NumberOfCases();
    	cases.setCaseId("Case1");
    	cases.setComment("Comment1");
    	
    	List<NumberOfCases> numberOfCases = new ArrayList<>();
    	numberOfCases.add(cases);
    	
        UpdateCase updateCase = new UpdateCase();
        updateCase.setUserId("UserID");
        updateCase.setNumberOfCases(numberOfCases);
        int index = 0;
       

        String requestId = "request-123";

        String ticketNumber = "ticket-123";
       
        int reasonForChange = 123;
        
        when(caseUpdateSqlHelper.getRequestId(anyString())).thenReturn(requestId);
      
        
         doThrow(new RuntimeException("Test Exception")).when(caseUpdateSqlHelper).saveRecordNotificationEntity(any());
        
        // When
        Exception exception = assertThrows(RecordCreationException.class, () -> {
        	caseActivityImpl.activity(updateCase, ticketNumber, index, reasonForChange);
        });

        // Then
        assertEquals("Notification Creation Failed. Please Try Again.", exception.getMessage());
         }
    
    
//    @Test
//    public void ActivityBlockException() throws SQLException {
//    	
//    	
//    	NumberOfCases cases = new NumberOfCases();
//    	cases.setCaseId("Case1");
//    	cases.setComment("Comment1");
//    	
//    	List<NumberOfCases> numberOfCases = new ArrayList<>();
//    	numberOfCases.add(cases);
//    	
//        UpdateCase updateCase = new UpdateCase();
//        updateCase.setUserId("UserID");
//        updateCase.setNumberOfCases(numberOfCases);
//        int index = 0;
//       
//
//        String requestId = "request-123";
//
//        String ticketNumber = "ticket-123";
//       
//        String reasonForChange = "Update Reason";
//        
//         CaseActivityImpl caseActivity = new CaseActivityImpl();
//         CaseActivityImpl spyObj = spy(caseActivity);
//        
//        // doNothing().when(caseUpdateSqlHelper).saveRecordRequestEntity(any());
//         when(caseUpdateSqlHelper.getRequestId(anyString())).thenReturn(requestId);
//      
//        
//         doThrow(new RuntimeException("Test Exception")).when(spyObj).notificationEntity(any(), any(), anyString(), anyString(), any());
//        when(messageSource.getMessage(anyString(), any(), eq(Locale.ENGLISH))).thenReturn("Error message");
//
//        // When
//        Exception exception = assertThrows(RecordCreationException.class, () -> {
//        	caseActivityImpl.activity(updateCase, ticketNumber, index, reasonForChange);
//        });
//
//        // Then
//        assertEquals("Notification Creation Failed. Please Try Again.", exception.getMessage());
//         }
    
}
    
    
    



