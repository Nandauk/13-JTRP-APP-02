//package com.ombudsman.service.respondent.helper;
//
//import static org.junit.Assert.assertEquals;
//import static org.junit.Assert.assertThrows;
//import static org.mockito.ArgumentMatchers.any;
//import static org.mockito.ArgumentMatchers.anyString;
//import static org.mockito.ArgumentMatchers.eq;
//import static org.mockito.Mockito.doThrow;
//import static org.mockito.Mockito.mock;
//import static org.mockito.Mockito.mockStatic;
//import static org.mockito.Mockito.times;
//import static org.mockito.Mockito.verify;
//import static org.mockito.Mockito.when;
//
//import java.lang.reflect.InvocationTargetException;
//import java.lang.reflect.Method;
//import java.sql.Connection;
//import java.sql.PreparedStatement;
//import java.sql.ResultSet;
//import java.sql.SQLException;
//import java.sql.Timestamp;
//import java.time.OffsetDateTime;
//import java.util.ArrayList;
//import java.util.HashMap;
//import java.util.HashSet;
//import java.util.List;
//import java.util.Map;
//import java.util.Set;
//
//import javax.sql.DataSource;
//
//import org.junit.jupiter.api.AfterEach;
//import org.junit.jupiter.api.BeforeEach;
//import org.junit.jupiter.api.Test;
//import org.junit.jupiter.api.extension.ExtendWith;
//import org.mockito.InjectMocks;
//import org.mockito.Mock;
//import org.mockito.MockedStatic;
//import org.mockito.MockitoAnnotations;
//import org.mockito.junit.jupiter.MockitoExtension;
//import org.slf4j.Logger;
//import org.springframework.jdbc.core.JdbcTemplate;
//import org.springframework.jdbc.core.namedparam.SqlParameterSource;
//import org.springframework.jdbc.core.simple.SimpleJdbcCall;
//
//import com.ombudsman.service.repondent.model.EfileApiResponse.ReasonForChangeMapping;
//import com.ombudsman.service.repondent.model.NotificationModel;
//import com.ombudsman.service.repondent.model.RequestModel;
//import com.ombudsman.service.repondent.model.SubjectAndCatCode;
//import com.ombudsman.service.repondent.model.UpdateCaseDto;
//import com.ombudsman.service.respondent.common.DataSourceSingleton;
//import com.ombudsman.service.respondent.exception.RecordCreationException;
//import com.ombudsman.service.respondent.exception.SQLDataAccessException;
//import com.ombudsman.service.respondent.serviceimpl.IncidentInfoImpl;
//
//@ExtendWith(MockitoExtension.class)
//public class CaseUpdateSqlHelperTest {
//
//    
//	
//	@Mock
//    private DataSource mockDataSource;
//
//    @Mock
//    private Connection mockConnection;
//
//    @Mock
//    private PreparedStatement mockStatement;
//    
//    @Mock
//    private ResultSet mockResultSet;
//    
//    @Mock
//    private JdbcTemplate mockJdbcTemplate;
//
//    @Mock
//    private SimpleJdbcCall mockJdbcCall;
//
//    @Mock
//    private Logger mockLogger;
//
//    private MockedStatic<DataSourceSingleton> mockedStaticDataSourceSingleton;
//
//    @InjectMocks
//    private CaseUpdateSqlHelper databaseService;
//    
//    @BeforeEach
//    public void setUp() throws SQLException {
//        mockedStaticDataSourceSingleton = mockStatic(DataSourceSingleton.class);
//        mockedStaticDataSourceSingleton.when(DataSourceSingleton::getDataSource).thenReturn(mockDataSource);
//        when(mockDataSource.getConnection()).thenReturn(mockConnection);
//
//        
//    }
//
//    @AfterEach
//    public void tearDown() {
//        mockedStaticDataSourceSingleton.close();
//    }
//    
//    @Test
//    public void testSaveRecordUpdateCase() throws SQLException {
//        
//    	UpdateCaseDto mockUpdateCaseDto = mock(UpdateCaseDto.class);
//        OffsetDateTime createdOffsetDateTime = OffsetDateTime.now();
//        
//        when(mockConnection.prepareStatement(anyString())).thenReturn(mockStatement);
//        when(mockStatement.executeUpdate()).thenReturn(1);
//
//        // Define the expected behavior for the UpdateCaseDto methods
//        when(mockUpdateCaseDto.getCase_id()).thenReturn("123");
//        when(mockUpdateCaseDto.getComments()).thenReturn("Test Comment");
//        when(mockUpdateCaseDto.getDetails()).thenReturn("Test Details");
//        when(mockUpdateCaseDto.getReason_for_change()).thenReturn(1);
//        when(mockUpdateCaseDto.getUser_id()).thenReturn("user123");
//        when(mockUpdateCaseDto.getCreated()).thenReturn(createdOffsetDateTime);
//        when(mockUpdateCaseDto.getPackage_id()).thenReturn("pkg123");
//        when(mockUpdateCaseDto.getStatus()).thenReturn("Active");
//
//        // Call the method under test
//        databaseService.saveRecordUpdateCase(mockUpdateCaseDto);
//
//        // Verify the interactions and assertions
//        verify(mockConnection).prepareStatement(anyString());
//        verify(mockStatement).setString(1, "123");
//        verify(mockStatement).setString(2, "Test Comment");
//        verify(mockStatement).setString(3, "Test Details");
//        verify(mockStatement).setLong(4, 1L);
//        verify(mockStatement).setString(5, "user123");
//        verify(mockStatement).setTimestamp(eq(6), any(Timestamp.class));
//        verify(mockStatement).setString(7, "pkg123");
//        verify(mockStatement).setString(8, "Active");
//        verify(mockStatement).executeUpdate();
//
//    }
//    
//    @Test
//    public void testSaveRecordRequestEntity() throws SQLException {
//        RequestModel mockRequest = mock(RequestModel.class);
//        OffsetDateTime createdOffsetDateTime = OffsetDateTime.now();
//        // Set up mock behavior
//        when(mockConnection.prepareStatement(anyString())).thenReturn(mockStatement);
//        when(mockStatement.executeUpdate()).thenReturn(1);
//
//        // Define the expected behavior for the RequestModel methods
//        when(mockRequest.getUserOid()).thenReturn("user123");
//        when(mockRequest.getRequestingActivityName()).thenReturn("Test Activity");
//        when(mockRequest.getRequestStatusId()).thenReturn(1);
//        when(mockRequest.getRequestStatusDescription()).thenReturn("In Progress");
//        when(mockRequest.getRequestProcessingDetails()).thenReturn("Processing details...");
//        when(mockRequest.getRequestStartTime()).thenReturn(createdOffsetDateTime);
//        when(mockRequest.getRequestProcessingCounter()).thenReturn(3);
//        when(mockRequest.getCreatedBy()).thenReturn("creator123");
//        when(mockRequest.getCreatedOn()).thenReturn(createdOffsetDateTime);
//
//        // Call the method under test
//        databaseService.saveRecordRequestEntity(mockRequest);
//
//        // Verify the interactions and assertions
//        verify(mockDataSource).getConnection();
//        verify(mockConnection).prepareStatement(anyString());
//        verify(mockStatement).setString(1, "user123");
//        verify(mockStatement).setString(2, "Test Activity");
//        verify(mockStatement).setInt(3, 1);
//        verify(mockStatement).setString(4, "In Progress");
//        verify(mockStatement).setString(5, "Processing details...");
//        verify(mockStatement).setTimestamp(eq(6), any(Timestamp.class));
//        verify(mockStatement).setInt(7, 3);
//        verify(mockStatement).setString(8, "creator123");
//        verify(mockStatement).setTimestamp(eq(9), any(Timestamp.class));
//        verify(mockStatement).executeUpdate();
//
//        // Handle exception scenario
//        doThrow(new SQLException("SQL Error")).when(mockStatement).executeUpdate();
//        assertThrows(RecordCreationException.class, () -> databaseService.saveRecordRequestEntity(mockRequest));
//    }
//    
//    @Test
//    public void testSaveRecordNotificationEntity() throws SQLException, NoSuchMethodException, SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException {
//        NotificationModel mockRequest = mock(NotificationModel.class);
//
//        // Set up mock behavior
//        when(mockConnection.prepareStatement(anyString())).thenReturn(mockStatement);
//        when(mockStatement.executeUpdate()).thenReturn(1);
//
//        // Define the expected behavior for the NotificationModel methods
//        when(mockRequest.getRequest_id()).thenReturn("req123");
//        when(mockRequest.getUser_oid()).thenReturn("user456");
//        when(mockRequest.getRequesting_activity_name()).thenReturn("Test Activity");
//        when(mockRequest.getNotification_status_id()).thenReturn("1");
//        when(mockRequest.getNotification_status_description()).thenReturn("Pending");
//        when(mockRequest.getMessage()).thenReturn("Test Message");
//        when(mockRequest.getCreated_on()).thenReturn("2025-02-04T16:34:00Z");
//        when(mockRequest.getCreated_by()).thenReturn("creator123");
//        when(mockRequest.getModified_on()).thenReturn("2025-02-04T16:34:00Z");
//        when(mockRequest.getModified_by()).thenReturn("modifier123");
//
//        // Call the method under test
//        String result = databaseService.saveRecordNotificationEntity(mockRequest);
//
//        // Verify the interactions and assertions
//        //verify(mockDataSource).getConnection();
//        verify(mockConnection, times(2)).prepareStatement(anyString());  // Updated to verify twice for prepareStatement
//        verify(mockStatement, times(2)).setString(1, "req123");  // Updated to verify twice for setString
//        verify(mockStatement).executeUpdate();
//
//
//
//     // Mock the private getNotificationId method using reflection
//        Method getNotificationIdMethod = CaseUpdateSqlHelper.class.getDeclaredMethod("getNotificationId", String.class);
//        getNotificationIdMethod.setAccessible(true);
//        String notificationId = (String) getNotificationIdMethod.invoke(databaseService, "req123");
//
//        assertEquals("", notificationId);
//       
//        
//        // Handle exception scenario
//        doThrow(new SQLException("SQL Error")).when(mockStatement).executeUpdate();
//        assertThrows(RecordCreationException.class, () -> databaseService.saveRecordNotificationEntity(mockRequest));
//    }
//    
// //   @Test
////    public void testGetIncident() throws SQLException {
////        String incidentId = "inc123";
////        List<String> account = List.of("account1", "account2");
////
////        // Set up mock behavior
////        when(mockConnection.prepareStatement(anyString())).thenReturn(mockStatement);
////        when(mockStatement.executeQuery()).thenReturn(mockResultSet);
////        when(mockResultSet.next()).thenReturn(true).thenReturn(false);
////        when(mockResultSet.getString("incidentid")).thenReturn("inc123");
////        when(mockResultSet.getString("ticketnumber")).thenReturn("ticket789");
////
////        // Call the method under test
////        IncidentInfoImpl result = databaseService.getIncident(incidentId, account);
////
////        // Verify the interactions and assertions
////        verify(mockDataSource).getConnection();
////        verify(mockConnection).prepareStatement(anyString());
////        verify(mockStatement).setString(1, "inc123");
////        verify(mockStatement).setString(2, "account1, account2");
////        verify(mockStatement).executeQuery();
////       
////        verify(mockResultSet).getString("incidentid");
////        verify(mockResultSet).getString("ticketnumber");
////
////        assertEquals("inc123", result.getIncidentId());
////        assertEquals("ticket789", result.getTicketNumber());
////
////        // Handle exception scenario
////     //   doThrow(new SQLException("SQL Error")).when(mockStatement).executeQuery();
////      //  assertThrows(SQLDataAccessException.class, () -> databaseService.getIncident(incidentId, account));
////    }
//    
//
//    @Test
//    public void testGetOwnerId() throws SQLException {
//        String incidentId = "incident123";
//
//        // Set up mock behavior
//        when(mockConnection.prepareStatement(anyString())).thenReturn(mockStatement);
//        when(mockStatement.executeQuery()).thenReturn(mockResultSet);
//        when(mockResultSet.next()).thenReturn(true).thenReturn(false);
//        when(mockResultSet.getString("ownerid")).thenReturn("owner123");
//
//        // Call the method under test
//        String result = databaseService.getOwnerId(incidentId);
//
//        // Verify the interactions and assertions
//        verify(mockDataSource).getConnection();
//        verify(mockConnection).prepareStatement(anyString());
//        verify(mockStatement).setString(1, incidentId);
//        verify(mockStatement).executeQuery();
//        verify(mockResultSet, times(2)).next();
//        verify(mockResultSet).getString("ownerid");
//
//        assertEquals("owner123", result);
//    }
//    
////    @Test
////    public void testGetRequestId() throws SQLException {
////        String oid = "oid123";
////
////        // Set up mock behavior
////        when(mockConnection.prepareStatement(anyString())).thenReturn(mockStatement);
////        when(mockStatement.executeQuery()).thenReturn(mockResultSet);
////        when(mockResultSet.next()).thenReturn(true).thenReturn(false);
////        when(mockResultSet.getString("request_id")).thenReturn("request123");
////
////        // Call the method under test
////        String result = databaseService.getRequestId(oid);
////
////        // Verify the interactions and assertions
////        verify(mockDataSource).getConnection();
////        verify(mockConnection).prepareStatement(anyString());
////        verify(mockStatement).setString(1, "caseUpdate");
////        verify(mockStatement).setString(2, oid);
////        verify(mockStatement).executeQuery();
////        verify(mockResultSet, times(1)).next();
////        verify(mockResultSet).getString("request_id");
////
////        assertEquals("request123", result);
////    }
//    
//    @Test
//    public void testGetSubCategoryCode() throws SQLException {
//        int reasonForChange = 1;
//
//        // Set up mock behavior
//        when(mockConnection.prepareStatement(anyString())).thenReturn(mockStatement);
//        when(mockStatement.executeQuery()).thenReturn(mockResultSet);
//        when(mockResultSet.next()).thenReturn(true).thenReturn(false);
//        when(mockResultSet.getString("subject")).thenReturn("Test Subject");
//        when(mockResultSet.getInt("category_code")).thenReturn(123);
//
//        // Call the method under test
//        List<SubjectAndCatCode> result = databaseService.getSubCategoryCode(reasonForChange);
//
//        // Verify the interactions and assertions
//        verify(mockDataSource).getConnection();
//        verify(mockConnection).prepareStatement(anyString());
//        verify(mockStatement).setLong(1, reasonForChange);
//        verify(mockStatement).executeQuery();
//        verify(mockResultSet, times(2)).next();
//        verify(mockResultSet).getString("subject");
//        verify(mockResultSet).getInt("category_code");
//
//        assertEquals(1, result.size());
//        assertEquals("Test Subject", result.get(0).getSubject());
//        assertEquals(123, result.get(0).getCategoryCode());
//    }
//    
//    @Test
//    public void testGetOwnerDetails() throws SQLException {
//        String caseId = "case123";
//
//        // Set up mock behavior
//        when(mockConnection.prepareStatement(anyString())).thenReturn(mockStatement);
//        when(mockStatement.executeQuery()).thenReturn(mockResultSet);
//        when(mockResultSet.next()).thenReturn(true).thenReturn(false);
//        when(mockResultSet.getString("ownerid")).thenReturn("owner123");
//        when(mockResultSet.getString("owningteam")).thenReturn("team123");
//        when(mockResultSet.getString("owninguser")).thenReturn("user123");
//
//        // Call the method under test
//        Map<String, String> result = databaseService.getOwnerDetails(caseId);
//
//        // Verify the interactions and assertions
//        verify(mockDataSource).getConnection();
//        verify(mockConnection).prepareStatement(anyString());
//        verify(mockStatement).setString(1, caseId);
//        verify(mockStatement).executeQuery();
//        verify(mockResultSet, times(2)).next();
//        verify(mockResultSet).getString("ownerid");
//        verify(mockResultSet).getString("owningteam");
//        verify(mockResultSet).getString("owninguser");
//
//        assertEquals(3, result.size());
//        assertEquals("owner123", result.get("ownerId"));
//        assertEquals("team123", result.get("owningTeam"));
//        assertEquals("user123", result.get("owningUser"));
//    }
//    
//    @Test
//    public void testUpdateCaseTable() throws SQLException {
//        String caseID = "case123";
//        String status = "SUCCESS";
//
//        // Set up mock behavior
//        when(mockConnection.prepareStatement(anyString())).thenReturn(mockStatement);
//        when(mockStatement.executeUpdate()).thenReturn(1);
//
//        // Call the method under test
//        databaseService.updateCaseTable(caseID, status);
//
//        // Verify the interactions and assertions
//        verify(mockDataSource).getConnection();
//        verify(mockConnection).prepareStatement(anyString());
//        verify(mockStatement).setString(1, status);
//        verify(mockStatement).setString(2, caseID);
//        verify(mockStatement).executeUpdate();
//
//    }
//    
//    @Test
//    public void testUpdateNotificationTable() throws SQLException {
//        String requestId = "request123";
//        String updatedStatus = "SUCCESS";
//        String updatedCode = "200";
//
//        // Set up mock behavior
//        when(mockConnection.prepareStatement(anyString())).thenReturn(mockStatement);
//        when(mockStatement.executeUpdate()).thenReturn(1);
//
//        // Call the method under test
//        databaseService.updateNotificationTable(requestId, updatedStatus, updatedCode);
//
//        // Verify the interactions and assertions
//        verify(mockDataSource).getConnection();
//        verify(mockConnection).prepareStatement(anyString());
//        verify(mockStatement).setString(1, updatedStatus);
//        verify(mockStatement).setString(2, updatedCode);
//        verify(mockStatement).setString(3, requestId);
//        verify(mockStatement).setString(4, "Pending");
//        verify(mockStatement).executeUpdate();
//
//    }       
//
//    
//    @Test
//    public void testDeleteAllRecords() throws SQLException {
//        // Set up mock behavior
//        when(mockConnection.prepareStatement(anyString())).thenReturn(mockStatement);
//
//        // Call the method under test
//        databaseService.deleteAllRecords();
//
//        // Verify the interactions and assertions
//        verify(mockDataSource).getConnection();
//        verify(mockConnection).prepareStatement(anyString());
//        verify(mockStatement).executeUpdate();
//
//    }
//    
//    @Test
//    public void testInsertApiMappingInTable() throws SQLException {
//        Map<String, ReasonForChangeMapping> reasonForChangeMap = new HashMap<>();
//        Set<String> commonKeys = new HashSet<>();
//        List<ReasonForChangeMapping> respondentMappings = List.of(new ReasonForChangeMapping());
//
//        // Mock a ReasonForChangeMapping object
//        ReasonForChangeMapping mockMapping = mock(ReasonForChangeMapping.class);
//        when(mockMapping.getReasonforchangecode()).thenReturn("code123");
//        when(mockMapping.getReasonforchangetext()).thenReturn("text123");
//        when(mockMapping.getSubjecttext()).thenReturn("subject123");
//        when(mockMapping.getCategorycode()).thenReturn("category123");
//
//        // Add mock data to the map
//        reasonForChangeMap.put("key123", mockMapping);
//        commonKeys.add("key123");
//
//        // Set up mock behavior
//        when(mockConnection.prepareStatement(anyString())).thenReturn(mockStatement);
//
//        // Call the method under test
//        databaseService.insertApiMappingInTable(reasonForChangeMap, commonKeys, respondentMappings);
//
//        // Verify the interactions and assertions
//        verify(mockDataSource).getConnection();
//        verify(mockConnection).prepareStatement(anyString());
//        verify(mockStatement).setString(1, "code123");
//        verify(mockStatement).setString(2, "text123");
//        verify(mockStatement).setString(3, "subject123");
//        verify(mockStatement).setString(4, "category123");
//        verify(mockStatement).setString(5, "RespAndComp");
//        verify(mockStatement).setTimestamp(eq(6), any(Timestamp.class));
//        verify(mockStatement).addBatch();
//        verify(mockStatement).executeBatch();
//
//        
//    }
//    
//    @Test
//    public void testInsertApiMappingInTable_Exception() throws Exception {
//        // Given
//        Map<String, ReasonForChangeMapping> reasonForChangeMap = new HashMap<>();
//        Set<String> commonKeys = new HashSet<>();
//        List<ReasonForChangeMapping> respondentMappings = new ArrayList<>();
//
//         when(mockConnection.prepareStatement(anyString())).thenReturn(mockStatement);
//         doThrow(SQLException.class).when(mockStatement).executeBatch();
//         
//        
//         assertThrows(SQLDataAccessException.class, () -> {
//        	 databaseService.insertApiMappingInTable(reasonForChangeMap, commonKeys, respondentMappings);
//         });
//
//       
//    }
//
//
//}