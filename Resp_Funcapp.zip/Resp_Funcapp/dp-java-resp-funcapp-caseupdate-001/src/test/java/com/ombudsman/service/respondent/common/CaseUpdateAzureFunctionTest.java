//package com.ombudsman.service.respondent.common;
//
//import static org.junit.jupiter.api.Assertions.assertThrows;
//import static org.mockito.ArgumentMatchers.any;
//import static org.mockito.ArgumentMatchers.anyInt;
//import static org.mockito.ArgumentMatchers.anyList;
//import static org.mockito.ArgumentMatchers.anyString;
//import static org.mockito.Mockito.doNothing;
//import static org.mockito.Mockito.mockStatic;
//import static org.mockito.Mockito.times;
//import static org.mockito.Mockito.verify;
//import static org.mockito.Mockito.when;
//
//import java.io.IOException;
//import java.sql.SQLException;
//import java.text.ParseException;
//import java.util.ArrayList;
//import java.util.Arrays;
//import java.util.HashMap;
//import java.util.List;
//import java.util.Map;
//import java.util.concurrent.ExecutionException;
//
//import org.json.JSONException;
//import org.junit.jupiter.api.BeforeEach;
//import org.junit.jupiter.api.Test;
//import org.mockito.InjectMocks;
//import org.mockito.Mock;
//import org.mockito.MockedStatic;
//import org.mockito.MockitoAnnotations;
//
//import com.fasterxml.jackson.databind.ObjectMapper;
//import com.microsoft.azure.functions.ExecutionContext;
//import com.ombudsman.service.repondent.model.SendMailReq;
//import com.ombudsman.service.repondent.model.SubjectAndCatCode;
//import com.ombudsman.service.repondent.model.UpdateCase;
//import com.ombudsman.service.repondent.model.UpdateCase.NumberOfCases;
//import com.ombudsman.service.respondent.CaseUpdateAzureFunction;
//import com.ombudsman.service.respondent.exception.AzureServiceException;
//import com.ombudsman.service.respondent.exception.InputValidationException;
//import com.ombudsman.service.respondent.exception.MailJetServiceException;
//import com.ombudsman.service.respondent.helper.CaseUpdateSqlHelper;
//import com.ombudsman.service.respondent.helper.RequestBodyHelper;
//import com.ombudsman.service.respondent.serviceimpl.CaseActivityImpl;
//import com.ombudsman.service.respondent.serviceimpl.IncidentInfoImpl;
//import com.ombudsman.service.respondent.serviceimpl.PhoenixProcessorImpl;
//import com.ombudsman.service.respondent.serviceimpl.SendEmailService;
//
//public class CaseUpdateAzureFunctionTest {
//
//	@InjectMocks
//    private CaseUpdateAzureFunction caseUpdateAzureFunction;
//
//    @Mock
//    private CaseUpdateSqlHelper caseUpdateSqlHelper;
//
//    @Mock
//    private CaseActivityImpl caseActivityImpl;
//
//    @Mock
//    private WebClientData webClientData;
//
//    @Mock
//    private PhoenixProcessorImpl phoenixProcessorImpl;
//
//    @Mock
//    private ExecutionContext executionContext ;
//    
//    private IncidentInfoImpl incidentinfo ;
// 
//    @Mock
//	RequestBodyHelper requestBodyHelper = new RequestBodyHelper();
//    @Mock
//	SendMailReq sendMailReq = new SendMailReq() ;
//	@Mock
//    SendEmailService sendEmailService;
//
//	 Map<String, Object> phnxUserDetails = new HashMap<>();
//	 
//    String Pack;
//    
////    @BeforeEach
////    public void setUp() {
////        MockitoAnnotations.openMocks(this);
////         incidentinfo = new IncidentInfoImpl(); 
////        incidentinfo.setIncidentId("Incident1"); 
////        incidentinfo.setTicketNumber("PHNX-123");
////         Pack = "12A";
////      
////       //  MockedStatic<System> mockedSystem = mockStatic(System.class);
////       //  mockedSystem.when(() -> System.getenv("templateId")).thenReturn("123");
////        
////      
////    }
//
////    @Test
////    public void testUpdateBulkCase() throws InterruptedException, ExecutionException, IOException, SQLException, InputValidationException, JSONException, ParseException, MailJetServiceException {
////        // Prepare mock data and behavior
////        UpdateCase updateCase = new UpdateCase();
////        
////        updateCase.setContactId("mockContactID");
////        updateCase.setDetails("mockDetails");
////        updateCase.setPackageId("mockPackageID");
////        updateCase.setReasonForChange(123);
////        updateCase.setUserId("mockUserOID");
////        updateCase.setTemplateId(12345);
////        updateCase.setTemplateName("templateName");
////        updateCase.setUsersAccountIds(new ArrayList<String>(Arrays.asList("acc1")));
////
////       
////        NumberOfCases numberOfCases = new NumberOfCases();
////        numberOfCases.setCaseId("testCaseId");
////        numberOfCases.setComment("Comment1");
////        updateCase.setNumberOfCases(List.of(numberOfCases));
////        
////        ObjectMapper objectMapper = new ObjectMapper();
////         String jsonReponse = objectMapper.writeValueAsString(updateCase);
////       
////        when(caseUpdateSqlHelper.getIncident(anyString(), anyList())).thenReturn(incidentinfo);
////        when(caseActivityImpl.activity(any(), anyString(), anyInt(), anyInt())).thenReturn(Pack); 
////        doNothing().when(caseUpdateSqlHelper).saveRecordUpdateCase(any());
////        phnxUserDetails.put("Incident","12");
////        when(caseUpdateSqlHelper.getContactId(any(), any())).thenReturn(phnxUserDetails);
////        
////        when(phoenixProcessorImpl.getToValue(anyString(),anyString(), anyString())).thenReturn("tovalueResult");
////
////       when(phoenixProcessorImpl.createRecordPhnx(anyString(),anyString())).thenReturn(204);
////       List<String> output = Arrays.asList("Name","Email");
////       
////        when(caseUpdateSqlHelper.getOwnerId(anyString())).thenReturn("ownerId");
////        when(caseUpdateSqlHelper.getOwnerDetails(anyString())).thenReturn(Map.of("ownerId", "ownerId", "owningTeam", "owningTeam", "owningUser", "owningUser"));
////        when(caseUpdateSqlHelper.getUserEmailName(anyString())).thenReturn(output);
////        when(caseUpdateSqlHelper.getReasonForChangeText(anyInt())).thenReturn("Reason for change text");
////        List<SubjectAndCatCode> result = new ArrayList<>();
////        SubjectAndCatCode s = new SubjectAndCatCode();
////        s.setCategoryCode(0);;
////        s.setSubject("Subject");
////        result.add(s);
////        
////		when(caseUpdateSqlHelper.getSubCategoryCode(123)).thenReturn(result);
////		
////       
////        // Execute the function
////     caseUpdateAzureFunction.updateBulkCase(jsonReponse, executionContext);
////     verify(phoenixProcessorImpl, times(1)).createRecordPhnx(anyString(),anyString());
////        
////    }
//     
//    @Test
//    public void testUpdateBulkCasenotSuccess() throws InterruptedException, ExecutionException, IOException, SQLException {
//        // Prepare mock data and behavior
//        UpdateCase updateCase = new UpdateCase();
//        
//        updateCase.setContactId("mockContactID");
//        updateCase.setDetails("mockDetails");
//        updateCase.setPackageId("mockPackageID");
//        updateCase.setReasonForChange(123);
//        updateCase.setUserId("mockUserOID");
//        updateCase.setTemplateId(12345);
//        updateCase.setTemplateName("templateName");
//        updateCase.setUsersAccountIds(new ArrayList<String>(Arrays.asList("acc1")));
//
//       
//        NumberOfCases numberOfCases = new NumberOfCases();
//        numberOfCases.setCaseId("testCaseId");
//        numberOfCases.setComment("Comment1");
//        updateCase.setNumberOfCases(List.of(numberOfCases));
//        
//        ObjectMapper objectMapper = new ObjectMapper();
//         String jsonReponse = objectMapper.writeValueAsString(updateCase);
//       
//        when(caseUpdateSqlHelper.getIncident(anyString(), anyList())).thenReturn(incidentinfo);
//        when(caseActivityImpl.activity(any(), anyString(), anyInt(), anyInt())).thenReturn(Pack); 
//        doNothing().when(caseUpdateSqlHelper).saveRecordUpdateCase(any());
//        phnxUserDetails.put("Incident","12");
//        when(caseUpdateSqlHelper.getContactId(any(), any())).thenReturn(phnxUserDetails);
//        
//        when(phoenixProcessorImpl.getToValue(anyString(),anyString(), anyString())).thenReturn("tovalueResult");
//
//       when(phoenixProcessorImpl.createRecordPhnx(anyString(),anyString())).thenReturn(201);
//
//        
//        when(caseUpdateSqlHelper.getOwnerId(anyString())).thenReturn("ownerId");
//        when(caseUpdateSqlHelper.getOwnerDetails(anyString())).thenReturn(Map.of("ownerId", "ownerId", "owningTeam", "owningTeam", "owningUser", "owningUser"));
//
//        List<SubjectAndCatCode> result = new ArrayList<>();
//        SubjectAndCatCode s = new SubjectAndCatCode();
//        s.setCategoryCode(0);;
//        s.setSubject("Subject");
//        result.add(s);
//        
//		when(caseUpdateSqlHelper.getSubCategoryCode(123)).thenReturn(result);
//		
//       
//        // Execute the function
//		 assertThrows(RuntimeException.class, () -> {
//		        caseUpdateAzureFunction.updateBulkCase(jsonReponse, executionContext);
//		    });     
//    }
//    
//
//}
