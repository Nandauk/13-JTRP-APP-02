package com.ombudsman.service.respondent.model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.ombudsman.service.repondent.model.EfileApiResponse;

public class EfileApiResponseTest {

    private EfileApiResponse efileApiResponse;

    @BeforeEach
    public void setUp() {
        efileApiResponse = new EfileApiResponse();
    }

    @Test
    public void testForAttribute() {
        String forAttribute = "testAttribute";
        efileApiResponse.setForAttribute(forAttribute);
        assertEquals(forAttribute, efileApiResponse.getForAttribute());
    }

    @Test
    public void testDocumentCodes() {
        EfileApiResponse.DocumentCode docCode = new EfileApiResponse.DocumentCode();
        docCode.setName("TestName");
        docCode.setCode("TestCode");
       String code =  docCode.getCode();
        String name = docCode.getName();
        assertEquals("TestName",name);
        assertEquals("TestCode",code);
        
        List<EfileApiResponse.DocumentCode> documentCodes = new ArrayList<>();
        documentCodes.add(docCode);
        
        efileApiResponse.setDocumentCodes(documentCodes);
        assertEquals(documentCodes, efileApiResponse.getDocumentCodes());
    }

    @Test
    public void testOriginatorCodes() {
        EfileApiResponse.OriginatorCode originatorCode = new EfileApiResponse.OriginatorCode();
        originatorCode.setName("OriginatorName");
        originatorCode.setCode("OriginatorCode");
        String code =  originatorCode.getCode();
        String name = originatorCode.getName();
        assertEquals("OriginatorName",name);
        assertEquals("OriginatorCode",code);
        List<EfileApiResponse.OriginatorCode> originatorCodes = new ArrayList<>();
        originatorCodes.add(originatorCode);
        
        efileApiResponse.setOriginatorCodes(originatorCodes);
        assertEquals(originatorCodes, efileApiResponse.getOriginatorCodes());
    }

    @Test
    public void testReasonForChangeCodes() {
        EfileApiResponse.ReasonForChangeCode reasonForChangeCode = new EfileApiResponse.ReasonForChangeCode();
        reasonForChangeCode.setName("ReasonName");
        reasonForChangeCode.setCode("ReasonCode");
        String code =  reasonForChangeCode.getCode();
        String name = reasonForChangeCode.getName();
        assertEquals("ReasonName",name);
        assertEquals("ReasonCode",code);
        
        List<EfileApiResponse.ReasonForChangeCode> reasonForChangeCodes = new ArrayList<>();
        reasonForChangeCodes.add(reasonForChangeCode);
        
        efileApiResponse.setReasonForChangeCodes(reasonForChangeCodes);
        assertEquals(reasonForChangeCodes, efileApiResponse.getReasonForChangeCodes());
    }

    @Test
    public void testReasonForChangeMapping() {
        EfileApiResponse.ReasonForChangeMapping reasonForChangeMapping = new EfileApiResponse.ReasonForChangeMapping();
        reasonForChangeMapping.setReasonforchangecode("ChangeCode");
        reasonForChangeMapping.setReasonforchangetext("ChangeText");
        reasonForChangeMapping.setCategorycode("CategoryCode");
        reasonForChangeMapping.setSubjecttext("SubjectText");
        
        reasonForChangeMapping.getCategorycode();
        reasonForChangeMapping.getReasonforchangecode();
        reasonForChangeMapping.getReasonforchangetext();
        reasonForChangeMapping.getSubjecttext();
        
        
        List<EfileApiResponse.ReasonForChangeMapping> reasonForChangeMappings = new ArrayList<>();
        reasonForChangeMappings.add(reasonForChangeMapping);
        
        efileApiResponse.setReasonForChangeMapping(reasonForChangeMappings);
        assertEquals(reasonForChangeMappings, efileApiResponse.getReasonForChangeMapping());
    }
}

