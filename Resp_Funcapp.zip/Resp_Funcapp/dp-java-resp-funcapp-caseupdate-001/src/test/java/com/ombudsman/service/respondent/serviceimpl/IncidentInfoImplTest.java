package com.ombudsman.service.respondent.serviceimpl;


import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.Test;

public class IncidentInfoImplTest {

//    @Test
//    public void testIncidentInfoImpl() {
//        //IncidentInfoImpl incidentInfo = new IncidentInfoImpl();
//
//        String incidentId = "incident-12345";
//        String ticketNumber = "ticket-12345";
//
//        incidentInfo.setIncidentId(incidentId);
//        incidentInfo.setTicketNumber(ticketNumber);
//
//        assertNotNull(incidentInfo);
//        assertEquals(incidentId, incidentInfo.getIncidentId());
//        assertEquals(ticketNumber, incidentInfo.getTicketNumber());
//    }
}


