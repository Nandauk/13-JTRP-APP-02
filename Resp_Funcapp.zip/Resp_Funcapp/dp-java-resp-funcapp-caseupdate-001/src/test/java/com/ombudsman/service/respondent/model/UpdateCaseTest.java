package com.ombudsman.service.respondent.model;

import java.util.List;

import com.nimbusds.jose.shaded.gson.annotations.SerializedName;
import com.ombudsman.service.repondent.model.IncidentInfo;
import com.ombudsman.service.repondent.model.UpdateCase;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.util.Arrays;
import java.util.List;

public class UpdateCaseTest {

    private UpdateCase updateCase;
    private UpdateCase.NumberOfCases numberOfCases;
    private IncidentInfo incidentInfo;

    @BeforeEach
    public void setUp() {
        updateCase = new UpdateCase();
        numberOfCases = new UpdateCase.NumberOfCases();
       
    }

    @Test
    public void testAll() {
        // Test numberOfCases
        numberOfCases.setComment("Test Comment");
        numberOfCases.setCaseId("Case123");
        List<UpdateCase.NumberOfCases> numberOfCasesList = Arrays.asList(numberOfCases);
        updateCase.setNumberOfCases(numberOfCasesList);
        assertEquals(numberOfCasesList, updateCase.getNumberOfCases());

        // Test details
        String details = "Test Details";
        updateCase.setDetails(details);
        assertEquals(details, updateCase.getDetails());

        // Test reasonForChange
        int reasonForChange = 1;
        updateCase.setReasonForChange(reasonForChange);
        assertEquals(reasonForChange, updateCase.getReasonForChange());

        // Test userId
        String userId = "User123";
        updateCase.setUserId(userId);
        assertEquals(userId, updateCase.getUserId());

        // Test usersAccountIds
        List<String> usersAccountIds = Arrays.asList("User1", "User2");
        updateCase.setUsersAccountIds(usersAccountIds);
        assertEquals(usersAccountIds, updateCase.getUsersAccountIds());

        // Test incidentInfo
        List<IncidentInfo> incidentInfoList = Arrays.asList(incidentInfo);
        updateCase.setIncidentInfo(incidentInfoList);
        assertEquals(incidentInfoList, updateCase.getIncidentInfo());

        // Test packageIdReq
        String packageIdReq = "Package123";
        updateCase.setPackageIdReq(packageIdReq);
        assertEquals(packageIdReq, updateCase.getPackageIdReq());

        // Test templateId
        int templateId = 123;
        updateCase.setTemplateId(templateId);
        assertEquals(templateId, updateCase.getTemplateId());

        // Test caaseIdList
        List<String> caaseIdList = Arrays.asList("Case1", "Case2");
        updateCase.setCaaseIdList(caaseIdList);
        assertEquals(caaseIdList, updateCase.getCaaseIdList());

        // Test digitalPortalUserName
        String digitalPortalUserName = "Digital User";
        updateCase.setDigitalPortalUserName(digitalPortalUserName);
        assertEquals(digitalPortalUserName, updateCase.getDigitalPortalUserName());

        // Test digitalPortalUserEmailAddress
        String digitalPortalUserEmailAddress = "digital@example.com";
        updateCase.setDigitalPortalUserEmailAddress(digitalPortalUserEmailAddress);
        assertEquals(digitalPortalUserEmailAddress, updateCase.getDigitalPortalUserEmailAddress());

        // Test packageId
        String packageId = "Package456";
        updateCase.setPackageId(packageId);
        assertEquals(packageId, updateCase.getPackageId());

        // Test contactId
        String contactId = "Contact123";
        updateCase.setContactId(contactId);
        assertEquals(contactId, updateCase.getContactId());

        // Test isRespondent
        String isRespondent = "Yes";
        updateCase.setIsRespondent(isRespondent);
        assertEquals(isRespondent, updateCase.getIsRespondent());
    }
}
