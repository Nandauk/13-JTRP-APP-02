package com.ombudsman.service.respondent.model;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.ombudsman.service.repondent.model.SubjectAndCatCode;

public class SubjectAndCatCodeTest {

    private SubjectAndCatCode subjectAndCatCode;

    @BeforeEach
    public void setUp() {
        subjectAndCatCode = new SubjectAndCatCode();
    }

    @Test
    public void testAll() {
        // Test subject
        String subject = "Test Subject";
        subjectAndCatCode.setSubject(subject);
        assertEquals(subject, subjectAndCatCode.getSubject());

        // Test reasonForChange
        int reasonForChange = 100;
        subjectAndCatCode.setCategoryCode(reasonForChange);
        assertEquals(reasonForChange, subjectAndCatCode.getCategoryCode());
    }
}
