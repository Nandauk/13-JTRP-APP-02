package com.ombudsman.service.respondent.model;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.ombudsman.service.repondent.model.NotificationResponse;

public class NotificationResponseTest {

    private NotificationResponse notificationResponse;

    @BeforeEach
    public void setUp() {
        notificationResponse = new NotificationResponse();
    }

    @Test
    public void testAll() {
        // Test result
        String result = "Success";
        notificationResponse.setResult(result);
        assertEquals(result, notificationResponse.getResult());

        // Test status
        String status = "Completed";
        notificationResponse.setStatus(status);
        assertEquals(status, notificationResponse.getStatus());

        // Test message
        String message = "Operation completed successfully";
        notificationResponse.setMessage(message);
        assertEquals(message, notificationResponse.getMessage());
    }
}
