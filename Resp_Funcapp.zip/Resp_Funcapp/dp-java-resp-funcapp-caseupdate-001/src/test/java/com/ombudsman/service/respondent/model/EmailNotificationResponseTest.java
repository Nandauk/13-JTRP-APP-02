package com.ombudsman.service.respondent.model;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.ombudsman.service.repondent.model.EmailNotificationResponse;

public class EmailNotificationResponseTest {

    private EmailNotificationResponse emailNotificationResponse;

    @BeforeEach
    public void setUp() {
        emailNotificationResponse = new EmailNotificationResponse();
    }

    @Test
    public void testAll() {
        // Test status
        String status = "Success";
        emailNotificationResponse.setStatus(status);
        assertEquals(status, emailNotificationResponse.getStatus());

        // Test message
        String message = "Email sent successfully";
        emailNotificationResponse.setMessage(message);
        assertEquals(message, emailNotificationResponse.getMessage());
    }
}

