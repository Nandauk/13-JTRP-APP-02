package com.ombudsman.service.respondent.model;

import com.ombudsman.service.repondent.model.From;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class FromTest {

    private From from;

    @BeforeEach
    public void setUp() {
        from = new From();
    }

    @Test
    public void testAll() {
        // Test fromEmail
        String email = "test@example.com";
        from.setFromEmail(email);
        assertEquals(email, from.getFromEmail());

        // Test fromName
        String name = "Test User";
        from.setFromName(name);
        assertEquals(name, from.getFromName());
    }
}
