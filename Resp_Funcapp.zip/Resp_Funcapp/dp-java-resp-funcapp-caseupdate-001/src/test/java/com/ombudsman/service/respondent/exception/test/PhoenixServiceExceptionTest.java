package com.ombudsman.service.respondent.exception.test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.Test;

import com.ombudsman.service.respondent.exception.PhoenixServiceException;

public class PhoenixServiceExceptionTest {

    @Test
    public void testPhoenixServiceException() {
        String message = "Phoenix service error";
        String exceptionMessage = "Detailed error message";

        PhoenixServiceException exception = new PhoenixServiceException(message, exceptionMessage);

        assertNotNull(exception);
        assertEquals(message, exception.getMessage());
        assertEquals("PHOENIX_ERROR", exception.getCode());
    }
}

