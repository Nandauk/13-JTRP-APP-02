package com.ombudsman.service.respondent.model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.ombudsman.service.repondent.model.EfileMessage;

public class EfileMessageTest {

    private EfileMessage efileMessage;

    @BeforeEach
    public void setUp() {
        efileMessage = new EfileMessage();
    }

    @Test
    public void testCaseId() {
        String caseId = "case123";
        efileMessage.setCaseId(caseId);
        assertEquals(caseId, efileMessage.getCaseId());
    }

    @Test
    public void testComments() {
        String comments = "These are comments.";
        efileMessage.setComments(comments);
        assertEquals(comments, efileMessage.getComments());
    }

    @Test
    public void testDetails() {
        String details = "Details of the case.";
        efileMessage.setDetails(details);
        assertEquals(details, efileMessage.getDetails());
    }

    @Test
    public void testReasonForChange() {
        int reasonForChange = 12345;
        efileMessage.setReasonForChange(reasonForChange);
        assertEquals(reasonForChange, efileMessage.getReasonForChange());
    }

    @Test
    public void testPackageId() {
        String packageId = "package456";
        efileMessage.setPackageId(packageId);
        assertEquals(packageId, efileMessage.getPackageId());
    }

    @Test
    public void testUsersAccountIds() {
        String[] usersAccountIds = {"user1", "user2"};
        efileMessage.setUsersAccountIds(usersAccountIds);
        assertEquals(usersAccountIds, efileMessage.getUsersAccountIds());
    }

    @Test
    public void testDigitalPortalUserName() {
        String digitalPortalUserName = "User Name";
        efileMessage.setDigitalPortalUserName(digitalPortalUserName);
        assertEquals(digitalPortalUserName, efileMessage.getDigitalPortalUserName());
    }

    @Test
    public void testDigitalPortalUserEmailAddress() {
        String digitalPortalUserEmailAddress = "user@example.com";
        efileMessage.setDigitalPortalUserEmailAddress(digitalPortalUserEmailAddress);
        assertEquals(digitalPortalUserEmailAddress, efileMessage.getDigitalPortalUserEmailAddress());
    }

    @Test
    public void testContactId() {
        String contactId = "contact123";
        efileMessage.setContactId(contactId);
        assertEquals(contactId, efileMessage.getContactId());
    }


}
