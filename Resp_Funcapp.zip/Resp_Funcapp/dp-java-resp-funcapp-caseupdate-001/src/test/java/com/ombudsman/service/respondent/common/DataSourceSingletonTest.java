package com.ombudsman.service.respondent.common;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.*;

import org.apache.commons.dbcp2.BasicDataSource;
import org.junit.jupiter.api.Test;
import org.mockito.MockedStatic;

public class DataSourceSingletonTest {

    @Test
    public void testGetDataSource() {
        try (MockedStatic<DataSourceSingleton> mockedStatic = mockStatic(DataSourceSingleton.class)) {
            BasicDataSource mockDataSource = mock(BasicDataSource.class);
            when(mockDataSource.getUrl()).thenReturn("mocksqlUrl");
            when(mockDataSource.getUsername()).thenReturn("mockUser");
            when(mockDataSource.getPassword()).thenReturn("mockPas");
            when(mockDataSource.getMinIdle()).thenReturn(5);
            when(mockDataSource.getMaxIdle()).thenReturn(10);
            when(mockDataSource.getMaxOpenPreparedStatements()).thenReturn(100);

            mockedStatic.when(DataSourceSingleton::getDataSource).thenReturn(mockDataSource);

            BasicDataSource dataSource = (BasicDataSource) DataSourceSingleton.getDataSource();

            assertNotNull(dataSource);
            assertEquals("mocksqlUrl", dataSource.getUrl());
            assertEquals("mockUser", dataSource.getUsername());
            assertEquals("mockPas", dataSource.getPassword());
            assertEquals(5, dataSource.getMinIdle());
            assertEquals(10, dataSource.getMaxIdle());
            assertEquals(100, dataSource.getMaxOpenPreparedStatements());
        }
    }
}
