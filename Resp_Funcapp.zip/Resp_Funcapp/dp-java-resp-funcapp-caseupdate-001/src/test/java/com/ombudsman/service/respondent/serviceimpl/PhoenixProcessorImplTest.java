package com.ombudsman.service.respondent.serviceimpl;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.when;

import java.io.IOException;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.context.MessageSource;

import com.google.gson.Gson;
import com.ombudsman.service.respondent.exception.PhoenixServiceException;

import okhttp3.Call;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Protocol;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.ResponseBody;

public class PhoenixProcessorImplTest {

    @InjectMocks
    private PhoenixProcessorImpl phoenixProcessorImpl;

    @Mock
    private MessageSource messageSource;

    @Mock
    private OkHttpClient mockClient;

    @Mock
    private Gson mockGson;

    private Response response;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
        phoenixProcessorImpl = new PhoenixProcessorImpl();
        response = new Response.Builder()
                .request(new Request.Builder().url("http://localhost").build())
                .protocol(Protocol.HTTP_1_1)
                .code(200)
                .message("OK")
                .body(ResponseBody.create("{\"key\":\"value\"}", MediaType.parse("application/json; charset=utf-8")))
                .build();
    }


//    @Test
//    public void testCreateRecordPhnx() throws IOException {
//        String accessToken = "dummyAccessToken";
//        String entity = "entity";
//        String jsonBody = "{\"key\":\"value\"}";
// 
//        Call mockCall = mock(Call.class); 
//       
//       when(mockClient.newCall(any(Request.class))).thenReturn(mockCall); 
//       when(mockCall.execute()).thenReturn(response);
//
//       int result = phoenixProcessorImpl.createRecordPhnx(accessToken, entity, jsonBody);
//
//        assertEquals(401, result);
//    }

    
//    @Test
//    public void testGetRecordFromQueue() throws IOException {
//        String accessToken = "dummyAccessToken";
//        String entity = "entity";
//        String jsonBody = "{\"key\":\"value\"}";
// 
//        Call mockCall = mock(Call.class); 
//       
//       when(mockClient.newCall(any(Request.class))).thenReturn(mockCall); 
//       when(mockCall.execute()).thenReturn(response);
//
//       String result = phoenixProcessorImpl.getRecordFromQueue(accessToken, entity, jsonBody);
//
//        assertEquals(401, result);
//    }
    
//    @Test
//    public void testGetToValue_User() {
//        String accessToken = "dummyAccessToken";
//        String ownerId = "owner-123";
//        String owningTeam = "";
//        String owningUser = "owningUser-123";
//
//        PhoenixProcessorImpl spyProcessor = spy(phoenixProcessorImpl);
//        doReturn("user-123").when(spyProcessor).getRecordFromSystemUser(anyString(), anyString(), anyString());
//
//        String result = spyProcessor.getToValue(accessToken, ownerId, owningTeam, owningUser);
//
//        assertEquals("/systemusers/user-123", result);
//    }

//    @Test
//    public void testGetToValue_Team() {
//        String accessToken = "dummyAccessToken";
//        String ownerId = "owner-123";
//        String owningTeam = "owningTeam-123";
//        String owningUser = "";
//
//        PhoenixProcessorImpl spyProcessor = spy(phoenixProcessorImpl);
//        doReturn("queue-123").when(spyProcessor).getRecordFromQueue(anyString(), anyString(), anyString());
//
//        String result = spyProcessor.getToValue(accessToken, ownerId, owningTeam, owningUser);
//
//        assertEquals("/queue/queue-123", result);
//    }

   
   
}
