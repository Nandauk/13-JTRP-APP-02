package com.ombudsman.service.respondent.exception.test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.Test;

import com.ombudsman.service.respondent.exception.MailJetServiceException;

public class MailJetServiceExceptionTest {

    @Test
    public void testMailJetServiceException() {
        String message = "MailJet service error";

        MailJetServiceException exception = new MailJetServiceException(message);

        assertNotNull(exception);
        assertEquals(message, exception.getMessage());
    }
}

