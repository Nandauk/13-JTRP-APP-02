package com.ombudsman.service.respondent.model;

import java.time.OffsetDateTime;


import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.time.OffsetDateTime;

import org.junit.jupiter.api.Test;

import com.ombudsman.service.repondent.model.UpdateCaseDto;

public class UpdateCaseDtoTest {

    @Test
    public void testUpdateCaseDto() {
        UpdateCaseDto updateCaseDto = new UpdateCaseDto();

        Integer id = 1;
        String caseId = "case123";
        String comments = "Some comments";
        String details = "Some details";
        int reasonForChange = 2;
        String userId = "user123";
        String packageId = "package123";
        OffsetDateTime created = OffsetDateTime.now();
        String status = "Pending";

        updateCaseDto.setId(id);
        updateCaseDto.setCase_id(caseId);
        updateCaseDto.setComments(comments);
        updateCaseDto.setDetails(details);
        updateCaseDto.setReason_for_change(reasonForChange);
        updateCaseDto.setUser_id(userId);
        updateCaseDto.setPackage_id(packageId);
        updateCaseDto.setCreated(created);
        updateCaseDto.setStatus(status);

        assertNotNull(updateCaseDto);
        assertEquals(id, updateCaseDto.getId());
        assertEquals(caseId, updateCaseDto.getCase_id());
        assertEquals(comments, updateCaseDto.getComments());
        assertEquals(details, updateCaseDto.getDetails());
        assertEquals(reasonForChange, updateCaseDto.getReason_for_change());
        assertEquals(userId, updateCaseDto.getUser_id());
        assertEquals(packageId, updateCaseDto.getPackage_id());
        assertEquals(created, updateCaseDto.getCreated());
        assertEquals(status, updateCaseDto.getStatus());
    }
}
