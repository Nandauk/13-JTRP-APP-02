package com.ombudsman.service.respondent.model;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.ombudsman.service.repondent.model.SystemUserData;

public class SystemUserDataTest {

    private SystemUserData systemUserData;

    @BeforeEach
    public void setUp() {
        systemUserData = new SystemUserData();
    }

    @Test
    public void testAll() {
        // Test systemuserid
        String systemuserid = "SYS123";
        systemUserData.setSystemuserid(systemuserid);
        assertEquals(systemuserid, systemUserData.getSystemuserid());

        // Test ownerid
        String ownerid = "OWN456";
        systemUserData.setOwnerid(ownerid);
        systemUserData.toString();
        assertEquals(ownerid, systemUserData.getOwnerid());
    }
}


