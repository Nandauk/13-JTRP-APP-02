package com.ombudsman.service.respondent.exception.test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.Test;

import com.ombudsman.service.respondent.exception.InputValidationException;

public class InputValidationExceptionTest {

    @Test
    public void testInputValidationException() {
        String message = "Input validation error";
        String exceptionMessage = "Detailed error message";
        StackTraceElement[] stackTrace = new StackTraceElement[] {
            new StackTraceElement("className", "methodName", "fileName", 123)
        };

        InputValidationException exception = new InputValidationException(message, "RESPONDENT_USER_1000", exceptionMessage, stackTrace);

        assertNotNull(exception);
        assertEquals(message, exception.getMessage());
        assertEquals("RESPONDENT_USER_1000", exception.getCode());
        assertEquals(exceptionMessage, exception.getExceptionMessage());
        //assertEquals(stackTrace, exception.getStackTrace());
    }
}
