package com.ombudsman.service.respondent.exception.test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.Test;

import com.ombudsman.service.respondent.exception.InvalidADOrganizationException;

public class InvalidADOrganizationExceptionTest {

    @Test
    public void testInvalidADOrganizationException() {
        String message = "Invalid AD Organization";
        String exceptionMessage = "Detailed error message";
        StackTraceElement[] stackTrace = new StackTraceElement[] {
            new StackTraceElement("className", "methodName", "fileName", 123)
        };

        InvalidADOrganizationException exception = new InvalidADOrganizationException(message, exceptionMessage, stackTrace);

        assertNotNull(exception);
        assertEquals(message, exception.getMessage());
        assertEquals("RESPONDENT_INVALID_AD_ORG_1000", exception.getCode());
        assertEquals(exceptionMessage, exception.getExceptionMessage());
       // assertEquals(stackTrace, exception.getStackTrace());
    }
}

