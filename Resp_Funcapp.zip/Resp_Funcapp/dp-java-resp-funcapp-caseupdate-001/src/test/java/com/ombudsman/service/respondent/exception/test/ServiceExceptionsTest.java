package com.ombudsman.service.respondent.exception.test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.Test;

import com.ombudsman.service.respondent.exception.ServiceExceptions;

public class ServiceExceptionsTest {

    @Test
    public void testServiceExceptions() {
        String message = "Service error";
        String code = "ERROR_CODE";

        ServiceExceptions exception = new ServiceExceptions(message, code);

        assertNotNull(exception);
        assertEquals(message, exception.getMessage());
        assertEquals(code, exception.getCode());
    }
}
