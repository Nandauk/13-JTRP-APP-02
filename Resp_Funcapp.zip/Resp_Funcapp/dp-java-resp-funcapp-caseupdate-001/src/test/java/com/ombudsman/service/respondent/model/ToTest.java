package com.ombudsman.service.respondent.model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.ombudsman.service.repondent.model.To;

public class ToTest {

    private To to;

    @BeforeEach
    public void setUp() {
        to = new To();
    }

    @Test
    public void testAll() {
        // Test toEmail
        String email = "test@example.com";
        to.setToEmail(email);
        assertEquals(email, to.getToEmail());

        // Test toName
        String name = "Test User";
        to.setToName(name);
        assertEquals(name, to.getToName());
    }
}
