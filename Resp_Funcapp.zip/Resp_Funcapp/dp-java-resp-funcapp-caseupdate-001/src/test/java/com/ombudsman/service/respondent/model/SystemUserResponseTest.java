package com.ombudsman.service.respondent.model;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.ombudsman.service.repondent.model.SystemUserData;
import com.ombudsman.service.repondent.model.SystemUserResponse;

import java.util.Arrays;


public class SystemUserResponseTest {

    private SystemUserResponse systemUserResponse;
    private SystemUserData systemUserData;

    @BeforeEach
    public void setUp() {
        systemUserResponse = new SystemUserResponse();
        systemUserData = new SystemUserData();
    }

    @Test
    public void testAll() {
        // Test SystemUserDataTest
    	systemUserData.setSystemuserid("SYS123");
    	systemUserData.setOwnerid("OWN456");

        List<SystemUserData> value = Arrays.asList(systemUserData);
        systemUserResponse.setValue(value);
        systemUserResponse.toString();
        assertEquals(value, systemUserResponse.getValue());
    }
}

