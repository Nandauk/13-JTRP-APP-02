package com.ombudsman.service.repondent.model;

import java.io.Serializable;

public interface IncidentInfo extends Serializable {

	public Integer getIncidentid();
	public String getTicketnumber();
	
	
}
