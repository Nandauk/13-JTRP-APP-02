package com.ombudsman.service.respondent.common;

import javax.sql.DataSource;

import org.apache.commons.dbcp2.BasicDataSource;

public class DataSourceSingleton {
    private static BasicDataSource dataSource;

    static {
        dataSource = new BasicDataSource();
        dataSource.setUrl(System.getenv("SQL-DATASOURCE-URL"));
        dataSource.setUsername(System.getenv("SQL-DATASOURCE-USERNAME"));
        dataSource.setPassword(System.getenv("SQL-DATASOURCE-PASSWORD"));
        dataSource.setMinIdle(5);
        dataSource.setMaxIdle(30);
        dataSource.setMaxOpenPreparedStatements(100);
    }
    

    public static DataSource getDataSource() {
        return dataSource;
    }
}
	