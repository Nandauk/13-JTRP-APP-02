package com.ombudsman.service.respondent.helper;

import java.io.UnsupportedEncodingException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONException;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.WebClient;

import com.google.gson.Gson;
import com.ombudsman.service.repondent.model.From;
import com.ombudsman.service.repondent.model.MailjetResponseBody;
import com.ombudsman.service.repondent.model.MailjetVariables;
import com.ombudsman.service.repondent.model.Messages;
import com.ombudsman.service.repondent.model.SendMailDetails;
import com.ombudsman.service.repondent.model.SendMailReq;
import com.ombudsman.service.repondent.model.To;
import com.ombudsman.service.respondent.exception.MailJetServiceException;

@Service
public class RequestBodyHelper {

	Logger LOG = LogManager.getRootLogger();
	private static final boolean TRUE = true;

	public SendMailReq contructSendEmailBody(SendMailDetails request) {

		List<To> to = new ArrayList<>();
		To toEmailAddress = new To();
		toEmailAddress.setToEmail(request.getEmail());
		toEmailAddress.setToName(request.getFullName());
		to.add(toEmailAddress);

		Messages message = new Messages();
		message.setTemplateID(request.getTemplateId());
		message.setName(request.getTemplateName());
		LOG.info("-----TemplateID and templateName set Inside helper method successfully----");
		message.setTemplateLanguage(TRUE);
		message.setTo(to);

		From fromEmailAddress = new From();
		fromEmailAddress.setFromEmail(System.getenv("MAILJET_FROM_EMAIL"));
		fromEmailAddress.setFromName(System.getenv("MAILJET_SERVER_NAME"));
		message.setFrom(fromEmailAddress);

		MailjetVariables var = new MailjetVariables();

		setIfNotEmpty(request.getTicketNumber(), var::setTicketNumber);
		setIfNotEmpty(request.getReasonForChange(), var::setReasonForChange);

		message.setVar(var);
		List<Messages> sendmessage = new ArrayList<>();
		sendmessage.add(message);
		SendMailReq sendMailReq = new SendMailReq();
		sendMailReq.setMessages(sendmessage);
		return sendMailReq;

	}

	public MailjetResponseBody send(SendMailReq req)
			throws UnsupportedEncodingException, JSONException, ParseException, MailJetServiceException {

		LOG.info("Mailjet Send request method started");
		Gson gson = new Gson();
		String json = gson.toJson(req);
		MailjetResponseBody responseBody = new MailjetResponseBody();
		LOG.info("Requset data----{}" + json);

		try {
			responseBody = WebClient.create().post().uri(System.getenv("MAILJET_APIM_URL"))
					.body(BodyInserters.fromValue(json)).accept(MediaType.APPLICATION_JSON).retrieve()
					.bodyToMono(MailjetResponseBody.class).block();

			if (responseBody != null) {
				String status = responseBody.getMessages().get(0).getStatus();
				LOG.info("Status of response from Mailjet API : {}" + status);
			} else {
				LOG.info("No response retrieved from Mailjet API : {}");
			}
		} catch (Exception ex) {
			LOG.error("Mailjet Webclient call failed " + ex);
			throw new MailJetServiceException("Mailjet Webclient call failed :");

		}

		return responseBody;

	}

	public void setIfNotEmpty(String variableValue, Consumer<String> setter) {
		if (!StringUtils.trimToEmpty(variableValue).isEmpty()) {
			setter.accept(variableValue);
			LOG.info("Value successfully set under variables " + variableValue);
		} else {
			LOG.info("Value fialed to set  under variables " + variableValue);
		}
	}

}
