package com.ombudsman.service.repondent.model;

import com.google.gson.annotations.SerializedName;

   
public class To {

   @SerializedName("Email")
   private String toEmail;

   @SerializedName("Name")
   private String toName;
    	
	public void setToEmail(String email) {
        this.toEmail = email;
    }
    public String getToEmail() {
        return toEmail;
    }
    
    public void setToName(String name) {
        this.toName = name;
    }
    public String getToName() {
        return toName;
    }
    
}