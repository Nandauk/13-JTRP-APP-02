package com.ombudsman.service.respondent.common;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Service;

import com.azure.core.amqp.AmqpTransportType;
import com.azure.identity.ClientSecretCredentialBuilder;
import com.azure.messaging.servicebus.ServiceBusClientBuilder;
import com.azure.messaging.servicebus.ServiceBusMessage;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ombudsman.service.repondent.model.EfileMessage;
import com.ombudsman.service.respondent.exception.AzureServiceException;

@Service
public class WebClientData {

	Logger log = LogManager.getRootLogger();

	public void bulkUpdateCaseServiceBusWebclient(EfileMessage efileMessage) throws JsonProcessingException {
		log.info("updateCaseServiceBusWebclient Started ");
		try {

			String writeValueAsString = new ObjectMapper().writeValueAsString(efileMessage);
			log.info(String.format("updateCaseServiceBusWebclient Started with message :: %s ",writeValueAsString));

			new ServiceBusClientBuilder().transportType(AmqpTransportType.AMQP)
					.fullyQualifiedNamespace(System.getenv("updateCaseServiceBusExtfullyQualifiedNamespace"))
					.credential(new ClientSecretCredentialBuilder().tenantId(System.getenv("servicbusExttenantId"))
							.clientId(System.getenv("servicebusCaseUpdateExtClientId"))
							.clientSecret(System.getenv("servicebusCaseUpdateExtSecretId")).build())
					.sender().queueName(System.getenv("caseupdateExtqueueName")).buildClient()
					.sendMessage(new ServiceBusMessage(writeValueAsString));
				


			log.info(String.format("updateCaseServiceBusWebclient Ended :: %s ",writeValueAsString));

		} catch (Exception e) {
			log.error("Posting case update in ServiceBus Connectivity Failed ::{} ", e.getMessage());
			throw new AzureServiceException("External Service Bus Connection Failed", e.getMessage(),
					e.getStackTrace());
		}

	}

}
