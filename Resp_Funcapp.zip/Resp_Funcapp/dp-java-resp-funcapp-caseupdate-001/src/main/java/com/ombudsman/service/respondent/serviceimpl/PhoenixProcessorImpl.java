package com.ombudsman.service.respondent.serviceimpl;

import java.io.IOException;
import java.net.MalformedURLException;
import java.util.Locale;
import java.util.Optional;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;

import com.google.gson.Gson;
import com.microsoft.aad.adal4j.AuthenticationContext;
import com.microsoft.aad.adal4j.AuthenticationResult;
import com.microsoft.aad.adal4j.ClientCredential;
import com.ombudsman.service.repondent.model.QueueData;
import com.ombudsman.service.repondent.model.QueueResponse;
import com.ombudsman.service.repondent.model.SystemUserData;
import com.ombudsman.service.repondent.model.SystemUserResponse;
import com.ombudsman.service.respondent.exception.PhoenixServiceException;
import com.ombudsman.service.respondent.service.PhoenixProcessor;

import io.github.resilience4j.retry.annotation.Retry;
import io.netty.util.internal.StringUtil;
import okhttp3.HttpUrl;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class PhoenixProcessorImpl implements PhoenixProcessor {

	
	//MessageSource messageSource;

	Logger LOG = LogManager.getRootLogger();
	private static final String SYSTEMUSER = "/systemusers(";
	private static final String TEAMUSER = "/teams(";

	@Override
	@Retry(name = "odataRetry", fallbackMethod = "connectWithSecondSPN")
	//public int createRecordPhnx(String accessToken, String entity, String jsonBody) {
		public int createRecordPhnx(String entity, String jsonBody) {
		Response response;
		try {

			LOG.info("Entering to createRecordPhnx method");

			OkHttpClient client = new OkHttpClient();

			MediaType mediaType = MediaType.parse("application/json; charset=utf-8");

			HttpUrl httpUrl = new HttpUrl.Builder().scheme("https")
					.host(System.getenv("phoenixHost")).addPathSegment("phoenixOdata")
					.addPathSegment(entity).build();

			RequestBody body = RequestBody.create(jsonBody, mediaType);

			Request request = new Request.Builder().url(httpUrl).addHeader("Content-Type", "application/json")
					.addHeader("OData-MaxVersion", "4.0").addHeader("OData-Version", "4.0")
					//.addHeader("Authorization", "Bearer " + accessToken)
					.post(body).build();

			response = Optional.ofNullable(client.newCall(request).execute()).orElseThrow(
					() -> new PhoenixServiceException("Phoenix exception occured", "No Response from ODATA api"));

//			if (response.code() == 429) {
//				LOG.info("Received 429 Too Many Requests, switching to second SPN");
//				return connectWithSecondSPN(entity, jsonBody);
//			}

			LOG.info("Response Code: {}", response.code());
			String responseBody = response.body().string();
			LOG.info("Response Body: {}", responseBody);

			LOG.info("createRecordPhnx Method Sucess");
			return (response.code());

		} catch (Exception e) {
			LOG.info("Phoenix connection failed {}" + e.getMessage() + " " + e.getStackTrace());
			throw new PhoenixServiceException("Phoenix exception occured", e.getMessage());

		}

	}

//	public int connectWithSecondSPN(String entity, String jsonBody) {
//		String newAccessToken = "";
//		try {
//			newAccessToken = getConnectionWithSecondSPN();
//		} catch (InterruptedException ie) {
//			LOG.error("InterruptedException: {}", ie);
//			Thread.currentThread().interrupt();
//		}
//		return createRecordPhnx(newAccessToken, entity, jsonBody);
//	}
//
//	public String getConnectionWithSecondSPN() throws InterruptedException {
//		String accessToken = null;
//		ExecutorService service = Executors.newFixedThreadPool(1);
//		AuthenticationResult result;
//
//		try {
//			AuthenticationContext context = new AuthenticationContext(
//					System.getenv("d365Authority") + System.getenv("OdataSPN2TenantId"), true, service);
//			Future<AuthenticationResult> future = context.acquireToken(System.getenv("phoenixHostFull"),
//					new ClientCredential(System.getenv("OdataSPN2ClientId"), System.getenv("OdataSPN2SecrectId")),
//					null);
//
//			result = future.get();
//			accessToken = result.getAccessToken();
//
//		} catch (MalformedURLException | ExecutionException e) {
//			throw new PhoenixServiceException("Phoenix connectivity failure", e.getMessage());
//		}
//		return accessToken;
//	}

//	public String getConnectionWithD365() throws InterruptedException {
//		String accessToken = null;
//		ExecutorService service = Executors.newFixedThreadPool(1);
//		AuthenticationResult result;
//
//		try {
//
//			AuthenticationContext context = new AuthenticationContext(
//					System.getenv("d365Authority") + System.getenv("OdataSPN1TenantId"), true, service);
//			Future<AuthenticationResult> future = context.acquireToken(System.getenv("phoenixHostFull"),
//					new ClientCredential(System.getenv("OdataSPN1ClientId"), System.getenv("OdataSPN1SecrectId")),
//					null);
//
//			result = future.get();
//			accessToken = result.getAccessToken();
//
//		} catch (MalformedURLException | ExecutionException e) {
//
//			throw new PhoenixServiceException("Phoenix connectivity failure", e.getMessage());
//		}
//		return accessToken;
//	}
	
	@Override	 
	public String getOwnerValue(String owningTeam, String owningUser) {
		if (!StringUtil.isNullOrEmpty(owningUser)) { 
			LOG.info("Owning user value is not empty, thus it is USER : {}", owningUser); 
			return SYSTEMUSER;
		} else if (!StringUtil.isNullOrEmpty(owningTeam)) { 
			LOG.info("Owning team value is not empty, thus it is TEAM : {}", owningTeam);
			return TEAMUSER;
		}
		return "";
	}

	@Override
	public String getToValue(String ownerId, String owningTeam, String owningUser) {
	//public String getToValue(String accessToken, String ownerId, String owningTeam, String owningUser) {

		if (!StringUtil.isNullOrEmpty(owningUser)) {
			LOG.info("Owning user value is not empty, thus it is USER : {}", owningUser);
			String entityName = "systemusers";
			//String systemuserid = getRecordFromSystemUser(accessToken, entityName, ownerId);
			String systemuserid = getRecordFromSystemUser(entityName, ownerId);
			return "/systemusers/" + systemuserid;

		} else if (!StringUtil.isNullOrEmpty(owningTeam)) {
			LOG.info("Owning team value is not empty, thus it is TEAM : {}", owningTeam);
			String recordIdentifier = "<ombudsman Investigators and adjudicators general>";
			String entityName = "queues";
			//String queueid = getRecordFromQueue(accessToken, entityName, recordIdentifier);
			String queueid = getRecordFromQueue(entityName, recordIdentifier);
			return "/queues/" + queueid;
		}

		return "";
	}

//	public String getRecordFromQueue(String accessToken, String entityName, String recordIdentifier) {
	@Override	
	public String getRecordFromQueue( String entityName, String recordIdentifier) {
		Response response = null;
		try {
			LOG.info("Entering getRecordFromQueue method");

			OkHttpClient client = new OkHttpClient();

			HttpUrl httpUrl = new HttpUrl.Builder().scheme("https").host(System.getenv("phoenixHost"))
					.addPathSegment("phoenixOdata").addPathSegment(entityName)
					.addQueryParameter("$filter", "name eq '" + recordIdentifier + "'").build();

			Request request = new Request.Builder().url(httpUrl)
					//.addHeader("Authorization", "Bearer " + accessToken)
					.addHeader("OData-Version", "4.0").addHeader("OData-MaxVersion", "4.0").get().build();

			LOG.info("Request URL: {}", httpUrl);
			LOG.info("Request Headers: {}", request.headers().toString());

			response = Optional.ofNullable(client.newCall(request).execute()).orElseThrow(
					() -> new PhoenixServiceException("Phoenix exception occured", "No Response from ODATA api"));

			LOG.info("Response Code from Queue: {}", response.code());
			String responseBody = response.body().string();
			LOG.info("Response Body Of Queue: {}", responseBody);

			String jsonString = responseBody;

			Gson gson = new Gson();
			QueueResponse mapResponse = gson.fromJson(jsonString, QueueResponse.class);
			String queueId = "";
			for (QueueData valueData : mapResponse.getValue()) {
				if (!StringUtil.isNullOrEmpty(valueData.getQueueid())) {
					queueId = valueData.getQueueid();
				} else {
					LOG.info("Queue ID is either null or Emplty {}");
				}
			}

			return queueId;

		} catch (Exception e) {
			if (response != null && response.body() != null) {
				try {
					LOG.info("Response body: {}", response.body().string());
				} catch (IOException ioe) {
					LOG.info("Error reading response body: {}", ioe.getMessage());
				}
			}
			LOG.info("Phoenix connection failed {}", e.getMessage());
			throw new PhoenixServiceException(
					"Unable to fetch record from Queue table", e.getMessage());
		}

	}

	//public String getRecordFromSystemUser( String accessToken, String entityName, String recordIdentifier) {
		@Override
		public String getRecordFromSystemUser(String entityName, String recordIdentifier) {
			
		Response response = null;
		try {
			LOG.info("Entering getRecordFromSystemUser method");

			OkHttpClient client = new OkHttpClient();

			HttpUrl httpUrl = new HttpUrl.Builder().scheme("https").host(System.getenv("phoenixHost"))
					.addPathSegment("phoenixOdata").addPathSegment(entityName)
					.addQueryParameter("$filter", "systemuserid eq '" + recordIdentifier + "'").build();

			Request request = new Request.Builder().url(httpUrl)
					//.addHeader("Authorization", "Bearer " + accessToken)
					.addHeader("OData-Version", "4.0").addHeader("OData-MaxVersion", "4.0").get().build();

			LOG.info("Request URL: {}", httpUrl);
			LOG.info("Request Headers: {}", request.headers().toString());

			response = Optional.ofNullable(client.newCall(request).execute()).orElseThrow(
					() -> new PhoenixServiceException("Phoenix exception occured", "No Response from ODATA api"));

			LOG.info("Response Code from System User: {}", response.code());
			String responseBody = response.body().string();
			LOG.info("Response Body Of System User: {}", responseBody);

			String jsonString = responseBody;

			Gson gson = new Gson();
			SystemUserResponse mapResponse = gson.fromJson(jsonString, SystemUserResponse.class);
			String systemUserID = "";
			for (SystemUserData valueData : mapResponse.getValue()) {
				if (!StringUtil.isNullOrEmpty(valueData.getSystemuserid())) {
					systemUserID = valueData.getSystemuserid();
				} else {
					LOG.info("SystemUserID ID is either null or Emplty {}");
				}
			}
			return systemUserID;

		} catch (Exception e) {
			if (response != null && response.body() != null) {
				try {
					LOG.info("Response body: {}", response.body().string());
				} catch (IOException ioe) {
					LOG.info("Error reading response body: {}", ioe.getMessage());
				}
			}
			LOG.info("Phoenix connection failed {}", e.getMessage());
			throw new PhoenixServiceException(
					"Unable to fetch record from System Users table", e.getMessage());
		}

	}



}
