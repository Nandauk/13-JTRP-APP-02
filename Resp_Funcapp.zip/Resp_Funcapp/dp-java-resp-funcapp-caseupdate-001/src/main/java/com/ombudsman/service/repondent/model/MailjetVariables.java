package com.ombudsman.service.repondent.model;


import com.google.gson.annotations.SerializedName;

public class MailjetVariables {



	@SerializedName("ticketNumber")
	private String ticketNumber;
	@SerializedName("reasonForChange")
	private String reasonForChange;
	public String getTicketNumber() {

		return ticketNumber;

	}

	public void setTicketNumber(String ticketNumber) {

		this.ticketNumber = ticketNumber;

	}

	public String getReasonForChange() {

		return reasonForChange;

	}

	public void setReasonForChange(String reasonForChange) {

		this.reasonForChange = reasonForChange;

	}


}




