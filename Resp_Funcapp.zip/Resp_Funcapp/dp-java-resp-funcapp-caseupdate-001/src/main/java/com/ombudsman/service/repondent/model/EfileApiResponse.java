package com.ombudsman.service.repondent.model;


import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.List;

public class EfileApiResponse {

    @JsonProperty("for")
    private String forAttribute;

    @JsonProperty("documentCodes")
    private List<DocumentCode> documentCodes;

    @JsonProperty("originatorCodes")
    private List<OriginatorCode> originatorCodes;

    @JsonProperty("reasonForChangeCodes")
    private List<ReasonForChangeCode> reasonForChangeCodes;

    @JsonProperty("reasonForChangeMapping")
    private List<ReasonForChangeMapping> reasonForChangeMapping;

    // Getters and Setters
    public String getForAttribute() {
        return forAttribute;
    }

    public void setForAttribute(String forAttribute) {
        this.forAttribute = forAttribute;
    }

    public List<DocumentCode> getDocumentCodes() {
        return documentCodes;
    }

    public void setDocumentCodes(List<DocumentCode> documentCodes) {
        this.documentCodes = documentCodes;
    }

    public List<OriginatorCode> getOriginatorCodes() {
        return originatorCodes;
    }

    public void setOriginatorCodes(List<OriginatorCode> originatorCodes) {
        this.originatorCodes = originatorCodes;
    }

    public List<ReasonForChangeCode> getReasonForChangeCodes() {
        return reasonForChangeCodes;
    }

    public void setReasonForChangeCodes(List<ReasonForChangeCode> reasonForChangeCodes) {
        this.reasonForChangeCodes = reasonForChangeCodes;
    }

    public List<ReasonForChangeMapping> getReasonForChangeMapping() {
        return reasonForChangeMapping;
    }

    public void setReasonForChangeMapping(List<ReasonForChangeMapping> reasonForChangeMapping) {
        this.reasonForChangeMapping = reasonForChangeMapping;
    }

    // Nested classes
    public static class DocumentCode {
        private String name;
        private String code;

        // Getters and Setters
        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getCode() {
            return code;
        }

        public void setCode(String code) {
            this.code = code;
        }
    }

    public static class OriginatorCode {
        private String name;
        private String code;

        // Getters and Setters
        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getCode() {
            return code;
        }

        public void setCode(String code) {
            this.code = code;
        }
    }

    public static class ReasonForChangeCode {
        private String name;
        private String code;

        // Getters and Setters
        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getCode() {
            return code;
        }

        public void setCode(String code) {
            this.code = code;
        }
    }

    public static class ReasonForChangeMapping {
        private String reasonforchangecode;
        private String reasonforchangetext;
        private String categorycode;
        private String subjecttext;

        // Getters and Setters
        public String getReasonforchangecode() {
            return reasonforchangecode;
        }

        public void setReasonforchangecode(String reasonforchangecode) {
            this.reasonforchangecode = reasonforchangecode;
        }

        public String getReasonforchangetext() {
            return reasonforchangetext;
        }

        public void setReasonforchangetext(String reasonforchangetext) {
            this.reasonforchangetext = reasonforchangetext;
        }

        public String getCategorycode() {
            return categorycode;
        }

        public void setCategorycode(String categorycode) {
            this.categorycode = categorycode;
        }

        public String getSubjecttext() {
            return subjecttext;
        }

        public void setSubjecttext(String subjecttext) {
            this.subjecttext = subjecttext;
        }
    }
    
    
}
