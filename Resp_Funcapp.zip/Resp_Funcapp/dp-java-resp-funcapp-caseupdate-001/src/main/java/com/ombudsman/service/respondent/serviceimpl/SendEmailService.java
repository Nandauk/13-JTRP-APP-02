package com.ombudsman.service.respondent.serviceimpl;

import java.io.UnsupportedEncodingException;
import java.text.ParseException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONException;
import org.springframework.beans.factory.annotation.Autowired;

import com.ombudsman.service.repondent.model.EmailNotificationResponse;
import com.ombudsman.service.repondent.model.MailjetResponseBody;
import com.ombudsman.service.repondent.model.SendMailDetails;
import com.ombudsman.service.repondent.model.SendMailReq;
import com.ombudsman.service.respondent.exception.InputValidationException;
import com.ombudsman.service.respondent.exception.MailJetServiceException;
import com.ombudsman.service.respondent.helper.RequestBodyHelper;

public class SendEmailService {

	Logger LOG = LogManager.getRootLogger();

	RequestBodyHelper requestBodyHelper = new RequestBodyHelper();

	SendMailReq sendMailReq = new SendMailReq();

	EmailNotificationResponse result = new EmailNotificationResponse();

	MailjetResponseBody response = new MailjetResponseBody();

	public EmailNotificationResponse sendInviteEmail(SendMailDetails request) throws InputValidationException,
			UnsupportedEncodingException, ParseException, JSONException, MailJetServiceException {

		EmailNotificationResponse result = new EmailNotificationResponse();
		LOG.info("Inside sendInviteEmail impl method {}");

		sendMailReq = requestBodyHelper.contructSendEmailBody(request);

		response = requestBodyHelper.send(sendMailReq);

		LOG.info("Response received from SEND menthod {}");

		String status = response.getMessages().get(0).getStatus();
		if (status.equals("success")) {
			result.setStatus(status);
			result.setMessage("MailJet API call success :{}");
		} else {
			result.setStatus(status);
			result.setMessage("MailJet API call failed :{}");
		}

		return result;
	}

}
