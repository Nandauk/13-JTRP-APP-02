package com.ombudsman.service.respondent;

import java.beans.Transient;
import java.io.IOException;
import java.sql.SQLException;
import java.text.ParseException;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONException;
import org.springframework.jdbc.core.JdbcTemplate;

import org.springframework.stereotype.Component;
import org.springframework.web.util.HtmlUtils;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.microsoft.azure.functions.ExecutionContext;
import com.microsoft.azure.functions.annotation.FunctionName;
import com.microsoft.azure.functions.annotation.ServiceBusQueueTrigger;
import com.ombudsman.service.repondent.model.EfileMessage;
import com.ombudsman.service.repondent.model.EmailNotificationResponse;
import com.ombudsman.service.repondent.model.SendMailDetails;
import com.ombudsman.service.repondent.model.SubjectAndCatCode;
import com.ombudsman.service.repondent.model.UpdateCase;
import com.ombudsman.service.repondent.model.UpdateCase.NumberOfCases;
import com.ombudsman.service.repondent.model.UpdateCaseDto;
import com.ombudsman.service.repondent.model.UpdateCaseMessage;
import com.ombudsman.service.repondent.model.UpdateCaseMessage.FosPortalActivityParty;
import com.ombudsman.service.respondent.common.DataSourceSingleton;
import com.ombudsman.service.respondent.common.WebClientData;
import com.ombudsman.service.respondent.exception.InputValidationException;
import com.ombudsman.service.respondent.exception.MailJetServiceException;
import com.ombudsman.service.respondent.exception.RecordCreationException;
import com.ombudsman.service.respondent.helper.CaseUpdateSqlHelper;
import com.ombudsman.service.respondent.serviceimpl.CaseActivityImpl;
import com.ombudsman.service.respondent.serviceimpl.IncidentInfoImpl;
import com.ombudsman.service.respondent.serviceimpl.PhoenixProcessorImpl;
import com.ombudsman.service.respondent.serviceimpl.SendEmailService;

@Component
public class CaseUpdateAzureFunction {

	Logger log = LogManager.getRootLogger();

	private static final String SUCCESS = "Success";
	private static final String READY_FOR_DELIVERY = "ReadyForDelivery";
	private static final String FAILED = "Failed";
	private static final String TRUE = "true";
	private static final String PORTAL_ENTITY_PHNX = "fos_portals";
	private static final String ACTIVITYPARTY = "Microsoft.Dynamics.CRM.activityparty";
	private static final String INCIDENT = "/incidents(";
	private static final String SYSTEMUSER = "/systemusers(";
	private static final String TEAMUSER = "/teams(";
	private static final String CONTACTS = "/contacts/";
	private static final String PENDING = "Pending";
	private static final String templateName= "Update Case Failed";

	CaseActivityImpl caseActivityImpl = new CaseActivityImpl();

	CaseUpdateSqlHelper caseUpdateSqlHelper = new CaseUpdateSqlHelper();

	WebClientData webClientData = new WebClientData();

	PhoenixProcessorImpl phoenixProcessorImpl = new PhoenixProcessorImpl();

	SendEmailService sendEmailService = new SendEmailService();

	JdbcTemplate jdbcTemplateConn = new JdbcTemplate();

	@FunctionName("BulkCaseUpdateRequest")
	@Transient(true)
	public void updateBulkCase(
			@ServiceBusQueueTrigger(name = "CaseUpdateMsg", queueName = "%QueueNameCaseUpdate%", connection = "AzureWebJobsServiceBus") String request,
			final ExecutionContext context) throws InterruptedException, IOException, SQLException, InputValidationException, JSONException, ParseException, MailJetServiceException {

		log.info("Message received: {}", request);

		UpdateCase dto = new UpdateCase();

		// Map to store CaseID with respect to PackageID
	    Map<String, String> mapCaseIdToPckgId = new HashMap<>();
	    String email = "";
	    String name = "";
	    int reasonForChange = 0;
	    String details = "";
	    String oid = "";
	    String contactId = "";
	    String reasonForChangeText = "";
	     Map<String, String> caseIdAndPhnxTicket = new HashMap<>();

		// Step 1 : Mapping Message request to model class
		try {

			dto = new ObjectMapper().readValue(request.toString(), UpdateCase.class);

			log.info(String.format("Dto received: %s", dto));
		} catch (Exception e) {
			log.info("Error processing message: {}" + e.getMessage());
		}

		try {

			 reasonForChange = dto.getReasonForChange();
			 details = dto.getDetails();
			 oid = dto.getUserId();
			List<String> accounts = dto.getUsersAccountIds();
			List<NumberOfCases> caseIdList = dto.getNumberOfCases();

			//Get user email and Name from OID
			List<String> output = caseUpdateSqlHelper.getUserEmailName(oid);
			name = output.get(0);
			email  = output.get(1);
			int index = 0;

			// Step 2 : Setting IncidentInfo
		
			List<IncidentInfoImpl> incidentInfo = new ArrayList<>();
			for (NumberOfCases eachCase : caseIdList) {
				IncidentInfoImpl info = caseUpdateSqlHelper.getIncident(eachCase.getCaseId(), accounts);
				//IncidentID and Ticket number in INFO

				if (!(info.getIncidentId().equalsIgnoreCase(eachCase.getCaseId().toLowerCase()))) {
						
					log.info(String.format("No IncidentId found matching the caseID provided:: %s %s",
							info.getIncidentId() + " " + eachCase.getCaseId()));
				}
				
				incidentInfo.add(info);
				caseIdAndPhnxTicket.put(info.getIncidentId(), info.getTicketNumber()); //Case ID --> Ticket number
			
				}
			
			 reasonForChangeText = caseUpdateSqlHelper.getReasonForChangeText(reasonForChange);
			log.info(String.format("reasonForChangeText : %s", reasonForChangeText));

			// Step 3 : Adding record in Request and Notification table
			for (IncidentInfoImpl info : incidentInfo) {
				String id = caseActivityImpl.activity(dto, info.getTicketNumber(), index,
						reasonForChange);
				index++;
				log.info(String.format("Package Id from case activity : %s", id));
				mapCaseIdToPckgId.put(info.getIncidentId().toLowerCase(), id);//IncientID --> PackageID

			}

			log.info(String.format("Total Number of Cases added in Request table : %s", index));

			// Step 4 : Add Record in CASEUPDAT_TABLE and status as Pending
			for (NumberOfCases singleCase : dto.getNumberOfCases()) {
				UpdateCaseDto req = new UpdateCaseDto();
				req.setCase_id(singleCase.getCaseId());
				req.setComments(HtmlUtils.htmlUnescape(singleCase.getComment()));
				req.setDetails(details);
				req.setReason_for_change(reasonForChange);
				req.setCreated(OffsetDateTime.now());
				req.setPackage_id(mapCaseIdToPckgId.get(singleCase.getCaseId().toLowerCase()));
				req.setUser_id(oid);
				req.setStatus(PENDING);
				caseUpdateSqlHelper.saveRecordUpdateCase(req);

			}

			jdbcTemplateConn = new JdbcTemplate(DataSourceSingleton.getDataSource());

			for (NumberOfCases singleCase : dto.getNumberOfCases()) {
				UpdateCaseMessage updateCaseMessage = new UpdateCaseMessage();

				// STEP 5 : Calling Stored procedure to get ContactID, phnxemailId, phnxUsername

				Map<String, Object> inputs = new HashMap<>();
				inputs.put("oidinput", oid);
				inputs.put("incidentid", singleCase.getCaseId());
				log.info(String.format("Inputs for SPM are OID and caseID : %s", inputs));
				final Map<String, Object> phnxUserDetails = caseUpdateSqlHelper.getContactId(inputs, jdbcTemplateConn);
				log.info(String.format("Details as fetched from SP call : %s", phnxUserDetails));
				if (phnxUserDetails != null && !phnxUserDetails.isEmpty()) {
					List<Map<String, Object>> resultSet = (List<Map<String, Object>>) phnxUserDetails
							.get("#result-set-1");
					if (resultSet != null && !resultSet.isEmpty()) {
						Map<String, Object> userDetails = resultSet.get(0);

						contactId = (String) userDetails.get("contactid");
						log.info(String.format("ContactID from SP is: %s", contactId));
						
					}
				} else {
					log.info("phnxUserDetails Is null for User when fetched from SP:  ");
				}

				Map<String, String> values = caseUpdateSqlHelper.getOwnerDetails(singleCase.getCaseId());
				
				updateCaseMessage.setRegardingObjectIdIncidentFosPortal(INCIDENT + singleCase.getCaseId() + ")");
				/*
				 * if(StringUtils.isNoneEmpty(values.get("ownerId"))){
				 * updateCaseMessage.setOwnerId(SYSTEMUSER +
				 * caseUpdateSqlHelper.getOwnerId(singleCase.getCaseId()) + ")"); } else if()
				 */
				final String ownerTableValue = phoenixProcessorImpl.getOwnerValue(values.get("owningTeam"), values.get("owningUser"));
				updateCaseMessage.setOwnerId(ownerTableValue + caseUpdateSqlHelper.getOwnerId(singleCase.getCaseId()) + ")");
				//updateCaseMessage.setOwnerId(SYSTEMUSER + caseUpdateSqlHelper.getOwnerId(singleCase.getCaseId()) + ")");
				updateCaseMessage.setDescription(HtmlUtils.htmlUnescape(singleCase.getComment()));
				updateCaseMessage.setActivityId(mapCaseIdToPckgId.get(singleCase.getCaseId().toLowerCase()));
				updateCaseMessage.setFosPackageId(mapCaseIdToPckgId.get(singleCase.getCaseId().toLowerCase()));
				updateCaseMessage.setFosReasonForChange(reasonForChange);
				updateCaseMessage.setFosOtherReasonForChange(details);
				updateCaseMessage.setFosDpUserEmailAddress(email);
				updateCaseMessage.setFosDpUserFullName(name);

				// (subject and category code) are based on reason for change
				List<SubjectAndCatCode> result = Optional
						.ofNullable(caseUpdateSqlHelper.getSubCategoryCode(reasonForChange)).orElseThrow();
				if (!Objects.isNull(result)) {
					updateCaseMessage.setFosCategoryCode(result.get(0).getCategoryCode());
					updateCaseMessage.setSubject(result.get(0).getSubject());
				}

				// Is always false for respondent
				updateCaseMessage.setFosBusinessResponse(false);
				updateCaseMessage.setFosCapacity(140000000); // Static values : Respondent = 140000000, Complainant =
																// 140000001

				// To and From fields
				List<FosPortalActivityParty> toAndFrom = new ArrayList<>();
				FosPortalActivityParty toAttribute = new FosPortalActivityParty();
				FosPortalActivityParty fromAttribute = new FosPortalActivityParty();

				fromAttribute.setType(ACTIVITYPARTY);
				fromAttribute.setPartyIdContact(CONTACTS + contactId); // contactID will come from SP

				fromAttribute.setParticipationTypeMask(1);
				toAndFrom.add(fromAttribute);

				// Step 6 : Record Creation in Phoenix CRM Using Phoenix API

				ObjectMapper objectMapper = new ObjectMapper();
				//String accessToken = phoenixProcessorImpl.getConnectionWithD365();

				
				//String toValue = phoenixProcessorImpl.getToValue(accessToken, values.get("ownerId"),values.get("owningTeam"), values.get("owningUser"));
				
				String toValue = phoenixProcessorImpl.getToValue(values.get("ownerId"),
						values.get("owningTeam"), values.get("owningUser"));
				if(values.get("owningTeam")!=null) {
					toAttribute.setPartyIdQueue(toValue);
				}else if((values.get("owningUser")!=null)){
					toAttribute.setPartyIdSystemUser(toValue);
				}
				toAttribute.setType(ACTIVITYPARTY);
				toAttribute.setParticipationTypeMask(2);
				toAttribute.setPartyIdSystemUser(toValue);
				toAndFrom.add(toAttribute);
				updateCaseMessage.setFosPortalActivityParties(toAndFrom);

				String jsonString = objectMapper.writeValueAsString(updateCaseMessage);
				log.info(String.format("Json Rquest String for recrod creation in Portal table : %s ", jsonString));

			//	int recordCreationResponse = phoenixProcessorImpl.createRecordPhnx(accessToken,PORTAL_ENTITY_PHNX,jsonString);
				
				int recordCreationResponse = phoenixProcessorImpl.createRecordPhnx(PORTAL_ENTITY_PHNX,
						jsonString);

				if (recordCreationResponse == 204) {

					// Update SATAUS in caseUpdate table to Success
					caseUpdateSqlHelper.updateCaseTable(singleCase.getCaseId(), SUCCESS);

					// Update Notification table as Success
					caseUpdateSqlHelper.updateNotificationTable(mapCaseIdToPckgId.get(singleCase.getCaseId().toLowerCase()), SUCCESS,
							"5");

					// Create Efile messge
					EfileMessage efileMessage = new EfileMessage();
					efileMessage.setCaseId(singleCase.getCaseId());
					efileMessage.setComments(HtmlUtils.htmlUnescape(singleCase.getComment()));
					efileMessage.setContactId(contactId);
					efileMessage.setDetails(details);
					efileMessage.setDigitalPortalUserEmailAddress(email);
					efileMessage.setDigitalPortalUserName(name);
					efileMessage.setIsRespondent(TRUE);
					efileMessage.setPackageId(mapCaseIdToPckgId.get(singleCase.getCaseId().toLowerCase()));
					efileMessage.setReasonForChange(reasonForChange);
					efileMessage.setUsersAccountIds(accounts.toArray(new String[0]));

					log.info(String.format("Efile Message sent to external bus : %s", efileMessage));
					
					// Send Message to external Queue for Efile to read and create PDF
					webClientData.bulkUpdateCaseServiceBusWebclient(efileMessage);
					log.error(String.format("Efile message ready to be sent in service bus : %s",efileMessage));

				} else {

					// Update Notification status as ReadyForDelviery
					caseUpdateSqlHelper.updateNotificationTable(mapCaseIdToPckgId.get(singleCase.getCaseId().toLowerCase()),
							READY_FOR_DELIVERY, "2");

					// Update SATAUS in caseUpdate table to Failure
					caseUpdateSqlHelper.updateCaseTable(singleCase.getCaseId(), FAILED);

					// Send email Notification for Failure to update
					SendMailDetails emailDetails = new SendMailDetails();
					emailDetails.setEmail(email);
					emailDetails.setFullName(name);
					emailDetails.setReasonForChange(reasonForChangeText);
					emailDetails.setTicketNumber(caseIdAndPhnxTicket.get(singleCase.getCaseId()));
					emailDetails.setTemplateId(Integer.parseInt(System.getenv("templateId")));
					emailDetails.setTemplateName(templateName);

					EmailNotificationResponse res = sendEmailService.sendInviteEmail(emailDetails);

					log.info(String.format("Email sent successfully for failed Case Update scenario : %s", res.getStatus()));
					log.info("Record not created in portal table ");
				}

			}

		}catch (Exception e) {
			log.error("Exception in Bulk case update Azure function {}", e.getMessage());
		
	        // Code in the else block goes here
	        for (NumberOfCases singleCase : dto.getNumberOfCases()) {
	            // Update Notification status as ReadyForDelviery
	            caseUpdateSqlHelper.updateNotificationTable(mapCaseIdToPckgId.get(singleCase.getCaseId().toLowerCase()),
	                    READY_FOR_DELIVERY, "2");

	            // Update STATUS in caseUpdate table to Failure
	            caseUpdateSqlHelper.updateCaseTable(singleCase.getCaseId(), FAILED);

	            // Send email Notification for Failure to update
	            SendMailDetails emailDetails = new SendMailDetails();
	            emailDetails.setEmail(email);
	            emailDetails.setFullName(name);
	            emailDetails.setReasonForChange(reasonForChangeText);
	            emailDetails.setTicketNumber(caseIdAndPhnxTicket.get(singleCase.getCaseId()));
	            emailDetails.setTemplateId(Integer.parseInt(System.getenv("templateId")));
	            emailDetails.setTemplateName(templateName);

	            EmailNotificationResponse res = sendEmailService.sendInviteEmail(emailDetails);

	            log.info(String.format("Email sent successfully for failed Case Update scenario : %s", res.getStatus()));
	            log.info("Record not created in portal table ");
	        }	throw new RecordCreationException("", "Phoenix record cannot be created", null);
		}

	}

}
