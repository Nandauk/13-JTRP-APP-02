package com.ombudsman.service.respondent;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.MediaType;
import org.springframework.web.reactive.function.client.WebClient;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import com.microsoft.azure.functions.ExecutionContext;
import com.microsoft.azure.functions.annotation.FunctionName;
import com.microsoft.azure.functions.annotation.TimerTrigger;
import com.ombudsman.service.repondent.model.EfileApiResponse;
import com.ombudsman.service.repondent.model.EfileApiResponse.ReasonForChangeMapping;
import com.ombudsman.service.respondent.common.WebClientData;
import com.ombudsman.service.respondent.exception.SQLDataAccessException;
import com.ombudsman.service.respondent.helper.CaseUpdateSqlHelper;

public class DpSqlTableUpdate {

	Logger log = LogManager.getRootLogger();


	CaseUpdateSqlHelper caseUpdateSqlHelper = new CaseUpdateSqlHelper();

	/** * This function runs once every 24 hours. */
	@FunctionName("TimerTriggerFunction")
	public void dpTableUpdate(
			@TimerTrigger(name = "timerInfo", schedule = "0 0 0 * * *")String packgid, final ExecutionContext context) {

		log.info("Java Timer Trigger function App Started to Update DP table :");
		log.info(String.format("Java Timer trigger function executed at: %s", java.time.LocalDateTime.now()));

		try {

			// Call efile API getSharedConfigurationAPI
			List<EfileApiResponse> responses = Optional
				    .ofNullable(WebClient.create()
				        .get()
				        .uri(System.getenv("EFILE_API_END_POINT"))
				        .accept(MediaType.APPLICATION_JSON)
				        .retrieve()
				        .bodyToFlux(EfileApiResponse.class)
				        .collectList()
				        .block())
				    .orElseThrow(() -> new SQLDataAccessException("No Data fetched from Static config table {}","" ));
			
			log.info(String.format("Response Received after calling Efile API : %s",responses));

			List<ReasonForChangeMapping> complainantMappings = responses.stream()
					.filter(response -> "complainant".equals(response.getForAttribute()))
					.flatMap(response -> response.getReasonForChangeMapping().stream()).collect(Collectors.toList());

			log.info(String.format("Complainants Records calling Efile API : %s",complainantMappings.toString()));
			
			List<ReasonForChangeMapping> respondentMappings = responses.stream()
					.filter(response -> "respondent".equals(response.getForAttribute()))
					.flatMap(response -> response.getReasonForChangeMapping().stream()).collect(Collectors.toList());

			log.info(String.format("Respondent Records calling Efile API : %s",respondentMappings.toString()));
			Map<String, ReasonForChangeMapping> reasonForChangeMap = new HashMap<>();
			Set<String> commonKeys = new HashSet<>();

			// Process respondent records
			for (ReasonForChangeMapping mapping : respondentMappings) {
				String key = mapping.getReasonforchangecode() + mapping.getReasonforchangetext()
						+ mapping.getCategorycode() + mapping.getSubjecttext();
				log.info(String.format("Respondent Key Values created  : %s",key));
				if (reasonForChangeMap.containsKey(key)) {
					commonKeys.add(key);
				} else {
					reasonForChangeMap.put(key, mapping);
				}
			}

			// Process complainant records
			for (ReasonForChangeMapping mapping : complainantMappings) {
				String key = mapping.getReasonforchangecode() + mapping.getReasonforchangetext()
						+ mapping.getCategorycode() + mapping.getSubjecttext();
				log.info(String.format("Complainant Key Values created  : %s",key));
				if (reasonForChangeMap.containsKey(key)) {
					commonKeys.add(key);
				} else {
					reasonForChangeMap.put(key, mapping);
				}
			}

			// Delete all existing records
			caseUpdateSqlHelper.deleteAllRecords();

			log.info("All records deleted from the table.Back to trigger function :");

			// Insert all records
			caseUpdateSqlHelper.insertApiMappingInTable(reasonForChangeMap, commonKeys, respondentMappings);

			log.info("All records inserted ");

		} catch (Exception e) {
			log.error(String.format("catch block of time trigger :: %s ", e.getMessage()));
		}

	}
}
