package com.ombudsman.service.repondent.model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.sun.jna.platform.win32.Guid;

@ExtendWith(SpringExtension.class)
public class PortalActivityAddedTest {
	
	@Test
	public void  testPortalActivityAdded() {
		 
		PortalActivityAdded testInstance = new PortalActivityAdded();
		
		 
		  String[] usersAccountIds = {"acc1","acc2"} ;
		  int reasonForChange = 123 ;
		  boolean isBusinessResponse = true;
		  String comments = "cooment" ;
		  String digitalPortalUserName = "userNameMock" ;
		  String digitalPortalUserEmailAddress = "emialAddressMock" ;
		  
		  testInstance.setBusinessResponse(isBusinessResponse);
		  testInstance.setComments(comments);
		  testInstance.setDigitalPortalUserEmailAddress(digitalPortalUserEmailAddress);
		  testInstance.setDigitalPortalUserName(digitalPortalUserName);
		  testInstance.setReasonForChange(reasonForChange);
		  testInstance.setPortalType("Respondent");
		  testInstance.setUsersAccountIds(usersAccountIds);
		  
		  assertEquals(testInstance.isBusinessResponse(),isBusinessResponse);
		  assertEquals(testInstance.getComments(),comments);
		  assertEquals(testInstance.getDigitalPortalUserEmailAddress(),digitalPortalUserEmailAddress);
		  
		  assertEquals(testInstance.getDigitalPortalUserName(),digitalPortalUserName);
		  assertEquals(testInstance.getReasonForChange(),reasonForChange);
		  assertEquals(testInstance.getPortalType(),"Respondent");
		  assertEquals(testInstance.getUsersAccountIds(),usersAccountIds);
		  
			
	}

}
