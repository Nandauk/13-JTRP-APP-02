package com.ombudsman.service.respondent.model.request.test;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.time.OffsetDateTime;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.ombudsman.service.respondent.model.request.Uploadrequests;


@ExtendWith(SpringExtension.class)
public class UploadrequestsTest {

	@Test
	public void  testUploadrequests() {

		Uploadrequests testInstance = new Uploadrequests();
		 
		Integer id = 12;
		 String packageid = "mockVaal";
		 String status = "mockVaal";
		 String caseid = "mockVaal";
		 String pnx = "mockVaal";
		 String userid = "mockVaal";
		 OffsetDateTime created = OffsetDateTime.now() ;
		 String comments = "mockVaal";
		 
		 testInstance.setCaseid(caseid);
		 testInstance.setComments(comments);
		 testInstance.setCreated(created);
		 testInstance.setId(id);
		 testInstance.setPackageid(packageid);
		 testInstance.setPnx(pnx);
		 testInstance.setStatus(status);
		 testInstance.setUserid(userid);
		 
		 assertEquals( testInstance.getCaseid(),caseid);
		 assertEquals(testInstance.getComments(),comments);
		 assertEquals( testInstance.getCreated(),created);
		 assertEquals(testInstance.getId(),id);
		 assertEquals( testInstance.getPackageid(),packageid);
		 assertEquals( testInstance.getPnx(),pnx);
		 assertEquals(testInstance.getStatus(),status);
		 assertEquals(testInstance.getUserid(),userid);
		
	}
}
