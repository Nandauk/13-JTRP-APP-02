package com.ombudsman.service.respondent.model.dto;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.time.OffsetDateTime;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.test.context.junit.jupiter.SpringExtension;

@ExtendWith(SpringExtension.class)
public class UploadRequestFileTest {

	@Test
	public void  testUploadRequestFile() {
		
		UploadRequestFile testInstance = new UploadRequestFile();
		
		
		 int id =1;
		 int uploadRequestId=2;
		 String status = "mockVal";
		 String comments = "mockVal";
		 OffsetDateTime lastUpdatedTime = OffsetDateTime.now() ;
		 String fileName = "mockVal";
		 String documentId = "mockVal";
		 String fileSize = "mockVal";
		 boolean isUploaded =true;
		 
		 testInstance.setComments(comments);
		 testInstance.setDocumentId(documentId);
		 testInstance.setFileName(fileName);
		 testInstance.setFileSize(fileSize);
		 testInstance.setId(id);
		 testInstance.setLastUpdatedTime(lastUpdatedTime);
		 testInstance.setStatus(status);
		 testInstance.setUploaded(isUploaded);
		 testInstance.setUploadRequestId(uploadRequestId);
		 
		 
		 
		 assertEquals(testInstance.getComments(),comments);
		 assertEquals(testInstance.getDocumentId(),documentId);
		 assertEquals(testInstance.getFileName(),fileName);
		 assertEquals(testInstance.getFileSize(),fileSize);
		 assertEquals(testInstance.getId(),id);
		 assertEquals(testInstance.getLastUpdatedTime(),lastUpdatedTime);
		 assertEquals(testInstance.getStatus(),status);
		 assertEquals(testInstance.getUploaded(),isUploaded);
		 assertEquals(testInstance.getUploadRequestId(),uploadRequestId);

		
		
	}
	
}
