package com.ombudsman.service.respondent.helper.test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.when;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.Spy;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.azure.storage.blob.BlobContainerClient;
import com.azure.storage.blob.BlobServiceClientBuilder;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ombudsman.service.respondent.helper.ValidationServiceHelper;
import com.ombudsman.service.respondent.model.dto.PostScanningParamsDto;
import com.ombudsman.service.respondent.model.dto.ScanResultDto;
import com.ombudsman.service.respondent.model.dto.UploadCompletedMessageDto;

@ExtendWith(SpringExtension.class)
public class ValidationServiceHelperTest {

	@InjectMocks
	ValidationServiceHelper testInstance;
	
	@Mock
	Connection jdbcConnection;

    @Mock
    private PreparedStatement stmt;
    
    @Mock
    private ResultSet rs;
    
    @Mock
    BlobServiceClientBuilder b;
    
    @Mock
    BlobContainerClient sourceContainerClient ;
	
	@Test
	public void updateRequestTest() throws SQLException {
		
		ScanResultDto data = new ScanResultDto();
		data.setClean(false); //not clean
		data.setComment("good");
		data.setDocumentId("doc11");
		data.setFileName("fileNameMock");
		List<ScanResultDto> scanResultList = new ArrayList<ScanResultDto>();
		scanResultList.add(data);
		UploadCompletedMessageDto messageData = new UploadCompletedMessageDto();
		messageData.setCaseId("case1");
		
		PostScanningParamsDto postScanningParams = new PostScanningParamsDto();
		postScanningParams.setPackageId("acv123");
		postScanningParams.setIngestionMessageSent(true);
		postScanningParams.setScanningResults(scanResultList);
		postScanningParams.setMessage(messageData);
		postScanningParams.isIngestionMessageSent();
		
		 when(jdbcConnection.prepareStatement(Mockito.any(String.class))).thenReturn(stmt);
		
	     when(rs.getString(1)).thenReturn("package123");
	     when(stmt.executeQuery()).thenReturn(rs);
	    
	   //  when(testInstance.connectionjdbc()).thenReturn(jdbcConnection);
		testInstance.updateRequest(postScanningParams);
		
	}
	
	@Test
	public void  sendPortalActivityAddedMessageTest() {
		
		UploadCompletedMessageDto uploadCompletedMessageDto = new UploadCompletedMessageDto() ;
		uploadCompletedMessageDto.setCaseId("12");
		boolean response = testInstance.sendPortalActivityAddedMessage(uploadCompletedMessageDto);
		assertEquals(response,false);

	}
	
//	@Test
//	public void processPassedfileTest() {
//		
//
//		
//		PostScanningParamsDto postScanningParamsDto = new PostScanningParamsDto();
//		
//		ScanResultDto a = new ScanResultDto();
//		a.setClean(true);
//		a.setComment("mockComment");
//		a.setFileName("file1");
//		a.setDocumentId("doc1");
//		List<ScanResultDto> data = new ArrayList<>();
//		data.add(a);
//		postScanningParamsDto.setScanningResults(data);
//		postScanningParamsDto.setPackageId("package1");
//		ValidationServiceHelper myClass = spy(new ValidationServiceHelper());
//		when(myClass.moveFile(Mockito.anyList(),Mockito.anyString(),Mockito.anyString())).thenReturn(true);
//		
//		int result = myClass.processPassedfile(postScanningParamsDto);
//	}

	
}
