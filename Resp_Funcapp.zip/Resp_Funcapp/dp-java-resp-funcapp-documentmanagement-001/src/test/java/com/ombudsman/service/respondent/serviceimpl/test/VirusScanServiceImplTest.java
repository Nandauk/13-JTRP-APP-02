package com.ombudsman.service.respondent.serviceimpl.test;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.net.http.HttpClient;
import java.util.concurrent.ExecutionException;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ombudsman.service.repondent.model.CloudmersivePayload;
import com.ombudsman.service.respondent.model.dto.ScanResultDto;
import com.ombudsman.service.respondent.model.request.VirusScanResponse;
import com.ombudsman.service.respondent.serviceimpl.VirusScanServiceImpl;
@ExtendWith(SpringExtension.class)
public class VirusScanServiceImplTest {

	@InjectMocks
	VirusScanServiceImpl testInstance;
	
	@Mock
	HttpClient httpClient;
	
	@Mock
	CloudmersivePayload payload;
	
	@Mock
	ObjectMapper objectMapper;
	
	
	@Test
	public void setHeaderValuesTest() {
		
		//HttpClient response = testInstance.setHeaderValues(httpClient,  payload);
		//assertNotNull(response);
	}
	
	@Test
	public void initializePayloadTest() {
		
		CloudmersivePayload response = testInstance.initializePayload();
		assertNotNull(response);
		
	}
	
	@Test
	public void virusScanClientActivityTest() throws InterruptedException, ExecutionException, IOException {
		ScanResultDto response = testInstance.virusScanClientActivity(payload);
		assertNotNull(response);
	}
	
	@Test
	public void scanBlobTest() throws InterruptedException, ExecutionException, IOException {
		ScanResultDto response = testInstance.scanBlob( payload,httpClient);
		assertNotNull(response);
	}
	
	@Test
	public void scanBlobTestFalse() throws InterruptedException, ExecutionException, IOException {
		
		CloudmersivePayload payload = new CloudmersivePayload();
		payload.setScanEnabled(true);
		
		ScanResultDto response = testInstance.scanBlob( payload,httpClient);
		assertNotNull(response);
	}
	
	@Test
	public  void performScanTest() throws JsonProcessingException {
		
		CloudmersivePayload payload = new CloudmersivePayload();
		payload.setScanEnabled(true);
		payload.setApikey("mockApiKey");
		payload.setBlobPath("mockBlobPath");
		payload.setConnectionString("MockConnection");
		payload.setDocumentId("123");
		payload.setScanUrl("mockscanURL");
		payload.setContainerName("mockContainerName");
		when(objectMapper.writeValueAsString(payload)).thenReturn("mockpayloaddata");
		
		VirusScanResponse response = testInstance.performScan(payload, httpClient);
		assertNotNull(response);
	}
	
	
}
