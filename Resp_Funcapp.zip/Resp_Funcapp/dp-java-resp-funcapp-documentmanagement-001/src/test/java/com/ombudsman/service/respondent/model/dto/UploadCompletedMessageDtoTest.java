package com.ombudsman.service.respondent.model.dto;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.test.context.junit.jupiter.SpringExtension;

@ExtendWith(SpringExtension.class)
public class UploadCompletedMessageDtoTest {

	@Test
	public void  testUploadCompletedMessageDto() {
		 
		UploadCompletedMessageDto testInstance = new UploadCompletedMessageDto();
		
		int uploadRequestId = 12;
		 String caseId = "caseId";
		 String contactId = "mockValue";
		 String packageId = "mockValue";
		 String pnx = "mockValue";
		 String comments = "mockValue";
		 String userId = "mockValue";
		 String orgId = "mockValue";
		 String userEmail = "mockValue";
		 String userName = "mockValue";
		 String[] usersAccountIds = {"mock1","mock2"};
		 String subject = "mockValue";
		 int reasonForChange =12;
		

		 List<UploadFileInfoDto> files = new ArrayList<>();
		 UploadFileInfoDto data = new UploadFileInfoDto();
		 data.setDocumentId("doc1");
		 data.setFileName("file1");
		 files.add(data);

		 boolean isBusinessResponse =true;
		 String digitalPortalUserName ="mock";
		 String digitalPortalUserEmailAddress = "mock";
		 
		 testInstance.setCaseId(caseId);
		 testInstance.setComments(comments);
		 testInstance.setContactId(contactId);
		 testInstance.setDigitalPortalUserEmailAddress(digitalPortalUserEmailAddress);
		 testInstance.setDigitalPortalUserName(digitalPortalUserName);
		 testInstance.setFiles(files);
		 testInstance.setIsBusinessResponse(isBusinessResponse);
		 testInstance.setPortalType("Respondent");
		 testInstance.setOrgId(orgId);
		 testInstance.setPackageId(packageId);
		 testInstance.setPnx(pnx);
		 testInstance.setReasonForChange(reasonForChange);
		 testInstance.setSubject(subject);
		 testInstance.setUploadRequestId(uploadRequestId);
		 testInstance.setUserEmail(userEmail);
		 testInstance.setUserId(userId);
		 testInstance.setUserName(userName);
		 testInstance.setUsersAccountIds(usersAccountIds);
		 
		 assertEquals(testInstance.getCaseId(),caseId);
		 assertEquals(testInstance.getComments(),comments);
		 assertEquals(testInstance.getContactId(),contactId);
		 assertEquals(testInstance.getDigitalPortalUserEmailAddress(),digitalPortalUserEmailAddress);
		 assertEquals(testInstance.getDigitalPortalUserName(),digitalPortalUserName);
		 assertEquals(testInstance.getFiles(),files);
		 assertEquals(testInstance.getIsBusinessResponse(),isBusinessResponse);
		 assertEquals(testInstance.getPortalType(),"Respondent");
		 assertEquals(testInstance.getOrgId(),orgId);
		 assertEquals(testInstance.getPackageId(),packageId);
		 assertEquals(testInstance.getPnx(),pnx);
		 assertEquals(testInstance.getReasonForChange(),reasonForChange);
		 assertEquals(testInstance.getSubject(),subject);
		 assertEquals(testInstance.getUploadRequestId(),uploadRequestId);
		 assertEquals(testInstance.getUserEmail(),userEmail);
		 assertEquals(testInstance.getUserId(),userId);
		 assertEquals(testInstance.getUserName(),userName);
		 assertEquals(testInstance.getUsersAccountIds(),usersAccountIds);
		 
		
		 
		 
	}
	
}
