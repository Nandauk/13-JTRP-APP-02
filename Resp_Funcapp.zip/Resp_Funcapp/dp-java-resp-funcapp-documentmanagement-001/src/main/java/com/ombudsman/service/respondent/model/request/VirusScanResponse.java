package com.ombudsman.service.respondent.model.request;

import java.io.Serializable;

import com.ombudsman.service.repondent.model.ContentInformation;

public class VirusScanResponse implements Serializable {

	/**
	* 
	*/
	private static final long serialVersionUID = 1L;
	boolean successful;
	boolean cleanResult;
	boolean containsExecutable;
	boolean containsInvalidFile;
	boolean containsScript;
	boolean containsPasswordProtectedFile;
	boolean containsRestrictedFileFormat;
	boolean containsMacros;
	String verifiedFileFormat;
	String foundViruses;
	String errorDetailedDescription;
	int fileSize;
	ContentInformation contentInformation;
	public boolean getSuccessful() {
		return successful;
	}
	public void setSuccessful(boolean successful) {
		this.successful = successful;
	}
	public boolean getCleanResult() {
		return cleanResult;
	}
	public void setCleanResult(boolean cleanResult) {
		this.cleanResult = cleanResult;
	}
	public boolean getContainsExecutable() {
		return containsExecutable;
	}
	public void setContainsExecutable(boolean containsExecutable) {
		this.containsExecutable = containsExecutable;
	}
	public boolean getContainsInvalidFile() {
		return containsInvalidFile;
	}
	public void setContainsInvalidFile(boolean containsInvalidFile) {
		this.containsInvalidFile = containsInvalidFile;
	}
	public boolean getContainsScript() {
		return containsScript;
	}
	public void setContainsScript(boolean containsScript) {
		this.containsScript = containsScript;
	}
	public boolean getContainsPasswordProtectedFile() {
		return containsPasswordProtectedFile;
	}
	public void setContainsPasswordProtectedFile(boolean containsPasswordProtectedFile) {
		this.containsPasswordProtectedFile = containsPasswordProtectedFile;
	}
	public boolean getContainsRestrictedFileFormat() {
		return containsRestrictedFileFormat;
	}
	public void setContainsRestrictedFileFormat(boolean containsRestrictedFileFormat) {
		this.containsRestrictedFileFormat = containsRestrictedFileFormat;
	}
	public boolean getContainsMacros() {
		return containsMacros;
	}
	public void setContainsMacros(boolean containsMacros) {
		this.containsMacros = containsMacros;
	}
	public String getVerifiedFileFormat() {
		return verifiedFileFormat;
	}
	public void setVerifiedFileFormat(String verifiedFileFormat) {
		this.verifiedFileFormat = verifiedFileFormat;
	}
	public String getFoundViruses() {
		return foundViruses;
	}
	public void setFoundViruses(String foundViruses) {
		this.foundViruses = foundViruses;
	}
	public String getErrorDetailedDescription() {
		return errorDetailedDescription;
	}
	public void setErrorDetailedDescription(String errorDetailedDescription) {
		this.errorDetailedDescription = errorDetailedDescription;
	}
	public int getFileSize() {
		return fileSize;
	}
	public void setFileSize(int fileSize) {
		this.fileSize = fileSize;
	}
	public ContentInformation getContentInformation() {
		return contentInformation;
	}
	public void setContentInformation(ContentInformation contentInformation) {
		this.contentInformation = contentInformation;
	}

	
}