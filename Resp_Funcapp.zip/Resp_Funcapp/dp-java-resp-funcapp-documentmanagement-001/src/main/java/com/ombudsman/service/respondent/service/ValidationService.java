package com.ombudsman.service.respondent.service;

import java.util.List;

import com.ombudsman.service.respondent.model.dto.PostScanningParamsDto;
import com.ombudsman.service.respondent.model.dto.UploadCompletedMessageDto;

public interface ValidationService {

	
	
	public boolean postScanning(PostScanningParamsDto postScanningParams);
	public List<String> preScanning(UploadCompletedMessageDto message);


}
