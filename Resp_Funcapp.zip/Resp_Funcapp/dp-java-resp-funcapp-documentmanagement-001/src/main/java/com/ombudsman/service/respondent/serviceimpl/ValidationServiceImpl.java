package com.ombudsman.service.respondent.serviceimpl;

import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Service;

import com.ombudsman.service.respondent.helper.ValidationServiceHelper;
import com.ombudsman.service.respondent.model.dto.PostScanningParamsDto;
import com.ombudsman.service.respondent.model.dto.ScanResultDto;
import com.ombudsman.service.respondent.model.dto.UploadCompletedMessageDto;
import com.ombudsman.service.respondent.model.dto.UploadFileInfoDto;
import com.ombudsman.service.respondent.service.ValidationService;

@Service
public class ValidationServiceImpl implements ValidationService {

	static Logger log = LogManager.getRootLogger();
	ValidationServiceHelper validationServiceHelper = new ValidationServiceHelper();

	@Override
	public boolean postScanning(PostScanningParamsDto postScanningParams) {
		Boolean okToSendForUpload = false;
		try {
			int count = 0;
			log.info(String.format("postScanning started :: PackageId :-%s", postScanningParams.getPackageId()));
			List<String> badFiles = new ArrayList<>();
			List<String> cleanFiles = new ArrayList<>();
			List<ScanResultDto> scanningResults = postScanningParams.getScanningResults();
			List<ScanResultDto> scanResultDtoList = new ArrayList<>();

			for (ScanResultDto scanResultDto : scanningResults) {
				if (!scanResultDto.getClean()) {
					log.info(String.format("badfile is present "));
					count++;
					badFiles.add(postScanningParams.getPackageId() + "/" + scanResultDto.getDocumentId());
					// validationServiceHelper.moveFolderActivity(postScanningParams.getPackageId());
					// vservice.deleteFilesfromSourceContainer(postScanningParams);
					log.info(String.format("bad file count :-%s", count));
				} else {
					log.info(String.format("Post Scanning inside else   :-%s", count));
					log.info(String.format("PostScanninginside else scanResultDto.getClean()  :-%s",scanResultDto.getClean()));
					log.info(String.format("Document IDs Added inside else  :-%s", scanResultDto.getDocumentId()));
					if (scanResultDto.getClean()) {
						scanResultDtoList.add(scanResultDto);
						log.info(String.format("clean file is present "));
						cleanFiles.add(postScanningParams.getPackageId() + "/" + scanResultDto.getDocumentId());
						log.info(String.format("added clean file successfully  :-%s",postScanningParams.getPackageId() + "/" + scanResultDto.getDocumentId()));
					}
					log.info(String.format("clean file count :-%s", cleanFiles.size()));

				}
			}
			
			if (!badFiles.isEmpty()) {
				log.info(String.format("getting bad file, moving dpfile to quartine container"));
				// int countBadfile = validationServiceHelper.deleteBadFilesfromSourceContainer(badFiles,System.getenv("QUARATINE_CONTAINER"));
				validationServiceHelper.moveFile(cleanFiles, System.getenv("DPFILE_CONTAINER"),
						System.getenv("QUARATINE_CONTAINER"));
				log.info("moveFile dpfile to quartine successfully");
			}
			if (!cleanFiles.isEmpty()) {
				log.info(String.format("getting clean file, moving dpfile to upload container"));
				validationServiceHelper.moveFile(cleanFiles, System.getenv("DPFILE_CONTAINER"),	System.getenv("UPLOAD_CONTAINER"));
				// validationServiceHelper.moveFile(postlist,System.getenv("QUARATINE_CONTAINER"), System.getenv("UPLOAD_CONTAINER"));
				log.info("moveFile dpfile to upload successfully");
			}

			log.info(String.format("bad file  :-%s", badFiles));
			validationServiceHelper.deletefileFromContainer(badFiles, System.getenv("DPFILE_CONTAINER"));
			log.info(String.format("delete bad file From dpfile "));
			log.info(String.format("clean file  :-%s", cleanFiles));
			validationServiceHelper.deletefileFromContainer(cleanFiles, System.getenv("DPFILE_CONTAINER"));
			log.info(String.format("delete clean file From dpfile "));
			int value = validationServiceHelper.prepareForIngestion(postScanningParams,
					System.getenv("UPLOAD_CONTAINER"));
			//postScanningParams.setScanningResults(cleanF)
			postScanningParams.setScanningResults(scanResultDtoList);
			log.info(String.format("PrepareForSendForUploadActivity end  :-%s", value));
			if (value > 0) {
				List<UploadFileInfoDto> baddocument = new ArrayList();
				UploadCompletedMessageDto message = postScanningParams.getMessage();
				List<UploadFileInfoDto> files = message.getFiles();
				if (!files.isEmpty()) {
				for (UploadFileInfoDto uploadFileInfoDto : files) {
					if (!cleanFiles.isEmpty() && cleanFiles.contains(postScanningParams.getPackageId() + "/"+uploadFileInfoDto.getDocumentId())) {
						log.info(String.format("document id is clean  :-%s", uploadFileInfoDto.getDocumentId()));
					} else {
						if (!cleanFiles.isEmpty() && !(cleanFiles.contains(postScanningParams.getPackageId() + "/"+uploadFileInfoDto.getDocumentId()))) {
							log.info(String.format("documentid is not clean  :-%s", uploadFileInfoDto.getDocumentId()));
							baddocument.add(uploadFileInfoDto);
						}
					}
				}
				
					files.removeAll(baddocument);
				}
				message.setFiles(files);
				log.info(String.format("message for postscanning  :-%s", message));
				Boolean ingestionMessageSent = validationServiceHelper.sendPortalActivityAddedMessage(message);
				log.info(String.format("Setting ingestionMessage in postScanningParams Model :-%s",	ingestionMessageSent));
				log.info(String.format("package ID when setIngestionMessageSent  :-%s",	postScanningParams.getPackageId()));
				postScanningParams.setIngestionMessageSent(ingestionMessageSent);
			}
			validationServiceHelper.updateRequest(postScanningParams);
		} catch (Exception ex) {
			log.info(String.format("Error in PostScanning Method :-%s", ex.getMessage()));
		}
		log.info(String.format("PostScanning Method  ended  :-%s", postScanningParams));
		return okToSendForUpload;

	}

	@Override
	public List<String> preScanning(UploadCompletedMessageDto message) {
		log.info(String.format("preScanning Method Started :: package id :-%s", message.getPackageId()));
		validationServiceHelper.removeCancelledFiles(message.getPackageId(), message.getUploadRequestId(),	System.getenv("DPFILE_CONTAINER"));
		// List<String> filesCopiedToUploadContainer = validationServiceHelper.moveFolderActivity(message.getPackageId());
		List<String> filesCopiedToScanContainer = validationServiceHelper.moveFolderToScan(message.getPackageId());
		log.info(String.format("preScanning Method Ended ::filesCopieddpfileToScanContainer :-%s",filesCopiedToScanContainer));
		return filesCopiedToScanContainer;
	}

}
