package com.ombudsman.service.respondent;

import java.beans.Transient;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.microsoft.azure.functions.annotation.FunctionName;
import com.microsoft.azure.functions.annotation.ServiceBusQueueTrigger;
import com.ombudsman.service.repondent.model.CloudmersivePayload;
import com.ombudsman.service.respondent.helper.ValidationServiceHelper;
import com.ombudsman.service.respondent.model.dto.PostScanningParamsDto;
import com.ombudsman.service.respondent.model.dto.ScanResultDto;
import com.ombudsman.service.respondent.model.dto.UploadCompletedMessageDto;
import com.ombudsman.service.respondent.serviceimpl.ValidationServiceImpl;
import com.ombudsman.service.respondent.serviceimpl.VirusScanServiceImpl;

@Component
public class AzureFunction {

	Logger log = LogManager.getRootLogger();
	ValidationServiceImpl validationService = new ValidationServiceImpl();
	VirusScanServiceImpl  virusService =new VirusScanServiceImpl();

	@FunctionName("uploadorchestrator")
	@Transient(true)
	public void runDurableFunc(
			@ServiceBusQueueTrigger(name = "message", queueName = "%QueueName%", connection = "AzureWebJobsServiceBus") String request)
//			@HttpTrigger(name = "req", methods = { HttpMethod.GET,HttpMethod.POST }, authLevel = AuthorizationLevel.ANONYMOUS) final HttpRequestMessage<String> request)
			throws InterruptedException, ExecutionException, IOException {
		
		//convert request data in UploadCompletedMessageDto
		log.info(String.format("Start UploadOrchestrator:-%s", request));
		UploadCompletedMessageDto dto = new UploadCompletedMessageDto();
		dto = new ObjectMapper().readValue(request, UploadCompletedMessageDto.class);
		log.info(String.format("packageid when request recive from scan queue:-%s", dto.getPackageId()));
		//object assign
		CloudmersivePayload payload = new CloudmersivePayload();
		ScanResultDto callActivity = new ScanResultDto();
		List<ScanResultDto> results = new ArrayList<>();
		VirusScanServiceImpl virusScanService = new VirusScanServiceImpl();
		ValidationServiceHelper validationServiceHelper = new ValidationServiceHelper();
		
		List<String> copiedFiles = validationService.preScanning(dto);
		log.info(String.format("copiedFilesFuture:-%s", copiedFiles));
		log.info(String.format("copiedFilesFuture size:-%s", copiedFiles.size()));
		if (!copiedFiles.isEmpty()) {
			payload = virusScanService.initializePayload();
			for (String file : copiedFiles) {
				log.info("********************************");
				payload.setBlobPath(file); // file name - blob name stored in payload *****
				payload.setDocumentId(file.split("/")[1]); // documentid of blob ******
				log.info(String.format("payload blobpath:-%s", payload.getBlobPath()));
				log.info(String.format("payload documentId:-%s", payload.getDocumentId()));
				log.info("Before proceeding to VirusScanClientActivity Method ");
				callActivity = virusService.virusScanClientActivity(payload);
				log.info(String.format("after virusScanClientActivity:-%s", callActivity));
				results.add(callActivity);
				log.info(String.format("results:-%s", results));
			}

//			**** Process all data till now from the above code ****
			PostScanningParamsDto postScanningParams = new PostScanningParamsDto();
			postScanningParams.setMessage(dto);
			postScanningParams.setScanningResults(results);
			postScanningParams.setPackageId(dto.getPackageId());
			validationServiceHelper.deleteFromScanContainer(postScanningParams.getPackageId(), System.getenv("SCAN_CONTAINER"));
			log.info(String.format("before postScanningParams:-%s", postScanningParams));
			Boolean postScanning = validationService.postScanning(postScanningParams);
			postScanningParams.setIngestionMessageSent(postScanning);
			log.info(String.format("after postScanningParams , data added in Ingestion service bus:-%s", postScanningParams));

		}
		log.info("end UploadOrchestrator changes");
	}

	

	
	

	

	
}
