package com.ombudsman.service.respondent.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;
	
@ResponseStatus(HttpStatus.BAD_REQUEST)
public class BlobConnectionURLException extends RespondentsServiceExceptions {

		private static final long serialVersionUID = 1L;

		public BlobConnectionURLException(String message, String exceptionMessage, StackTraceElement[] stackTrace) {
			super(message, "DOCUMENTMANAGEMENT_UPLOAD_DOWNLOAD_INVALID_APIMURL_1004", exceptionMessage, stackTrace);
		}
	}

