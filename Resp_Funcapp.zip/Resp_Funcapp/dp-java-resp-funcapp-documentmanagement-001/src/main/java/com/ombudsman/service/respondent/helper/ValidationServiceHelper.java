package com.ombudsman.service.respondent.helper;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.Duration;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.reactive.function.client.WebClient;

import com.azure.core.amqp.AmqpTransportType;
import com.azure.core.http.rest.PagedIterable;
import com.azure.core.util.polling.LongRunningOperationStatus;
import com.azure.core.util.polling.PollResponse;
import com.azure.core.util.polling.SyncPoller;
import com.azure.identity.ClientSecretCredentialBuilder;
import com.azure.messaging.servicebus.ServiceBusClientBuilder;
import com.azure.messaging.servicebus.ServiceBusMessage;
import com.azure.storage.blob.BlobClient;
import com.azure.storage.blob.BlobContainerClient;
import com.azure.storage.blob.BlobServiceClientBuilder;
import com.azure.storage.blob.models.BlobCopyInfo;
import com.azure.storage.blob.models.BlobItem;
import com.azure.storage.blob.models.ListBlobsOptions;
import com.azure.storage.blob.sas.BlobContainerSasPermission;
import com.azure.storage.blob.sas.BlobServiceSasSignatureValues;
import com.azure.storage.common.sas.SasProtocol;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ombudsman.service.respondent.common.Status;
import com.ombudsman.service.respondent.model.dto.PostScanningParamsDto;
import com.ombudsman.service.respondent.model.dto.ScanResultDto;
import com.ombudsman.service.respondent.model.dto.UploadCompletedMessageDto;
import com.ombudsman.service.respondent.model.dto.UploadRequestFile;
import com.ombudsman.service.respondent.model.request.Uploadrequests;

@Configuration
public class ValidationServiceHelper {

	private static final String SELECT_ID_FROM_DP_UPLOAD_REQUESTS_WHERE_PACKAGE_ID = "SELECT id FROM dp_upload_requests WHERE package_id = ?";
	private static final String SELECT_STATUS_FROM_DP_UPLOAD_REQUESTS_WHERE_ID = "SELECT status,id FROM dp_upload_request_files WHERE upload_request_id = ? and document_id=?";
	private static final String SQLQUERY_TO_FETCH_UPLOAD_ID = "SELECT upload_request_id, status FROM dp_upload_request_files WHERE upload_request_id = ?";
	private static final String SQLQUERY_TO_UPDATE_UPLOAD_ID = "Update dp_upload_request_files SET status = ?,comments = ?,last_updated_time = ? where upload_request_id = ? and id= ?";
	private static final String SQLQUERY_TO_GET_ALLDATA_FROM_CHILDTABLE = "SELECT id, upload_request_id, status, comments, last_updated_time, file_name, document_id, file_size, is_uploaded FROM dp_upload_request_files WHERE upload_request_id = ?";
   
	Logger log = LogManager.getRootLogger();

	public void updateRequest(PostScanningParamsDto dto) {
		log.info(String.format("updateRequest Started :: with package ID  :-%s", dto.getPackageId()));

		Uploadrequests request = new Uploadrequests();

		try {
//			table dp_upload_requests
			Connection conn = connectionjdbc();
			PreparedStatement pstmt = conn.prepareStatement(SELECT_ID_FROM_DP_UPLOAD_REQUESTS_WHERE_PACKAGE_ID);
			pstmt.setString(1, dto.getMessage().getPackageId());

			try (ResultSet rs = pstmt.executeQuery()) {

				while (rs.next()) {

					request.setId(rs.getInt("id"));
					log.info(String.format("updateRequest RS :: get Id from Uploadrequests table :-%s",
							request.getId()));
				}
			} catch (Exception e) {				
				log.info(String.format("catch block one :-%s ", e.getMessage()));
			}
		} catch (Exception e) {			
			log.info(String.format("catch block two ", e.getMessage()));
		}

//		table dp_upload_request_files
		List<UploadRequestFile> fileQuery = new ArrayList<>();
		UploadRequestFile file = new UploadRequestFile();

		try {
			Connection conn = connectionjdbc();
			PreparedStatement pstmt = conn.prepareStatement(SQLQUERY_TO_FETCH_UPLOAD_ID);
			pstmt.setInt(1, request.getId());

			try (ResultSet rs = pstmt.executeQuery()) {

				while (rs.next()) {
					file.setUploadRequestId(rs.getInt("upload_request_id"));
					file.setStatus(rs.getString("status"));
					fileQuery.add(file);
					log.info(String.format("updateRequest RS :: get status from Uploadrequestsfile table :-%s",
							file.getStatus()));
					log.info(String.format("updateRequest RS :: get UploadRequestId from Uploadrequestsfile table :-%s",
							file.getUploadRequestId()));
				}
			} catch (Exception e) {				
				log.info(String.format("catch block one :-%s ", e.getMessage()));
			}
		} catch (Exception e) {			
			log.info(String.format("catch block two :-%s ", e.getMessage()));
		}

		List<String> collect = new ArrayList<>();
		for (UploadRequestFile uploadRequestFile : fileQuery) {
			collect.add(uploadRequestFile.getStatus());
		}
		log.info(String.format("updateRequest activity :: collect :-%s", collect.size()));
		for (String status : collect) {
			request.setStatus(status);

			try {
				Connection conn = connectionjdbc();
				PreparedStatement pstmt = conn.prepareStatement("Update dp_upload_requests SET status= ? WHERE id = ?");
				pstmt.setInt(2, file.getUploadRequestId());
				pstmt.setString(1, file.getStatus());
				log.info(String.format("update status in main table :-%s", file.getStatus()));
				log.info(String.format("upload req id for main table  :-%s", file.getUploadRequestId()));
				pstmt.executeUpdate();
			} catch (Exception e) {				
				log.info(String.format("catch block one :-%s ", e.getMessage()));
			}

		}

	}

	public boolean sendPortalActivityAddedMessage(UploadCompletedMessageDto uploadCompletedMessageDto) {
		log.info(String.format("SendReadyForIngestionMessageActivity Started  :-%s", uploadCompletedMessageDto));
		ObjectMapper objectMapper = new ObjectMapper();
		try {
			uploadCompletedMessageDto.setReasonForChange(140000006);
			String json = objectMapper.writeValueAsString(uploadCompletedMessageDto);
			log.info(String.format("SendReadyForIngestionMessageActivity json :-%s", json));
			log.info(String.format("SendReadyForIngestionMessageActivity :: proceeding to send json to queue "));
			return sendMessageToQueue(json);
		} catch (JsonProcessingException e) {			
			return false;
		}

	}

	public int prepareForIngestion(PostScanningParamsDto postScanningParamsDto, String containerName) {
		log.info(String.format("prepareForIngestion Started  :-%s", postScanningParamsDto));

		Uploadrequests request = new Uploadrequests();

		try {
			Connection conn = connectionjdbc();
			PreparedStatement pstmt = conn.prepareStatement(SELECT_ID_FROM_DP_UPLOAD_REQUESTS_WHERE_PACKAGE_ID);
			pstmt.setString(1, postScanningParamsDto.getPackageId());

			try (ResultSet rs = pstmt.executeQuery()) {

				while (rs.next()) {
					log.info(String.format("RS prepareForIngestion :-%s ", rs));
					request.setId(rs.getInt("id"));
				}
			} catch (Exception e) {
				e.printStackTrace();
				log.info(String.format("error message :-%s ", e.getMessage()));
			}
		} catch (Exception e) {			
			log.info(String.format("error message :-%s ", e.getMessage()));
		}

		List<ScanResultDto> scanningResults = postScanningParamsDto.getScanningResults();
		List<String> cleanFiles = new ArrayList<>();
		
		for (ScanResultDto scanResultDto : scanningResults) {
			int documentId=-1;
			log.info(String.format("scanResultDto :-%s ", scanResultDto));
			try {
				Connection conn = connectionjdbc();
				PreparedStatement pstmt = conn.prepareStatement(SELECT_STATUS_FROM_DP_UPLOAD_REQUESTS_WHERE_ID);
				pstmt.setInt(1, request.getId());
				pstmt.setString(2, scanResultDto.getDocumentId());
				try (ResultSet rs = pstmt.executeQuery()) {
					log.info(String.format("scanResultDto  inside try :-%s ", scanResultDto));
					while (rs.next()) {
						log.info(String.format("RS :-%s ", rs));

						request.setStatus(rs.getString("status"));
						documentId= rs.getInt("id");
						log.info(String.format("request.getStatus() :-%s ", request.getStatus()));
					}
				} catch (Exception e) {
					e.printStackTrace();
					log.info(String.format("error in catch block :-%s ", e.getMessage()));
				}
			} catch (Exception e) {				
				log.info(String.format("line 388 :-%s ", e.getMessage()));
			}

			try {

				log.info(String.format("scanResultDto.getClean()123:-%s ", scanResultDto.getClean()));
				if (scanResultDto.getClean()) {
					Connection conn = connectionjdbc();
					PreparedStatement pstmt = conn.prepareStatement(SQLQUERY_TO_UPDATE_UPLOAD_ID);
					pstmt.setString(1, Status.Passed);
					pstmt.setString(2, scanResultDto.getComment());
					pstmt.setTimestamp(3, new Timestamp(System.currentTimeMillis()));
					pstmt.setInt(4, request.getId());
					pstmt.setInt(5, documentId);

					// update main table
					log.info(String.format("pstmt for update file main table  :-%s ", pstmt));
					pstmt.executeUpdate();
					log.info(String.format("update success  :-%s ", request.getStatus()));

					cleanFiles.add(postScanningParamsDto.getPackageId() + "/" + scanResultDto.getDocumentId());
				} else {
					Connection conn = connectionjdbc();
					PreparedStatement pstmt = conn.prepareStatement(SQLQUERY_TO_UPDATE_UPLOAD_ID);
					pstmt.setString(1, Status.Failed);
					pstmt.setString(2, scanResultDto.getComment());
					pstmt.setTimestamp(3, new Timestamp(System.currentTimeMillis()));
					pstmt.setInt(4, request.getId());
					pstmt.setInt(5, documentId);
					log.info(String.format("pstmt 222 :-%s ", pstmt));
					pstmt.executeUpdate();
					log.info(String.format("update success  :-%s ", request.getStatus()));
				}

			} catch (Exception e) {				
				log.info(String.format("error 229 :-%s ", e.getMessage()));
			}

		}

		int filecount = 0;
		if (!cleanFiles.isEmpty()) {
			filecount = cleanFiles.size();
			int removeFilesNotInList = removeFilesNotInList(postScanningParamsDto.getPackageId(), containerName,
					cleanFiles);
			log.info(String.format("prepareForIngestion removeFilesNotInList  filecount:-%s", removeFilesNotInList));
		}
		log.info(String.format("prepareForIngestion ended  filecount:-%s", filecount));
		return filecount;
	}

	public int processPassedfile(PostScanningParamsDto postScanningParamsDto) {
		log.info(String.format("processPassedfile Started  :-%s", postScanningParamsDto));
		log.info(String.format("processPassedfile getPackageId is   :-%s", postScanningParamsDto.getPackageId()));
		List<ScanResultDto> scanningResults = postScanningParamsDto.getScanningResults();

		List<String> collect = new ArrayList<>();
		for (ScanResultDto scanResultDto : scanningResults) {
			log.info(String.format("processPassedfile scanResultDto is   :-%s", scanResultDto.getClean()));
			if (scanResultDto.getClean()) {
				log.info(String.format("processPassedfile getPackageId is   :-%s",
						postScanningParamsDto.getPackageId()));
				log.info(String.format("processPassedfile scanResultDto.getDocumentId()is   :-%s",
						scanResultDto.getDocumentId()));
				collect.add(postScanningParamsDto.getPackageId() + "/" + scanResultDto.getDocumentId());
				moveFile(collect, System.getenv("QUARATINE_CONTAINER"), System.getenv("UPLOAD_CONTAINER"));
			}
		}

		return collect.size();
	}

	public void deletefileFromContainer(List<String> badFiles, String container) {
		log.info(String.format("deletefileFromContainer Started  size :-%s", badFiles));

		if (CollectionUtils.isNotEmpty(badFiles) && badFiles.size() > 0) {
			log.info(String.format(
					"deletefileFromContainer Method list is not empty- proceeding to Move file Method :-%s", badFiles));
			delFile(badFiles, container);
		}
	}

	public int deleteFromScanContainer(String packageId, String containerName) {
		log.info(String.format("deleteFromScanContainer Method Started  :-%s ", packageId));
		BlobServiceClientBuilder b = new BlobServiceClientBuilder()
				.connectionString(System.getenv("Cloudmersive_ConnectionString"));
		BlobContainerClient containerclient = b.buildClient().getBlobContainerClient(containerName);
		PagedIterable<BlobItem> blobs = containerclient.listBlobs(new ListBlobsOptions().setPrefix(packageId), null);
		log.info(String.format("deleteFromScanContainer Method :: blobs  :-%s", blobs));
		int deletedItems = 0;
		for (BlobItem blob : blobs) {
			deleteBlob(blob.getName(), containerclient);
			deletedItems++;
		}
		return deletedItems;
	}

	public void removeCancelledFiles(String packageId, int uploadRequestId, String containerName) {
		log.info(String.format("start removeCancelledFiles with requestId :-%s ", uploadRequestId));

		List<UploadRequestFile> listfile = new ArrayList<>();
		List<String> documentIds = new ArrayList<>();
		UploadRequestFile file = new UploadRequestFile();
		try {
			Connection conn = connectionjdbc();
			PreparedStatement pstmt = conn.prepareStatement(SQLQUERY_TO_GET_ALLDATA_FROM_CHILDTABLE);
			pstmt.setInt(1, uploadRequestId);
			try (ResultSet rs = pstmt.executeQuery()) {
				while (rs.next()) {
					log.info(String.format("RS :-%s ", rs.getFetchSize())); // fetch size should be 50 count or less
																			// that that
					file.setId(rs.getInt("id"));
					file.setUploadRequestId(rs.getInt("upload_request_id"));
					file.setStatus(rs.getString("status"));
					file.setComments(rs.getString("comments"));
					// request.setLastUpdatedTime(rs.getString("last_updated_time"));
					file.setFileName(rs.getString("file_name"));
					log.info(String.format("FileName :-%s ", file.getFileName()));
					file.setDocumentId(rs.getString("document_id"));
					file.setFileSize(rs.getString("file_size"));
					file.setUploaded(rs.getBoolean("is_uploaded"));

					listfile.add(file);
					documentIds.add(file.getDocumentId());
					log.info(String.format("documentId  :-%s", documentIds));
					log.info(String.format("List Size :-%s ", listfile.size()));
					if (listfile.size() > 50) {
						log.info(String.format("User Exceeds limit of data above 50 "));
					}

				}
			} catch (Exception e) {
				e.printStackTrace();
				log.info(String.format("catch block A :-%s", e.getMessage()));
			}
		} catch (Exception e) {
			e.printStackTrace();
			log.info(String.format("catch block B:-%s", e.getMessage()));
		}
		log.info(String.format("getfile  size :-%s", listfile.size()));
		log.info(String.format("documentIds :-%s", documentIds));
		prepareForMove(containerName, packageId, documentIds);
		log.info(String.format("save in repo "));

	}

	public Connection connectionjdbc() throws SQLException {
		log.info(String.format("inside Connectionjdbc "));
		return DriverManager.getConnection(System.getenv("SQL_DATASOURCE_URL"), System.getenv("SQL_DATASOURCE_USERNAME"),
				System.getenv("SQL_DATASOURCE_PASSWORD"));
	}

	public void prepareForMove(String containerName, String packageId, List<String> documentIds) {
		log.info(String.format("start prepareForMove Method "));

		log.info(String.format("containerName :-%s", containerName));
		log.info(String.format("packageId :-%s", packageId));
		log.info(String.format("documentIds :-%s", documentIds));
		BlobServiceClientBuilder b = new BlobServiceClientBuilder()
				.connectionString(System.getenv("CONNECTION_STRING"));
		BlobContainerClient blobContainerClient = b.buildClient().getBlobContainerClient(containerName);
		log.info(String.format("blobContainerClient {}", blobContainerClient));
		PagedIterable<BlobItem> blobs = blobContainerClient.listBlobs(new ListBlobsOptions().setPrefix(packageId),
				null);

		for (BlobItem blobItem : blobs) {
			log.info(String.format("blobItem :-%s", blobItem));
			BlobClient blobClient = blobContainerClient.getBlobClient(blobItem.getName());
			log.info(String.format("documentIds getting from DB :-%s", documentIds));
			log.info(String.format("documentIds getting from blob :-%s", blobItem.getName().split("/")[1]));
			if (!documentIds.contains(blobItem.getName().split("/")[1])) {
				log.info(String.format("before deleting blob :-%s", blobItem.getName()));
				deleteBlob(blobClient.getBlobName(), blobContainerClient);
				log.info(String.format("deleting blob successfully from dpfile container "));
			}
		}
		log.info(String.format(" prepareForMove method ended"));
	}

	public void deleteBlob(String blobName, BlobContainerClient containerClient) {
		try {
			log.info(String.format("deleteBlob method started {}", blobName));
			BlobClient blobClient = containerClient.getBlobClient(blobName);
			blobClient.delete();
		} catch (Exception e) {
			log.info(String.format("deleteBlob method error {}", e.getMessage()));
		}
		log.info(String.format("deleteBlob method ended {}", blobName));
	}

	public int removeFilesNotInList(String folderPrefix, String containerName, List<String> documentIds) {

		log.info(String.format("removeFilesNotInList Started  :-%s", folderPrefix));
		log.info(String.format("removeFilesNotInList documentIds  :-%s", documentIds));
		BlobServiceClientBuilder b = new BlobServiceClientBuilder()
				.connectionString(System.getenv("CONNECTION_STRING"));
		BlobContainerClient blobContainerClient = b.buildClient().getBlobContainerClient(containerName);
		PagedIterable<BlobItem> blobs = blobContainerClient.listBlobs(new ListBlobsOptions().setPrefix(folderPrefix),
				null);
		log.info(String.format("removeFilesNotInList blobs  :-%s", blobs));
		for (BlobItem blobItem : blobs) {
			log.info(String.format("removeFilesNotInList blobItem  :-%s", blobItem));
			BlobClient blobClient = blobContainerClient.getBlobClient(blobItem.getName());
			log.info(String.format("removeFilesNotInList blobClient  :-%s", blobClient));
			if (!documentIds.contains(blobItem.getName())) {
				log.info(String.format("removeFilesNotInList blobItem.getName()  :-%s", blobItem.getName()));
				deleteBlob(blobClient.getBlobName(), blobContainerClient);
			}
		}
		blobs = blobContainerClient.listBlobs(new ListBlobsOptions().setPrefix(folderPrefix), null);
		log.info(String.format("removeFilesNotInList blobs final  :-%s", blobs.stream().count()));
		return (int) blobs.stream().count();
	}

	public boolean sendMessageToQueue(String jsonMessage) {
		log.info(String.format("sendMessageToQueue started with updated logs"));
		log.info(String.format("sendMessageToQueue method started:-%s", jsonMessage));

		boolean returnValue = false;

		try {
			log.info(String.format("sendMessageToQueue Method in try block :-%s", System.getenv("SB_QUEUE_NAME")));
			new ServiceBusClientBuilder().transportType(AmqpTransportType.AMQP)
					.fullyQualifiedNamespace(System.getenv("FULLY_QULIFIED_NAME_SB"))
					.credential(new ClientSecretCredentialBuilder().tenantId(System.getenv("TANENT_ID_SB"))
							.clientId(System.getenv("CLIENT_ID_SB")).clientSecret(System.getenv("CLIENT_SECRET_SB"))
							.build())
					.sender().queueName(System.getenv("SB_QUEUE_NAME")).buildClient() // in inputqueue in ext sb
					.sendMessage(new ServiceBusMessage(jsonMessage));
			log.info(String.format("sendMessageToQueue end , sand msg sucessfully in input queue :-%s", jsonMessage));
			returnValue = true;
		} catch (Exception e) {
			log.info(String.format("Error in Connectivity of sendMessageToQueue :-%s", e.getMessage()));
			returnValue = false;
		}
		log.info(String.format("sendMessageToQueue Method Ended :-%s", returnValue));
		return returnValue;

	}

	public List<String> moveFolderActivity(String packageId) {
		log.info(String.format("MoveFolderActivity Method started  and packageId is :-%s", packageId));
		try {
			List<String> result = copyFolder(packageId, System.getenv("DPFILE_CONTAINER"),
					System.getenv("QUARATINE_CONTAINER"));
			log.info(String.format("MoveFolderActivity Method ended with packageId:-%s", packageId));
			return result;

		} catch (Exception ex) {
			log.info(String.format("Error in MoveFolderActivity Method  packageId:-%s", packageId));
			log.info(String.format("Error in MoveFolderActivity Method  error message:-%s", ex.getMessage()));
			return new ArrayList<>();
		}
	}

	public List<String> moveFolderToScan(String packageId) {
		log.info(String.format("moveFolderToScan Method started  and packageId is :-%s", packageId));
		try {
			List<String> result = copyFolderToScan(packageId, System.getenv("DPFILE_CONTAINER"),
					System.getenv("SCAN_CONTAINER"));
			log.info(String.format("moveFolderToScan Method ended with packageId:-%s", packageId));
			return result;

		} catch (Exception ex) {
			log.info(String.format("Error in moveFolderToScan Method  packageId:-%s", packageId));
			log.info(String.format("Error in moveFolderToScan Method  error message:-%s", ex.getMessage()));
			return new ArrayList<>();
		}
	}

	public boolean moveFile(List<String> fileNames, String sourceContainerName, String destinationContainerName) {
		log.info(String.format("moveFile Method started:-%s", fileNames));
		for (String fileName : fileNames) {
			log.info(String.format("fileName :-%s", fileName));
			copyFolder(fileName, sourceContainerName, destinationContainerName);
		}
		log.info(String.format("moveFile Method ended :-%s", fileNames));
		return true;
	}

	public boolean delFile(List<String> fileNames, String sourceContainerName) {
		log.info(String.format("delFile Method started   :-%s", fileNames));
		BlobServiceClientBuilder b = new BlobServiceClientBuilder()
				.connectionString(System.getenv("CONNECTION_STRING"));
		BlobContainerClient sourceContainerClient = b.buildClient().getBlobContainerClient(sourceContainerName);
		log.info(String.format("sourceContainerClient :-%s", sourceContainerClient));
		if (!sourceContainerClient.exists()) {
			return false;
		}

		for (String fileName : fileNames) {
			log.info(String.format("fileName :-%s", fileName));
			deleteBlob(fileName, sourceContainerClient);
		}
		log.info(String.format("moveFile Method ended :-%s", fileNames));
		return true;
	}

	public String createSasUri(OffsetDateTime expiryTime, BlobClient blobClient, BlobContainerClient bc) {
		log.info("createSasUri Method Started ");
		BlobContainerSasPermission blobContainerSasPermission = new BlobContainerSasPermission().setReadPermission(true)
				.setWritePermission(true);
		BlobServiceSasSignatureValues builder = new BlobServiceSasSignatureValues(expiryTime,
				blobContainerSasPermission).setProtocol(SasProtocol.HTTPS_ONLY);
		log.info("createSasUri end ");
		return blobClient.getBlobUrl() + "?" + bc.generateSas(builder);

	}

	public List<String> copyFolderToScan(String packageId, String sourceContainer, String destinationContainer) {
		log.info(String.format("copyFolderToScan Method started : with package id :-%s ", packageId));
		BlobServiceClientBuilder dpfile = new BlobServiceClientBuilder()
				.connectionString(System.getenv("CONNECTION_STRING"));
		BlobServiceClientBuilder scan = new BlobServiceClientBuilder()
				.connectionString(System.getenv("Cloudmersive_ConnectionString"));
		BlobContainerClient sourceContainerClient = dpfile.buildClient().getBlobContainerClient(sourceContainer);

		log.info(String.format("copyFolderToScan : sourceContainer :-%s", sourceContainer));
		BlobContainerClient destinationContainerClient = scan.buildClient()
				.getBlobContainerClient(destinationContainer);
		log.info(String.format("copyFolderToScan : destinationContainer :-%s", destinationContainer));

		PagedIterable<BlobItem> blobs = sourceContainerClient.listBlobs(new ListBlobsOptions().setPrefix(packageId),
				null);

		List<String> fileNames = new ArrayList<>();
		for (BlobItem blobItem : blobs) {
			log.info(String.format("copyFolderToScan : blobItem Name() :-%s", blobItem.getName()));
			BlobClient sourceBlobClient = sourceContainerClient.getBlobClient(blobItem.getName());
			log.info(String.format("copyFolderToScan : sourceBlobClient :-%s", sourceBlobClient));

			String sourceBlobUrl = createSasUri(OffsetDateTime.now().plusHours(1), sourceBlobClient,
					sourceContainerClient);
			log.info(String.format("copyFolderToScan : genrate sas url successfully (sourceBlobUrl) :-%s",	sourceBlobUrl));
			BlobClient destinationBlobClient = destinationContainerClient.getBlobClient(blobItem.getName());
			final SyncPoller<BlobCopyInfo, Void> poller = destinationBlobClient.beginCopy(sourceBlobUrl,
					Duration.ofSeconds(2));
			PollResponse<BlobCopyInfo> response = poller.waitUntil(LongRunningOperationStatus.SUCCESSFULLY_COMPLETED);
			log.info(String.format("RESPONSE STATUS from pollresponse : %s", response.getStatus()));
			log.info(String.format("RESPONSE ERROR from pollresponse : %s", response.getValue().getError()));
			log.info(String.format("RESPONSE COPY STATUS from pollresponse : %s", response.getValue().getCopyStatus()));

			log.info(String.format("copyFolderToScan : copied successfully source container to destination for package id :-%s",packageId));
			fileNames.add(blobItem.getName());
		}
		log.info(String.format("copyFolder: dpfileToScan Method ended "));
		return fileNames;
	}

	public List<String> copyFolder(String packageId, String sourceContainer, String destinationContainer) {
		log.info(String.format("copyFolder Method started : with package id :-%s ", packageId));
		BlobServiceClientBuilder b = new BlobServiceClientBuilder()
				.connectionString(System.getenv("CONNECTION_STRING"));
		BlobContainerClient sourceContainerClient = b.buildClient().getBlobContainerClient(sourceContainer);
		log.info(String.format("copyFolder : sourceContainer :-%s", sourceContainer));
		BlobContainerClient destinationContainerClient = b.buildClient().getBlobContainerClient(destinationContainer);
		log.info(String.format("copyFolder : destinationContainer :-%s", destinationContainer));

		PagedIterable<BlobItem> blobs = sourceContainerClient.listBlobs(new ListBlobsOptions().setPrefix(packageId),
				null);

		List<String> fileNames = new ArrayList<>();
		for (BlobItem blobItem : blobs) {
			log.info(String.format("copyFolder : blobItem :-%s", blobItem));
			log.info(String.format("copyFolder : blobItemgetName :-%s", blobItem.getName()));
			BlobClient sourceBlobClient = sourceContainerClient.getBlobClient(blobItem.getName());
			BlobClient destinationBlobClient = destinationContainerClient.getBlobClient(blobItem.getName());
			destinationBlobClient.beginCopy(sourceBlobClient.getBlobUrl(), null);
			log.info(String.format(
					"copyFolder : copied successfully source container to destination for package id :-%s", packageId));
			fileNames.add(blobItem.getName());
		}
		log.info(String.format("Filename size :-%s", fileNames.size()));
		log.info(String.format("Filename listed :-%s", fileNames));
		log.info(String.format("copyFolder Method ended "));
		return fileNames;
	}

	public void uploadSas(String destinationsasurl, String sourcesasurl, BlobItem blobItem) {
		try {
			log.info(String.format("webclient uploadSas stated destination sas url :-%s", destinationsasurl));
			log.info(String.format("webclient uploadSas stated sourceurl :-%s", sourcesasurl));
			log.info(String.format("webclient uploadSas stated  string:-%s", blobItem));
			String block = WebClient.create().put().uri(destinationsasurl).headers(httpHeaders -> {
				httpHeaders.set("x-ms-blob-type", "BlockBlob");
				httpHeaders.set("X-Ms-Blob-Content-Type", "application/octet-stream");
			}).bodyValue(blobItem).retrieve().bodyToMono(String.class).block();
			log.info(String.format("webclient sasurl call  :-%s", block));
		} catch (Exception e) {
			log.info(String.format("webclient sasurl call failed  :-%s", e.getMessage()));
			log.info(String.format("webclient sasurl call failed printstack :-%s", e.getStackTrace()));
		}
	}

}
