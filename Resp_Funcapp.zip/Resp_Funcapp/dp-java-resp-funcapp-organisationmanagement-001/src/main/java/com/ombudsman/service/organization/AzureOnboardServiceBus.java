package com.ombudsman.service.organization;

import java.beans.Transient;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.microsoft.azure.functions.ExecutionContext;
import com.microsoft.azure.functions.annotation.FunctionName;
import com.microsoft.azure.functions.annotation.ServiceBusQueueTrigger;
import com.ombudsman.service.organization.common.SendMailNotification;
import com.ombudsman.service.organization.dao.NotificationDataUpdate;
import com.ombudsman.service.organization.dao.OrganizationOnboardDataAccess;
import com.ombudsman.service.organization.helper.OnboardOrganisationHelper;
import com.ombudsman.service.organization.model.Account;
import com.ombudsman.service.organization.model.AccountResponse;
import com.ombudsman.service.organization.model.OnboardMessage;
import com.ombudsman.service.organization.repository.JDBCConnectionUtil;

public class AzureOnboardServiceBus {

	Logger logger = LogManager.getRootLogger();
	public static final String SUCCESS = "success";
	public static final String FAILURE = "failure";
	public static final String FAILURE_STATUS = "5";
	public static final String SUCCESS_STATUS = "2";
	private static final String ACCOUNTSQL = "SELECT * FROM [dbo].[account] where accountid = ?";

	@FunctionName("organizationOnboardWorker")
	@Transient(true)

	public void organizationOnboardWorkerFunction(
			@ServiceBusQueueTrigger(name = "message", queueName = "%QueueNameOnBoard%", connection = "AzureWebJobsServiceBus") String message,
			final ExecutionContext context) throws IOException {

		/*
		 * public void run(@HttpTrigger(name = "req", methods = {
		 * com.microsoft.azure.functions.HttpMethod.GET,
		 * com.microsoft.azure.functions.HttpMethod.POST }, authLevel =
		 * AuthorizationLevel.ANONYMOUS) final HttpRequestMessage<String> message, final
		 * ExecutionContext context) throws IOException {
		 */

		logger.info("onBoard WorkerFunction Azure Fuction Started. {}", message);
		final OnboardMessage onboardMessage = requestBodyExtractionToOnboardOrgReq(message);

		final OnboardOrganisationHelper onboardOrganisationHelper = new OnboardOrganisationHelper();
		List<Account> organisationFromChlidAccount = new ArrayList<>();
		List<Account> organisationFromAccount;
		final NotificationDataUpdate notificationDataUpdate = new NotificationDataUpdate();
		final SendMailNotification sendMailNotification = new SendMailNotification();

		try {
			List<Account> parentAccount;
			Optional<String> isParentPresent;

			// DB call to fetch data
			final OrganizationOnboardDataAccess organizationOnboardDataAccess = new OrganizationOnboardDataAccess();

			final String accountId = onboardMessage.getAccountId();
			final JdbcTemplate jdbcConnection = JDBCConnectionUtil.getJdbcConnection();
			final NamedParameterJdbcTemplate namedJdbcTemplate = JDBCConnectionUtil.getNamedParameterJdbcConnection();

			final Optional<String> res = organizationOnboardDataAccess.checkOrgPresentInAccount(accountId,
					onboardMessage, jdbcConnection);// checking phoenix for accoint id
			logger.info("resOrgPresentinAd response for 1st query::{}", res);
			Optional<String> resOrgPresentinAd = organizationOnboardDataAccess.checkOrgPresentInADGroup(accountId,
					jdbcConnection);// validation through SQL
			logger.info("resOrgPresentinAd::::::::::::::::::::::{}", resOrgPresentinAd);

			// Flow 1 PBI 2025
			Optional<String> parentCheck = organizationOnboardDataAccess.checkOrgIsParent(accountId, jdbcConnection); // Flow2
																														// if
			logger.info("parentCheck::::::::::::::::::::::::::::::::{}", parentCheck); // true
			// PBI 2025
			String orhpanCheck = organizationOnboardDataAccess.checkOrgIsOrphan(accountId, jdbcConnection);
			logger.info("orhpanCheck::::::::::::::::::::::::::::::::{}", orhpanCheck);
			List<Account> accountList;

			String parentAccountId = organizationOnboardDataAccess.getParentAccountIdIfPresent(accountId,
					jdbcConnection);
			logger.info("parentAccountId::::::::::::::::::::::::::::::::{}", parentAccountId);

			Optional<Account> account = Optional.empty();

			if (StringUtils.isNotEmpty(onboardMessage.getAccountId())) {
				accountList = jdbcConnection.query(ACCOUNTSQL, new AccountResponse(), onboardMessage.getAccountId());
				account = accountList.stream().findFirst();
			}

			// List<Account> accountDtl=
			// organizationOnboardDataAccess.checkIfAccoutIdIsParent(accountId,
			// jdbcConnection);

			if (res.isPresent()) {
				if (resOrgPresentinAd.isEmpty()) {
					logger.info("resOrgPresentinAd.isEmpty()::::::::::::::::::{}", resOrgPresentinAd);

					if (parentCheck.isPresent()) {
						logger.info("parentCheck.isPresent()::::::::::::::::::{}", parentCheck.isPresent());

						parentAccount = organizationOnboardDataAccess.getParentAcc(accountId, namedJdbcTemplate);
						logger.info("parentAccount::::::::::::::::::::::::::::::::{}", parentAccount);

						onboardOrganisation(parentAccount, onboardMessage.getDomainList(),
								onboardMessage.getRequestId(), namedJdbcTemplate, jdbcConnection,
								onboardMessage.getUserEmailId());

						// return "Parent Entity with all childs Onboarded to AD";
						final String notificationDesc = "Parent Entity with all childs Onboarded to AD";
						notificationDataUpdate.updateNotificationData(SUCCESS, onboardMessage.getRequestId(),
								notificationDesc, SUCCESS_STATUS, jdbcConnection);
						sendMailNotification.sendInviteToUserWebclient(onboardMessage, account);

					} else if (StringUtils.isNotEmpty(orhpanCheck)) {
						logger.info("orhpanCheck check::::::::::::::::::{}", orhpanCheck);

						parentAccount = organizationOnboardDataAccess.getParentAcc(accountId, namedJdbcTemplate);
						if (CollectionUtils.isNotEmpty(parentAccount)) {
							onboardOrganisationHelper.onboardOrphonOrgToAD(parentAccount.get(0),
									onboardMessage.getDomainList(), jdbcConnection, onboardMessage.getUserEmailId());
						}

						// return "Organisation Onboarded to AD as Orphan";
						final String notificationDesc = "Organisation Onboarded to AD as Orphan";
						notificationDataUpdate.updateNotificationData(SUCCESS, onboardMessage.getRequestId(),
								notificationDesc, SUCCESS_STATUS, jdbcConnection);
						sendMailNotification.sendInviteToUserWebclient(onboardMessage, account);
					} else {
						logger.info("if not orphan::::::::::::::::::");

						// child account
						Optional<String> parentOfChild = organizationOnboardDataAccess
								.getParentOfChildFromAccount(accountId, jdbcConnection);// acc table
						logger.info("parentOfChild::::::::::::::::::{}", parentOfChild);
						if (parentOfChild.isPresent()) {
							logger.info("Step1::::::::::::::::::{}", parentOfChild);
							isParentPresent = organizationOnboardDataAccess.isParentPresentInAD(parentOfChild.get(),
									jdbcConnection);
							if (isParentPresent.isPresent()) {
								List<Account> accountOfChild = organizationOnboardDataAccess.getChildAccount(accountId,
										jdbcConnection);
								organizationOnboardDataAccess.getOidOfParentAccount(parentOfChild.get(),
										jdbcConnection);

								if (CollectionUtils.isNotEmpty(accountOfChild)) {
									organisationFromChlidAccount.add(accountOfChild.get(0));
								}

								onboardOrganisationHelper.onBoardChildToDigitalPortal(organisationFromChlidAccount,
										onboardMessage.getDomainList(), jdbcConnection,
										onboardMessage.getUserEmailId());

								final String notificationDesc = "Child organization onboarded to AD";
								notificationDataUpdate.updateNotificationData(SUCCESS, onboardMessage.getRequestId(),
										notificationDesc, SUCCESS_STATUS, jdbcConnection);
								sendMailNotification.sendInviteToUserWebclient(onboardMessage, account);

							} else {
								logger.info("Step2::::::::::::::::::{}", parentOfChild);
								parentAccount = organizationOnboardDataAccess.getParentAcc(parentOfChild.get(),
										namedJdbcTemplate);
								logger.info(String.format("attributes for parentAccount details  %s", parentAccount));
								/*
								 * if (null != parentAccount && null !=
								 * parentAccount.get(0).getParentAccountId()) {
								 * onboardOrganisationHelper.onboardParentToDigitalPortal(parentAccount.get(0),
								 * onboardMessage.getDomainList(), onboardMessage.getRequestId(),
								 * jdbcConnection, onboardMessage.getUserEmailId()); // flow 4 }
								 */
								// Onboard the parent organisation
								if (parentAccount != null) {
									onboardOrganisationHelper.onboardTheParentOrganisationDigitalPortal(parentAccount.get(0),
											onboardMessage.getDomainList(), onboardMessage.getRequestId(),
											jdbcConnection, onboardMessage.getUserEmailId()); // flow
								}
								

								organisationFromAccount = organizationOnboardDataAccess
										.getAllAccounts(parentAccount.get(0), namedJdbcTemplate);
								/* fetching all child organisation */
								logger.info(String.format("attributes for parentAccount details  %s",
										organisationFromAccount != null ? organisationFromAccount.get(0).getAccountId()
												: organisationFromAccount));

								onboardOrganisationHelper.onBoardChildToDigitalPortal(organisationFromAccount,
										onboardMessage.getDomainList(), jdbcConnection,
										onboardMessage.getUserEmailId()); /* after parent onboard childs */ // onboard
																											// all

								// return "Child with Parent Entity Onboarded to AD"; //response need to chnage
								final String notificationDesc = "Child with Parent Entity Onboarded to AD";
								notificationDataUpdate.updateNotificationData(SUCCESS, onboardMessage.getRequestId(),
										notificationDesc, SUCCESS_STATUS, jdbcConnection);
								sendMailNotification.sendInviteToUserWebclient(onboardMessage, account);
							}
						} else {
							/*
							 * Notification update with parent account id not present in Phinix
							 * "Organisation doesn't exist in phoenix."
							 */
							logger.info("Step3::::::::::::::::::{}", parentOfChild);
							final String notificationDesc = "parent account id not present in Phoinix";
							notificationDataUpdate.updateNotificationData(FAILURE, onboardMessage.getRequestId(),
									notificationDesc, FAILURE_STATUS, jdbcConnection);
							sendMailNotification.sendInviteToUserWebclient(onboardMessage, account);

						}

					}

				} else {
					/* return "Business Entity Already Present"; */
					logger.info("Step4::::::::::::::::::");
					final String notificationDesc = "Business Entity Already Present";
					notificationDataUpdate.updateNotificationData(FAILURE, onboardMessage.getRequestId(),
							notificationDesc, FAILURE_STATUS, jdbcConnection);
					sendMailNotification.sendInviteToUserWebclient(onboardMessage, account); // messagevfiled-> accoutnt
																								// name- "Business
																								// Entity Already
																								// Present";
					// faliure, 5/ get account name from ABOVE QUERY

				}
			} else {
				/*
				 * Notification update with the message as
				 * "Organisation doesn't exist in phoenix."
				 */
				logger.info("Step5------------");
				final String notificationDesc = "Organisation doesnt exist in phoenix";
				notificationDataUpdate.updateNotificationData(FAILURE, onboardMessage.getRequestId(), notificationDesc,
						FAILURE_STATUS, jdbcConnection);
				sendMailNotification.sendInviteToUserWebclient(onboardMessage, account);

			}

		} catch (Exception ex) {
			logger.info("exception::{}", ex.getMessage());

		}

	}

	private OnboardMessage requestBodyExtractionToOnboardOrgReq(final String message) throws JsonProcessingException {
		OnboardMessage request;
		// String to json conversion of onboard Organisation Request
		ObjectMapper mapper = new ObjectMapper();
		request = mapper.readValue(message, OnboardMessage.class);
		logger.info("scope {}", request);
		return request;
	}

	private void onboardOrganisation(List<Account> parentAccount, String domainList, String reqId,
			NamedParameterJdbcTemplate namedJdbcTemplate, JdbcTemplate jdbcConnection, String emailId) {
		ArrayList<Account> organisationFromAccount;
		final OrganizationOnboardDataAccess organizationOnboardDataAccess = new OrganizationOnboardDataAccess();
		final OnboardOrganisationHelper onboardOrganisationHelper = new OnboardOrganisationHelper();
		String parentOnboarded=null;
		if (CollectionUtils.isNotEmpty(parentAccount)) {
			logger.info("Start organisationFromAccount with account id::::::::::::::::::::::::::::::::{}",
					parentAccount);
			
			organisationFromAccount = (ArrayList<Account>) organizationOnboardDataAccess
					.getAllAccounts(parentAccount.get(0), namedJdbcTemplate); // fetching
			logger.info("End organisationFromAccount::::::::::::::::::::::::::::::::{}", organisationFromAccount);

			/* Onboard parent Organisation to digital portal */
			if(null !=parentAccount.get(0).getParentAccountId()){
			 parentOnboarded=onboardOrganisationHelper.onboardParentToDigitalPortal(parentAccount.get(0), domainList, reqId,
					jdbcConnection, emailId);
			}
			else {
				onboardOrganisationHelper.onboardTheParentOrganisationDigitalPortal(parentAccount.get(0), domainList, reqId, jdbcConnection, emailId);
			}
			// groups.getDomainList() WILL COME FORM SERVICE BUS MESSAGE

			/* add childs only if present */
			if (null != organisationFromAccount) {
				onBoardChildToDigitalPortal(organisationFromAccount, domainList, onboardOrganisationHelper,
						jdbcConnection, emailId);
			}
		}
	}

	private void onBoardChildToDigitalPortal(ArrayList<Account> organisationFromAccount, String domain,
			OnboardOrganisationHelper onboardOrganisationHelper, JdbcTemplate jdbcConnection, String emailId) {
		if (!organisationFromAccount.isEmpty()) {
			onboardOrganisationHelper.onBoardChildToDigitalPortal(organisationFromAccount, domain, jdbcConnection,
					emailId); // flow
			// 2
		}
	}

}