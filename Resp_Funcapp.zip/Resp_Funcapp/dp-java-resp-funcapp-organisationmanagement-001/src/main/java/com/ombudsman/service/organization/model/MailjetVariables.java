package com.ombudsman.service.organization.model;

import com.google.gson.annotations.SerializedName;

public class MailjetVariables {

	@SerializedName("organisationName")
	String organisationName;

	@SerializedName("requestId")
	String requestId;

	@SerializedName("name")
	String name;

	@SerializedName("userEmailId")
	String userEmailId;

	@SerializedName("requestNo")
	String requestNo;
	@SerializedName("fcaId")
	String fcaId;

	public String getRequestNo() {
		return requestNo;
	}

	public void setRequestNo(String requestNo) {
		this.requestNo = requestNo;
	}

	@SerializedName("guidId")
	String guidId;

	public String getFcaId() {
		return fcaId;
	}

	public void setFcaId(String fcaId) {
		this.fcaId = fcaId;
	}

	public String getGuidId() {
		return guidId;
	}

	public void setGuidId(String guidId) {
		this.guidId = guidId;
	}

	public String getOrganisationName() {
		return organisationName;
	}

	public void setOrganisationName(String organisationName) {
		this.organisationName = organisationName;
	}

	public String getRequestId() {
		return requestId;
	}

	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getUserEmailId() {
		return userEmailId;
	}

	public void setUserEmailId(String userEmailId) {
		this.userEmailId = userEmailId;
	}

}
