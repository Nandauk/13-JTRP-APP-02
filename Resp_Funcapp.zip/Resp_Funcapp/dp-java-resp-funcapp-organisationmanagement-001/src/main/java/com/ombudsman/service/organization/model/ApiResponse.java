package com.ombudsman.service.organization.model;

import org.springframework.http.HttpStatusCode;

public class ApiResponse {
	
	public boolean Success ;
    public String Message;
    public HttpStatusCode Status;
    public Object Data;
	
	
	public ApiResponse() {
		super();
	
	}


	public boolean isSuccess() {
		return Success;
	}
	public void setSuccess(boolean success) {
		Success = success;
	}
	public String getMessage() {
		return Message;
	}
	public void setMessage(String message) {
		Message = message;
	}
	public HttpStatusCode getStatus() {
		return Status;
	}
	public void setStatus(HttpStatusCode status) {
		Status = status;
	}
	public Object getData() {
		return Data;
	}
	public void setData(Object data) {
		Data = data;
	}
    
    

}
