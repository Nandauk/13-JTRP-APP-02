package com.ombudsman.service.organization.repository;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

public class JDBCConnectionUtil {
	public static final  Logger logger=LogManager.getRootLogger();

	private JDBCConnectionUtil() {
	}

	
	public static JdbcTemplate getJdbcConnection() {
		JdbcTemplate con;
		DriverManagerDataSource dataSource = getDataSource();
		con = new JdbcTemplate(dataSource);
		logger.info("connection to jdbc:: {} ", con);
		return con;
	}
	public static NamedParameterJdbcTemplate getNamedParameterJdbcConnection() {
		NamedParameterJdbcTemplate con;
		DriverManagerDataSource dataSource = getDataSource();
		con = new NamedParameterJdbcTemplate(dataSource);
		logger.info("connection to jdbc:: {} ", con);
		return con;
	}
	
	private static  DriverManagerDataSource getDataSource() {
		logger.info("dataSource:: {}", System.getenv("SQL_DATASOURCE_URL"));
		DriverManagerDataSource dataSource = new DriverManagerDataSource();
		dataSource.setDriverClassName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
		dataSource.setUrl(System.getenv("SQL_DATASOURCE_URL"));
		dataSource.setUsername(System.getenv("SQL_DATASOURCE_USERNAME"));
		dataSource.setPassword(System.getenv("SQL_DATASOURCE_PASSWORD"));
		return dataSource;
	}
	
	
}