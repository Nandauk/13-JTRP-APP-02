package com.ombudsman.service.organization.model;
//package com.ombudsman.service.respondent.model;
//
//import jakarta.persistence.Column;
//import jakarta.persistence.Entity;
//import jakarta.persistence.Id;
//import jakarta.persistence.Table;
//import jakarta.transaction.Transactional;
//
//@Entity
//@Table(name = "notification")
//@Transactional
//public class NotificationModel {
//
//		@Id
//		@Column(name = "Id")
//		private String Id;
//		private String requestid;
//		private String oid;
//		private String usecase;
//		private String downloadUrl;
//		private String statusUrl;
//		private String status;
//		private String Remark;
//
//		public String getId() {
//			return Id;
//		}
//
//		public void setId(String id) {
//			Id = id;
//		}
//
//		public String getRequestid() {
//			return requestid;
//		}
//
//		public void setRequestid(String requestid) {
//			this.requestid = requestid;
//		}
//
//		public String getOid() {
//			return oid;
//		}
//
//		public void setOid(String oid) {
//			this.oid = oid;
//		}
//
//		public String getUsecase() {
//			return usecase;
//		}
//
//		public void setUsecase(String usecase) {
//			this.usecase = usecase;
//		}
//
//		public String getDownloadUrl() {
//			return downloadUrl;
//		}
//
//		public void setDownloadUrl(String downloadUrl) {
//			this.downloadUrl = downloadUrl;
//		}
//
//		public String getStatusUrl() {
//			return statusUrl;
//		}
//
//		public void setStatusUrl(String statusUrl) {
//			this.statusUrl = statusUrl;
//		}
//
//		public String getStatus() {
//			return status;
//		}
//
//		public void setStatus(String status) {
//			this.status = status;
//		}
//
//		public String getRemark() {
//			return Remark;
//		}
//
//		public void setRemark(String remark) {
//			Remark = remark;
//		}
//
//}
