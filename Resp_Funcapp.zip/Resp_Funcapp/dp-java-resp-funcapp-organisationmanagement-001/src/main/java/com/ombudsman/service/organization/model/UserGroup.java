package com.ombudsman.service.organization.model;


import java.io.Serializable;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "dp_user_group_role_respondent")


public class UserGroup implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name="ad_user_id")	
	private String aduserid;
	
	@Column(name="id_role")	
	private int idrole;
	
	@Column(name="id_group")	
	private int idgroup;

	public UserGroup(String aduserid, int idrole, int idgroup) {
		// TODO Auto-generated constructor stub
		this.aduserid = aduserid;
		this.idrole = idrole;
		this.idgroup = idgroup;
	}

	public UserGroup(String aduserid) {
		this.aduserid = aduserid;
	}

	public String getAduserid() {
		return aduserid;
	}

	public void setAduserid(String aduserid) {
		this.aduserid = aduserid;
	}

	public int getIdrole() {
		return idrole;
	}

	public void setIdrole(int idrole) {
		this.idrole = idrole;
	}

	public int getIdgroup() {
		return idgroup;
	}

	public void setIdgroup(int idgroup) {
		this.idgroup = idgroup;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	
	
}
