package com.ombudsman.service.organization.helper;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.jdbc.core.JdbcTemplate;

import com.ombudsman.service.organization.dao.NotificationDataUpdate;
import com.ombudsman.service.organization.exception.AzureSQLServiceException;
import com.ombudsman.service.organization.exception.AzureServiceException;
import com.ombudsman.service.organization.model.ADGroup;
import com.ombudsman.service.organization.model.Account;
import com.ombudsman.service.organization.repository.ADJDBCGroupRepository;

public class OnboardOrganisationHelper {
	Logger log = LogManager.getRootLogger();

	private static final String ACTIVE = "Active";
	private static final String ENV_PREFIX = System.getenv("envPrefix");

	
	ADJDBCGroupRepository adGroupRepository = new ADJDBCGroupRepository();
	NotificationDataUpdate notification = new NotificationDataUpdate();

	public String onboardParentToDigitalPortal(Account acc, String domain, String reqid, JdbcTemplate jdbcConnection, String emailId)
			throws AzureServiceException {

		// check whether parent account id present in Digital portal table
		Optional<String> isParentPresent = adGroupRepository.checkParentPresentInDigitalPortal(acc.getParentAccountId(),  // acc.getParentAccoutnt()
				jdbcConnection);
		final String adGroupId = getGroupId();
		log.info(String.format("attributes for parentAccount id  %s", acc.getParentAccountId()));
		if (isParentPresent.isEmpty()) {
			final String displayName = "DP-" + ENV_PREFIX + "-" + acc.getParentAccountId();
			adGroupUpdate(acc.getParentAccountId(), domain, adGroupId.toString(), displayName, jdbcConnection,emailId);
			return adGroupId.toString();
		} else {
			final String notificationDesc = "Parent account exists in digital portal";
			notification.updateNotificationData("FAILURE", reqid, notificationDesc, "5", jdbcConnection);
			return null;

		}

	}
	public String onboardTheParentOrganisationDigitalPortal(Account acc, String domain, String reqid, JdbcTemplate jdbcConnection, String emailId)
			throws AzureServiceException {

		// check whether parent account id present in Digital portal table
		Optional<String> isParentPresent = adGroupRepository.checkParentPresentInDigitalPortal(acc.getAccountId(),  // acc.getParentAccoutnt()
				jdbcConnection);
		final String adGroupId = getGroupId();
		log.info(String.format("onboardTheOrganisationDigitalPortal for parentAccount id  %s", acc.getAccountId()));
		if (isParentPresent.isEmpty()) {
			final String displayName = "DP-" + ENV_PREFIX + "-" + acc.getAccountId();
			adGroupUpdate(acc.getAccountId(), domain, adGroupId.toString(), displayName, jdbcConnection,emailId);
			return adGroupId.toString();
		} else {
			final String notificationDesc = "Parent account exists in digital portal";
			notification.updateNotificationData("FAILURE", reqid, notificationDesc, "5", jdbcConnection);
			return null;

		}

	}

	private String getGroupId() {
		final UUID adGroupId = UUID.randomUUID();
		return adGroupId.toString();
	}

	public void adGroupUpdate(String acc, String domain, String oid, String displayName, JdbcTemplate jdbcConnection, String emailId)
			throws AzureSQLServiceException {
		ADGroup adGroup = new ADGroup();
		adGroup.setAdGroupId(oid);
		adGroup.setAdGroupName(displayName);
		adGroup.setDomain(domain);
		adGroup.setPnxGroupId(acc);
		adGroup.setStatus(ACTIVE);
		adGroup.setType("Group");
		adGroupRepository.saveAdGroupDetails(adGroup, jdbcConnection,emailId);
	}	

	public void onBoardChildToDigitalPortal(List<Account> organisationFromAccount, String domain,
			JdbcTemplate jdbcConnection,String emailId) {

		if (!organisationFromAccount.isEmpty()) {
			for (Account acc : organisationFromAccount) {
				if(acc.getAccountId() !=null) {
				final String adGroupId = getGroupId();
				final String displayName = "DP-" + ENV_PREFIX + "-" + acc.getAccountId();
				adGroupUpdate(acc.getAccountId(), domain, adGroupId, displayName, jdbcConnection,emailId);
				}
			}

		}

	}

	public void onboardOrphonOrgToAD(Account acc, String domain, JdbcTemplate jdbcConnection, String emailId) {
		final String adGroupId = getGroupId();
		final String displayName = "DP-" + ENV_PREFIX + "-" + acc.getAccountId();

		adGroupUpdate(acc.getAccountId(), domain, adGroupId, displayName, jdbcConnection,emailId);

	}

}
