package com.ombudsman.service.organization.model;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.UUID;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Entity
@Table(name = "dp_user_dprespondent")

public class UserDpRespondent implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="oid")
	private UUID oid;
	
	@Column(name="full_name")
	private String fullname;
	
	@Column(name="first_name")
	private String firstname;
	
	@Column(name="last_name")
	private String lastname;
	
	@Column(name="email")
	private String email;
	
	@Column(name="user_type")
	private String usertype;
	
	
	@Column(name="invited_status")
	private String invitedstatus;
	
	@Column(name="pnx_flag")
	private String pnxflag;
		
	@Column(name="pnxuuid")
	private UUID pnxuuid;
	
	@Column(name="user_ad_status")
	private String useradstatus;
	
	@Column(name="invited_by")
	private String invitedby;
	
	@Column(name="portal")
	private String portal;
	
	@Column(name="onboarding_organisation_id")
	private Integer onboardingorganisationid;
	
	@Column(name="created_on")
	private LocalDateTime  createdon;
	
	@Column(name="last_updated_on")
	private LocalDateTime lastupdated;

	public UserDpRespondent(UUID oid, String fullname, String firstname, String lastname, String email, String usertype,
			String invitedstatus, String pnxflag, UUID pnxuuid, String useradstatus, String invitedby, String portal, int onboardingorganisationid,
			LocalDateTime createdon, LocalDateTime lastupdated) {
		// TODO Auto-generated constructor stub
		this.oid = oid;
		this.fullname = fullname;
		this.firstname = firstname;
		this.lastname = lastname;
		this.email = email;
		this.usertype = usertype;
		this.invitedstatus = invitedstatus;
		this.pnxflag = pnxflag;
		this.pnxuuid = pnxuuid;
		this.useradstatus = useradstatus;
		this.invitedby = invitedby;
		this.portal = portal;
		this.onboardingorganisationid = onboardingorganisationid;
		this.createdon = createdon;
		this.lastupdated = lastupdated;
	}

	public UserDpRespondent(UUID oid) {
		this.oid = oid;
	}

	public UUID getOid() {
		return oid;
	}

	public void setOid(UUID oid) {
		this.oid = oid;
	}

	public String getFullname() {
		return fullname;
	}

	public void setFullname(String fullname) {
		this.fullname = fullname;
	}

	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getUsertype() {
		return usertype;
	}

	public void setUsertype(String usertype) {
		this.usertype = usertype;
	}

	public String getInvitedstatus() {
		return invitedstatus;
	}

	public void setInvitedstatus(String invitedstatus) {
		this.invitedstatus = invitedstatus;
	}

	public String getPnxflag() {
		return pnxflag;
	}

	public void setPnxflag(String pnxflag) {
		this.pnxflag = pnxflag;
	}

	public UUID getPnxuuid() {
		return pnxuuid;
	}

	public void setPnxuuid(UUID pnxuuid) {
		this.pnxuuid = pnxuuid;
	}

	public String getUseradstatus() {
		return useradstatus;
	}

	public void setUseradstatus(String useradstatus) {
		this.useradstatus = useradstatus;
	}

	public String getInvitedby() {
		return invitedby;
	}

	public void setInvitedby(String invitedby) {
		this.invitedby = invitedby;
	}

	public String getPortal() {
		return portal;
	}

	public void setPortal(String portal) {
		this.portal = portal;
	}

	public Integer getOnboardingorganisationid() {
		return onboardingorganisationid;
	}

	public void setOnboardingorganisationid(Integer onboardingorganisationid) {
		this.onboardingorganisationid = onboardingorganisationid;
	}

	public LocalDateTime getCreatedon() {
		return createdon;
	}

	public void setCreatedon(LocalDateTime createdon) {
		this.createdon = createdon;
	}

	public LocalDateTime getLastupdated() {
		return lastupdated;
	}

	public void setLastupdated(LocalDateTime lastupdated) {
		this.lastupdated = lastupdated;
	}
	

	
}

