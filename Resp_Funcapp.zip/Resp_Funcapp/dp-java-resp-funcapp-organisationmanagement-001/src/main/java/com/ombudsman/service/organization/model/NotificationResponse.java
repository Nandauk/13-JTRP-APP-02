package com.ombudsman.service.organization.model;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class NotificationResponse implements RowMapper<Notification> {

	private Long notification_id;
	private Integer requestId; 
	private String userOid;
	private String requestingActivityName; 
	private Integer notificationStatusId; 
	private String notificationStatusDescription; 
	private String message;
	private String fileDownloadUrl;
	private String createdBy;
	private String modifiedOn;
	private String modifiedBy;
	
		
	public NotificationResponse() {
		// TODO Auto-generated constructor stub
	}


	@Override
	public Notification mapRow(ResultSet rs, int rowNum) throws SQLException {
		// TODO Auto-generated method stub
		return new Notification(
	            rs.getLong("notification_id"),
	            rs.getString("request_id"),
	            rs.getString("user_oid"),
	            rs.getString("requesting_activity_name"),
	            rs.getString("notification_status_id"),
	            rs.getString("notification_status_description"),
	            rs.getString("message"),
	            rs.getString("file_download_url"),
	            rs.getString("created_by"),
	            rs.getString("modified_on"),
	            rs.getString("modified_by")	            
	    );
	}
	
	
}

