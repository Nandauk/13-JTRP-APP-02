package com.ombudsman.service.organization.exception;

public class CaseListNotFoundException extends RuntimeException {
	/**
   * 
   */
  private static final long serialVersionUID = 1L;

  public CaseListNotFoundException(String orgName){
		super(orgName);
	}
}
