package com.ombudsman.service.organization.model;

import java.util.List;

import com.google.gson.annotations.SerializedName;

public class Messages {

	@SerializedName("From")
	private From From;

	@SerializedName("To")
	private List<To> To;

	@SerializedName("TemplateID")
	private int TemplateID;

	@SerializedName("TemplateLanguage")
	private boolean TemplateLanguage;

	
	@SerializedName("Variables")
	MailjetVariables var;
	public MailjetVariables getVar() {
		return var;
	}
 
	public void setVar(MailjetVariables var) {
		this.var = var;
	}


	public void setFrom(From From) {
		this.From = From;
	}

	public From getFrom() {
		return From;
	}

	public void setTo(List<To> To) {
		this.To = To;
	}

	public List<To> getTo() {
		return To;
	}

	public int getTemplateID() {
		return TemplateID;
	}

	public void setTemplateID(int templateID) {
		TemplateID = templateID;
	}

	public void setTemplateLanguage(boolean TemplateLanguage) {
		this.TemplateLanguage = TemplateLanguage;
	}

	public boolean getTemplateLanguage() {
		return TemplateLanguage;
	}

	
}