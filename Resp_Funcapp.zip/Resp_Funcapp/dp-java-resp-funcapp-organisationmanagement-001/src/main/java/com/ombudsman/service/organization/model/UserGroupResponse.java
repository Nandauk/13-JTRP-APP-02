package com.ombudsman.service.organization.model;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

/**
 * @author pravichandran
 *
 */
public class UserGroupResponse implements RowMapper<UserGroup> {

	private String aduserid;
	private int idrole;
	private int idgroup;
	
	
		
	public String getAduserid() {
		return aduserid;
	}



	public void setAduserid(String aduserid) {
		this.aduserid = aduserid;
	}



	public int getIdrole() {
		return idrole;
	}



	public void setIdrole(int idrole) {
		this.idrole = idrole;
	}



	public int getIdgroup() {
		return idgroup;
	}



	public void setIdgroup(int idgroup) {
		this.idgroup = idgroup;
	}



	public UserGroupResponse() {
		// TODO Auto-generated constructor stub
	}

	

	@Override
	public UserGroup mapRow(ResultSet rs, int rowNum) throws SQLException {
		// TODO Auto-generated method stub
		return new UserGroup(
	            rs.getString("ad_user_id")					            
	    );
	}
	
	
}
