package com.ombudsman.service.organization.common;

import java.io.UnsupportedEncodingException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONException;
import org.springframework.http.MediaType;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.WebClient;


import com.google.gson.Gson;

import com.ombudsman.service.organization.exception.MailJetServiceException;
import com.ombudsman.service.organization.model.Account;
import com.ombudsman.service.organization.model.From;
import com.ombudsman.service.organization.model.MailjetResponseBody;
import com.ombudsman.service.organization.model.MailjetVariables;
import com.ombudsman.service.organization.model.Messages;
import com.ombudsman.service.organization.model.OnboardMessage;
import com.ombudsman.service.organization.model.SendMailReq;
import com.ombudsman.service.organization.model.To;


public class SendMailNotification {
	Logger logger = LogManager.getRootLogger();
	private static final boolean TRUE = true;
	
	public void sendInviteToUserWebclient(OnboardMessage onboardMessage, Optional<Account> account) {

		logger.info("SendMailReq code started ");
		try {
			SendMailReq sendMailReq = new SendMailReq();
			List<To> to = new ArrayList<>();
			List<Messages> sendmessage = new ArrayList<>();
			To to1 = new To();
			to1.setEmail(onboardMessage.getEmailId());
			
			to1.setName(onboardMessage.getName());//need to pass name from MS to Service bus
			to.add(to1);

			Messages message = new Messages();
			if (StringUtils.isNotEmpty(onboardMessage.getTemplateId())) {
				message.setTemplateID(Integer.parseInt(onboardMessage.getTemplateId()));
			} else {
				message.setTemplateID(Integer.parseInt(System.getenv("TemplateId")));
			}
			
			MailjetVariables mailJetVar = new MailjetVariables();
			Account acc=null;
			if(account.isPresent()){
				acc=account.get();
			}
			
			logger.info("FCA ID for the onvoard organisation {}",acc);
			if(acc !=null) {
				mailJetVar.setOrganisationName(account.get().getName());
				mailJetVar.setFcaId(account.get().getFosFcareference());
				mailJetVar.setGuidId(account.get().getAccountId());
			}
			
			mailJetVar.setRequestNo(onboardMessage.getRequestId());
			mailJetVar.setUserEmailId(StringUtils.isNotEmpty(onboardMessage.getUserEmailId())?onboardMessage.getUserEmailId(): StringUtils.EMPTY);
			mailJetVar.setRequestId(onboardMessage.getRequestId());
			mailJetVar.setName(StringUtils.isNotEmpty(onboardMessage.getName())?onboardMessage.getName(): StringUtils.EMPTY);
			message.setVar(mailJetVar);			
			message.setTemplateID(Integer.parseInt(onboardMessage.getTemplateId()));			
			message.setTemplateLanguage(TRUE);
			message.setTo(to);

			From from = new From();
			from.setEmail("No-Reply@DigitalSelfServe.Financial-Ombudsman.org.uk");//  from service bus  request id , account name need to  pass
			from.setName("OnBoardOrgNotification");
			message.setFrom(from);
			sendmessage.add(message);
			sendMailReq.setMessages(sendmessage);

			String response = send(sendMailReq);
            logger.info("sendMailReq response {}", response);

			if (response.equals("success")) {
				logger.info("MailJet API call success ::{}", response);
				//responseMessage.setMessage("MailJet API call success :" + response);
			} else {
				//responseMessage.setMessage("MailJet API call failed :" + response);
				logger.info("MailJet API call failed :{}", response);
			}
			logger.info("SendMailReq code  ended ");
		} catch (Exception e) {
			logger.error("Error in Method SendMailReq {}", e.getMessage());
		}
	}



	public String send(SendMailReq req) throws UnsupportedEncodingException, JSONException, ParseException {
		logger.info("Mailjet Send request method started");
		Gson gson = new Gson();
		String json = gson.toJson(req);
		MailjetResponseBody responseBody = new MailjetResponseBody();
		String status = null;
		logger.info("Request data {}" , json);
		final String mailJetUrl=System.getenv("mailjetUrl");
		logger.info("mailjet URL {}" , mailJetUrl);

		try {			
			responseBody = WebClient.create().post().uri(mailJetUrl).body(BodyInserters.fromValue(json))
					.accept(MediaType.APPLICATION_JSON).retrieve().bodyToMono(MailjetResponseBody.class).block();		
			 
			if (responseBody != null) {
				status = responseBody.getMessages().get(0).getStatus();
				logger.info("Response : {}" , status);
			}
		} catch (Exception ex) {
			logger.error("Webclient call failed {}" , ex.getMessage());
			throw new MailJetServiceException("Mailjet Exception occured", ex.getMessage(), ex.getStackTrace());
		}

		logger.info("Response : {}" , responseBody);
		if(null !=responseBody) {
		status = responseBody.getMessages().get(0).getStatus();
		}

		return status;

	}

}
