package com.ombudsman.service.organization.model;

import java.time.OffsetDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.transaction.Transactional;

@Entity
@Table(name = "dp_user_request")
@Transactional
public class RequestModel {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "request_id")
	private Integer requestId;
	@Column(name = "user_oid")
	private String userOid; // notnull
	@Column(name = "requesting_activity_name")
	private String requestingActivityName; // notnull
	@Column(name = "request_status_id")
	private Integer requestStatusId; // notnull
	@Column(name = "request_status_description")
	private String requestStatusDescription; // notnull
	@Column(name = "request_processing_details")
	private String requestProcessingDetails;
	@Column(name = "request_start_time")
	private OffsetDateTime requestStartTime;
	@Column(name = "request_finish_time")
	private OffsetDateTime requestFinishTime; // notnull
	@Column(name = "request_processing_counter")
	private Integer requestProcessingCounter; // notnull
//	@Column(name = "created_on")
//	private OffsetDateTime createdOn; // notnull
	@Column(name = "created_by")
	private String createdBy; // notnull
	@Column(name = "modified_on")
	private String modifiedOn;
	@Column(name = "modified_by")
	private String modifiedBy;

	public Integer getRequestId() {
		return requestId;
	}

	public void setRequestId(Integer requestId) {
		this.requestId = requestId;
	}

	public String getUserOid() {
		return userOid;
	}

	public void setUserOid(String userOid) {
		this.userOid = userOid;
	}

	public String getRequestingActivityName() {
		return requestingActivityName;
	}

	public void setRequestingActivityName(String requestingActivityName) {
		this.requestingActivityName = requestingActivityName;
	}

	public Integer getRequestStatusId() {
		return requestStatusId;
	}

	public void setRequestStatusId(Integer requestStatusId) {
		this.requestStatusId = requestStatusId;
	}

	public String getRequestStatusDescription() {
		return requestStatusDescription;
	}

	public void setRequestStatusDescription(String requestStatusDescription) {
		this.requestStatusDescription = requestStatusDescription;
	}

	public String getRequestProcessingDetails() {
		return requestProcessingDetails;
	}

	public void setRequestProcessingDetails(String requestProcessingDetails) {
		this.requestProcessingDetails = requestProcessingDetails;
	}

	public OffsetDateTime getRequestStartTime() {
		return requestStartTime;
	}

	public void setRequestStartTime(OffsetDateTime requestStartTime) {
		this.requestStartTime = requestStartTime;
	}

	public OffsetDateTime getRequestFinishTime() {
		return requestFinishTime;
	}

	public void setRequestFinishTime(OffsetDateTime requestFinishTime) {
		this.requestFinishTime = requestFinishTime;
	}

	public Integer getRequestProcessingCounter() {
		return requestProcessingCounter;
	}

	public void setRequestProcessingCounter(Integer requestProcessingCounter) {
		this.requestProcessingCounter = requestProcessingCounter;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getModifiedOn() {
		return modifiedOn;
	}

	public void setModifiedOn(String modifiedOn) {
		this.modifiedOn = modifiedOn;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}


}
