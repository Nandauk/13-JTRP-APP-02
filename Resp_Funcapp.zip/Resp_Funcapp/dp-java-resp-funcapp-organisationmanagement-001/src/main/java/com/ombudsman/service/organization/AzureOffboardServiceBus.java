package com.ombudsman.service.organization;

import java.beans.Transient;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONException;
import org.springframework.http.MediaType;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.microsoft.azure.functions.ExecutionContext;
import com.microsoft.azure.functions.annotation.FunctionName;
import com.microsoft.azure.functions.annotation.ServiceBusQueueTrigger;
import com.microsoft.graph.models.User;
import com.ombudsman.service.organization.exception.MailJetServiceException;
import com.ombudsman.service.organization.model.ADGroup;
import com.ombudsman.service.organization.model.ADGroupResponse;
import com.ombudsman.service.organization.model.Account;
import com.ombudsman.service.organization.model.AccountResponse;
import com.ombudsman.service.organization.model.From;
import com.ombudsman.service.organization.model.GetResponseMessage;
import com.ombudsman.service.organization.model.MailjetResponseBody;
import com.ombudsman.service.organization.model.MailjetVariables;
import com.ombudsman.service.organization.model.Messages;
import com.ombudsman.service.organization.model.Notification;
import com.ombudsman.service.organization.model.NotificationResponse;
import com.ombudsman.service.organization.model.OffboardOrganisaitionReq;
import com.ombudsman.service.organization.model.SendMailReq;
import com.ombudsman.service.organization.model.To;
import com.ombudsman.service.organization.model.UserDpRespondent;
import com.ombudsman.service.organization.model.UserDpRespondentResponse;
import com.ombudsman.service.organization.model.UserGroup;
import com.ombudsman.service.organization.model.UserGroupResponse;

public class AzureOffboardServiceBus {

	private static final String ACCOUNTID = "Accountid";
	private static final String RESULTSET_3 = "Resultset_3";
	private static final String RESULTSET_2 = "Resultset_2";
	private static final String RESULTSET_1 = "Resultset_1";
	private static final String PRC_PROCESS_OFF_BOARDING = "prc_ProcessOffBoarding";
	private static final String ACCOUNTSQL = "SELECT * FROM [dbo].[account] where accountid = ?";
	
	private static final String NOTIFICATIONSQL = "update dp_user_notification set notification_status_id= ?,notification_status_description= ?,message= ? where request_id= ?";
	private static final String DP_ORG_ERROR_SQL = "INSERT INTO dbo.dp_org_error (request_id, details, action, group_id, remarks) VALUES (?, ?, ?, ?, ?)";
	private static final String USERGROUPSQL = "SELECT * from dbo.dp_user_group_role_respondent where id_group= ?";
	private static final String DPRESPONDENTSQL = "SELECT * FROM [dbo].[dp_user_dprespondent] where onboarding_organisation_id = ?";
	private static final String ADGROUPSQL = "SELECT * FROM [dbo].[dp_respondent_groups] where pnx_group_id = ? and status = 'Active'";
	private static final String ORGANISATION_OFFBOARDING_PROCESS_FAILED = "Organisation Offboarding Process Failed";
	private static final String JOB = "Job";
	private static final String ORGANISATION_OFFBOARDING_SUCCESS = "Organisation Offboarding Success";
	private static final String READY_FOR_DELIVERY = "ReadyForDelivery";
	private static final String FAILURE = "Failure";
	private static final String ORGANISATION_OFFBOARDING_WITH_PARTIAL_UPDATE = "Organisation Offboarding with Partial Update";
	private static final String PORTAL = "PORTAL";
	private static final String FAILED_FROM_OFFBOARDING = "Failed from Offboarding";
	private static final String DELETE_FROM_AD = "Delete from AD";
	private static final boolean TRUE = true;
	private static final String APIM_URL=System.getenv("APIM_URL");
	
	Logger logger = LogManager.getRootLogger();

	/*
	 * @FunctionName("offboardFunc")
	 * 
	 * @Transient(true) public GetResponseMessage run(@HttpTrigger(name = "req",
	 * methods = { HttpMethod.GET, HttpMethod.POST }, authLevel =
	 * AuthorizationLevel.ANONYMOUS) final HttpRequestMessage<String> message)
	 * throws IOException, SQLException {
	 */

	@FunctionName("offboardFunc")

	@Transient(true)
	public void serviceBusProcessIncident(

			@ServiceBusQueueTrigger(name = "OffBoardOrgTrigger", queueName = "%QueueNameOffBoard%", connection = "AzureWebJobsServiceBus") String message,
			final ExecutionContext context) throws IOException {

		logger.info("OffBoard WorkerFunction Azure Fuction Started. {}", message);

		OffboardOrganisaitionReq request ;
		GetResponseMessage response = new GetResponseMessage();
		logger.info("message {}", message);

		request = requestBodyExtractionToOffboardOrgReq(message);

		JdbcTemplate jdbcTemplate = getJdbcTemplate();

		boolean notificationFlag = false;

		if (request.getType().equalsIgnoreCase(JOB)) {

			offBoardOrganisationByJob(request, jdbcTemplate, notificationFlag, response);
		} else {

			offBoardOrganisationByPortal(request, jdbcTemplate, notificationFlag, response);

		}

		logger.info("offboard Request  ................... {}", request);
		// return response;
	}

	private JdbcTemplate getJdbcTemplate() {

		DriverManagerDataSource dataSource = new DriverManagerDataSource();
		dataSource.setDriverClassName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
		dataSource.setUrl(System.getenv("SQL_DATASOURCE_URL"));
		dataSource.setUsername(System.getenv("SQL_DATASOURCE_USERNAME"));
		dataSource.setPassword(System.getenv("SQL_DATASOURCE_PASSWORD"));
		return new JdbcTemplate(dataSource);
		
	}

	private void sendOffboardOrgNotificationWebclient(OffboardOrganisaitionReq request,
			GetResponseMessage responseMessage, Optional<Account> account) {

		logger.info("SendMailReq code started ");
		try {
			SendMailReq sendMailReq = new SendMailReq();
			List<To> to = new ArrayList<>();
			List<Messages> sendmessage = new ArrayList<>();
			To to1 = new To();
			if (request.getEmailId() != null) {
				to1.setEmail(request.getEmailId());
				
			} else {
				to1.setEmail(System.getenv("ToEmail"));
				
			}
			
			// to1.setName(exportReqModel.getAttributes().getUsers().getFullName());
			to.add(to1);

			Messages message = new Messages();
			if (request.getTemplateId() != null) {
				message.setTemplateID(Integer.parseInt(request.getTemplateId()));
			} else {
				message.setTemplateID(Integer.parseInt(System.getenv("TemplateId")));
			}
			
			message.setTemplateLanguage(TRUE);
			MailjetVariables mailJetVar = new MailjetVariables();
			if(account.isPresent()) {
				mailJetVar.setOrganisationName(account.get().getName());				
				mailJetVar.setFcaId(account.get().getFosFcareference());
				mailJetVar.setGuidId(account.get().getAccountId());
			}
			mailJetVar.setRequestNo(request.getRequestId());
			mailJetVar.setUserEmailId(StringUtils.isNotEmpty(request.getUserEmailId())?request.getUserEmailId(): StringUtils.EMPTY);
			mailJetVar.setRequestId(request.getRequestId());
			mailJetVar.setName(StringUtils.isNotEmpty(request.getName())?request.getName(): StringUtils.EMPTY);
			message.setVar(mailJetVar);		
			
			message.setTo(to);
			From from = new From();
			from.setEmail("No-Reply@DigitalSelfServe.Financial-Ombudsman.org.uk");
			from.setName("OffboardOrgNotification");
			message.setFrom(from);
			sendmessage.add(message);
			sendMailReq.setMessages(sendmessage);

			String response = send(sendMailReq);
			logger.info("sendMailReq response {}", response);

			if (response.equals("success")) {
				responseMessage.setMessage("MailJet API call success :" + response);
			} else {
				responseMessage.setMessage("MailJet API call failed :" + response);
			}
			logger.info("SendMailReq code  ended ");
		} catch (Exception e) {
			logger.error("Error in Method SendMailReq {}", e.getMessage());
		}
	}

	public String send(SendMailReq req) throws  JSONException {
		logger.info("Mailjet Send request method started ================ {}", req);
		Gson gson = new Gson();
		String json = gson.toJson(req);
		MailjetResponseBody responseBody = new MailjetResponseBody();
		String status = null;
		logger.info("Request data {}================", json);

		try {
			responseBody = WebClient.create().post().uri(System.getenv("mailjetUrl")).body(BodyInserters.fromValue(json))
					.accept(MediaType.APPLICATION_JSON).retrieve().bodyToMono(MailjetResponseBody.class).block();
			if (responseBody != null) {
				status = responseBody.getMessages().get(0).getStatus();
				logger.info("Response : {}", status);
			}
		} catch (Exception ex) {
			logger.error("Webclient call failed {}", ex.getMessage());
			throw new MailJetServiceException("Mailjet Exception occured", ex.getMessage(), ex.getStackTrace());
		}

		logger.info("Response : {}", responseBody);
		if(null !=responseBody) {
		status = responseBody.getMessages().get(0).getStatus();
		}

		return status;

	}

	private void offBoardOrganisationByPortal(OffboardOrganisaitionReq request,
			JdbcTemplate jdbcTemplate, boolean notificationFlag, GetResponseMessage response) {

		final SimpleJdbcCall simpleJdbcCall = new SimpleJdbcCall(jdbcTemplate)

				.withProcedureName(PRC_PROCESS_OFF_BOARDING)

				.returningResultSet(RESULTSET_1, new UserGroupResponse())
				.returningResultSet(RESULTSET_2, new UserDpRespondentResponse())
				.returningResultSet(RESULTSET_3, new ADGroupResponse());

		logger.info("simpleJdbcCall: {}", simpleJdbcCall);

		SqlParameterSource in = new MapSqlParameterSource().addValue(ACCOUNTID, request.getAccountId());
		logger.info("in : {}", in);

		logger.info("getOffBoardOrganisationByPortal method parameteres passing to Store procedure");
		logger.info("calling SP of getOffBoardOrganisationByPortal account id : {}",ACCOUNTID);
		Map<String, Object> out = simpleJdbcCall.execute(in);

		List<UserGroup> userGroupResponse = (List<UserGroup>) out.get(RESULTSET_1);

		List<UserDpRespondent> userDpRespondentResponse = (List<UserDpRespondent>) out.get(RESULTSET_2);

		List<ADGroup> adGroups = (List<ADGroup>) out.get(RESULTSET_3);
		logger.info("Result 3: {}",adGroups);
		List<String> aDGroupList=new ArrayList<>();
		for(ADGroup adGroup: adGroups) {
			if(StringUtils.isNotEmpty(adGroup.getAdGroupId())){
				aDGroupList.add(adGroup.getAdGroupId());
			}			
		}
		
		logger.info("Result 4: {}",aDGroupList);

		

		

		List<Notification> notificationList =null;

		Optional<Notification> notification = Optional.empty();

		if (!aDGroupList.isEmpty()) {

			if (request.getRequestId() != null) {

				String notificationSelectSql = "SELECT * FROM [dbo].[dp_user_notification] where request_id = ?";

				notificationList = jdbcTemplate.query(notificationSelectSql,
						new NotificationResponse(), request.getRequestId());

				notification = notificationList.stream().findFirst();

			}

			notificationDeletionProcess(aDGroupList, userDpRespondentResponse,  jdbcTemplate, request,
					notificationFlag, notification, response);

		} else {

			logger.info("account not onboarded in Digital Portal****************");
			response.setMessage("Account not onboarded into Digital Portal for the " + request.getAccountId());
		}

	}
	

	private OffboardOrganisaitionReq requestBodyExtractionToOffboardOrgReq(final String message)
			throws JsonProcessingException{
		OffboardOrganisaitionReq request;
		// String to json conversion of offboard Organisation Request
		ObjectMapper mapper = new ObjectMapper();
		request = mapper.readValue(message, OffboardOrganisaitionReq.class);
		logger.info("scope {}", request);
		return request;
	}

	private void offBoardOrganisationByJob(OffboardOrganisaitionReq request,
			JdbcTemplate jdbcTemplate, boolean notificationFlag, GetResponseMessage response){

		List<ADGroup> adGroupResponse = jdbcTemplate.query(ADGROUPSQL, new ADGroupResponse(),
				request.getAccountId());

		logger.info("JDBC template Id 1==================={}"
				, adGroupResponse.stream().map(ADGroup::getId).findFirst());

		Optional<Integer> sqlGroupId = adGroupResponse.stream().map(ADGroup::getId).findFirst();
		List<String> sqlAdGroupId = adGroupResponse.stream().map(ADGroup::getAdGroupId).collect(Collectors.toList());

		if (!sqlGroupId.isEmpty()) {

			Optional<Notification> notification = Optional.empty();

			List<UserDpRespondent> userDpRespondentResponse = jdbcTemplate
					.query(DPRESPONDENTSQL, new UserDpRespondentResponse(), sqlGroupId.get());

			logger.info("JDBC template Id 2 Size==================={}" , userDpRespondentResponse.size());

			for (UserDpRespondent userDpRespondent : userDpRespondentResponse) {

				logger.info("JDBC template Id 2==================={}" , userDpRespondent.getOid());
			}

			List<UserGroup> userGroupResponse = jdbcTemplate.query(USERGROUPSQL,
					new UserGroupResponse(), sqlGroupId.get());

			logger.info("JDBC template Id 3 Size==================={}" , userGroupResponse.size());

			for (UserGroup userGroup : userGroupResponse) {

				logger.info("JDBC template Id 3==================={}",userGroup.getAduserid());
			}

			notificationDeletionProcess(sqlAdGroupId, userDpRespondentResponse,  jdbcTemplate, request,
					notificationFlag, notification, response);

		} else {
			logger.info("account not onboarded in Digital Portal****************");
			response.setMessage("Account not onboarded into Digital Portal for the " + request.getAccountId());
		}

	}

	private void notificationDeletionProcess(List<String> sqlAdGroupIds,
			List<UserDpRespondent> userDpRespondentResponse, 
			JdbcTemplate jdbcTemplate, OffboardOrganisaitionReq request, boolean notificationFlag,
			Optional<Notification> notification, GetResponseMessage response) {
		try {
			int count = 0;
			int maxTries = 3;
			

			for (String sqlAdGroupId : sqlAdGroupIds) {

				/*
				 * for (UserGroup userGroup : userGroupResponse) {
				 * 
				 * try { DirectoryObject groups = graphClient.groups().byId(sqlAdGroupId.get())
				 * .members(userGroup.getAduserid()).buildRequest().get();
				 * 
				 * logger.info("Groups ============ ", groups.id); } catch (Exception e) {
				 * e.printStackTrace(); }
				 * 
				 * // graphClient.groups().byId(sqlAdGroupId.toString()).memberOf(userGroup.
				 * getAduserid()).buildRequest().delete(); }
				 */

				updateNotiicationforDeletion(Optional.of(sqlAdGroupId), jdbcTemplate, request,
						notification);

				

				/*
				 * updateNotification(userDpRespondentResponse, count, jdbcTemplate, request,
				 * notificationFlag, notification);
				 */
				
				graphClientDPRespondentDeletion(userDpRespondentResponse, count,
						maxTries, jdbcTemplate, Optional.of(sqlAdGroupId), request, notificationFlag, notification);


			
				logger.info("sqlAdGroupId.toString()============== {}", sqlAdGroupId);
				

			}

			

			List<Account> accountList;

			Optional<Account> account = Optional.empty();

			if (request.getAccountId() != null) {

				accountList = jdbcTemplate.query(ACCOUNTSQL, new AccountResponse(),
						request.getAccountId());

				account = accountList.stream().findFirst();

			}

			sendOffboardOrgNotificationWebclient(request, response, account);
		}

		catch (Exception e) {

			logger.info("Error in connection of Azure Ad {}", e.getMessage());
			
			if (request.getType().equalsIgnoreCase(JOB)) {
				jdbcTemplate.update(DP_ORG_ERROR_SQL, request.getAccountId() + "_JOB",
						userDpRespondentResponse.get(0).getOid().toString(), DELETE_FROM_AD,
						sqlAdGroupIds.get(0), FAILED_FROM_OFFBOARDING);
			} else {
				jdbcTemplate.update(DP_ORG_ERROR_SQL, request.getRequestId(),
						userDpRespondentResponse.get(0).getOid().toString(), DELETE_FROM_AD,
						sqlAdGroupIds.get(0), FAILED_FROM_OFFBOARDING);
			}

		}
	}
	private void graphClientDPRespondentDeletion(List<UserDpRespondent> userDpRespondentResponse,
			 int count,
			int maxTries, JdbcTemplate jdbcTemplate, Optional<String> sqlAdGroupId, OffboardOrganisaitionReq request,
			boolean notificationFlag, Optional<Notification> notification) {

		
		for (int i = 0; i < userDpRespondentResponse.size(); i++) {

			try {
				
				deleteUserfromB2C(userDpRespondentResponse.get(i).getOid().toString());				
				

			} catch (Exception e) {
				String adGpId = null;
				logger.info("error form graph api {}", e.getMessage());
				
					while (count <= maxTries) {
						if (count >= maxTries) {
							// error table entry
							if (sqlAdGroupId.isPresent()) {
								adGpId = sqlAdGroupId.get();
							}
							if (request.getType().equalsIgnoreCase(JOB) && null !=adGpId && null !=userDpRespondentResponse.get(i).getOid()) {

								jdbcTemplate.update(DP_ORG_ERROR_SQL, request.getAccountId() + "_JOB",
										userDpRespondentResponse.get(i).getOid().toString(), DELETE_FROM_AD, adGpId,
										FAILED_FROM_OFFBOARDING);
							} else {
								jdbcTemplate.update(DP_ORG_ERROR_SQL, request.getRequestId(),
										userDpRespondentResponse.get(i).getOid().toString(), DELETE_FROM_AD, adGpId,
										FAILED_FROM_OFFBOARDING);
							}
							logger.info("Inside Catch block {}", count);
							count = 0;
							notificationFlag = true;
							break;
						} else {
							try {
								logger.info(String.format("user to delete from azure   %s", userDpRespondentResponse.get(i).getOid()));							
								
								logger.info("user to delete {}",userDpRespondentResponse.get(i).getOid());
								deleteUserfromB2C(userDpRespondentResponse.get(i).getOid().toString());
								count = 0;
								break;
							} catch (Exception ex) {	
								logger.info(String.format("unable to update  %s", e.getMessage()));							
								logger.info("Inside Catch block with count value {} value{} ", count, i);
								count++;
							}
						}
					}
				
			}
		}
			
		}

		private void deleteUserfromB2C(String userId) {
			logger.info("deleteUserfromB2C APIM call started ");

			String url = APIM_URL + "/respgraphapi/users/" + userId;
			logger.info(String.format("user to delete   %s", userId));

			try {
				if (StringUtils.isNotEmpty(getUserFromAd(userId))) {
					WebClient.create().delete().uri(url).accept(MediaType.APPLICATION_JSON).retrieve()
							.bodyToMono(User.class).block();
					logger.info(String.format("deleteUserfromB2C userdata deleted for OID %s ", userId));
				}
			} catch (Exception e) {
				logger.info("API call failed: {}", e.getMessage());

			}
			logger.info("deleteUserfromB2C APIM call ended ");

		}
		public String getUserFromAd(String userId) {
			logger.info("getUserFromAd APIM call started ");
			
			String url = APIM_URL+"/respgraphapi/users/" + userId;
			User userData=null;
			try {
				userData=WebClient.create().get().uri(url)
						.accept(MediaType.APPLICATION_JSON).retrieve().bodyToMono(User.class).block();
				logger.info(String.format("getUserFromAd  for OID %s ",  userData.id));
			} catch (Exception e) {
				logger.info("User already deleted or user is not present in Azure AD: {}",  e.getMessage());
				return null;
			}
			logger.info("getUserFromAd APIM call ended ");
			return userData.id;

		}

	/*private void updateNotification(List<UserDpRespondent> userDpRespondentResponse,
			 int count,
			JdbcTemplate jdbcTemplate, OffboardOrganisaitionReq request,
			boolean notificationFlag, Optional<Notification> notification) {

		
		
		logger.info("Notification flag value before exiting the metod {} ", notificationFlag);

		if (notificationFlag && request.getType().equalsIgnoreCase(PORTAL)) {

			logger.info("Notification Flag within if block**************** {}", notificationFlag);

			if (!notification.isEmpty()) {

				notification.get().setNotificationStatusId("5");
				notification.get().setNotificationStatusDescription(FAILURE);
				notification.get().setMessage(ORGANISATION_OFFBOARDING_WITH_PARTIAL_UPDATE);

				notificationJdbcCall(notification.get(), jdbcTemplate);
			}
		}
	}*/

	private void updateNotiicationforDeletion(Optional<String> sqlAdGroupId,
			JdbcTemplate jdbcTemplate,
			OffboardOrganisaitionReq request, Optional<Notification> notification) {

		try {
			

			if (!notification.isEmpty()) {

				notification.get().setNotificationStatusId("2");
				notification.get().setNotificationStatusDescription(READY_FOR_DELIVERY);
				notification.get().setMessage(ORGANISATION_OFFBOARDING_SUCCESS);

				notificationJdbcCall(notification.get(), jdbcTemplate);
			}

		} catch (Exception e1) {
			int count = 0;
			int maxTries = 3;
			while (count <= maxTries) {
				if (count >= maxTries) {
					
					// error table entry
					if (request.getType().equalsIgnoreCase(JOB)) {
						jdbcTemplate.update(DP_ORG_ERROR_SQL, request.getAccountId() + "_JOB", "", DELETE_FROM_AD,
								sqlAdGroupId.get(), FAILED_FROM_OFFBOARDING);
					} else {
						jdbcTemplate.update(DP_ORG_ERROR_SQL, request.getRequestId(), "", DELETE_FROM_AD,
								sqlAdGroupId.get(), FAILED_FROM_OFFBOARDING);
					}
					logger.info("Inside Catch block third result set ==========={}",count);

					if (!notification.isEmpty()) {

						notification.get().setNotificationStatusId("5");
						notification.get().setNotificationStatusDescription(FAILURE);
						notification.get().setMessage(ORGANISATION_OFFBOARDING_PROCESS_FAILED);

						notificationJdbcCall(notification.get(), jdbcTemplate);
					}					
					break;

				} else {
					try {
						

						if (!notification.isEmpty()) {

							notification.get().setNotificationStatusId("2");
							notification.get().setNotificationStatusDescription(READY_FOR_DELIVERY);
							notification.get().setMessage(ORGANISATION_OFFBOARDING_SUCCESS);

							notificationJdbcCall(notification.get(), jdbcTemplate);
						}						
						break;
					} catch (Exception e2) {						
						logger.info("Inside Catch block with count value ={} ", count);
						count++;
					}
				}
			}
		}

	}

	private void notificationJdbcCall(Notification notification, JdbcTemplate jdbcTemplate) {
		logger.info("notificationJdbcCall method started ");

		try {

			Object[] paramNotification = new Object[] { notification.getNotificationStatusId(),
					notification.getNotificationStatusDescription(), notification.getMessage(),
					notification.getRequestId() };
			logger.info("paramNotification {}", paramNotification);

			logger.info("sql : {}", NOTIFICATIONSQL);

			jdbcTemplate.update(NOTIFICATIONSQL, paramNotification);
			logger.info("Notification data updated in Database : {}", jdbcTemplate);

		} catch (Exception e) {
			logger.error("Error in notification {}", e.getMessage());
		}
		logger.info("notificationJdbcCall method Ended ");
	}

	
}
