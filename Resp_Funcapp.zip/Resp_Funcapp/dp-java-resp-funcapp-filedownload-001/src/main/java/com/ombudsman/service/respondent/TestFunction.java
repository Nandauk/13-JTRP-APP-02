package com.ombudsman.service.respondent;

public class TestFunction {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		FileDownloadFunction testFunc = new FileDownloadFunction();
		//testFunc.test();
	}

}
