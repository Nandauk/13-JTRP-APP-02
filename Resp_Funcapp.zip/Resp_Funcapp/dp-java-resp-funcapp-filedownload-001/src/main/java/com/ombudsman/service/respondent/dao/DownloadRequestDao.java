package com.ombudsman.service.respondent.dao;

import java.sql.SQLException;
import java.util.List;
import java.util.UUID;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;

import com.ombudsman.service.respondent.model.AuditMaster;
import com.ombudsman.service.respondent.model.FailedDownloadRequest;
import com.ombudsman.service.respondent.model.FailedDownloadRequestFiles;
import com.ombudsman.service.respondent.model.NotificationModel;

public interface DownloadRequestDao {

	List<FailedDownloadRequest> getFailedRequests(Boolean timeZoneFlag,JdbcTemplate jdbcTemplate) throws DataAccessException, SQLException;

	List<FailedDownloadRequestFiles> getFailedRequestFilesDetail(String requestId,JdbcTemplate jdbcTemplate)
			throws DataAccessException, SQLException;

	int postNotification(NotificationModel notifyModel,JdbcTemplate jdbcTemplate) throws SQLException;

	void postAudityEntity(AuditMaster auditMaster,JdbcTemplate jdbcTemplate) throws SQLException;

	void updateProcessingCounter(UUID requestId, int processingCounetr,JdbcTemplate jdbcTemplate) throws SQLException;
	
}
