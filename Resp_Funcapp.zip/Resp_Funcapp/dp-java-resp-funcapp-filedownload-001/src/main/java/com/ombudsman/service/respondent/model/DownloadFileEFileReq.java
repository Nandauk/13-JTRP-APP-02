package com.ombudsman.service.respondent.model;

import java.util.List;

public class DownloadFileEFileReq {

	private String caseId;
	private boolean isRespondent;
	private List<DownloadRequestItem> files;
	private String orgId;
	private String requestId;
	private String notificationId;
	public String getCaseId() {
		return caseId;
	}
	public void setCaseId(String caseId) {
		this.caseId = caseId;
	}
	public boolean getIsRespondent() {
		return isRespondent;
	}
	public void setIsRespondent(boolean isRespondent) {
		this.isRespondent = isRespondent;
	}
	public List<DownloadRequestItem> getFiles() {
		return files;
	}
	public void setFiles(List<DownloadRequestItem> files) {
		this.files = files;
	}
	public String getOrgId() {
		return orgId;
	}
	public void setOrgId(String orgId) {
		this.orgId = orgId;
	}
	public String getRequestId() {
		return requestId;
	}
	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}
	public String getNotificationId() {
		return notificationId;
	}
	public void setNotificationId(String notificationId) {
		this.notificationId = notificationId;
	}
}
