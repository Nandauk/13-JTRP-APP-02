package com.ombudsman.service.respondent.model;

public class DownloadRequestItem {
	private String documentId;

	public String getDocumentId() {
		return documentId;
	}

	public void setDocumentId(String documentId) {
		this.documentId = documentId;
	}
	  
	 public  DownloadRequestItem(String documentId)
	 {
		 this.setDocumentId(documentId);
	 }
}
