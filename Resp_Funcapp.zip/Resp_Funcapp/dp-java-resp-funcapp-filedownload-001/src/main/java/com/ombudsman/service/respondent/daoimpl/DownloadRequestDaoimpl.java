package com.ombudsman.service.respondent.daoimpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;

import com.ombudsman.service.respondent.dao.DownloadRequestDao;
import com.ombudsman.service.respondent.model.AuditMaster;
import com.ombudsman.service.respondent.model.FailedDownloadRequest;
import com.ombudsman.service.respondent.model.FailedDownloadRequestFiles;
import com.ombudsman.service.respondent.model.NotificationModel;
import com.ombudsman.service.respondent.repository.JDBCConnectionUtil;

public class DownloadRequestDaoimpl implements DownloadRequestDao{
	
	Logger log = LogManager.getRootLogger();

	/*public static final String GET_FAILED_REQUEST_UTC="select ntc.request_id requestId,request_processing_counter,ntc.notification_id notificationId from dp_user_notification ntc,dp_user_request user_req where ntc.request_id = user_req.request_id and ntc.requesting_activity_name='caseDownload' and notification_status_id in(11,13) and DATEDIFF(second,ntc.created_on,GETDATE())<82800 and request_processing_counter <=3";
	public static final String GET_FAILED_REQUEST ="select ntc.request_id requestId,request_processing_counter from dp_user_notification ntc,dp_user_request user_req where ntc.request_id = user_req.request_id and ntc.requesting_activity_name='caseDownload' and notification_status_description='Failed' and DATEDIFF(second,ntc.created_on,GETDATE())<86400 and request_processing_counter <=3";*/
	public static final String GET_FAILED_REQUEST_UTC = "select download_req.id requestId,request_processing_counter,(select top(1) notification_id from dp_user_notification ntc where ntc.request_id = download_req.id order by notification_id desc) as notificationId,download_req.user_id userId from dp_download_requests download_req,dp_user_request user_req where download_req.id = user_req.request_id and download_req.status='ToBeProcessedByJob' and DATEDIFF(second,download_req.created,GETDATE())<82800 and request_processing_counter <=3 and not exists (select 1 from dp_user_notification notif where notif.request_id=download_req.id and notif.notification_status_description ='Pending' )";
    public static final String GET_FAILED_REQUEST = "select download_req.id requestId,request_processing_counter,(select top(1) notification_id from dp_user_notification ntc where ntc.request_id = download_req.id order by notification_id desc) as notificationId,download_req.user_id userId from dp_download_requests download_req,dp_user_request user_req where download_req.id = user_req.request_id and download_req.status='ToBeProcessedByJob' and DATEDIFF(second,download_req.created,GETDATE())<86400 and request_processing_counter <=3 and not exists (select 1 from dp_user_notification notif where notif.request_id=download_req.id and notif.notification_status_description ='Pending' )";
	public static final String GET_FAILED_REQUEST_FILES_DETAIL = "select case_id,document_id,(select ticketnumber from incident where incidentid = case_id) ticketNumber  from dp_download_requests request,dp_download_request_items request_item where request.id = request_item.download_request_id and request.id=? and url is null";
	public static final String DP_USER_NOTIFICATION_INSERT = "INSERT INTO dp_user_notification (request_id,user_oid,requesting_activity_name,notification_status_id,notification_status_description,message,created_on,created_by) values (?,?,?,?,?,?,?,?)";
	public static final String DP_AUDIT_EVENT_INSERT = "INSERT INTO DP_AUDIT_EVENT (user_oid,audit_event_timestamp,audit_event_name,primary_audit_entity,primary_audit_entity_identifier,pre_audit_snapshot,post_audit_snapshot,created_on,created_by) VALUES (?,?,?,?,?,?,?,?,?)";
	public static final String DP_USER_REQUEST_UPDATE = " UPDATE DP_USER_REQUEST SET REQUEST_PROCESSING_COUNTER=? WHERE REQUEST_ID=?";

	JDBCConnectionUtil jdbcConnectionUtil;
	@Override
	public List<FailedDownloadRequest> getFailedRequests(Boolean timeZoneFlag,JdbcTemplate jdbcTemplate)
			throws DataAccessException, SQLException {

		List<FailedDownloadRequest> requests = new ArrayList<>();
		String strQuery = "";
		if (timeZoneFlag) {
			strQuery = GET_FAILED_REQUEST_UTC;
		} else {
			strQuery = GET_FAILED_REQUEST;
		}

		requests = jdbcTemplate.query(strQuery, (rs, rowNum) -> new FailedDownloadRequest(rs.getString("requestId"),
				rs.getString("request_processing_counter"),rs.getString("notificationId"),rs.getString("userId")));

		return requests;
	}

	@Override
	public List<FailedDownloadRequestFiles> getFailedRequestFilesDetail(String requestId,JdbcTemplate jdbcTemplate)
			throws DataAccessException, SQLException {

		List<FailedDownloadRequestFiles> failedFilesDetail = new ArrayList<>();
		String strQuery = GET_FAILED_REQUEST_FILES_DETAIL;
		
		failedFilesDetail = jdbcTemplate.query(strQuery, (rs, rowNum) -> new FailedDownloadRequestFiles(rs.getString("case_id"),
					rs.getString("document_id"),rs.getString("ticketNumber")), requestId);

		return failedFilesDetail;
	}
	
	@Override
	public int postNotification(NotificationModel notifyModel,JdbcTemplate jdbcTemplate) throws SQLException
	{
		KeyHolder keyHolder = new GeneratedKeyHolder();

		Connection conn = JDBCConnectionUtil.jdbcConnection();

		jdbcTemplate.update(connection -> {
			PreparedStatement ps = conn.prepareStatement(DP_USER_NOTIFICATION_INSERT, Statement.RETURN_GENERATED_KEYS);
			ps.setString(1, notifyModel.getRequest_id());
			ps.setString(2, notifyModel.getUser_oid());
			ps.setString(3, notifyModel.getRequesting_activity_name());
			ps.setString(4, notifyModel.getNotification_status_id());
			ps.setString(5, notifyModel.getNotification_status_description());
			ps.setString(6, notifyModel.getMessage());
			ps.setString(7, notifyModel.getCreated_on());
			ps.setString(8, notifyModel.getCreated_by());
			return ps;
		}, keyHolder);

			Number n = keyHolder.getKey();
			if (n != null)
				return n.intValue();
			else
				return 0;
		
	}
	
	@Override
	public void postAudityEntity(AuditMaster auditMaster,JdbcTemplate jdbcTemplate) throws SQLException
	{	
		jdbcTemplate.update(DP_AUDIT_EVENT_INSERT, auditMaster.getUserOID(),auditMaster.getAuditEventTimestamp(),auditMaster.getAuditEventName(),auditMaster.getPrimaryAuditEntity(),
				auditMaster.getPrimaryAuditEntityIdentifier(),auditMaster.getPreAuditSnapshot(),auditMaster.getPostAuditSnapshot(),auditMaster.getCreatedOn(),auditMaster.getCreatedBy());
	}
	
	@Override
	public void updateProcessingCounter(UUID requestId, int processingCounetr,JdbcTemplate jdbcTemplate) throws SQLException
	{
		jdbcTemplate.update(DP_USER_REQUEST_UPDATE,processingCounetr, requestId);
	}
	
}
