package com.ombudsman.service.respondent.model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

public class DownloadRequestItemTest {
	@Test
    public void testGettersAndSetters() {
		String documentId = "documentId";
		DownloadRequestItem downloadRequestItem	= new DownloadRequestItem("");
		
		downloadRequestItem.setDocumentId(documentId);
		
		assertEquals(documentId, downloadRequestItem.getDocumentId());
	}

}
