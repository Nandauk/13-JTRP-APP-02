package com.ombudsman.service.respondent.model;

import java.util.List;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.util.ArrayList;
import java.util.List;

public class DownloadFileEFileReqTest {
    
    private DownloadFileEFileReq downloadFileEFileReq;
    private List<DownloadRequestItem> files;

    @BeforeEach
    void setUp() {
        downloadFileEFileReq = new DownloadFileEFileReq();
        files = new ArrayList<>();
        files.add(new DownloadRequestItem("documentId"));
    }

    @Test
    void testCaseId() {
        String caseId = "12345";
        downloadFileEFileReq.setCaseId(caseId);
        assertEquals(caseId, downloadFileEFileReq.getCaseId());
    }

    @Test
    void testRespondent() {
        boolean isRespondent = true;
        downloadFileEFileReq.setIsRespondent(isRespondent);
        assertTrue(downloadFileEFileReq.getIsRespondent());
    }

    @Test
    void testFiles() {
        downloadFileEFileReq.setFiles(files);
        assertEquals(files, downloadFileEFileReq.getFiles());
    }

    @Test
    void testOrgId() {
        String orgId = "Org123";
        downloadFileEFileReq.setOrgId(orgId);
        assertEquals(orgId, downloadFileEFileReq.getOrgId());
    }

    @Test
    void testRequestId() {
        String requestId = "Req123";
        downloadFileEFileReq.setRequestId(requestId);
        assertEquals(requestId, downloadFileEFileReq.getRequestId());
    }

    @Test
    void testNotificationId() {
        String notificationId = "Notif123";
        downloadFileEFileReq.setNotificationId(notificationId);
        assertEquals(notificationId, downloadFileEFileReq.getNotificationId());
    }
}
