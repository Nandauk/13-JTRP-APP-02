package com.ombudsman.service.respondent.model;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.time.OffsetDateTime;

import org.junit.jupiter.api.Test;

public class AuditMasterTest {

	@Test
    public void testGettersAndSetters() {
		AuditMaster auditMaster = new AuditMaster();
		
		Integer auditRecordID = 0;
		String userOID = "userOID";
		OffsetDateTime auditEventTimestamp = OffsetDateTime.now();
		String auditEventName = "auditEventName";
		String primaryAuditEntity = "primaryAuditEntity";
		String primaryAuditEntityIdentifier = "primaryAuditEntityIdentifier";
		String preAuditSnapshot = "preAuditSnapshot";
		String postAuditSnapshot = "postAuditSnapshot";
		OffsetDateTime createdOn = OffsetDateTime.now();
		String createdBy = "creator";;
		OffsetDateTime modifiedOn = OffsetDateTime.now();
		String modifiedBy="modifier";
		
		auditMaster.setAuditRecordID(auditRecordID);
		auditMaster.setUserOID(userOID);
		auditMaster.setAuditEventTimestamp(auditEventTimestamp);
		auditMaster.setAuditEventName(auditEventName);
		auditMaster.setPrimaryAuditEntity(primaryAuditEntity);
		auditMaster.setPrimaryAuditEntityIdentifier(primaryAuditEntityIdentifier);
		auditMaster.setPreAuditSnapshot(preAuditSnapshot);
		auditMaster.setPostAuditSnapshot(postAuditSnapshot);
		auditMaster.setCreatedBy(createdBy);
		auditMaster.setCreatedOn(createdOn);
		auditMaster.setModifiedBy(modifiedBy);
		auditMaster.setModifiedOn(modifiedOn);
		
		assertEquals(auditRecordID,auditMaster.getAuditRecordID());
		assertEquals(userOID,auditMaster.getUserOID());
		assertEquals(auditEventTimestamp,auditMaster.getAuditEventTimestamp());
		assertEquals(auditEventName,auditMaster.getAuditEventName());
		assertEquals(primaryAuditEntity,auditMaster.getPrimaryAuditEntity());
		assertEquals(primaryAuditEntityIdentifier,auditMaster.getPrimaryAuditEntityIdentifier());
		assertEquals(preAuditSnapshot,auditMaster.getPreAuditSnapshot());
		assertEquals(postAuditSnapshot,auditMaster.getPostAuditSnapshot());
		assertEquals(createdBy,auditMaster.getCreatedBy());
		assertEquals(createdOn,auditMaster.getCreatedOn());
		assertEquals(modifiedBy,auditMaster.getModifiedBy());
		assertEquals(modifiedOn,auditMaster.getModifiedOn());
	}
}
