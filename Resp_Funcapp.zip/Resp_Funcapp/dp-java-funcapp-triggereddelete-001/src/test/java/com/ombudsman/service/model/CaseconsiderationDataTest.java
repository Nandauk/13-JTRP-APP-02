package com.ombudsman.service.model;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

import java.lang.reflect.Field;
import java.util.UUID;

public class CaseconsiderationDataTest {

    @Test
    public void testGetFos_caseconsiderationid() throws NoSuchFieldException, IllegalAccessException {
        UUID expectedUUID = UUID.randomUUID();
        CaseconsiderationData caseconsiderationData = new CaseconsiderationData();

        Field field = CaseconsiderationData.class.getDeclaredField("fos_caseconsiderationid");
        field.setAccessible(true);
        field.set(caseconsiderationData, expectedUUID);

        assertEquals(expectedUUID, caseconsiderationData.getFos_caseconsiderationid());
    }
}
