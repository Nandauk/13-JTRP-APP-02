package com.ombudsman.service.model;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

public class MessagesTest {

    @Test
    public void testGettersAndSetters() throws NoSuchFieldException, IllegalAccessException {
        Messages messages = new Messages();

        Field fromField = Messages.class.getDeclaredField("From");
        Field toField = Messages.class.getDeclaredField("To");
        Field templateIdField = Messages.class.getDeclaredField("TemplateID");
        Field templateLanguageField = Messages.class.getDeclaredField("TemplateLanguage");
        Field variablesField = Messages.class.getDeclaredField("var");

        fromField.setAccessible(true);
        toField.setAccessible(true);
        templateIdField.setAccessible(true);
        templateLanguageField.setAccessible(true);
        variablesField.setAccessible(true);

        From from = new From();
        List<To> toList = new ArrayList<>();
        To to = new To();
        toList.add(to);
        int templateID = 12345;
        boolean templateLanguage = true;
        MailjetVariables variables = new MailjetVariables();

        fromField.set(messages, from);
        toField.set(messages, toList);
        templateIdField.set(messages, templateID);
        templateLanguageField.set(messages, templateLanguage);
        variablesField.set(messages, variables);

        assertEquals(from, messages.getFrom());
        assertEquals(toList, messages.getTo());
        assertEquals(templateID, messages.getTemplateID());
        assertEquals(templateLanguage, messages.getTemplateLanguage());
        assertEquals(variables, messages.getVar());
    }
}
