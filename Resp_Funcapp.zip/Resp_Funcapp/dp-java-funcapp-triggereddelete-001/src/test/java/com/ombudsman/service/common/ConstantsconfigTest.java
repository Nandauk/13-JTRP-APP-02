//package com.ombudsman.service.common;
//
//import static org.junit.jupiter.api.Assertions.assertEquals;
//
//import org.junit.jupiter.api.Test;
//
//public class ConstantsconfigTest {
//
//    @Test
//    public void testConstantsConfigValues() {
//        ConstantsConfig constantsconfig = new ConstantsConfig();
//
//        // Set values directly
//        constantsconfig.Entity_Incident = "TestIncident";
//      
//
//        constantsconfig.In_Progress = "In_Progress";
//        constantsconfig.Pending = "Pending";
//        constantsconfig.Completed = "Completed";
//        constantsconfig.Ready_To_Process = "Ready_To_Process";
//        constantsconfig.Terminated = "Terminated";
//        constantsconfig.Failed = "Failed";
//        constantsconfig.Error_log = "PHOENIX_001";
//      
//
//        // Test getters
//        assertEquals("TestIncident", constantsconfig.Entity_Incident);
//        assertEquals(10, constantsconfig.Fetchxml_Record);
//        assertEquals("TestHost", constantsconfig.APIM_HOST);
//
//        assertEquals("In_Progress", constantsconfig.In_Progress);
//        assertEquals("Pending", constantsconfig.Pending);
//        assertEquals("Completed", constantsconfig.Completed);
//        assertEquals("Ready_To_Process", constantsconfig.Ready_To_Process);
//        assertEquals("Terminated", constantsconfig.Terminated);
//        assertEquals("Failed", constantsconfig.Failed);
//        assertEquals("PHOENIX_001", constantsconfig.Error_log);
//        assertEquals("SQL_001", constantsconfig.Error_log_sql);
//        assertEquals("PHOENIX_OR_SQL_001", constantsconfig.Error_log_phx_sql);
//        assertEquals("SCH", constantsconfig.DataSourceName);
//
//        assertEquals("incident", constantsconfig.Incident);
//        assertEquals("account", constantsconfig.Account);
//        assertEquals("fos_offeroroutcome", constantsconfig.Offeroutcome);
//        assertEquals("fos_caselink", constantsconfig.Caselink);
//        assertEquals("systemuser", constantsconfig.User);
//        assertEquals("email", constantsconfig.Email);
//        assertEquals("task", constantsconfig.Task);
//        assertEquals("letter", constantsconfig.Letter);
//        assertEquals("phonecall", constantsconfig.Phone);
//        assertEquals("fos_portal", constantsconfig.Portal);
//        assertEquals("fos_caseconsideration", constantsconfig.Caseconsideration);
//
//        assertEquals("incidentid", constantsconfig.IncidentPk);
//        assertEquals("accountid", constantsconfig.AccountPk);
//        assertEquals("fos_offeroroutcomeid", constantsconfig.OfferoutcomePk);
//        assertEquals("fos_caselinkid", constantsconfig.CaselinkPk);
//        assertEquals("systemuserid", constantsconfig.UserPk);
//        assertEquals("activityid", constantsconfig.EmailPk);
//        assertEquals("activityid", constantsconfig.TaskPk);
//        assertEquals("activityid", constantsconfig.LetterPk);
//        assertEquals("activityid", constantsconfig.PhonePk);
//        assertEquals("activityid", constantsconfig.PortalPk);
//        assertEquals("fos_caseconsiderationid", constantsconfig.CaseconsiderationPk);
//    }
//}
