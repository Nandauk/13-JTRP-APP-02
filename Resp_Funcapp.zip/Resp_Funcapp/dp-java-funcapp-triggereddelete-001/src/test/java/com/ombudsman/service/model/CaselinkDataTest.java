package com.ombudsman.service.model;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

import java.lang.reflect.Field;
import java.util.UUID;

public class CaselinkDataTest {

    @Test
    public void testGetFos_caselinkid() throws NoSuchFieldException, IllegalAccessException {
        UUID expectedUUID = UUID.randomUUID();
        CaselinkData caselinkData = new CaselinkData();

        Field field = CaselinkData.class.getDeclaredField("fos_caselinkid");
        field.setAccessible(true);
        field.set(caselinkData, expectedUUID);

        assertEquals(expectedUUID, caselinkData.getFos_caselinkid());
    }
}
