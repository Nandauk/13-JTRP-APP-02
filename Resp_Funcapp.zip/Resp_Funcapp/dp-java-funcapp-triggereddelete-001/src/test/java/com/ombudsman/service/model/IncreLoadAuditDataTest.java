package com.ombudsman.service.model;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

import java.lang.reflect.Field;

public class IncreLoadAuditDataTest {

    @Test
    public void testGettersAndSetters() throws NoSuchFieldException, IllegalAccessException {
        IncreLoadAuditData increLoadAuditData = new IncreLoadAuditData();

        Field incrementalIdField = IncreLoadAuditData.class.getDeclaredField("incremental_data_load_audit_id");
        Field jobIdField = IncreLoadAuditData.class.getDeclaredField("job_id");
        Field jobStartField = IncreLoadAuditData.class.getDeclaredField("job_start_dateTime");
        Field totalRecordsField = IncreLoadAuditData.class.getDeclaredField("total_number_of_records");
        Field processedRecordsField = IncreLoadAuditData.class.getDeclaredField("number_of_processed_record");
        Field failedRecordsField = IncreLoadAuditData.class.getDeclaredField("number_of_failed_record");
        Field currentJobStatusField = IncreLoadAuditData.class.getDeclaredField("current_job_status_id");
        Field jobCloseField = IncreLoadAuditData.class.getDeclaredField("job_close_datetime");
        Field nextJobRunField = IncreLoadAuditData.class.getDeclaredField("next_job_run_datetime");
        Field sourceField = IncreLoadAuditData.class.getDeclaredField("source");
        Field createdOnField = IncreLoadAuditData.class.getDeclaredField("created_on");
        Field modifiedOnField = IncreLoadAuditData.class.getDeclaredField("modified_on");
        Field createdByField = IncreLoadAuditData.class.getDeclaredField("created_by");
        Field modifiedByField = IncreLoadAuditData.class.getDeclaredField("modified_by");

        incrementalIdField.setAccessible(true);
        jobIdField.setAccessible(true);
        jobStartField.setAccessible(true);
        totalRecordsField.setAccessible(true);
        processedRecordsField.setAccessible(true);
        failedRecordsField.setAccessible(true);
        currentJobStatusField.setAccessible(true);
        jobCloseField.setAccessible(true);
        nextJobRunField.setAccessible(true);
        sourceField.setAccessible(true);
        createdOnField.setAccessible(true);
        modifiedOnField.setAccessible(true);
        createdByField.setAccessible(true);
        modifiedByField.setAccessible(true);

        incrementalIdField.set(increLoadAuditData, "some_id");
        jobIdField.set(increLoadAuditData, 123);
        jobStartField.set(increLoadAuditData, "2025-01-26T10:00:00");
        totalRecordsField.set(increLoadAuditData, 1000);
        processedRecordsField.set(increLoadAuditData, 900);
        failedRecordsField.set(increLoadAuditData, 100);
        currentJobStatusField.set(increLoadAuditData, 1);
        jobCloseField.set(increLoadAuditData, "2025-01-26T12:00:00");
        nextJobRunField.set(increLoadAuditData, "2025-01-27T10:00:00");
        sourceField.set(increLoadAuditData, "source_value");
        createdOnField.set(increLoadAuditData, "2025-01-26T08:00:00");
        modifiedOnField.set(increLoadAuditData, "2025-01-26T14:00:00");
        createdByField.set(increLoadAuditData, "creator");
        modifiedByField.set(increLoadAuditData, "modifier");

        assertEquals("some_id", increLoadAuditData.getIncremental_data_load_audit_id());
        assertEquals(123, increLoadAuditData.getJob_id());
        assertEquals("2025-01-26T10:00:00", increLoadAuditData.getJob_start_dateTime());
        assertEquals(1000, increLoadAuditData.getTotal_number_of_records());
        assertEquals(900, increLoadAuditData.getNumber_of_processed_record());
        assertEquals(100, increLoadAuditData.getNumber_of_failed_record());
        assertEquals(1, increLoadAuditData.getCurrent_job_status_id());
        assertEquals("2025-01-26T12:00:00", increLoadAuditData.getJob_close_datetime());
        assertEquals("2025-01-27T10:00:00", increLoadAuditData.getNext_job_run_datetime());
        assertEquals("source_value", increLoadAuditData.getSource());
        assertEquals("2025-01-26T08:00:00", increLoadAuditData.getCreated_on());
        assertEquals("2025-01-26T14:00:00", increLoadAuditData.getModified_on());
        assertEquals("creator", increLoadAuditData.getCreated_by());
        assertEquals("modifier", increLoadAuditData.getModified_by());
    }
}
