package com.ombudsman.service.model;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

import java.lang.reflect.Field;
import java.util.UUID;

public class IncidentDataTest {

    @Test
    public void testGetIncidentid() throws NoSuchFieldException, IllegalAccessException {
        UUID expectedUUID = UUID.randomUUID();
        IncidentData incidentData = new IncidentData();

        Field field = IncidentData.class.getDeclaredField("incidentid");
        field.setAccessible(true);
        field.set(incidentData, expectedUUID);

        assertEquals(expectedUUID, incidentData.getIncidentid());
    }
}
