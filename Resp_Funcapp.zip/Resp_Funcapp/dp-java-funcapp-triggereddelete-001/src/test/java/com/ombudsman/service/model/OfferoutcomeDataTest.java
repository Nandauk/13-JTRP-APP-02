package com.ombudsman.service.model;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

import java.lang.reflect.Field;
import java.util.UUID;

public class OfferoutcomeDataTest {

    @Test
    public void testGetFos_offeroroutcomeid() throws NoSuchFieldException, IllegalAccessException {
        UUID expectedUUID = UUID.randomUUID();
        OfferoutcomeData offeroutcomeData = new OfferoutcomeData();

        Field field = OfferoutcomeData.class.getDeclaredField("fos_offeroroutcomeid");
        field.setAccessible(true);
        field.set(offeroutcomeData, expectedUUID);

        assertEquals(expectedUUID, offeroutcomeData.getFos_offeroroutcomeid());
    }
}
