package com.ombudsman.service.model;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

import java.lang.reflect.Field;
import java.util.UUID;

public class ContactDataTest {

    @Test
    public void testGetContactid() throws NoSuchFieldException, IllegalAccessException {
        UUID expectedUUID = UUID.randomUUID();
        ContactData contactData = new ContactData();

        Field field = ContactData.class.getDeclaredField("contactid");
        field.setAccessible(true);
        field.set(contactData, expectedUUID);

        assertEquals(expectedUUID, contactData.getContactid());
    }
}
