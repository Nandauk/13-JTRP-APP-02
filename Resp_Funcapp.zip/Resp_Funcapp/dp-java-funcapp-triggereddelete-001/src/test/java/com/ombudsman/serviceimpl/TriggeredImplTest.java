package com.ombudsman.serviceimpl;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

import java.sql.SQLException;
import java.util.UUID;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;

public class TriggeredImplTest {

    @Mock
    private JdbcTemplate jdbcTemplate;

    @InjectMocks
    private TriggeredImpl triggeredImpl;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testGetJobID_Success() throws SQLException {
        // Given
        String entity = "test_entity";
        int expectedJobId = 123;
        when(jdbcTemplate.queryForObject(anyString(), eq(Integer.class), anyString())).thenReturn(expectedJobId);

        // When
        int actualJobId = triggeredImpl.getJobID(entity, jdbcTemplate);

        // Then
        assertEquals(expectedJobId, actualJobId);
        verify(jdbcTemplate, times(1)).queryForObject(anyString(), eq(Integer.class), eq(entity));
    }

    @Test
    public void testGetJobID_EmptyResult() throws SQLException {
        // Given
        String entity = "test_entity";
        when(jdbcTemplate.queryForObject(anyString(), eq(Integer.class), anyString())).thenThrow(new EmptyResultDataAccessException(1));

        // When
        int actualJobId = triggeredImpl.getJobID(entity, jdbcTemplate);

        // Then
        assertEquals(0, actualJobId);
        verify(jdbcTemplate, times(1)).queryForObject(anyString(), eq(Integer.class), eq(entity));
    }
    @Test
    public void testGetCurrentStatusIPId_Success() throws SQLException {
        // Given
        String entity = "test_entity";
        int expectedInProgressId = 123;
        when(jdbcTemplate.queryForObject(anyString(), eq(Integer.class), anyString(), anyString())).thenReturn(expectedInProgressId);

        // When
        int actualInProgressId = triggeredImpl.getCurrentStatusIPId(entity, jdbcTemplate);

        // Then
        assertEquals(expectedInProgressId, actualInProgressId);
        verify(jdbcTemplate, times(1)).queryForObject(anyString(), eq(Integer.class), anyString(), anyString());
    }
    @Test
    public void testGetCurrentStatusRTPId_Success() throws SQLException {
        // Given
        String entity = "test_entity";
        int expectedRTPId = 123;
        when(jdbcTemplate.queryForObject(anyString(), eq(Integer.class), anyString(), anyString())).thenReturn(expectedRTPId);

        // When
        int actualRTPId = triggeredImpl.getCurrentStatusRTPId(entity, jdbcTemplate);

        // Then
        assertEquals(expectedRTPId, actualRTPId);
        verify(jdbcTemplate, times(1)).queryForObject(anyString(), eq(Integer.class), anyString(), anyString());
    }

    @Test
    public void testGetCurrentStatusRTPId_EmptyResult() throws SQLException {
        // Given
        String entity = "test_entity";
        when(jdbcTemplate.queryForObject(anyString(), eq(Integer.class), anyString(), anyString())).thenThrow(new EmptyResultDataAccessException(1));

        // When
        int actualRTPId = triggeredImpl.getCurrentStatusRTPId(entity, jdbcTemplate);

        // Then
        assertEquals(0, actualRTPId);
        verify(jdbcTemplate, times(1)).queryForObject(anyString(), eq(Integer.class), anyString(), anyString());
    }
    @Test
    public void testInsertQuery() {
        // Given
        int jobId = 1;
        String startWebJobFormatted = "2025-01-01 00:00:00";
        Integer totalCount = 100;
        Integer totalSuccessCount = 95;
        Integer failedCount = 5;
        int currentStatusIdInProgress = 2;
        String dataSourceName = "DataSource";
        String entityContact = "Contact";
        String entityContact2 = "Contact2";
        UUID incremental_data_load_funcapp_id= UUID.randomUUID();

        // When
        triggeredImpl.InsertQuery(jobId, startWebJobFormatted, totalCount, totalSuccessCount, failedCount, 
            currentStatusIdInProgress, dataSourceName, entityContact, entityContact2, jdbcTemplate,incremental_data_load_funcapp_id);

        // Then
        verify(jdbcTemplate, times(1)).update(anyString(), eq(jobId), eq(startWebJobFormatted), eq(totalCount), 
            eq(totalSuccessCount), eq(failedCount), eq(currentStatusIdInProgress), eq(dataSourceName), eq(entityContact), eq(entityContact2),eq(incremental_data_load_funcapp_id));
    }

//   @Test
//    public void testGetIncrementalDataLoadAuditId_Success() throws SQLException {
//        // Given
//        String startWebJobFormatted = "2025-01-01 00:00:00";
//        int currentStatusIdInProgress = 2;
//        String dataSourceName = "DataSource";
//        String entity = "Entity";
//        UUID expectedAuditId = UUID.randomUUID();
//        UUID incremental_data_load_funcapp_id=UUID.randomUUID();
//
//        when(jdbcTemplate.queryForObject(anyString(), eq(UUID.class), anyInt(), anyString(), anyString(), anyString(),eq(UUID.class)))
//            .thenReturn(expectedAuditId);
//
//        // When
//        UUID actualAuditId = triggeredImpl.getIncrementalDataLoadAuditId(startWebJobFormatted, currentStatusIdInProgress, 
//            dataSourceName, entity, jdbcTemplate,incremental_data_load_funcapp_id);
//
//        // Then
//        assertEquals(expectedAuditId, actualAuditId);
//        verify(jdbcTemplate, times(1)).queryForObject(anyString(), eq(UUID.class), eq(currentStatusIdInProgress), 
//            eq(dataSourceName), eq(startWebJobFormatted), eq(entity));
//    }

    @Test
    public void testGetCurrentStatusFId_Success() throws SQLException {
        // Given
        String entity = "Entity";
        int expectedFailedId = 3;

        when(jdbcTemplate.queryForObject(anyString(), eq(Integer.class), anyString(), anyString()))
            .thenReturn(expectedFailedId);

        // When
        int actualFailedId = triggeredImpl.getCurrentStatusFId(entity, jdbcTemplate);

        // Then
        assertEquals(expectedFailedId, actualFailedId);
        verify(jdbcTemplate, times(1)).queryForObject(anyString(), eq(Integer.class), anyString(), anyString());
    }

    @Test
    public void testGetCurrentStatusFId_EmptyResult() throws SQLException {
        // Given
        String entity = "Entity";

        when(jdbcTemplate.queryForObject(anyString(), eq(Integer.class), anyString(), anyString()))
            .thenThrow(new EmptyResultDataAccessException(1));

        // When
        int actualFailedId = triggeredImpl.getCurrentStatusFId(entity, jdbcTemplate);

        // Then
        assertEquals(0, actualFailedId);
        verify(jdbcTemplate, times(1)).queryForObject(anyString(), eq(Integer.class), anyString(), anyString());
    }

    @Test
    public void testInsertQueryErrorTable() {
        // Given
        UUID fetchIncrementalDataLoadAuditId = UUID.randomUUID();
        String dataPayload = "DataPayload";
        int currentStatusIdFailed = 4;
        String errorLog = "ErrorLog";
        String stackTrace = "StackTrace";
        String entity = "Entity";
        String entity1 = "Entity1";

        // When
        triggeredImpl.InsertQueryErrorTable(fetchIncrementalDataLoadAuditId, dataPayload, currentStatusIdFailed, 
            errorLog, stackTrace, entity, entity1, jdbcTemplate);

        // Then
        verify(jdbcTemplate, times(1)).update(anyString(), eq(fetchIncrementalDataLoadAuditId), eq(dataPayload), 
            eq(currentStatusIdFailed), eq(errorLog), eq(stackTrace), eq(entity), eq(entity1));
    }
    @Test
    public void testUpdateQuery() {
        // Given
        Integer totalCount = 100;
        Integer totalSuccessCount = 95;
        Integer failedCount = 5;
        int currentStatusId = 2;
        String string = "testString";
        UUID fetchIncrementalDataLoadAuditId = UUID.randomUUID();
        String entity = "Entity";

        // When
        triggeredImpl.UpdateQuery(totalCount, totalSuccessCount, failedCount, currentStatusId, 
            string, fetchIncrementalDataLoadAuditId, entity, jdbcTemplate);

        // Then
        verify(jdbcTemplate, times(1)).update(anyString(), eq(totalCount), eq(totalSuccessCount), 
            eq(failedCount), eq(currentStatusId), eq(string), eq(entity), eq(fetchIncrementalDataLoadAuditId));
    }

    @Test
    public void testInsertRecordcontact() {
        // Given
        UUID uuid = UUID.randomUUID();
        UUID fetchIncrementalDataLoadAuditId = UUID.randomUUID();
        String entity = "Entity";

        // When
        triggeredImpl.insertRecordcontact(uuid, fetchIncrementalDataLoadAuditId, jdbcTemplate, entity);

        // Then
        verify(jdbcTemplate, times(1)).update(anyString(), eq(uuid), eq(fetchIncrementalDataLoadAuditId));
    }

    @Test
    public void testInsertRecordincident() {
        // Given
        UUID uuid = UUID.randomUUID();
        UUID fetchIncrementalDataLoadAuditId = UUID.randomUUID();
        String entity = "Entity";

        // When
        triggeredImpl.insertRecordincident(uuid, fetchIncrementalDataLoadAuditId, jdbcTemplate, entity);

        // Then
        verify(jdbcTemplate, times(1)).update(anyString(), eq(uuid), eq(fetchIncrementalDataLoadAuditId));
    }

    @Test
    public void testInsertRecordcaselink() {
        // Given
        UUID uuid = UUID.randomUUID();
        UUID fetchIncrementalDataLoadAuditId = UUID.randomUUID();
        String entity = "Entity";

        // When
        triggeredImpl.insertRecordcaselink(uuid, fetchIncrementalDataLoadAuditId, jdbcTemplate, entity);

        // Then
        verify(jdbcTemplate, times(1)).update(anyString(), eq(uuid), eq(fetchIncrementalDataLoadAuditId));
    }

    @Test
    public void testInsertRecordaccount() {
        // Given
        UUID uuid = UUID.randomUUID();
        UUID fetchIncrementalDataLoadAuditId = UUID.randomUUID();
        String entity = "Entity";

        // When
        triggeredImpl.insertRecordaccount(uuid, fetchIncrementalDataLoadAuditId, jdbcTemplate, entity);

        // Then
        verify(jdbcTemplate, times(1)).update(anyString(), eq(uuid), eq(fetchIncrementalDataLoadAuditId));
    }

    @Test
    public void testInsertRecordemail() {
        // Given
        UUID uuid = UUID.randomUUID();
        UUID fetchIncrementalDataLoadAuditId = UUID.randomUUID();
        String entity = "Entity";

        // When
        triggeredImpl.insertRecordemail(uuid, fetchIncrementalDataLoadAuditId, jdbcTemplate, entity);

        // Then
        verify(jdbcTemplate, times(1)).update(anyString(), eq(uuid), eq(fetchIncrementalDataLoadAuditId));
    }

    @Test
    public void testInsertRecordletter() {
        // Given
        UUID uuid = UUID.randomUUID();
        UUID fetchIncrementalDataLoadAuditId = UUID.randomUUID();
        String entity = "Entity";

        // When
        triggeredImpl.insertRecordletter(uuid, fetchIncrementalDataLoadAuditId, jdbcTemplate, entity);

        // Then
        verify(jdbcTemplate, times(1)).update(anyString(), eq(uuid), eq(fetchIncrementalDataLoadAuditId));
    }

    @Test
    public void testInsertRecordtask() {
        // Given
        UUID uuid = UUID.randomUUID();
        UUID fetchIncrementalDataLoadAuditId = UUID.randomUUID();
        String entity = "Entity";

        // When
        triggeredImpl.insertRecordtask(uuid, fetchIncrementalDataLoadAuditId, jdbcTemplate, entity);

        // Then
        verify(jdbcTemplate, times(1)).update(anyString(), eq(uuid), eq(fetchIncrementalDataLoadAuditId));
    }

    @Test
    public void testInsertRecordphone() {
        // Given
        UUID uuid = UUID.randomUUID();
        UUID fetchIncrementalDataLoadAuditId = UUID.randomUUID();
        String entity = "Entity";

        // When
        triggeredImpl.insertRecordphone(uuid, fetchIncrementalDataLoadAuditId, jdbcTemplate, entity);

        // Then
        verify(jdbcTemplate, times(1)).update(anyString(), eq(uuid), eq(fetchIncrementalDataLoadAuditId));
    }

    @Test
    public void testInsertRecordportal() {
        // Given
        UUID uuid = UUID.randomUUID();
        UUID fetchIncrementalDataLoadAuditId = UUID.randomUUID();
        String entity = "Entity";

        // When
        triggeredImpl.insertRecordportal(uuid, fetchIncrementalDataLoadAuditId, jdbcTemplate, entity);

        // Then
        verify(jdbcTemplate, times(1)).update(anyString(), eq(uuid), eq(fetchIncrementalDataLoadAuditId));
    }

    @Test
    public void testInsertRecorduser() {
        // Given
        UUID uuid = UUID.randomUUID();
        UUID fetchIncrementalDataLoadAuditId = UUID.randomUUID();
        String entity = "Entity";

        // When
        triggeredImpl.insertRecorduser(uuid, fetchIncrementalDataLoadAuditId, jdbcTemplate, entity);

        // Then
        verify(jdbcTemplate, times(1)).update(anyString(), eq(uuid), eq(fetchIncrementalDataLoadAuditId));
    }

    @Test
    public void testInsertRecordofferoutcome() {
        // Given
        UUID uuid = UUID.randomUUID();
        UUID fetchIncrementalDataLoadAuditId = UUID.randomUUID();
        String entity = "Entity";

        // When
        triggeredImpl.insertRecordofferoutcome(uuid, fetchIncrementalDataLoadAuditId, jdbcTemplate, entity);

        // Then
        verify(jdbcTemplate, times(1)).update(anyString(), eq(uuid), eq(fetchIncrementalDataLoadAuditId));
    }

    @Test
    public void testInsertRecordcaseconsideration() {
        // Given
        UUID uuid = UUID.randomUUID();
        UUID fetchIncrementalDataLoadAuditId = UUID.randomUUID();
        String entity = "Entity";

        // When
        triggeredImpl.insertRecordcaseconsideration(uuid, fetchIncrementalDataLoadAuditId, jdbcTemplate, entity);

        // Then
        verify(jdbcTemplate, times(1)).update(anyString(), eq(uuid), eq(fetchIncrementalDataLoadAuditId));
    }

    @Test
    public void testInsertRecordcorrespondence() {
        // Given
        UUID uuid = UUID.randomUUID();
        UUID fetchIncrementalDataLoadAuditId = UUID.randomUUID();
        String entity = "Entity";

        // When
        triggeredImpl.insertRecordcorrespondence(uuid, fetchIncrementalDataLoadAuditId, jdbcTemplate, entity);

        // Then
        verify(jdbcTemplate, times(1)).update(anyString(), eq(uuid), eq(fetchIncrementalDataLoadAuditId));
    }

    @Test
    public void testInsertRecordcorrespondenceSource() {
        // Given
        UUID uuid = UUID.randomUUID();
        UUID fetchIncrementalDataLoadAuditId = UUID.randomUUID();
        String entity = "Entity";

        // When
        triggeredImpl.insertRecordcorrespondenceSource(uuid, fetchIncrementalDataLoadAuditId, jdbcTemplate, entity);

        // Then
        verify(jdbcTemplate, times(1)).update(anyString(), eq(uuid), eq(fetchIncrementalDataLoadAuditId));
    }
}
   

