package com.ombudsman.service.model;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

import java.lang.reflect.Field;
import java.util.UUID;

public class EmailDataTest {

    @Test
    public void testGetActivityid() throws NoSuchFieldException, IllegalAccessException {
        UUID expectedUUID = UUID.randomUUID();
        EmailData emailData = new EmailData();

        Field field = EmailData.class.getDeclaredField("activityid");
        field.setAccessible(true);
        field.set(emailData, expectedUUID);

        assertEquals(expectedUUID, emailData.getActivityid());
    }
}
