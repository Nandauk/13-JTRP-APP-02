package com.ombudsman.service.model;

import java.util.UUID;

import jakarta.persistence.Id;

public class CorrespondenceData {

	@Id
	private UUID fos_correspondenceid;

	public UUID getFos_correspondenceid() {
		return fos_correspondenceid;
	}

}
