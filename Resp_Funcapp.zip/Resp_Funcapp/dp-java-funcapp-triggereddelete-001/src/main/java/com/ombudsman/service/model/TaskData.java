package com.ombudsman.service.model;

import java.util.UUID;

import jakarta.persistence.Id;

public class TaskData {

	@Id
	private UUID activityid;

	public UUID getActivityid() {
		return activityid;
	}

}
