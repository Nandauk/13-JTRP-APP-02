package com.ombudsman.service.common;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

public class JDBCConnectionUtil {

	public static final Logger LOG = LogManager.getRootLogger();

	public static JdbcTemplate jdbcConnection() {
		JdbcTemplate jdbcTemplate = new JdbcTemplate();
		DriverManagerDataSource dataSource = new DriverManagerDataSource();
		dataSource.setDriverClassName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
		dataSource.setUrl(System.getenv("SQL_DATASOURCE_URL"));
		dataSource.setUsername(System.getenv("SQL_DATASOURCE_USERNAME"));
		dataSource.setPassword(System.getenv("SQL_DATASOURCE_PASSWORD"));
		jdbcTemplate = new JdbcTemplate(dataSource);

		return jdbcTemplate;
	}

}
