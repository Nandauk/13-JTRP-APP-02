package com.ombudsman.service;

import java.beans.Transient;
import java.sql.SQLException;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.UUID;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.jdbc.core.JdbcTemplate;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.microsoft.azure.functions.ExecutionContext;
import com.microsoft.azure.functions.annotation.FunctionName;
import com.microsoft.azure.functions.annotation.ServiceBusQueueTrigger;
import com.ombudsman.service.common.ConstantsConfig;
import com.ombudsman.service.common.JDBCConnectionUtil;
import com.ombudsman.service.model.PortalData;
import com.ombudsman.serviceimpl.EmailHelper;
import com.ombudsman.serviceimpl.TriggeredImpl;

public class AzurefunctriggereddeletePortal {

	Integer failedCount = 0, totalSuccessCount = 0, totalCount = 0;
	Logger LOG = LogManager.getRootLogger();
	UUID Fetch_IncrementalDataLoadAuditId = null;
	TriggeredImpl triggerimpl = new TriggeredImpl();
	ConstantsConfig constant = new ConstantsConfig();
	JdbcTemplate jdbcTemplate = JDBCConnectionUtil.jdbcConnection();
	EmailHelper emailhelper = new EmailHelper();

	@FunctionName("PortalTriggerDelete")
	@Transient(true)
	public void serviceBusProcessPortal(
			@ServiceBusQueueTrigger(name = "Portalmsg", queueName = "%QueueNamePortal%", connection = "AzureWebJobsServiceBus") String message,
			final ExecutionContext context) throws SQLException {

		LOG.info("Message from Portal service bus queue : {}", message);

		ObjectMapper mapper = new ObjectMapper();
		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

		Instant startWebJob = Instant.now();
		String startWebJob_formatted = startWebJob.truncatedTo(ChronoUnit.MILLIS).toString().replaceAll("[TZ]", " ");

		// Parse the JSON message into PortalData object
		try {
			LOG.info("AZURE STARTED in TRY BLOCK for : {}", constant.Entity_Portal);
			PortalData portalData = mapper.readValue(message, PortalData.class);

			LOG.info("Portal ID : {} ", portalData.getActivityid());
			int JobId = triggerimpl.getJobID(constant.Entity_Portal, jdbcTemplate);

			int current_status_id_inprogress = triggerimpl.getCurrentStatusIPId(constant.Entity_Portal, jdbcTemplate);
			int current_status_id_readytoprocess = triggerimpl.getCurrentStatusRTPId(constant.Entity_Portal,
					jdbcTemplate);
			UUID incremental_data_load_funcapp_id = UUID.randomUUID();
			triggerimpl.InsertQuery(JobId, startWebJob_formatted, totalCount, totalSuccessCount, failedCount,
					current_status_id_inprogress, constant.DataSourceName, constant.Entity_Portal,
					constant.Entity_Portal, jdbcTemplate, incremental_data_load_funcapp_id);

			Fetch_IncrementalDataLoadAuditId = triggerimpl.getIncrementalDataLoadAuditId(startWebJob_formatted,
					current_status_id_inprogress, constant.DataSourceName, constant.Entity_Portal, jdbcTemplate,
					incremental_data_load_funcapp_id);
			// entry in Portal table
			triggerimpl.insertRecordportal(portalData.getActivityid(), Fetch_IncrementalDataLoadAuditId, jdbcTemplate,
					constant.Entity_Portal);

			totalCount += 1;

			// Entry in Audit table
			triggerimpl.UpdateQuery(totalCount, totalSuccessCount, failedCount, current_status_id_readytoprocess, null,
					Fetch_IncrementalDataLoadAuditId, constant.Entity_Portal, jdbcTemplate);

		} catch (Exception e) {
			LOG.info("AZURE STARTED in CATCH BLOCK for : {}", constant.Entity_Portal);
			String emailTime = Instant.now().toString();
			int current_status_id_failed = triggerimpl.getCurrentStatusFId(constant.Entity_Portal, jdbcTemplate);
			String DataPayload = message;
			// Entry in Error Table
			triggerimpl.InsertQueryErrorTable(Fetch_IncrementalDataLoadAuditId, DataPayload, current_status_id_failed,
					constant.Error_log, e.getMessage(), constant.Entity_Portal, constant.Entity_Portal, jdbcTemplate);
			// Entry in Audit table
			triggerimpl.UpdateQuery(totalCount, totalSuccessCount, failedCount, current_status_id_failed,
					Instant.now().toString(), Fetch_IncrementalDataLoadAuditId, constant.Entity_Portal, jdbcTemplate);
			// Send email to support team
			emailhelper.NotificationWebclient(constant.Entity_Portal, Fetch_IncrementalDataLoadAuditId,
					constant.DataSourceName, e.getMessage(), emailTime);
			//
			throw new RuntimeException(
					String.format("Job failed for %s entity with Error : %s", constant.Entity_Portal, e.getMessage()));
		}
	}

}
