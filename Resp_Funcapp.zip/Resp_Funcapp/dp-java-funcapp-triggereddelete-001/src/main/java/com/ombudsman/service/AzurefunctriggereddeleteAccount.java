package com.ombudsman.service;

import java.beans.Transient;
import java.sql.SQLException;
import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.UUID;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.jdbc.core.JdbcTemplate;

import com.azure.core.amqp.AmqpTransportType;
import com.azure.identity.ClientSecretCredentialBuilder;
import com.azure.identity.DefaultAzureCredentialBuilder;
import com.azure.messaging.servicebus.ServiceBusClientBuilder;
import com.azure.messaging.servicebus.ServiceBusMessage;
import com.azure.messaging.servicebus.ServiceBusSenderClient;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.microsoft.azure.functions.ExecutionContext;
import com.microsoft.azure.functions.annotation.FunctionName;
import com.microsoft.azure.functions.annotation.ServiceBusQueueTrigger;
import com.ombudsman.service.common.ConstantsConfig;
import com.ombudsman.service.common.JDBCConnectionUtil;
import com.ombudsman.service.model.AccountData;
import com.ombudsman.serviceimpl.EmailHelper;
import com.ombudsman.serviceimpl.TriggeredImpl;

public class AzurefunctriggereddeleteAccount {

	Integer failedCount = 0, totalSuccessCount = 0, totalCount = 0;
	Logger LOG = LogManager.getRootLogger();
	UUID Fetch_IncrementalDataLoadAuditId = null;
	TriggeredImpl triggerimpl = new TriggeredImpl();
	ConstantsConfig constant = new ConstantsConfig();
	JdbcTemplate jdbcTemplate = JDBCConnectionUtil.jdbcConnection();
	EmailHelper emailhelper = new EmailHelper();

	@FunctionName("AccountTriggerDelete")
	@Transient(true)
	public void serviceBusProcessAccount(
			@ServiceBusQueueTrigger(name = "Accountmsg", queueName = "%QueueNameAccount%", connection = "AzureWebJobsServiceBus") String message,
			final ExecutionContext context) throws SQLException {
		LOG.info("Message from acccount service bus queue : {}", message);

		ObjectMapper mapper = new ObjectMapper();
		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

		Instant startWebJob = Instant.now();

		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS").withZone(ZoneId.of("UTC"));
		String startWebJob_formatted = formatter.format(startWebJob);
		// Parse the JSON message into AccountData object
		try {
			LOG.info("AZURE STARTED in TRY BLOCK for : {}", constant.Entity_Account);
			AccountData accountData = mapper.readValue(message, AccountData.class);

			LOG.info("Account ID : {} ", accountData.getAccountid());
			int JobId = triggerimpl.getJobID(constant.Entity_Account, jdbcTemplate);

			int current_status_id_inprogress = triggerimpl.getCurrentStatusIPId(constant.Entity_Account, jdbcTemplate);
			int current_status_id_readytoprocess = triggerimpl.getCurrentStatusRTPId(constant.Entity_Account,
					jdbcTemplate);
			UUID incremental_data_load_funcapp_id = UUID.randomUUID();
			triggerimpl.InsertQuery(JobId, startWebJob_formatted, totalCount, totalSuccessCount, failedCount,
					current_status_id_inprogress, constant.DataSourceName, constant.Entity_Account,
					constant.Entity_Account, jdbcTemplate, incremental_data_load_funcapp_id);

			Fetch_IncrementalDataLoadAuditId = triggerimpl.getIncrementalDataLoadAuditId(startWebJob_formatted,
					current_status_id_inprogress, constant.DataSourceName, constant.Entity_Account, jdbcTemplate,
					incremental_data_load_funcapp_id);
			// entry in Account table
			triggerimpl.insertRecordaccount(accountData.getAccountid(), Fetch_IncrementalDataLoadAuditId, jdbcTemplate,
					constant.Entity_Account);

			totalCount += 1;
			if ("true".equalsIgnoreCase(System.getenv("flag_deleteAccountFromAD"))) {
				// Entry into temp table
				triggerimpl.insertRecordaccountTemp(Fetch_IncrementalDataLoadAuditId, accountData.getAccountid(),
						constant.Entity_Account, constant.In_Progress, jdbcTemplate);
			}

			// Entry in Audit table
			triggerimpl.UpdateQuery(totalCount, totalSuccessCount, failedCount, current_status_id_readytoprocess, null,
					Fetch_IncrementalDataLoadAuditId, constant.Entity_Account, jdbcTemplate);


		} catch (Exception e) {
			LOG.info("AZURE STARTED in CATCH BLOCK for : {}", constant.Entity_Account);
			String emailTime = Instant.now().toString();
			int current_status_id_failed = triggerimpl.getCurrentStatusFId(constant.Entity_Account, jdbcTemplate);
			String DataPayload = message;
			// Entry in Error Table
			triggerimpl.InsertQueryErrorTable(Fetch_IncrementalDataLoadAuditId, DataPayload, current_status_id_failed,
					constant.Error_log, e.getMessage(), constant.Entity_Account, constant.Entity_Account, jdbcTemplate);

			// Entry in Audit table
			triggerimpl.UpdateQuery(totalCount, totalSuccessCount, failedCount, current_status_id_failed,
					Instant.now().toString(), Fetch_IncrementalDataLoadAuditId, constant.Entity_Account, jdbcTemplate);

			// Send email to support team
			emailhelper.NotificationWebclient(constant.Entity_Account, Fetch_IncrementalDataLoadAuditId,
					constant.DataSourceName, e.getMessage(), emailTime);
			//

			throw new RuntimeException(
					String.format("Job failed for %s entity with Error : %s", constant.Entity_Account, e.getMessage()));
		}
	}

}