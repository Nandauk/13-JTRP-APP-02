package com.ombudsman.serviceimpl;

import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.json.JSONException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.MediaType;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.WebClient;

import com.google.gson.Gson;
import com.ombudsman.service.common.ConstantsConfig;
import com.ombudsman.service.exception.MailJetServiceException;
import com.ombudsman.service.model.From;
import com.ombudsman.service.model.MailjetResponseBody;
import com.ombudsman.service.model.MailjetVariables;
import com.ombudsman.service.model.Messages;
import com.ombudsman.service.model.SendMailReq;
import com.ombudsman.service.model.To;

public class EmailHelper {

	ConstantsConfig constant = new ConstantsConfig();
	To to1 = new To();

	private static final Logger LOG = LoggerFactory.getLogger(EmailHelper.class);
	private static final boolean TRUE = true;

	public void NotificationWebclient(String entity, UUID fetch_IncrementalDataLoadAuditId, String dataSourceName,
			String error, String emailTime) {

		LOG.info("Send Mail code started ");
		try {
			SendMailReq sendMailReq = new SendMailReq();
			List<To> to = new ArrayList<>();
			List<Messages> sendmessage = new ArrayList<>();
			Instant startWebJob = Instant.now();
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS")
					.withZone(ZoneId.of("UTC"));
			String startWebJob_formatted = formatter.format(startWebJob);

			to1.setEmail(System.getenv("TO_EMAIL"));
			to1.setName("NotificationFromIncremental");

			to.add(to1);

			Messages message = new Messages();

			message.setTemplateID(Integer.parseInt(System.getenv("TEMPLATE_ID")));
			message.setTemplateLanguage(TRUE);
			MailjetVariables mailJetVar = new MailjetVariables();

			mailJetVar.setEntityName(entity);
			mailJetVar.setAuditId(fetch_IncrementalDataLoadAuditId);
			mailJetVar.setSource(dataSourceName);

			mailJetVar.setErrorLog(error);
			mailJetVar.setTimeStamp(emailTime);
			message.setVar(mailJetVar);

			message.setTo(to);
			From from = new From();
			from.setEmail("No-Reply@DigitalSelfServe.Financial-Ombudsman.org.uk");
			from.setName("NotificationFromIncremental");
			message.setFrom(from);
			sendmessage.add(message);
			sendMailReq.setMessages(sendmessage);

			String response = send(sendMailReq, entity);
			LOG.info(String.format("sendMailReq response for  %s  at : %s ", entity, startWebJob_formatted));

			if (response.equals("success")) {
				LOG.info(String.format("MailJet API call reponse in case of success for  %s is:  at : %s", entity,
						response, startWebJob_formatted));
			} else {
				LOG.info(String.format("MailJet API call reponse for  %s is:  at : %s", entity, response,
						startWebJob_formatted));
			}
			LOG.info(String.format("sendMailReq response for  %s  ended ", entity));
		} catch (Exception e) {
			LOG.info(String.format("Error log for sendMailReq for  %s  is : %s ", entity, e.getMessage()));
		}

	}

	public String send(SendMailReq req, String entity) throws JSONException {
		LOG.info("Mailjet Send request method started ================ {}", req);
		Gson gson = new Gson();
		String json = gson.toJson(req);
		MailjetResponseBody responseBody = new MailjetResponseBody();
		String status = null;
		LOG.info("Request data {}================", json);

		try {

			responseBody = WebClient.create().post().uri(System.getenv("mailjetUrl"))
					.body(BodyInserters.fromValue(json)).accept(MediaType.APPLICATION_JSON).retrieve()
					.bodyToMono(MailjetResponseBody.class).block();
			if (responseBody != null) {
				status = responseBody.getMessages().get(0).getStatus();
				LOG.info(String.format("WebClient call status for  %s  is %s ", entity, status));
			}
		} catch (Exception ex) {
			LOG.info(String.format("WebClient call failed for  %s,Error log is :  %s ", entity, ex.getMessage()));
			throw new MailJetServiceException("Mailjet Exception occured", ex.getMessage(), ex.getMessage());
		}

		LOG.info("Response : {}", responseBody);
		if (null != responseBody) {
			status = responseBody.getMessages().get(0).getStatus();
		}

		return status;

	}
}
