package com.ombudsman.service.common;

public class ConstantsConfig {

	public final String Entity_Incident = "INCIDENT_ENTITY";
	public final String Entity_Contact = "CONTACT_ENTITY";
	public final String Entity_Caselink = "CASELINK_ENTITY";
	public final String Entity_Email = "EMAIL_ENTITY";
	public final String Entity_Letter = "LETTER_ENTITY";
	public final String Entity_Phone = "PHONE_ENTITY";
	public final String Entity_Task = "TASK_ENTITY";
	public final String Entity_User = "USER_ENTITY";
	public final String Entity_Caseconsideration = "CASECONSIDERATION_ENTITY";
	public final String Entity_Offeroutcome = "OFFEROUTCOME_ENTITY";
	public final String Entity_Correspondence = "CORRESPONDENCE_ENTITY";
	public final String Entity_CorrespondenceSource = "CORRESPONDENCESOURCE_ENTITY";
	public final String Entity_Portal = "PORTAL_ENTITY";
	public final String Entity_Account = "ACCOUNT_ENTITY";
	public final String In_Progress = "In_Progress";
	public final String Pending = "Pending";
	public final String Completed = "Completed";
	public final String Ready_To_Process = "Ready_To_Process";
	public final String Terminated = "Terminated";
	public final String Failed = "Failed";
	public final String DataSourceName = "AZUREFUNC";
	public final String Error_log = "SQL_SP_001";

}
