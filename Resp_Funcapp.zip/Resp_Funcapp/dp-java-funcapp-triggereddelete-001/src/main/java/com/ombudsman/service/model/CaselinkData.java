package com.ombudsman.service.model;

import java.util.UUID;

import jakarta.persistence.Id;

public class CaselinkData {

	@Id
	private UUID fos_caselinkid;

	public UUID getFos_caselinkid() {
		return fos_caselinkid;
	}

}
