package com.ombudsman.service;

import java.beans.Transient;
import java.sql.SQLException;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.UUID;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.jdbc.core.JdbcTemplate;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.microsoft.azure.functions.ExecutionContext;
import com.microsoft.azure.functions.annotation.FunctionName;
import com.microsoft.azure.functions.annotation.ServiceBusQueueTrigger;
import com.ombudsman.service.common.ConstantsConfig;
import com.ombudsman.service.common.JDBCConnectionUtil;
import com.ombudsman.service.model.CaselinkData;
import com.ombudsman.serviceimpl.EmailHelper;
import com.ombudsman.serviceimpl.TriggeredImpl;

public class AzurefunctriggereddeleteCaselink {

	Integer failedCount = 0, totalSuccessCount = 0, totalCount = 0;
	Logger LOG = LogManager.getRootLogger();
	UUID Fetch_IncrementalDataLoadAuditId = null;
	TriggeredImpl triggerimpl = new TriggeredImpl();
	ConstantsConfig constant = new ConstantsConfig();
	JdbcTemplate jdbcTemplate = JDBCConnectionUtil.jdbcConnection();
	EmailHelper emailhelper = new EmailHelper();

	@FunctionName("CaselinkTriggerDelete")
	@Transient(true)
	public void serviceBusProcessCaselink(
			@ServiceBusQueueTrigger(name = "Caselinkmsg", queueName = "%QueueNameCaselink%", connection = "AzureWebJobsServiceBus") String message,
			final ExecutionContext context) throws SQLException {
		LOG.info("Message from caselink service bus queue : {}", message);

		ObjectMapper mapper = new ObjectMapper();
		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

		Instant startWebJob = Instant.now();
		String startWebJob_formatted = startWebJob.truncatedTo(ChronoUnit.MILLIS).toString().replaceAll("[TZ]", " ");

		// Parse the JSON message into CaselinkData object
		try {
			LOG.info("AZURE STARTED in TRY BLOCK for : {}", constant.Entity_Caselink);
			CaselinkData caselinkData = mapper.readValue(message, CaselinkData.class);

			LOG.info("Caselink ID : {} ", caselinkData.getFos_caselinkid());
			int JobId = triggerimpl.getJobID(constant.Entity_Caselink, jdbcTemplate);

			int current_status_id_inprogress = triggerimpl.getCurrentStatusIPId(constant.Entity_Caselink, jdbcTemplate);
			int current_status_id_readytoprocess = triggerimpl.getCurrentStatusRTPId(constant.Entity_Caselink,
					jdbcTemplate);
			UUID incremental_data_load_funcapp_id = UUID.randomUUID();
			triggerimpl.InsertQuery(JobId, startWebJob_formatted, totalCount, totalSuccessCount, failedCount,
					current_status_id_inprogress, constant.DataSourceName, constant.Entity_Caselink,
					constant.Entity_Caselink, jdbcTemplate, incremental_data_load_funcapp_id);

			Fetch_IncrementalDataLoadAuditId = triggerimpl.getIncrementalDataLoadAuditId(startWebJob_formatted,
					current_status_id_inprogress, constant.DataSourceName, constant.Entity_Caselink, jdbcTemplate,
					incremental_data_load_funcapp_id);
			// entry in Caselink table
			triggerimpl.insertRecordcaselink(caselinkData.getFos_caselinkid(), Fetch_IncrementalDataLoadAuditId,
					jdbcTemplate, constant.Entity_Caselink);

			totalCount += 1;

			// Entry in Audit table
			triggerimpl.UpdateQuery(totalCount, totalSuccessCount, failedCount, current_status_id_readytoprocess, null,
					Fetch_IncrementalDataLoadAuditId, constant.Entity_Caselink, jdbcTemplate);

		} catch (Exception e) {
			LOG.info("AZURE STARTED in CATCH BLOCK for : {}", constant.Entity_Caselink);
			String emailTime = Instant.now().toString();
			int current_status_id_failed = triggerimpl.getCurrentStatusFId(constant.Entity_Caselink, jdbcTemplate);
			String DataPayload = message;
			// Entry in Error Table
			triggerimpl.InsertQueryErrorTable(Fetch_IncrementalDataLoadAuditId, DataPayload, current_status_id_failed,
					constant.Error_log, e.getMessage(), constant.Entity_Caselink, constant.Entity_Caselink,
					jdbcTemplate);

			// Entry in Audit table
			triggerimpl.UpdateQuery(totalCount, totalSuccessCount, failedCount, current_status_id_failed,
					Instant.now().toString(), Fetch_IncrementalDataLoadAuditId, constant.Entity_Caselink, jdbcTemplate);

			// Send email to support team
			emailhelper.NotificationWebclient(constant.Entity_Caselink, Fetch_IncrementalDataLoadAuditId,
					constant.DataSourceName, e.getMessage(), emailTime);
			//
			throw new RuntimeException(String.format("Job failed for %s entity with Error : %s",
					constant.Entity_Caselink, e.getMessage()));
		}
	}

}
