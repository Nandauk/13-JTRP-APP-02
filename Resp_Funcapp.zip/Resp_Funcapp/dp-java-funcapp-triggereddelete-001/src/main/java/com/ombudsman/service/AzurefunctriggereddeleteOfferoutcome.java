package com.ombudsman.service;

import java.beans.Transient;
import java.sql.SQLException;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.UUID;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.jdbc.core.JdbcTemplate;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.microsoft.azure.functions.ExecutionContext;
import com.microsoft.azure.functions.annotation.FunctionName;
import com.microsoft.azure.functions.annotation.ServiceBusQueueTrigger;
import com.ombudsman.service.common.ConstantsConfig;
import com.ombudsman.service.common.JDBCConnectionUtil;
import com.ombudsman.service.model.OfferoutcomeData;
import com.ombudsman.serviceimpl.EmailHelper;
import com.ombudsman.serviceimpl.TriggeredImpl;

public class AzurefunctriggereddeleteOfferoutcome {

	Integer failedCount = 0, totalSuccessCount = 0, totalCount = 0;
	Logger LOG = LogManager.getRootLogger();
	UUID Fetch_IncrementalDataLoadAuditId = null;
	TriggeredImpl triggerimpl = new TriggeredImpl();
	ConstantsConfig constant = new ConstantsConfig();
	JdbcTemplate jdbcTemplate = JDBCConnectionUtil.jdbcConnection();
	EmailHelper emailhelper = new EmailHelper();

	@FunctionName("OfferoutcomeTriggerDelete")
	@Transient(true)
	public void serviceBusProcessOfferoutcome(
			@ServiceBusQueueTrigger(name = "Offeroutcomemsg", queueName = "%QueueNameOfferoutcome%", connection = "AzureWebJobsServiceBus") String message,
			final ExecutionContext context) throws SQLException {

		LOG.info("Message from Offeroutcome service bus queue : {}", message);

		ObjectMapper mapper = new ObjectMapper();
		mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

		Instant startWebJob = Instant.now();
		String startWebJob_formatted = startWebJob.truncatedTo(ChronoUnit.MILLIS).toString().replaceAll("[TZ]", " ");

		// Parse the JSON message into OfferoutcomeData object
		try {
			LOG.info("AZURE STARTED in TRY BLOCK for : {}", constant.Entity_Offeroutcome);
			OfferoutcomeData offeroutcomeData = mapper.readValue(message, OfferoutcomeData.class);

			LOG.info("Offeroutcome ID : {} ", offeroutcomeData.getFos_offeroroutcomeid());
			int JobId = triggerimpl.getJobID(constant.Entity_Offeroutcome, jdbcTemplate);

			int current_status_id_inprogress = triggerimpl.getCurrentStatusIPId(constant.Entity_Offeroutcome,
					jdbcTemplate);
			int current_status_id_readytoprocess = triggerimpl.getCurrentStatusRTPId(constant.Entity_Offeroutcome,
					jdbcTemplate);
			UUID incremental_data_load_funcapp_id = UUID.randomUUID();
			triggerimpl.InsertQuery(JobId, startWebJob_formatted, totalCount, totalSuccessCount, failedCount,
					current_status_id_inprogress, constant.DataSourceName, constant.Entity_Offeroutcome,
					constant.Entity_Offeroutcome, jdbcTemplate, incremental_data_load_funcapp_id);

			Fetch_IncrementalDataLoadAuditId = triggerimpl.getIncrementalDataLoadAuditId(startWebJob_formatted,
					current_status_id_inprogress, constant.DataSourceName, constant.Entity_Offeroutcome, jdbcTemplate,
					incremental_data_load_funcapp_id);
			// entry in Offeroutcome table
			triggerimpl.insertRecordofferoutcome(offeroutcomeData.getFos_offeroroutcomeid(),
					Fetch_IncrementalDataLoadAuditId, jdbcTemplate, constant.Entity_Offeroutcome);

			totalCount += 1;

			// Entry in Audit table
			triggerimpl.UpdateQuery(totalCount, totalSuccessCount, failedCount, current_status_id_readytoprocess, null,
					Fetch_IncrementalDataLoadAuditId, constant.Entity_Offeroutcome, jdbcTemplate);

		} catch (Exception e) {
			LOG.info("AZURE STARTED in CATCH BLOCK for : {}", constant.Entity_Offeroutcome);
			String emailTime = Instant.now().toString();
			int current_status_id_failed = triggerimpl.getCurrentStatusFId(constant.Entity_Offeroutcome, jdbcTemplate);
			String DataPayload = message;
			// Entry in Error Table
			triggerimpl.InsertQueryErrorTable(Fetch_IncrementalDataLoadAuditId, DataPayload, current_status_id_failed,
					constant.Error_log, e.getMessage(), constant.Entity_Offeroutcome, constant.Entity_Offeroutcome,
					jdbcTemplate);
			// Entry in Audit table
			triggerimpl.UpdateQuery(totalCount, totalSuccessCount, failedCount, current_status_id_failed,
					Instant.now().toString(), Fetch_IncrementalDataLoadAuditId, constant.Entity_Offeroutcome,
					jdbcTemplate);
			// Send email to support team
			emailhelper.NotificationWebclient(constant.Entity_Offeroutcome, Fetch_IncrementalDataLoadAuditId,
					constant.DataSourceName, e.getMessage(), emailTime);
			//
			throw new RuntimeException(String.format("Job failed for %s entity with Error : %s",
					constant.Entity_Offeroutcome, e.getMessage()));
		}
	}

}
