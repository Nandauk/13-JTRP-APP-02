package com.ombudsman.service.model;

import java.util.UUID;

import jakarta.persistence.Id;

public class EmailData {

	@Id
	private UUID activityid;

	public UUID getActivityid() {
		return activityid;
	}
}
